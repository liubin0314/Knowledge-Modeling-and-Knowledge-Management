/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourEntranceRestrictionsSwellIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether heavy swell is a natural factor restricting the entrance of vessels into the port.";
	}

	private static HashMap<String, HarbourEntranceRestrictionsSwellIndicatorCode> physicalToCode = new HashMap<String, HarbourEntranceRestrictionsSwellIndicatorCode>();

	public static HarbourEntranceRestrictionsSwellIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourEntranceRestrictionsSwellIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourEntranceRestrictionsSwellIndicatorCode NO = new HarbourEntranceRestrictionsSwellIndicatorCode(
			"No",
			"NO",
			"Swell is not a natural factor restricting the entrance of vessels into the harbour.");
	public static final HarbourEntranceRestrictionsSwellIndicatorCode YES = new HarbourEntranceRestrictionsSwellIndicatorCode(
			"Yes",
			"YES",
			"Swell is a natural factor restricting the entrance of vessels into the harbour.");

	private HarbourEntranceRestrictionsSwellIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
