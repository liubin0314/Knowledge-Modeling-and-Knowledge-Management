/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SolidSurfaceStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of a specific solid surface.";
	}

	private static HashMap<String, SolidSurfaceStatusCode> physicalToCode = new HashMap<String, SolidSurfaceStatusCode>();

	public static SolidSurfaceStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SolidSurfaceStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SolidSurfaceStatusCode CLEARED = new SolidSurfaceStatusCode(
			"Cleared",
			"CLEARD",
			"A status indicating that terrain is passable or traversable.");
	public static final SolidSurfaceStatusCode CONTAMINATED = new SolidSurfaceStatusCode(
			"Contaminated",
			"CNTMND",
			"Subjectively judged by the reporting organisation to be defiled, sullied or infected by contact with toxic substances.");
	public static final SolidSurfaceStatusCode DESTROYED = new SolidSurfaceStatusCode(
			"Destroyed",
			"DSTRYD",
			"Subjectively judged by the reporting organisation to be rendered useless or ineffective.");
	public static final SolidSurfaceStatusCode HEAVILY_DAMAGED = new SolidSurfaceStatusCode(
			"Heavily damaged",
			"HVYDAM",
			"Subjectively judged by the reporting organisation to be heavily damaged.");
	public static final SolidSurfaceStatusCode LIGHTLY_DAMAGED = new SolidSurfaceStatusCode(
			"Lightly damaged",
			"LGTDAM",
			"Subjectively judged by the reporting organisation to be only lightly damaged.");
	public static final SolidSurfaceStatusCode MODERATELY_DAMAGED = new SolidSurfaceStatusCode(
			"Moderately damaged",
			"MODDAM",
			"Subjectively judged by the reporting organisation to be moderately damaged.");
	public static final SolidSurfaceStatusCode NOT_KNOWN = new SolidSurfaceStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final SolidSurfaceStatusCode OBSTRUCTED = new SolidSurfaceStatusCode(
			"Obstructed",
			"OBSTRD",
			"Subjectively judged by the reporting organisation that the terrain is obstructed.");

	private SolidSurfaceStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
