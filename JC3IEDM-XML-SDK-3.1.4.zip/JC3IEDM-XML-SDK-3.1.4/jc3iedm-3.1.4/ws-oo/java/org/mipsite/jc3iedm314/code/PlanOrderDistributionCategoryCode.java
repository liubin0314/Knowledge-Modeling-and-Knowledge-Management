/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderDistributionCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value assigned to represent the type of PLAN-ORDER-DISTRIBUTION with respect to the reason for its dissemination.";
	}

	private static HashMap<String, PlanOrderDistributionCategoryCode> physicalToCode = new HashMap<String, PlanOrderDistributionCategoryCode>();

	public static PlanOrderDistributionCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderDistributionCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderDistributionCategoryCode DISTRIBUTED_FOR_EXECUTION = new PlanOrderDistributionCategoryCode(
			"Distributed for execution",
			"DSTEXE",
			"The PLAN-ORDER is to be distributed to the specific ORGANISATION for execution.");
	public static final PlanOrderDistributionCategoryCode DISTRIBUTED_FOR_INFORMATION = new PlanOrderDistributionCategoryCode(
			"Distributed for information",
			"DSTINF",
			"The PLAN-ORDER is to be distributed to the specific ORGANISATION for information only.");

	private PlanOrderDistributionCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
