/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationActionTaskRuleOfEngagementStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the role a responsible ORGANISATION has with respect to the imposition or removal of a specific ACTION-TASK-RULE-OF-ENGAGEMENT.";
	}

	private static HashMap<String, OrganisationActionTaskRuleOfEngagementStatusCategoryCode> physicalToCode = new HashMap<String, OrganisationActionTaskRuleOfEngagementStatusCategoryCode>();

	public static OrganisationActionTaskRuleOfEngagementStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationActionTaskRuleOfEngagementStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationActionTaskRuleOfEngagementStatusCategoryCode AUTHORISATION_REQUEST = new OrganisationActionTaskRuleOfEngagementStatusCategoryCode(
			"Authorisation request",
			"AUTHRQ",
			"The ORGANISATION requests the activation of a particular RULE-OF-ENGAGEMENT for a specific ACTION-TASK.");
	public static final OrganisationActionTaskRuleOfEngagementStatusCategoryCode AUTHORISE = new OrganisationActionTaskRuleOfEngagementStatusCategoryCode(
			"Authorise",
			"AUTHRS",
			"The ORGANISATION activates a particular RULE-OF-ENGAGEMENT for a specific ACTION-TASK.");
	public static final OrganisationActionTaskRuleOfEngagementStatusCategoryCode CANCEL = new OrganisationActionTaskRuleOfEngagementStatusCategoryCode(
			"Cancel",
			"CANCEL",
			"The ORGANISATION deactivates a particular RULE-OF-ENGAGEMENT for a specific ACTION-TASK.");
	public static final OrganisationActionTaskRuleOfEngagementStatusCategoryCode CANCELLATION_REQUEST = new OrganisationActionTaskRuleOfEngagementStatusCategoryCode(
			"Cancellation request",
			"CNCLRQ",
			"The ORGANISATION requests the deactivation of a particular RULE-OF-ENGAGEMENT for a specific ACTION-TASK.");
	public static final OrganisationActionTaskRuleOfEngagementStatusCategoryCode DENY_REQUEST = new OrganisationActionTaskRuleOfEngagementStatusCategoryCode(
			"Deny request",
			"DENYRQ",
			"The ORGANISATION denies a request for activation or cancellation of a particular RULE-OF-ENGAGEMENT for a specific ACTION-TASK.");

	private OrganisationActionTaskRuleOfEngagementStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
