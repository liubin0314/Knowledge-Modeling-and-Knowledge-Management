/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextAssessmentLimitingFactorsCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the logistic factors, which are degrading operational capability in a specific CONTEXT-ASSESSMENT.";
	}

	private static HashMap<String, ContextAssessmentLimitingFactorsCode> physicalToCode = new HashMap<String, ContextAssessmentLimitingFactorsCode>();

	public static ContextAssessmentLimitingFactorsCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextAssessmentLimitingFactorsCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextAssessmentLimitingFactorsCode CROSS_SERVICING_CAPABILITY = new ContextAssessmentLimitingFactorsCode(
			"Cross-servicing capability",
			"CROSS",
			"The specific CONTEXT-ASSESSMENT reflects cross-servicing capability limitations.");
	public static final ContextAssessmentLimitingFactorsCode EQUIPMENT_LIMITATIONS = new ContextAssessmentLimitingFactorsCode(
			"Equipment limitations",
			"EQPLMT",
			"The specific CONTEXT-ASSESSMENT reflects equipment limitations affecting direct mission support.");
	public static final ContextAssessmentLimitingFactorsCode EXCEPTIONAL_SUPPLY = new ContextAssessmentLimitingFactorsCode(
			"Exceptional supply",
			"EXPSPL",
			"The specific CONTEXT-ASSESSMENT reflects exceptional supply shortages affecting the unit�s mission.");
	public static final ContextAssessmentLimitingFactorsCode FACILITY_LIMITATIONS = new ContextAssessmentLimitingFactorsCode(
			"Facility limitations",
			"FACLMT",
			"The specific CONTEXT-ASSESSMENT reflects facility limitations affecting direct mission support.");
	public static final ContextAssessmentLimitingFactorsCode MEDICAL_LIMITATIONS = new ContextAssessmentLimitingFactorsCode(
			"Medical limitations",
			"MEDLMT",
			"The specific CONTEXT-ASSESSMENT reflects medical limitations affecting the unit�s mission.");
	public static final ContextAssessmentLimitingFactorsCode MAINTENANCE_CAPABILITY = new ContextAssessmentLimitingFactorsCode(
			"Maintenance capability",
			"MNTCAP",
			"The specific CONTEXT-ASSESSMENT reflects maintenance capability limitations, including battle damage repair information.");
	public static final ContextAssessmentLimitingFactorsCode MUNITIONS_CAPABILITY = new ContextAssessmentLimitingFactorsCode(
			"Munitions capability",
			"MUNCAP",
			"The specific CONTEXT-ASSESSMENT reflects munitions capability limitations - capability for build-up, storage and transportation, not holdings.");
	public static final ContextAssessmentLimitingFactorsCode NO_CHANGE = new ContextAssessmentLimitingFactorsCode(
			"No change",
			"NOCHNG",
			"The specific CONTEXT-ASSESSMENT reflects no change limitations since last report.");
	public static final ContextAssessmentLimitingFactorsCode NO_LIMITATIONS = new ContextAssessmentLimitingFactorsCode(
			"No limitations",
			"NOLMTN",
			"The specific CONTEXT-ASSESSMENT reflects no limitations since last report.");
	public static final ContextAssessmentLimitingFactorsCode NOT_OTHERWISE_SPECIFIED = new ContextAssessmentLimitingFactorsCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ContextAssessmentLimitingFactorsCode PETROLEUM_OIL_AND_LUBRICATION = new ContextAssessmentLimitingFactorsCode(
			"Petroleum, oil and lubrication",
			"POL",
			"The specific CONTEXT-ASSESSMENT reflects petroleum, oil and lubrication capability limitations � capability to store and deliver, not holdings.");
	public static final ContextAssessmentLimitingFactorsCode PERSONNEL_LIMITATIONS = new ContextAssessmentLimitingFactorsCode(
			"Personnel limitations",
			"PRSLMT",
			"The specific CONTEXT-ASSESSMENT reflects personnel limitations in any area.");
	public static final ContextAssessmentLimitingFactorsCode RAPID_RUNWAY_REPAIR_CAPABILITY = new ContextAssessmentLimitingFactorsCode(
			"Rapid runway repair capability",
			"RRRCAP",
			"The specific CONTEXT-ASSESSMENT reflects capability limitations to perform rapid runway repair.");

	private ContextAssessmentLimitingFactorsCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
