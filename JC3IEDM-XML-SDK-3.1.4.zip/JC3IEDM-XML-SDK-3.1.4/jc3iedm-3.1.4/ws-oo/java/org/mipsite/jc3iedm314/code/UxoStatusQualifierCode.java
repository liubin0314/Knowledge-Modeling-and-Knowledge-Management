/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UxoStatusQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the qualification status of a specific Unexploded Explosive Ordnance.";
	}

	private static HashMap<String, UxoStatusQualifierCode> physicalToCode = new HashMap<String, UxoStatusQualifierCode>();

	public static UxoStatusQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UxoStatusQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UxoStatusQualifierCode BROKEN = new UxoStatusQualifierCode(
			"Broken",
			"BROKEN",
			"The specific value that determines that an Unexploded Explosive Ordnance is broken.");
	public static final UxoStatusQualifierCode INTACT = new UxoStatusQualifierCode(
			"Intact",
			"INTACT",
			"The specific value that determines that an Unexploded Explosive Ordnance is undamaged.");
	public static final UxoStatusQualifierCode LEAKING = new UxoStatusQualifierCode(
			"Leaking",
			"LEAKNG",
			"The specific value that determines that an Unexploded Explosive Ordnance is losing its content.");
	public static final UxoStatusQualifierCode NEW = new UxoStatusQualifierCode(
			"New",
			"NEW",
			"The specific value that determines that an Unexploded Explosive Ordnance is not old.");
	public static final UxoStatusQualifierCode NOT_KNOWN = new UxoStatusQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final UxoStatusQualifierCode NOT_OTHERWISE_SPECIFIED = new UxoStatusQualifierCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final UxoStatusQualifierCode OLD = new UxoStatusQualifierCode(
			"Old",
			"OLD",
			"The specific value that determines that an Unexploded Explosive Ordnance is not new.");
	public static final UxoStatusQualifierCode RUSTED = new UxoStatusQualifierCode(
			"Rusted",
			"RUSTED",
			"The specific value that determines that an Unexploded Explosive Ordnance is corroded.");

	private UxoStatusQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
