/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionEffect extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private ActionEffectDescriptionCode descriptionCode; // mandatory
	private ActionEffectSeverityCode severityCode; // optional
	private Ref<AbstractReportingData> reportingData; // mandatory

	// default constructor

	public AbstractActionEffect() {
		// no assignment
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractActionEffect.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractActionEffect.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public ActionEffectDescriptionCode getDescriptionCode() {
		if (this.descriptionCode == null) {
			throw new NullValueException("AbstractActionEffect.descriptionCode");
		}
		return this.descriptionCode;
	}

	public void setDescriptionCode(ActionEffectDescriptionCode descriptionCode) {
		this.descriptionCode = descriptionCode;
	}

	public ActionEffectSeverityCode getSeverityCode() {
		return this.severityCode;
	}

	public void setSeverityCode(ActionEffectSeverityCode severityCode) {
		this.severityCode = severityCode;
	}

	public Ref<AbstractReportingData> getReportingData() {
		if (this.reportingData == null) {
			throw new NullValueException("AbstractActionEffect.reportingData");
		}
		return this.reportingData;
	}

	public void setReportingData(Ref<AbstractReportingData> reportingData) {
		this.reportingData = reportingData;
	}
}
