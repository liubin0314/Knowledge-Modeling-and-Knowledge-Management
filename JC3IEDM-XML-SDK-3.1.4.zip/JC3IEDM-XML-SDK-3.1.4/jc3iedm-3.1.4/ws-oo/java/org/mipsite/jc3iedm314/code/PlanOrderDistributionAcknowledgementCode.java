/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderDistributionAcknowledgementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of acknowledgement of the distribution for a specific PLAN-ORDER and a specific recipient.";
	}

	private static HashMap<String, PlanOrderDistributionAcknowledgementCode> physicalToCode = new HashMap<String, PlanOrderDistributionAcknowledgementCode>();

	public static PlanOrderDistributionAcknowledgementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderDistributionAcknowledgementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderDistributionAcknowledgementCode ACKNOWLEDGED = new PlanOrderDistributionAcknowledgementCode(
			"Acknowledged",
			"ACK",
			"The recipient has understood the content of a specific PLAN-ORDER.");
	public static final PlanOrderDistributionAcknowledgementCode READ = new PlanOrderDistributionAcknowledgementCode(
			"Read",
			"READ",
			"The recipient has read the content of the specific PLAN-ORDER.");
	public static final PlanOrderDistributionAcknowledgementCode RECEIVED = new PlanOrderDistributionAcknowledgementCode(
			"Received",
			"RCVD",
			"The recipient has taken delivery of the specific PLAN-ORDER.");

	private PlanOrderDistributionAcknowledgementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
