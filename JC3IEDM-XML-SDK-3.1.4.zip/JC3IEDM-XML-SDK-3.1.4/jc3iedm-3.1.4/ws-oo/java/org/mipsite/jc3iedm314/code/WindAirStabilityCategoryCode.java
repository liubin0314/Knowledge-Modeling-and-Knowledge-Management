/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class WindAirStabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value used to indicate the class of air stability.";
	}

	private static HashMap<String, WindAirStabilityCategoryCode> physicalToCode = new HashMap<String, WindAirStabilityCategoryCode>();

	public static WindAirStabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<WindAirStabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final WindAirStabilityCategoryCode DETAILED_VERY_UNSTABLE = new WindAirStabilityCategoryCode(
			"Detailed, very unstable",
			"1",
			"The air is very unstable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table, developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_UNSTABLE = new WindAirStabilityCategoryCode(
			"Detailed, unstable",
			"2",
			"The air is unstable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_SLIGHTLY_UNSTABLE = new WindAirStabilityCategoryCode(
			"Detailed, slightly unstable",
			"3",
			"The air is slightly unstable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_NEUTRAL = new WindAirStabilityCategoryCode(
			"Detailed, neutral",
			"4",
			"The air is neutral in stability, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_SLIGHTLY_STABLE = new WindAirStabilityCategoryCode(
			"Detailed, slightly stable",
			"5",
			"The air is slightly stable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_STABLE = new WindAirStabilityCategoryCode(
			"Detailed, stable",
			"6",
			"The air is stable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode DETAILED_VERY_STABLE = new WindAirStabilityCategoryCode(
			"Detailed, very stable",
			"7",
			"The air is very stable, with reference to the detailed class. This is determined from observations of wind speed, cloud cover, and time of day based on a standard table developed from the work of Pasquill, Gifford, and Turner. The more unstable the conditions, the greater the degree of mixing, and the shorter the range of effectiveness.");
	public static final WindAirStabilityCategoryCode SIMPLIFIED_NEUTRAL = new WindAirStabilityCategoryCode(
			"Simplified, neutral",
			"N",
			"The degree of mixing is intermediate between that for stable and unstable conditions, and the range of effectiveness is intermediate between that for stable and unstable conditions.");
	public static final WindAirStabilityCategoryCode SIMPLIFIED_STABLE = new WindAirStabilityCategoryCode(
			"Simplified, stable",
			"S",
			"The air is stable, so there is little mixing, and the material is effective over longer distances.");
	public static final WindAirStabilityCategoryCode SIMPLIFIED_UNSTABLE = new WindAirStabilityCategoryCode(
			"Simplified, unstable",
			"U",
			"The air is unstable, so there is strong mixing, and the material is effective over shorter distances.");

	private WindAirStabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
