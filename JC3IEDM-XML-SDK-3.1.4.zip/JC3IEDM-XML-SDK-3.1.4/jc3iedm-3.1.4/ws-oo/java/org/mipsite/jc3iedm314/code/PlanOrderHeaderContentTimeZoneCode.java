/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderHeaderContentTimeZoneCode extends CodeDomain {

	public static String getComment() {
		return "The specific value assigned to represent divisions of the Earth's surface in which standard time is kept as it applies to the specific PLAN-ORDER.";
	}

	private static HashMap<String, PlanOrderHeaderContentTimeZoneCode> physicalToCode = new HashMap<String, PlanOrderHeaderContentTimeZoneCode>();

	public static PlanOrderHeaderContentTimeZoneCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderHeaderContentTimeZoneCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_1_HOUR = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 1 hour",
			"A",
			"Universal Time Coordinate with 1 hour added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_2_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 2 hours",
			"B",
			"Universal Time Coordinate with 2 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_3_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 3 hours",
			"C",
			"Universal Time Coordinate with 3 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_3_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 3 hours and 30 minutes",
			"C30",
			"Universal Time Coordinate with 3 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_4_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 4 hours",
			"D",
			"Universal Time Coordinate with 4 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_4_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 4 hours and 30 minutes",
			"D30",
			"Universal Time Coordinate with 4 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_5_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 5 hours",
			"E",
			"Universal Time Coordinate with 5 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_5_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 5 hours and 30 minutes",
			"E30",
			"Universal Time Coordinate with 5 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_5_HOURS_AND_45_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 5 hours and 45 minutes",
			"E45",
			"Universal Time Coordinate with 5 hours and 45 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_6_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 6 hours",
			"F",
			"Universal Time Coordinate with 6 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_6_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 6 hours and 30 minutes",
			"F30",
			"Universal Time Coordinate with 6 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_7_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 7 hours",
			"G",
			"Universal Time Coordinate with 7 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_8_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 8 hours",
			"H",
			"Universal Time Coordinate with 8 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_8_HOURS_AND_45_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 8 hours and 45 minutes",
			"H45",
			"Universal Time Coordinate with 8 hours and 45 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_9_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 9 hours",
			"I",
			"Universal Time Coordinate with 9 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_9_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 9 hours and 30 minutes",
			"I30",
			"Universal Time Coordinate with 9 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_10_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 10 hours",
			"K",
			"Universal Time Coordinate with 10 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_10_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 10 hours and 30 minutes",
			"K30",
			"Universal Time Coordinate with 10hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_11_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 11 hours",
			"L",
			"Universal Time Coordinate with 11 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_11_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 11 hours and 30 minutes",
			"L30",
			"Universal Time Coordinate with 11 hours and 30 minutes added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_12_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 12 hours",
			"M",
			"Universal Time Coordinate with 12 hours added.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_14_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 14 hours",
			"M120",
			"Universal Time Coordinate with 14 hours.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_PLUS_13_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC plus 13 hours",
			"M60",
			"Universal Time Coordinate with 13 hours.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_1_HOUR = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 1 hour",
			"N",
			"Universal Time Coordinate with 1 hour subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_2_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 2 hours",
			"O",
			"Universal Time Coordinate with 2 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_3_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 3 hours",
			"P",
			"Universal Time Coordinate with 3 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_3_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 3 hours and 30 minutes",
			"P30",
			"Universal Time Coordinate with 3 hours and 30 minutes subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_4_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 4 hours",
			"Q",
			"Universal Time Coordinate with 4 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_4_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 4 hours and 30 minutes",
			"Q30",
			"Universal Time Coordinate with 4 hours and 30 minutes subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_5_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 5 hours",
			"R",
			"Universal Time Coordinate with 5 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_6_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 6 hours",
			"S",
			"Universal Time Coordinate with 6 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_7_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 7 hours",
			"T",
			"Universal Time Coordinate with 7 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_8_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 8 hours",
			"U",
			"Universal Time Coordinate with 8 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_9_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 9 hours",
			"V",
			"Universal Time Coordinate with 9 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_9_HOURS_AND_30_MINUTES = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 9 hours and 30 minutes",
			"V30",
			"Universal Time Coordinate with 9 hours and 30 minutes subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_10_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 10 hours",
			"W",
			"Universal Time Coordinate with 10 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_11_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 11 hours",
			"X",
			"Universal Time Coordinate with 11 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_MINUS_12_HOURS = new PlanOrderHeaderContentTimeZoneCode(
			"UTC minus 12 hours",
			"Y",
			"Universal Time Coordinate with 12 hours subtracted.");
	public static final PlanOrderHeaderContentTimeZoneCode UTC_ZULU = new PlanOrderHeaderContentTimeZoneCode(
			"UTC (Zulu)",
			"Z",
			"Universal Time Coordinate (Zulu).");

	private PlanOrderHeaderContentTimeZoneCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
