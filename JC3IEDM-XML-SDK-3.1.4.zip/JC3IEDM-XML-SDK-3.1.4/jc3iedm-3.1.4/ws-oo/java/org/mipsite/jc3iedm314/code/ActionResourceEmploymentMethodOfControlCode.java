/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceEmploymentMethodOfControlCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the standard procedure to be used in controlling the employment of a specific ACTION-RESOURCE in support of a specific ACTION.";
	}

	private static HashMap<String, ActionResourceEmploymentMethodOfControlCode> physicalToCode = new HashMap<String, ActionResourceEmploymentMethodOfControlCode>();

	public static ActionResourceEmploymentMethodOfControlCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceEmploymentMethodOfControlCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceEmploymentMethodOfControlCode AS_ORDERED = new ActionResourceEmploymentMethodOfControlCode(
			"As ordered",
			"ASORD",
			"The target is fired upon at the direction of the observer, the supported unit or the higher headquarters.");
	public static final ActionResourceEmploymentMethodOfControlCode ON_ORDERS = new ActionResourceEmploymentMethodOfControlCode(
			"On orders",
			"ONORD",
			"The ACTION-RESOURCE will be used at a to be specified time.");

	private ActionResourceEmploymentMethodOfControlCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
