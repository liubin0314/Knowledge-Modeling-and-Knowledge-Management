/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusOperationalStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the operational status of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusOperationalStatusCode> physicalToCode = new HashMap<String, MaterielStatusOperationalStatusCode>();

	public static MaterielStatusOperationalStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusOperationalStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusOperationalStatusCode MARGINALLY_OPERATIONAL = new MaterielStatusOperationalStatusCode(
			"Marginally operational",
			"MOPS",
			"Subjectively judged by the reporting organisation to be marginally capable of performing the functions for which it is designed.");
	public static final MaterielStatusOperationalStatusCode NOT_KNOWN = new MaterielStatusOperationalStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusOperationalStatusCode NOT_OPERATIONAL = new MaterielStatusOperationalStatusCode(
			"Not operational",
			"NOP",
			"Subjectively judged by the reporting organisation to be permanently not capable of performing functions for which it is designed.");
	public static final MaterielStatusOperationalStatusCode OPERATIONAL = new MaterielStatusOperationalStatusCode(
			"Operational",
			"OPR",
			"Subjectively judged by the reporting organisation to be capable of performing or functions for which it is designed.");
	public static final MaterielStatusOperationalStatusCode SUBSTANTIALLY_OPERATIONAL = new MaterielStatusOperationalStatusCode(
			"Substantially operational",
			"SOPS",
			"Subjectively judged by the reporting organisation to have minor deficiencies that limit its capability to perform functions for which it is designed.");
	public static final MaterielStatusOperationalStatusCode TEMPORARILY_NOT_OPERATIONAL = new MaterielStatusOperationalStatusCode(
			"Temporarily not operational",
			"TNOPS",
			"Subjectively judged by the reporting organisation to be temporarily not capable of performing functions for which it is designed.");

	private MaterielStatusOperationalStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
