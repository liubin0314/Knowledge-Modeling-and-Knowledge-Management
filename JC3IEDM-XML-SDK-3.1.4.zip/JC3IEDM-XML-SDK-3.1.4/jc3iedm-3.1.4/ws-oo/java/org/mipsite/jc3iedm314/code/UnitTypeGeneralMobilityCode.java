/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeGeneralMobilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general mobility of a unit, seen as a whole.";
	}

	private static HashMap<String, UnitTypeGeneralMobilityCode> physicalToCode = new HashMap<String, UnitTypeGeneralMobilityCode>();

	public static UnitTypeGeneralMobilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeGeneralMobilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeGeneralMobilityCode AIR = new UnitTypeGeneralMobilityCode(
			"Air",
			"AIR",
			"The specified UNIT-TYPE moves generally through the air.");
	public static final UnitTypeGeneralMobilityCode AIR_COMPOSITE = new UnitTypeGeneralMobilityCode(
			"Air, composite",
			"AIRCMP",
			"The specified UNIT-TYPE moves generally through the air by means that combine deriving lift from fixed wings or from airfoils that rotate.");
	public static final UnitTypeGeneralMobilityCode AIR_FIXED_WING = new UnitTypeGeneralMobilityCode(
			"Air, fixed wing",
			"AIRFW",
			"The specified UNIT-TYPE moves generally through the air by deriving lift from fixed wings.");
	public static final UnitTypeGeneralMobilityCode AIR_ROTARY_WING = new UnitTypeGeneralMobilityCode(
			"Air, rotary wing",
			"AIRRW",
			"The specified UNIT-TYPE moves generally through the air by deriving lift from airfoils that rotate.");
	public static final UnitTypeGeneralMobilityCode AIR_VSTOL = new UnitTypeGeneralMobilityCode(
			"Air, VSTOL",
			"AIRVST",
			"The specified UNIT-TYPE moves generally through the air by using aircraft able to take off and land on very short distances.");
	public static final UnitTypeGeneralMobilityCode AMPHIBIOUS = new UnitTypeGeneralMobilityCode(
			"Amphibious",
			"AMPH",
			"The specified UNIT-TYPE moves generally both on land and in water.");
	public static final UnitTypeGeneralMobilityCode DISMOUNTED = new UnitTypeGeneralMobilityCode(
			"Dismounted",
			"DSMNTD",
			"The specified UNIT-TYPE moves generally on foot.");
	public static final UnitTypeGeneralMobilityCode HORSE = new UnitTypeGeneralMobilityCode(
			"Horse",
			"HORSE",
			"The specified UNIT-TYPE moves generally while carried by horses.");
	public static final UnitTypeGeneralMobilityCode LAND = new UnitTypeGeneralMobilityCode(
			"Land",
			"LAND",
			"The specified UNIT-TYPE moves generally on the ground.");
	public static final UnitTypeGeneralMobilityCode LAND_RAILED = new UnitTypeGeneralMobilityCode(
			"Land, railed",
			"LNDRAI",
			"The specified UNIT-TYPE moves generally on the ground, along rails.");
	public static final UnitTypeGeneralMobilityCode LAND_TRACKED = new UnitTypeGeneralMobilityCode(
			"Land, tracked",
			"LNDTRC",
			"The specified UNIT-TYPE moves generally on the ground by means of vehicles using caterpillar treads.");
	public static final UnitTypeGeneralMobilityCode LAND_TOWED = new UnitTypeGeneralMobilityCode(
			"Land, towed",
			"LNDTWD",
			"The main equipment of the specified UNIT-TYPE moves generally on the ground by means of external propulsion (mechanical or animal).");
	public static final UnitTypeGeneralMobilityCode LAND_WHEELED = new UnitTypeGeneralMobilityCode(
			"Land, wheeled",
			"LNDWHL",
			"The specified UNIT-TYPE moves generally on the ground by means of vehicles using wheels.");

	private UnitTypeGeneralMobilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
