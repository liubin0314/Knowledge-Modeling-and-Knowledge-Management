/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskOperationalLevelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the operational level of the specific ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskOperationalLevelCode> physicalToCode = new HashMap<String, ActionTaskOperationalLevelCode>();

	public static ActionTaskOperationalLevelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskOperationalLevelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskOperationalLevelCode STRATEGIC = new ActionTaskOperationalLevelCode(
			"Strategic",
			"STRTGC",
			"An ACTION-TASK executed at the strategic or operational level to achieve desired strategic effects and thus are likely to be shaped by political aims and constraints. Strategic attack is carried out against an adversary�s Centre of Gravity (CoG) or other vital target sets including command elements, military production assets and key supporting infrastructure.");
	public static final ActionTaskOperationalLevelCode TACTICAL = new ActionTaskOperationalLevelCode(
			"Tactical",
			"TACTCL",
			"An ACTION-TASK executed in full respect of fundamental principles designed to provide guidance for the employment of power in tactical operations to attain established objectives.");

	private ActionTaskOperationalLevelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
