/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldLandPatternCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the pattern of a specific MINEFIELD-LAND.";
	}

	private static HashMap<String, MinefieldLandPatternCode> physicalToCode = new HashMap<String, MinefieldLandPatternCode>();

	public static MinefieldLandPatternCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldLandPatternCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldLandPatternCode NOT_KNOWN = new MinefieldLandPatternCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MinefieldLandPatternCode REGULAR_MINEFIELD = new MinefieldLandPatternCode(
			"Regular minefield",
			"REGMNF",
			"A minefield that is implemented by placing mines one at a time in a regular pattern as directed by current doctrine (for example, straight line or zigzag).");
	public static final MinefieldLandPatternCode REGULAR_MINEFIELD_THICKENED_WITH_SCATTERED_MINES = new MinefieldLandPatternCode(
			"Regular minefield, thickened with scattered mines",
			"REGTHK",
			"A minefield that is implemented by placing mines one at a time in combination with scattered mines.");
	public static final MinefieldLandPatternCode SCATTERED = new MinefieldLandPatternCode(
			"Scattered",
			"SCATTR",
			"A minefield that is implemented by mines that are delivered by aircraft, artillery, missile or ground dispenser without any regard to classical patterns.");

	private MinefieldLandPatternCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
