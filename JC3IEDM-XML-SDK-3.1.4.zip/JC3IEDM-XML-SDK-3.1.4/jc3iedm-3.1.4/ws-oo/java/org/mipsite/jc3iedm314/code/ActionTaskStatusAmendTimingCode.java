/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStatusAmendTimingCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes request or requirement to modify the timing associated with a specific ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskStatusAmendTimingCode> physicalToCode = new HashMap<String, ActionTaskStatusAmendTimingCode>();

	public static ActionTaskStatusAmendTimingCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStatusAmendTimingCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStatusAmendTimingCode REQUIRE_END_AMEND_TIME = new ActionTaskStatusAmendTimingCode(
			"Require end amend time",
			"RQEEAT",
			"The timings entered into this entity represent the new timings the reporting organisation requires to achieve its part of the ACTION-TASK.");
	public static final ActionTaskStatusAmendTimingCode REQUIRE_START_AMEND_TIME = new ActionTaskStatusAmendTimingCode(
			"Require start amend time",
			"RQESAT",
			"The timings entered into this entity represent the new timings the reporting organisation requires to achieve its part of the ACTION-TASK.");
	public static final ActionTaskStatusAmendTimingCode REQUEST_END_AMEND_TIME = new ActionTaskStatusAmendTimingCode(
			"Request end amend time",
			"RQSEAT",
			"The times entered into this entity represent the reporting organisation�s requested alterations to the ACTION-TASK timings.");
	public static final ActionTaskStatusAmendTimingCode REQUEST_START_AMEND_TIME = new ActionTaskStatusAmendTimingCode(
			"Request start amend time",
			"RQSSAT",
			"The times entered into this entity represent the reporting organisation�s requested alterations to the ACTION-TASK timings.");

	private ActionTaskStatusAmendTimingCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
