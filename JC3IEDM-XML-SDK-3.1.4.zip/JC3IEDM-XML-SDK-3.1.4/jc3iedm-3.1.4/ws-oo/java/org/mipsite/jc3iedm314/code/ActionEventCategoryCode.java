/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEventCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general class or nature of activity prescribed by an ACTION-EVENT.";
	}

	private static HashMap<String, ActionEventCategoryCode> physicalToCode = new HashMap<String, ActionEventCategoryCode>();

	public static ActionEventCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEventCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEventCategoryCode ABDICATION = new ActionEventCategoryCode(
			"Abdication",
			"ABDICA",
			"The renouncement by a person of his official functions.");
	public static final ActionEventCategoryCode ACCIDENT_AIRCRAFT_GROUND = new ActionEventCategoryCode(
			"Accident, aircraft ground",
			"ACCAIR",
			"An accident involving an aircraft during ground operations or maintenance.");
	public static final ActionEventCategoryCode ACCIDENT = new ActionEventCategoryCode(
			"Accident",
			"ACCDNT",
			"An unfortunate event, esp. one causing physical harm or damage, brought about unintentionally.");
	public static final ActionEventCategoryCode ACCIDENT_MINE = new ActionEventCategoryCode(
			"Accident, mine",
			"ACCMNE",
			"An accident involving unexploded ordnance.");
	public static final ActionEventCategoryCode ACCIDENT_TRAFFIC = new ActionEventCategoryCode(
			"Accident, traffic",
			"ACCTRF",
			"An accident involving at least one motor vehicle.");
	public static final ActionEventCategoryCode ACCIDENT_WEAPON = new ActionEventCategoryCode(
			"Accident, weapon",
			"ACCWPN",
			"An accident involving a weapon.");
	public static final ActionEventCategoryCode ACCIDENT_WORKPLACE = new ActionEventCategoryCode(
			"Accident, workplace",
			"ACCWRK",
			"An accident occurring at the workplace.");
	public static final ActionEventCategoryCode AIRCRAFT_LOSS = new ActionEventCategoryCode(
			"Aircraft loss",
			"ACRLOS",
			"The unforeseen loss of an aircraft (and personnel), other than crash.");
	public static final ActionEventCategoryCode ADVANCING = new ActionEventCategoryCode(
			"Advancing",
			"ADVANC",
			"Moving towards an objective in some form of tactical formation. This is a transitional phase between operations that may or may not result in contact with the enemy.");
	public static final ActionEventCategoryCode AERIAL_ENGAGEMENT = new ActionEventCategoryCode(
			"Aerial engagement",
			"AERENG",
			"The occurrence of a hostile encounter between military aircraft.");
	public static final ActionEventCategoryCode AERIAL_SHOOT_DOWN = new ActionEventCategoryCode(
			"Aerial shoot down",
			"AERSHO",
			"The deliberate destruction of an aircraft.");
	public static final ActionEventCategoryCode AIRCRAFT_CRASH = new ActionEventCategoryCode(
			"Aircraft crash",
			"AIRCRS",
			"The unforeseen destruction or damage of an aircraft (and personnel).");
	public static final ActionEventCategoryCode AIRCRAFT_LAUNCH_ACTIVITY = new ActionEventCategoryCode(
			"Aircraft launch activity",
			"AIRLAU",
			"The occurrence of one or more aircraft taking off.");
	public static final ActionEventCategoryCode AIRCRAFT_LANDING = new ActionEventCategoryCode(
			"Aircraft landing",
			"AIRLND",
			"The action of approaching and alighting on the ground or some other surface after a flight.");
	public static final ActionEventCategoryCode AIRSPACE_VIOLATION = new ActionEventCategoryCode(
			"Airspace violation",
			"AIRVIO",
			"The invasion of the declared own airspace by an aircraft.");
	public static final ActionEventCategoryCode ALERT_CANCELLATION = new ActionEventCategoryCode(
			"Alert cancellation",
			"ALRCAN",
			"The end of a state of readiness.");
	public static final ActionEventCategoryCode AMBUSH = new ActionEventCategoryCode(
			"Ambush",
			"AMBUSH",
			"A surprise attack by fire or other destructive means from concealed positions on a moving or temporarily halted force or group of personnel.");
	public static final ActionEventCategoryCode AMPHIBIOUS_OPERATION = new ActionEventCategoryCode(
			"Amphibious operation",
			"AMPH",
			"Mounting an operation launched from the sea by naval and land forces against a hostile, or potentially hostile shore.");
	public static final ActionEventCategoryCode AIR_ASSAULT = new ActionEventCategoryCode(
			"Air assault",
			"ARASLT",
			"Mounting an assault utilising a mixture of aviation and ground transport, the principal feature of which is the insertion of combat power.");
	public static final ActionEventCategoryCode AIRBORNE_ASSAULT = new ActionEventCategoryCode(
			"Airborne assault",
			"ARBNAS",
			"Mounting an airborne operation, a phase beginning with delivery by air of the assault echelon of the force into the objective area and extending through attack of assault objectives and consolidation of the initial airhead.");
	public static final ActionEventCategoryCode ARMS_PRODUCTION = new ActionEventCategoryCode(
			"Arms production",
			"ARMPRD",
			"An activity of, relating to or based on the production of arms.");
	public static final ActionEventCategoryCode ARMS_TRADE = new ActionEventCategoryCode(
			"Arms trade",
			"ARMTRD",
			"A happening of selling or buying of arms.");
	public static final ActionEventCategoryCode ARRESTING_LEGAL = new ActionEventCategoryCode(
			"Arresting, legal",
			"ARRLGL",
			"Seizing and detaining of a person under authority of the law.");
	public static final ActionEventCategoryCode ARRESTING_OBSTRUCTING = new ActionEventCategoryCode(
			"Arresting/obstructing",
			"ARROBS",
			"Stopping or checking of the motion, progress, growth, or spread of something.");
	public static final ActionEventCategoryCode ARSON = new ActionEventCategoryCode(
			"Arson",
			"ARSON",
			"The crime of maliciously setting fire to the property of another or of burning one's own property for an improper purpose, as to collect insurance.");
	public static final ActionEventCategoryCode ARTILLERY_FIRE = new ActionEventCategoryCode(
			"Artillery fire",
			"ARTFIR",
			"The use of artillery fire.");
	public static final ActionEventCategoryCode ASSEMBLING = new ActionEventCategoryCode(
			"Assembling",
			"ASSMBL",
			"Joining together of multiple objects in the same area.");
	public static final ActionEventCategoryCode ASSASSINATION = new ActionEventCategoryCode(
			"Assassination",
			"ASSNTN",
			"Murder of a prominent person.");
	public static final ActionEventCategoryCode ASSISTING_A_CRIMINAL = new ActionEventCategoryCode(
			"Assisting a criminal",
			"ASTCRM",
			"Assisting or abetting a known criminal or terrorist.");
	public static final ActionEventCategoryCode ATMOSPHERIC_POLLUTION = new ActionEventCategoryCode(
			"Atmospheric pollution",
			"ATMPOL",
			"Contamination of the atmosphere caused by a poison or toxin.");
	public static final ActionEventCategoryCode ATTEMPTED_MURDER = new ActionEventCategoryCode(
			"Attempted murder",
			"ATMRDR",
			"The attempted act of unlawfully killing of one human being by another, especially with premeditated malice.");
	public static final ActionEventCategoryCode ATTEMPTED_RAPE = new ActionEventCategoryCode(
			"Attempted rape",
			"ATRAPE",
			"The attempted act of forcing another person to submit to sexual intercourse.");
	public static final ActionEventCategoryCode ATTEMPTED_ROBBERY = new ActionEventCategoryCode(
			"Attempted robbery",
			"ATRBRY",
			"The attempted act of robbing a person or place.");
	public static final ActionEventCategoryCode ATTEMPTED_SUICIDE = new ActionEventCategoryCode(
			"Attempted suicide",
			"ATSCDE",
			"The attempted act of killing oneself intentionally.");
	public static final ActionEventCategoryCode ATTACK_NOT_OTHERWISE_SPECIFIED = new ActionEventCategoryCode(
			"Attack, not otherwise specified",
			"ATTACK",
			"Conducting an offensive operation characterised by coordinated employment of firepower and manoeuvre to close with and destroy or capture the enemy.");
	public static final ActionEventCategoryCode ATTACK_DIVERSION = new ActionEventCategoryCode(
			"Attack, diversion",
			"ATTDVR",
			"Conducting an attack wherein a force attacks, or threatens to attack, a target other than the main target for the purpose of drawing enemy defences away from the main effort.");
	public static final ActionEventCategoryCode ATTACK_ELECTRONIC = new ActionEventCategoryCode(
			"Attack, electronic",
			"ATTEL",
			"Conducting electronic warfare involving the use of electromagnetic energy, directed energy or anti-radiation weapons to attack personnel, facilities, or equipment with the intent of degrading, neutralizing, or destroying enemy combat capability and is considered a form of fires.");
	public static final ActionEventCategoryCode ATTACK_MAIN = new ActionEventCategoryCode(
			"Attack, main",
			"ATTMN",
			"Conducting the principal attack or effort into which the commander throws the full weight of the offensive power at his disposal. An attack directed against the chief objective of the campaign or battle.");
	public static final ActionEventCategoryCode ATTACK_SUPPORTING = new ActionEventCategoryCode(
			"Attack, supporting",
			"ATTSPT",
			"Conducting an offensive operation carried out in conjunction with a main attack and designed to achieve one or more of the following: a. deceive the enemy; b. destroy or pin down enemy forces which could interfere with the main attack; c. control ground whose occupation by the enemy will hinder the main attack; or d. force the enemy to commit reserves prematurely or in an indecisive area.");
	public static final ActionEventCategoryCode AVOIDING = new ActionEventCategoryCode(
			"Avoiding",
			"AVOIDN",
			"Staying clear of a specified object.");
	public static final ActionEventCategoryCode BOOBY_TRAP_DISCOVERY = new ActionEventCategoryCode(
			"Booby trap discovery",
			"BBYTRD",
			"The detection of a device intended to cause damage to unsuspecting people.");
	public static final ActionEventCategoryCode BORDER_CROSSING_ESCORTED = new ActionEventCategoryCode(
			"Border crossing, escorted",
			"BCESC",
			"A border crossing that is conducted under escort.");
	public static final ActionEventCategoryCode BORDER_CROSSING_FORCED = new ActionEventCategoryCode(
			"Border crossing, forced",
			"BCFRCD",
			"A border crossing that is conducted under pressure.");
	public static final ActionEventCategoryCode BORDER_CROSSING_ILLEGAL = new ActionEventCategoryCode(
			"Border crossing, illegal",
			"BCILGL",
			"A border crossing that is forbidden by law.");
	public static final ActionEventCategoryCode BORDER_CROSSING_NOT_PLANNED = new ActionEventCategoryCode(
			"Border crossing, not-planned",
			"BCNTPL",
			"A border crossing that is unplanned.");
	public static final ActionEventCategoryCode BORDER_CROSSING_PLANNED = new ActionEventCategoryCode(
			"Border crossing, planned",
			"BCPLND",
			"A border crossing that is known to have been planned ahead of time.");
	public static final ActionEventCategoryCode BORDER_CROSSING_SURVEILLED = new ActionEventCategoryCode(
			"Border crossing, surveilled",
			"BCSRVL",
			"A border crossing that is conducted under surveillance.");
	public static final ActionEventCategoryCode BUILD_UP = new ActionEventCategoryCode(
			"Build-up",
			"BLDUP",
			"Attaining prescribed strength of units and prescribed levels of vehicles, equipment, stores and supplies.");
	public static final ActionEventCategoryCode BLOCKING = new ActionEventCategoryCode(
			"Blocking",
			"BLOCKN",
			"Denying of enemy access to an area or preventing his advance in a direction or along an avenue of approach.");
	public static final ActionEventCategoryCode BELLY_LANDING = new ActionEventCategoryCode(
			"Belly landing",
			"BLYLND",
			"An aircraft has landed without using the landing gear.");
	public static final ActionEventCategoryCode BOMBING_ACCIDENTAL = new ActionEventCategoryCode(
			"Bombing, accidental",
			"BMBACC",
			"An unfortunate bombing incident that happens unexpectedly and unintentionally.");
	public static final ActionEventCategoryCode BOMBING_DELIBERATE = new ActionEventCategoryCode(
			"Bombing, deliberate",
			"BMBDLB",
			"A deliberate and intentional bombing incident.");
	public static final ActionEventCategoryCode BOMBING = new ActionEventCategoryCode(
			"Bombing",
			"BOMBNG",
			"Attacking, damaging or destroying through the use of bombs.");
	public static final ActionEventCategoryCode BORDER_INCURSION = new ActionEventCategoryCode(
			"Border incursion",
			"BORINC",
			"Moving a force or a group of people across a national or territorial border.");
	public static final ActionEventCategoryCode BORDER_RAID = new ActionEventCategoryCode(
			"Border raid",
			"BORRAI",
			"A surprise attack by a force or a group of people across a national or territorial border (restricted to 25 km from the border).");
	public static final ActionEventCategoryCode BREACHING = new ActionEventCategoryCode(
			"Breaching",
			"BREACH",
			"Breaking through or securing a passage through an enemy defence, obstacle, minefield, or fortification.");
	public static final ActionEventCategoryCode BURNED_OUT_OBJECT = new ActionEventCategoryCode(
			"Burned out object",
			"BRNOBJ",
			"Complete destruction of an object by flames.");
	public static final ActionEventCategoryCode BYPASS = new ActionEventCategoryCode(
			"Bypass",
			"BYPASS",
			"Manoeuvring around an obstacle, position, or enemy force to maintain the momentum of advance.");
	public static final ActionEventCategoryCode CANALISE = new ActionEventCategoryCode(
			"Canalise",
			"CANLSE",
			"Restricting operations to a narrow zone by use of existing or reinforcing obstacles or by fire or bombing.");
	public static final ActionEventCategoryCode CAPTURE = new ActionEventCategoryCode(
			"Capture",
			"CAPTUR",
			"Taking possession of an object, normally by force; it frequently involves movement as a preliminary phase.");
	public static final ActionEventCategoryCode CARRIER_LAUNCH = new ActionEventCategoryCode(
			"Carrier launch",
			"CARLNC",
			"Launching of aircraft by a naval platform.");
	public static final ActionEventCategoryCode CARRIER_RECOVERY = new ActionEventCategoryCode(
			"Carrier recovery",
			"CARREC",
			"Aircraft recovery by a naval platform.");
	public static final ActionEventCategoryCode CBRN_EVENT = new ActionEventCategoryCode(
			"CBRN-EVENT",
			"CBRN",
			"An ACTION-EVENT that involves chemical, biological, radiological, or nuclear materiel individually or in combination.");
	public static final ActionEventCategoryCode CODEWORD_EXECUTION = new ActionEventCategoryCode(
			"Codeword execution",
			"CDWDEX",
			"Initiating the codeword activity.");
	public static final ActionEventCategoryCode CEREMONY_OR_PARADE = new ActionEventCategoryCode(
			"Ceremony or parade",
			"CEREMN",
			"The formal gathering of a group of people in order to carry out an act or series of acts prescribed by ritual protocol or convention.");
	public static final ActionEventCategoryCode CIVIL_DISOBEDIENCE = new ActionEventCategoryCode(
			"Civil disobedience",
			"CIVDIS",
			"The refusal to comply with certain laws or to pay taxes etc. as a peaceful form of political protest.");
	public static final ActionEventCategoryCode CIVIL_DEMONSTRATION_ILLEGAL = new ActionEventCategoryCode(
			"Civil demonstration, illegal",
			"CIVDMI",
			"A public meeting or march illegally expressing protest or other opinion on an issue.");
	public static final ActionEventCategoryCode CIVIL_DEMONSTRATION_LEGAL = new ActionEventCategoryCode(
			"Civil demonstration, legal",
			"CIVDML",
			"A public meeting or march legally expressing protest or other opinion on an issue.");
	public static final ActionEventCategoryCode CIVIL_UNREST = new ActionEventCategoryCode(
			"Civil unrest",
			"CIVUNR",
			"A behaviour that results in the disturbance of the normal order of society that generally falls short of riots and/or property destruction in the civil population.");
	public static final ActionEventCategoryCode CIVIL_WAR = new ActionEventCategoryCode(
			"Civil war",
			"CIVWAR",
			"A war among fellow-citizens or within the limits of one community.");
	public static final ActionEventCategoryCode CLEARING_AIR = new ActionEventCategoryCode(
			"Clearing, air",
			"CLRAIR",
			"Clearing of the air to gain either temporary or permanent air superiority or control in a given sector.");
	public static final ActionEventCategoryCode CLEARING_LAND_COMBAT = new ActionEventCategoryCode(
			"Clearing, land combat",
			"CLRLND",
			"Removing all enemy forces from a specific location, area, or zone.");
	public static final ActionEventCategoryCode CLEARING_OBSTACLE = new ActionEventCategoryCode(
			"Clearing, obstacle",
			"CLROBS",
			"Eliminating or neutralizing an obstacle.");
	public static final ActionEventCategoryCode CLEARING_RADIO_NET = new ActionEventCategoryCode(
			"Clearing, radio net",
			"CLRRAD",
			"Eliminating transmissions on a tactical radio net in order to allow a higher precedence transmission to occur.");
	public static final ActionEventCategoryCode CONDUCTING_CONFERENCE = new ActionEventCategoryCode(
			"Conducting conference",
			"CNDCNF",
			"Conducting a meeting for discussion, esp. a regular one held by an association or organisation.");
	public static final ActionEventCategoryCode CONDUCTING_MEDIA_INTERVIEW = new ActionEventCategoryCode(
			"Conducting media interview",
			"CNDMED",
			"Conducting a conversation between a reporter etc. and a person of public interest, used as a basis of a broadcast or publication.");
	public static final ActionEventCategoryCode CONDUCTING_RECREATIONAL_ACTIVITIES = new ActionEventCategoryCode(
			"Conducting recreational activities",
			"CNDRCR",
			"Conducting a refreshing or entertaining activity.");
	public static final ActionEventCategoryCode CONDUCTING_SOCIAL_EVENTS = new ActionEventCategoryCode(
			"Conducting social events",
			"CNDSCL",
			"Conducting any social gathering, esp. one organised by a club or congregation.");
	public static final ActionEventCategoryCode CONDUCTING_SPORTING_EVENTS = new ActionEventCategoryCode(
			"Conducting sporting events",
			"CNDSPT",
			"Conducting any game or competitive activity, especially an outdoor one involving physical exertion, e.g. cricket, football, racing, hunting.");
	public static final ActionEventCategoryCode CONFISCATION = new ActionEventCategoryCode(
			"Confiscation",
			"CNFSTN",
			"The seizure of property under public authority.");
	public static final ActionEventCategoryCode CONDUCTING_FORWARD_PASSAGE_OF_LINES = new ActionEventCategoryCode(
			"Conducting forward passage of lines",
			"CNFWPS",
			"Moving an incoming force through another force that is currently in contact with the enemy in order for the incoming force to come into contact with the enemy.");
	public static final ActionEventCategoryCode CONDUCTING_PREPARATORY_FIRE = new ActionEventCategoryCode(
			"Conducting preparatory fire",
			"CNPRFR",
			"Delivering fire on a target preparatory to an assault.");
	public static final ActionEventCategoryCode CONDUCTING_ROAD_SERVICE = new ActionEventCategoryCode(
			"Conducting road service",
			"CNRDSV",
			"Enabling the movement of a number of specific units.");
	public static final ActionEventCategoryCode CONDUCTING_REARWARD_PASSAGE_OF_LINES = new ActionEventCategoryCode(
			"Conducting rearward passage of lines",
			"CNRWPS",
			"Moving a force through the defensive positions of another force behind it in order to break contact with the enemy.");
	public static final ActionEventCategoryCode CONSOLIDATING_OF_A_POSITION = new ActionEventCategoryCode(
			"Consolidating of a position",
			"CNSLDT",
			"Re-organising and strengthening of a newly captured position so that it can be used against the enemy.");
	public static final ActionEventCategoryCode COERCION = new ActionEventCategoryCode(
			"Coercion",
			"COERC",
			"The practice of persuading someone to do something by using force or threats.");
	public static final ActionEventCategoryCode COLLISION_MID_AIR = new ActionEventCategoryCode(
			"Collision, mid-air",
			"COLMID",
			"In-flight collision of an aircraft with another aircraft.");
	public static final ActionEventCategoryCode COLLISION_OBSTACLE = new ActionEventCategoryCode(
			"Collision, obstacle",
			"COLOBS",
			"In-flight collision of an aircraft with natural or man-made object (fixed or mobile) located on the ground.");
	public static final ActionEventCategoryCode COMMUNICATIONS_ACTIVATION = new ActionEventCategoryCode(
			"Communications activation",
			"COMACT",
			"The enabling of transmission of information.");
	public static final ActionEventCategoryCode COMMUNICATIONS_DEACTIVATION = new ActionEventCategoryCode(
			"Communications deactivation",
			"COMDEA",
			"The disabling of transmission of information.");
	public static final ActionEventCategoryCode COMMUNICATIONS_DISRUPTION = new ActionEventCategoryCode(
			"Communications disruption",
			"COMDIS",
			"Interruption of the passage of communications by natural or man-made phenomena.");
	public static final ActionEventCategoryCode COMMUNICATIONS_INTERCEPTION = new ActionEventCategoryCode(
			"Communications interception",
			"COMINT",
			"Capturing electromagnetic communications signals.");
	public static final ActionEventCategoryCode COMMUNICATIONS_OUTAGE = new ActionEventCategoryCode(
			"Communications outage",
			"COMOUT",
			"The failure of communications equipment due to a mechanical malfunction.");
	public static final ActionEventCategoryCode COMMUNICATIONS_RESTORATION = new ActionEventCategoryCode(
			"Communications restoration",
			"COMRES",
			"The reestablishment of the ability to communicate.");
	public static final ActionEventCategoryCode CONSULTATION = new ActionEventCategoryCode(
			"Consultation",
			"CONSLT",
			"The action of consulting or taking counsel together; deliberation, conference, e.g. Shura.");
	public static final ActionEventCategoryCode CONSTRUCTING = new ActionEventCategoryCode(
			"Constructing",
			"CONSTN",
			"Building, digging or creating an object.");
	public static final ActionEventCategoryCode CONTAINING = new ActionEventCategoryCode(
			"Containing",
			"CONTAN",
			"Restricting enemy forces by stopping, holding or surrounding them or compelling the enemy forces to centre activity on a given front and to prevent his withdrawing any part of his forces for use elsewhere.");
	public static final ActionEventCategoryCode COOPERATING = new ActionEventCategoryCode(
			"Cooperating",
			"COOPER",
			"Working or acting together.");
	public static final ActionEventCategoryCode COUP_D_�TAT = new ActionEventCategoryCode(
			"Coup d��tat",
			"COUPDE",
			"A violent or illegal seizure of power.");
	public static final ActionEventCategoryCode COVERING = new ActionEventCategoryCode(
			"Covering",
			"COVERN",
			"Operating as a force apart from the main body to protect the main body by fighting to gain time while also observing and reporting information and preventing enemy ground observation of an direct fire against the main body.");
	public static final ActionEventCategoryCode CRIMINAL_INCIDENT = new ActionEventCategoryCode(
			"Criminal incident",
			"CRIMIN",
			"A violation of law.");
	public static final ActionEventCategoryCode CRIME_AGAINST_HUMANITY = new ActionEventCategoryCode(
			"Crime against humanity",
			"CRMHMN",
			"Violation of the laws so gross in numbers affected that it is considered to affect all humans and not only individuals.");
	public static final ActionEventCategoryCode CROSSING = new ActionEventCategoryCode(
			"Crossing",
			"CROSSN",
			"Traversing a FEATURE or FACILITY.");
	public static final ActionEventCategoryCode COUNTER_ATTACK = new ActionEventCategoryCode(
			"Counter attack",
			"CTRATK",
			"Mounting an offensive operation in which an attack by a part or all of a defending force is made against an enemy attacking force, for such specific purposes as regaining ground lost, cutting off or destroying lead enemy units, and with the general objective of regaining the initiative and denying the enemy the attainment of his goal or purpose in attacking.");
	public static final ActionEventCategoryCode COUNTER_BATTERY_FIRE = new ActionEventCategoryCode(
			"Counter-battery fire",
			"CTRBYF",
			"Fire delivered for the purpose of destroying or neutralizing indirect fire weapons systems.");
	public static final ActionEventCategoryCode COUNTER_ATTACK_BY_FIRE = new ActionEventCategoryCode(
			"Counter attack by fire",
			"CTRFIR",
			"Denying the enemy his goal by using fire against an engagement area to defeat or destroy an enemy force.");
	public static final ActionEventCategoryCode DAZZLE = new ActionEventCategoryCode(
			"Dazzle",
			"DAZZLE",
			"Causing a temporary loss of vision or a temporary reduction in visual acuity; may also be applied to effects on optics.");
	public static final ActionEventCategoryCode DECEPTION_ELECTRONIC = new ActionEventCategoryCode(
			"Deception, electronic",
			"DCPTEL",
			"In electronic countermeasures, the deliberate radiation, re-radiation, alteration, absorption or reflection of electromagnetic energy in a manner intended to confuse, distract or seduce an enemy or his electronic systems.");
	public static final ActionEventCategoryCode DECEPTION = new ActionEventCategoryCode(
			"Deception",
			"DCPTIN",
			"Employing measures designed to mislead the enemy by manipulation, distortion, or falsification of evidence to induce him to react in a manner prejudicial to his interests.");
	public static final ActionEventCategoryCode DEATH_OF_CHIEF_OF_STATE = new ActionEventCategoryCode(
			"Death of chief of state",
			"DEACST",
			"Self-defined.");
	public static final ActionEventCategoryCode DEATH_OF_SPIRITUAL_LEADER = new ActionEventCategoryCode(
			"Death of spiritual leader",
			"DEASPL",
			"Self-defined.");
	public static final ActionEventCategoryCode DEFEAT = new ActionEventCategoryCode(
			"Defeat",
			"DEFEAT",
			"Diminution of the effectiveness of the enemy to the extent that he is unable to participate further in the battle or at least cannot fulfil his intention.");
	public static final ActionEventCategoryCode DEFENDING = new ActionEventCategoryCode(
			"Defending",
			"DEFEND",
			"Protecting a defined object against an enemy attack.");
	public static final ActionEventCategoryCode DEFLECTING = new ActionEventCategoryCode(
			"Deflecting",
			"DEFLCT",
			"Preventing an enemy force from following the intended course.");
	public static final ActionEventCategoryCode DELAYING = new ActionEventCategoryCode(
			"Delaying",
			"DELAYN",
			"Slowing the momentum of the enemy by conducting an operation in which the force under pressure trades time for space; the aim is to inflict the maximum damage on the enemy without becoming decisively engaged.");
	public static final ActionEventCategoryCode DEMOLITION = new ActionEventCategoryCode(
			"Demolition",
			"DEMO",
			"The destruction of structures, facilities, or materiel by use of fire, water, explosives, mechanical, or other means.");
	public static final ActionEventCategoryCode DENYING = new ActionEventCategoryCode(
			"Denying",
			"DENYNG",
			"Preventing access by blocking, disrupting, dislocating and/or bringing fire to bear.");
	public static final ActionEventCategoryCode DEPLOYING = new ActionEventCategoryCode(
			"Deploying",
			"DEPLOY",
			"Moving to and adopting a tactical formation or dispersal at a specific location.");
	public static final ActionEventCategoryCode MASSIVE_DEPORTATION_BANISHMENT = new ActionEventCategoryCode(
			"Massive deportation/banishment",
			"DEPORT",
			"The driving out or removing from a home or place of usual resort or continuance of a large number of people.");
	public static final ActionEventCategoryCode DESERTION = new ActionEventCategoryCode(
			"Desertion",
			"DESRTN",
			"The act of forsaking; abandonment of a service, a cause, or any post of duty; the quitting of one's duties wilfully and without right.");
	public static final ActionEventCategoryCode DISEASE = new ActionEventCategoryCode(
			"Disease",
			"DISEAS",
			"A disorder of structure or function in a human, animal, or plant, especially one that produces specific symptoms or that affects a specific part.");
	public static final ActionEventCategoryCode DISENGAGING = new ActionEventCategoryCode(
			"Disengaging",
			"DISENG",
			"Breaking off an action.");
	public static final ActionEventCategoryCode DISPLACEMENT = new ActionEventCategoryCode(
			"Displacement",
			"DISPLC",
			"The moving of something from its place or position.");
	public static final ActionEventCategoryCode DIVERSION = new ActionEventCategoryCode(
			"Diversion",
			"DIVRSN",
			"Drawing the attention and forces of an enemy from the point of the principal operation; an attack, alarm, or feint that diverts attention.");
	public static final ActionEventCategoryCode ATTACK_DELIBERATE = new ActionEventCategoryCode(
			"Attack, deliberate",
			"DLBATK",
			"Conducting an offensive operation characterised by pre-planned coordinated employment of firepower and manoeuvre to close with and destroy or capture the enemy.");
	public static final ActionEventCategoryCode DEMONSTRATION = new ActionEventCategoryCode(
			"Demonstration",
			"DMNSTR",
			"Conducting an offensive operation that is either an attack or a show of force on a front where a decision is not sought, made with the aim of deceiving the enemy. It is similar to a feint with the exception that no contact with the enemy is sought. In OOTW, an operation by military forces in sight of an actual or potential enemy to show military capabilities.");
	public static final ActionEventCategoryCode DRUG_CONSUMPTION_ILLEGAL = new ActionEventCategoryCode(
			"Drug consumption, illegal",
			"DRGCNS",
			"An action of consuming illegal drugs.");
	public static final ActionEventCategoryCode DRUG_DISTRIBUTION_ILLEGAL = new ActionEventCategoryCode(
			"Drug distribution, illegal",
			"DRGDST",
			"An action to distribute illegal drugs or to illegally distribute legal drugs.");
	public static final ActionEventCategoryCode DRUG_MANUFACTURING_ILLEGAL = new ActionEventCategoryCode(
			"Drug manufacturing, illegal",
			"DRGMNF",
			"An action to manufacture illegal drugs or to illegally manufacture legal drugs.");
	public static final ActionEventCategoryCode DRUG_OPERATION = new ActionEventCategoryCode(
			"Drug operation",
			"DRGOPR",
			"Illegal trafficking in drugs by a group or an organisation.");
	public static final ActionEventCategoryCode DRUG_STORAGE = new ActionEventCategoryCode(
			"Drug storage",
			"DRGSTR",
			"An action to store drugs.");
	public static final ActionEventCategoryCode DRUG_TRANSPORTATION = new ActionEventCategoryCode(
			"Drug transportation",
			"DRGTRN",
			"An action to transport drugs.");
	public static final ActionEventCategoryCode DROUGHT = new ActionEventCategoryCode(
			"Drought",
			"DROUGH",
			"A prolonged or chronic shortage of water.");
	public static final ActionEventCategoryCode DRIVE_BY_SHOOTING = new ActionEventCategoryCode(
			"Drive-by shooting",
			"DRVSHT",
			"The act of firing a weapon, usually at a person, from a passing vehicle.");
	public static final ActionEventCategoryCode DISRUPTING = new ActionEventCategoryCode(
			"Disrupting",
			"DSRPTN",
			"Breaking apart an enemy�s formation and tempo, interrupting the enemy�s time table, causing premature commitment of forces, and/or splintering their attack using integrated fire planning and obstacle effect.");
	public static final ActionEventCategoryCode DISTRIBUTING = new ActionEventCategoryCode(
			"Distributing",
			"DSTRBT",
			"Dividing or dispensing in portions.");
	public static final ActionEventCategoryCode DESTROYING = new ActionEventCategoryCode(
			"Destroying",
			"DSTRYN",
			"Physically rendering an enemy force combat-ineffective or damaging a target so that it cannot function as intended, nor be restored to a usable condition without being entirely rebuilt.");
	public static final ActionEventCategoryCode DEATH_NATURAL_CAUSES = new ActionEventCategoryCode(
			"Death, natural causes",
			"DTHNAT",
			"Normal termination of life.");
	public static final ActionEventCategoryCode EARTHQUAKE = new ActionEventCategoryCode(
			"Earthquake",
			"EARTHQ",
			"A convulsion of the earth's crust due to the release of accumulated stress as a result of faults in strata or volcanic action.");
	public static final ActionEventCategoryCode EARLY_WARNING_ALERT = new ActionEventCategoryCode(
			"Early warning alert",
			"EARWAR",
			"Early notification of the launch or approach of weapons or weapons carriers.");
	public static final ActionEventCategoryCode ELECTRONIC_EMISSION = new ActionEventCategoryCode(
			"Electronic emission",
			"ELCEMS",
			"The radiation of electromagnetic energy.");
	public static final ActionEventCategoryCode ELECTION_ASSOCIATED_VIOLENCE = new ActionEventCategoryCode(
			"Election associated violence",
			"ELCVIO",
			"The occurrence of violent acts due to an election process.");
	public static final ActionEventCategoryCode ELECTRONIC_WARFARE = new ActionEventCategoryCode(
			"Electronic warfare",
			"ELCWAR",
			"Military action to exploit the electro-magnetic spectrum encompassing the search for, interception and identification of electro-magnetic emissions, the employment of electro-magnetic energy, including directed energy, to reduce or prevent hostile use of the electro-magnetic spectrum, and actions to ensure its effective use by friendly forces.");
	public static final ActionEventCategoryCode ENGAGING = new ActionEventCategoryCode(
			"Engaging",
			"ENGAGE",
			"Bringing the enemy under fire.");
	public static final ActionEventCategoryCode ENEMY_CONTACT = new ActionEventCategoryCode(
			"Enemy contact",
			"ENMCON",
			"The situation when opposing forces are in sight of or in range of direct fire of each other's weapons.");
	public static final ActionEventCategoryCode ENVELOPING = new ActionEventCategoryCode(
			"Enveloping",
			"ENVLPN",
			"Manoeuvring by the main attacking force to pass around or over the enemy's principal defensive positions with the aim of securing objectives to the enemy's rear.");
	public static final ActionEventCategoryCode EPIDEMIC = new ActionEventCategoryCode(
			"Epidemic",
			"EPEDEM",
			"A widespread occurrence of a disease in a community at a particular time.");
	public static final ActionEventCategoryCode EQUIPMENT_FAILURE = new ActionEventCategoryCode(
			"Equipment failure",
			"EQPFAI",
			"A cessation of proper functioning or performance of a piece of equipment.");
	public static final ActionEventCategoryCode ESCAPING = new ActionEventCategoryCode(
			"Escaping",
			"ESCPNG",
			"Breaking free from a restriction or control of a place, person, or organisation.");
	public static final ActionEventCategoryCode ESCORTING = new ActionEventCategoryCode(
			"Escorting",
			"ESCRTN",
			"Accompanying and protecting another force or convoy.");
	public static final ActionEventCategoryCode EVACUATING = new ActionEventCategoryCode(
			"Evacuating",
			"EVACTN",
			"Clearing or removing materiel and personnel from a given locality.");
	public static final ActionEventCategoryCode EXECUTION = new ActionEventCategoryCode(
			"Execution",
			"EXECTN",
			"Putting a person to death, especially as a legal penalty.");
	public static final ActionEventCategoryCode EXPLOSION = new ActionEventCategoryCode(
			"Explosion",
			"EXPLOS",
			"A sudden release of any kind of energy.");
	public static final ActionEventCategoryCode EXPLOITATION = new ActionEventCategoryCode(
			"Exploitation",
			"EXPLTN",
			"Taking advantage of a successful attack by mounting an offensive operation to follow-up and harass a dislocated enemy with the aim of further disorganising him in depth. This may provide the opportunity to capture ground that was not part of the objective of the original attack.");
	public static final ActionEventCategoryCode EXTORTION = new ActionEventCategoryCode(
			"Extortion",
			"EXTORT",
			"Obtaining by coercive means, as by threats or intimidation.");
	public static final ActionEventCategoryCode FAMINE = new ActionEventCategoryCode(
			"Famine",
			"FAMINE",
			"An extreme scarcity of food.");
	public static final ActionEventCategoryCode FIRE = new ActionEventCategoryCode(
			"Fire",
			"FIRE",
			"A rapid, persistent chemical reaction that releases heat and light, especially the exothermic combination of a combustible substance with oxygen.");
	public static final ActionEventCategoryCode FIX = new ActionEventCategoryCode(
			"Fix",
			"FIX",
			"Preventing the enemy from moving any part of his force from a specific location for a specific period of time.");
	public static final ActionEventCategoryCode FIX_ACOUSTIC = new ActionEventCategoryCode(
			"Fix, acoustic",
			"FIXACO",
			"Determining a position using acoustic data.");
	public static final ActionEventCategoryCode FIX_ELECTROMAGNETIC = new ActionEventCategoryCode(
			"Fix, electromagnetic",
			"FIXELM",
			"Determining a position using electromagnetic data.");
	public static final ActionEventCategoryCode FIX_ELECTRO_OPTICAL = new ActionEventCategoryCode(
			"Fix, electro-optical",
			"FIXELO",
			"Determining a position using electro-optical data.");
	public static final ActionEventCategoryCode FLOOD = new ActionEventCategoryCode(
			"Flood",
			"FLOOD",
			"The overflowing of a body of water onto dry land.");
	public static final ActionEventCategoryCode FOLLOWING_AND_ASSUMING = new ActionEventCategoryCode(
			"Following and assuming",
			"FOLASS",
			"Operating as a committed force that is following a force conducting an offensive operation and is prepared to continue the mission of the force it is following when that force is fixed, attrited, or otherwise unable to continue.");
	public static final ActionEventCategoryCode FOLLOWING_AND_SUPPORTING = new ActionEventCategoryCode(
			"Following and supporting",
			"FOLSPT",
			"Operating as a committed force that follows and supports the mission accomplishment of a force conducting an offensive operation.");
	public static final ActionEventCategoryCode FORCED_LANDING = new ActionEventCategoryCode(
			"Forced landing",
			"FRCLND",
			"An aircraft that by hostile act, or lack of vital resources is compelled to land.");
	public static final ActionEventCategoryCode FIREFIGHTING = new ActionEventCategoryCode(
			"Firefighting",
			"FRFGTN",
			"The activity of extinguishing fires.");
	public static final ActionEventCategoryCode FRIENDLY_FIRE = new ActionEventCategoryCode(
			"Friendly fire",
			"FRNDFR",
			"Accidental damage by Allied troops to one's own installations, aircraft or personnel.");
	public static final ActionEventCategoryCode GENERATING_CHEMICAL_SMOKE = new ActionEventCategoryCode(
			"Generating chemical smoke",
			"GENCHS",
			"Producing chemical smoke to act as a form of cover to protect ongoing operations.");
	public static final ActionEventCategoryCode GENOCIDE = new ActionEventCategoryCode(
			"Genocide",
			"GENOCD",
			"The deliberated and systematic destruction of a racial, political or cultural group.");
	public static final ActionEventCategoryCode GOVERNMENTAL_COLLAPSE = new ActionEventCategoryCode(
			"Governmental collapse",
			"GOVCOL",
			"The sudden loss of force, effectiveness or authority of the governing organisation.");
	public static final ActionEventCategoryCode GATHERING = new ActionEventCategoryCode(
			"Gathering",
			"GTHRNG",
			"An assembly or meeting, especially a social or festive one or one held for a specific purpose.");
	public static final ActionEventCategoryCode GUARDING = new ActionEventCategoryCode(
			"Guarding",
			"GUARDN",
			"Operating as a security element to protect the main body by fighting to gain time while also observing and reporting information.");
	public static final ActionEventCategoryCode GUNNERY_AIR_TO_AIR = new ActionEventCategoryCode(
			"Gunnery, air-to-air",
			"GUNATA",
			"The act of firing an air-to-air weapon, usually at an aircraft.");
	public static final ActionEventCategoryCode HARASSING = new ActionEventCategoryCode(
			"Harassing",
			"HARASS",
			"Conducting an operation or executing a fire plan designed to curtail movement and, by threat of losses, to lower the morale of enemy troops.");
	public static final ActionEventCategoryCode ATTACK_HASTY = new ActionEventCategoryCode(
			"Attack, hasty",
			"HASTY",
			"In land operations, an attack in which preparation time is traded for speed in order to exploit an opportunity.");
	public static final ActionEventCategoryCode HIDING = new ActionEventCategoryCode(
			"Hiding",
			"HIDING",
			"Concealing an object.");
	public static final ActionEventCategoryCode HIJACKING_NOT_OTHERWISE_SPECIFIED = new ActionEventCategoryCode(
			"Hijacking, not otherwise specified",
			"HIJACK",
			"Seizure of a vehicle in order to go somewhere other than the scheduled destination.");
	public static final ActionEventCategoryCode HIJACKING_BOAT = new ActionEventCategoryCode(
			"Hijacking, boat",
			"HJCKBT",
			"Seizure of a boat or ship in order to go somewhere other than the scheduled destination.");
	public static final ActionEventCategoryCode HIJACKING_LAND_VEHICLE = new ActionEventCategoryCode(
			"Hijacking, land vehicle",
			"HJCKLV",
			"Seizure of a land vehicle in order to go somewhere other than the scheduled destination.");
	public static final ActionEventCategoryCode HIJACKING_PLANE = new ActionEventCategoryCode(
			"Hijacking, plane",
			"HJCKPL",
			"Seizure of an aircraft in order to go somewhere other than the scheduled destination.");
	public static final ActionEventCategoryCode HOLD_DEFENSIVE = new ActionEventCategoryCode(
			"Hold, defensive",
			"HLDDEF",
			"Maintaining or retaining possession by force a position or area in defensive operations.");
	public static final ActionEventCategoryCode HOLD_OFFENSIVE = new ActionEventCategoryCode(
			"Hold, offensive",
			"HLDOFF",
			"Exerting sufficient pressure by means of combat power in an attack to prevent the movement or redeployment of enemy forces.");
	public static final ActionEventCategoryCode NATIONAL_HOLIDAY = new ActionEventCategoryCode(
			"National holiday",
			"HOLIDY",
			"A day designated by a national authority as a day when work is not compulsory.");
	public static final ActionEventCategoryCode HUMAN_RIGHTS_VIOLATION = new ActionEventCategoryCode(
			"Human rights violation",
			"HRVIOL",
			"The commitment of an act against human rights.");
	public static final ActionEventCategoryCode HOSTAGE_TAKING = new ActionEventCategoryCode(
			"Hostage taking",
			"HSTTKN",
			"Action to seize or hold a person as security for the fulfilment of a condition.");
	public static final ActionEventCategoryCode HUNTING = new ActionEventCategoryCode(
			"Hunting",
			"HUNTNG",
			"The activity of hunting wild animals or game, especially for food or sport.");
	public static final ActionEventCategoryCode IDENTIFYING = new ActionEventCategoryCode(
			"Identifying",
			"IDENT",
			"Determining the identification of a particular class of object, recognising the friendly or enemy character of an object, or detecting the presence of an object.");
	public static final ActionEventCategoryCode IED_CACHE_DISCOVERY = new ActionEventCategoryCode(
			"IED cache discovery",
			"IEDCCH",
			"An IED incident that involves the discovery and/or recovery of a cache of unarmed devices, IED components and IED paraphernalia.");
	public static final ActionEventCategoryCode IED_DISCOVERY = new ActionEventCategoryCode(
			"IED discovery",
			"IEDDSC",
			"Initial observing or finding of an IED.");
	public static final ActionEventCategoryCode IED_EXPLOSION = new ActionEventCategoryCode(
			"IED explosion",
			"IEDEXP",
			"A violent and destructive shattering or blowing apart of an IED.");
	public static final ActionEventCategoryCode IED_HOAX = new ActionEventCategoryCode(
			"IED hoax",
			"IEDHX",
			"An IED incident that involves a device fabricated to look like an IED and is intended to purposely simulate one in order to elicit a response.");
	public static final ActionEventCategoryCode ILLEGAL_CHECK_POINT_ACTIVITY = new ActionEventCategoryCode(
			"Illegal check point activity",
			"ILCKPT",
			"The act of controlling movement with the intent of conducting illegal activities.");
	public static final ActionEventCategoryCode ILLUMINATION = new ActionEventCategoryCode(
			"Illumination",
			"ILLUMN",
			"Providing battlespace lighting by employing searchlight or pyrotechnic illuminants using diffusion or reflection.");
	public static final ActionEventCategoryCode INDUSTRIAL_ESPIONAGE_INCIDENT = new ActionEventCategoryCode(
			"Industrial espionage incident",
			"INDESP",
			"The practice of spying or the use of spies to obtain information about the plans and activities of competitors.");
	public static final ActionEventCategoryCode INDIRECT_FIRE = new ActionEventCategoryCode(
			"Indirect fire",
			"INDFIR",
			"Fire delivered on a target that is not itself used as a point of aim for the weapons or the director.");
	public static final ActionEventCategoryCode INDISCRIMINATE_SHOOTING = new ActionEventCategoryCode(
			"Indiscriminate shooting",
			"INDSHO",
			"Firing without a specific objective and without making distinction.");
	public static final ActionEventCategoryCode INFILTRATION = new ActionEventCategoryCode(
			"Infiltration",
			"INFLTN",
			"Moving a force, broken down as individuals or small groups, over, through or around enemy positions with the aim of avoiding detection.");
	public static final ActionEventCategoryCode INFLUENCE = new ActionEventCategoryCode(
			"Influence",
			"INFLUC",
			"Affecting the condition of, to have an affect on.");
	public static final ActionEventCategoryCode INTERCEPTION = new ActionEventCategoryCode(
			"Interception",
			"INTCPN",
			"Conducting electronic warfare support operations with a view to searching, locating and recording radiated electromagnetic energy.");
	public static final ActionEventCategoryCode INTERDICTION = new ActionEventCategoryCode(
			"Interdiction",
			"INTDCT",
			"Diverting, disrupting, delaying, or destroying the enemy's surface military potential before it can be used effectively against friendly forces.");
	public static final ActionEventCategoryCode INTIMIDATION = new ActionEventCategoryCode(
			"Intimidation",
			"INTMDN",
			"Act to frighten or overawe.");
	public static final ActionEventCategoryCode INVASION = new ActionEventCategoryCode(
			"Invasion",
			"INVASI",
			"The act of taking possession of another land.");
	public static final ActionEventCategoryCode ISOLATION = new ActionEventCategoryCode(
			"Isolation",
			"ISOLTN",
			"Sealing off (both physically and psychologically) an enemy from its sources of support, denying an enemy freedom of movement, and preventing an enemy unit from having contact with other enemy forces.");
	public static final ActionEventCategoryCode ISSUING_MEDIA_ARTICLE = new ActionEventCategoryCode(
			"Issuing media article",
			"ISSMDA",
			"Sending forth or putting into circulation a non-fictional essay, especially one included with others in a newspaper, magazine, or journal.");
	public static final ActionEventCategoryCode ISSUING_MEDIA_DOCUMENTARY = new ActionEventCategoryCode(
			"Issuing media documentary",
			"ISSMDD",
			"Sending forth or putting into circulation any document published on a media that provides a factual record or report.");
	public static final ActionEventCategoryCode ISSUING_PRESS_RELEASE = new ActionEventCategoryCode(
			"Issuing press release",
			"ISSPRS",
			"Sending forth or putting into circulation an official statement issued to media for information.");
	public static final ActionEventCategoryCode JAMMING = new ActionEventCategoryCode(
			"Jamming",
			"JAMMNG",
			"Deliberately radiating, re-radiating or reflecting electromagnetic energy with the object of impairing the use of electronic devices, equipment or systems being used by the enemy.");
	public static final ActionEventCategoryCode KIDNAPPING = new ActionEventCategoryCode(
			"Kidnapping",
			"KIDNAP",
			"Seizing and holding a person unlawfully, usually for ransom or political gain.");
	public static final ActionEventCategoryCode LABOUR_STRIKE = new ActionEventCategoryCode(
			"Labour strike",
			"LABSTR",
			"The organised refusal by employees to work until some grievance is remedied.");
	public static final ActionEventCategoryCode LEAGUER = new ActionEventCategoryCode(
			"Leaguer",
			"LEAGR",
			"Adopting a defended formation as a temporary defensive measure in areas of low or moderate risk of combat.");
	public static final ActionEventCategoryCode LOCAL_ELECTION = new ActionEventCategoryCode(
			"Local election",
			"LOCELC",
			"An ACTION-EVENT in which local officials are selected by vote.");
	public static final ActionEventCategoryCode LOCATING = new ActionEventCategoryCode(
			"Locating",
			"LOCTNG",
			"Establishing the position of an object.");
	public static final ActionEventCategoryCode LOOTING = new ActionEventCategoryCode(
			"Looting",
			"LOOTNG",
			"Act to take private property from an enemy in war or stolen by thieves.");
	public static final ActionEventCategoryCode LETTER_BOMB_EXPLOSION = new ActionEventCategoryCode(
			"Letter bomb explosion",
			"LTRBME",
			"The explosion of a seemingly harmless letter or parcel.");
	public static final ActionEventCategoryCode LETTER_BOMB_INCIDENT = new ActionEventCategoryCode(
			"Letter bomb incident",
			"LTRBMI",
			"The detection of a seemingly harmless letter or parcel.");
	public static final ActionEventCategoryCode MAINTAINING = new ActionEventCategoryCode(
			"Maintaining",
			"MAINTN",
			"Providing services to keep equipment in condition to carry out its function.");
	public static final ActionEventCategoryCode MARKING = new ActionEventCategoryCode(
			"Marking",
			"MARKNG",
			"Making visible (by the use of light/IR/laser/arty) an object in order to allow its identification by another object (usually as a precursor to the use of direct fire weapons).");
	public static final ActionEventCategoryCode MARTIAL_LAW_IMPLEMENTATION = new ActionEventCategoryCode(
			"Martial law implementation",
			"MARLAW",
			"Giving practical effect to military law, usually by restricting the rights of citizens for security reasons.");
	public static final ActionEventCategoryCode MASSING_OF_FORCES = new ActionEventCategoryCode(
			"Massing of forces",
			"MASFOR",
			"The concentration of large quantities of military equipment and personnel.");
	public static final ActionEventCategoryCode MEDICAL_EVACUATION = new ActionEventCategoryCode(
			"Medical evacuation",
			"MEDEVC",
			"The process of moving any person who is wounded, injured or ill to/between medical treatment FACILITYs.");
	public static final ActionEventCategoryCode MEETING = new ActionEventCategoryCode(
			"Meeting",
			"MEETNG",
			"The action of coming together into one place or into the presence of each other.");
	public static final ActionEventCategoryCode MILITARY_MOBILISATION = new ActionEventCategoryCode(
			"Military mobilisation",
			"MILMOB",
			"The act of assembling and making ready for active military service.");
	public static final ActionEventCategoryCode MINE_LAYING = new ActionEventCategoryCode(
			"Mine-laying",
			"MINLAY",
			"Emplacement or deployment of one or more mines.");
	public static final ActionEventCategoryCode MISSING_INDIVIDUAL = new ActionEventCategoryCode(
			"Missing individual",
			"MISSIG",
			"The absence of a PERSON from an expected or anticipated location.");
	public static final ActionEventCategoryCode MISSION_STAGING = new ActionEventCategoryCode(
			"Mission staging",
			"MISSTG",
			"The assembly of aircraft for the completion of a mission or other activity.");
	public static final ActionEventCategoryCode MOVING = new ActionEventCategoryCode(
			"Moving",
			"MOVING",
			"Changing position.");
	public static final ActionEventCategoryCode MORTAR_FIRE = new ActionEventCategoryCode(
			"Mortar fire",
			"MRTFIR",
			"The discharge of a projectile from a mortar weapon.");
	public static final ActionEventCategoryCode MURDER = new ActionEventCategoryCode(
			"Murder",
			"MURDER",
			"The unlawful killing of one human being by another, especially with premeditated malice.");
	public static final ActionEventCategoryCode MUTUAL_ASSISTANCE_PACT_AGREEMENT = new ActionEventCategoryCode(
			"Mutual assistance pact agreement",
			"MUTASS",
			"An arrangement or contract between a number of organisations to provide mutual support.");
	public static final ActionEventCategoryCode NARCOTICS_PRODUCTION = new ActionEventCategoryCode(
			"Narcotics production",
			"NARCTC",
			"The action of producing or manufacturing narcotics.");
	public static final ActionEventCategoryCode NATURAL_DISASTER = new ActionEventCategoryCode(
			"Natural disaster",
			"NATDIS",
			"The damage caused by force of nature, such as a hurricane, cyclone, tornado or tidal wave.");
	public static final ActionEventCategoryCode NATIONAL_ELECTION = new ActionEventCategoryCode(
			"National election",
			"NATELC",
			"An ACTION-EVENT in which national officials are selected by vote.");
	public static final ActionEventCategoryCode NATIONAL_STATE_OF_EMERGENCY = new ActionEventCategoryCode(
			"National state of emergency",
			"NATEMG",
			"A political term, to describe a condition approximating to that of war, wherein the normal constitution is suspended.");
	public static final ActionEventCategoryCode NAVAL_GUN_FIRE = new ActionEventCategoryCode(
			"Naval gun fire",
			"NAVGUN",
			"The act of firing a naval surface-to-surface weapon.");
	public static final ActionEventCategoryCode NAVAL_PLATFORM_FLIGHT_OPERATIONS = new ActionEventCategoryCode(
			"Naval platform flight operations",
			"NAVPLF",
			"Aircraft launch or recovery by a naval platform.");
	public static final ActionEventCategoryCode NETWORK_SEIZURE = new ActionEventCategoryCode(
			"Network seizure",
			"NETSEI",
			"Taking electronic control of a communications network.");
	public static final ActionEventCategoryCode NOT_OTHERWISE_SPECIFIED = new ActionEventCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionEventCategoryCode NEUTRALIZE_CHEMICAL = new ActionEventCategoryCode(
			"Neutralize, chemical",
			"NTRCHM",
			"Making safe or non-toxic an object contaminated with a chemical agent.");
	public static final ActionEventCategoryCode NEUTRALIZE_COMBAT = new ActionEventCategoryCode(
			"Neutralize, combat",
			"NTRCOM",
			"Rendering ineffective or unusable in military operations.");
	public static final ActionEventCategoryCode NEUTRALIZE_EXPLOSIVE = new ActionEventCategoryCode(
			"Neutralize, explosive",
			"NTREXP",
			"Rendering bombs, mines, missiles, and booby traps into a safe state.");
	public static final ActionEventCategoryCode OBSCURE = new ActionEventCategoryCode(
			"Obscure",
			"OBSCUR",
			"Covering something by a smoke screen.");
	public static final ActionEventCategoryCode OBSERVING = new ActionEventCategoryCode(
			"Observing",
			"OBSRNG",
			"Providing continuous view and the potential for reports on the activity of an object.");
	public static final ActionEventCategoryCode OCCUPYING = new ActionEventCategoryCode(
			"Occupying",
			"OCCPNG",
			"Moving onto an objective, key terrain, or other manmade or natural terrain area without opposition and controlling that entire area.");
	public static final ActionEventCategoryCode OFFENSIVE_COUNTEROFFENSIVE = new ActionEventCategoryCode(
			"Offensive/counteroffensive",
			"OFFCOF",
			"Conducting an operation by an attack force.");
	public static final ActionEventCategoryCode ORGANISED_CRIME = new ActionEventCategoryCode(
			"Organised crime",
			"ORGCRM",
			"Violation of the laws of a civil society performed by a group of persons established for that reason.");
	public static final ActionEventCategoryCode PICKETING = new ActionEventCategoryCode(
			"Picketing",
			"PCKTNG",
			"An act by a person or persons outside a place of work, intending to persuade esp. workers not to enter during a strike.");
	public static final ActionEventCategoryCode PEACE_TREATY_AGREEMENT = new ActionEventCategoryCode(
			"Peace treaty agreement",
			"PEAAGR",
			"An arrangement or contract among involved nations or factions to end a conflict.");
	public static final ActionEventCategoryCode PEACE_CONFERENCE = new ActionEventCategoryCode(
			"Peace conference",
			"PEACON",
			"A meeting of a group of persons to discuss a peace process.");
	public static final ActionEventCategoryCode PENETRATING = new ActionEventCategoryCode(
			"Penetrating",
			"PENTRT",
			"Breaking through the enemy's defence or disrupting the enemy's defensive systems.");
	public static final ActionEventCategoryCode PETROLEUM_PRODUCT_SPILLS = new ActionEventCategoryCode(
			"Petroleum product spills",
			"PETSPL",
			"The accidental or delivered release of any petroleum product into the environment.");
	public static final ActionEventCategoryCode POISONING = new ActionEventCategoryCode(
			"Poisoning",
			"POISON",
			"Injuring or killing with toxic agents.");
	public static final ActionEventCategoryCode POLITICAL_DEMONSTRATION = new ActionEventCategoryCode(
			"Political demonstration",
			"POLDEM",
			"A public display of group feelings towards a political idea, person or cause.");
	public static final ActionEventCategoryCode POLITICAL_EXECUTION = new ActionEventCategoryCode(
			"Political execution",
			"POLEXE",
			"A putting to death of a person or group of persons for political reasons.");
	public static final ActionEventCategoryCode PRISONER_EXCHANGE = new ActionEventCategoryCode(
			"Prisoner exchange",
			"POWEXC",
			"The act of giving or taking POWs in return for others.");
	public static final ActionEventCategoryCode POW_RETURN = new ActionEventCategoryCode(
			"POW return",
			"POWRET",
			"The arrival of a POW or a group of POWs to their own forces or country.");
	public static final ActionEventCategoryCode PROCURING = new ActionEventCategoryCode(
			"Procuring",
			"PROCUR",
			"Buying whatever is needed to fulfil a certain action.");
	public static final ActionEventCategoryCode PROTECTION_ELECTRONIC = new ActionEventCategoryCode(
			"Protection, electronic",
			"PROTEL",
			"That division of electronic warfare involving actions taken to ensure effective friendly use of the electromagnetic spectrum despite the enemy's use of electromagnetic energy.");
	public static final ActionEventCategoryCode PROTEST = new ActionEventCategoryCode(
			"Protest",
			"PROTST",
			"The expressing of dissent from, or rejection of the prevailing social, political or cultural mores.");
	public static final ActionEventCategoryCode PROVIDING_ACCOMMODATION = new ActionEventCategoryCode(
			"Providing accommodation",
			"PRVACC",
			"Providing room for receiving people, esp. a place to live or lodgings.");
	public static final ActionEventCategoryCode PROVIDING_AGRICULTURAL_SUPPORT = new ActionEventCategoryCode(
			"Providing agricultural support",
			"PRVAGR",
			"Providing advice or supplies for cultivating the soil and rearing animals.");
	public static final ActionEventCategoryCode PROVIDING_BEDDING = new ActionEventCategoryCode(
			"Providing bedding",
			"PRVBDD",
			"Providing (1) sleeping accommodation or (2) mattress and bedclothes.");
	public static final ActionEventCategoryCode PROVIDING_CAMPS = new ActionEventCategoryCode(
			"Providing camps",
			"PRVCMP",
			"Providing temporary accommodation of various kinds, usually consisting of huts or tents, for detainees, homeless persons, and other emergency use.");
	public static final ActionEventCategoryCode PROVIDING_CONSTRUCTION_SERVICES = new ActionEventCategoryCode(
			"Providing construction services",
			"PRVCNS",
			"Providing labour and materiel for construction of facilities.");
	public static final ActionEventCategoryCode PROVIDING_DECONTAMINATION_SERVICES = new ActionEventCategoryCode(
			"Providing decontamination services",
			"PRVDCN",
			"Providing purification of different items from contamination.");
	public static final ActionEventCategoryCode PROVIDING_EDUCATION_SERVICES = new ActionEventCategoryCode(
			"Providing education services",
			"PRVEDU",
			"Providing labour and materiel for the educational process.");
	public static final ActionEventCategoryCode PROVIDING_HEALTHCARE_SERVICES = new ActionEventCategoryCode(
			"Providing healthcare services",
			"PRVHLT",
			"Providing labour and materiel for maintaining the general health and welfare.");
	public static final ActionEventCategoryCode PROVIDING_HOST_NATION_SUPPORT = new ActionEventCategoryCode(
			"Providing host nation support",
			"PRVHSN",
			"Providing civil and/or military assistance rendered by a nation to foreign forces within its territory during peacetime, crises or emergencies, or war based on agreements mutually concluded between nations.");
	public static final ActionEventCategoryCode PROVIDING_INFRASTRUCTURE = new ActionEventCategoryCode(
			"Providing infrastructure",
			"PRVINF",
			"Providing basic facilities such as roads, bridges, and sewers.");
	public static final ActionEventCategoryCode PROVIDING_LAUNDRY_SERVICES = new ActionEventCategoryCode(
			"Providing laundry services",
			"PRVLND",
			"Providing labour and materiel for laundering of clothes or linens.");
	public static final ActionEventCategoryCode PROVIDING_REPAIR_SERVICES = new ActionEventCategoryCode(
			"Providing repair services",
			"PRVRPR",
			"Providing labour and materiel to restore objects to sound condition.");
	public static final ActionEventCategoryCode PROVIDING_SECURITY_SERVICES = new ActionEventCategoryCode(
			"Providing security services",
			"PRVSCY",
			"Providing labour and materiel to assure safety of personnel and facilities.");
	public static final ActionEventCategoryCode PROVIDING_SHELTER = new ActionEventCategoryCode(
			"Providing shelter",
			"PRVSHL",
			"Providing housing.");
	public static final ActionEventCategoryCode PROVIDING_STORAGE_SERVICES = new ActionEventCategoryCode(
			"Providing storage services",
			"PRVSTG",
			"Providing services for storage.");
	public static final ActionEventCategoryCode PROVIDING_TRANSHIPMENT_SERVICES = new ActionEventCategoryCode(
			"Providing transhipment services",
			"PRVTRS",
			"Providing movement of cargo from one ship or train or container to another for further shipment.");
	public static final ActionEventCategoryCode PROXY_BOMBING = new ActionEventCategoryCode(
			"Proxy-bombing",
			"PRXBMB",
			"A deliberate and intentional bombing incident that happens unexpectedly where the perpetrator acts through a representative.");
	public static final ActionEventCategoryCode PESTILENCE = new ActionEventCategoryCode(
			"Pestilence",
			"PSTLNC",
			"A fatal epidemic disease, especially bubonic plague.");
	public static final ActionEventCategoryCode PSYCHOLOGICAL_OPERATION = new ActionEventCategoryCode(
			"Psychological operation",
			"PSYOP",
			"Planned operations to convey selected information and indicators to foreign audiences to influence their emotions, motives, objective reasoning, and ultimately the behaviour of foreign governments, organisations, groups, and individuals. The purpose of psychological operations is to induce or reinforce foreign attitudes and behaviour favourable to the originator's objectives.");
	public static final ActionEventCategoryCode PATROLLING = new ActionEventCategoryCode(
			"Patrolling",
			"PTRLNG",
			"Gathering information or carrying out a destructive, harassing, mopping-up, or security mission.");
	public static final ActionEventCategoryCode PUBLISHING_MEDIA_ARTICLE = new ActionEventCategoryCode(
			"Publishing media article",
			"PUBMDA",
			"Making generally known a non-fictional essay, especially one included with others in a newspaper, magazine, journal, etc.");
	public static final ActionEventCategoryCode PUBLISHING_MEDIA_DOCUMENTARY = new ActionEventCategoryCode(
			"Publishing media documentary",
			"PUBMDD",
			"Making generally known any document published on a media that provides a factual record or report.");
	public static final ActionEventCategoryCode PUBLISHING_PRESS_RELEASE = new ActionEventCategoryCode(
			"Publishing press release",
			"PUBPRS",
			"Making generally known an official statement issued to media for information.");
	public static final ActionEventCategoryCode PURSUING = new ActionEventCategoryCode(
			"Pursuing",
			"PURSNG",
			"Continuing an offensive operation in order to catch or cut off a hostile force attempting to escape, with the aim of destroying it. Typically, contact is maintained and risk taken to harass relentlessly, thereby turning the pursuit into a rout.");
	public static final ActionEventCategoryCode OUTBREAK_OF_RACIAL_TRIBAL_ETHNIC_WARFARE = new ActionEventCategoryCode(
			"Outbreak of racial/tribal/ethnic warfare",
			"RACIAL",
			"The use of force or violence by or against racial or tribal groups.");
	public static final ActionEventCategoryCode RAPE = new ActionEventCategoryCode(
			"Rape",
			"RAPE",
			"The act of forcing another person to submit to sexual intercourse.");
	public static final ActionEventCategoryCode RECONNAISSANCE = new ActionEventCategoryCode(
			"Reconnaissance",
			"RECCE",
			"Conducting a mission to obtain by visual operations or other detection methods information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic or geographic characteristics of a particular area.");
	public static final ActionEventCategoryCode RECONNAISSANCE_IN_FORCE = new ActionEventCategoryCode(
			"Reconnaissance in force",
			"RECCEF",
			"Conducting an offensive operation designed to discover and/or test the enemy's strength, or to obtain other information.");
	public static final ActionEventCategoryCode RECONSTITUTING = new ActionEventCategoryCode(
			"Reconstituting",
			"RECNSN",
			"Attaining prescribed strength of units and prescribed levels of vehicles, equipment, stores and supplies. The process will only take place after a unit/formation combat effectiveness has been reduced.");
	public static final ActionEventCategoryCode RECUPERATING = new ActionEventCategoryCode(
			"Recuperating",
			"RECPRN",
			"Resting a unit after it has been in action. Some reconstitution may take place as well.");
	public static final ActionEventCategoryCode RECOVERING = new ActionEventCategoryCode(
			"Recovering",
			"RECVRN",
			"Retrieving any lost, incapacitated or captured object.");
	public static final ActionEventCategoryCode REDEPLOYMENT = new ActionEventCategoryCode(
			"Redeployment",
			"REDPLN",
			"Transferring a unit, an individual, or supplies deployed in one area to another area, or to another location within the area, for the purpose of further employment.");
	public static final ActionEventCategoryCode REFUGEE_MOVEMENT = new ActionEventCategoryCode(
			"Refugee movement",
			"REFMVM",
			"The movement of people who has been forced to leave their country in order to escape war, persecution, or natural disaster.");
	public static final ActionEventCategoryCode REINFORCING = new ActionEventCategoryCode(
			"Reinforcing",
			"REINFN",
			"Making a force available for the purpose of supplementing an in-place force.");
	public static final ActionEventCategoryCode RELIGIOUS_DEMONSTRATION = new ActionEventCategoryCode(
			"Religious demonstration",
			"RELDEM",
			"A public display of group feelings towards a religious idea, person or cause.");
	public static final ActionEventCategoryCode RELIGIOUS_VIOLENCE = new ActionEventCategoryCode(
			"Religious violence",
			"RELVIO",
			"Individual or organised act directed against groups or individuals because of their religious beliefs.");
	public static final ActionEventCategoryCode RELIGIOUS_WARFARE = new ActionEventCategoryCode(
			"Religious warfare",
			"RELWAR",
			"An act of open armed conflict due to a difference of religious belief between two separate groups.");
	public static final ActionEventCategoryCode REORGANISING = new ActionEventCategoryCode(
			"Reorganising",
			"REORGN",
			"Changing a task organisation for a particular operation. (Normally takes place before an operation). This includes the transfer of authority.");
	public static final ActionEventCategoryCode REPAIRING = new ActionEventCategoryCode(
			"Repairing",
			"REPAIR",
			"Restoring an item to serviceable condition through correction of a specific failure or unserviceable condition.");
	public static final ActionEventCategoryCode RESUPPLYING = new ActionEventCategoryCode(
			"Resupplying",
			"RESPLN",
			"Replenishing stocks in order to maintain the required levels of supply.");
	public static final ActionEventCategoryCode RESTING = new ActionEventCategoryCode(
			"Resting",
			"RESTNG",
			"Observing a specified period of inactivity by an organisation that is out of contact with the enemy.");
	public static final ActionEventCategoryCode RETAIN = new ActionEventCategoryCode(
			"Retain",
			"RETAIN",
			"Occupying and holding a terrain feature to ensure it is free of enemy occupation or use.");
	public static final ActionEventCategoryCode RETIRE = new ActionEventCategoryCode(
			"Retire",
			"RETIRE",
			"Moving a force out of contact with the enemy with the expectation of no further significant contact.");
	public static final ActionEventCategoryCode REVOLUTION = new ActionEventCategoryCode(
			"Revolution",
			"REVOLU",
			"The overthrow or renunciation of one government or ruler and the substitution of another by the governed.");
	public static final ActionEventCategoryCode RIOT = new ActionEventCategoryCode(
			"Riot",
			"RIOT",
			"A disturbance of the peace by a crowd; an occurrence of public disorder.");
	public static final ActionEventCategoryCode ROCKET_FIRE = new ActionEventCategoryCode(
			"Rocket fire",
			"RKTFIR",
			"The employment of a rocket powered weapon.");
	public static final ActionEventCategoryCode RELIEF_IN_PLACE = new ActionEventCategoryCode(
			"Relief in place",
			"RLFPLC",
			"An operation in which, by direction of higher authority, all or part of a unit is replaced in an area by the incoming unit. The responsibilities of the replaced elements for the mission and the assigned zone of operations are transferred to the incoming unit. The incoming unit continues the operation as ordered.");
	public static final ActionEventCategoryCode RENDEZVOUS = new ActionEventCategoryCode(
			"Rendezvous",
			"RNDZVS",
			"Achieving a pre-arranged meeting at a given time and place.");
	public static final ActionEventCategoryCode ROBBERY = new ActionEventCategoryCode(
			"Robbery",
			"ROBERY",
			"Unlawfully taking property, valuables or money from a person or place.");
	public static final ActionEventCategoryCode SABOTAGE = new ActionEventCategoryCode(
			"Sabotage",
			"SABOTG",
			"An act or acts with intent to injure, interfere with, or obstruct the national defence of a country by wilfully injuring or destroying, or attempting to injure or destroy, any national defence or war material, premises or utilities, to include human and natural resources.");
	public static final ActionEventCategoryCode SUBVERSION = new ActionEventCategoryCode(
			"Subversion",
			"SBVRSN",
			"Action designed to weaken the military, economic or political strength of a nation by undermining the morale, loyalty or reliability of its citizens.");
	public static final ActionEventCategoryCode SCOUTING = new ActionEventCategoryCode(
			"Scouting",
			"SCOTNG",
			"The action of gathering information.");
	public static final ActionEventCategoryCode SCREENING = new ActionEventCategoryCode(
			"Screening",
			"SCRNNG",
			"Operating as a security element whose primary task is to observe, identify and report information, and which only fights in self-protection.");
	public static final ActionEventCategoryCode SECURITY_COMPROMISE = new ActionEventCategoryCode(
			"Security compromise",
			"SECCMP",
			"A release of information to someone unauthorised.");
	public static final ActionEventCategoryCode SECESSION_OF_PORTION_OF_COUNTRY = new ActionEventCategoryCode(
			"Secession of portion of country",
			"SECCOU",
			"The formal withdrawal of a portion of a country.");
	public static final ActionEventCategoryCode SECURING = new ActionEventCategoryCode(
			"Securing",
			"SECRNG",
			"Gaining possession of a position or terrain feature, with or without force, and making such disposition to prevent, as far as possible, its destruction or loss by enemy action.");
	public static final ActionEventCategoryCode SECURITY_VIOLATION = new ActionEventCategoryCode(
			"Security violation",
			"SECVIO",
			"An infringement of a security protocol.");
	public static final ActionEventCategoryCode SEIZING = new ActionEventCategoryCode(
			"Seizing",
			"SEIZNG",
			"Clearing a designated area and obtaining control of it.");
	public static final ActionEventCategoryCode SHOOTING = new ActionEventCategoryCode(
			"Shooting",
			"SHOTNG",
			"The act of firing of a weapon, usually at a person.");
	public static final ActionEventCategoryCode SIGHTING = new ActionEventCategoryCode(
			"Sighting",
			"SIGTNG",
			"The action of looking, catching sight of.");
	public static final ActionEventCategoryCode VESSEL_SINKING = new ActionEventCategoryCode(
			"Vessel sinking",
			"SINKIN",
			"The unforeseen loss, damage or destruction of a vessel by submersion.");
	public static final ActionEventCategoryCode SMUGGLING = new ActionEventCategoryCode(
			"Smuggling",
			"SMGLNG",
			"To convey (goods) clandestinely, in order to avoid payment of legal duties or to convey illegal goods.");
	public static final ActionEventCategoryCode SNIPER_ATTACK = new ActionEventCategoryCode(
			"Sniper attack",
			"SNPATK",
			"An attack by one who shoots at others from a concealed place.");
	public static final ActionEventCategoryCode SPACE_ACCIDENT = new ActionEventCategoryCode(
			"Space accident",
			"SPACAC",
			"The unforeseen loss, destruction or damage of a spacecraft.");
	public static final ActionEventCategoryCode SPEECH = new ActionEventCategoryCode(
			"Speech",
			"SPEECH",
			"An address or discourse of more or less formal character delivered to an audience or assembly; an oration.");
	public static final ActionEventCategoryCode SPYING = new ActionEventCategoryCode(
			"Spying",
			"SPYING",
			"Obtaining intelligence information furtively as an agent of a foreign power or competition.");
	public static final ActionEventCategoryCode SEARCHING = new ActionEventCategoryCode(
			"Searching",
			"SRCHNG",
			"The act of looking for something or someone.");
	public static final ActionEventCategoryCode SERVING_AS_AN_ADVANCE_GUARD = new ActionEventCategoryCode(
			"Serving as an advance guard",
			"SRVADV",
			"Operating as a security element whose primary task is to move ahead of the main body and protect the main force by fighting to gain time, whilst also observing and reporting information.");
	public static final ActionEventCategoryCode SERVING_AS_A_BRIDGEHEAD_FORCE = new ActionEventCategoryCode(
			"Serving as a bridgehead force",
			"SRVBRD",
			"Operating as a force that seizes or controls ground in order to permit the continuous embarkation, landing or crossing of troops or materiel and to provide manoeuvre space during a water obstacle crossing.");
	public static final ActionEventCategoryCode SERVING_AS_A_BREAKOUT_FORCE = new ActionEventCategoryCode(
			"Serving as a breakout force",
			"SRVBRK",
			"Operating as a force that is tasked with the continuation of the operation during an obstacle crossing.");
	public static final ActionEventCategoryCode SERVING_AS_A_FLANK_GUARD = new ActionEventCategoryCode(
			"Serving as a flank guard",
			"SRVFLK",
			"Operating as a security element whose primary task is to protect the main force by fighting on the designated flank to gain time, whilst also observing and reporting information.");
	public static final ActionEventCategoryCode SERVING_AS_AN_IN_PLACE_FORCE = new ActionEventCategoryCode(
			"Serving as an in-place force",
			"SRVINP",
			"Operating as a force that provides fire and other support to the bridgehead force during an obstacle crossing.");
	public static final ActionEventCategoryCode SURVEILLANCE = new ActionEventCategoryCode(
			"Surveillance",
			"SRVLNC",
			"The systematic observation of aerospace, surface or subsurface areas, places, person or things by visual, aural, electronic, photographic or other means.");
	public static final ActionEventCategoryCode SERVING_AS_A_MAIN_BODY = new ActionEventCategoryCode(
			"Serving as a main body",
			"SRVMNB",
			"Operating as the main force for a specific operation.");
	public static final ActionEventCategoryCode SERVING_AS_A_REAR_GUARD = new ActionEventCategoryCode(
			"Serving as a rear guard",
			"SRVRGD",
			"Operating as a security element whose primary task is to move (or remain) at the rear of the main body and protect the main force by fighting to gain time, whilst also observing and reporting information.");
	public static final ActionEventCategoryCode SERVING_AS_A_RESERVE = new ActionEventCategoryCode(
			"Serving as a reserve",
			"SRVRSF",
			"Operating as a force that may be committed into combat only on the order of the commander of the organisation who so designated the reserve force.");
	public static final ActionEventCategoryCode STATE_OF_WAR = new ActionEventCategoryCode(
			"State of war",
			"STAWAR",
			"A state characterised by hostile military activity between the parts.");
	public static final ActionEventCategoryCode SETTING_UP = new ActionEventCategoryCode(
			"Setting up",
			"STNGUP",
			"Establishing a FACILITY, ORGANISATION or FEATURE.");
	public static final ActionEventCategoryCode STRAFING_AERIAL = new ActionEventCategoryCode(
			"Strafing, aerial",
			"STRFAR",
			"Attack by enemy aircraft against ground targets using forward firing ordnance (bullets, shells, or rockets).");
	public static final ActionEventCategoryCode STRIKE = new ActionEventCategoryCode(
			"Strike",
			"STRIKE",
			"The organised refusal by employees to work until some grievance is remedied.");
	public static final ActionEventCategoryCode SUICIDE = new ActionEventCategoryCode(
			"Suicide",
			"SUICDE",
			"The action of killing oneself intentionally.");
	public static final ActionEventCategoryCode SUPPRESSING = new ActionEventCategoryCode(
			"Suppressing",
			"SUPRSN",
			"Providing fires that neutralizes or temporarily degrades the capabilities of enemy forces within a specific area. This makes no assumptions as to enemy casualties; it may be a transitory effect.");
	public static final ActionEventCategoryCode SUPPORTING = new ActionEventCategoryCode(
			"Supporting",
			"SUPRTN",
			"Aiding, protecting, complementing or sustaining an object.");
	public static final ActionEventCategoryCode SURRENDER = new ActionEventCategoryCode(
			"Surrender",
			"SURREN",
			"Yielding to the control or power of the enemy.");
	public static final ActionEventCategoryCode SURVEILLANCE_ELECTRONIC = new ActionEventCategoryCode(
			"Surveillance, electronic",
			"SURVEL",
			"The systematic observation of aerospace, surface or subsurface areas, places, persons, or things, by electronic means.");
	public static final ActionEventCategoryCode SUSPENSION_OF_HOSTILITIES = new ActionEventCategoryCode(
			"Suspension of hostilities",
			"SUSHOS",
			"The cessation of war activities.");
	public static final ActionEventCategoryCode TERRORISM = new ActionEventCategoryCode(
			"Terrorism",
			"TERR",
			"Using or threatening force or violence against individuals or property in an attempt to coerce or intimidate governments or societies to achieve political, religious or ideological objectives.");
	public static final ActionEventCategoryCode THREATEN = new ActionEventCategoryCode(
			"Threaten",
			"THREAT",
			"Menacing an armed force by manoeuvre or action.");
	public static final ActionEventCategoryCode TORTURE = new ActionEventCategoryCode(
			"Torture",
			"TORTUR",
			"An action or practice of inflicting severe pain as a punishment or a forcible means of persuasion.");
	public static final ActionEventCategoryCode TROUBLEMAKING_AGITATING = new ActionEventCategoryCode(
			"Troublemaking, agitating",
			"TRBAGT",
			"Stirring up of public interest on a matter of controversy, such as a political or social issue.");
	public static final ActionEventCategoryCode TROUBLEMAKING_BULLYING = new ActionEventCategoryCode(
			"Troublemaking, bullying",
			"TRBBLL",
			"Intimidating by the use of superior size or strength.");
	public static final ActionEventCategoryCode TROUBLEMAKING_HARASSING = new ActionEventCategoryCode(
			"Troublemaking, harassing",
			"TRBHAR",
			"Persecuting systematically by besetting with annoyances, threats or demands.");
	public static final ActionEventCategoryCode TROUBLEMAKING_HOOLIGANISM = new ActionEventCategoryCode(
			"Troublemaking, hooliganism",
			"TRBHLG",
			"Causing difficulties by the actions of hoodlums, especially young ruffians.");
	public static final ActionEventCategoryCode TROUBLEMAKING_INCITING = new ActionEventCategoryCode(
			"Troublemaking, inciting",
			"TRBINC",
			"Provoking to action, stirring up or urging on.");
	public static final ActionEventCategoryCode TROUBLEMAKING_INTIMIDATING = new ActionEventCategoryCode(
			"Troublemaking, intimidating",
			"TRBINT",
			"Discouraging or inhibiting by or as if by threats.");
	public static final ActionEventCategoryCode TREATY_VIOLATION = new ActionEventCategoryCode(
			"Treaty violation",
			"TREVIO",
			"An infringement or breaking of the provisions of a formal agreement.");
	public static final ActionEventCategoryCode TRANSMISSION = new ActionEventCategoryCode(
			"Transmission",
			"TRNSMS",
			"The transfer of information from one point to one or more other points by means of signals.");
	public static final ActionEventCategoryCode TRANSPORTING = new ActionEventCategoryCode(
			"Transporting",
			"TRNSPN",
			"Moving assets to a specified objective by sea, land or air.");
	public static final ActionEventCategoryCode TRAVERSING = new ActionEventCategoryCode(
			"Traversing",
			"TRVRSN",
			"Travelling over a designated route.");
	public static final ActionEventCategoryCode TURNING = new ActionEventCategoryCode(
			"Turning",
			"TURNNG",
			"Compelling an enemy force to move from one avenue of approach or movement corridor to another.");
	public static final ActionEventCategoryCode UXO_DISCOVERY = new ActionEventCategoryCode(
			"UXO discovery",
			"UXODSC",
			"The detection of the presence of unexploded explosive ordnance.");
	public static final ActionEventCategoryCode VANDALISM_RAPE_LOOT_RANSACK_PLUNDER_SACK = new ActionEventCategoryCode(
			"Vandalism/Rape/Loot/Ransack/Plunder/Sack",
			"VANDAL",
			"An act of vandalism, raping, looting, ransacking or plundering against an individual or property.");
	public static final ActionEventCategoryCode VERIFYING = new ActionEventCategoryCode(
			"Verifying",
			"VERFYN",
			"Testifying to, asserting, affirming or confirming, as true or certain.");
	public static final ActionEventCategoryCode VOLCANIC_ERUPTION = new ActionEventCategoryCode(
			"Volcanic eruption",
			"VOLCAN",
			"The release of lava or steam by a volcano.");
	public static final ActionEventCategoryCode WAR_CRISIS_ALERT = new ActionEventCategoryCode(
			"War/crisis alert",
			"WARALE",
			"The state of readiness caused by the possibility of a war.");
	public static final ActionEventCategoryCode WAR_MILITARY_CONFERENCE = new ActionEventCategoryCode(
			"War/military conference",
			"WARCON",
			"A meeting of a group of persons to discuss war/military process.");
	public static final ActionEventCategoryCode WAR_CRIME = new ActionEventCategoryCode(
			"War crime",
			"WARCRM",
			"Violation of the laws and customs of war, i.e. the principles and norms of international law that enshrine the rights and duties of warring parties and neutral states.");
	public static final ActionEventCategoryCode OCEANS_SEAS_OR_WATER_POLLUTION = new ActionEventCategoryCode(
			"Oceans, seas or water pollution",
			"WATPOL",
			"Contamination of a body of water caused by a poison or toxin.");
	public static final ActionEventCategoryCode WITHDRAWAL_UNDER_PRESSURE = new ActionEventCategoryCode(
			"Withdrawal under pressure",
			"WDRPRS",
			"Disengaging from the enemy when the enemy has sufficient contact with friendly forces to interfere with the withdrawal.");
	public static final ActionEventCategoryCode WITHDRAWAL = new ActionEventCategoryCode(
			"Withdrawal",
			"WITDRL",
			"Disengaging a force in contact from an enemy force.");
	public static final ActionEventCategoryCode WITNESSING = new ActionEventCategoryCode(
			"Witnessing",
			"WITNSN",
			"Observing an activity that may result in the need to provide evidence.");
	public static final ActionEventCategoryCode WEAPON_FIRING = new ActionEventCategoryCode(
			"Weapon firing",
			"WPNFIR",
			"The firing of weapons.");

	private ActionEventCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
