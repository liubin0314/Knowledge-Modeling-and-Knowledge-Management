/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ApproachDirectionCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that differentiates between left, right and centre parallel runways, Short Takeoff and Landing (STOL) or true as applicable.";
	}

	private static HashMap<String, ApproachDirectionCategoryCode> physicalToCode = new HashMap<String, ApproachDirectionCategoryCode>();

	public static ApproachDirectionCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ApproachDirectionCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ApproachDirectionCategoryCode CENTRE = new ApproachDirectionCategoryCode(
			"Centre",
			"C",
			"The specific value that specifies the centre runway approach for parallel runways.");
	public static final ApproachDirectionCategoryCode LEFT = new ApproachDirectionCategoryCode(
			"Left",
			"L",
			"The specific value that specifies the left side runway approach for parallel runways.");
	public static final ApproachDirectionCategoryCode RIGHT = new ApproachDirectionCategoryCode(
			"Right",
			"R",
			"The specific value that specifies the right side runway approach for parallel runways.");
	public static final ApproachDirectionCategoryCode STOL = new ApproachDirectionCategoryCode(
			"STOL",
			"S",
			"The specific value that specifies short take-off and landing approach direction.");
	public static final ApproachDirectionCategoryCode TRUE = new ApproachDirectionCategoryCode(
			"True",
			"T",
			"The specific value, which specifies that the approach direction is comparable to the true heading not magnetic heading.");

	private ApproachDirectionCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
