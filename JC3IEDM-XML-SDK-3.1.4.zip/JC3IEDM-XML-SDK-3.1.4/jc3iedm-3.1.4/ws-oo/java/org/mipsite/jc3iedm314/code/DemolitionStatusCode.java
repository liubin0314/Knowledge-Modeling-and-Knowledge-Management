/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class DemolitionStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of an object destined for demolition.";
	}

	private static HashMap<String, DemolitionStatusCode> physicalToCode = new HashMap<String, DemolitionStatusCode>();

	public static DemolitionStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<DemolitionStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final DemolitionStatusCode ABANDONED_INCOMPLETE = new DemolitionStatusCode(
			"Abandoned incomplete",
			"ABNDIN",
			"The object of the demolition was abandoned before the destruction was executed. Demolition devices may still be present.");
	public static final DemolitionStatusCode CANCELLED = new DemolitionStatusCode(
			"Cancelled",
			"CANCLD",
			"The demolition of the object was cancelled either before demolition devices were attached or these devices were removed.");
	public static final DemolitionStatusCode EXECUTED = new DemolitionStatusCode(
			"Executed",
			"EXECTD",
			"The object is demolished.");
	public static final DemolitionStatusCode NOT_KNOWN = new DemolitionStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final DemolitionStatusCode PLANNED_PRELIMINARY = new DemolitionStatusCode(
			"Planned preliminary",
			"PLNPRL",
			"The object of the demolition is planned as a preliminary demolition; execution can proceed without reference to an authorised commander.");
	public static final DemolitionStatusCode PLANNED_RESERVE = new DemolitionStatusCode(
			"Planned reserve",
			"PLNRES",
			"The object of the demolition is planned as a reserve demolition; execution is to be ordered by a specific authorised commander.");
	public static final DemolitionStatusCode PREPARED_FOR_EXECUTION = new DemolitionStatusCode(
			"Prepared for execution",
			"PRPEXE",
			"The object is prepared for demolition.");
	public static final DemolitionStatusCode STATE_1 = new DemolitionStatusCode(
			"State 1",
			"STATE1",
			"The object is at demolition state 1 (safe). The demolition devices are installed but not armed.");
	public static final DemolitionStatusCode STATE_2 = new DemolitionStatusCode(
			"State 2",
			"STATE2",
			"The object is at demolition state 2 (armed). The demolition devices are installed and armed; therefore the object is ready for immediate demolition.");

	private DemolitionStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
