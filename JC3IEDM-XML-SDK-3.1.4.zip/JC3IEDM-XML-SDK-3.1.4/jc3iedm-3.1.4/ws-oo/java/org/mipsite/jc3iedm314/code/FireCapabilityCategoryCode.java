/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FireCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FIRE-CAPABILITY.";
	}

	private static HashMap<String, FireCapabilityCategoryCode> physicalToCode = new HashMap<String, FireCapabilityCategoryCode>();

	public static FireCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FireCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FireCapabilityCategoryCode AIR_TO_AIR = new FireCapabilityCategoryCode(
			"Air to air",
			"AIRAIR",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from aircraft at targets in the air.");
	public static final FireCapabilityCategoryCode AIR_TO_GROUND = new FireCapabilityCategoryCode(
			"Air to ground",
			"AIRGRD",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from aircraft at targets on the ground.");
	public static final FireCapabilityCategoryCode AIR_TO_SEA = new FireCapabilityCategoryCode(
			"Air to sea",
			"AIRSEA",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from aircraft at targets at sea.");
	public static final FireCapabilityCategoryCode GROUND_TO_AIR = new FireCapabilityCategoryCode(
			"Ground to air",
			"GRDAIR",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from the ground to an airborne target.");
	public static final FireCapabilityCategoryCode GROUND_TO_GROUND = new FireCapabilityCategoryCode(
			"Ground to ground",
			"GRDGRD",
			"The specific value implies that a specific FIRE-CAPABILITY involves surface firing.");
	public static final FireCapabilityCategoryCode GROUND_TO_SEA = new FireCapabilityCategoryCode(
			"Ground to sea",
			"GRDSEA",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from the ground to targets at sea.");
	public static final FireCapabilityCategoryCode SEA_TO_AIR = new FireCapabilityCategoryCode(
			"Sea to air",
			"SEAAIR",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from a vessel to airborne targets.");
	public static final FireCapabilityCategoryCode SEA_TO_GROUND = new FireCapabilityCategoryCode(
			"Sea to ground",
			"SEAGRD",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from a vessel to targets on the ground.");
	public static final FireCapabilityCategoryCode SEA_TO_SEA = new FireCapabilityCategoryCode(
			"Sea to sea",
			"SEASEA",
			"The specific value implies that a specific FIRE-CAPABILITY involves firing from a vessel to targets at sea.");

	private FireCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
