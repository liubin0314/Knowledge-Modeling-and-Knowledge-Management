/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VegetationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general type of vegetation.";
	}

	private static HashMap<String, VegetationCategoryCode> physicalToCode = new HashMap<String, VegetationCategoryCode>();

	public static VegetationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VegetationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VegetationCategoryCode BARE = new VegetationCategoryCode(
			"Bare",
			"BARE",
			"Land devoid of vegetation.");
	public static final VegetationCategoryCode JUNGLE = new VegetationCategoryCode(
			"Jungle",
			"JUNGLE",
			"An area where heat is seldom less than 80�F/27�C, humidity normally 80-95% and rainfall on average at least 80 inches per year and rugged terrain.");
	public static final VegetationCategoryCode NOT_KNOWN = new VegetationCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final VegetationCategoryCode NOT_OTHERWISE_SPECIFIED = new VegetationCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final VegetationCategoryCode PLANT_CULTIVATION = new VegetationCategoryCode(
			"Plant cultivation",
			"PLANT",
			"An area containing crops or gardens.");
	public static final VegetationCategoryCode RANGELAND = new VegetationCategoryCode(
			"Rangeland",
			"RNGLND",
			"An area containing uncultured plants of low height.");
	public static final VegetationCategoryCode WETLANDS = new VegetationCategoryCode(
			"Wetlands",
			"WETLND",
			"A swamp, marsh, or other usually saturated area containing vegetation adapted to wet conditions.");
	public static final VegetationCategoryCode WOODLAND = new VegetationCategoryCode(
			"Woodland",
			"WODLND",
			"An area containing vegetation composed of tree species which have reached sufficient size for use as timber.");

	private VegetationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
