/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionTask extends AbstractAction {

	// private fields

	private ActionTaskActivityCode activityCode; // mandatory
	private DurationType19 minimumDuration; // optional
	private DurationType19 estimatedDuration; // optional
	private DurationType19 maximumDuration; // optional
	private DatetimeTypeFix18 plannedStartDatetime; // optional
	private ActionTaskStartQualifierCode startQualifierCode; // optional
	private DatetimeTypeFix18 plannedEndDatetime; // optional
	private ActionTaskEndQualifierCode endQualifierCode; // optional
	private ActionTaskPriorityCode priorityCode; // optional
	private ActionTaskEntailedSafetyDegreeCode entailedSafetyDegreeCode; // optional
	private ActionTaskOvertCovertCode overtCovertCode; // optional
	private TextTypeVar255 detailText; // optional
	private ActionTaskTimingDayCode timingDayCode; // optional
	private ActionTaskTimingHourCode timingHourCode; // optional
	private ActionTaskMeteorologicalImpactCode meteorologicalImpactCode; // optional
	private ActionTaskOperationalLevelCode operationalLevelCode; // optional
	private Ref<CandidateTargetList> candidateTargetList; // optional
	private Ref<OrganisationStructure> organisationStructure; // optional
	private Set<Ref<ActionTaskRuleOfEngagement>> actionTaskRuleOfEngagementSet; // zero-one-or-more
	private Set<Ref<ActionTaskStatus>> statusSet; // zero-one-or-more

	// default constructor

	public AbstractActionTask() {
		this.actionTaskRuleOfEngagementSet = new HashSet<Ref<ActionTaskRuleOfEngagement>>();
		this.statusSet = new HashSet<Ref<ActionTaskStatus>>();
	}

	// getter & setter methods

	public ActionTaskActivityCode getActivityCode() {
		if (this.activityCode == null) {
			throw new NullValueException("AbstractActionTask.activityCode");
		}
		return this.activityCode;
	}

	public void setActivityCode(ActionTaskActivityCode activityCode) {
		this.activityCode = activityCode;
	}

	public DurationType19 getMinimumDuration() {
		return this.minimumDuration;
	}

	public void setMinimumDuration(DurationType19 minimumDuration) {
		this.minimumDuration = minimumDuration;
	}

	public DurationType19 getEstimatedDuration() {
		return this.estimatedDuration;
	}

	public void setEstimatedDuration(DurationType19 estimatedDuration) {
		this.estimatedDuration = estimatedDuration;
	}

	public DurationType19 getMaximumDuration() {
		return this.maximumDuration;
	}

	public void setMaximumDuration(DurationType19 maximumDuration) {
		this.maximumDuration = maximumDuration;
	}

	public DatetimeTypeFix18 getPlannedStartDatetime() {
		return this.plannedStartDatetime;
	}

	public void setPlannedStartDatetime(DatetimeTypeFix18 plannedStartDatetime) {
		this.plannedStartDatetime = plannedStartDatetime;
	}

	public ActionTaskStartQualifierCode getStartQualifierCode() {
		return this.startQualifierCode;
	}

	public void setStartQualifierCode(ActionTaskStartQualifierCode startQualifierCode) {
		this.startQualifierCode = startQualifierCode;
	}

	public DatetimeTypeFix18 getPlannedEndDatetime() {
		return this.plannedEndDatetime;
	}

	public void setPlannedEndDatetime(DatetimeTypeFix18 plannedEndDatetime) {
		this.plannedEndDatetime = plannedEndDatetime;
	}

	public ActionTaskEndQualifierCode getEndQualifierCode() {
		return this.endQualifierCode;
	}

	public void setEndQualifierCode(ActionTaskEndQualifierCode endQualifierCode) {
		this.endQualifierCode = endQualifierCode;
	}

	public ActionTaskPriorityCode getPriorityCode() {
		return this.priorityCode;
	}

	public void setPriorityCode(ActionTaskPriorityCode priorityCode) {
		this.priorityCode = priorityCode;
	}

	public ActionTaskEntailedSafetyDegreeCode getEntailedSafetyDegreeCode() {
		return this.entailedSafetyDegreeCode;
	}

	public void setEntailedSafetyDegreeCode(ActionTaskEntailedSafetyDegreeCode entailedSafetyDegreeCode) {
		this.entailedSafetyDegreeCode = entailedSafetyDegreeCode;
	}

	public ActionTaskOvertCovertCode getOvertCovertCode() {
		return this.overtCovertCode;
	}

	public void setOvertCovertCode(ActionTaskOvertCovertCode overtCovertCode) {
		this.overtCovertCode = overtCovertCode;
	}

	public TextTypeVar255 getDetailText() {
		return this.detailText;
	}

	public void setDetailText(TextTypeVar255 detailText) {
		this.detailText = detailText;
	}

	public ActionTaskTimingDayCode getTimingDayCode() {
		return this.timingDayCode;
	}

	public void setTimingDayCode(ActionTaskTimingDayCode timingDayCode) {
		this.timingDayCode = timingDayCode;
	}

	public ActionTaskTimingHourCode getTimingHourCode() {
		return this.timingHourCode;
	}

	public void setTimingHourCode(ActionTaskTimingHourCode timingHourCode) {
		this.timingHourCode = timingHourCode;
	}

	public ActionTaskMeteorologicalImpactCode getMeteorologicalImpactCode() {
		return this.meteorologicalImpactCode;
	}

	public void setMeteorologicalImpactCode(ActionTaskMeteorologicalImpactCode meteorologicalImpactCode) {
		this.meteorologicalImpactCode = meteorologicalImpactCode;
	}

	public ActionTaskOperationalLevelCode getOperationalLevelCode() {
		return this.operationalLevelCode;
	}

	public void setOperationalLevelCode(ActionTaskOperationalLevelCode operationalLevelCode) {
		this.operationalLevelCode = operationalLevelCode;
	}

	public Ref<CandidateTargetList> getCandidateTargetList() {
		return this.candidateTargetList;
	}

	public void setCandidateTargetList(Ref<CandidateTargetList> candidateTargetList) {
		this.candidateTargetList = candidateTargetList;
	}

	public Ref<OrganisationStructure> getOrganisationStructure() {
		return this.organisationStructure;
	}

	public void setOrganisationStructure(Ref<OrganisationStructure> organisationStructure) {
		this.organisationStructure = organisationStructure;
	}

	public Set<Ref<ActionTaskRuleOfEngagement>> getActionTaskRuleOfEngagementSet() {
		return this.actionTaskRuleOfEngagementSet;
	}

	public void addActionTaskRuleOfEngagement(Ref<ActionTaskRuleOfEngagement> actionTaskRuleOfEngagement) {
		this.actionTaskRuleOfEngagementSet.add(actionTaskRuleOfEngagement);
	}

	public Set<Ref<ActionTaskStatus>> getStatusSet() {
		return this.statusSet;
	}

	public void addStatus(Ref<ActionTaskStatus> status) {
		this.statusSet.add(status);
	}
}
