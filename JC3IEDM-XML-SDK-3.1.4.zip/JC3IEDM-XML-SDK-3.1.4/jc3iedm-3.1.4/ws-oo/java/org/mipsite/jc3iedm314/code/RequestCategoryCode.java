/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RequestCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type classification of a specific REQUEST.";
	}

	private static HashMap<String, RequestCategoryCode> physicalToCode = new HashMap<String, RequestCategoryCode>();

	public static RequestCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RequestCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RequestCategoryCode ACTION = new RequestCategoryCode(
			"Action",
			"ACTION",
			"To discover the actions of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode ASSOCIATION = new RequestCategoryCode(
			"Association",
			"ASSOC",
			"To discover the relation between two ACTION-OBJECTIVEs (OBJECT-ITEMs) by any means.");
	public static final RequestCategoryCode CAPABILITY = new RequestCategoryCode(
			"Capability",
			"CAPAB",
			"To discover the capability of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode HOLDING = new RequestCategoryCode(
			"Holding",
			"HOLDNG",
			"To discover the holding of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode HOSTILITY = new RequestCategoryCode(
			"Hostility",
			"HOSTIL",
			"To recognise the friendly or enemy character of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode LOCATION = new RequestCategoryCode(
			"Location",
			"LOCATN",
			"To discover the location of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode PRESENCE = new RequestCategoryCode(
			"Presence",
			"PRESNC",
			"To discover the manifestation of an ACTION-OBJECTIVE in the area of operational interest specified through another ACTION-OBJECTIVE (OBJECT-ITEM: FACILITY, FEATURE).");
	public static final RequestCategoryCode STATUS = new RequestCategoryCode(
			"Status",
			"STATUS",
			"To recognise the status of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");
	public static final RequestCategoryCode TYPE = new RequestCategoryCode(
			"Type",
			"TYPE",
			"To recognise the type of an ACTION-OBJECTIVE (OBJECT-ITEM) by any means.");

	private RequestCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
