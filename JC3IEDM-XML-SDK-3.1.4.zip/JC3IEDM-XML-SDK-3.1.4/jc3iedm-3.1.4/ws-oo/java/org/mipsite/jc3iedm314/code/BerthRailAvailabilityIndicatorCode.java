/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BerthRailAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the availability of railroad transportation capability at a specific BERTH.";
	}

	private static HashMap<String, BerthRailAvailabilityIndicatorCode> physicalToCode = new HashMap<String, BerthRailAvailabilityIndicatorCode>();

	public static BerthRailAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BerthRailAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BerthRailAvailabilityIndicatorCode NO = new BerthRailAvailabilityIndicatorCode(
			"No",
			"NO",
			"Railroad transportation is not available at the berth.");
	public static final BerthRailAvailabilityIndicatorCode YES = new BerthRailAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Railroad transportation is available at the berth.");

	private BerthRailAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
