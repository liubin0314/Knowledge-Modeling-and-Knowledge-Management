/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemLocationMeaningCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the meaning of the LOCATION geometry as it pertains to the OBJECT-ITEM.";
	}

	private static HashMap<String, ObjectItemLocationMeaningCode> physicalToCode = new HashMap<String, ObjectItemLocationMeaningCode>();

	public static ObjectItemLocationMeaningCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemLocationMeaningCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemLocationMeaningCode ADDRESSEE_S_PRESENT_POSITION = new ObjectItemLocationMeaningCode(
			"Addressee�s present position",
			"ADRPRP",
			"The current position of an addressee.");
	public static final ObjectItemLocationMeaningCode ASSOCIATION_WITH_COMMAND_POST = new ObjectItemLocationMeaningCode(
			"Association with command post",
			"ASSCP",
			"The point representing the location of the ORGANISATION is the same as that of its command post.");
	public static final ObjectItemLocationMeaningCode CENTRE_OF_MASS_MANUAL_DERIVATION = new ObjectItemLocationMeaningCode(
			"Centre of mass (manual derivation)",
			"CEOFMA",
			"A point representing the mean position of an OBJECT-ITEM. It is derived by manual means.");
	public static final ObjectItemLocationMeaningCode COMMANDER_DETERMINED = new ObjectItemLocationMeaningCode(
			"Commander determined",
			"CMDDET",
			"A point representing the position of an OBJECT-ITEM in accordance to criteria specified by competent authority.");
	public static final ObjectItemLocationMeaningCode CENTRE_OF_MASS_AUTOMATED_DERIVATION = new ObjectItemLocationMeaningCode(
			"Centre of mass (automated derivation)",
			"COM",
			"A point representing the mean position of an OBJECT-ITEM. It is calculated by automated means.");
	public static final ObjectItemLocationMeaningCode CENTRE_FRONT_OF_FORCE_CONVOY = new ObjectItemLocationMeaningCode(
			"Centre front of force/convoy",
			"CTRMNB",
			"A position in the centre of the front line of a force or convoy when the convoy is not in circular formation.");
	public static final ObjectItemLocationMeaningCode DISPOSITION_CENTRE = new ObjectItemLocationMeaningCode(
			"Disposition centre",
			"DSPCTR",
			"The central position of a maritime force disposition.");
	public static final ObjectItemLocationMeaningCode FORMATION_CENTRE = new ObjectItemLocationMeaningCode(
			"Formation centre",
			"FRMCTR",
			"The central point of a maritime force formation.");
	public static final ObjectItemLocationMeaningCode LINE_OF_BEARING = new ObjectItemLocationMeaningCode(
			"Line of bearing",
			"LNBRNG",
			"A specific LOCATION representing the direction from an observer to the specific OBJECT-ITEM. The direction is specified by means of FAN-AREA geometry using the observer's position as the vertex.");
	public static final ObjectItemLocationMeaningCode ORIGINATOR_S_PRESENT_LOCATION = new ObjectItemLocationMeaningCode(
			"Originator�s present location",
			"ORGPRL",
			"Originators current position.");
	public static final ObjectItemLocationMeaningCode POSITION_OF_INTENDED_MOVEMENT = new ObjectItemLocationMeaningCode(
			"Position of intended movement",
			"POSOIM",
			"The pre-planned movement of a unit or force between designated points detailed by either time, position, course and speed.");
	public static final ObjectItemLocationMeaningCode SHAPE = new ObjectItemLocationMeaningCode(
			"Shape",
			"SHAPE",
			"A location describing the external geometry of an OBJECT-ITEM.");
	public static final ObjectItemLocationMeaningCode SOUNDING = new ObjectItemLocationMeaningCode(
			"Sounding",
			"SOUND",
			"A measured water depth or spot depth which has been reduced to chart datum.");
	public static final ObjectItemLocationMeaningCode STANDARD_POSITION_ESTAB_BY_OTC = new ObjectItemLocationMeaningCode(
			"Standard position estab by OTC",
			"STDPOS",
			"A position designated by the OTC in which all positional reports are to be based upon.");

	private ObjectItemLocationMeaningCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
