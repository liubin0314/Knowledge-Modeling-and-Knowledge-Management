/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of EQUIPMENT-TYPE.";
	}

	private static HashMap<String, EquipmentTypeCategoryCode> physicalToCode = new HashMap<String, EquipmentTypeCategoryCode>();

	public static EquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EquipmentTypeCategoryCode AIRCRAFT_TYPE = new EquipmentTypeCategoryCode(
			"AIRCRAFT-TYPE",
			"AIRCFT",
			"An EQUIPMENT-TYPE that is designed to fly.");
	public static final EquipmentTypeCategoryCode CBRN_EQUIPMENT_TYPE = new EquipmentTypeCategoryCode(
			"CBRN-EQUIPMENT-TYPE",
			"CBRNEQ",
			"An EQUIPMENT-TYPE that is designed for specialised roles in detecting, decontaminating or reconnoitring NBC (CBRN) materiel.");
	public static final EquipmentTypeCategoryCode ELECTRONIC_EQUIPMENT_TYPE = new EquipmentTypeCategoryCode(
			"ELECTRONIC-EQUIPMENT-TYPE",
			"ELCTRN",
			"An EQUIPMENT-TYPE that is designed to use electronic processing to realise its primary function.");
	public static final EquipmentTypeCategoryCode ENGINEERING_EQUIPMENT_TYPE = new EquipmentTypeCategoryCode(
			"ENGINEERING-EQUIPMENT-TYPE",
			"ENGEQ",
			"An EQUIPMENT-TYPE that is designed to accomplish engineering functions.");
	public static final EquipmentTypeCategoryCode MISCELLANEOUS_EQUIPMENT_TYPE = new EquipmentTypeCategoryCode(
			"MISCELLANEOUS-EQUIPMENT-TYPE",
			"MISCEQ",
			"An EQUIPMENT-TYPE whose designed function does not fit in any other defined category.");
	public static final EquipmentTypeCategoryCode MARITIME_EQUIPMENT_TYPE = new EquipmentTypeCategoryCode(
			"MARITIME-EQUIPMENT-TYPE",
			"MRTMEQ",
			"An EQUIPMENT-TYPE that is designed to be used in a maritime environment.");
	public static final EquipmentTypeCategoryCode RAILCAR_TYPE = new EquipmentTypeCategoryCode(
			"RAILCAR-TYPE",
			"RAIL",
			"An EQUIPMENT-TYPE that is designed to operate on rail tracks.");
	public static final EquipmentTypeCategoryCode VEHICLE_TYPE = new EquipmentTypeCategoryCode(
			"VEHICLE-TYPE",
			"VEHCLE",
			"An EQUIPMENT-TYPE that is designed to operate on land routes (other than rail) with a primary role of transporting personnel, equipment or supplies.");
	public static final EquipmentTypeCategoryCode VESSEL_TYPE = new EquipmentTypeCategoryCode(
			"VESSEL-TYPE",
			"VESSEL",
			"An EQUIPMENT-TYPE that is designed to operate on or under the water surface.");
	public static final EquipmentTypeCategoryCode WEAPON_TYPE = new EquipmentTypeCategoryCode(
			"WEAPON-TYPE",
			"WEPTYP",
			"An EQUIPMENT-TYPE of any kind used in warfare or combat to attack and overcome an enemy.");

	private EquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
