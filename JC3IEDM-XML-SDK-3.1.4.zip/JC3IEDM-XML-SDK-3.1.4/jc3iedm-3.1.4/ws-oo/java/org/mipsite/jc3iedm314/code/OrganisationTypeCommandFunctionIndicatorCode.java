/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationTypeCommandFunctionIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether an ORGANISATION-TYPE has a command function.";
	}

	private static HashMap<String, OrganisationTypeCommandFunctionIndicatorCode> physicalToCode = new HashMap<String, OrganisationTypeCommandFunctionIndicatorCode>();

	public static OrganisationTypeCommandFunctionIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationTypeCommandFunctionIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationTypeCommandFunctionIndicatorCode NO = new OrganisationTypeCommandFunctionIndicatorCode(
			"No",
			"NO",
			"The ORGANISATION-TYPE does not have a command function.");
	public static final OrganisationTypeCommandFunctionIndicatorCode YES = new OrganisationTypeCommandFunctionIndicatorCode(
			"Yes",
			"YES",
			"The ORGANISATION-TYPE does have a command function.");

	private OrganisationTypeCommandFunctionIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
