/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusCommandAndControlRoleCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the role played by a command and control ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusCommandAndControlRoleCode> physicalToCode = new HashMap<String, OrganisationStatusCommandAndControlRoleCode>();

	public static OrganisationStatusCommandAndControlRoleCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusCommandAndControlRoleCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusCommandAndControlRoleCode ADVANCED_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Advanced command post",
			"ADVNCP",
			"The advanced command post of a unit/formation.");
	public static final OrganisationStatusCommandAndControlRoleCode FORWARD_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Forward headquarters",
			"FRWDHQ",
			"The organisation performs the functions of a forward headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode LOGISTIC_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Logistic command post",
			"LOGCP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1284/2.");
	public static final OrganisationStatusCommandAndControlRoleCode LEAPFROG_ELEMENT = new OrganisationStatusCommandAndControlRoleCode(
			"Leapfrog element",
			"LPFRGE",
			"The organisation performs the functions of a leapfrog element.");
	public static final OrganisationStatusCommandAndControlRoleCode MAIN_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Main command post",
			"MAINCP",
			"A command post that includes those staff activities involved in controlling and sustaining current operations and in planning future operations.");
	public static final OrganisationStatusCommandAndControlRoleCode MOBILE_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Mobile command post",
			"MOBLCP",
			"The mobile command post of a unit/formation.");
	public static final OrganisationStatusCommandAndControlRoleCode MOBILE_WAR_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Mobile war headquarters",
			"MOBLHQ",
			"The organisation performs the functions of a mobile war headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode NATIONAL_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"National headquarters",
			"NATLHQ",
			"The organisation performs the functions of a national headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode NOT_KNOWN = new OrganisationStatusCommandAndControlRoleCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusCommandAndControlRoleCode PEACETIME_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Peacetime command post",
			"PEACCP",
			"The peacetime command post of a unit/formation.");
	public static final OrganisationStatusCommandAndControlRoleCode PEACE_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Peace headquarters",
			"PEACHQ",
			"The organisation performs the functions of a peace headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode PRIMARY_WAR_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Primary war headquarters",
			"PRWRHQ",
			"The organisation performs the functions of a primary war headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode REAR_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Rear command post",
			"REARCP",
			"Those staff activities concerned primarily with combat service support of the force, administrative support of the headquarters and other activities not immediately concerned with current operations.");
	public static final OrganisationStatusCommandAndControlRoleCode RESERVE_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Reserve command post",
			"RESVCP",
			"A command post that is only activated when required.");
	public static final OrganisationStatusCommandAndControlRoleCode STATIC_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Static command post",
			"STATCP",
			"The static command post of a unit/formation.");
	public static final OrganisationStatusCommandAndControlRoleCode STATIC_WAR_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Static war headquarters",
			"STATHQ",
			"The organisation performs the functions of a static war headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode STEP_UP_ALTERNATE_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Step up/alternate command post",
			"STUPCP",
			"Any location designated by a commander to assume command post functions in the event the main or rear command post becomes inoperative.");
	public static final OrganisationStatusCommandAndControlRoleCode STEP_UP_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Step up headquarters",
			"STUPHQ",
			"The organisation performs the functions of a step up headquarters.");
	public static final OrganisationStatusCommandAndControlRoleCode TACTICAL_COMMAND_POST = new OrganisationStatusCommandAndControlRoleCode(
			"Tactical command post",
			"TACTCP",
			"A small, mobile headquarters capable of serving the requirements of the commander (but usually not the staff) for short periods.");
	public static final OrganisationStatusCommandAndControlRoleCode TACTICAL_HEADQUARTERS = new OrganisationStatusCommandAndControlRoleCode(
			"Tactical headquarters",
			"TACTHQ",
			"The organisation performs the functions of a tactical headquarters.");

	private OrganisationStatusCommandAndControlRoleCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
