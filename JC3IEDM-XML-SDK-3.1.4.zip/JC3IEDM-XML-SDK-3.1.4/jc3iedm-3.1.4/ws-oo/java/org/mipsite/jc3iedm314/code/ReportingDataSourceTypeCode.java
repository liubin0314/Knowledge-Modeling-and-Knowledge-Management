/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataSourceTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies the source type from which intelligence information is obtained and which is referred to by a specific REPORTING-DATA.";
	}

	private static HashMap<String, ReportingDataSourceTypeCode> physicalToCode = new HashMap<String, ReportingDataSourceTypeCode>();

	public static ReportingDataSourceTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataSourceTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataSourceTypeCode AIRBORNE_INFRARED = new ReportingDataSourceTypeCode(
			"Airborne infrared",
			"AIRIFR",
			"The intelligence information is derived from airborne infrared systems.");
	public static final ReportingDataSourceTypeCode AIR_RECONNAISSANCE = new ReportingDataSourceTypeCode(
			"Air reconnaissance",
			"AIRREC",
			"The intelligence information is gathered either by visual observation from the air or through the use of airborne sensors.");
	public static final ReportingDataSourceTypeCode AIR_OBSERVER = new ReportingDataSourceTypeCode(
			"Air observer",
			"AOBSR",
			"The intelligence information is derived from an individual whose primary mission is to observe or take photographs from an aircraft.");
	public static final ReportingDataSourceTypeCode ARTILLERY_OBSERVATION = new ReportingDataSourceTypeCode(
			"Artillery observation",
			"ARTOBS",
			"The intelligence information is derived from artillery unit surveillance.");
	public static final ReportingDataSourceTypeCode CAPTURED_DOCUMENT = new ReportingDataSourceTypeCode(
			"Captured document",
			"CAPDOC",
			"The intelligence information is derived from documentation seized from the enemy.");
	public static final ReportingDataSourceTypeCode CAPTURED_MATERIAL = new ReportingDataSourceTypeCode(
			"Captured material",
			"CAPMAT",
			"The intelligence information is derived from equipment or supplies seized from the enemy.");
	public static final ReportingDataSourceTypeCode RADAR_COUNTER_BATTERY = new ReportingDataSourceTypeCode(
			"Radar, counter battery",
			"CBRR",
			"The intelligence information is derived from counter battery radar systems.");
	public static final ReportingDataSourceTypeCode RADAR_COUNTER_MORTAR = new ReportingDataSourceTypeCode(
			"Radar, counter mortar",
			"CMRR",
			"The intelligence information is derived from counter mortar radar systems.");
	public static final ReportingDataSourceTypeCode COMMUNICATIONS_INTELLIGENCE = new ReportingDataSourceTypeCode(
			"Communications intelligence",
			"COMINT",
			"The intelligence information is derived from electromagnetic communications and communications systems by other than intended recipients or users.");
	public static final ReportingDataSourceTypeCode CONTACT = new ReportingDataSourceTypeCode(
			"Contact",
			"CONTAC",
			"The discrete airborne, surface or subsurface intelligence information is collected from electronic, acoustic, and/or visual sensors.");
	public static final ReportingDataSourceTypeCode DEFECTOR = new ReportingDataSourceTypeCode(
			"Defector",
			"DEFECT",
			"The intelligence information is collected from a person who repudiates his or her country when beyond its jurisdiction or control.");
	public static final ReportingDataSourceTypeCode ELECTRONIC_INTELLIGENCE = new ReportingDataSourceTypeCode(
			"Electronic intelligence",
			"ELINT",
			"The intelligence information is derived from electromagnetic non-communications transmissions by other than intended recipients or users.");
	public static final ReportingDataSourceTypeCode EYEBALL_OBSERVATION = new ReportingDataSourceTypeCode(
			"Eyeball observation",
			"EYOBSN",
			"The intelligence information is derived from a human observation without any device.");
	public static final ReportingDataSourceTypeCode FLASH_RANGING = new ReportingDataSourceTypeCode(
			"Flash ranging",
			"FLRNG",
			"The intelligence information is derived from flash ranging devices.");
	public static final ReportingDataSourceTypeCode FORWARD_OBSERVER = new ReportingDataSourceTypeCode(
			"Forward observer",
			"FO",
			"The intelligence information is derived from an observer with forward troops trained to call for and adjust supporting fire and pass battlefield information.");
	public static final ReportingDataSourceTypeCode FORWARD_OBSERVER_WITHOUT_LASER = new ReportingDataSourceTypeCode(
			"Forward observer without laser",
			"FOWOL",
			"The intelligence information is derived from an observer with forward troops without laser systems.");
	public static final ReportingDataSourceTypeCode GROUND_RECONNAISSANCE = new ReportingDataSourceTypeCode(
			"Ground reconnaissance",
			"GRDREC",
			"The intelligence information is derived from ground reconnaissance tasks.");
	public static final ReportingDataSourceTypeCode RADAR_GROUND_SURVEILLANCE = new ReportingDataSourceTypeCode(
			"Radar, ground surveillance",
			"GSRA",
			"The intelligence information is derived from ground surveillance radar systems.");
	public static final ReportingDataSourceTypeCode HUMAN_INTELLIGENCE = new ReportingDataSourceTypeCode(
			"Human intelligence",
			"HUMINT",
			"The intelligence information is collected and provided by human sources.");
	public static final ReportingDataSourceTypeCode INFLIGHT = new ReportingDataSourceTypeCode(
			"Inflight",
			"INFLIT",
			"The intelligence information is reported as mission results by aircrews while in flight.");
	public static final ReportingDataSourceTypeCode LONG_RANGE_RECONNAISSANCE_PATROL = new ReportingDataSourceTypeCode(
			"Long range reconnaissance patrol",
			"LRRP",
			"The intelligence information is derived from ground reconnaissance behind the FLOT.");
	public static final ReportingDataSourceTypeCode OBSERVER_NOT_ARTILLERY = new ReportingDataSourceTypeCode(
			"Observer, not artillery",
			"OBSR",
			"The intelligence information is derived from non-artillery observation.");
	public static final ReportingDataSourceTypeCode PHOTO_INTERPRETATION = new ReportingDataSourceTypeCode(
			"Photo interpretation",
			"PI",
			"The intelligence information is derived from extraction from photographs or other recorded images.");
	public static final ReportingDataSourceTypeCode PRISONER_OF_WAR = new ReportingDataSourceTypeCode(
			"Prisoner of war",
			"POW",
			"The intelligence information is derived from captured forces.");
	public static final ReportingDataSourceTypeCode REFUGEE = new ReportingDataSourceTypeCode(
			"Refugee",
			"REFUGE",
			"The intelligence information is derived from persons who, owing to religious persecution or political troubles, move within their own country (national refugees) or across international boundaries.");
	public static final ReportingDataSourceTypeCode REMOTELY_PILOTED_VEHICLE = new ReportingDataSourceTypeCode(
			"Remotely-piloted vehicle",
			"RPV",
			"The intelligence information is derived from an unmanned vehicle capable of being controlled from a distant location through a communication link.");
	public static final ReportingDataSourceTypeCode SATELLITE = new ReportingDataSourceTypeCode(
			"Satellite",
			"SAT",
			"The intelligence information is derived from satellite surveillance or reconnaissance.");
	public static final ReportingDataSourceTypeCode SIGNAL_INTELLIGENCE = new ReportingDataSourceTypeCode(
			"Signal intelligence",
			"SIGINT",
			"The intelligence information is collected either by communications intelligence or electronic intelligence when there is no requirement to differentiate between these two types of intelligence, or represents a fusion of information from the two.");
	public static final ReportingDataSourceTypeCode RADAR_SIDE_LOOKING = new ReportingDataSourceTypeCode(
			"Radar, side looking",
			"SLAR",
			"The intelligence information is derived from an airborne radar, viewing at right angles to the axis of the vehicle, which produces a presentation of terrain or moving targets.");
	public static final ReportingDataSourceTypeCode SOUND_RANGING = new ReportingDataSourceTypeCode(
			"Sound ranging",
			"SORNG",
			"The intelligence information is derived from sound ranging devices.");
	public static final ReportingDataSourceTypeCode TACTICAL_AIR = new ReportingDataSourceTypeCode(
			"Tactical air",
			"TACAIR",
			"The intelligence information is derived from tactical air operations.");
	public static final ReportingDataSourceTypeCode TARGET_BASE = new ReportingDataSourceTypeCode(
			"Target base",
			"TGTB",
			"The intelligence information is derived from target bases.");
	public static final ReportingDataSourceTypeCode UNATTENDED_GROUND_SENSOR = new ReportingDataSourceTypeCode(
			"Unattended ground sensor",
			"UGS",
			"The intelligence information is derived from an unmanned ground sensor device.");
	public static final ReportingDataSourceTypeCode UNSPECIFIED_SENSITIVE_SOURCE = new ReportingDataSourceTypeCode(
			"Unspecified sensitive source",
			"UNSPEC",
			"The source of the intelligence information is not specified.");
	public static final ReportingDataSourceTypeCode VARIOUS_SOURCES = new ReportingDataSourceTypeCode(
			"Various sources",
			"VARI",
			"The intelligence information is derived from different sources.");

	private ReportingDataSourceTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
