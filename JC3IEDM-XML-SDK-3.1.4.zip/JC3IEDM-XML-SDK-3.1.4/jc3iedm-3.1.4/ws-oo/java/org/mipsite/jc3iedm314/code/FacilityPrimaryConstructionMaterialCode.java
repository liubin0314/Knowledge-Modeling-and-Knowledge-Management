/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityPrimaryConstructionMaterialCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the major material used in building the specific FACILITY.";
	}

	private static HashMap<String, FacilityPrimaryConstructionMaterialCode> physicalToCode = new HashMap<String, FacilityPrimaryConstructionMaterialCode>();

	public static FacilityPrimaryConstructionMaterialCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityPrimaryConstructionMaterialCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityPrimaryConstructionMaterialCode ASPHALT = new FacilityPrimaryConstructionMaterialCode(
			"Asphalt",
			"ASPHLT",
			"The primary construction material used in the FACILITY is asphalt.");
	public static final FacilityPrimaryConstructionMaterialCode BITUMEN = new FacilityPrimaryConstructionMaterialCode(
			"Bitumen",
			"BIT",
			"The primary construction material used in the FACILITY is bituminous (tar or asphalt mixed in place, oiled).");
	public static final FacilityPrimaryConstructionMaterialCode BRICK_MASONRY = new FacilityPrimaryConstructionMaterialCode(
			"Brick/Masonry",
			"BRKMSN",
			"The primary construction material used in the FACILITY is brick/masonry.");
	public static final FacilityPrimaryConstructionMaterialCode COBBLESTONE = new FacilityPrimaryConstructionMaterialCode(
			"Cobblestone",
			"CBLSTN",
			"The primary construction material used in the FACILITY is cobblestone.");
	public static final FacilityPrimaryConstructionMaterialCode CLAY = new FacilityPrimaryConstructionMaterialCode(
			"Clay",
			"CLA",
			"The primary construction material used in the FACILITY is clay.");
	public static final FacilityPrimaryConstructionMaterialCode CONCRETE_BLOCKS = new FacilityPrimaryConstructionMaterialCode(
			"Concrete blocks",
			"CNCRBL",
			"Pre-constructed pieces from a composition of gravel, sand, cement, and water, used for building.");
	public static final FacilityPrimaryConstructionMaterialCode CONCRETE = new FacilityPrimaryConstructionMaterialCode(
			"Concrete",
			"CNCRTE",
			"The primary construction material used in the FACILITY is concrete.");
	public static final FacilityPrimaryConstructionMaterialCode COMPOSITE_SOFT = new FacilityPrimaryConstructionMaterialCode(
			"Composite, soft",
			"COM",
			"The construction material used in the FACILITY is composite, where less than 50 percent of the FACILITY surface length is made up of permanent (hard) surface material.");
	public static final FacilityPrimaryConstructionMaterialCode COMPOSITE_PERMANENT = new FacilityPrimaryConstructionMaterialCode(
			"Composite, permanent",
			"COP",
			"The construction material used in the FACILITY is composite, where 50 percent or more of the FACILITY surface length is made up of permanent (hard) surface material.");
	public static final FacilityPrimaryConstructionMaterialCode CORAL = new FacilityPrimaryConstructionMaterialCode(
			"Coral",
			"COR",
			"The primary construction material used in the FACILITY is coral.");
	public static final FacilityPrimaryConstructionMaterialCode EARTH = new FacilityPrimaryConstructionMaterialCode(
			"Earth",
			"EARTH",
			"The primary construction material used in the FACILITY is earth.");
	public static final FacilityPrimaryConstructionMaterialCode GRAVEL = new FacilityPrimaryConstructionMaterialCode(
			"Gravel",
			"GRAVEL",
			"The primary construction material used in the FACILITY is gravel.");
	public static final FacilityPrimaryConstructionMaterialCode ICE = new FacilityPrimaryConstructionMaterialCode(
			"Ice",
			"ICE",
			"The primary construction material used in the FACILITY is ice.");
	public static final FacilityPrimaryConstructionMaterialCode LATERITE = new FacilityPrimaryConstructionMaterialCode(
			"Laterite",
			"LAT",
			"The primary construction material used in the FACILITY is laterite.");
	public static final FacilityPrimaryConstructionMaterialCode MACADAM = new FacilityPrimaryConstructionMaterialCode(
			"Macadam",
			"MACDAM",
			"Material especially for road making with successive layers of compacted broken stone.");
	public static final FacilityPrimaryConstructionMaterialCode MEMBRANE = new FacilityPrimaryConstructionMaterialCode(
			"Membrane",
			"MEM",
			"The primary construction material used in the FACILITY is membrane (plastic or other coated fibre material).");
	public static final FacilityPrimaryConstructionMaterialCode METAL = new FacilityPrimaryConstructionMaterialCode(
			"Metal",
			"METAL",
			"The primary construction material used in the FACILITY is metal.");
	public static final FacilityPrimaryConstructionMaterialCode MIX = new FacilityPrimaryConstructionMaterialCode(
			"Mix",
			"MIX",
			"The primary construction material used in the FACILITY is mixed in place using non-bituminous binders such as portland cement.");
	public static final FacilityPrimaryConstructionMaterialCode NOT_KNOWN = new FacilityPrimaryConstructionMaterialCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FacilityPrimaryConstructionMaterialCode NOT_OTHERWISE_SPECIFIED = new FacilityPrimaryConstructionMaterialCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final FacilityPrimaryConstructionMaterialCode PEBBLE = new FacilityPrimaryConstructionMaterialCode(
			"Pebble",
			"PEBBLE",
			"The primary construction material used in the FACILITY is pebble.");
	public static final FacilityPrimaryConstructionMaterialCode PERMANENT_SURFACE_MIX = new FacilityPrimaryConstructionMaterialCode(
			"Permanent surface mix",
			"PEM",
			"The primary construction material used in the FACILITY is for hard (permanent) surfaces, made up of part concrete, part asphalt, or part bitumen-bound macadam.");
	public static final FacilityPrimaryConstructionMaterialCode PERMANENT_SURFACE = new FacilityPrimaryConstructionMaterialCode(
			"Permanent surface",
			"PER",
			"The primary construction material used in the FACILITY is for hard (permanent) surfaces, but the type is unknown.");
	public static final FacilityPrimaryConstructionMaterialCode PRE_STRESSED_CONCRETE = new FacilityPrimaryConstructionMaterialCode(
			"Pre-stressed concrete",
			"PRSTCN",
			"The primary construction material used in the FACILITY is pre-stressed concrete.");
	public static final FacilityPrimaryConstructionMaterialCode PIERCED_STEEL = new FacilityPrimaryConstructionMaterialCode(
			"Pierced steel",
			"PSTEEL",
			"The primary construction materiel used in the FACILITY is pierced steel.");
	public static final FacilityPrimaryConstructionMaterialCode REINFORCED_CONCRETE = new FacilityPrimaryConstructionMaterialCode(
			"Reinforced concrete",
			"REINCN",
			"The primary construction material used in the FACILITY is reinforced concrete.");
	public static final FacilityPrimaryConstructionMaterialCode ROLLED_EARTH = new FacilityPrimaryConstructionMaterialCode(
			"Rolled earth",
			"RLDERT",
			"The primary construction materiel used in the FACILITY is rolled earth.");
	public static final FacilityPrimaryConstructionMaterialCode ROCK = new FacilityPrimaryConstructionMaterialCode(
			"Rock",
			"ROCK",
			"The primary construction material used in the FACILITY is rock.");
	public static final FacilityPrimaryConstructionMaterialCode SAND = new FacilityPrimaryConstructionMaterialCode(
			"Sand",
			"SAND",
			"The primary construction material used in the FACILITY is sand.");
	public static final FacilityPrimaryConstructionMaterialCode SILT = new FacilityPrimaryConstructionMaterialCode(
			"Silt",
			"SILT",
			"The primary construction material used in the FACILITY is silt.");
	public static final FacilityPrimaryConstructionMaterialCode SNOW = new FacilityPrimaryConstructionMaterialCode(
			"Snow",
			"SNOW",
			"The primary construction material used in the FACILITY is snow.");
	public static final FacilityPrimaryConstructionMaterialCode STEEL_MAT = new FacilityPrimaryConstructionMaterialCode(
			"Steel mat",
			"STELMT",
			"The primary construction materiel used in the FACILITY is steel mat.");
	public static final FacilityPrimaryConstructionMaterialCode WOOD_TIMBER = new FacilityPrimaryConstructionMaterialCode(
			"Wood/timber",
			"WOOD",
			"The primary construction material used in the FACILITY is wood/timber.");

	private FacilityPrimaryConstructionMaterialCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
