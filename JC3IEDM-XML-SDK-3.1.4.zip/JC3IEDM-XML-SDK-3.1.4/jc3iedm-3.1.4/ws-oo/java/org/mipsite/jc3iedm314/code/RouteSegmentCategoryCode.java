/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RouteSegmentCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ROUTE-SEGMENT.";
	}

	private static HashMap<String, RouteSegmentCategoryCode> physicalToCode = new HashMap<String, RouteSegmentCategoryCode>();

	public static RouteSegmentCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RouteSegmentCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RouteSegmentCategoryCode AIR_ROUTE_SEGMENT = new RouteSegmentCategoryCode(
			"AIR-ROUTE-SEGMENT",
			"AIRRTE",
			"A portion of a route to be flown usually without an intermediate stop, as defined by two consecutive significant points.");
	public static final RouteSegmentCategoryCode NOT_OTHERWISE_SPECIFIED = new RouteSegmentCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private RouteSegmentCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
