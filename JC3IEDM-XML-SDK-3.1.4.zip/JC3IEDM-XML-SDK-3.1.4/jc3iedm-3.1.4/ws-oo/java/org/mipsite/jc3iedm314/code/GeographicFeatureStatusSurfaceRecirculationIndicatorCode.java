/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureStatusSurfaceRecirculationIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether the surface will recirculate as a result of rotor downwash.";
	}

	private static HashMap<String, GeographicFeatureStatusSurfaceRecirculationIndicatorCode> physicalToCode = new HashMap<String, GeographicFeatureStatusSurfaceRecirculationIndicatorCode>();

	public static GeographicFeatureStatusSurfaceRecirculationIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureStatusSurfaceRecirculationIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureStatusSurfaceRecirculationIndicatorCode NO = new GeographicFeatureStatusSurfaceRecirculationIndicatorCode(
			"No",
			"NO",
			"The specific GEOGRAPHIC-FEATURE will not recirculate as a result of rotor downwash.");
	public static final GeographicFeatureStatusSurfaceRecirculationIndicatorCode YES = new GeographicFeatureStatusSurfaceRecirculationIndicatorCode(
			"Yes",
			"YES",
			"The specific GEOGRAPHIC-FEATURE will recirculate as a result of rotor downwash.");

	private GeographicFeatureStatusSurfaceRecirculationIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
