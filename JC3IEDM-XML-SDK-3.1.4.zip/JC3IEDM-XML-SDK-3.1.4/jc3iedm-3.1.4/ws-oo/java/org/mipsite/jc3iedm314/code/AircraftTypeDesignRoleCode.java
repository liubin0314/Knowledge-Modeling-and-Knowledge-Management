/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeDesignRoleCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the designed role of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeDesignRoleCode> physicalToCode = new HashMap<String, AircraftTypeDesignRoleCode>();

	public static AircraftTypeDesignRoleCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeDesignRoleCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeDesignRoleCode DEFENSIVE = new AircraftTypeDesignRoleCode(
			"Defensive",
			"DEF",
			"The major role of this aircraft is defensive.");
	public static final AircraftTypeDesignRoleCode MULTI_ROLE = new AircraftTypeDesignRoleCode(
			"Multi role",
			"MULTI",
			"An aircraft capable of carrying out more than one role.");
	public static final AircraftTypeDesignRoleCode NOT_KNOWN = new AircraftTypeDesignRoleCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeDesignRoleCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeDesignRoleCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AircraftTypeDesignRoleCode OFFENSIVE = new AircraftTypeDesignRoleCode(
			"Offensive",
			"OFF",
			"The major role of this aircraft is offensive.");
	public static final AircraftTypeDesignRoleCode SUPPORT = new AircraftTypeDesignRoleCode(
			"Support",
			"SUPPRT",
			"The major role of this aircraft is support.");

	private AircraftTypeDesignRoleCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
