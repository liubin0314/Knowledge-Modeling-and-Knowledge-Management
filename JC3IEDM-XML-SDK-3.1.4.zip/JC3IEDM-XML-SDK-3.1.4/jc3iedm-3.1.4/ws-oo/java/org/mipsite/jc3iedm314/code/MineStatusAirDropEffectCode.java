/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MineStatusAirDropEffectCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represent the behaviour of air-delivered mine after weapon release.";
	}

	private static HashMap<String, MineStatusAirDropEffectCode> physicalToCode = new HashMap<String, MineStatusAirDropEffectCode>();

	public static MineStatusAirDropEffectCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MineStatusAirDropEffectCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MineStatusAirDropEffectCode ARM_MALFUNCTION = new MineStatusAirDropEffectCode(
			"Arm malfunction",
			"ARMMAL",
			"Arming wires not retained.");
	public static final MineStatusAirDropEffectCode ARM_MALFUNCTION_BROKE_UP = new MineStatusAirDropEffectCode(
			"Arm malfunction, broke up",
			"ARMMBU",
			"Arming wires not retained, case broke up on impact.");
	public static final MineStatusAirDropEffectCode ARM_MALFUNCTION_SKIP = new MineStatusAirDropEffectCode(
			"Arm malfunction, skip",
			"ARMMS",
			"Arming wires not retained, case skipped on impact.");
	public static final MineStatusAirDropEffectCode ARM_MALFUNCTION_SKIP_BROKE_UP = new MineStatusAirDropEffectCode(
			"Arm malfunction, skip, broke up",
			"ARMMSB",
			"Arming wires not retained, case skipped and broke up on impact.");
	public static final MineStatusAirDropEffectCode NORMAL = new MineStatusAirDropEffectCode(
			"Normal",
			"NORMAL",
			"Parachute drop and weapon impact where normal.");
	public static final MineStatusAirDropEffectCode PARACHUTE_ARM_MALFUNCTION = new MineStatusAirDropEffectCode(
			"Parachute arm malfunction",
			"PARAM",
			"Parachute failed to fully open, arming wires not retained.");
	public static final MineStatusAirDropEffectCode PARACHUTE_AND_ARM_MALFUNCTION_SKIP_BROKE_UP = new MineStatusAirDropEffectCode(
			"Parachute and arm malfunction, skip, broke up",
			"PARAMB",
			"Parachute failed to fully open, arming wires not retained, and case skipped and broke up on impact.");
	public static final MineStatusAirDropEffectCode PARACHUTE_AND_ARM_MALFUNCTION_SKIP = new MineStatusAirDropEffectCode(
			"Parachute and arm malfunction, skip",
			"PARAMS",
			"Parachute failed to fully open, arming wires not retained, and case skipped on impact.");
	public static final MineStatusAirDropEffectCode PARACHUTE_MALFUNCTION = new MineStatusAirDropEffectCode(
			"Parachute malfunction",
			"PARMAL",
			"Parachute failed to fully open.");
	public static final MineStatusAirDropEffectCode PARACHUTE_MALFUNCTION_BROKE_UP = new MineStatusAirDropEffectCode(
			"Parachute malfunction, broke up",
			"PARMBU",
			"Parachute failed to fully open, case broke up on impact.");
	public static final MineStatusAirDropEffectCode PARACHUTE_MALFUNCTION_SKIP = new MineStatusAirDropEffectCode(
			"Parachute malfunction, skip",
			"PARMS",
			"Parachute failed to fully open, case skipped on impact.");
	public static final MineStatusAirDropEffectCode SKIP = new MineStatusAirDropEffectCode(
			"Skip",
			"SKIP",
			"Case skipped on impact.");
	public static final MineStatusAirDropEffectCode SKIP_BROKE_UP = new MineStatusAirDropEffectCode(
			"Skip, broke up",
			"SKIPBU",
			"Case skipped and broke up on impact.");
	public static final MineStatusAirDropEffectCode UNKNOWN = new MineStatusAirDropEffectCode(
			"Unknown",
			"UNK",
			"The type of malfunction is unknown.");

	private MineStatusAirDropEffectCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
