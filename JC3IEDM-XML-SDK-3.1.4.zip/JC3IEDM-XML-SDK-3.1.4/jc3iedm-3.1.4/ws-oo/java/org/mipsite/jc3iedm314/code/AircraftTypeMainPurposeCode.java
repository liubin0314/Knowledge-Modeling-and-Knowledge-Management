/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeMainPurposeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the main purpose of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeMainPurposeCode> physicalToCode = new HashMap<String, AircraftTypeMainPurposeCode>();

	public static AircraftTypeMainPurposeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeMainPurposeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeMainPurposeCode AIR_TO_AIR_REFUELLING = new AircraftTypeMainPurposeCode(
			"Air to air refuelling",
			"AAR",
			"An aircraft in which the objective is to enhance combat effectiveness by extending the range, payload or endurance of receiver aircraft.");
	public static final AircraftTypeMainPurposeCode AIRBORNE_COMMAND_POST_C2 = new AircraftTypeMainPurposeCode(
			"Airborne command post (C2)",
			"ACP",
			"An aircraft that is the airborne element in which the unit or sub-unit commander is located or from which he operates.");
	public static final AircraftTypeMainPurposeCode AIRBORNE_EARLY_WARNING = new AircraftTypeMainPurposeCode(
			"Airborne early warning",
			"AEW",
			"An aircraft equipped with search and height finding radars and communications equipment designed to provide air surveillance.");
	public static final AircraftTypeMainPurposeCode AIRBORNE_EARLY_WARNING_AND_CONTROL = new AircraftTypeMainPurposeCode(
			"Airborne early warning and control",
			"AEWCON",
			"An aircraft equipped with search and height finding radars and communications equipment designed to provide air surveillance and to control airborne weapons systems.");
	public static final AircraftTypeMainPurposeCode AIR_DEFENSE = new AircraftTypeMainPurposeCode(
			"Air defense",
			"AIRDEF",
			"An aircraft that protects and defends an area, and/or a strike attack, and/or an installation, and/or naval forces.");
	public static final AircraftTypeMainPurposeCode AIR_SUPERIORITY = new AircraftTypeMainPurposeCode(
			"Air superiority",
			"AIRSUP",
			"An aircraft that is deemed to obtain a degree of dominance in the air battle of one force over another in order to permit the conduct of operations by the former and its related land, sea and air forces at a given time and place without prohibitive interference by the opposite force.");
	public static final AircraftTypeMainPurposeCode ANTI_ARMOUR = new AircraftTypeMainPurposeCode(
			"Anti-armour",
			"ANTARM",
			"An aircraft designed and primarily armed for use in the destruction of armoured targets.");
	public static final AircraftTypeMainPurposeCode AIRBORNE_RELAY = new AircraftTypeMainPurposeCode(
			"Airborne relay",
			"ARELAY",
			"An aircraft that employs a technique with radio relay for the purpose of increasing the range, flexibility or physical security of communication systems.");
	public static final AircraftTypeMainPurposeCode ARMED_ASSAULT = new AircraftTypeMainPurposeCode(
			"Armed assault",
			"ARMAS",
			"An aircraft that enables a short, violent, but well ordered attack against a local objective such as a gun emplacement, a fort or a machine-gun nest.");
	public static final AircraftTypeMainPurposeCode ANTI_SUBMARINE_WARFARE_CARRIER_BASED = new AircraftTypeMainPurposeCode(
			"Anti-submarine warfare (carrier based)",
			"ASCB",
			"An aircraft based on an aircraft carrier conducting operations with the intention of denying the enemy the effective use of submarines.");
	public static final AircraftTypeMainPurposeCode ANTI_SUBMARINE_WARFARE_MPA = new AircraftTypeMainPurposeCode(
			"Anti-submarine warfare (MPA)",
			"ASMPA",
			"A maritime patrol aircraft conducting operations with the intention of denying the enemy the effective use of submarines.");
	public static final AircraftTypeMainPurposeCode ANTI_SUBMARINE_WARFARE = new AircraftTypeMainPurposeCode(
			"Anti-submarine warfare",
			"ASUW",
			"An aircraft employed in air operation conducted with the intention of denying the enemy the effective use of submarines.");
	public static final AircraftTypeMainPurposeCode ANTI_SURFACE_MPA = new AircraftTypeMainPurposeCode(
			"Anti-surface (MPA)",
			"ASW",
			"A maritime patrol aircraft conducting operations with the intention of denying the enemy the effective use of surface forces.");
	public static final AircraftTypeMainPurposeCode ATTACK_STRIKE = new AircraftTypeMainPurposeCode(
			"Attack/strike",
			"ATKSTR",
			"An aircraft specifically designed to employ various weapons within a strike to attack and destroy enemy targets.");
	public static final AircraftTypeMainPurposeCode ATTACK = new AircraftTypeMainPurposeCode(
			"Attack",
			"ATTACK",
			"An aircraft specifically designed to employ various weapons to attack and destroy enemy targets.");
	public static final AircraftTypeMainPurposeCode CARGO_AIRLIFT = new AircraftTypeMainPurposeCode(
			"Cargo airlift",
			"CARGO",
			"An aircraft used for the transport of cargo.");
	public static final AircraftTypeMainPurposeCode COMMAND_AND_CONTROL = new AircraftTypeMainPurposeCode(
			"Command and control",
			"CMDCTL",
			"An aircraft designed and equipped to allow a commander to exercise authority and direction over assigned and attached forces in the accomplishment of the mission.");
	public static final AircraftTypeMainPurposeCode COMMUNICATIONS_C3I = new AircraftTypeMainPurposeCode(
			"Communications (C3I)",
			"COM",
			"An aircraft equipped with communication means such as data links or radio means for the purpose of consultation, command, control and intelligence.");
	public static final AircraftTypeMainPurposeCode SEARCH_AND_RESCUE_COMBAT = new AircraftTypeMainPurposeCode(
			"Search and rescue (Combat)",
			"CSAR",
			"An aircraft designed and equipped to look for and bring back any lost, incapacitated or captured person or group of persons in a combat area.");
	public static final AircraftTypeMainPurposeCode DRONE_LAUNCH = new AircraftTypeMainPurposeCode(
			"Drone launch",
			"DRONL",
			"An aircraft used for the launch of drones.");
	public static final AircraftTypeMainPurposeCode ELECTRONIC_COUNTER_MEASURES_JAMMER = new AircraftTypeMainPurposeCode(
			"Electronic counter measures (Jammer)",
			"ECMJAM",
			"An aircraft that operates in a division of electronic warfare involving actions taken to prevent or reduce an enemy�s effective use of the electromagnetic spectrum through the use of electromagnetic energy by electronic jamming.");
	public static final AircraftTypeMainPurposeCode ELECTRONIC_COUNTER_MEASURES = new AircraftTypeMainPurposeCode(
			"Electronic counter measures",
			"ELCCNM",
			"An aircraft that operates in a division of electronic warfare involving actions taken to prevent or reduce an enemy�s effective use of the electromagnetic spectrum through the use of electromagnetic energy. There are three subdivisions of electronic countermeasures: electronic jamming, electronic deception and electronic neutralization.");
	public static final AircraftTypeMainPurposeCode ELECTRONIC_WARFARE = new AircraftTypeMainPurposeCode(
			"Electronic warfare",
			"EW",
			"An aircraft designed for military action to exploit the electromagnetic spectrum encompassing: the search for, interception and identification of electromagnetic emissions, the employment of electromagnetic energy, including directed energy, to reduce or prevent hostile use of the electromagnetic spectrum, and actions to ensure its effective use by friendly forces.");
	public static final AircraftTypeMainPurposeCode FIGHTER_BOMBER = new AircraftTypeMainPurposeCode(
			"Fighter-bomber",
			"FIGBOM",
			"An aircraft that combines the functions of a fighter and a bomber.");
	public static final AircraftTypeMainPurposeCode FIGHTER_INTERCEPTOR = new AircraftTypeMainPurposeCode(
			"Fighter-interceptor",
			"FIGINT",
			"An aircraft that combines the functions of a fighter and an interceptor.");
	public static final AircraftTypeMainPurposeCode GROUND_ATTACK = new AircraftTypeMainPurposeCode(
			"Ground attack",
			"GDATK",
			"An aircraft that performs ground attack.");
	public static final AircraftTypeMainPurposeCode GROUND_ATTACK_RECONNAISSANCE = new AircraftTypeMainPurposeCode(
			"Ground attack reconnaissance",
			"GDATKR",
			"An aircraft that performs reconnaissance in order to gather information to prepare for ground attacks.");
	public static final AircraftTypeMainPurposeCode IMAGERY_INTELLIGENCE_GATHERING = new AircraftTypeMainPurposeCode(
			"Imagery intelligence gathering",
			"IMINGT",
			"An aircraft designed and equipped with imaging sensors primarily for the purpose of gathering imagery for intelligence purposes.");
	public static final AircraftTypeMainPurposeCode LIAISON_DUTIES = new AircraftTypeMainPurposeCode(
			"Liaison duties",
			"LIAIS",
			"An aircraft that is devoted to liaise between different locations.");
	public static final AircraftTypeMainPurposeCode MAINTENANCE_OVERHAUL_REPAIR = new AircraftTypeMainPurposeCode(
			"Maintenance overhaul repair",
			"MAINT",
			"An aircraft that is equipped to perform the maintenance, overhaul or repair of other aircraft.");
	public static final AircraftTypeMainPurposeCode MEDICAL_EVACUATION = new AircraftTypeMainPurposeCode(
			"Medical evacuation",
			"MEDEVC",
			"An aircraft designed and equipped to perform medical evacuation and treatment.");
	public static final AircraftTypeMainPurposeCode METEOROLOGICAL = new AircraftTypeMainPurposeCode(
			"Meteorological",
			"METBAL",
			"An aircraft that gathers meteorological information such as humidity, pressure, and temperature characteristics of Earth�s atmosphere.");
	public static final AircraftTypeMainPurposeCode MINE_COUNTERMEASURES = new AircraftTypeMainPurposeCode(
			"Mine countermeasures",
			"MINCM",
			"An aircraft designed and equipped to perform mine countermeasures.");
	public static final AircraftTypeMainPurposeCode MINE_WARFARE = new AircraftTypeMainPurposeCode(
			"Mine warfare",
			"MINWAR",
			"An aircraft designed and equipped to perform mine warfare functions including mine laying and mine countermeasures.");
	public static final AircraftTypeMainPurposeCode MARITIME_PATROL = new AircraftTypeMainPurposeCode(
			"Maritime patrol",
			"MPA",
			"An aircraft that flies over an area monitoring and where necessary destroying hostile aircraft as well as protecting friendly shipping in the vicinity of the objective area in amphibious operations.");
	public static final AircraftTypeMainPurposeCode MARITIME_RECONNAISSANCE = new AircraftTypeMainPurposeCode(
			"Maritime reconnaissance",
			"MPAREC",
			"The role of the aircraft is to obtain, by radar detection and other sensory means information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final AircraftTypeMainPurposeCode MULTI_PURPOSE = new AircraftTypeMainPurposeCode(
			"Multi-purpose",
			"MULTIP",
			"An aircraft that is capable of performing various missions.");
	public static final AircraftTypeMainPurposeCode MULTI_SENSOR = new AircraftTypeMainPurposeCode(
			"Multi-sensor",
			"MULTIS",
			"An aircraft equipped with multi sensors that detect, and may indicate, and/or record objects and activities by means of energy or particles emitted, reflected, or modified by objects.");
	public static final AircraftTypeMainPurposeCode NAVAL = new AircraftTypeMainPurposeCode(
			"Naval",
			"NAV",
			"An aircraft that is capable of performing maritime missions.");
	public static final AircraftTypeMainPurposeCode NAVAL_ATTACK = new AircraftTypeMainPurposeCode(
			"Naval attack",
			"NAVATK",
			"An aircraft that is capable of performing naval attack.");
	public static final AircraftTypeMainPurposeCode NOT_KNOWN = new AircraftTypeMainPurposeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeMainPurposeCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeMainPurposeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AircraftTypeMainPurposeCode PATROL = new AircraftTypeMainPurposeCode(
			"Patrol",
			"PATROL",
			"An aircraft flying over an objective area, over the force projected, over the critical area of a combat zone, or over an air-defense area for the purpose of intercepting and destroying hostile aircraft before they reach their target.");
	public static final AircraftTypeMainPurposeCode PHOTO_MAPPING = new AircraftTypeMainPurposeCode(
			"Photo mapping",
			"PHOTO",
			"An aircraft that produces a photograph or photomosaic upon which the grid lines, marginal data, contours, place names, boundaries, and other data may be added.");
	public static final AircraftTypeMainPurposeCode PASSENGER_AIRLIFT = new AircraftTypeMainPurposeCode(
			"Passenger airlift",
			"PSG",
			"An aircraft used for the transport of passengers.");
	public static final AircraftTypeMainPurposeCode RADIO_RADAR_CALIBRATION = new AircraftTypeMainPurposeCode(
			"Radio/radar calibration",
			"RCALIB",
			"An aircraft that flies a specific route to calibrate radars and radios.");
	public static final AircraftTypeMainPurposeCode RECONNAISSANCE = new AircraftTypeMainPurposeCode(
			"Reconnaissance",
			"RECCE",
			"An aircraft intended to obtain, by visual observation or other detection methods, information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final AircraftTypeMainPurposeCode RECONNAISSANCE_ECM = new AircraftTypeMainPurposeCode(
			"Reconnaissance, ECM",
			"RECECM",
			"An aircraft intended to obtain by detection means information about the ECM activities and resources of an enemy or potential enemy in a particular area.");
	public static final AircraftTypeMainPurposeCode RECONNAISSANCE_PHOTOGRAPHIC = new AircraftTypeMainPurposeCode(
			"Reconnaissance, photographic",
			"RECPHO",
			"An aircraft intended to obtain, by photographic means information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final AircraftTypeMainPurposeCode RECONNAISSANCE_RADAR = new AircraftTypeMainPurposeCode(
			"Reconnaissance, radar",
			"RECRAD",
			"The role of the aircraft is to obtain, by radar detection methods information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final AircraftTypeMainPurposeCode RECONNAISSANCE_VISUAL = new AircraftTypeMainPurposeCode(
			"Reconnaissance, visual",
			"RECVIS",
			"The role of the aircraft is to obtain, visual information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final AircraftTypeMainPurposeCode SEARCH_AND_RESCUE = new AircraftTypeMainPurposeCode(
			"Search and rescue",
			"SAR",
			"An aircraft designed and equipped to look for and bring back any lost, incapacitated or captured person or group of persons.");
	public static final AircraftTypeMainPurposeCode SCOUT = new AircraftTypeMainPurposeCode(
			"Scout",
			"SCOUT",
			"An aircraft collecting intelligence without engaging enemy forces in order to participate in the close in security of a force.");
	public static final AircraftTypeMainPurposeCode SIGNALS_INTELLIGENCE_GATHERING = new AircraftTypeMainPurposeCode(
			"Signals intelligence gathering",
			"SINGA",
			"An aircraft designed and equipped primarily for the purpose of intercepting and gathering electronic and communications transmissions for intelligence purposes.");
	public static final AircraftTypeMainPurposeCode SPECIAL_OPERATIONS_FORCES = new AircraftTypeMainPurposeCode(
			"Special operations forces",
			"SOF",
			"An aircraft used for the transport of members of special operation forces.");
	public static final AircraftTypeMainPurposeCode SPECIAL_PURPOSE = new AircraftTypeMainPurposeCode(
			"Special purpose",
			"SPCPRP",
			"An aircraft designed for a singular purpose.");
	public static final AircraftTypeMainPurposeCode STORAGE = new AircraftTypeMainPurposeCode(
			"Storage",
			"STOR",
			"An aircraft under care and maintenance.");
	public static final AircraftTypeMainPurposeCode TANKER = new AircraftTypeMainPurposeCode(
			"Tanker",
			"TANKER",
			"An aircraft used for carrying fuel in bulk, esp. for the aerial refuelling of other aircraft.");
	public static final AircraftTypeMainPurposeCode TARGET_RELAY_RECONNAISSANCE = new AircraftTypeMainPurposeCode(
			"Target/relay, reconnaissance",
			"TGTREL",
			"An aircraft capable of obtaining information about the activities and resources of a target.");
	public static final AircraftTypeMainPurposeCode TOW_TARGET = new AircraftTypeMainPurposeCode(
			"Tow target",
			"TOWTGT",
			"An aircraft capable of towing a target.");
	public static final AircraftTypeMainPurposeCode UTILITY = new AircraftTypeMainPurposeCode(
			"Utility",
			"UTILTY",
			"Multi-purpose aircraft capable of carrying troops but may be used in a command and control, logistics, casualty evacuation or armed aircraft role.");

	private AircraftTypeMainPurposeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
