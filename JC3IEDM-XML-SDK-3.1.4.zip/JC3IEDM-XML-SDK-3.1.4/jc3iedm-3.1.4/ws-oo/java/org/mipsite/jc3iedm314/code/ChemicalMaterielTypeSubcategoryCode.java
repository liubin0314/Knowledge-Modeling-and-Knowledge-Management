/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ChemicalMaterielTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of a specific CHEMICAL-MATERIEL-TYPE.";
	}

	private static HashMap<String, ChemicalMaterielTypeSubcategoryCode> physicalToCode = new HashMap<String, ChemicalMaterielTypeSubcategoryCode>();

	public static ChemicalMaterielTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ChemicalMaterielTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ChemicalMaterielTypeSubcategoryCode ARSINE = new ChemicalMaterielTypeSubcategoryCode(
			"Arsine",
			"ARSINE",
			"A poisonous gas made by the reaction of some arsenic compounds with acids. [AsH3.]");
	public static final ChemicalMaterielTypeSubcategoryCode CHLOROPICRIN = new ChemicalMaterielTypeSubcategoryCode(
			"Chloropicrin",
			"CHLRPC",
			"A poisonous gas made by the reaction of some chloro compounds with nitrated phenol.");
	public static final ChemicalMaterielTypeSubcategoryCode CYCLO_SARIN = new ChemicalMaterielTypeSubcategoryCode(
			"Cyclo-Sarin",
			"CYCLSR",
			"An organophosphorus nerve gas evolved from Sarin.");
	public static final ChemicalMaterielTypeSubcategoryCode CYANOGEN_CHLORIDE = new ChemicalMaterielTypeSubcategoryCode(
			"Cyanogen chloride",
			"CYNGNC",
			"A colourless flammable highly poisonous gas made by oxidising hydrogen cyanide. (Blood agent)");
	public static final ChemicalMaterielTypeSubcategoryCode DI_PHOSGENE = new ChemicalMaterielTypeSubcategoryCode(
			"Di-phosgene",
			"DIPSGN",
			"A poisonous gas formerly used in warfare derived from phosgene. [COCl2.]");
	public static final ChemicalMaterielTypeSubcategoryCode HYDROGEN_CYANIDE = new ChemicalMaterielTypeSubcategoryCode(
			"Hydrogen cyanide",
			"HDRNCY",
			"A highly poisonous gas or volatile liquid with an odour of bitter almonds, made by the action of acids on cyanides. [HCN.]");
	public static final ChemicalMaterielTypeSubcategoryCode LEWISITE = new ChemicalMaterielTypeSubcategoryCode(
			"Lewisite",
			"LWSITE",
			"A dark oily liquid producing an irritant gas that causes blisters, developed for use in chemical warfare.");
	public static final ChemicalMaterielTypeSubcategoryCode MUSTARD_DISTILLED = new ChemicalMaterielTypeSubcategoryCode(
			"Mustard distilled",
			"MSTRDD",
			"A colourless oily liquid, whose vapour is a powerful irritant and vesicant, used in chemical weapons.");
	public static final ChemicalMaterielTypeSubcategoryCode MUSTARD_LEWISITE = new ChemicalMaterielTypeSubcategoryCode(
			"Mustard-Lewisite",
			"MSTRDL",
			"A mixture of distilled mustard and Lewisite.");
	public static final ChemicalMaterielTypeSubcategoryCode NOT_KNOWN = new ChemicalMaterielTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ChemicalMaterielTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new ChemicalMaterielTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ChemicalMaterielTypeSubcategoryCode NITROGEN_MUSTARD = new ChemicalMaterielTypeSubcategoryCode(
			"Nitrogen mustard",
			"NTRGNM",
			"A nitrated colourless oily liquid, whose vapour is a powerful irritant and vesicant, used in chemical weapons.");
	public static final ChemicalMaterielTypeSubcategoryCode PHOSGENE = new ChemicalMaterielTypeSubcategoryCode(
			"Phosgene",
			"PHOSGN",
			"A poisonous gas formerly used in warfare. [COCl2.]");
	public static final ChemicalMaterielTypeSubcategoryCode PHOSGENE_OXIME = new ChemicalMaterielTypeSubcategoryCode(
			"Phosgene oxime",
			"PHSGNO",
			"A poisonous gas formerly used in warfare derived from phosgene used to block the oxygenation of aemoglobin. [COCl2.] (Blood agent)");
	public static final ChemicalMaterielTypeSubcategoryCode QUINUCLIDINYL_BENZILATE = new ChemicalMaterielTypeSubcategoryCode(
			"Quinuclidinyl benzilate",
			"QNCLDN",
			"A poisonous gas formerly used in warfare.");
	public static final ChemicalMaterielTypeSubcategoryCode SARIN = new ChemicalMaterielTypeSubcategoryCode(
			"Sarin",
			"SARIN",
			"An organophosphorus nerve gas.");
	public static final ChemicalMaterielTypeSubcategoryCode SOMAN = new ChemicalMaterielTypeSubcategoryCode(
			"Soman",
			"SOMAN",
			"A colourless liquid use as a nerve gas. Chemically, is fluoromethylpinacolyloxyphosphine oxide.");
	public static final ChemicalMaterielTypeSubcategoryCode TABUN = new ChemicalMaterielTypeSubcategoryCode(
			"Tabun",
			"TABUN",
			"An organophosphorus nerve gas.");
	public static final ChemicalMaterielTypeSubcategoryCode TEAR_GAS = new ChemicalMaterielTypeSubcategoryCode(
			"Tear gas",
			"TRGAS",
			"A type of chemical compound used in riot control agents.");
	public static final ChemicalMaterielTypeSubcategoryCode TRIMERIC_MUSTARD = new ChemicalMaterielTypeSubcategoryCode(
			"Trimeric mustard",
			"TRMRCM",
			"A thickened colourless oily liquid, whose vapour is a powerful irritant and vesicant, used in chemical weapons.");
	public static final ChemicalMaterielTypeSubcategoryCode VX = new ChemicalMaterielTypeSubcategoryCode(
			"VX",
			"VX",
			"An organophosphorus nerve gas.");

	private ChemicalMaterielTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
