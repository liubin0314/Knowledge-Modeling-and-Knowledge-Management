/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusEnemyActivityConditionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of enemy activity around or at the FACILITY.";
	}

	private static HashMap<String, FacilityStatusEnemyActivityConditionCode> physicalToCode = new HashMap<String, FacilityStatusEnemyActivityConditionCode>();

	public static FacilityStatusEnemyActivityConditionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusEnemyActivityConditionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusEnemyActivityConditionCode COLD = new FacilityStatusEnemyActivityConditionCode(
			"Cold",
			"COLD",
			"No enemy action evident.");
	public static final FacilityStatusEnemyActivityConditionCode HOT = new FacilityStatusEnemyActivityConditionCode(
			"Hot",
			"HOT",
			"Enemy action in proximity.");

	private FacilityStatusEnemyActivityConditionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
