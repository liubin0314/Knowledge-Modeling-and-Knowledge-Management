/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NuclearEventCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of NUCLEAR-EVENT.";
	}

	private static HashMap<String, NuclearEventCategoryCode> physicalToCode = new HashMap<String, NuclearEventCategoryCode>();

	public static NuclearEventCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NuclearEventCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NuclearEventCategoryCode NOT_KNOWN = new NuclearEventCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NuclearEventCategoryCode NUCLEAR_RELEASE_OTHER_THAN_ATTACK_ROTA = new NuclearEventCategoryCode(
			"Nuclear release other than attack (ROTA)",
			"NROTA",
			"The release of nuclear material into the environment intentionally or accidentally but not for the intended purpose of conducting an attack.");
	public static final NuclearEventCategoryCode NUCLEAR_ATTACK = new NuclearEventCategoryCode(
			"Nuclear attack",
			"NUCATT",
			"The delivery of a nuclear weapon against a target.");
	public static final NuclearEventCategoryCode NUCLEAR_SAMPLING = new NuclearEventCategoryCode(
			"Nuclear sampling",
			"NUCSMP",
			"The action of detecting a radiological contaminant.");
	public static final NuclearEventCategoryCode NUCLEAR_TEST = new NuclearEventCategoryCode(
			"Nuclear test",
			"NUCTST",
			"The explosion of a nuclear device for test purpose.");
	public static final NuclearEventCategoryCode NUCLEAR_WAR_ALERT = new NuclearEventCategoryCode(
			"Nuclear war alert",
			"NUCWAR",
			"The state of readiness caused by the possibility of atomic bombings.");
	public static final NuclearEventCategoryCode NUCLEAR_WEAPON_EVENT = new NuclearEventCategoryCode(
			"NUCLEAR-WEAPON-EVENT",
			"NUCWEP",
			"A NUCLEAR-EVENT that involves the detonation of a nuclear device.");
	public static final NuclearEventCategoryCode NUCLEAR_WASTE_DISPOSAL = new NuclearEventCategoryCode(
			"Nuclear waste disposal",
			"NUCWST",
			"Removing nuclear polluted substances to a designated storage area.");

	private NuclearEventCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
