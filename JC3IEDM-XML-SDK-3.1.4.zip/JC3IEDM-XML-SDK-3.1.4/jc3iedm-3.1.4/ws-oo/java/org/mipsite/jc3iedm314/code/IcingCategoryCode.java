/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IcingCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a particular ICING.";
	}

	private static HashMap<String, IcingCategoryCode> physicalToCode = new HashMap<String, IcingCategoryCode>();

	public static IcingCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IcingCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IcingCategoryCode CLEAR_ICING = new IcingCategoryCode(
			"Clear icing",
			"CLRICE",
			"Glossy, clear, or translucent ice formed by the relatively slow freezing of large supercooled droplets. The droplets spread out over the airframe surface before completely freezing.");
	public static final IcingCategoryCode MIXED_ICING = new IcingCategoryCode(
			"Mixed icing",
			"MIXICE",
			"A hard rough conglomerate of ice that can cause very rough accumulation and severe loss of lift.");
	public static final IcingCategoryCode RIME_ICING = new IcingCategoryCode(
			"Rime icing",
			"RIMICE",
			"Rough, milky opaque ice formed by the instantaneous freezing of small supercooled droplets which trap air within the ice as they strike the aircraft.");

	private IcingCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
