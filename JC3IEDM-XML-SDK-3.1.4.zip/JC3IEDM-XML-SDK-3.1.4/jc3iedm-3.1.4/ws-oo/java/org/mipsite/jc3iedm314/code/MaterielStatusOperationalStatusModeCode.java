/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusOperationalStatusModeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the firepower or mobility or communications degradation of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusOperationalStatusModeCode> physicalToCode = new HashMap<String, MaterielStatusOperationalStatusModeCode>();

	public static MaterielStatusOperationalStatusModeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusOperationalStatusModeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusOperationalStatusModeCode COMMUNICATIONS_ONLY = new MaterielStatusOperationalStatusModeCode(
			"Communications only",
			"CO",
			"An indication that the associated degraded operational status only applies to the communications of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode FIREPOWER_AND_COMMUNICATIONS = new MaterielStatusOperationalStatusModeCode(
			"Firepower and communications",
			"FC",
			"An indication that the associated degraded operational status applies to both the firepower and the communications of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode FIREPOWER_MOBILITY_AND_COMMUNICATIONS = new MaterielStatusOperationalStatusModeCode(
			"Firepower, mobility and communications",
			"FMC",
			"An indication that the associated degraded operational status applies to the firepower, the mobility and the communications of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode FIREPOWER_ONLY = new MaterielStatusOperationalStatusModeCode(
			"Firepower only",
			"FO",
			"An indication that the associated degraded operational status only applies to the firepower of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode MOBILITY_AND_COMMUNICATIONS = new MaterielStatusOperationalStatusModeCode(
			"Mobility and communications",
			"MC",
			"An indication that the associated degraded operational status applies to both the mobility and the communications of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode MOBILITY_AND_FIREPOWER = new MaterielStatusOperationalStatusModeCode(
			"Mobility and firepower",
			"MF",
			"An indication that the associated degraded operational status applies to both the mobility and the firepower of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode MOBILITY_ONLY = new MaterielStatusOperationalStatusModeCode(
			"Mobility only",
			"MO",
			"An indication that the associated degraded operational status only applies to the mobility of the specified item of MATERIEL.");
	public static final MaterielStatusOperationalStatusModeCode NOT_KNOWN = new MaterielStatusOperationalStatusModeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private MaterielStatusOperationalStatusModeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
