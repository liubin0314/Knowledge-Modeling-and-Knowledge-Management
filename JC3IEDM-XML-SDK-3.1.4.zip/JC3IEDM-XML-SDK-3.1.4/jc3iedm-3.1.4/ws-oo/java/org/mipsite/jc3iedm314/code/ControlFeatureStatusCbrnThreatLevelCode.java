/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ControlFeatureStatusCbrnThreatLevelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the assessed CBRN threat level status of a specific CONTROL-FEATURE that defines a given operational area for friendly forces.";
	}

	private static HashMap<String, ControlFeatureStatusCbrnThreatLevelCode> physicalToCode = new HashMap<String, ControlFeatureStatusCbrnThreatLevelCode>();

	public static ControlFeatureStatusCbrnThreatLevelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ControlFeatureStatusCbrnThreatLevelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ControlFeatureStatusCbrnThreatLevelCode HIGH = new ControlFeatureStatusCbrnThreatLevelCode(
			"High",
			"HIGH",
			"NBC (CBRN) attack is imminent in immediate area.");
	public static final ControlFeatureStatusCbrnThreatLevelCode LOW = new ControlFeatureStatusCbrnThreatLevelCode(
			"Low",
			"LOW",
			"Enemy has offensive NBC (CBRN) capability but there is no indication of use in immediate future.");
	public static final ControlFeatureStatusCbrnThreatLevelCode MEDIUM = new ControlFeatureStatusCbrnThreatLevelCode(
			"Medium",
			"MEDIUM",
			"NBC (CBRN) weapons have been used in another operation area and/or there are strong indications that enemy will use NBC (CBRN) weapons in immediate future.");

	private ControlFeatureStatusCbrnThreatLevelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
