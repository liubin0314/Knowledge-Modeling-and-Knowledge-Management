/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CbrnEquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CBRN-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, CbrnEquipmentTypeCategoryCode> physicalToCode = new HashMap<String, CbrnEquipmentTypeCategoryCode>();

	public static CbrnEquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CbrnEquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CbrnEquipmentTypeCategoryCode AUTOMATED_CHEMICAL_AND_BIOLOGICAL_AGENT_DETECTOR = new CbrnEquipmentTypeCategoryCode(
			"Automated chemical and biological agent detector",
			"ABICHM",
			"An unattended chemical and biological detection and alarm system.");
	public static final CbrnEquipmentTypeCategoryCode AUTOMATED_BIOLOGICAL_DETECTOR = new CbrnEquipmentTypeCategoryCode(
			"Automated biological detector",
			"ABIDET",
			"An unattended biological detection and alarm system.");
	public static final CbrnEquipmentTypeCategoryCode AUTOMATED_CHEMICAL_DETECTOR = new CbrnEquipmentTypeCategoryCode(
			"Automated chemical detector",
			"ACHDET",
			"An unattended chemical detection and alarm system.");
	public static final CbrnEquipmentTypeCategoryCode AUTOMATED_RADIATION_DETECTOR = new CbrnEquipmentTypeCategoryCode(
			"Automated radiation detector",
			"ARDDET",
			"An unattended radiation detector.");
	public static final CbrnEquipmentTypeCategoryCode BIOLOGICAL_INTEGRATED_DETECTOR = new CbrnEquipmentTypeCategoryCode(
			"Biological integrated detector",
			"BIOINT",
			"An integrated biological detection, alarm, and identification system.");
	public static final CbrnEquipmentTypeCategoryCode BIOLOGICAL_STAND_OFF_DETECTION_SYSTEM = new CbrnEquipmentTypeCategoryCode(
			"Biological stand-off detection system",
			"BIOSTO",
			"A detector capable of remotely detecting biological contamination.");
	public static final CbrnEquipmentTypeCategoryCode CBRN_DECONTAMINATION_VEHICLE = new CbrnEquipmentTypeCategoryCode(
			"CBRN decontamination vehicle",
			"CBRNDC",
			"A vehicle that, as its primary function, is equipped to decontaminate persons or equipment contaminated by an NBC (CBRN) exposure.");
	public static final CbrnEquipmentTypeCategoryCode CBRN_RECONNAISSANCE_VEHICLE = new CbrnEquipmentTypeCategoryCode(
			"CBRN reconnaissance vehicle",
			"CBRNRC",
			"A vehicle that, as its primary function, is equipped to perform by visual observation or other detection methods, information a particular area potentially contaminated by an NBC (CBRN) event.");
	public static final CbrnEquipmentTypeCategoryCode CHEMICAL_AGENT_MONITOR = new CbrnEquipmentTypeCategoryCode(
			"Chemical agent monitor",
			"CHMMON",
			"A handheld chemical agent detector.");
	public static final CbrnEquipmentTypeCategoryCode MASS_SPECTROMETER = new CbrnEquipmentTypeCategoryCode(
			"Mass spectrometer",
			"MSSPTR",
			"An apparatus used for recording and measuring the mass spectra of particles, especially as a method of analysis.");
	public static final CbrnEquipmentTypeCategoryCode NOT_KNOWN = new CbrnEquipmentTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final CbrnEquipmentTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new CbrnEquipmentTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final CbrnEquipmentTypeCategoryCode RADIOLOGICAL_KIT = new CbrnEquipmentTypeCategoryCode(
			"Radiological kit",
			"RADKIT",
			"A collection of personal dosimeters or detectors for determination of radiation exposure history and protection against radiation hazards issued to a person.");
	public static final CbrnEquipmentTypeCategoryCode RADIATION_SPECTROMETER = new CbrnEquipmentTypeCategoryCode(
			"Radiation spectrometer",
			"RDSPTR",
			"An apparatus used for recording and measuring a radiation energy spectra, especially as a method of analysis.");

	private CbrnEquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
