/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LanguageSkillProficiencyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the level of skill or comprehension of a specific PERSON in a specific language skill.";
	}

	private static HashMap<String, LanguageSkillProficiencyCode> physicalToCode = new HashMap<String, LanguageSkillProficiencyCode>();

	public static LanguageSkillProficiencyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LanguageSkillProficiencyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LanguageSkillProficiencyCode _0 = new LanguageSkillProficiencyCode(
			"0",
			"0",
			"No significant or practical proficiency.");
	public static final LanguageSkillProficiencyCode _1 = new LanguageSkillProficiencyCode(
			"1",
			"1",
			"Elementary: Low performance ability.");
	public static final LanguageSkillProficiencyCode _2 = new LanguageSkillProficiencyCode(
			"2",
			"2",
			"Fair: Limited working performance ability.");
	public static final LanguageSkillProficiencyCode _3 = new LanguageSkillProficiencyCode(
			"3",
			"3",
			"Good: Minimum professional performance ability.");
	public static final LanguageSkillProficiencyCode _4 = new LanguageSkillProficiencyCode(
			"4",
			"4",
			"Very good: Full professional performance ability.");
	public static final LanguageSkillProficiencyCode _5 = new LanguageSkillProficiencyCode(
			"5",
			"5",
			"Excellent: Native / Bilingual.");

	private LanguageSkillProficiencyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
