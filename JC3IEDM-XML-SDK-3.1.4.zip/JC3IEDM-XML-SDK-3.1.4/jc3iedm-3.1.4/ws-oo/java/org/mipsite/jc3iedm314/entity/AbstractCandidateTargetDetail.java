/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractCandidateTargetDetail extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private CandidateTargetDetailFocusTypeCode focusTypeCode; // mandatory
	private TextTypeVar255 labelText; // optional
	private OrdinalType6 priorityOrdinal; // optional
	private CandidateTargetDetailSchemeCode schemeCode; // optional
	private Set<Ref<CandidateTargetDetailAuthorisation>> authorisationSet; // zero-one-or-more
	private Set<Ref<CandidateTargetDetailAssociation>> candidateTargetDetailAssociationInObjectSet; // zero-one-or-more
	private Set<Ref<CandidateTargetDetailAssociation>> candidateTargetDetailAssociationInSubjectSet; // zero-one-or-more

	// default constructor

	public AbstractCandidateTargetDetail() {
		this.authorisationSet = new HashSet<Ref<CandidateTargetDetailAuthorisation>>();
		this.candidateTargetDetailAssociationInObjectSet = new HashSet<Ref<CandidateTargetDetailAssociation>>();
		this.candidateTargetDetailAssociationInSubjectSet = new HashSet<Ref<CandidateTargetDetailAssociation>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractCandidateTargetDetail.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractCandidateTargetDetail.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public CandidateTargetDetailFocusTypeCode getFocusTypeCode() {
		if (this.focusTypeCode == null) {
			throw new NullValueException("AbstractCandidateTargetDetail.focusTypeCode");
		}
		return this.focusTypeCode;
	}

	public void setFocusTypeCode(CandidateTargetDetailFocusTypeCode focusTypeCode) {
		this.focusTypeCode = focusTypeCode;
	}

	public TextTypeVar255 getLabelText() {
		return this.labelText;
	}

	public void setLabelText(TextTypeVar255 labelText) {
		this.labelText = labelText;
	}

	public OrdinalType6 getPriorityOrdinal() {
		return this.priorityOrdinal;
	}

	public void setPriorityOrdinal(OrdinalType6 priorityOrdinal) {
		this.priorityOrdinal = priorityOrdinal;
	}

	public CandidateTargetDetailSchemeCode getSchemeCode() {
		return this.schemeCode;
	}

	public void setSchemeCode(CandidateTargetDetailSchemeCode schemeCode) {
		this.schemeCode = schemeCode;
	}

	public Set<Ref<CandidateTargetDetailAuthorisation>> getAuthorisationSet() {
		return this.authorisationSet;
	}

	public void addAuthorisation(Ref<CandidateTargetDetailAuthorisation> authorisation) {
		this.authorisationSet.add(authorisation);
	}

	public Set<Ref<CandidateTargetDetailAssociation>> getCandidateTargetDetailAssociationInObjectSet() {
		return this.candidateTargetDetailAssociationInObjectSet;
	}

	public void addCandidateTargetDetailAssociationInObject(Ref<CandidateTargetDetailAssociation> candidateTargetDetailAssociationInObject) {
		this.candidateTargetDetailAssociationInObjectSet.add(candidateTargetDetailAssociationInObject);
	}

	public Set<Ref<CandidateTargetDetailAssociation>> getCandidateTargetDetailAssociationInSubjectSet() {
		return this.candidateTargetDetailAssociationInSubjectSet;
	}

	public void addCandidateTargetDetailAssociationInSubject(Ref<CandidateTargetDetailAssociation> candidateTargetDetailAssociationInSubject) {
		this.candidateTargetDetailAssociationInSubjectSet.add(candidateTargetDetailAssociationInSubject);
	}
}
