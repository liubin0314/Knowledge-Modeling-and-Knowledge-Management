/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaritimeEquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MARITIME-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, MaritimeEquipmentTypeCategoryCode> physicalToCode = new HashMap<String, MaritimeEquipmentTypeCategoryCode>();

	public static MaritimeEquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaritimeEquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaritimeEquipmentTypeCategoryCode ANCHOR = new MaritimeEquipmentTypeCategoryCode(
			"Anchor",
			"ANCHOR",
			"An equipment for holding a vessel in a fixed position mooring it to the bottom of the sea or river by means of a heavy structure traditionally composed of a long shank with a ring at one end for the cable and at the other end two arms tending upwards with barbs on each side.");
	public static final MaritimeEquipmentTypeCategoryCode BUOY = new MaritimeEquipmentTypeCategoryCode(
			"Buoy",
			"BUOY",
			"A floating object fastened in a particular place to mark the position of underwater objects or the course that ships have to navigate.");
	public static final MaritimeEquipmentTypeCategoryCode CUTTER = new MaritimeEquipmentTypeCategoryCode(
			"Cutter",
			"CUTTER",
			"In naval mine warfare a device fitted to a sweep wire to cut or part the mooring of mines or obstructors. It may also be fitted in, or to, the mooring of a mine or obstructors to part a sweep wire.");
	public static final MaritimeEquipmentTypeCategoryCode DEPTH_CHARGE_LAUNCHER = new MaritimeEquipmentTypeCategoryCode(
			"Depth-charge launcher",
			"DCLAUN",
			"A structural device designed to support and hold a depth-charge in position for firing.");
	public static final MaritimeEquipmentTypeCategoryCode DIAPHRAGM = new MaritimeEquipmentTypeCategoryCode(
			"Diaphragm",
			"DIAPHR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1135/55.");
	public static final MaritimeEquipmentTypeCategoryCode DIVERTER = new MaritimeEquipmentTypeCategoryCode(
			"Diverter",
			"DVERTR",
			"An object used to carry the magnetic cable in a dispersed form of loop, a specific form of float.");
	public static final MaritimeEquipmentTypeCategoryCode ELECTRODE = new MaritimeEquipmentTypeCategoryCode(
			"Electrode",
			"ELCTRD",
			"In naval mine warfare, a magnetic cable sweep in which salt water and the seabed form part of the electric circuit.");
	public static final MaritimeEquipmentTypeCategoryCode FLOAT = new MaritimeEquipmentTypeCategoryCode(
			"Float",
			"FLOAT",
			"A cork or other buoyant object that is used to support other equipment, a mine sweep wire for surface minesweepng.");
	public static final MaritimeEquipmentTypeCategoryCode KITE_DEPRESSOR = new MaritimeEquipmentTypeCategoryCode(
			"Kite, depressor",
			"KITEDP",
			"A device which when towed submerges and planes at a predetermined depth without sideways displacement.");
	public static final MaritimeEquipmentTypeCategoryCode MECHANICAL_INFLUENCE = new MaritimeEquipmentTypeCategoryCode(
			"Mechanical influence",
			"MECHNF",
			"Equipment designed to locate the mine by operating the magnetic firing system of a mine.");
	public static final MaritimeEquipmentTypeCategoryCode MARITIME_MINE_DISPOSAL_VEHICLE = new MaritimeEquipmentTypeCategoryCode(
			"Maritime mine disposal vehicle",
			"MRTMDV",
			"ROV used to destroy mines normally armed with MDC mine disposal charge.");
	public static final MaritimeEquipmentTypeCategoryCode NOT_KNOWN = new MaritimeEquipmentTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaritimeEquipmentTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new MaritimeEquipmentTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaritimeEquipmentTypeCategoryCode OBSTRUCTORS_MINE = new MaritimeEquipmentTypeCategoryCode(
			"Obstructors, mine",
			"OBSTRM",
			"A device laid with the sole object of obstructing or damaging mechanical minesweeping equipment.");
	public static final MaritimeEquipmentTypeCategoryCode OTTER = new MaritimeEquipmentTypeCategoryCode(
			"Otter",
			"OTTER",
			"In naval mine warfare, a device which, when towed, displaces itself sideways to a predetermined distance.");
	public static final MaritimeEquipmentTypeCategoryCode PARAVANE = new MaritimeEquipmentTypeCategoryCode(
			"Paravane",
			"PARVNE",
			"A towed body with planes and a cutter with a means of depth keeping, which displaces itself sideways and can be used as a ship protection measure against certain moored mines.");
	public static final MaritimeEquipmentTypeCategoryCode PELLETS = new MaritimeEquipmentTypeCategoryCode(
			"Pellets",
			"PELLET",
			"Orange floats used to support a length of line to aid recovery.");
	public static final MaritimeEquipmentTypeCategoryCode RADAR_REFLECTOR = new MaritimeEquipmentTypeCategoryCode(
			"Radar reflector",
			"RADARR",
			"An object designed to increase the radio reflectivity of a vessel so that it is more visible on radar.");
	public static final MaritimeEquipmentTypeCategoryCode RUBBER_MOORING = new MaritimeEquipmentTypeCategoryCode(
			"Rubber mooring",
			"RBBRMR",
			"Part of the mooring equipment used with a short scope buoy.");
	public static final MaritimeEquipmentTypeCategoryCode SONAR_MARITIME = new MaritimeEquipmentTypeCategoryCode(
			"Sonar, maritime",
			"SONARM",
			"An acoustic device used primarily for the detection and location of underwater objects.");
	public static final MaritimeEquipmentTypeCategoryCode SWEEP = new MaritimeEquipmentTypeCategoryCode(
			"Sweep",
			"SWEEP",
			"Equipment designed to be employed in minesweeping operations.");
	public static final MaritimeEquipmentTypeCategoryCode SWELL_RECORDER = new MaritimeEquipmentTypeCategoryCode(
			"Swell recorder",
			"SWELLR",
			"A device used to record the pressure fluctuation on the bottom.");
	public static final MaritimeEquipmentTypeCategoryCode TOWED_ARRAY_SURVEILLANCE_SYSTEM = new MaritimeEquipmentTypeCategoryCode(
			"Towed array surveillance system",
			"TASVST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeCategoryCode TOWED_ARRAY_SURVEILLANCE_SYSTEM_TACTICAL = new MaritimeEquipmentTypeCategoryCode(
			"Towed array surveillance system, tactical",
			"TTASVS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeCategoryCode WEIGHT = new MaritimeEquipmentTypeCategoryCode(
			"Weight",
			"WEIGHT",
			"A heavy object used to pull, press or hold something down, e.g. buoy, mine.");

	private MaritimeEquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
