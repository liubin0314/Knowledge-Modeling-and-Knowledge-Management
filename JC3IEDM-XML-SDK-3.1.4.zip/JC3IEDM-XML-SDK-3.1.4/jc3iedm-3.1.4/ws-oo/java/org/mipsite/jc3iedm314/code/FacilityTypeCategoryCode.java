/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FACILITY-TYPE.";
	}

	private static HashMap<String, FacilityTypeCategoryCode> physicalToCode = new HashMap<String, FacilityTypeCategoryCode>();

	public static FacilityTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityTypeCategoryCode UNIT_OF_ACCOMMODATION = new FacilityTypeCategoryCode(
			"Unit of accommodation",
			"ACCOM",
			"An amount of living space distinct and separate. (Intended for humanitarian aid scenario to enable general indication of accommodation requirements).");
	public static final FacilityTypeCategoryCode AIRBORNE_EARLY_WARNING_GROUND_FACILITY = new FacilityTypeCategoryCode(
			"Airborne early warning ground facility",
			"AEWGRD",
			"A facility on the ground that has an electromagnetic link to an airborne early warning system.");
	public static final FacilityTypeCategoryCode AIRFIELD_TYPE = new FacilityTypeCategoryCode(
			"AIRFIELD-TYPE",
			"AIRFLD",
			"A FACILITY-TYPE that is a class of an area prepared for the accommodation (including any buildings, installations, or equipment) of landing and take off of aircraft.");
	public static final FacilityTypeCategoryCode ALTERNATE_DECONTAMINATION_FACILITY = new FacilityTypeCategoryCode(
			"Alternate decontamination facility",
			"ALTDCN",
			"A decontamination facility designated as the alternate to the primary decontamination facility that can be used in place of the where personnel and/or materiel (incl. vehicles) can be cleaned after (potential) contamination of radioactive, biological, or chemical material.");
	public static final FacilityTypeCategoryCode ANCHORAGE = new FacilityTypeCategoryCode(
			"Anchorage",
			"ANCHOR",
			"A FACILITY-TYPE that is a place where vessels anchor.");
	public static final FacilityTypeCategoryCode APRON = new FacilityTypeCategoryCode(
			"Apron",
			"APRON",
			"A FACILITY-TYPE that is an area intended for parking, loading, unloading and/or servicing.");
	public static final FacilityTypeCategoryCode APARTMENT_BUILDING = new FacilityTypeCategoryCode(
			"Apartment building",
			"APRTBD",
			"A residential unit consisting of a block of flats.");
	public static final FacilityTypeCategoryCode AMMUNITION_SUPPLY_POINT = new FacilityTypeCategoryCode(
			"Ammunition supply point",
			"ASP",
			"A facility at which ammunition, obtained from supporting supply points by a division or other unit, are broken down for distribution to other units.");
	public static final FacilityTypeCategoryCode AMMUNITION_TRANSFER_POINT = new FacilityTypeCategoryCode(
			"Ammunition transfer point",
			"ATP",
			"A facility for physical transfer of ammunition from one means of transport to another or to the final receiving unit.");
	public static final FacilityTypeCategoryCode BANK = new FacilityTypeCategoryCode(
			"Bank",
			"BANK",
			"An establishment where money is stored for saving or commercial purposes.");
	public static final FacilityTypeCategoryCode BARRACKS = new FacilityTypeCategoryCode(
			"Barracks",
			"BARRCK",
			"A building or group of buildings used to house soldiers.");
	public static final FacilityTypeCategoryCode BASIN = new FacilityTypeCategoryCode(
			"Basin",
			"BASIN",
			"A FACILITY-TYPE that is an open area of water, usually artificial and enclosed by dock gates lined with wharves, warehouses and berths to enable vessels to load and unload.");
	public static final FacilityTypeCategoryCode BATH = new FacilityTypeCategoryCode(
			"Bath",
			"BATH",
			"A facility used for personal cleanliness.");
	public static final FacilityTypeCategoryCode BERM = new FacilityTypeCategoryCode(
			"Berm",
			"BERM",
			"An artificial ridge or embankment.");
	public static final FacilityTypeCategoryCode BERTH = new FacilityTypeCategoryCode(
			"Berth",
			"BERTH",
			"A FACILITY-TYPE that is a space or length in the water at a harbour allocated to or reserved for a vessel to dock and moor for loading or unloading.");
	public static final FacilityTypeCategoryCode BULK_FUEL_INSTALLATION_FIELD = new FacilityTypeCategoryCode(
			"Bulk fuel installation, field",
			"BFIFLD",
			"A facility containing fuel containers, pipe work and dispensing equipment connected together to form a temporary fuel installation within a tactical field location.");
	public static final FacilityTypeCategoryCode BIVOUAC = new FacilityTypeCategoryCode(
			"Bivouac",
			"BIVOUC",
			"A temporary encampment, under canvas, of troops in the field.");
	public static final FacilityTypeCategoryCode BUILDING = new FacilityTypeCategoryCode(
			"Building",
			"BLD",
			"A relatively permanent structure, roofed and usually walled and designed for some particular use.");
	public static final FacilityTypeCategoryCode BRIDGE_TYPE = new FacilityTypeCategoryCode(
			"BRIDGE-TYPE",
			"BRGTYP",
			"A FACILITY-TYPE that is a class of structures (including overpasses and viaducts), fixed or moveable, spanning and/or providing passage over an object.");
	public static final FacilityTypeCategoryCode BUILT_UP_AREA = new FacilityTypeCategoryCode(
			"Built-up area",
			"BUA",
			"A facility containing a concentration of buildings and other structures.");
	public static final FacilityTypeCategoryCode BUNKER = new FacilityTypeCategoryCode(
			"Bunker",
			"BUNKER",
			"A fortified chamber, mostly below ground, often built with reinforced concrete and provided with embrasures.");
	public static final FacilityTypeCategoryCode CACHE = new FacilityTypeCategoryCode(
			"Cache",
			"CACHE",
			"A place for concealment and safekeeping.");
	public static final FacilityTypeCategoryCode CAMP = new FacilityTypeCategoryCode(
			"Camp",
			"CAMP",
			"An accommodation based upon a number of tents or huts.");
	public static final FacilityTypeCategoryCode CANAL = new FacilityTypeCategoryCode(
			"Canal",
			"CAN",
			"A man-made or improved natural waterway used for transportation.");
	public static final FacilityTypeCategoryCode NBC_OBSERVATION_POST_DISMOUNTED = new FacilityTypeCategoryCode(
			"NBC observation post (dismounted)",
			"CBRNPS",
			"A facility from which chemical, biological, radiological, or nuclear observations are made and which possesses appropriate communications; it is dismounted.");
	public static final FacilityTypeCategoryCode COMBAT_OUTPOST = new FacilityTypeCategoryCode(
			"Combat outpost",
			"CBTPST",
			"A reinforced observation post capable of conducting limited combat operations.");
	public static final FacilityTypeCategoryCode CEMETERY_GRAVEYARD_BURIAL_GROUND = new FacilityTypeCategoryCode(
			"Cemetery/graveyard/burial ground",
			"CEM",
			"A facility that is an area of land for burying the dead.");
	public static final FacilityTypeCategoryCode CHIMNEY_SMOKESTACK = new FacilityTypeCategoryCode(
			"Chimney/smokestack",
			"CHM",
			"A vertical structure containing a passage or flue for discharging smoke and gases of combustion.");
	public static final FacilityTypeCategoryCode CHANNEL_PASS_LOCK = new FacilityTypeCategoryCode(
			"Channel pass lock",
			"CHPLCK",
			"A confined section of a canal or river where the level can be changed for raising and lowering boats between adjacent sections by the use of gates and sluices.");
	public static final FacilityTypeCategoryCode CIVILIAN_MILITARY_COORDINATION_CENTRE = new FacilityTypeCategoryCode(
			"Civilian-military coordination centre",
			"CIMICC",
			"A facility at which civilian-military coordination operations are performed.");
	public static final FacilityTypeCategoryCode CITY = new FacilityTypeCategoryCode(
			"City",
			"CITY",
			"A large town. In most cases a town created a city by charter.");
	public static final FacilityTypeCategoryCode CHECK_POINT_POLICE = new FacilityTypeCategoryCode(
			"Check point, police",
			"CKPPOL",
			"A facility where police check vehicular or pedestrian traffic in order to enforce circulation control measures and other laws, orders, and regulations.");
	public static final FacilityTypeCategoryCode CLASSIFICATION_FACILITY = new FacilityTypeCategoryCode(
			"Classification facility",
			"CLSFAC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final FacilityTypeCategoryCode COMMUNICATIONS_BUILDING = new FacilityTypeCategoryCode(
			"Communications building",
			"COB",
			"A building in which communications signals are processed or controlled.");
	public static final FacilityTypeCategoryCode COMPOUND = new FacilityTypeCategoryCode(
			"Compound",
			"COMPND",
			"A cluster of structures having a shared purpose, usually inside a fence or wall.");
	public static final FacilityTypeCategoryCode COMMUNICATIONS_TOWER = new FacilityTypeCategoryCode(
			"Communications tower",
			"COT",
			"A relatively tall structure used for transmitting and/or receiving electronic communications signals.");
	public static final FacilityTypeCategoryCode COMMAND_POST_FACILITY = new FacilityTypeCategoryCode(
			"Command post facility",
			"CP",
			"A facility from which a commander directs operations or controls forces.");
	public static final FacilityTypeCategoryCode CROPLAND = new FacilityTypeCategoryCode(
			"Cropland",
			"CRP",
			"An area that has been tilled for the planting of crops.");
	public static final FacilityTypeCategoryCode CASUALTY_COLLECTION_POINT = new FacilityTypeCategoryCode(
			"Casualty collection point",
			"CSCLPT",
			"A facility where casualties are assembled to be transported to a medical treatment facility for example a company aid post.");
	public static final FacilityTypeCategoryCode CONTROL_TOWER = new FacilityTypeCategoryCode(
			"Control tower",
			"CTT",
			"A tower-like structure that houses the persons and equipment used to control the flow of air, rail, or marine traffic.");
	public static final FacilityTypeCategoryCode CULTURAL_SITE = new FacilityTypeCategoryCode(
			"Cultural site",
			"CULTRL",
			"An area that is recognised (for example: designated as World Heritage Site) because of its cultural (for example: historical) importance.");
	public static final FacilityTypeCategoryCode CULVERT = new FacilityTypeCategoryCode(
			"Culvert",
			"CULVRT",
			"An enclosed channel for carrying a watercourse (for example: a stream, a sewer, or a drain) under a route (for example: a road, a railway, or an embankment).");
	public static final FacilityTypeCategoryCode CUT = new FacilityTypeCategoryCode(
			"Cut",
			"CUT",
			"An excavation of the earth's surface to provide passage for a road, railway, canal, etc.");
	public static final FacilityTypeCategoryCode CIVILIAN_COLLECTION_POINT = new FacilityTypeCategoryCode(
			"Civilian collection point",
			"CVCLPT",
			"A facility where civilians are assembled for classification, sorting or further movement to other facilities or installations.");
	public static final FacilityTypeCategoryCode CLEARED_WAY_FIREBREAK = new FacilityTypeCategoryCode(
			"Cleared way/firebreak",
			"CWY",
			"A man-made clearing in a cultural area or through a stand of trees, designed to provide access for a road, railroad, pipeline or power transmission line, or to impede the progress of forest fires.");
	public static final FacilityTypeCategoryCode DAM_WEIR = new FacilityTypeCategoryCode(
			"Dam/weir",
			"DAM",
			"A permanent barrier across a watercourse used to impound water or to control its flow.");
	public static final FacilityTypeCategoryCode DITCH = new FacilityTypeCategoryCode(
			"Ditch",
			"DCH",
			"A channel constructed for the purpose of irrigation or drainage.");
	public static final FacilityTypeCategoryCode DECONTAMINATION_FACILITY = new FacilityTypeCategoryCode(
			"Decontamination facility",
			"DECONP",
			"A facility where personnel and/or materiel (incl. vehicles) can be cleaned after (potential) contamination of radioactive, biological, or chemical material.");
	public static final FacilityTypeCategoryCode DEPOT_BIOLOGICAL = new FacilityTypeCategoryCode(
			"Depot, biological",
			"DEPBIO",
			"An area used for the storage of biological agents.");
	public static final FacilityTypeCategoryCode DEPOT_CHEMICALS = new FacilityTypeCategoryCode(
			"Depot, chemicals",
			"DEPCHM",
			"An area used for the storage of chemicals.");
	public static final FacilityTypeCategoryCode DEPOT_ENGINEER = new FacilityTypeCategoryCode(
			"Depot, engineer",
			"DEPENG",
			"An area used for the storage of engineer equipment.");
	public static final FacilityTypeCategoryCode DEPOT_MEDICAL = new FacilityTypeCategoryCode(
			"Depot, medical",
			"DEPMED",
			"An area used for the storage of medical supplies.");
	public static final FacilityTypeCategoryCode DEPOT_MISSILE_AMMUNITION = new FacilityTypeCategoryCode(
			"Depot, missile ammunition",
			"DEPMIS",
			"An area used for the storage of missile ammunition.");
	public static final FacilityTypeCategoryCode DEPOT_AMMUNITION = new FacilityTypeCategoryCode(
			"Depot, ammunition",
			"DEPMUN",
			"An area used for the storage of ammunition.");
	public static final FacilityTypeCategoryCode DEPOT_NUCLEAR_STORAGE = new FacilityTypeCategoryCode(
			"Depot, nuclear storage",
			"DEPNUC",
			"An area used for the storage of nuclear weapons.");
	public static final FacilityTypeCategoryCode DEPOT_NOT_OTHERWISE_SPECIFIED = new FacilityTypeCategoryCode(
			"Depot, not otherwise specified",
			"DEPOT",
			"An area used for the storage of products or supplies. A facility for the receipt, classification, storage, accounting, issue, maintenance, procurement, manufacture, assembly, research, salvage or disposal of material.");
	public static final FacilityTypeCategoryCode DEPOT_POL = new FacilityTypeCategoryCode(
			"Depot, POL",
			"DEPPOL",
			"An area used for the storage of petroleum, oil and/or lubricants.");
	public static final FacilityTypeCategoryCode DEMOLITION_DEBRIS = new FacilityTypeCategoryCode(
			"Demolition debris",
			"DMDBRS",
			"The debris left over from the demolition of an object.");
	public static final FacilityTypeCategoryCode DEPOT_NBC = new FacilityTypeCategoryCode(
			"Depot, NBC",
			"DPCBRN",
			"An area used for the storage of chemical, biological, radiological, or nuclear materiel.");
	public static final FacilityTypeCategoryCode DRAINAGE_SEWAGE = new FacilityTypeCategoryCode(
			"Drainage/sewage",
			"DRNSEW",
			"A facility used for emptying of liquid and channelling sewage to get rid of waste, dirty water and drain water.");
	public static final FacilityTypeCategoryCode DRESSING_STATION = new FacilityTypeCategoryCode(
			"Dressing station",
			"DRSTAT",
			"A movable facility for the initial treatment of casualties.");
	public static final FacilityTypeCategoryCode DRY_DOCK = new FacilityTypeCategoryCode(
			"Dry-dock",
			"DRYDCK",
			"A FACILITY-TYPE that provides an enclosure for maintenance, building or repairing ships, from which water can be pumped out.");
	public static final FacilityTypeCategoryCode DETAINEE_COLLECTION_POINT = new FacilityTypeCategoryCode(
			"Detainee collection point",
			"DTCLPT",
			"A facility where detainees are assembled for classification, sorting or further movement to other facilities or installations.");
	public static final FacilityTypeCategoryCode DETAINEE_HOLDING_AREA = new FacilityTypeCategoryCode(
			"Detainee holding area",
			"DTHARE",
			"A facility where detainees are provided custodial care pending further disposition.");
	public static final FacilityTypeCategoryCode ELECTRONIC_INSTALLATION = new FacilityTypeCategoryCode(
			"Electronic installation",
			"ELCINS",
			"A facility whose essential function is based on the use of electronic equipment.");
	public static final FacilityTypeCategoryCode ELECTRICAL_SUPPLY = new FacilityTypeCategoryCode(
			"Electrical supply",
			"ELCSPL",
			"A facility containing the equipment used for the production and/or distribution of electricity.");
	public static final FacilityTypeCategoryCode ELECTRONIC_INSTALLATION_RADAR_DOME = new FacilityTypeCategoryCode(
			"Electronic installation, radar dome",
			"ELIRDD",
			"A cover usually intended for protecting radar from the effects of its physical environment without degrading significantly its electrical performance.");
	public static final FacilityTypeCategoryCode ELECTRONIC_INSTALLATION_SURFACE_SURVEILLANCE_JAMMER = new FacilityTypeCategoryCode(
			"Electronic installation, surface surveillance jammer",
			"ELISSJ",
			"A facility whose essential function is jamming to prevent or reduce the enemy's effective use of the electromagnetic spectrum for surface surveillance.");
	public static final FacilityTypeCategoryCode ELECTRONIC_INSTALLATION_WARFARE = new FacilityTypeCategoryCode(
			"Electronic installation, warfare",
			"ELIWAR",
			"A facility whose essential function is to exploit the electromagnetic spectrum encompassing: the search for, interception and identification of electromagnetic emissions, the employment of electromagnetic energy, including directed energy, to reduce or prevent hostile use of the electromagnetic spectrum, and actions to ensure its effective use by friendly forces.");
	public static final FacilityTypeCategoryCode EMBANKMENT = new FacilityTypeCategoryCode(
			"Embankment",
			"EMBNKM",
			"A man-made raised long mound of earth or other material.");
	public static final FacilityTypeCategoryCode EMPLACEMENT = new FacilityTypeCategoryCode(
			"Emplacement",
			"EMPLAC",
			"A prepared position for one or more weapons or pieces of equipment for protection against hostile fire or bombardment, and from which they can execute their tasks.");
	public static final FacilityTypeCategoryCode EQUIPMENT_MANUFACTURE = new FacilityTypeCategoryCode(
			"Equipment, manufacture",
			"EQIMFT",
			"A facility generally used specifically to support the manufacture of equipment.");
	public static final FacilityTypeCategoryCode MILITARY_BASE_FACILITY_AIRPORT_AIRBASE = new FacilityTypeCategoryCode(
			"Military base/facility, airport/airbase",
			"FACAIR",
			"A facility that is used as a military base prepared for the accommodation, landing and takeoff of aircraft.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_AMMUNITION_AND_EXPLOSIVES_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, ammunition and explosives production",
			"FACAMM",
			"A facility used as for munitions and explosives production.");
	public static final FacilityTypeCategoryCode MILITARY_BASE_FACILITY_ARMY = new FacilityTypeCategoryCode(
			"Military base/facility, army",
			"FACAR",
			"A facility that is used as a military base by the army.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_ARMAMENT_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, armament production",
			"FACARM",
			"A facility used as for armament production.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_AIRCRAFT_PRODUCTION_AND_ASSEMBLY = new FacilityTypeCategoryCode(
			"Military materiel facility, aircraft production and assembly",
			"FACARP",
			"A facility used as for aircraft production and assembly.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_ATOMIC_ENERGY_REACTOR = new FacilityTypeCategoryCode(
			"Military materiel facility, atomic energy reactor",
			"FACATR",
			"A facility used as an atomic energy reactor.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_ENGINEERING_EQUIPMENT_PRODUCTION_BRIDGE = new FacilityTypeCategoryCode(
			"Military materiel facility, engineering equipment production, bridge",
			"FACBRG",
			"A facility used as for engineering equipment production, bridge.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_CHEMICAL_AND_BIOLOGICAL_WARFARE_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, chemical and biological warfare production",
			"FACCHB",
			"A facility used as for chemical and biological warfare production.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_ENGINEERING_EQUIPMENT_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, engineering equipment production",
			"FACENG",
			"A facility used as for engineering equipment production.");
	public static final FacilityTypeCategoryCode GOVERNMENTAL_LEADERSHIP = new FacilityTypeCategoryCode(
			"Governmental leadership",
			"FACGOV",
			"A facility used to support governmental leadership functions.");
	public static final FacilityTypeCategoryCode MILITARY_BASE_FACILITY = new FacilityTypeCategoryCode(
			"Military base/facility",
			"FACMIL",
			"A facility that is used as a military base.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_MISSILE_AND_SPACE_SYSTEM_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, missile and space system production",
			"FACMSL",
			"A facility used as for missile and space system production.");
	public static final FacilityTypeCategoryCode MILITARY_BASE_FACILITY_SEAPORT_NAVAL_BASE = new FacilityTypeCategoryCode(
			"Military base/facility, seaport/naval base",
			"FACNAV",
			"A facility that is used as a naval base and where ships may receive or discharge their cargoes.");
	public static final FacilityTypeCategoryCode SERVICE_RESEARCH_UTILITY_FACILITY_ELECTRIC_POWER_FACILITY = new FacilityTypeCategoryCode(
			"Service, research, utility facility, electric power facility",
			"FACPOW",
			"A facility generally used to support service, research or utility functions in support of electric power.");
	public static final FacilityTypeCategoryCode PROCESSING_FACILITY = new FacilityTypeCategoryCode(
			"Processing facility",
			"FACPRO",
			"A facility generally used to support a particular method of operation in any manufacture or to support a series of actions or events.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_SHIP_CONSTRUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, ship construction",
			"FACSHP",
			"A facility used as for ship construction.");
	public static final FacilityTypeCategoryCode SERVICE_RESEARCH_UTILITY_FACILITY = new FacilityTypeCategoryCode(
			"Service, research, utility facility",
			"FACSRU",
			"A facility generally used to support service, research or utility functions.");
	public static final FacilityTypeCategoryCode SERVICE_RESEARCH_UTILITY_FACILITY_TECHNOLOGICAL_RESEARCH_FACILITY = new FacilityTypeCategoryCode(
			"Service, research, utility facility, technological research facility",
			"FACTEC",
			"A facility generally used to support service, research or utility functions in support of technological research.");
	public static final FacilityTypeCategoryCode SERVICE_RESEARCH_UTILITY_FACILITY_TELECOMMUNICATIONS_FACILITY = new FacilityTypeCategoryCode(
			"Service, research, utility facility, telecommunications facility",
			"FACTEL",
			"A facility generally used to support service, research or utility functions in support of telecommunications.");
	public static final FacilityTypeCategoryCode TRANSPORT_FACILITY = new FacilityTypeCategoryCode(
			"Transport facility",
			"FACTRN",
			"A facility that is used to support transport functions.");
	public static final FacilityTypeCategoryCode MILITARY_MATERIEL_FACILITY_VEHICLE_PRODUCTION = new FacilityTypeCategoryCode(
			"Military materiel facility, vehicle production",
			"FACVEH",
			"A facility used as for vehicle production.");
	public static final FacilityTypeCategoryCode SERVICE_RESEARCH_UTILITY_FACILITY_PUBLIC_WATER_SERVICE = new FacilityTypeCategoryCode(
			"Service, research, utility facility, public water service",
			"FACWAT",
			"A facility generally used to support service, research or utility functions in support of public water services.");
	public static final FacilityTypeCategoryCode FARM = new FacilityTypeCategoryCode(
			"Farm",
			"FARM",
			"Land devoted to agricultural production, raising and breeding of animals or an area of water devoted to the raising and breeding of aquatic animals.");
	public static final FacilityTypeCategoryCode FORWARD_ARMING_AND_REFUELLING_POINT = new FacilityTypeCategoryCode(
			"Forward arming and refuelling point",
			"FARP",
			"A temporary facility that is organised, equipped, and deployed by an aviation commander and normally located in the main battle area closer to the area of operations than the aviation unit's combat service support (CSS) area. It provides fuel and ammunition necessary for the employment of aviation manoeuvre units in combat. It permits combat aircraft to rapidly refuel and rearm simultaneously.");
	public static final FacilityTypeCategoryCode FORD_CONCRETE_LINED_BED = new FacilityTypeCategoryCode(
			"Ford, concrete lined bed",
			"FCRLBD",
			"A shallow place in a river or other water marked with a concrete-lined bed that can be crossed without bridging, boats, or rafts.");
	public static final FacilityTypeCategoryCode FORD_STONE_LINED_BED = new FacilityTypeCategoryCode(
			"Ford, stone lined bed",
			"FCRSLB",
			"A shallow place in a river or other water marked with a stone-lined bed that can be crossed without bridging, boats, or rafts.");
	public static final FacilityTypeCategoryCode FENCE = new FacilityTypeCategoryCode(
			"Fence",
			"FENCE",
			"A man-made barrier of relatively light structure used as an enclosure or boundary.");
	public static final FacilityTypeCategoryCode FERRY_INSTALLATION = new FacilityTypeCategoryCode(
			"Ferry installation",
			"FERINS",
			"A facility (including the terminals and the water craft) to enable moving equipment and personnel across a body of water.");
	public static final FacilityTypeCategoryCode FIRE_FIGHTERS_BARRACKS = new FacilityTypeCategoryCode(
			"Fire-fighters barracks",
			"FFBRKS",
			"A building housing fire-fighters and their equipment.");
	public static final FacilityTypeCategoryCode FUEL_HANDLING_POINT = new FacilityTypeCategoryCode(
			"Fuel handling point",
			"FHPT",
			"A facility for refuelling of POL products.");
	public static final FacilityTypeCategoryCode FORWARD_OPERATING_BASE = new FacilityTypeCategoryCode(
			"Forward operating base",
			"FOB",
			"A base used to support tactical operations without establishing full support facilities which may be used for an extended time period.");
	public static final FacilityTypeCategoryCode FORWARD_OBSERVER_POSITION = new FacilityTypeCategoryCode(
			"Forward observer position",
			"FOBSPS",
			"A facility from which military observations are made or fires directed and adjusted by the occupants and which possesses appropriate communications; it may be airborne.");
	public static final FacilityTypeCategoryCode FORT = new FacilityTypeCategoryCode(
			"Fort",
			"FORT",
			"A fortified place garrisoned with troops.");
	public static final FacilityTypeCategoryCode FOXHOLE = new FacilityTypeCategoryCode(
			"Foxhole",
			"FOXHOL",
			"A hole in the ground used by a soldier for protection.");
	public static final FacilityTypeCategoryCode FREIGHT_TERMINAL = new FacilityTypeCategoryCode(
			"Freight terminal",
			"FRGTER",
			"A facility processing 'goods' in transit or being transferred from one transportation means to another.");
	public static final FacilityTypeCategoryCode FORTIFICATION = new FacilityTypeCategoryCode(
			"Fortification",
			"FRTFCN",
			"An emplacement or shelter of a temporary or permanent nature constructed for defence by forces for protection of forces.");
	public static final FacilityTypeCategoryCode FIELD_STORAGE_AREA_AMMUNITION = new FacilityTypeCategoryCode(
			"Field storage area-ammunition",
			"FSAAMM",
			"A facility with a group of field storage sites containing a max of 5000 tonnes gross weight of ammunition and explosives.");
	public static final FacilityTypeCategoryCode FIELD_STORAGE_MODULE_AMMUNITION = new FacilityTypeCategoryCode(
			"Field storage module-ammunition",
			"FSMAMM",
			"A facility that is a site containing approximately 10 tonnes gross weight of ammunition and explosives.");
	public static final FacilityTypeCategoryCode FIELD_STORAGE_SITE_AMMUNITION = new FacilityTypeCategoryCode(
			"Field storage site-ammunition",
			"FSSAMM",
			"A facility with a group of field storage modules containing a max of 200 tonnes gross weight of ammunition and explosives.");
	public static final FacilityTypeCategoryCode FIELD_STORAGE_STACK_AMMUNITION = new FacilityTypeCategoryCode(
			"Field storage stack-ammunition",
			"FSSTAM",
			"A facility where approximately 1 tonne gross weight of ammunition and explosives stored under tactical field conditions.");
	public static final FacilityTypeCategoryCode GARAGE = new FacilityTypeCategoryCode(
			"Garage",
			"GARAGE",
			"A building, either private or public, used for parking and/or storing vehicles.");
	public static final FacilityTypeCategoryCode GAS_PROCESSING_FACILITY = new FacilityTypeCategoryCode(
			"Gas processing facility",
			"GASPFA",
			"Installations for processing and purification of natural gas or separating natural gas from crude oil.");
	public static final FacilityTypeCategoryCode GATE = new FacilityTypeCategoryCode(
			"Gate",
			"GAT",
			"A barrier that controls passage to a road, railway, tunnel or bridge.");
	public static final FacilityTypeCategoryCode GOVERNMENT_BUILDING = new FacilityTypeCategoryCode(
			"Government building",
			"GVTBLD",
			"A building for the administration of local, regional, or national government.");
	public static final FacilityTypeCategoryCode HAMLET = new FacilityTypeCategoryCode(
			"Hamlet",
			"HAMLET",
			"A small village, especially one without a church.");
	public static final FacilityTypeCategoryCode HANGAR = new FacilityTypeCategoryCode(
			"Hangar",
			"HANGAR",
			"A covered space, shed or shelter for the accommodation of aircraft or spacecraft.");
	public static final FacilityTypeCategoryCode HARBOUR_TYPE = new FacilityTypeCategoryCode(
			"HARBOUR-TYPE",
			"HARBOR",
			"A FACILITY-TYPE that is a restricted body of water, an anchorage, or other limited coastal water area and its water approaches from which and in which shipping operations are projected or supported.");
	public static final FacilityTypeCategoryCode HIGH_TECHNOLOGY_COMPLEX = new FacilityTypeCategoryCode(
			"High-technology complex",
			"HGHTCH",
			"A building or set of integrated buildings that use state-of-the-art-technology designed for a specific purpose such as manufacturing, research and development or other related activity.");
	public static final FacilityTypeCategoryCode HISTORIC_SITE = new FacilityTypeCategoryCode(
			"Historic site",
			"HISTST",
			"A site containing one or more historical structures or terrain.");
	public static final FacilityTypeCategoryCode HOUSE = new FacilityTypeCategoryCode(
			"House",
			"HOUSE",
			"A detached household used as a dwelling for one or more persons.");
	public static final FacilityTypeCategoryCode HELICOPTER_LANDING_PAD = new FacilityTypeCategoryCode(
			"Helicopter landing pad",
			"HPD",
			"An improved area used for takeoff, and landing, by helicopters and other vertical takeoff and landing aircraft.");
	public static final FacilityTypeCategoryCode HELIPORT = new FacilityTypeCategoryCode(
			"Heliport",
			"HPT",
			"A place designated for the landing and takeoff of helicopters, including its buildings and facilities.");
	public static final FacilityTypeCategoryCode HEADQUARTERS_FACILITY = new FacilityTypeCategoryCode(
			"Headquarters facility",
			"HQ",
			"A facility from which administrative and/or command functions are performed.");
	public static final FacilityTypeCategoryCode MEDICAL_FACILITY_HOSPITAL = new FacilityTypeCategoryCode(
			"Medical facility, hospital",
			"HSP",
			"A fixed medical treatment facility capable of providing inpatient care.");
	public static final FacilityTypeCategoryCode MEDICAL_FACILITY_HOSPITAL_FIELD = new FacilityTypeCategoryCode(
			"Medical facility, hospital field",
			"HSPFLD",
			"A movable medical treatment facility capable of providing inpatient care.");
	public static final FacilityTypeCategoryCode MEDICAL_FACILITY_HOSPITAL_NOT_OTHERWISE_SPECIFIED = new FacilityTypeCategoryCode(
			"Medical facility, hospital, not otherwise specified",
			"HSPNOS",
			"A facility established for the purpose of furnishing medical and/or dental care to eligible individuals.");
	public static final FacilityTypeCategoryCode HUT = new FacilityTypeCategoryCode(
			"Hut",
			"HUT",
			"A small simple or crude house or shelter.");
	public static final FacilityTypeCategoryCode IMPROVED_BED_TYPE_UNKNOWN = new FacilityTypeCategoryCode(
			"Improved bed, type unknown",
			"IMPBED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final FacilityTypeCategoryCode INDUSTRIAL_INSTALLATION = new FacilityTypeCategoryCode(
			"Industrial installation",
			"INDINS",
			"A facility containing factories and/or productive installations.");
	public static final FacilityTypeCategoryCode INSTALLATION = new FacilityTypeCategoryCode(
			"Installation",
			"INSTAL",
			"A grouping of facilities, located in the same vicinity, which support particular functions. Installations may be elements of a base.");
	public static final FacilityTypeCategoryCode INTELLIGENCE_CENTRE_TACTICAL = new FacilityTypeCategoryCode(
			"Intelligence centre, tactical",
			"INTCTR",
			"A facility, at the tactical level, used by intelligence personnel for intelligence operations.");
	public static final FacilityTypeCategoryCode INTERCHANGE_COMPLEX_JUNCTION = new FacilityTypeCategoryCode(
			"Interchange/complex junction",
			"JCT",
			"A connection designed to provide traffic access from one road to another.");
	public static final FacilityTypeCategoryCode JETTY = new FacilityTypeCategoryCode(
			"Jetty",
			"JETTY",
			"A FACILITY-TYPE that is a platform that may be fixed or floating extending from a shore, normally attached to a wharf or the shore, and which allows access to a vessel lying alongside, used to secure, protect and provide landing and docking for vessels.");
	public static final FacilityTypeCategoryCode LOGISTICS_RELEASE_POINT = new FacilityTypeCategoryCode(
			"Logistics release point",
			"LGRLPT",
			"The facility along the supply route where the supported unit meets the supporting unit to transfer supplies.");
	public static final FacilityTypeCategoryCode LIGHTHOUSE = new FacilityTypeCategoryCode(
			"Lighthouse",
			"LGTHSE",
			"A tower or other structure, with a powerful light or lights at the top, erected at some important or dangerous point on or near the seacoast for the guidance of mariners.");
	public static final FacilityTypeCategoryCode LOADING_PLATFORM = new FacilityTypeCategoryCode(
			"Loading platform",
			"LOADPL",
			"A facility constructed for loading goods/equipment.");
	public static final FacilityTypeCategoryCode LOADING_PLATFORM_MILITARY = new FacilityTypeCategoryCode(
			"Loading platform, military",
			"LOADPM",
			"A facility constructed for loading military goods/equipment.");
	public static final FacilityTypeCategoryCode MAINTENANCE_FACILITY = new FacilityTypeCategoryCode(
			"Maintenance facility",
			"MAINTF",
			"A facility containing the resources and infrastructure to enable it to be used for the repair and servicing of equipment.");
	public static final FacilityTypeCategoryCode MARKET = new FacilityTypeCategoryCode(
			"Market",
			"MARKET",
			"A facility where commercial activity is conducted and goods and services are bought and sold.");
	public static final FacilityTypeCategoryCode MILITARY_BASE_FACILITY_SUBMARINE = new FacilityTypeCategoryCode(
			"Military base/facility, submarine",
			"MBFSUB",
			"A facility that is used as a naval base and where submarines may receive or discharge their cargoes or receive maintenance.");
	public static final FacilityTypeCategoryCode MEDICAL_SUPPORT = new FacilityTypeCategoryCode(
			"Medical support",
			"MEDSPT",
			"A facility that hosts medical personnel who carry out treatment of sick or wounded persons.");
	public static final FacilityTypeCategoryCode METEOROLOGICAL_FACILITY = new FacilityTypeCategoryCode(
			"Meteorological facility",
			"METFAC",
			"A facility that supports the study of or the science of, the motions and phenomena of the atmosphere, with a view to forecasting the weather.");
	public static final FacilityTypeCategoryCode MEDICAL_FACILITY = new FacilityTypeCategoryCode(
			"Medical facility",
			"MF",
			"A facility used as a medical facility.");
	public static final FacilityTypeCategoryCode MEDICAL_FACILITY_UNIT_MEDICAL_STATION = new FacilityTypeCategoryCode(
			"Medical facility, unit medical station",
			"MFUMS",
			"A facility used as a first level care medical facility for a unit.");
	public static final FacilityTypeCategoryCode MILITARY_OBSTACLE_TYPE = new FacilityTypeCategoryCode(
			"MILITARY-OBSTACLE-TYPE",
			"MILOBS",
			"A FACILITY-TYPE that is a class of man-made devices or passive defence works that are designed to stop, impede, or divert movement of amphibious or ground forces.");
	public static final FacilityTypeCategoryCode MINE = new FacilityTypeCategoryCode(
			"Mine",
			"MINE",
			"A facility where materials are extracted from the ground.");
	public static final FacilityTypeCategoryCode MUNITIONS_COMPLEX = new FacilityTypeCategoryCode(
			"Munitions complex",
			"MNCPLX",
			"A facility that could be used for munitions and explosives production or storage.");
	public static final FacilityTypeCategoryCode MINING_INSTALLATION_OPEN_SKY = new FacilityTypeCategoryCode(
			"Mining installation, open sky",
			"MNINOS",
			"A facility where materials are extracted from the ground directly, without using tunnels.");
	public static final FacilityTypeCategoryCode MINING_INSTALLATION_UNDERGROUND = new FacilityTypeCategoryCode(
			"Mining installation, underground",
			"MNINUG",
			"A facility where materials are extracted from the ground using underground tunnels and shafts.");
	public static final FacilityTypeCategoryCode MINING_INSTALLATION_UNDERWATER = new FacilityTypeCategoryCode(
			"Mining installation, underwater",
			"MNINUW",
			"A facility where materials are extracted from the bottom of a lake, river or sea.");
	public static final FacilityTypeCategoryCode MAINTENANCE_COLLECTION_POINT = new FacilityTypeCategoryCode(
			"Maintenance collection point",
			"MNTCPT",
			"A facility established to collect equipment awaiting repair, controlled exchange, cannibalisation or evacuation. May be operated by the user or by intermediate maintenance units.");
	public static final FacilityTypeCategoryCode MONUMENT = new FacilityTypeCategoryCode(
			"Monument",
			"MONUM",
			"A structure generally created for commemorative purposes.");
	public static final FacilityTypeCategoryCode MISSILE_SITE = new FacilityTypeCategoryCode(
			"Missile site",
			"MSS",
			"An area with related facilities for storing and launching missiles.");
	public static final FacilityTypeCategoryCode MASS_GRAVE = new FacilityTypeCategoryCode(
			"Mass grave",
			"MSSGRV",
			"A FACILITY-TYPE used for the burial of multiple bodies.");
	public static final FacilityTypeCategoryCode MAINTENANCE_FACILITY_ARMOUR_ARTILLERY = new FacilityTypeCategoryCode(
			"Maintenance facility, armour/artillery",
			"MTFAAR",
			"A facility containing the resources and infrastructure to enable it to be used for the repair and servicing of armour/artillery equipment.");
	public static final FacilityTypeCategoryCode MAINTENANCE_FACILITY_AIRCRAFT = new FacilityTypeCategoryCode(
			"Maintenance facility, aircraft",
			"MTFAIR",
			"A facility containing the resources and infrastructure to enable it to be used for the repair and servicing of aircraft.");
	public static final FacilityTypeCategoryCode MAINTENANCE_FACILITY_MOTOR_VEHICLE = new FacilityTypeCategoryCode(
			"Maintenance facility, motor vehicle",
			"MTFMVH",
			"A facility containing the resources and infrastructure to enable it to be used for the repair and servicing of motor vehicles.");
	public static final FacilityTypeCategoryCode MOTORWAY = new FacilityTypeCategoryCode(
			"Motorway",
			"MWY",
			"An open, broad way, often with shoulders and barriers, maintained for vehicular use.");
	public static final FacilityTypeCategoryCode NAVAL_AIR_STATION = new FacilityTypeCategoryCode(
			"Naval air station",
			"NAVAST",
			"A Naval facility that is used by and provides services for naval or other aviation units or organisations.");
	public static final FacilityTypeCategoryCode NUCLEAR_FACILITY = new FacilityTypeCategoryCode(
			"Nuclear facility",
			"NCLFAC",
			"An installation with associated buildings capable of handling civilian or military nuclear material.");
	public static final FacilityTypeCategoryCode NETWORK = new FacilityTypeCategoryCode(
			"Network",
			"NETWRK",
			"A FACILITY-TYPE that provides communication and information services.");
	public static final FacilityTypeCategoryCode NOT_KNOWN = new FacilityTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FacilityTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new FacilityTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final FacilityTypeCategoryCode OBSERVATION_POST = new FacilityTypeCategoryCode(
			"Observation post",
			"OBSP",
			"A facility from which military observations are made or fires directed and adjusted and which possesses appropriate communications; it may be airborne.");
	public static final FacilityTypeCategoryCode OBSERVATION_TOWER = new FacilityTypeCategoryCode(
			"Observation tower",
			"OBSTWR",
			"A position from which military observations are made, or fire directed and adjusted, and which possesses appropriate communications.");
	public static final FacilityTypeCategoryCode OFFICE = new FacilityTypeCategoryCode(
			"Office",
			"OFFICE",
			"A place in which business, professional or clerical activities are conducted.");
	public static final FacilityTypeCategoryCode OMNIRANGE_STATION = new FacilityTypeCategoryCode(
			"Omnirange station",
			"OMNIST",
			"A facility used for non-directional radio transmissions.");
	public static final FacilityTypeCategoryCode ORCHARD_PLANTATION = new FacilityTypeCategoryCode(
			"Orchard/plantation",
			"ORD",
			"An area covered by systematic plantings of trees that yield fruits, nuts or other products.");
	public static final FacilityTypeCategoryCode PASSENGER_TERMINAL = new FacilityTypeCategoryCode(
			"Passenger terminal",
			"PASTRM",
			"A facility that provides transportation services for passengers.");
	public static final FacilityTypeCategoryCode PETROCHEMICAL_REFINERY = new FacilityTypeCategoryCode(
			"Petrochemical refinery",
			"PCHREF",
			"Installations for refining crude oil and/or intermediate petroleum products or for refining synthetic petroleum.");
	public static final FacilityTypeCategoryCode PERSONNEL_BARRIER = new FacilityTypeCategoryCode(
			"Personnel barrier",
			"PERSBR",
			"A coordinated series of obstacles designed or employed to detect, channel, direct, restrict, delay or stop the movement of personnel.");
	public static final FacilityTypeCategoryCode PIER = new FacilityTypeCategoryCode(
			"Pier",
			"PIER",
			"A solid structure of stone, or of earth faced with piles, extending into the sea or a tidal river to protect or partially enclose a harbour and form a landing place for vessels, or a breakwater.");
	public static final FacilityTypeCategoryCode PIPELINE = new FacilityTypeCategoryCode(
			"Pipeline",
			"PIPLIN",
			"A system of pipes above or under ground including their supports, which transports liquids or gas over distance.");
	public static final FacilityTypeCategoryCode PUMPING_STATION = new FacilityTypeCategoryCode(
			"Pumping station",
			"PMPSTN",
			"A facility that supports the movement of gases or liquids.");
	public static final FacilityTypeCategoryCode POL_POINT = new FacilityTypeCategoryCode(
			"POL point",
			"POLPT",
			"A facility for the distribution of petroleum and associated products.");
	public static final FacilityTypeCategoryCode POLICE_STATION = new FacilityTypeCategoryCode(
			"Police station",
			"POLSTA",
			"The office of a local police force.");
	public static final FacilityTypeCategoryCode PORT = new FacilityTypeCategoryCode(
			"Port",
			"PORT",
			"A town or place possessing a harbour where vessels load and unload, or begin or end their voyage.");
	public static final FacilityTypeCategoryCode PRISONER_OF_WAR_HOLDING_AREA = new FacilityTypeCategoryCode(
			"Prisoner of war holding area",
			"POWARE",
			"A facility where Prisoners of war are provided custodial care pending further disposition.");
	public static final FacilityTypeCategoryCode POW_CAMP = new FacilityTypeCategoryCode(
			"POW camp",
			"POWCMP",
			"A camp of semi-permanent nature established for the internment of prisoners of war (POW).");
	public static final FacilityTypeCategoryCode PRISONER_OF_WAR_COLLECTION_POINT = new FacilityTypeCategoryCode(
			"Prisoner of war collection point",
			"POWCPT",
			"A facility where Prisoners of war are assembled for classification, sorting or further movement to other facilities or installations.");
	public static final FacilityTypeCategoryCode PRODUCTION_COMPLEX_AIRCRAFT = new FacilityTypeCategoryCode(
			"Production complex, aircraft",
			"PRCXAC",
			"A facility used for aircraft production.");
	public static final FacilityTypeCategoryCode PRODUCTION_COMPLEX_CHEMICAL = new FacilityTypeCategoryCode(
			"Production complex, chemical",
			"PRCXCH",
			"A facility used for production of chemicals.");
	public static final FacilityTypeCategoryCode PRODUCTION_COMPLEX_GUIDED_MISSILE = new FacilityTypeCategoryCode(
			"Production complex, guided missile",
			"PRCXGM",
			"A facility used for production of guided missiles.");
	public static final FacilityTypeCategoryCode PRODUCTION_COMPLEX_GENERAL_MOTOR_VEHICLE = new FacilityTypeCategoryCode(
			"Production complex, general motor vehicle",
			"PRCXMV",
			"A facility used for non-military motor vehicle production and assembly.");
	public static final FacilityTypeCategoryCode PRODUCTION_COMPLEX_PETROLEUM = new FacilityTypeCategoryCode(
			"Production complex, petroleum",
			"PRCXPT",
			"A facility used for petroleum based products production.");
	public static final FacilityTypeCategoryCode POWER_TRANSMISSION_LINE = new FacilityTypeCategoryCode(
			"Power transmission line",
			"PTL",
			"A system of above ground wires including their supports, which transmit electricity over distance.");
	public static final FacilityTypeCategoryCode POWER_PLANT_FOSSIL_FUEL = new FacilityTypeCategoryCode(
			"Power plant, fossil fuel",
			"PWPLFF",
			"A facility that provides power produced from fossil fuels.");
	public static final FacilityTypeCategoryCode POWER_PLANT_HYDROELECTRIC = new FacilityTypeCategoryCode(
			"Power plant, hydroelectric",
			"PWPLHL",
			"A facility that provides power produced from hydroelectric processes.");
	public static final FacilityTypeCategoryCode POWER_PLANT_NUCLEAR = new FacilityTypeCategoryCode(
			"Power plant, nuclear",
			"PWPLNC",
			"A facility that provides power produced from nuclear energy.");
	public static final FacilityTypeCategoryCode POWER_PLANT_THERMAL = new FacilityTypeCategoryCode(
			"Power plant, thermal",
			"PWPLTH",
			"A facility that provides power produced from thermal processes.");
	public static final FacilityTypeCategoryCode QUAY = new FacilityTypeCategoryCode(
			"Quay",
			"QUAY",
			"A FACILITY-TYPE that is a solidly constructed platform, usually parallel to the shoreline of navigable water, alongside which a vessel can be docked or berthed and, on which, the vessel can be accessed and cargo can be loaded or unloaded on one side of the vessel only.");
	public static final FacilityTypeCategoryCode RAIL_FACILITIES = new FacilityTypeCategoryCode(
			"Rail facilities",
			"RAIL",
			"An installation on a railway where loads may be transferred between trains and other means of transport.");
	public static final FacilityTypeCategoryCode RAILHEAD = new FacilityTypeCategoryCode(
			"Railhead",
			"RAILHD",
			"The point on a railway from which branch-line or road transport of supplies begins.");
	public static final FacilityTypeCategoryCode RAILWAY = new FacilityTypeCategoryCode(
			"Railway",
			"RAILWY",
			"A rail or set of parallel rails on which a train or tram runs.");
	public static final FacilityTypeCategoryCode ROAD_JUNCTION = new FacilityTypeCategoryCode(
			"Road, junction",
			"RDJNCT",
			"A site where two or more roads join or form a connection.");
	public static final FacilityTypeCategoryCode RADAR_HEAD = new FacilityTypeCategoryCode(
			"Radar head",
			"RDRHD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final FacilityTypeCategoryCode RADAR_POST = new FacilityTypeCategoryCode(
			"Radar post",
			"RDRPST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final FacilityTypeCategoryCode REFUGEE_HOLDING_AREA = new FacilityTypeCategoryCode(
			"Refugee holding area",
			"REFARE",
			"A facility where refugees are assembled for classification, sorting or further movement to other facilities or installations.");
	public static final FacilityTypeCategoryCode RELAY_FACILITY = new FacilityTypeCategoryCode(
			"Relay facility",
			"RELAY",
			"An installation organised, equipped, and located for the purpose of extending the coverage of electronic communications and detection.");
	public static final FacilityTypeCategoryCode RELIGIOUS_FACILITY = new FacilityTypeCategoryCode(
			"Religious facility",
			"RELFAC",
			"An ecclesiastical facility established for the purpose of worship and prayer.");
	public static final FacilityTypeCategoryCode RESERVOIR = new FacilityTypeCategoryCode(
			"Reservoir",
			"RES",
			"A man-made open enclosure or area formed for the storage of water.");
	public static final FacilityTypeCategoryCode REVETMENT = new FacilityTypeCategoryCode(
			"Revetment",
			"REVETM",
			"An embankment to provide shelter (as against bomb splinters or strafing).");
	public static final FacilityTypeCategoryCode RAIL_FACILITY_REPAIR = new FacilityTypeCategoryCode(
			"Rail facility, repair",
			"RFAREP",
			"An installation on a railway where railway equipment may be repaired.");
	public static final FacilityTypeCategoryCode ROAD = new FacilityTypeCategoryCode(
			"Road",
			"ROAD",
			"An open way maintained for vehicular use.");
	public static final FacilityTypeCategoryCode REFUEL_ON_THE_MOVE_POINT = new FacilityTypeCategoryCode(
			"Refuel on the move point",
			"ROMPT",
			"A facility where vehicles receive a prescribed (timed) amount of fuel and then continue their movement.");
	public static final FacilityTypeCategoryCode ROW_HOUSE = new FacilityTypeCategoryCode(
			"Row house",
			"ROWHSE",
			"Facilities of a type that represent individual houses sharing at least one wall.");
	public static final FacilityTypeCategoryCode REARM_REFUEL_AND_RESUPPLY_POINT = new FacilityTypeCategoryCode(
			"Rearm, refuel and resupply point",
			"RRRSPT",
			"A designated facility through which a unit passes where it receives fuel, ammunition, and other necessary supplies to continue combat operations.");
	public static final FacilityTypeCategoryCode RUINS = new FacilityTypeCategoryCode(
			"Ruins",
			"RUI",
			"A site or location where remains of ancient civilisations or human activity have been discovered.");
	public static final FacilityTypeCategoryCode RAILWAY_CROSSING = new FacilityTypeCategoryCode(
			"Railway crossing",
			"RWCRSS",
			"A predefined place at which a railway may be crossed at the same level by a road.");
	public static final FacilityTypeCategoryCode RAILWAY_JUNCTION = new FacilityTypeCategoryCode(
			"Railway, junction",
			"RWJNCT",
			"A site where two or more railway tracks join or form a connection.");
	public static final FacilityTypeCategoryCode SCHOOL = new FacilityTypeCategoryCode(
			"School",
			"SCHOOL",
			"A facility whose essential function is instruction and education.");
	public static final FacilityTypeCategoryCode SENSOR_OUTPOST_LISTENING_POST = new FacilityTypeCategoryCode(
			"Sensor outpost/listening post",
			"SENPST",
			"A facility from which military observations are made or fires directed and adjusted and which possesses appropriate communications; it may be airborne. This is an unmanned Observation Post with electronic or other devices to detect activity within the sensors� range.");
	public static final FacilityTypeCategoryCode SHED = new FacilityTypeCategoryCode(
			"Shed",
			"SHD",
			"A storage facility usually characterised by one or more open sides, support pillars and a roof.");
	public static final FacilityTypeCategoryCode SHELTER_SURFACE = new FacilityTypeCategoryCode(
			"Shelter, surface",
			"SHLSUR",
			"A fortified structure built on the surface, used to house personnel and/or equipment.");
	public static final FacilityTypeCategoryCode SHELTER_UNDERGROUND = new FacilityTypeCategoryCode(
			"Shelter, underground",
			"SHLUND",
			"A fortified structure built underground, used to house personnel and/or equipment.");
	public static final FacilityTypeCategoryCode SHOP = new FacilityTypeCategoryCode(
			"Shop",
			"SHOP",
			"A small retail store or a speciality department in a large store.");
	public static final FacilityTypeCategoryCode SHORAN_STATION = new FacilityTypeCategoryCode(
			"Shoran station",
			"SHORAN",
			"A facility used in short range navigation.");
	public static final FacilityTypeCategoryCode SHIPYARD = new FacilityTypeCategoryCode(
			"Shipyard",
			"SHYARD",
			"A large enclosure, adjoining the sea or a river, in which ships are built, repaired or maintained.");
	public static final FacilityTypeCategoryCode SITE_AIR_DEFENCE_RADAR = new FacilityTypeCategoryCode(
			"Site, air-defence radar",
			"SITADR",
			"A facility containing radar employed for air-defence purposes.");
	public static final FacilityTypeCategoryCode SITE_ARTILLERY_LOCATING = new FacilityTypeCategoryCode(
			"Site, artillery locating",
			"SITART",
			"A facility containing equipment employed for locating artillery.");
	public static final FacilityTypeCategoryCode SITE_ELECTRONIC_WARFARE = new FacilityTypeCategoryCode(
			"Site, electronic warfare",
			"SITEEW",
			"A facility that carries out Electronic Warfare.");
	public static final FacilityTypeCategoryCode SITE_GROUND_SURVEILLANCE_RADAR = new FacilityTypeCategoryCode(
			"Site, ground surveillance radar",
			"SITGSR",
			"A facility containing radar employed for ground surveillance purposes.");
	public static final FacilityTypeCategoryCode SITE_LOGISTIC = new FacilityTypeCategoryCode(
			"Site, logistic",
			"SITLOG",
			"A facility for the storage, maintenance, research, or disposal of material.");
	public static final FacilityTypeCategoryCode SITE_MILITARY_BRIDGING = new FacilityTypeCategoryCode(
			"Site, military bridging",
			"SITMLB",
			"A facility that is used as a basis for military bridging.");
	public static final FacilityTypeCategoryCode SITE_RADAR = new FacilityTypeCategoryCode(
			"Site, radar",
			"SITRAD",
			"A facility containing radar that may be employed for the tracking and identification of battlespace objects.");
	public static final FacilityTypeCategoryCode SITE_RAFT = new FacilityTypeCategoryCode(
			"Site, raft",
			"SITRFT",
			"No definition provided in APP-6A.");
	public static final FacilityTypeCategoryCode SLIPWAY = new FacilityTypeCategoryCode(
			"Slipway",
			"SLPWAY",
			"A FACILITY-TYPE that provides a sloping surface or inclined structure leading down to the water.");
	public static final FacilityTypeCategoryCode SENSOR_FUSION_POST = new FacilityTypeCategoryCode(
			"Sensor fusion post",
			"SNSRFP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final FacilityTypeCategoryCode SITE_NAVIGATION_RADAR = new FacilityTypeCategoryCode(
			"Site, navigation radar",
			"SNVRDR",
			"A facility containing radar employed for navigation purposes.");
	public static final FacilityTypeCategoryCode SUPPORT_AREA = new FacilityTypeCategoryCode(
			"Support area",
			"SPTARE",
			"A facility in which combat services support (CSS) elements and some staff elements locate to support a unit.");
	public static final FacilityTypeCategoryCode STATION_GENERAL = new FacilityTypeCategoryCode(
			"Station, general",
			"STN",
			"A stopping place for the transfer of passengers and/or freight.");
	public static final FacilityTypeCategoryCode STEEPLE_SPIRE = new FacilityTypeCategoryCode(
			"Steeple/spire",
			"STP",
			"In architecture, a steeply pointed pyramidal or conical structure usually attached to an ecclesiastical or public building.");
	public static final FacilityTypeCategoryCode SITE_SURFACE_TO_SURFACE_MISSILE = new FacilityTypeCategoryCode(
			"Site, surface to surface missile",
			"STSSML",
			"An installation dedicated to the storage and launch of surface-to-surface missiles.");
	public static final FacilityTypeCategoryCode SUPPLY_DUMP_AMMUNITION = new FacilityTypeCategoryCode(
			"Supply dump, ammunition",
			"SUPDAM",
			"A temporary storage area, usually in the open, for ammunition.");
	public static final FacilityTypeCategoryCode SUPPLY_DUMP = new FacilityTypeCategoryCode(
			"Supply dump",
			"SUPDMP",
			"A temporary storage area, usually in the open, for bombs, ammunition, equipment, or supplies.");
	public static final FacilityTypeCategoryCode SUPPLY_POINT = new FacilityTypeCategoryCode(
			"Supply point",
			"SUPPT",
			"A facility where supply services are provided.");
	public static final FacilityTypeCategoryCode SEWAGE_TREATMENT_FACILITY = new FacilityTypeCategoryCode(
			"Sewage treatment facility",
			"SWGFAC",
			"A facility used for the handling and treatment of sewage.");
	public static final FacilityTypeCategoryCode TACAN_STATION = new FacilityTypeCategoryCode(
			"Tacan station",
			"TACAN",
			"A facility used in a global tactical air navigation system.");
	public static final FacilityTypeCategoryCode TRENCH = new FacilityTypeCategoryCode(
			"Trench",
			"TCH",
			"A linear excavation dug for defensive purposes.");
	public static final FacilityTypeCategoryCode TOWER_NON_COMMUNICATIONS = new FacilityTypeCategoryCode(
			"Tower, non-communications",
			"TOW",
			"A relatively tall structure which may be used for observation, support, or storage etc.");
	public static final FacilityTypeCategoryCode TOWN = new FacilityTypeCategoryCode(
			"Town",
			"TOWN",
			"An urban area with a name, defined boundaries and local government, being larger than a village and generally smaller than a city.");
	public static final FacilityTypeCategoryCode TRAIL = new FacilityTypeCategoryCode(
			"Trail",
			"TRAIL",
			"A beaten path, especially through a wild region.");
	public static final FacilityTypeCategoryCode TRANSLOADING_FACILITY = new FacilityTypeCategoryCode(
			"Transloading facility",
			"TRANSF",
			"Enables transfer of materiel from one mode of transportation to another or between the same modes of transportation.");
	public static final FacilityTypeCategoryCode TRAFFIC_CONTROL_POST = new FacilityTypeCategoryCode(
			"Traffic control post",
			"TRFPST",
			"A facility at which traffic is controlled either by police or by mechanical means.");
	public static final FacilityTypeCategoryCode TUNNEL = new FacilityTypeCategoryCode(
			"Tunnel",
			"TUN",
			"An underground or underwater passage, open at both ends, and usually containing a road or railway.");
	public static final FacilityTypeCategoryCode TOWER_FLAK = new FacilityTypeCategoryCode(
			"Tower, flak",
			"TWFLAK",
			"A relatively tall structure mounted with an anti-aircraft gun.");
	public static final FacilityTypeCategoryCode TOWN_HALL = new FacilityTypeCategoryCode(
			"Town hall",
			"TWNHAL",
			"A building for the administration of local government, having public meeting rooms, etc.");
	public static final FacilityTypeCategoryCode TOWER_TELEVISION_TRANSMITTER = new FacilityTypeCategoryCode(
			"Tower, television transmitter",
			"TWTLTM",
			"A relatively tall structure mounted with a television transmitter.");
	public static final FacilityTypeCategoryCode URBAN_AREA = new FacilityTypeCategoryCode(
			"Urban area",
			"URBANA",
			"A developed area, constituting, forming, or including a city, town, or burgh, or part of such.");
	public static final FacilityTypeCategoryCode VILLAGE = new FacilityTypeCategoryCode(
			"Village",
			"VLLAGE",
			"A group of houses and associated buildings, larger than a hamlet and smaller than a town, especially in a rural area.");
	public static final FacilityTypeCategoryCode VEHICLE_STORAGE_PARKING_AREA = new FacilityTypeCategoryCode(
			"Vehicle storage/parking area",
			"VST",
			"An open land area used for storing or parking vehicles or vessels. (Including Recreational Vehicles).");
	public static final FacilityTypeCategoryCode WALL = new FacilityTypeCategoryCode(
			"Wall",
			"WALL",
			"A continuous, vertical structure, such as a concrete or rock wall serving to enclose, divide, support or protect an area of land. Includes sea walls.");
	public static final FacilityTypeCategoryCode WAREHOUSE = new FacilityTypeCategoryCode(
			"Warehouse",
			"WAREHS",
			"A facility for the receipt, classification, storage, accounting, issue, maintenance, procurement, manufacture, assembly, research, salvage or disposal of material.");
	public static final FacilityTypeCategoryCode WATER_SUPPLY = new FacilityTypeCategoryCode(
			"Water supply",
			"WATSPL",
			"A facility containing the equipment used for the storage and/or distribution of water.");
	public static final FacilityTypeCategoryCode WINDMILL = new FacilityTypeCategoryCode(
			"Windmill",
			"WML",
			"A wind-driven system of vanes attached to a tower-like structure (excluding wind-generated power plants).");
	public static final FacilityTypeCategoryCode WORSHIP_PLACE = new FacilityTypeCategoryCode(
			"Worship place",
			"WRSHPL",
			"A building or open space where people assemble for religious purpose.");
	public static final FacilityTypeCategoryCode WASHING_FACILITY = new FacilityTypeCategoryCode(
			"Washing facility",
			"WSHFAC",
			"A facility for washing personnel and/or equipment.");
	public static final FacilityTypeCategoryCode WASTE_PILE = new FacilityTypeCategoryCode(
			"Waste pile",
			"WSTPLE",
			"Unusable or unwanted material, which may include hazardous materiel.");
	public static final FacilityTypeCategoryCode WATER_TREATMENT_FACILITY = new FacilityTypeCategoryCode(
			"Water treatment facility",
			"WTRFAC",
			"A facility used for the handling and treatment of water.");
	public static final FacilityTypeCategoryCode WATER_TOWER = new FacilityTypeCategoryCode(
			"Water tower",
			"WTW",
			"An elevated container and its supporting structure used to hold water.");
	public static final FacilityTypeCategoryCode CROSSING_LEVEL_CROSSING = new FacilityTypeCategoryCode(
			"Crossing/level crossing",
			"XLC",
			"A facility that is a point where two or more line features intersect or cross at the same level.");
	public static final FacilityTypeCategoryCode CROSSING_RAILWAY_RIVER = new FacilityTypeCategoryCode(
			"Crossing, railway/river",
			"XRR",
			"A facility where railway track crosses a highway or street, or where a river can be crossed.");

	private FacilityTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
