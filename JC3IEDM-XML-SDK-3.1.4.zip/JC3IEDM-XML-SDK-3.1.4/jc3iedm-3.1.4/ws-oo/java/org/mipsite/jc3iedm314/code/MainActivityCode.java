/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MainActivityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the main activity of an ORGANISATION-TYPE.";
	}

	private static HashMap<String, MainActivityCode> physicalToCode = new HashMap<String, MainActivityCode>();

	public static MainActivityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MainActivityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MainActivityCode AGRICULTURE_PROGRAMS = new MainActivityCode(
			"Agriculture programs",
			"AGRCPR",
			"The activity that deals with providing agriculture services.");
	public static final MainActivityCode EDUCATION_PROGRAMS = new MainActivityCode(
			"Education programs",
			"EDUCPR",
			"The activity that deals with providing education services.");
	public static final MainActivityCode FOOD_PROGRAMS = new MainActivityCode(
			"Food programs",
			"FOODPR",
			"The activity that deals with distribution of food.");
	public static final MainActivityCode HEALTH_PROGRAMS = new MainActivityCode(
			"Health programs",
			"HLTHPR",
			"The activity that deals with providing health care services.");
	public static final MainActivityCode INFRASTRUCTURE_AND_CONSTRUCTION_REPAIR_PROGRAMS = new MainActivityCode(
			"Infrastructure and construction repair programs",
			"INFSPR",
			"The activity that deals with providing infrastructure and construction repair services.");
	public static final MainActivityCode NOT_OTHERWISE_SPECIFIED = new MainActivityCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MainActivityCode SOCIAL_PROGRAMS = new MainActivityCode(
			"Social programs",
			"SOCLPR",
			"The activity that deals with providing social programs.");

	private MainActivityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
