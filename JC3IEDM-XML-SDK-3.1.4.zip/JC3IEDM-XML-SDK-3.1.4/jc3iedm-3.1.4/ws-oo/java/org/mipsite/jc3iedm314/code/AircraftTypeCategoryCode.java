/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeCategoryCode> physicalToCode = new HashMap<String, AircraftTypeCategoryCode>();

	public static AircraftTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeCategoryCode ROTARY_WING = new AircraftTypeCategoryCode(
			"Rotary wing",
			"AIRRW",
			"A machine or device capable of atmospheric flight and dependent on rotating blades for lift.");
	public static final AircraftTypeCategoryCode FIXED_WING = new AircraftTypeCategoryCode(
			"Fixed wing",
			"FIXWNG",
			"A machine or device capable of atmospheric flight and dependent on wings for lift.");
	public static final AircraftTypeCategoryCode LIGHTER_THAN_AIR = new AircraftTypeCategoryCode(
			"Lighter than air",
			"LGTAIR",
			"A machine or device capable of atmospheric flight weighing less than the air it displaces.");
	public static final AircraftTypeCategoryCode NOT_KNOWN = new AircraftTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AircraftTypeCategoryCode SPACE_VEHICLE = new AircraftTypeCategoryCode(
			"Space vehicle",
			"SPACEM",
			"An aircraft capable of operating in the region beyond the earth�s atmosphere.");

	private AircraftTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
