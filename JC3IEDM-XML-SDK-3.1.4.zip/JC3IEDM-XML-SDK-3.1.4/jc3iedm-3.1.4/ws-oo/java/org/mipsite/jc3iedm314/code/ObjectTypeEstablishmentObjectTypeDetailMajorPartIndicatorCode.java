/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether a detail is a �major part� when the established and detail OBJECT-TYPEs are instances of MATERIEL-TYPE.";
	}

	private static HashMap<String, ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode> physicalToCode = new HashMap<String, ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode>();

	public static ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode NO = new ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode(
			"No",
			"NO",
			"An indication that the MATERIEL-TYPE specified as the detail of the OBJECT-TYPE-ESTABLISHMENT is not designated as a major part.");
	public static final ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode YES = new ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode(
			"Yes",
			"YES",
			"An indication that the MATERIEL-TYPE specified as the detail of the OBJECT-TYPE-ESTABLISHMENT is designated as a major part.");

	private ObjectTypeEstablishmentObjectTypeDetailMajorPartIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
