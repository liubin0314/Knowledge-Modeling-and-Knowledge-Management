/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkCapacityProtocolCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents an application-level (OSI model level 3 to 7) protocol governing the information transfer in a NETWORK.";
	}

	private static HashMap<String, NetworkCapacityProtocolCode> physicalToCode = new HashMap<String, NetworkCapacityProtocolCode>();

	public static NetworkCapacityProtocolCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkCapacityProtocolCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkCapacityProtocolCode APPLETALK = new NetworkCapacityProtocolCode(
			"Appletalk",
			"APLTLK",
			"Apple networks protocol suite.");
	public static final NetworkCapacityProtocolCode ATM = new NetworkCapacityProtocolCode(
			"ATM",
			"ATM",
			"The protocol used within ATM (Asynchronous Transfer Mode) based networks.");
	public static final NetworkCapacityProtocolCode DECNET = new NetworkCapacityProtocolCode(
			"DECnet",
			"DECNET",
			"Digital Equipment�s proprietary protocol suite.");
	public static final NetworkCapacityProtocolCode HAVE_QUICK = new NetworkCapacityProtocolCode(
			"HAVE QUICK",
			"HVQCK",
			"The protocol used within HAVE QUICK networks.");
	public static final NetworkCapacityProtocolCode HAVE_QUICK2 = new NetworkCapacityProtocolCode(
			"HAVE QUICK2",
			"HVQCK2",
			"The protocol used within HAVE QUICK2 networks.");
	public static final NetworkCapacityProtocolCode IPV6 = new NetworkCapacityProtocolCode(
			"IPv6",
			"IPV6",
			"The protocol used within IPv6 (Internet Protocol Version 6) wide area networks.");
	public static final NetworkCapacityProtocolCode IPX_SPX = new NetworkCapacityProtocolCode(
			"IPX/SPX",
			"IPXSPX",
			"Novell networks protocol suite.");
	public static final NetworkCapacityProtocolCode MIDS = new NetworkCapacityProtocolCode(
			"MIDS",
			"MIDS",
			"The protocol used within MIDS (Multi-functional Information Distribution System) networks.");
	public static final NetworkCapacityProtocolCode NETBEUI = new NetworkCapacityProtocolCode(
			"NetBEUI",
			"NETBEU",
			"Microsoft networks protocol suite.");
	public static final NetworkCapacityProtocolCode NOT_OTHERWISE_SPECIFIED = new NetworkCapacityProtocolCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkCapacityProtocolCode OSI = new NetworkCapacityProtocolCode(
			"OSI",
			"OSI",
			"An OSI 7-layer model compatible protocol suite.");
	public static final NetworkCapacityProtocolCode SNA = new NetworkCapacityProtocolCode(
			"SNA",
			"SNA",
			"An SNA layer model compatible protocol suite.");
	public static final NetworkCapacityProtocolCode TCP_IP = new NetworkCapacityProtocolCode(
			"TCP/IP",
			"TCPIP",
			"The protocol used within TCP/IP (Transfer Control Protocol/Internet Protocol) wide area networks.");
	public static final NetworkCapacityProtocolCode UDP = new NetworkCapacityProtocolCode(
			"UDP",
			"UDP",
			"The protocol used within UDP (User Datagram Protocol) wide area networks.");
	public static final NetworkCapacityProtocolCode X25 = new NetworkCapacityProtocolCode(
			"X25",
			"X25",
			"The protocol used within ISO standard X25 based networks.");
	public static final NetworkCapacityProtocolCode X400 = new NetworkCapacityProtocolCode(
			"X400",
			"X400",
			"The protocol used within ISO standard X400 based networks.");

	private NetworkCapacityProtocolCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
