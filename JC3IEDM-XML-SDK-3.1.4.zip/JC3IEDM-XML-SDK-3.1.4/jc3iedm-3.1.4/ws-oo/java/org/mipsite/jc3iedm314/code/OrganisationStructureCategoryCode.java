/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStructureCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of the ORGANISATION-STRUCTURE.";
	}

	private static HashMap<String, OrganisationStructureCategoryCode> physicalToCode = new HashMap<String, OrganisationStructureCategoryCode>();

	public static OrganisationStructureCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStructureCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStructureCategoryCode NOT_OTHERWISE_SPECIFIED = new OrganisationStructureCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final OrganisationStructureCategoryCode ORDER_OF_BATTLE = new OrganisationStructureCategoryCode(
			"Order of battle",
			"ORBAT",
			"An organisational structure representing an ORBAT");
	public static final OrganisationStructureCategoryCode TASK_ORGANISATION = new OrganisationStructureCategoryCode(
			"Task organisation",
			"TSKORG",
			"An organisational structure representing a Taskorg.");

	private OrganisationStructureCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
