/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceContentCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the classification of the general content of the artefact cited in a specific REFERENCE.";
	}

	private static HashMap<String, ReferenceContentCategoryCode> physicalToCode = new HashMap<String, ReferenceContentCategoryCode>();

	public static ReferenceContentCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceContentCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceContentCategoryCode ADMINISTRATIVE_DOCUMENT = new ReferenceContentCategoryCode(
			"Administrative document",
			"ADMDOC",
			"The artefact cited in the specific REFERENCE provides administrative information.");
	public static final ReferenceContentCategoryCode AUTHORISATION = new ReferenceContentCategoryCode(
			"Authorisation",
			"AUTHRS",
			"The artefact cited in the specific REFERENCE constitutes an authorising document.");
	public static final ReferenceContentCategoryCode CERTIFICATE = new ReferenceContentCategoryCode(
			"Certificate",
			"CERTFC",
			"The artefact cited in the specific REFERENCE is an official document authorised for a specific use.");
	public static final ReferenceContentCategoryCode DIRECTIVE = new ReferenceContentCategoryCode(
			"Directive",
			"DRCTV",
			"The artefact cited in the specific REFERENCE provides compulsory instructions.");
	public static final ReferenceContentCategoryCode GUIDANCE = new ReferenceContentCategoryCode(
			"Guidance",
			"GUIDNC",
			"The artefact cited in the specific REFERENCE provides advisory information.");
	public static final ReferenceContentCategoryCode HISTORICAL_DOCUMENT = new ReferenceContentCategoryCode(
			"Historical document",
			"HISDOC",
			"The artefact cited in the specific REFERENCE records historical information.");
	public static final ReferenceContentCategoryCode HEALTH_DOCUMENT = new ReferenceContentCategoryCode(
			"Health document",
			"HLTDOC",
			"The artefact cited in the specific REFERENCE records medical information.");
	public static final ReferenceContentCategoryCode IDENTIFICATION_DOCUMENT = new ReferenceContentCategoryCode(
			"Identification document",
			"IDDOC",
			"The artefact cited in the specific REFERENCE is an official document to ascertain identity.");
	public static final ReferenceContentCategoryCode INSTRUCTION = new ReferenceContentCategoryCode(
			"Instruction",
			"INSTRC",
			"The artefact cited in the specific REFERENCE provides information to support learning.");
	public static final ReferenceContentCategoryCode LEGAL_DOCUMENT = new ReferenceContentCategoryCode(
			"Legal document",
			"LGLDOC",
			"The artefact cited in the specific REFERENCE records information regarding legal matters.");
	public static final ReferenceContentCategoryCode MAP = new ReferenceContentCategoryCode(
			"Map",
			"MAP",
			"The artefact cited in the specific REFERENCE provides graphic geographic information.");
	public static final ReferenceContentCategoryCode MESSAGE_TEXT_FORMAT = new ReferenceContentCategoryCode(
			"Message text format",
			"MTF",
			"The artefact cited in the specific REFERENCE is composed of several sets ordered in a specified sequence, each set characterized by an identifier and containing information of a specified type, coded and arranged in an ordered sequence of character fields in accordance with the NATO message text formatting rules.");
	public static final ReferenceContentCategoryCode NOT_OTHERWISE_SPECIFIED = new ReferenceContentCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ReferenceContentCategoryCode ORDER = new ReferenceContentCategoryCode(
			"Order",
			"ORDER",
			"The artefact cited in the specific REFERENCE is a document that is directive in nature and generally used within the military sphere.");
	public static final ReferenceContentCategoryCode PERSONNEL_DOCUMENT = new ReferenceContentCategoryCode(
			"Personnel document",
			"PERDOC",
			"The artefact cited in the specific REFERENCE records information regarding matters affecting personnel.");
	public static final ReferenceContentCategoryCode REPORT = new ReferenceContentCategoryCode(
			"Report",
			"REPORT",
			"The artefact cited in the specific REFERENCE is an authoritative account of an event or situation.");
	public static final ReferenceContentCategoryCode STAFF_JOURNAL_LOG = new ReferenceContentCategoryCode(
			"Staff journal/log",
			"STFFJR",
			"The artefact cited in the specific REFERENCE is a detailed account of the activities of a staff.");
	public static final ReferenceContentCategoryCode TECHNICAL_DOCUMENT = new ReferenceContentCategoryCode(
			"Technical document",
			"TECDOC",
			"The artefact cited in the specific REFERENCE provides technical description.");
	public static final ReferenceContentCategoryCode TEMPLATE = new ReferenceContentCategoryCode(
			"Template",
			"TEMPLT",
			"The artefact cited in the specific REFERENCE provides a pre-defined guide.");
	public static final ReferenceContentCategoryCode TEST_DOCUMENT = new ReferenceContentCategoryCode(
			"Test document",
			"TSTDOC",
			"The artefact cited in the specific REFERENCE provides information about test design or test results.");

	private ReferenceContentCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
