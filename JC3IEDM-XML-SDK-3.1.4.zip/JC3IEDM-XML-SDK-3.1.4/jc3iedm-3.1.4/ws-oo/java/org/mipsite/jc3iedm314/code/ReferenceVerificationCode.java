/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceVerificationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the verification of the artefact cited in a specific REFERENCE.";
	}

	private static HashMap<String, ReferenceVerificationCode> physicalToCode = new HashMap<String, ReferenceVerificationCode>();

	public static ReferenceVerificationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceVerificationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceVerificationCode REFERENCE_UNVERIFIED = new ReferenceVerificationCode(
			"Reference unverified",
			"REFUNV",
			"The information provided by the artefact cited in a specific REFERENCE is unverified.");
	public static final ReferenceVerificationCode REFERENCE_VERIFIED = new ReferenceVerificationCode(
			"Reference verified",
			"REFVER",
			"The information provided by the artefact cited in a specific REFERENCE is verified.");
	public static final ReferenceVerificationCode REFERENCE_VERIFICATION_NOT_AVAILABLE = new ReferenceVerificationCode(
			"Reference verification not available",
			"REFVNA",
			"The information on the verification of the REFERENCE provided by the artefact cited in a specific REFERENCE is not available.");

	private ReferenceVerificationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
