/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class QuayContainerHandlingTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of container handling equipment available at a specific QUAY.";
	}

	private static HashMap<String, QuayContainerHandlingTypeCode> physicalToCode = new HashMap<String, QuayContainerHandlingTypeCode>();

	public static QuayContainerHandlingTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<QuayContainerHandlingTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final QuayContainerHandlingTypeCode CONTAINER_STRADDLE_LIFT = new QuayContainerHandlingTypeCode(
			"Container straddle lift",
			"CNTSTR",
			"A freight container lifting frame which straddles a container, is able to lift the container and carry it about inside the frame, can be towed or self-propelled, may have steerable wheels and used for loading, unloading, transportation and stacking of freight containers.");
	public static final QuayContainerHandlingTypeCode EMPTY_CONTAINER_FORKLIFT = new QuayContainerHandlingTypeCode(
			"Empty container forklift",
			"EMPCNT",
			"A forklift truck or tractor for lifting, moving and stacking only empty freight containers.");
	public static final QuayContainerHandlingTypeCode NOT_OTHERWISE_SPECIFIED = new QuayContainerHandlingTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final QuayContainerHandlingTypeCode REACH_STACKER = new QuayContainerHandlingTypeCode(
			"Reach stacker",
			"RCHSTK",
			"A vehicle similar to a forklift tractor with a single boom or arm which moves in a vertical plane with on-top spreader for clamping freight containers, used for moving and stacking fully loaded freight containers.");
	public static final QuayContainerHandlingTypeCode ROUGH_TERRAIN_CONTAINER_HANDLER = new QuayContainerHandlingTypeCode(
			"Rough terrain container handler",
			"RGHTER",
			"A vehicle with an attachment or clamp to the forks in front for lifting and carrying ISO freight containers, used for loading and unloading containers and is designed to be used on rough undulating surface conditions or off-road conditions, all wheels are driven.");
	public static final QuayContainerHandlingTypeCode SHUNTING_TERMINAL_TRACTOR = new QuayContainerHandlingTypeCode(
			"Shunting/terminal tractor",
			"SHNTER",
			"A vehicle used in port operations to move freight containers between a stacking area and a vessel side by means of a towed trailer upon which the container is placed.");
	public static final QuayContainerHandlingTypeCode SHIP_TO_SHORE_CONTAINER_HANDLER_CRANE = new QuayContainerHandlingTypeCode(
			"Ship to shore container handler, crane",
			"SHPTSH",
			"A crane designed with sufficient outreach to load and unload freight container vessels berthed alongside.");

	private QuayContainerHandlingTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
