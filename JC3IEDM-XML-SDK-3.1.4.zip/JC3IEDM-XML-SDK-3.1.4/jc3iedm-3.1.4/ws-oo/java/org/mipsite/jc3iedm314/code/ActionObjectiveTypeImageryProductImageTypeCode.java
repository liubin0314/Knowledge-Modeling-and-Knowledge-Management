/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveTypeImageryProductImageTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the media of transmission and the quality of the photographic product required.";
	}

	private static HashMap<String, ActionObjectiveTypeImageryProductImageTypeCode> physicalToCode = new HashMap<String, ActionObjectiveTypeImageryProductImageTypeCode>();

	public static ActionObjectiveTypeImageryProductImageTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveTypeImageryProductImageTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveTypeImageryProductImageTypeCode _10_X_10_PRINT = new ActionObjectiveTypeImageryProductImageTypeCode(
			"10 x 10 print",
			"10PRNT",
			"Hardcopy 10 by 10 inch imagery product.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode _10_X_12_PRINT = new ActionObjectiveTypeImageryProductImageTypeCode(
			"10 x 12 print",
			"12PRNT",
			"Hardcopy 10 by 12 inch imagery product.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode _8_X_10_PRINT = new ActionObjectiveTypeImageryProductImageTypeCode(
			"8 x 10 print",
			"8PRNT",
			"Hardcopy 8 by 10 inch imagery product.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode ANAGLYPH_PRINT_WITH_VIEWER = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Anaglyph print with viewer",
			"ANPRNT",
			"3-dimensional imagery print with a 3D viewer.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode CD_ROM = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Cd Rom",
			"CDROM",
			"Hardcopy imagery product using a compact disc format.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode CONTACT_PRINT = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Contact print",
			"CNPRNT",
			"A print made from a negative or a diapositive in direct contact with sensitized material.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode DUPE_FILE = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Dupe file",
			"DUPFLE",
			"A file that is an exact duplicate of an original.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode DUPE_NEGATIVE = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Dupe negative",
			"DUPNEG",
			"A duplicate negative reproduced from a negative or a diapositive.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode DUPE_POSITIVE = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Dupe positive",
			"DUPPOS",
			"A positive copy made from the original negative.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode DUPE_TAPE = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Dupe tape",
			"DUPTAP",
			"A tape that is an exact duplicate of an original.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode DVD = new ActionObjectiveTypeImageryProductImageTypeCode(
			"DVD",
			"DVD",
			"Hardcopy imagery product using a DVD format.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode MAX_ENLARGEMENT = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Max enlargement",
			"MAXENL",
			"A photo magnified to the point before the image loses its identity and becomes a random series of tonal impressions.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode MOSAIC = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Mosaic",
			"MOSAIC",
			"An assembly of overlapping photographs that have been matched to form a continuous photographic representation of a portion of the surface of the Earth.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode PLANNING_GRAPHIC = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Planning graphic",
			"PLNGRP",
			"A photo that is prepared for use as a planning graphic.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode SONNE = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Sonne",
			"SONNE",
			"A one to one contact photograph on long rolled paper.");
	public static final ActionObjectiveTypeImageryProductImageTypeCode TARGET_GRAPHIC = new ActionObjectiveTypeImageryProductImageTypeCode(
			"Target graphic",
			"TGTGRP",
			"A photo that is prepared for use as a target graphic.");

	private ActionObjectiveTypeImageryProductImageTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
