/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a subsurface vessel has torpedo loading rails and lifting bands.";
	}

	private static HashMap<String, SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode> physicalToCode = new HashMap<String, SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode>();

	public static SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode NO = new SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode(
			"No",
			"NO",
			"The specific SUBSURFACE-VESSEL-TYPE does not have torpedo loading rails and lifting bands.");
	public static final SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode YES = new SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode(
			"Yes",
			"YES",
			"The specific SUBSURFACE-VESSEL-TYPE has torpedo loading rails and lifting bands.");

	private SubsurfaceVesselTypeTorpedoLoadingGearIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
