/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MATERIEL.";
	}

	private static HashMap<String, MaterielCategoryCode> physicalToCode = new HashMap<String, MaterielCategoryCode>();

	public static MaterielCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielCategoryCode INSTRUMENT_LANDING_SYSTEM = new MaterielCategoryCode(
			"INSTRUMENT-LANDING-SYSTEM",
			"ILS",
			"A MATERIEL that provides aircraft with horizontal and vertical guidance just before landing and during landing, and at certain fixed points, indicates the distance to the reference point of landing.");
	public static final MaterielCategoryCode NOT_OTHERWISE_SPECIFIED = new MaterielCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private MaterielCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
