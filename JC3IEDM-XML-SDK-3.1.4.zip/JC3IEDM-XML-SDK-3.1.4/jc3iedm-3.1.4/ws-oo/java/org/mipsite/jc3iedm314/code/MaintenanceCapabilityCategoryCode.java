/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaintenanceCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MAINTENANCE-CAPABILITY.";
	}

	private static HashMap<String, MaintenanceCapabilityCategoryCode> physicalToCode = new HashMap<String, MaintenanceCapabilityCategoryCode>();

	public static MaintenanceCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaintenanceCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaintenanceCapabilityCategoryCode CABLE = new MaintenanceCapabilityCategoryCode(
			"Cable",
			"CABLE",
			"The specific MAINTENANCE-CAPABILITY determines the ability to provide cable repair.");
	public static final MaintenanceCapabilityCategoryCode ELECTRICAL = new MaintenanceCapabilityCategoryCode(
			"Electrical",
			"ELEC",
			"The specific MAINTENANCE-CAPABILITY determines the ability to provide electrical repair.");
	public static final MaintenanceCapabilityCategoryCode NAVIGATIONAL_EQUIPMENT = new MaintenanceCapabilityCategoryCode(
			"Navigational equipment",
			"NAVGTE",
			"The specific MAINTENANCE-CAPABILITY determines the ability to provide navigational equipment repair.");
	public static final MaintenanceCapabilityCategoryCode PLUMBING = new MaintenanceCapabilityCategoryCode(
			"Plumbing",
			"PLUMBN",
			"Equipment and resources for fitting and repairing pipes, fixtures and other apparatus of a water gas or sewage system belonging to a docked vessel.");
	public static final MaintenanceCapabilityCategoryCode PAINT_SHOP = new MaintenanceCapabilityCategoryCode(
			"Paint shop",
			"PNTSHP",
			"Equipment and resources for painting any part of a docked vessel.");
	public static final MaintenanceCapabilityCategoryCode SHIPWRIGHT = new MaintenanceCapabilityCategoryCode(
			"Shipwright",
			"SHPWRG",
			"Equipment and resources for the construction, fitting and repairing the wooden parts of a docked vessel.");
	public static final MaintenanceCapabilityCategoryCode SHOTBLAST = new MaintenanceCapabilityCategoryCode(
			"Shotblast",
			"SHTBLS",
			"Equipment and resources for the cleaning of metal, belonging to a docked vessel, by the impact of a stream of shot (lead pellets).");
	public static final MaintenanceCapabilityCategoryCode STEAM = new MaintenanceCapabilityCategoryCode(
			"Steam",
			"STEAM",
			"The specific MAINTENANCE-CAPABILITY determines the ability to provide steam repair.");
	public static final MaintenanceCapabilityCategoryCode STEELWORK_FABRICATION = new MaintenanceCapabilityCategoryCode(
			"Steelwork fabrication",
			"STLFBR",
			"Equipment and resources for the construction or manufacture of any article made of steel required for a docked vessel.");
	public static final MaintenanceCapabilityCategoryCode TANK_CLEANING = new MaintenanceCapabilityCategoryCode(
			"Tank cleaning",
			"TNKCLN",
			"Equipment and resources for the removal of any trace of the original contents of any tank belonging to a docked vessel. Removal is often carried out by means of a high-pressure water jet.");

	private MaintenanceCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
