/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GovernmentOrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of GOVERNMENT-ORGANISATION-TYPE.";
	}

	private static HashMap<String, GovernmentOrganisationTypeCategoryCode> physicalToCode = new HashMap<String, GovernmentOrganisationTypeCategoryCode>();

	public static GovernmentOrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GovernmentOrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GovernmentOrganisationTypeCategoryCode INTERNATIONAL_CIVIL = new GovernmentOrganisationTypeCategoryCode(
			"International civil",
			"INTCIV",
			"A GOVERNMENT-ORGANISATION-TYPE that is officially involved in international civil affairs.");
	public static final GovernmentOrganisationTypeCategoryCode INTERNATIONAL_CIVIL_MILITARY = new GovernmentOrganisationTypeCategoryCode(
			"International civil/military",
			"INTCMI",
			"A GOVERNMENT-ORGANISATION-TYPE that is officially involved in international affairs that include both civil and military elements.");
	public static final GovernmentOrganisationTypeCategoryCode MILITARY_ORGANISATION_TYPE = new GovernmentOrganisationTypeCategoryCode(
			"MILITARY-ORGANISATION-TYPE",
			"MILORG",
			"A GOVERNMENT-ORGANISATION-TYPE that is officially sanctioned and is trained and equipped to exert force.");
	public static final GovernmentOrganisationTypeCategoryCode NATIONAL_CIVIL = new GovernmentOrganisationTypeCategoryCode(
			"National civil",
			"NATCIV",
			"A GOVERNMENT-ORGANISATION-TYPE that is officially involved in national civil affairs.");
	public static final GovernmentOrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new GovernmentOrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private GovernmentOrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
