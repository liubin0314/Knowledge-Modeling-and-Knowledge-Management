/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkCapacityBandwidthCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a bandwidth capacity that is supported by a NETWORK.";
	}

	private static HashMap<String, NetworkCapacityBandwidthCode> physicalToCode = new HashMap<String, NetworkCapacityBandwidthCode>();

	public static NetworkCapacityBandwidthCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkCapacityBandwidthCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkCapacityBandwidthCode _100_MBPS = new NetworkCapacityBandwidthCode(
			"100 Mbps",
			"100MBP",
			"A digital bandwidth value representing a transfer speed of 100 Megabits per second.");
	public static final NetworkCapacityBandwidthCode _10_GBPS = new NetworkCapacityBandwidthCode(
			"10 Gbps",
			"10GBPS",
			"A digital bandwidth value representing a transfer speed of 10 Gigabits per second.");
	public static final NetworkCapacityBandwidthCode _10_MBPS = new NetworkCapacityBandwidthCode(
			"10 Mbps",
			"10MBPS",
			"A digital bandwidth value representing a transfer speed of 10 Megabits per second.");
	public static final NetworkCapacityBandwidthCode _1_GBPS = new NetworkCapacityBandwidthCode(
			"1 Gbps",
			"1GBPS",
			"A digital bandwidth value representing a transfer speed of 1 Gigabits per second.");
	public static final NetworkCapacityBandwidthCode _56_KBPS = new NetworkCapacityBandwidthCode(
			"56 Kbps",
			"56KBPS",
			"A digital bandwidth value representing a transfer speed of 56 Kilobits per second.");
	public static final NetworkCapacityBandwidthCode _64_KBPS = new NetworkCapacityBandwidthCode(
			"64 Kbps",
			"64KBPS",
			"A digital bandwidth value representing a transfer speed of 64 Kilobits per second.");
	public static final NetworkCapacityBandwidthCode E1 = new NetworkCapacityBandwidthCode(
			"E1",
			"E1",
			"A dedicated point-to-point transmission line of 2048Kbps bandwidth capacity.");
	public static final NetworkCapacityBandwidthCode E2 = new NetworkCapacityBandwidthCode(
			"E2",
			"E2",
			"A dedicated point-to-point transmission line of 8192 Kbps bandwidth capacity.");
	public static final NetworkCapacityBandwidthCode E3 = new NetworkCapacityBandwidthCode(
			"E3",
			"E3",
			"A dedicated point-to-point transmission line of 32768 Kbps bandwidth capacity.");
	public static final NetworkCapacityBandwidthCode EUROCOM = new NetworkCapacityBandwidthCode(
			"Eurocom",
			"EUROCM",
			"A dedicated point-to-point transmission line of 512 Kbps bandwidth capacity.");
	public static final NetworkCapacityBandwidthCode FDDI = new NetworkCapacityBandwidthCode(
			"FDDI",
			"FDDI",
			"A 100 Mbps token passed ring network.");
	public static final NetworkCapacityBandwidthCode FRAME_RELAY = new NetworkCapacityBandwidthCode(
			"Frame relay",
			"FRMRLY",
			"A 1.544Mbps permanent virtual circuit that uses a packet switching scheme.");
	public static final NetworkCapacityBandwidthCode ISDN = new NetworkCapacityBandwidthCode(
			"ISDN",
			"ISDN",
			"A 144Kbps basic rate dial-up line.");
	public static final NetworkCapacityBandwidthCode NOT_OTHERWISE_SPECIFIED = new NetworkCapacityBandwidthCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkCapacityBandwidthCode SONET = new NetworkCapacityBandwidthCode(
			"SONET",
			"SONET",
			"A fibre optic NETWORK that delivers data at speeds up to 622 Mbps, and beyond. (Synchronous Optical NETwork).");
	public static final NetworkCapacityBandwidthCode SWITCHED_56 = new NetworkCapacityBandwidthCode(
			"Switched 56",
			"SWTD56",
			"A circuit-switched 56Kbps leased line.");
	public static final NetworkCapacityBandwidthCode T1 = new NetworkCapacityBandwidthCode(
			"T1",
			"T1",
			"A dedicated point-to-point transmission line of 1.544Mbps bandwidth capacity.");
	public static final NetworkCapacityBandwidthCode T3 = new NetworkCapacityBandwidthCode(
			"T3",
			"T3",
			"A dedicated point-to-point transmission line of 45 Mbps bandwidth capacity.");

	private NetworkCapacityBandwidthCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
