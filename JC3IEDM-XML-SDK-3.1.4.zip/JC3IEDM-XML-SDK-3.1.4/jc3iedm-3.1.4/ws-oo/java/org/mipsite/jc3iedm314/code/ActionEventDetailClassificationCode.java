/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEventDetailClassificationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the classification of a specific ACTION-EVENT according to a broad subject area.";
	}

	private static HashMap<String, ActionEventDetailClassificationCode> physicalToCode = new HashMap<String, ActionEventDetailClassificationCode>();

	public static ActionEventDetailClassificationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEventDetailClassificationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEventDetailClassificationCode DISASTROUS = new ActionEventDetailClassificationCode(
			"Disastrous",
			"DISAST",
			"The specific ACTION-EVENT can be characterised as resulting in a great or sudden misfortune.");
	public static final ActionEventDetailClassificationCode ECONOMIC = new ActionEventDetailClassificationCode(
			"Economic",
			"ECONMC",
			"The specific ACTION-EVENT can be characterised as occurring within an economic area of activity.");
	public static final ActionEventDetailClassificationCode ENVIRONMENTAL = new ActionEventDetailClassificationCode(
			"Environmental",
			"ENVIRN",
			"The specific ACTION-EVENT that is related to ecological or environmental conditions.");
	public static final ActionEventDetailClassificationCode ETHNIC = new ActionEventDetailClassificationCode(
			"Ethnic",
			"ETHNIC",
			"The specific ACTION-EVENT can be characterised as occurring within an ethnic area of activity.");
	public static final ActionEventDetailClassificationCode HISTORICAL = new ActionEventDetailClassificationCode(
			"Historical",
			"HSTRCL",
			"The specific ACTION-EVENT can be characterised as occurring within an historical area of activity.");
	public static final ActionEventDetailClassificationCode LABOUR = new ActionEventDetailClassificationCode(
			"Labour",
			"LABOUR",
			"The specific ACTION-EVENT can be characterised as occurring within a labour area of activity.");
	public static final ActionEventDetailClassificationCode MILITARY = new ActionEventDetailClassificationCode(
			"Military",
			"MILTRY",
			"The specific ACTION-EVENT can be characterised as occurring within a military area of activity.");
	public static final ActionEventDetailClassificationCode POLITICAL = new ActionEventDetailClassificationCode(
			"Political",
			"POLTCL",
			"The specific ACTION-EVENT can be characterised as occurring within a political area of activity.");
	public static final ActionEventDetailClassificationCode RELIGIOUS = new ActionEventDetailClassificationCode(
			"Religious",
			"RELIGS",
			"The specific ACTION-EVENT can be characterised as occurring within a religious area of activity.");
	public static final ActionEventDetailClassificationCode SOCIAL = new ActionEventDetailClassificationCode(
			"Social",
			"SOCIAL",
			"The specific ACTION-EVENT can be characterised as occurring within a social area of activity.");

	private ActionEventDetailClassificationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
