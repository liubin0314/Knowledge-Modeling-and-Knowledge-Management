/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionContextCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the nature of the ACTION-CONTEXT as it relates to a specific ACTION and a specific CONTEXT.";
	}

	private static HashMap<String, ActionContextCategoryCode> physicalToCode = new HashMap<String, ActionContextCategoryCode>();

	public static ActionContextCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionContextCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionContextCategoryCode DESIRED = new ActionContextCategoryCode(
			"Desired",
			"DES",
			"An expected positive consequence of a specific CONTEXT in relation to a specific ACTION.");
	public static final ActionContextCategoryCode FINAL_STATE_ACTUAL = new ActionContextCategoryCode(
			"Final state, actual",
			"FINACT",
			"An actual specific CONTEXT as it exists at the end of a specific ACTION.");
	public static final ActionContextCategoryCode FINAL_STATE_PLANNING = new ActionContextCategoryCode(
			"Final state, planning",
			"FINPLA",
			"A planned specific CONTEXT that may exist at the end of a specific ACTION.");
	public static final ActionContextCategoryCode INITIAL_STATE_ACTUAL = new ActionContextCategoryCode(
			"Initial state, actual",
			"INIACT",
			"An actual specific CONTEXT as it exists at the start of a specific ACTION.");
	public static final ActionContextCategoryCode INITIAL_STATE_PLANNING = new ActionContextCategoryCode(
			"Initial state, planning",
			"INIPLA",
			"A planned specific CONTEXT that may exist at the start of a specific ACTION.");
	public static final ActionContextCategoryCode INTERMEDIATE_STATE_ACTUAL = new ActionContextCategoryCode(
			"Intermediate state, actual",
			"INTACT",
			"An actual specific CONTEXT as it exists at an intermediate point during the execution of a specific ACTION.");
	public static final ActionContextCategoryCode INTERMEDIATE_STATE_PLANNING = new ActionContextCategoryCode(
			"Intermediate state, planning",
			"INTPLA",
			"A planned specific CONTEXT that may exist at an intermediate point during the execution of a specific ACTION.");
	public static final ActionContextCategoryCode IS_INCLUDED_IN = new ActionContextCategoryCode(
			"Is included in",
			"ISINCL",
			"The specific ACTION is encompassed within the information content of a specific CONTEXT.");
	public static final ActionContextCategoryCode MAXIMUM_REQUIRED = new ActionContextCategoryCode(
			"Maximum required",
			"MAX",
			"The maximum value referred to by a specific CONTEXT that is necessary for the evolution of a specific ACTION.");
	public static final ActionContextCategoryCode MINIMUM_REQUIRED = new ActionContextCategoryCode(
			"Minimum required",
			"MIN",
			"The minimum value referred to by a specific CONTEXT that is necessary for the evolution of a specific ACTION.");

	private ActionContextCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
