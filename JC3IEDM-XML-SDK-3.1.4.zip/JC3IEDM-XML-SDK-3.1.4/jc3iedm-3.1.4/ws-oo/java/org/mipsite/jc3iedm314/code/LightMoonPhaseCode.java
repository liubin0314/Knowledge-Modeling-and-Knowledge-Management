/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LightMoonPhaseCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the phase of the moon for a specific LIGHT.";
	}

	private static HashMap<String, LightMoonPhaseCode> physicalToCode = new HashMap<String, LightMoonPhaseCode>();

	public static LightMoonPhaseCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LightMoonPhaseCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LightMoonPhaseCode FULL_MOON = new LightMoonPhaseCode(
			"Full moon",
			"FUL",
			"The moon with its entire disc illuminated.");
	public static final LightMoonPhaseCode NEW_MOON = new LightMoonPhaseCode(
			"New moon",
			"NEW",
			"The moon when first seen as a slender crescent shortly after its conjunction with the sun.");
	public static final LightMoonPhaseCode WANING_MOON = new LightMoonPhaseCode(
			"Waning moon",
			"WAN",
			"The moon is decreasing in phase.");
	public static final LightMoonPhaseCode WAXING_MOON = new LightMoonPhaseCode(
			"Waxing moon",
			"WAX",
			"The moon is increasing in phase.");

	private LightMoonPhaseCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
