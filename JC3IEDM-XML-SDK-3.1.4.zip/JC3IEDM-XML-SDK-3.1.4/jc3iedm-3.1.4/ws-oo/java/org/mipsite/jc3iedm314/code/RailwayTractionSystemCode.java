/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailwayTractionSystemCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the motive power (engine type) that is supported along a specific RAILWAY.";
	}

	private static HashMap<String, RailwayTractionSystemCode> physicalToCode = new HashMap<String, RailwayTractionSystemCode>();

	public static RailwayTractionSystemCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailwayTractionSystemCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailwayTractionSystemCode ELECTRIC = new RailwayTractionSystemCode(
			"Electric",
			"E",
			"The RAILWAY supports electric locomotives.");
	public static final RailwayTractionSystemCode NOT_ELECTRIC = new RailwayTractionSystemCode(
			"Not electric",
			"NE",
			"The RAILWAY supports locomotives that are not electric.");

	private RailwayTractionSystemCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
