/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BridgeUsageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the usage of a specific BRIDGE.";
	}

	private static HashMap<String, BridgeUsageCode> physicalToCode = new HashMap<String, BridgeUsageCode>();

	public static BridgeUsageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BridgeUsageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BridgeUsageCode FOOT = new BridgeUsageCode(
			"Foot",
			"FOOT",
			"The BRIDGE is intended to be used by foot traffic.");
	public static final BridgeUsageCode MULTIPLE_USE = new BridgeUsageCode(
			"Multiple use",
			"MLTUSE",
			"The BRIDGE is intended to be used for foot, vehicle and rail traffic.");
	public static final BridgeUsageCode NOT_KNOWN = new BridgeUsageCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final BridgeUsageCode NOT_OTHERWISE_SPECIFIED = new BridgeUsageCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final BridgeUsageCode RAILWAY = new BridgeUsageCode(
			"Railway",
			"RAILWY",
			"The BRIDGE is intended to be used for rail traffic.");
	public static final BridgeUsageCode RAILWAY_VEHICLE = new BridgeUsageCode(
			"Railway/vehicle",
			"RLWYVH",
			"The BRIDGE is intended to be used both for rail and vehicle traffic.");
	public static final BridgeUsageCode VEHICLE = new BridgeUsageCode(
			"Vehicle",
			"VEHCLE",
			"The BRIDGE is intended to be used by vehicle traffic.");

	private BridgeUsageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
