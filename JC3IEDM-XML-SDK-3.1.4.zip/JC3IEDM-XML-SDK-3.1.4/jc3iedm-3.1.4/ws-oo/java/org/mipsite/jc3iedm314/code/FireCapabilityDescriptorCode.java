/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FireCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the FIRE-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, FireCapabilityDescriptorCode> physicalToCode = new HashMap<String, FireCapabilityDescriptorCode>();

	public static FireCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FireCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FireCapabilityDescriptorCode BURST_FIRE_RATE = new FireCapabilityDescriptorCode(
			"Burst fire rate",
			"BRTFIR",
			"The numeric value that denotes the rate at which projectiles can be fired in a short but rapid burst.");
	public static final FireCapabilityDescriptorCode MAXIMUM_RANGE = new FireCapabilityDescriptorCode(
			"Maximum range",
			"MRANGE",
			"The longest distance that can be achieved.");
	public static final FireCapabilityDescriptorCode MAXIMUM_FIRE_RATE = new FireCapabilityDescriptorCode(
			"Maximum fire rate",
			"MRATFR",
			"The numeric value that denotes the highest rate at which projectiles can be fired for a limited period of time.");
	public static final FireCapabilityDescriptorCode MINIMUM_RANGE = new FireCapabilityDescriptorCode(
			"Minimum range",
			"NRANGE",
			"The shortest distance that can be achieved.");
	public static final FireCapabilityDescriptorCode SAFETY_DISTANCE_FACTOR = new FireCapabilityDescriptorCode(
			"Safety distance factor",
			"SFTDST",
			"The numeric value that denotes the minimum distance to be maintained between own troops and the intended target.");
	public static final FireCapabilityDescriptorCode SUSTAINED_FIRE_RATE = new FireCapabilityDescriptorCode(
			"Sustained fire rate",
			"SSTRTF",
			"The numeric value that denotes the rate at which projectiles can be fired repeatedly for a prolonged period of time.");

	private FireCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
