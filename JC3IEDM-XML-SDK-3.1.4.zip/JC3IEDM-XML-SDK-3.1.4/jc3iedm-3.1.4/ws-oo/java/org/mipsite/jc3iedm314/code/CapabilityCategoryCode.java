/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general class of a CAPABILITY.";
	}

	private static HashMap<String, CapabilityCategoryCode> physicalToCode = new HashMap<String, CapabilityCategoryCode>();

	public static CapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CapabilityCategoryCode ENGINEERING_CAPABILITY = new CapabilityCategoryCode(
			"ENGINEERING-CAPABILITY",
			"ENGI",
			"A CAPABILITY, required for planning, of those ORGANISATIONs and PERSONs or ORGANISATION-TYPEs and PERSON-TYPEs that are deemed as having the ability to perform construction or destruction activities.");
	public static final CapabilityCategoryCode FIRE_CAPABILITY = new CapabilityCategoryCode(
			"FIRE-CAPABILITY",
			"FIRE",
			"A CAPABILITY, required for planning, of those FACILITYs, MATERIELs, ORGANISATIONs and PERSONs, or FACILITY-TYPEs, EQUIPMENT-TYPEs, ORGANISATION-TYPEs and PERSON-TYPEs that are deemed as having the ability to discharge or launch a projectile or missile.");
	public static final CapabilityCategoryCode HANDLING_CAPABILITY = new CapabilityCategoryCode(
			"HANDLING-CAPABILITY",
			"HNDLNG",
			"A CAPABILITY, required for planning, of those FACILITYs and MATERIELs, or FACILITY-TYPEs and EQUIPMENT-TYPEs that are deemed as having the ability to move materiels (raw materials, scrap, semi-finished, and finished) to, through, and from productive processes; in warehouses and storage; and in receiving and shipping areas.");
	public static final CapabilityCategoryCode MAINTENANCE_CAPABILITY = new CapabilityCategoryCode(
			"MAINTENANCE-CAPABILITY",
			"MAIN",
			"A CAPABILITY, required for planning, of those FACILITYs, MATERIELs, ORGANISATIONs and PERSONs or FACILITY-TYPEs, EQUIPMENT-TYPEs, ORGANISATION-TYPEs, and PERSON-TYPEs that are deemed as having the ability to provide a range of activities required to restore or maintain operational usage.");
	public static final CapabilityCategoryCode MOBILITY_CAPABILITY = new CapabilityCategoryCode(
			"MOBILITY-CAPABILITY",
			"MOBL",
			"A CAPABILITY, required for planning, of those FACILITYs, MATERIELs, ORGANISATIONs and PERSONs or FACILITY-TYPEs, EQUIPMENT-TYPEs, ORGANISATION-TYPEs, and PERSON-TYPEs that are deemed as having the nominal ability to move in space, air, on water, under water, or over a specific type of terrain.");
	public static final CapabilityCategoryCode OPERATIONAL_CAPABILITY = new CapabilityCategoryCode(
			"OPERATIONAL-CAPABILITY",
			"OPERAT",
			"A CAPABILITY, required for planning, of those objects and types of objects that are deemed as having the ability, the training and the equipment to perform an operation.");
	public static final CapabilityCategoryCode STORAGE_CAPABILITY = new CapabilityCategoryCode(
			"STORAGE-CAPABILITY",
			"STOR",
			"A CAPABILITY, required for planning, of those FACILITYs and MATERIELs or EQUIPMENT-TYPEs and FACILITY-TYPEs that are deemed as having the ability to hold a specific OBJECT-TYPE.");
	public static final CapabilityCategoryCode SUPPORT_CAPABILITY = new CapabilityCategoryCode(
			"SUPPORT-CAPABILITY",
			"SUPPRT",
			"A CAPABILITY, required for planning, of those FACILITYs, MATERIELs and ORGANISATIONs or FACILITY-TYPEs, EQUIPMENT-TYPEs and ORGANISATION-TYPEs that are deemed as having the ability to provide supplies or services.");
	public static final CapabilityCategoryCode SURVEILLANCE_CAPABILITY = new CapabilityCategoryCode(
			"SURVEILLANCE-CAPABILITY",
			"SURV",
			"A CAPABILITY, required for planning, of those FACILITYs, MATERIELs, ORGANISATIONs and PERSONs or FACILITY-TYPEs, EQUIPMENT-TYPEs, ORGANISATION-TYPEs and PERSON-TYPEs that are deemed as having the nominal ability to observe aerospace, surface or subsurface areas, places, persons, or things, by visual, aural, electronic, photographic or other means.");
	public static final CapabilityCategoryCode TRANSMISSION_CAPABILITY = new CapabilityCategoryCode(
			"TRANSMISSION-CAPABILITY",
			"TRANSM",
			"A CAPABILITY, required for planning, of those MATERIELs or MATERIEL-TYPEs that are deemed as having the ability to generate, receive or affect signals in the electromagnetic spectrum.");

	private CapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
