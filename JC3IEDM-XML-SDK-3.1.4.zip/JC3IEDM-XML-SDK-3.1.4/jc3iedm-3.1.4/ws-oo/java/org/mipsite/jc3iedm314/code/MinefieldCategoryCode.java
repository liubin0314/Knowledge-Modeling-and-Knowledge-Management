/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MINEFIELD.";
	}

	private static HashMap<String, MinefieldCategoryCode> physicalToCode = new HashMap<String, MinefieldCategoryCode>();

	public static MinefieldCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldCategoryCode MINEFIELD_LAND = new MinefieldCategoryCode(
			"MINEFIELD-LAND",
			"MNFLND",
			"A MINEFIELD that is an area of land containing mines.");
	public static final MinefieldCategoryCode MINEFIELD_MARITIME = new MinefieldCategoryCode(
			"MINEFIELD-MARITIME",
			"MNFMRT",
			"A MINEFIELD that is an area or volume of water containing mines.");

	private MinefieldCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
