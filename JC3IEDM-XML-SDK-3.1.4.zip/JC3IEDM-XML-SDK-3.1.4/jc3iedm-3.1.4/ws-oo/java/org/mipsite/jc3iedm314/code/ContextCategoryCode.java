/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CONTEXT.";
	}

	private static HashMap<String, ContextCategoryCode> physicalToCode = new HashMap<String, ContextCategoryCode>();

	public static ContextCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextCategoryCode ASSESSMENT = new ContextCategoryCode(
			"Assessment",
			"ASSESS",
			"Information encompassed by the CONTEXT is the subject for an assessment.");
	public static final ContextCategoryCode CORRECTION = new ContextCategoryCode(
			"Correction",
			"CORREC",
			"Information encompassed by the CONTEXT is to be corrected.");
	public static final ContextCategoryCode CORRELATION = new ContextCategoryCode(
			"Correlation",
			"CORREL",
			"Information encompassed by the CONTEXT is the basis for a summary arrived at through a process of correlation.");
	public static final ContextCategoryCode NEGATION = new ContextCategoryCode(
			"Negation",
			"NEGATE",
			"Information encompassed by the CONTEXT is to be declared untrue.");
	public static final ContextCategoryCode NOT_OTHERWISE_SPECIFIED = new ContextCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ContextCategoryCode OPERATIONAL_INFORMATION_GROUP = new ContextCategoryCode(
			"OPERATIONAL-INFORMATION-GROUP",
			"OIG",
			"A CONTEXT that encompasses a set of pre-defined operational information.");
	public static final ContextCategoryCode OVERLAY = new ContextCategoryCode(
			"Overlay",
			"OVERLY",
			"Information encompassed by the CONTEXT is the basis for an overlay.");
	public static final ContextCategoryCode PREDICTION = new ContextCategoryCode(
			"Prediction",
			"PREDCT",
			"Information encompassed by the CONTEXT is the basis for a forecast.");

	private ContextCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
