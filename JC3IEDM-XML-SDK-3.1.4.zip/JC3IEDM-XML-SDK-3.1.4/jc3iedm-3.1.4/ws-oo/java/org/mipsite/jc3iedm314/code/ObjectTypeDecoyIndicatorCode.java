/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeDecoyIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether a specific OBJECT-TYPE represents an object class acting as a decoy.";
	}

	private static HashMap<String, ObjectTypeDecoyIndicatorCode> physicalToCode = new HashMap<String, ObjectTypeDecoyIndicatorCode>();

	public static ObjectTypeDecoyIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeDecoyIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeDecoyIndicatorCode NO = new ObjectTypeDecoyIndicatorCode(
			"No",
			"NO",
			"The OBJECT-TYPE represents an object not acting as a decoy or dummy.");
	public static final ObjectTypeDecoyIndicatorCode YES = new ObjectTypeDecoyIndicatorCode(
			"Yes",
			"YES",
			"The OBJECT-TYPE represents an object acting as a decoy or dummy.");

	private ObjectTypeDecoyIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
