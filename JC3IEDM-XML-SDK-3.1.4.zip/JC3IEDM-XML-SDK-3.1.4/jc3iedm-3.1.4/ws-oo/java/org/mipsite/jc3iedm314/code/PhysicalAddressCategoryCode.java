/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PhysicalAddressCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of the PHYSICAL-ADDRESS.";
	}

	private static HashMap<String, PhysicalAddressCategoryCode> physicalToCode = new HashMap<String, PhysicalAddressCategoryCode>();

	public static PhysicalAddressCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PhysicalAddressCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PhysicalAddressCategoryCode MAILING_ADDRESS = new PhysicalAddressCategoryCode(
			"Mailing address",
			"MLADDR",
			"An address to which a specific piece of mail is sent.");
	public static final PhysicalAddressCategoryCode NOT_OTHERWISE_SPECIFIED = new PhysicalAddressCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final PhysicalAddressCategoryCode PHYSICAL_ADDRESS = new PhysicalAddressCategoryCode(
			"Physical address",
			"PHADDR",
			"The actual address of a facility, organisation or person.");
	public static final PhysicalAddressCategoryCode POSTMARK = new PhysicalAddressCategoryCode(
			"Postmark",
			"PSTMRK",
			"The mark affixed to a mailed item by the post office.");
	public static final PhysicalAddressCategoryCode RETURN_ADDRESS = new PhysicalAddressCategoryCode(
			"Return address",
			"RTADDR",
			"An address to which a specific piece of mail should be returned to if not delivered.");

	private PhysicalAddressCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
