/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonProfessingIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific PERSON professes a religious preference.";
	}

	private static HashMap<String, PersonProfessingIndicatorCode> physicalToCode = new HashMap<String, PersonProfessingIndicatorCode>();

	public static PersonProfessingIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonProfessingIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonProfessingIndicatorCode NO = new PersonProfessingIndicatorCode(
			"No",
			"NO",
			"The specific PERSON does not profess a religious preference.");
	public static final PersonProfessingIndicatorCode YES = new PersonProfessingIndicatorCode(
			"Yes",
			"YES",
			"The specific PERSON does profess a religious preference.");

	private PersonProfessingIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
