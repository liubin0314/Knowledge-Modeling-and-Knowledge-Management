/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CasualtyGroupCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the categorisation of casualties by group.";
	}

	private static HashMap<String, CasualtyGroupCode> physicalToCode = new HashMap<String, CasualtyGroupCode>();

	public static CasualtyGroupCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CasualtyGroupCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CasualtyGroupCode FRIENDLY_FORCES = new CasualtyGroupCode(
			"Friendly forces",
			"FRFOR",
			"The casualty is a member of the friendly force.");
	public static final CasualtyGroupCode LOCAL_CIVILIANS = new CasualtyGroupCode(
			"Local civilians",
			"LOCCIV",
			"The casualty is a local civilian.");
	public static final CasualtyGroupCode OPPOSING_FORCES = new CasualtyGroupCode(
			"Opposing forces",
			"OPFOR",
			"The casualty is a member of the opposing force.");

	private CasualtyGroupCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
