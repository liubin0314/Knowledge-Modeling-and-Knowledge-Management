/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RouteTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ROUTE-TYPE.";
	}

	private static HashMap<String, RouteTypeCategoryCode> physicalToCode = new HashMap<String, RouteTypeCategoryCode>();

	public static RouteTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RouteTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RouteTypeCategoryCode ADVISORY_ROUTE = new RouteTypeCategoryCode(
			"Advisory route",
			"ADVRTE",
			"A designated route along which air traffic advisory service is available.");
	public static final RouteTypeCategoryCode AIR_CORRIDOR = new RouteTypeCategoryCode(
			"Air corridor",
			"AIRCOR",
			"A restricted air route of travel specified for use by friendly aircraft and established for the purpose of preventing friendly aircraft from being fired on by friendly forces.");
	public static final RouteTypeCategoryCode AIR_ROUTE = new RouteTypeCategoryCode(
			"Air route",
			"AIRRTE",
			"The navigable airspace between two points identified to the extent necessary for the application of flight.");
	public static final RouteTypeCategoryCode AIRWAY = new RouteTypeCategoryCode(
			"Airway",
			"AIRWAY",
			"A control area or portion thereof established in the form of a corridor equipped with radio navigational aids.");
	public static final RouteTypeCategoryCode ALTERNATE_SUPPLY_ROUTE = new RouteTypeCategoryCode(
			"Alternate supply route",
			"ALTSPL",
			"A route or routes designated within an area of operations to provide for the movement of traffic when main supply routes become disabled or congested.");
	public static final RouteTypeCategoryCode APPROACH_CORRIDOR = new RouteTypeCategoryCode(
			"Approach corridor",
			"APRCOR",
			"Airspace established for the safe passage of land based aircraft joining or departing a maritime force.");
	public static final RouteTypeCategoryCode AIR_TRAFFIC_SERVICES_ROUTE = new RouteTypeCategoryCode(
			"Air traffic services route",
			"ATS",
			"A specified route designed for channelling the flow of traffic as necessary for the provision of air traffic services (ATS).");
	public static final RouteTypeCategoryCode CONDITIONAL_ROUTE = new RouteTypeCategoryCode(
			"Conditional route",
			"CONDRT",
			"A non-permanent air traffic service route or portion thereof which can be planned and used only under certain conditions.");
	public static final RouteTypeCategoryCode CONVENTIONAL_ROUTE = new RouteTypeCategoryCode(
			"Conventional route",
			"CONVRT",
			"Conventional route.");
	public static final RouteTypeCategoryCode DCT = new RouteTypeCategoryCode(
			"DCT",
			"DCT",
			"Direct routing.");
	public static final RouteTypeCategoryCode EGRESS_ROUTE = new RouteTypeCategoryCode(
			"Egress route",
			"EGRRTU",
			"An outbound route from a specific area or target.");
	public static final RouteTypeCategoryCode FLIGHT_PATH = new RouteTypeCategoryCode(
			"Flight path",
			"FLTPTH",
			"The line connecting the successive positions occupied, or to be occupied, by an aircraft, missile or space vehicle as it moves through air or space.");
	public static final RouteTypeCategoryCode GREAT_CIRCLE_ROUTE = new RouteTypeCategoryCode(
			"Great circle route",
			"GRCLRT",
			"The route that follows the shortest arc between two points on the earth's surface.");
	public static final RouteTypeCategoryCode INGRESS_ROUTE = new RouteTypeCategoryCode(
			"Ingress route",
			"INGRTE",
			"An inbound route to a specific area or target.");
	public static final RouteTypeCategoryCode LATERAL_ROUTE = new RouteTypeCategoryCode(
			"Lateral route",
			"LATR",
			"A route generally parallel to the forward edge of the battle area, which crosses, or feeds into, axial routes.");
	public static final RouteTypeCategoryCode LOW_LEVEL_TRANSIT_ROUTE = new RouteTypeCategoryCode(
			"Low level transit route",
			"LLTR",
			"A temporary corridor of defined dimensions established in the forward area to minimise the risk to friendly aircraft from friendly air defences or surface forces.");
	public static final RouteTypeCategoryCode MARITIME_MINEFIELD_SWEEP_TRACK = new RouteTypeCategoryCode(
			"Maritime minefield sweep track",
			"MAMNST",
			"The prescribed line over the ground along which the centre of the mine counter measures gear must travel in order that the lane swept can be defined by the width and the depth swept.");
	public static final RouteTypeCategoryCode MARITIME_MINELAYING_TRACK = new RouteTypeCategoryCode(
			"Maritime minelaying track",
			"MAMNTR",
			"The prescribed line over the ground along which the centre of the minelaying gear must travel.");
	public static final RouteTypeCategoryCode MINIMUM_RISK_ROUTE = new RouteTypeCategoryCode(
			"Minimum risk route",
			"MRR",
			"A temporary corridor of defined dimensions recommended for use by high-speed, fixed-wing aircraft that presents the minimum known hazards to low-flying aircraft transiting the combat zone. Army--An MRR is a temporary flight route recommended for USAF use. It presents the minimum known hazards to low-flying aircraft in the control zone (CZ). The MRR must be approved by the airspace control authority and avoids fire support targets such as air defence weapons, landing zones, pick-up zones, FARPs, and Army airfields.");
	public static final RouteTypeCategoryCode MAIN_SUPPLY_ROUTE = new RouteTypeCategoryCode(
			"Main supply route",
			"MSR",
			"The route or routes designated with an area of operations on which the bulk of traffic flows in support of military operations.");
	public static final RouteTypeCategoryCode AREA_NAVIGATION_ROUTE = new RouteTypeCategoryCode(
			"Area navigation route",
			"NAVRTE",
			"An air traffic services route established for the use of aircraft capable of employing area navigation.");
	public static final RouteTypeCategoryCode NOT_KNOWN = new RouteTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RouteTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new RouteTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RouteTypeCategoryCode POLAR_ROUTE = new RouteTypeCategoryCode(
			"Polar route",
			"POLRRT",
			"Polar route.");
	public static final RouteTypeCategoryCode Q_ROUTE = new RouteTypeCategoryCode(
			"Q-route",
			"QROUTE",
			"A system of preplanned shipping lanes in mined or potentially mined waters used to minimize the area the mine countermeasures commander has to keep clear of mines in order to provide safe passage for friendly shipping.");
	public static final RouteTypeCategoryCode Q_ROUTE_SEGMENT = new RouteTypeCategoryCode(
			"Q-route-segment",
			"QRTESG",
			"A part of a system of preplanned shipping lanes in mined or potentially mined waters used to minimize the area the mine countermeasures commander has to keep clear of mines in order to provide safe passage for friendly shipping.");
	public static final RouteTypeCategoryCode REFERENCE_TRACK = new RouteTypeCategoryCode(
			"Reference track",
			"REFTRK",
			"The prescribed reference line over the ground along which the centre of the mine counter measures gear must travel.");
	public static final RouteTypeCategoryCode RETURN_TO_FORCE_ROUTE = new RouteTypeCategoryCode(
			"Return to force route",
			"RETFRT",
			"Planned route profiles for use by friendly aircraft returning to an aircraft-capable ship.");
	public static final RouteTypeCategoryCode RHUMB_LINE_ROUTE = new RouteTypeCategoryCode(
			"Rhumb line route",
			"RHLNRT",
			"The route that maintains a constant direction, shown on a map as a line crossing all meridians at the same angle.");
	public static final RouteTypeCategoryCode SPECIAL_CORRIDOR = new RouteTypeCategoryCode(
			"Special corridor",
			"SPCCDR",
			"An area established to accommodate the special routing requirements of specific missions.");
	public static final RouteTypeCategoryCode STANDARD_USE_ARMY_AIRCRAFT_FLIGHT_ROUTE = new RouteTypeCategoryCode(
			"Standard-use army aircraft flight route",
			"STDART",
			"Route established below the coordination altitude to facilitate movement of army aviation assets in the forward area in direct support of ground operations.");
	public static final RouteTypeCategoryCode STANDARD_ROUTE = new RouteTypeCategoryCode(
			"Standard route",
			"STRDRT",
			"In naval cooperation and guidance for shipping, a preplanned single track connecting positions within the main shipping route.");
	public static final RouteTypeCategoryCode SUPERSONIC_ROUTE = new RouteTypeCategoryCode(
			"Supersonic route",
			"SUPRRT",
			"Supersonic route.");
	public static final RouteTypeCategoryCode TACAN_ROUTE = new RouteTypeCategoryCode(
			"TACAN route",
			"TACAN",
			"Tactical air navigation route.");
	public static final RouteTypeCategoryCode TEMPORARY_MINIMUM_RISK_ROUTE = new RouteTypeCategoryCode(
			"Temporary minimum risk route",
			"TMMRRT",
			"A temporary route of defined dimension recommended for use by high speed fixed-wing aircraft to route them between TRs and the rear of the forward area and their operations areas.");
	public static final RouteTypeCategoryCode TRUNK_ROUTE = new RouteTypeCategoryCode(
			"Trunk route",
			"TRNKRT",
			"Trunk route.");
	public static final RouteTypeCategoryCode TRANSIT_ROUTE = new RouteTypeCategoryCode(
			"Transit route",
			"TRSTRT",
			"A temporary corridor of defined dimensions established in the forward area to minimise the risk to friendly aircraft from friendly air defences or surface forces.");
	public static final RouteTypeCategoryCode UNMANNED_AERIAL_VEHICLE_ROUTE = new RouteTypeCategoryCode(
			"Unmanned aerial vehicle route",
			"UNMVRT",
			"The CONTROL-FEATURE-TYPE that specifies a route along which an unmanned aerial vehicle travels.");
	public static final RouteTypeCategoryCode USUAL_COASTAL_ROUTE = new RouteTypeCategoryCode(
			"Usual coastal route",
			"USCTRT",
			"The route that follows the shape or boundary of a coast.");
	public static final RouteTypeCategoryCode VARIABLE_TRACK_ROUTE = new RouteTypeCategoryCode(
			"Variable track route",
			"VARTRA",
			"Any combination of other than standard routes.");

	private RouteTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
