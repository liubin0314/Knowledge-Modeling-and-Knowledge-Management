/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LightCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of LIGHT.";
	}

	private static HashMap<String, LightCategoryCode> physicalToCode = new HashMap<String, LightCategoryCode>();

	public static LightCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LightCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LightCategoryCode CIVIL_TWILIGHT = new LightCategoryCode(
			"Civil twilight",
			"CIVIL",
			"The periods of incomplete darkness following sunset and preceding sunrise. The darker limit occurs when the centre of the sun is 6 degrees below the celestial horizon.");
	public static final LightCategoryCode DARKNESS = new LightCategoryCode(
			"Darkness",
			"DARK",
			"The absence of light.");
	public static final LightCategoryCode DAYLIGHT = new LightCategoryCode(
			"Daylight",
			"DAY",
			"Ambient atmospheric light resulting from the sun.");
	public static final LightCategoryCode MOONLIGHT = new LightCategoryCode(
			"Moonlight",
			"MOON",
			"Ambient atmospheric light resulting from the moon.");
	public static final LightCategoryCode NAUTICAL_TWILIGHT = new LightCategoryCode(
			"Nautical twilight",
			"NAUTIC",
			"The periods of incomplete darkness following sunset and preceding sunrise. The darker limit occurs when the centre of the sun is 12 degrees below the celestial horizon.");

	private LightCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
