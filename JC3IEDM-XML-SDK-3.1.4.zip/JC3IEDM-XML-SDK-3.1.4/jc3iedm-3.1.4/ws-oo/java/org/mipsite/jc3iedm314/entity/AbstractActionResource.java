/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionResource extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private ActionResourceCriticalityIndicatorCode criticalityIndicatorCode; // optional
	private ActionResourceQualifierCode qualifierCode; // optional
	private Ref<AbstractOrganisation> authorisingOrganisation; // optional
	private Set<Ref<AbstractActionResourceEmployment>> employmentSet; // zero-or-one

	// default constructor

	public AbstractActionResource() {
		this.employmentSet = new HashSet<Ref<AbstractActionResourceEmployment>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractActionResource.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractActionResource.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public ActionResourceCriticalityIndicatorCode getCriticalityIndicatorCode() {
		return this.criticalityIndicatorCode;
	}

	public void setCriticalityIndicatorCode(ActionResourceCriticalityIndicatorCode criticalityIndicatorCode) {
		this.criticalityIndicatorCode = criticalityIndicatorCode;
	}

	public ActionResourceQualifierCode getQualifierCode() {
		return this.qualifierCode;
	}

	public void setQualifierCode(ActionResourceQualifierCode qualifierCode) {
		this.qualifierCode = qualifierCode;
	}

	public Ref<AbstractOrganisation> getAuthorisingOrganisation() {
		return this.authorisingOrganisation;
	}

	public void setAuthorisingOrganisation(Ref<AbstractOrganisation> authorisingOrganisation) {
		this.authorisingOrganisation = authorisingOrganisation;
	}

	public Set<Ref<AbstractActionResourceEmployment>> getEmploymentSet() {
		return this.employmentSet;
	}

	public void addEmployment(Ref<AbstractActionResourceEmployment> employment) {
		this.employmentSet.add(employment);
	}
}
