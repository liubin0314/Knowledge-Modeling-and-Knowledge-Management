/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrderStatusExecutionStateCode extends CodeDomain {

	public static String getComment() {
		return "The specific value assigned to represent the state of execution for a specific ORDER.";
	}

	private static HashMap<String, OrderStatusExecutionStateCode> physicalToCode = new HashMap<String, OrderStatusExecutionStateCode>();

	public static OrderStatusExecutionStateCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrderStatusExecutionStateCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrderStatusExecutionStateCode ISSUED = new OrderStatusExecutionStateCode(
			"Issued",
			"ISSUED",
			"The specific ORDER has been distributed to be executed according to order provisions.");
	public static final OrderStatusExecutionStateCode STOPPED = new OrderStatusExecutionStateCode(
			"Stopped",
			"STOPPD",
			"The execution of a specific ORDER has been paused, aborted, or completed.");

	private OrderStatusExecutionStateCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
