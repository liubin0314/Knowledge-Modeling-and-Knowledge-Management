/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourTugAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the availability of tugs at a specific HARBOUR.";
	}

	private static HashMap<String, HarbourTugAvailabilityIndicatorCode> physicalToCode = new HashMap<String, HarbourTugAvailabilityIndicatorCode>();

	public static HarbourTugAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourTugAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourTugAvailabilityIndicatorCode NO = new HarbourTugAvailabilityIndicatorCode(
			"No",
			"NO",
			"Tugs are not available at the harbour.");
	public static final HarbourTugAvailabilityIndicatorCode YES = new HarbourTugAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Tugs are available at the harbour.");

	private HarbourTugAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
