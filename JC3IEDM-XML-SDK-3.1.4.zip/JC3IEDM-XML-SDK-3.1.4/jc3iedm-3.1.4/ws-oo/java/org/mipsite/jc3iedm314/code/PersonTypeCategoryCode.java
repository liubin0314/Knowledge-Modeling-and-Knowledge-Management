/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of PERSON-TYPE.";
	}

	private static HashMap<String, PersonTypeCategoryCode> physicalToCode = new HashMap<String, PersonTypeCategoryCode>();

	public static PersonTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonTypeCategoryCode CIVILIAN = new PersonTypeCategoryCode(
			"Civilian",
			"CIV",
			"A PERSON-TYPE who is not a uniformed member of a regular armed force.");
	public static final PersonTypeCategoryCode MILITARY = new PersonTypeCategoryCode(
			"Military",
			"MILTRY",
			"A PERSON-TYPE who is a uniformed member of a regular armed force.");
	public static final PersonTypeCategoryCode NOT_KNOWN = new PersonTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new PersonTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final PersonTypeCategoryCode PARAMILITARY = new PersonTypeCategoryCode(
			"Paramilitary",
			"PAR",
			"A PERSON-TYPE who is a member of an irregular armed force.");

	private PersonTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
