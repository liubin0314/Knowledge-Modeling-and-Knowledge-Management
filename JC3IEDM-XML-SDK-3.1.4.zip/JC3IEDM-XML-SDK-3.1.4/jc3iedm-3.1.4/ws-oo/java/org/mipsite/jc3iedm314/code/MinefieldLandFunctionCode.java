/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldLandFunctionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the intended function of the specific MINEFIELD-LAND.";
	}

	private static HashMap<String, MinefieldLandFunctionCode> physicalToCode = new HashMap<String, MinefieldLandFunctionCode>();

	public static MinefieldLandFunctionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldLandFunctionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldLandFunctionCode HEAVY_TACTICAL = new MinefieldLandFunctionCode(
			"Heavy tactical",
			"HTACT",
			"A minefield that is part of a formation obstacle plan and is laid to delay, channel or break up an enemy advance. A heavy minefield is categorised as one with 7 rows per kilometre depth at a standard spacing for the type of mine used.");
	public static final MinefieldLandFunctionCode LIGHT_TACTICAL = new MinefieldLandFunctionCode(
			"Light tactical",
			"LTACT",
			"A minefield that is part of a formation obstacle plan and is laid to delay, channel or break up an enemy advance. A light minefield is categorised as one with 3 rows per kilometre depth at a standard spacing for the type of mine used.");
	public static final MinefieldLandFunctionCode MEDIUM_TACTICAL = new MinefieldLandFunctionCode(
			"Medium tactical",
			"MTACT",
			"A minefield that is part of a formation obstacle plan and is laid to delay, channel or break up an enemy advance. A medium minefield is categorised as one with 5 rows per kilometre depth at a standard spacing for the type of mine used.");
	public static final MinefieldLandFunctionCode NUISANCE = new MinefieldLandFunctionCode(
			"Nuisance",
			"NUISNC",
			"A minefield laid to delay and disorganise the enemy and to hinder his use of an area or route.");
	public static final MinefieldLandFunctionCode PHONEY = new MinefieldLandFunctionCode(
			"Phoney",
			"PHONEY",
			"A minefield that denotes an area free of live mines used to simulate a minefield, or section of a minefield, with the object of deceiving the enemy.");
	public static final MinefieldLandFunctionCode PROTECTIVE = new MinefieldLandFunctionCode(
			"Protective",
			"PROTCT",
			"A minefield employed to protect an ORGANISATION, FACILITY, or FEATURE.");

	private MinefieldLandFunctionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
