/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.xml.processing.*;

public abstract class AbstractAbsolutePoint extends AbstractPoint {

	// private fields

	private Ref<VerticalDistance> verticalDistance; // optional

	// default constructor

	public AbstractAbsolutePoint() {
		// no assignment
	}

	// getter & setter methods

	public Ref<VerticalDistance> getVerticalDistance() {
		return this.verticalDistance;
	}

	public void setVerticalDistance(Ref<VerticalDistance> verticalDistance) {
		this.verticalDistance = verticalDistance;
	}
}
