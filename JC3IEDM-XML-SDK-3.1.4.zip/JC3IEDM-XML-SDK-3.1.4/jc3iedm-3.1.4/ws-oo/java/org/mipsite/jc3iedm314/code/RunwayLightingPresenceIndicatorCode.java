/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RunwayLightingPresenceIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific RUNWAY has runway lighting.";
	}

	private static HashMap<String, RunwayLightingPresenceIndicatorCode> physicalToCode = new HashMap<String, RunwayLightingPresenceIndicatorCode>();

	public static RunwayLightingPresenceIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RunwayLightingPresenceIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RunwayLightingPresenceIndicatorCode NO = new RunwayLightingPresenceIndicatorCode(
			"No",
			"NO",
			"At the specific RUNWAY there is no lighting.");
	public static final RunwayLightingPresenceIndicatorCode YES = new RunwayLightingPresenceIndicatorCode(
			"Yes",
			"YES",
			"At the specific RUNWAY there is lighting.");

	private RunwayLightingPresenceIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
