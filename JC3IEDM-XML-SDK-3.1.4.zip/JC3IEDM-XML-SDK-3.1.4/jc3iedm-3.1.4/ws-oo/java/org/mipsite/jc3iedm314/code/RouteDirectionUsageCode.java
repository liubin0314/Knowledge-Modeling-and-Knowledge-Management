/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RouteDirectionUsageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the assigned direction for the traffic on the route.";
	}

	private static HashMap<String, RouteDirectionUsageCode> physicalToCode = new HashMap<String, RouteDirectionUsageCode>();

	public static RouteDirectionUsageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RouteDirectionUsageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RouteDirectionUsageCode ALTERNATING = new RouteDirectionUsageCode(
			"Alternating",
			"ALTRNG",
			"The movement of traffic is controlled to be in one direction at any given time.");
	public static final RouteDirectionUsageCode ONE_WAY = new RouteDirectionUsageCode(
			"One-way",
			"ONEWAY",
			"Of a thoroughfare: along which traffic is permitted in only one direction; of traffic.");
	public static final RouteDirectionUsageCode TWO_WAY = new RouteDirectionUsageCode(
			"Two-way",
			"TWOWAY",
			"Occurring or existing in two directions; along which traffic is permitted in two directions.");

	private RouteDirectionUsageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
