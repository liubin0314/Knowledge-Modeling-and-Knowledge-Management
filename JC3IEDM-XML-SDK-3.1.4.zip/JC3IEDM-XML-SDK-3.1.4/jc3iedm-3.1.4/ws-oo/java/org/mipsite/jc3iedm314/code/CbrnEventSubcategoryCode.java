/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CbrnEventSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class or nature of activity prescribed by CBRN-EVENT.";
	}

	private static HashMap<String, CbrnEventSubcategoryCode> physicalToCode = new HashMap<String, CbrnEventSubcategoryCode>();

	public static CbrnEventSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CbrnEventSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CbrnEventSubcategoryCode AIR_SAMPLING = new CbrnEventSubcategoryCode(
			"Air sampling",
			"AIRSMP",
			"The operational action to confirm the presence of a gaseous contaminant.");
	public static final CbrnEventSubcategoryCode ALPHA_RADIATION_SOURCE_DETECTION = new CbrnEventSubcategoryCode(
			"Alpha radiation source detection",
			"ALPRAD",
			"The action performed to detect a source of Alpha radiation.");
	public static final CbrnEventSubcategoryCode AIR_BURST = new CbrnEventSubcategoryCode(
			"Air burst",
			"ARBRST",
			"An explosion of a bomb or projectile above the surface as distinguished from an explosion on contact with the surface or after penetration.");
	public static final CbrnEventSubcategoryCode BETA_RADIATION_SOURCE_DETECTION = new CbrnEventSubcategoryCode(
			"Beta radiation source detection",
			"BETRAD",
			"The action performed to detect a source of Beta radiation.");
	public static final CbrnEventSubcategoryCode BURNING_FIRE = new CbrnEventSubcategoryCode(
			"Burning Fire",
			"BRNFIR",
			"An event where a fire is consuming materiel and emitting smoke, which may be toxic.");
	public static final CbrnEventSubcategoryCode VISIBLE_NBC_CLOUD = new CbrnEventSubcategoryCode(
			"Visible NBC cloud",
			"CBRNCL",
			"The action of detecting a visible NBC (CBRN) cloud.");
	public static final CbrnEventSubcategoryCode CONTINUOUS_FLOW_FROM_DAMAGED_PIPE_OR_CONTAINER = new CbrnEventSubcategoryCode(
			"Continuous flow from damaged pipe or container",
			"CNTFLW",
			"An event where a continuous flow of possibly toxic liquid is spilled from a container.");
	public static final CbrnEventSubcategoryCode GAMMA_RADIATION_SOURCE_DETECTION = new CbrnEventSubcategoryCode(
			"Gamma radiation source detection",
			"GAMRAD",
			"The action performed to detect a source of Gamma radiation.");
	public static final CbrnEventSubcategoryCode LIQUID_SAMPLING = new CbrnEventSubcategoryCode(
			"Liquid sampling",
			"LQDSMP",
			"The operational action to confirm the presence of a liquid contaminant.");
	public static final CbrnEventSubcategoryCode LARGE_QUANTITY_OF_SPILL_LIQUID = new CbrnEventSubcategoryCode(
			"Large quantity of spill liquid",
			"LRGSPL",
			"An event where a large quantity of possibly toxic liquid is spilled.");
	public static final CbrnEventSubcategoryCode NEUTRON_RADIATION_SOURCE_DETECTION = new CbrnEventSubcategoryCode(
			"Neutron radiation source detection",
			"NEUTRN",
			"The action performed to detect a source of Neutron particle.");
	public static final CbrnEventSubcategoryCode NOT_KNOWN = new CbrnEventSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final CbrnEventSubcategoryCode NOT_OTHERWISE_SPECIFIED = new CbrnEventSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final CbrnEventSubcategoryCode SUB_SURFACE_BURST = new CbrnEventSubcategoryCode(
			"Sub surface burst",
			"SBSRBU",
			"The explosion of a nuclear weapon in which the centre of the detonation lies at a point beneath the surface of the ground.");
	public static final CbrnEventSubcategoryCode SAMPLING_IDENTIFICATION_OF_BIOLOGICAL_CHEMICAL_AGENT_SAMPLE = new CbrnEventSubcategoryCode(
			"Sampling/identification of biological/chemical agent sample",
			"SIBCA",
			"The forensic expertise performed to confirm to commanders the actual occurrence of a chemical or biological event.");
	public static final CbrnEventSubcategoryCode SAMPLING_AND_IDENTIFICATION_OF_RADIOLOGICAL_AGENT_SAMPLE = new CbrnEventSubcategoryCode(
			"Sampling and identification of radiological agent sample",
			"SIRA",
			"The forensic expertise performed to confirm to commanders the actual occurrence of a Nuclear event.");
	public static final CbrnEventSubcategoryCode SMALL_QUANTITY_OF_SPILL_LIQUID = new CbrnEventSubcategoryCode(
			"Small quantity of spill liquid",
			"SMLSPL",
			"An event where a small quantity of possibly toxic liquid is spilled.");
	public static final CbrnEventSubcategoryCode SURFACE_BURST = new CbrnEventSubcategoryCode(
			"Surface burst",
			"SURBUR",
			"An explosion of a nuclear weapon at the surface of land or water; or above the surface at a height less than the maximum radius of the fireball.");

	private CbrnEventSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
