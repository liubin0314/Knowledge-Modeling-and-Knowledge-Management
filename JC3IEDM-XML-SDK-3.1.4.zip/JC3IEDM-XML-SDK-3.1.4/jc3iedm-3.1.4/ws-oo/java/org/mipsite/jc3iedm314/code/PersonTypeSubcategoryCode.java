/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of PERSON-TYPE.";
	}

	private static HashMap<String, PersonTypeSubcategoryCode> physicalToCode = new HashMap<String, PersonTypeSubcategoryCode>();

	public static PersonTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonTypeSubcategoryCode CONTRACTOR = new PersonTypeSubcategoryCode(
			"Contractor",
			"CNTRCT",
			"A PERSON-TYPE who contracts or undertakes to supply certain articles, or to perform any work or service (esp. for government or other public body) at a certain price or rate.");
	public static final PersonTypeSubcategoryCode CRIMINAL = new PersonTypeSubcategoryCode(
			"Criminal",
			"CRIMIN",
			"A PERSON-TYPE who violates the law.");
	public static final PersonTypeSubcategoryCode DEFECTOR = new PersonTypeSubcategoryCode(
			"Defector",
			"DEFCTR",
			"A PERSON-TYPE who has abandoned their country or cause for another country or cause.");
	public static final PersonTypeSubcategoryCode DETAINEE = new PersonTypeSubcategoryCode(
			"Detainee",
			"DETNEE",
			"A person detained in custody, especially for political reasons.");
	public static final PersonTypeSubcategoryCode DISPLACED_PERSON = new PersonTypeSubcategoryCode(
			"Displaced person",
			"DSPLPR",
			"A PERSON-TYPE who has been removed from their home country by military or political pressure and thereafter homeless.");
	public static final PersonTypeSubcategoryCode DESERTER = new PersonTypeSubcategoryCode(
			"Deserter",
			"DSRTR",
			"A PERSON-TYPE who has abandoned their country or cause.");
	public static final PersonTypeSubcategoryCode EDUCATIONAL = new PersonTypeSubcategoryCode(
			"Educational",
			"EDUCAL",
			"A PERSON-TYPE who provides labour and materiel for the educational process.");
	public static final PersonTypeSubcategoryCode ENGINEER = new PersonTypeSubcategoryCode(
			"Engineer",
			"ENGNER",
			"A PERSON-TYPE that is identified as one who designs and constructs facilities.");
	public static final PersonTypeSubcategoryCode FINANCIAL = new PersonTypeSubcategoryCode(
			"Financial",
			"FINCAL",
			"A PERSON-TYPE who provides financial support.");
	public static final PersonTypeSubcategoryCode FOREIGN_FIGHTER = new PersonTypeSubcategoryCode(
			"Foreign fighter",
			"FRNFGT",
			"A PERSON-TYPE consists of a fighter who is not from the country in which the fighting is taking place supporting belligerents or irregular forces.");
	public static final PersonTypeSubcategoryCode GOVERNMENT_EMPLOYEE = new PersonTypeSubcategoryCode(
			"Government employee",
			"GOVEMP",
			"A PERSON-TYPE who is representing a Governmental Organisation and is not a uniformed member of a regular armed force.");
	public static final PersonTypeSubcategoryCode INSURGENT = new PersonTypeSubcategoryCode(
			"Insurgent",
			"INSRGT",
			"A PERSON-TYPE that rises in revolt against authority.");
	public static final PersonTypeSubcategoryCode INTELLIGENCE = new PersonTypeSubcategoryCode(
			"Intelligence",
			"INTEL",
			"A PERSON-TYPE that is employed to gather information.");
	public static final PersonTypeSubcategoryCode INTELLECTUAL = new PersonTypeSubcategoryCode(
			"Intellectual",
			"INTLCT",
			"A PERSON-TYPE who is an intellectual being; a person possessing or supposed to possess superior powers of intellect.");
	public static final PersonTypeSubcategoryCode JOURNALIST = new PersonTypeSubcategoryCode(
			"Journalist",
			"JRNLST",
			"A PERSON-TYPE who earns a living by editing or writing for a public journal.");
	public static final PersonTypeSubcategoryCode JUDICIAL = new PersonTypeSubcategoryCode(
			"Judicial",
			"JUDCAL",
			"A PERSON-TYPE provides judgment in courts of justice or to the administration of justice.");
	public static final PersonTypeSubcategoryCode LANDOWNER = new PersonTypeSubcategoryCode(
			"Landowner",
			"LNDOWN",
			"A PERSON-TYPE who is an owner or proprietor of land.");
	public static final PersonTypeSubcategoryCode MANUFACTURING_WORKER = new PersonTypeSubcategoryCode(
			"Manufacturing worker",
			"MANFCT",
			"A PERSON-TYPE that is identified as one who manufactures products; excluding utility, transportation, and financial companies.");
	public static final PersonTypeSubcategoryCode MEDICAL = new PersonTypeSubcategoryCode(
			"Medical",
			"MEDCAL",
			"A PERSON-TYPE that is identified as a medical practitioner.");
	public static final PersonTypeSubcategoryCode MEDIA_INTERNATIONAL = new PersonTypeSubcategoryCode(
			"Media, international",
			"MEDINT",
			"A PERSON-TYPE who is reporting for international mass communications, but not taking part in the actions.");
	public static final PersonTypeSubcategoryCode MEDIA_LOCAL = new PersonTypeSubcategoryCode(
			"Media, local",
			"MEDLCL",
			"A PERSON-TYPE who is reporting for local mass communications, but not taking part in the actions.");
	public static final PersonTypeSubcategoryCode MEDIA_NATIONAL = new PersonTypeSubcategoryCode(
			"Media, national",
			"MEDNAT",
			"A PERSON-TYPE who is reporting for national mass communications, but not taking part in the actions.");
	public static final PersonTypeSubcategoryCode MEDIA_NOT_OTHERWISE_SPECIFIED = new PersonTypeSubcategoryCode(
			"Media, not otherwise specified",
			"MEDNOS",
			"A PERSON-TYPE who is reporting for mass communications (especially television, radio, and newspapers) of an origin not specified.");
	public static final PersonTypeSubcategoryCode MESSENGER = new PersonTypeSubcategoryCode(
			"Messenger",
			"MESSNG",
			"A PERSON-TYPE that is identified as a carrier of a message.");
	public static final PersonTypeSubcategoryCode MISSIONARY = new PersonTypeSubcategoryCode(
			"Missionary",
			"MISSNR",
			"A PERSON-TYPE who is concerned with religious missions in the form of missionary work.");
	public static final PersonTypeSubcategoryCode MERCHANT = new PersonTypeSubcategoryCode(
			"Merchant",
			"MRCHNT",
			"A PERSON-TYPE whose occupation is the purchase and sale of marketable commodities for profit.");
	public static final PersonTypeSubcategoryCode NOT_KNOWN = new PersonTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonTypeSubcategoryCode NON_GOVERNMENT_EMPLOYEE = new PersonTypeSubcategoryCode(
			"Non-government employee",
			"NONGVE",
			"A PERSON-TYPE who is representing a Non-Governmental Organisation and is not a uniformed member of a regular armed force.");
	public static final PersonTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new PersonTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final PersonTypeSubcategoryCode PARARESCUE_JUMPER = new PersonTypeSubcategoryCode(
			"Pararescue jumper",
			"PARARS",
			"A PERSON-TYPE who is specially trained and qualified to penetrate to the site of an incident by land or parachute, render medical aid, accomplish survival methods, and rescue survivors.");
	public static final PersonTypeSubcategoryCode PARTISAN = new PersonTypeSubcategoryCode(
			"Partisan",
			"PARTSN",
			"A PERSON-TYPE who is a member of a party of light or irregular troops employed in scouring the country, surprising the enemy's outposts and foraging parties.");
	public static final PersonTypeSubcategoryCode PILOT = new PersonTypeSubcategoryCode(
			"Pilot",
			"PILOT",
			"A PERSON-TYPE that is identified as one who controls an aircraft, balloon, spacecraft, or the like during flight, usually a person duly qualified to do so.");
	public static final PersonTypeSubcategoryCode POLICE_CHIEF = new PersonTypeSubcategoryCode(
			"Police chief",
			"POLCHF",
			"A PERSON-TYPE who has the responsibility for the regulation, discipline, and control of a community for the enforcement of law and public order.");
	public static final PersonTypeSubcategoryCode POLICEMAN = new PersonTypeSubcategoryCode(
			"Policeman",
			"POLCMN",
			"A PERSON-TYPE that is identified as a member of a police force.");
	public static final PersonTypeSubcategoryCode POLITICAL = new PersonTypeSubcategoryCode(
			"Political",
			"POLTCL",
			"A PERSON-TYPE that is identified as being involved within a political area of activity and concerned with politics or has ties to a political party.");
	public static final PersonTypeSubcategoryCode PRISONER_OF_WAR = new PersonTypeSubcategoryCode(
			"Prisoner of war",
			"POW",
			"A PERSON-TYPE who, while engaged in combat under orders of his or her government, is captured by the armed forces of the enemy.");
	public static final PersonTypeSubcategoryCode PRISONER = new PersonTypeSubcategoryCode(
			"Prisoner",
			"PRSNR",
			"A PERSON-TYPE in custody on a criminal charge and on trial.");
	public static final PersonTypeSubcategoryCode REFUGEE = new PersonTypeSubcategoryCode(
			"Refugee",
			"REFUGE",
			"A PERSON-TYPE who, because of real or imagined danger, moves of his own volition, spontaneously, or in violation of a �stay-put� policy.");
	public static final PersonTypeSubcategoryCode REPATRIATE = new PersonTypeSubcategoryCode(
			"Repatriate",
			"REPAT",
			"A PERSON-TYPE who has returned to his or her native land.");
	public static final PersonTypeSubcategoryCode SABOTEUR = new PersonTypeSubcategoryCode(
			"Saboteur",
			"SABOTR",
			"A PERSON-TYPE who commits sabotage.");
	public static final PersonTypeSubcategoryCode SOCIAL = new PersonTypeSubcategoryCode(
			"Social",
			"SOCIAL",
			"A PERSON-TYPE that seeks and enjoys companies of others, or characterized by friendly companionship or relations.");
	public static final PersonTypeSubcategoryCode SPY = new PersonTypeSubcategoryCode(
			"Spy",
			"SPY",
			"A PERSON-TYPE who is employed to obtain intelligence information to which he or she would not normally be allowed access.");
	public static final PersonTypeSubcategoryCode TERRORIST = new PersonTypeSubcategoryCode(
			"Terrorist",
			"TERRST",
			"A PERSON-TYPE who attempts to further their views by a system of coercive intimidation.");
	public static final PersonTypeSubcategoryCode UNLAWFUL_COMBATANT = new PersonTypeSubcategoryCode(
			"Unlawful combatant",
			"UNLCMB",
			"An individual who is not authorised to take part in hostilities but does.");
	public static final PersonTypeSubcategoryCode VILLAGE_ELDER = new PersonTypeSubcategoryCode(
			"Village elder",
			"VILELD",
			"A PERSON-TYPE of ripe years and experience whose counsel is therefore sought and valued.");
	public static final PersonTypeSubcategoryCode VERY_IMPORTANT_PERSON = new PersonTypeSubcategoryCode(
			"Very important person",
			"VIP",
			"A PERSON-TYPE of high ranking and/or an important individual.");
	public static final PersonTypeSubcategoryCode WRITER = new PersonTypeSubcategoryCode(
			"Writer",
			"WRITER",
			"A PERSON-TYPE who practices or performs writing.");

	private PersonTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
