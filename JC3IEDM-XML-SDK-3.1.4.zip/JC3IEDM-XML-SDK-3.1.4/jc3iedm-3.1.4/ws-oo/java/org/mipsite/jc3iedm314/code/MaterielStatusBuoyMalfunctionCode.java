/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusBuoyMalfunctionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of malfunction of a buoy.";
	}

	private static HashMap<String, MaterielStatusBuoyMalfunctionCode> physicalToCode = new HashMap<String, MaterielStatusBuoyMalfunctionCode>();

	public static MaterielStatusBuoyMalfunctionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusBuoyMalfunctionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusBuoyMalfunctionCode BUOY_NOT_IN_SIGHT = new MaterielStatusBuoyMalfunctionCode(
			"Buoy not in sight",
			"BUOYNT",
			"The buoy is no longer visible in the location/area deployed.");
	public static final MaterielStatusBuoyMalfunctionCode NO_FLAG = new MaterielStatusBuoyMalfunctionCode(
			"No flag",
			"NOFLAG",
			"The buoy does not display a marker flag.");
	public static final MaterielStatusBuoyMalfunctionCode NO_LIGHT = new MaterielStatusBuoyMalfunctionCode(
			"No light",
			"NOLGHT",
			"The buoy no longer has an operable lighting mechanism.");
	public static final MaterielStatusBuoyMalfunctionCode NO_RADAR_REFLECTION = new MaterielStatusBuoyMalfunctionCode(
			"No radar reflection",
			"NORADR",
			"The buoy does not produce an acceptable radar reflection.");
	public static final MaterielStatusBuoyMalfunctionCode SERVICEABLE_BUOY_HAS_DRAGGED_ITS_POSITION = new MaterielStatusBuoyMalfunctionCode(
			"Serviceable buoy has dragged its position",
			"SERVCE",
			"The buoy has moved from its original placed location.");

	private MaterielStatusBuoyMalfunctionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
