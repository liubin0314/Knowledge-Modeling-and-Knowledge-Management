/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OperationalCapabilityLevelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the force level at which the specific OPERATIONAL-CAPABILITY is intended to be performed.";
	}

	private static HashMap<String, OperationalCapabilityLevelCode> physicalToCode = new HashMap<String, OperationalCapabilityLevelCode>();

	public static OperationalCapabilityLevelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OperationalCapabilityLevelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OperationalCapabilityLevelCode CORPS = new OperationalCapabilityLevelCode(
			"Corps",
			"CORPS",
			"The specific mission can be performed at Corps level of command.");
	public static final OperationalCapabilityLevelCode DIVISION = new OperationalCapabilityLevelCode(
			"Division",
			"DIV",
			"The specific mission can be performed at Division level of command.");
	public static final OperationalCapabilityLevelCode FORCE = new OperationalCapabilityLevelCode(
			"Force",
			"FORCE",
			"The specific mission can be performed at Force level of command.");
	public static final OperationalCapabilityLevelCode OPERATIONAL = new OperationalCapabilityLevelCode(
			"Operational",
			"OPR",
			"The specific mission can be performed at Operational level of command.");
	public static final OperationalCapabilityLevelCode STRATEGIC = new OperationalCapabilityLevelCode(
			"Strategic",
			"STRTGC",
			"The specific mission can be performed at Strategic level of command.");
	public static final OperationalCapabilityLevelCode TACTICAL = new OperationalCapabilityLevelCode(
			"Tactical",
			"TACTCL",
			"The specific mission can be performed at Tactical level of command.");
	public static final OperationalCapabilityLevelCode THEATRE = new OperationalCapabilityLevelCode(
			"Theatre",
			"THTRE",
			"The specific mission can be performed at Theatre level of command.");

	private OperationalCapabilityLevelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
