/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AffiliationGeopoliticalCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the identification of the independent first-level geographic-political area and its dependencies, areas of quasi-independence, and areas with special unrecognised sovereignty, including outlying and disputed areas.";
	}

	private static HashMap<String, AffiliationGeopoliticalCode> physicalToCode = new HashMap<String, AffiliationGeopoliticalCode>();

	public static AffiliationGeopoliticalCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AffiliationGeopoliticalCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AffiliationGeopoliticalCode ARUBA = new AffiliationGeopoliticalCode(
			"Aruba",
			"ABW",
			"");
	public static final AffiliationGeopoliticalCode AFGHANISTAN = new AffiliationGeopoliticalCode(
			"Afghanistan",
			"AFG",
			"");
	public static final AffiliationGeopoliticalCode ANGOLA = new AffiliationGeopoliticalCode(
			"Angola",
			"AGO",
			"");
	public static final AffiliationGeopoliticalCode ANGUILLA = new AffiliationGeopoliticalCode(
			"Anguilla",
			"AIA",
			"");
	public static final AffiliationGeopoliticalCode �LAND_ISLANDS = new AffiliationGeopoliticalCode(
			"�land Islands",
			"ALA",
			"Self governing part of Finland (added in 2004).");
	public static final AffiliationGeopoliticalCode ALBANIA = new AffiliationGeopoliticalCode(
			"Albania",
			"ALB",
			"");
	public static final AffiliationGeopoliticalCode ANDORRA = new AffiliationGeopoliticalCode(
			"Andorra",
			"AND",
			"");
	public static final AffiliationGeopoliticalCode NETHERLANDS_ANTILLES = new AffiliationGeopoliticalCode(
			"Netherlands Antilles",
			"ANT",
			"");
	public static final AffiliationGeopoliticalCode UNITED_ARAB_EMIRATES = new AffiliationGeopoliticalCode(
			"United Arab Emirates",
			"ARE",
			"");
	public static final AffiliationGeopoliticalCode ARGENTINA = new AffiliationGeopoliticalCode(
			"Argentina",
			"ARG",
			"");
	public static final AffiliationGeopoliticalCode ARMENIA = new AffiliationGeopoliticalCode(
			"Armenia",
			"ARM",
			"");
	public static final AffiliationGeopoliticalCode AMERICAN_SAMOA = new AffiliationGeopoliticalCode(
			"American Samoa",
			"ASM",
			"");
	public static final AffiliationGeopoliticalCode ANTARCTICA = new AffiliationGeopoliticalCode(
			"Antarctica",
			"ATA",
			"");
	public static final AffiliationGeopoliticalCode FRENCH_SOUTHERN_TERRITORIES = new AffiliationGeopoliticalCode(
			"French Southern Territories",
			"ATF",
			"");
	public static final AffiliationGeopoliticalCode ANTIGUA_AND_BARBUDA = new AffiliationGeopoliticalCode(
			"Antigua and Barbuda",
			"ATG",
			"");
	public static final AffiliationGeopoliticalCode AUSTRALIA = new AffiliationGeopoliticalCode(
			"Australia",
			"AUS",
			"");
	public static final AffiliationGeopoliticalCode AUSTRIA = new AffiliationGeopoliticalCode(
			"Austria",
			"AUT",
			"");
	public static final AffiliationGeopoliticalCode AZERBAIJAN = new AffiliationGeopoliticalCode(
			"Azerbaijan",
			"AZE",
			"");
	public static final AffiliationGeopoliticalCode BURUNDI = new AffiliationGeopoliticalCode(
			"Burundi",
			"BDI",
			"");
	public static final AffiliationGeopoliticalCode BELGIUM = new AffiliationGeopoliticalCode(
			"Belgium",
			"BEL",
			"");
	public static final AffiliationGeopoliticalCode BENIN = new AffiliationGeopoliticalCode(
			"Benin",
			"BEN",
			"Formerly Dahomey (1977)");
	public static final AffiliationGeopoliticalCode BURKINA_FASO = new AffiliationGeopoliticalCode(
			"Burkina Faso",
			"BFA",
			"Formerly Upper Volta (1984)");
	public static final AffiliationGeopoliticalCode BANGLADESH = new AffiliationGeopoliticalCode(
			"Bangladesh",
			"BGD",
			"");
	public static final AffiliationGeopoliticalCode BULGARIA = new AffiliationGeopoliticalCode(
			"Bulgaria",
			"BGR",
			"");
	public static final AffiliationGeopoliticalCode BAHRAIN = new AffiliationGeopoliticalCode(
			"Bahrain",
			"BHR",
			"");
	public static final AffiliationGeopoliticalCode BAHAMAS = new AffiliationGeopoliticalCode(
			"Bahamas",
			"BHS",
			"");
	public static final AffiliationGeopoliticalCode BOSNIA_AND_HERZEGOVINA = new AffiliationGeopoliticalCode(
			"Bosnia and Herzegovina",
			"BIH",
			"");
	public static final AffiliationGeopoliticalCode BELARUS = new AffiliationGeopoliticalCode(
			"Belarus",
			"BLR",
			"");
	public static final AffiliationGeopoliticalCode BELIZE = new AffiliationGeopoliticalCode(
			"Belize",
			"BLZ",
			"");
	public static final AffiliationGeopoliticalCode BERMUDA = new AffiliationGeopoliticalCode(
			"Bermuda",
			"BMU",
			"");
	public static final AffiliationGeopoliticalCode BOLIVIA = new AffiliationGeopoliticalCode(
			"Bolivia",
			"BOL",
			"");
	public static final AffiliationGeopoliticalCode BRAZIL = new AffiliationGeopoliticalCode(
			"Brazil",
			"BRA",
			"");
	public static final AffiliationGeopoliticalCode BARBADOS = new AffiliationGeopoliticalCode(
			"Barbados",
			"BRB",
			"");
	public static final AffiliationGeopoliticalCode BRUNEI_DARUSSALAM = new AffiliationGeopoliticalCode(
			"Brunei Darussalam",
			"BRN",
			"");
	public static final AffiliationGeopoliticalCode BHUTAN = new AffiliationGeopoliticalCode(
			"Bhutan",
			"BTN",
			"");
	public static final AffiliationGeopoliticalCode BOUVET_ISLAND = new AffiliationGeopoliticalCode(
			"Bouvet Island",
			"BVT",
			"");
	public static final AffiliationGeopoliticalCode BOTSWANA = new AffiliationGeopoliticalCode(
			"Botswana",
			"BWA",
			"");
	public static final AffiliationGeopoliticalCode CENTRAL_AFRICAN_REPUBLIC = new AffiliationGeopoliticalCode(
			"Central African Republic",
			"CAF",
			"");
	public static final AffiliationGeopoliticalCode CANADA = new AffiliationGeopoliticalCode(
			"Canada",
			"CAN",
			"");
	public static final AffiliationGeopoliticalCode COCOS_KEELING_ISLANDS = new AffiliationGeopoliticalCode(
			"Cocos (Keeling) Islands",
			"CCK",
			"");
	public static final AffiliationGeopoliticalCode SWITZERLAND = new AffiliationGeopoliticalCode(
			"Switzerland",
			"CHE",
			"");
	public static final AffiliationGeopoliticalCode CHILE = new AffiliationGeopoliticalCode(
			"Chile",
			"CHL",
			"");
	public static final AffiliationGeopoliticalCode CHINA = new AffiliationGeopoliticalCode(
			"China",
			"CHN",
			"");
	public static final AffiliationGeopoliticalCode COTE_D_IVOIRE = new AffiliationGeopoliticalCode(
			"Cote d'Ivoire",
			"CIV",
			"Formerly Ivory Coast");
	public static final AffiliationGeopoliticalCode CAMEROON = new AffiliationGeopoliticalCode(
			"Cameroon",
			"CMR",
			"");
	public static final AffiliationGeopoliticalCode CONGO_DEMOCRATIC_REPUBLIC_OF_THE = new AffiliationGeopoliticalCode(
			"Congo, Democratic Republic of the",
			"COD",
			"");
	public static final AffiliationGeopoliticalCode CONGO = new AffiliationGeopoliticalCode(
			"Congo",
			"COG",
			"");
	public static final AffiliationGeopoliticalCode COOK_ISLANDS = new AffiliationGeopoliticalCode(
			"Cook Islands",
			"COK",
			"");
	public static final AffiliationGeopoliticalCode COLOMBIA = new AffiliationGeopoliticalCode(
			"Colombia",
			"COL",
			"");
	public static final AffiliationGeopoliticalCode COMOROS = new AffiliationGeopoliticalCode(
			"Comoros",
			"COM",
			"");
	public static final AffiliationGeopoliticalCode CAPE_VERDE = new AffiliationGeopoliticalCode(
			"Cape Verde",
			"CPV",
			"");
	public static final AffiliationGeopoliticalCode COSTA_RICA = new AffiliationGeopoliticalCode(
			"Costa Rica",
			"CRI",
			"");
	public static final AffiliationGeopoliticalCode CZECH_AND_SLOVAK_FEDERATIVE_REPUBLIC_FORMER = new AffiliationGeopoliticalCode(
			"Czech and Slovak Federative Republic (former)",
			"CSHH",
			"(1993)");
	public static final AffiliationGeopoliticalCode SERBIA_AND_MONTENEGRO_FORMER = new AffiliationGeopoliticalCode(
			"Serbia and Montenegro (former)",
			"CSXX",
			"");
	public static final AffiliationGeopoliticalCode CUBA = new AffiliationGeopoliticalCode(
			"Cuba",
			"CUB",
			"");
	public static final AffiliationGeopoliticalCode CHRISTMAS_ISLAND = new AffiliationGeopoliticalCode(
			"Christmas Island",
			"CXR",
			"");
	public static final AffiliationGeopoliticalCode CAYMAN_ISLANDS = new AffiliationGeopoliticalCode(
			"Cayman Islands",
			"CYM",
			"");
	public static final AffiliationGeopoliticalCode CYPRUS = new AffiliationGeopoliticalCode(
			"Cyprus",
			"CYP",
			"");
	public static final AffiliationGeopoliticalCode CZECH_REPUBLIC = new AffiliationGeopoliticalCode(
			"Czech Republic",
			"CZE",
			"");
	public static final AffiliationGeopoliticalCode GERMAN_DEMOCRATIC_REPUBLIC_FORMER = new AffiliationGeopoliticalCode(
			"German Democratic Republic (former)",
			"DDDE",
			"GDR (1990)");
	public static final AffiliationGeopoliticalCode GERMANY = new AffiliationGeopoliticalCode(
			"Germany",
			"DEU",
			"");
	public static final AffiliationGeopoliticalCode DJIBOUTI = new AffiliationGeopoliticalCode(
			"Djibouti",
			"DJI",
			"");
	public static final AffiliationGeopoliticalCode DOMINICA = new AffiliationGeopoliticalCode(
			"Dominica",
			"DMA",
			"");
	public static final AffiliationGeopoliticalCode DENMARK = new AffiliationGeopoliticalCode(
			"Denmark",
			"DNK",
			"");
	public static final AffiliationGeopoliticalCode DOMINICAN_REPUBLIC = new AffiliationGeopoliticalCode(
			"Dominican Republic",
			"DOM",
			"");
	public static final AffiliationGeopoliticalCode ALGERIA = new AffiliationGeopoliticalCode(
			"Algeria",
			"DZA",
			"");
	public static final AffiliationGeopoliticalCode ECUADOR = new AffiliationGeopoliticalCode(
			"Ecuador",
			"ECU",
			"");
	public static final AffiliationGeopoliticalCode EGYPT = new AffiliationGeopoliticalCode(
			"Egypt",
			"EGY",
			"");
	public static final AffiliationGeopoliticalCode ERITREA = new AffiliationGeopoliticalCode(
			"Eritrea",
			"ERI",
			"");
	public static final AffiliationGeopoliticalCode WESTERN_SAHARA = new AffiliationGeopoliticalCode(
			"Western Sahara",
			"ESH",
			"");
	public static final AffiliationGeopoliticalCode SPAIN = new AffiliationGeopoliticalCode(
			"Spain",
			"ESP",
			"");
	public static final AffiliationGeopoliticalCode ESTONIA = new AffiliationGeopoliticalCode(
			"Estonia",
			"EST",
			"");
	public static final AffiliationGeopoliticalCode ETHIOPIA = new AffiliationGeopoliticalCode(
			"Ethiopia",
			"ETH",
			"");
	public static final AffiliationGeopoliticalCode FINLAND = new AffiliationGeopoliticalCode(
			"Finland",
			"FIN",
			"");
	public static final AffiliationGeopoliticalCode FIJI = new AffiliationGeopoliticalCode(
			"Fiji",
			"FJI",
			"");
	public static final AffiliationGeopoliticalCode FALKLAND_ISLANDS_MALVINAS = new AffiliationGeopoliticalCode(
			"Falkland Islands (Malvinas)",
			"FLK",
			"");
	public static final AffiliationGeopoliticalCode FRANCE = new AffiliationGeopoliticalCode(
			"France",
			"FRA",
			"");
	public static final AffiliationGeopoliticalCode FAROE_ISLANDS = new AffiliationGeopoliticalCode(
			"Faroe Islands",
			"FRO",
			"");
	public static final AffiliationGeopoliticalCode MICRONESIA_FEDERATED_STATES_OF = new AffiliationGeopoliticalCode(
			"Micronesia Federated States of",
			"FSM",
			"");
	public static final AffiliationGeopoliticalCode FRANCE_METROPOLITAN_FORMER = new AffiliationGeopoliticalCode(
			"France, Metropolitan (former)",
			"FXFR",
			"");
	public static final AffiliationGeopoliticalCode GABON = new AffiliationGeopoliticalCode(
			"Gabon",
			"GAB",
			"");
	public static final AffiliationGeopoliticalCode UNITED_KINGDOM = new AffiliationGeopoliticalCode(
			"United Kingdom",
			"GBR",
			"");
	public static final AffiliationGeopoliticalCode GEORGIA = new AffiliationGeopoliticalCode(
			"Georgia",
			"GEO",
			"");
	public static final AffiliationGeopoliticalCode GUERNSEY = new AffiliationGeopoliticalCode(
			"Guernsey",
			"GGY",
			"No longer a subdivision of GBR (2006).");
	public static final AffiliationGeopoliticalCode GHANA = new AffiliationGeopoliticalCode(
			"Ghana",
			"GHA",
			"");
	public static final AffiliationGeopoliticalCode GIBRALTAR = new AffiliationGeopoliticalCode(
			"Gibraltar",
			"GIB",
			"");
	public static final AffiliationGeopoliticalCode GUINEA = new AffiliationGeopoliticalCode(
			"Guinea",
			"GIN",
			"");
	public static final AffiliationGeopoliticalCode GUADELOUPE = new AffiliationGeopoliticalCode(
			"Guadeloupe",
			"GLP",
			"");
	public static final AffiliationGeopoliticalCode GAMBIA = new AffiliationGeopoliticalCode(
			"Gambia",
			"GMB",
			"");
	public static final AffiliationGeopoliticalCode GUINEA_BISSAU = new AffiliationGeopoliticalCode(
			"Guinea-Bissau",
			"GNB",
			"");
	public static final AffiliationGeopoliticalCode EQUATORIAL_GUINEA = new AffiliationGeopoliticalCode(
			"Equatorial Guinea",
			"GNQ",
			"");
	public static final AffiliationGeopoliticalCode GREECE = new AffiliationGeopoliticalCode(
			"Greece",
			"GRC",
			"");
	public static final AffiliationGeopoliticalCode GRENADA = new AffiliationGeopoliticalCode(
			"Grenada",
			"GRD",
			"");
	public static final AffiliationGeopoliticalCode GREENLAND = new AffiliationGeopoliticalCode(
			"Greenland",
			"GRL",
			"");
	public static final AffiliationGeopoliticalCode GUATEMALA = new AffiliationGeopoliticalCode(
			"Guatemala",
			"GTM",
			"");
	public static final AffiliationGeopoliticalCode FRENCH_GUIANA = new AffiliationGeopoliticalCode(
			"French Guiana",
			"GUF",
			"");
	public static final AffiliationGeopoliticalCode GUAM = new AffiliationGeopoliticalCode(
			"Guam",
			"GUM",
			"");
	public static final AffiliationGeopoliticalCode GUYANA = new AffiliationGeopoliticalCode(
			"Guyana",
			"GUY",
			"");
	public static final AffiliationGeopoliticalCode HONG_KONG = new AffiliationGeopoliticalCode(
			"Hong Kong",
			"HKG",
			"");
	public static final AffiliationGeopoliticalCode HEARD_AND_MCDONALD_ISLANDS = new AffiliationGeopoliticalCode(
			"Heard and Mcdonald Islands",
			"HMD",
			"");
	public static final AffiliationGeopoliticalCode HONDURAS = new AffiliationGeopoliticalCode(
			"Honduras",
			"HND",
			"");
	public static final AffiliationGeopoliticalCode CROATIA = new AffiliationGeopoliticalCode(
			"Croatia",
			"HRV",
			"");
	public static final AffiliationGeopoliticalCode HAITI = new AffiliationGeopoliticalCode(
			"Haiti",
			"HTI",
			"");
	public static final AffiliationGeopoliticalCode HUNGARY = new AffiliationGeopoliticalCode(
			"Hungary",
			"HUN",
			"");
	public static final AffiliationGeopoliticalCode INDONESIA = new AffiliationGeopoliticalCode(
			"Indonesia",
			"IDN",
			"");
	public static final AffiliationGeopoliticalCode ISLE_OF_MAN = new AffiliationGeopoliticalCode(
			"Isle of Man",
			"IMN",
			"No longer a subdivision of GBR (2006).");
	public static final AffiliationGeopoliticalCode INDIA = new AffiliationGeopoliticalCode(
			"India",
			"IND",
			"");
	public static final AffiliationGeopoliticalCode BRITISH_INDIAN_OCEAN_TERRITORY = new AffiliationGeopoliticalCode(
			"British Indian Ocean Territory",
			"IOT",
			"");
	public static final AffiliationGeopoliticalCode IRELAND = new AffiliationGeopoliticalCode(
			"Ireland",
			"IRL",
			"");
	public static final AffiliationGeopoliticalCode IRAN_ISLAMIC_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Iran, Islamic Republic of",
			"IRN",
			"");
	public static final AffiliationGeopoliticalCode IRAQ = new AffiliationGeopoliticalCode(
			"Iraq",
			"IRQ",
			"");
	public static final AffiliationGeopoliticalCode ICELAND = new AffiliationGeopoliticalCode(
			"Iceland",
			"ISL",
			"");
	public static final AffiliationGeopoliticalCode ISRAEL = new AffiliationGeopoliticalCode(
			"Israel",
			"ISR",
			"");
	public static final AffiliationGeopoliticalCode ITALY = new AffiliationGeopoliticalCode(
			"Italy",
			"ITA",
			"");
	public static final AffiliationGeopoliticalCode JAMAICA = new AffiliationGeopoliticalCode(
			"Jamaica",
			"JAM",
			"");
	public static final AffiliationGeopoliticalCode JERSEY = new AffiliationGeopoliticalCode(
			"Jersey",
			"JEY",
			"No longer a subdivision of GBR (2006).");
	public static final AffiliationGeopoliticalCode JORDAN = new AffiliationGeopoliticalCode(
			"Jordan",
			"JOR",
			"");
	public static final AffiliationGeopoliticalCode JAPAN = new AffiliationGeopoliticalCode(
			"Japan",
			"JPN",
			"");
	public static final AffiliationGeopoliticalCode KAZAKHSTAN = new AffiliationGeopoliticalCode(
			"Kazakhstan",
			"KAZ",
			"");
	public static final AffiliationGeopoliticalCode KENYA = new AffiliationGeopoliticalCode(
			"Kenya",
			"KEN",
			"");
	public static final AffiliationGeopoliticalCode KYRGYZSTAN = new AffiliationGeopoliticalCode(
			"Kyrgyzstan",
			"KGZ",
			"");
	public static final AffiliationGeopoliticalCode CAMBODIA = new AffiliationGeopoliticalCode(
			"Cambodia",
			"KHM",
			"Formerly Kampuchea");
	public static final AffiliationGeopoliticalCode KIRIBATI = new AffiliationGeopoliticalCode(
			"Kiribati",
			"KIR",
			"");
	public static final AffiliationGeopoliticalCode SAINT_KITTS_AND_NEVIS = new AffiliationGeopoliticalCode(
			"Saint Kitts and Nevis",
			"KNA",
			"");
	public static final AffiliationGeopoliticalCode KOREA_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Korea, Republic of",
			"KOR",
			"");
	public static final AffiliationGeopoliticalCode KUWAIT = new AffiliationGeopoliticalCode(
			"Kuwait",
			"KWT",
			"");
	public static final AffiliationGeopoliticalCode LAO_PEOPLE_S_DEMOCRATIC_REPUBLIC = new AffiliationGeopoliticalCode(
			"Lao People's Democratic Republic",
			"LAO",
			"");
	public static final AffiliationGeopoliticalCode LEBANON = new AffiliationGeopoliticalCode(
			"Lebanon",
			"LBN",
			"");
	public static final AffiliationGeopoliticalCode LIBERIA = new AffiliationGeopoliticalCode(
			"Liberia",
			"LBR",
			"");
	public static final AffiliationGeopoliticalCode LIBYAN_ARAB_JAMAHIRIYA = new AffiliationGeopoliticalCode(
			"Libyan Arab Jamahiriya",
			"LBY",
			"");
	public static final AffiliationGeopoliticalCode SAINT_LUCIA = new AffiliationGeopoliticalCode(
			"Saint Lucia",
			"LCA",
			"");
	public static final AffiliationGeopoliticalCode LIECHTENSTEIN = new AffiliationGeopoliticalCode(
			"Liechtenstein",
			"LIE",
			"");
	public static final AffiliationGeopoliticalCode SRI_LANKA = new AffiliationGeopoliticalCode(
			"Sri Lanka",
			"LKA",
			"");
	public static final AffiliationGeopoliticalCode LESOTHO = new AffiliationGeopoliticalCode(
			"Lesotho",
			"LSO",
			"");
	public static final AffiliationGeopoliticalCode LITHUANIA = new AffiliationGeopoliticalCode(
			"Lithuania",
			"LTU",
			"");
	public static final AffiliationGeopoliticalCode LUXEMBOURG = new AffiliationGeopoliticalCode(
			"Luxembourg",
			"LUX",
			"");
	public static final AffiliationGeopoliticalCode LATVIA = new AffiliationGeopoliticalCode(
			"Latvia",
			"LVA",
			"");
	public static final AffiliationGeopoliticalCode MACAO = new AffiliationGeopoliticalCode(
			"Macao",
			"MAC",
			"");
	public static final AffiliationGeopoliticalCode MOROCCO = new AffiliationGeopoliticalCode(
			"Morocco",
			"MAR",
			"");
	public static final AffiliationGeopoliticalCode MONACO = new AffiliationGeopoliticalCode(
			"Monaco",
			"MCO",
			"");
	public static final AffiliationGeopoliticalCode MOLDOVA_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Moldova, Republic of",
			"MDA",
			"");
	public static final AffiliationGeopoliticalCode MADAGASCAR = new AffiliationGeopoliticalCode(
			"Madagascar",
			"MDG",
			"");
	public static final AffiliationGeopoliticalCode MALDIVES = new AffiliationGeopoliticalCode(
			"Maldives",
			"MDV",
			"");
	public static final AffiliationGeopoliticalCode MEXICO = new AffiliationGeopoliticalCode(
			"Mexico",
			"MEX",
			"");
	public static final AffiliationGeopoliticalCode MARSHALL_ISLANDS = new AffiliationGeopoliticalCode(
			"Marshall Islands",
			"MHL",
			"");
	public static final AffiliationGeopoliticalCode MACEDONIA_THE_FORMER_YUGOSLAV_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Macedonia, the former Yugoslav Republic of",
			"MKD",
			"");
	public static final AffiliationGeopoliticalCode MALI = new AffiliationGeopoliticalCode(
			"Mali",
			"MLI",
			"");
	public static final AffiliationGeopoliticalCode MALTA = new AffiliationGeopoliticalCode(
			"Malta",
			"MLT",
			"");
	public static final AffiliationGeopoliticalCode MYANMAR = new AffiliationGeopoliticalCode(
			"Myanmar",
			"MMR",
			"Formerly Burma (1989)");
	public static final AffiliationGeopoliticalCode MONTENEGRO = new AffiliationGeopoliticalCode(
			"Montenegro",
			"MNE",
			"New entry after split of Serbia and Montenegro.");
	public static final AffiliationGeopoliticalCode MONGOLIA = new AffiliationGeopoliticalCode(
			"Mongolia",
			"MNG",
			"");
	public static final AffiliationGeopoliticalCode NORTHERN_MARIANA_ISLANDS = new AffiliationGeopoliticalCode(
			"Northern Mariana Islands",
			"MNP",
			"");
	public static final AffiliationGeopoliticalCode MOZAMBIQUE = new AffiliationGeopoliticalCode(
			"Mozambique",
			"MOZ",
			"");
	public static final AffiliationGeopoliticalCode MAURITANIA = new AffiliationGeopoliticalCode(
			"Mauritania",
			"MRT",
			"");
	public static final AffiliationGeopoliticalCode MONTSERRAT = new AffiliationGeopoliticalCode(
			"Montserrat",
			"MSR",
			"");
	public static final AffiliationGeopoliticalCode MARTINIQUE = new AffiliationGeopoliticalCode(
			"Martinique",
			"MTQ",
			"");
	public static final AffiliationGeopoliticalCode MAURITIUS = new AffiliationGeopoliticalCode(
			"Mauritius",
			"MUS",
			"");
	public static final AffiliationGeopoliticalCode MALAWI = new AffiliationGeopoliticalCode(
			"Malawi",
			"MWI",
			"");
	public static final AffiliationGeopoliticalCode MALAYSIA = new AffiliationGeopoliticalCode(
			"Malaysia",
			"MYS",
			"");
	public static final AffiliationGeopoliticalCode MAYOTTE = new AffiliationGeopoliticalCode(
			"Mayotte",
			"MYT",
			"");
	public static final AffiliationGeopoliticalCode NAMIBIA = new AffiliationGeopoliticalCode(
			"Namibia",
			"NAM",
			"");
	public static final AffiliationGeopoliticalCode NEW_CALEDONIA = new AffiliationGeopoliticalCode(
			"New Caledonia",
			"NCL",
			"");
	public static final AffiliationGeopoliticalCode NIGER = new AffiliationGeopoliticalCode(
			"Niger",
			"NER",
			"");
	public static final AffiliationGeopoliticalCode NORFOLK_ISLAND = new AffiliationGeopoliticalCode(
			"Norfolk Island",
			"NFK",
			"");
	public static final AffiliationGeopoliticalCode NIGERIA = new AffiliationGeopoliticalCode(
			"Nigeria",
			"NGA",
			"");
	public static final AffiliationGeopoliticalCode NICARAGUA = new AffiliationGeopoliticalCode(
			"Nicaragua",
			"NIC",
			"");
	public static final AffiliationGeopoliticalCode NIUE = new AffiliationGeopoliticalCode(
			"Niue",
			"NIU",
			"");
	public static final AffiliationGeopoliticalCode NETHERLANDS = new AffiliationGeopoliticalCode(
			"Netherlands",
			"NLD",
			"");
	public static final AffiliationGeopoliticalCode NORWAY = new AffiliationGeopoliticalCode(
			"Norway",
			"NOR",
			"");
	public static final AffiliationGeopoliticalCode NOT_OTHERWISE_SPECIFIED = new AffiliationGeopoliticalCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AffiliationGeopoliticalCode NEPAL = new AffiliationGeopoliticalCode(
			"Nepal",
			"NPL",
			"");
	public static final AffiliationGeopoliticalCode NAURU = new AffiliationGeopoliticalCode(
			"Nauru",
			"NRU",
			"");
	public static final AffiliationGeopoliticalCode NEW_ZEALAND = new AffiliationGeopoliticalCode(
			"New Zealand",
			"NZL",
			"");
	public static final AffiliationGeopoliticalCode OMAN = new AffiliationGeopoliticalCode(
			"Oman",
			"OMN",
			"");
	public static final AffiliationGeopoliticalCode PAKISTAN = new AffiliationGeopoliticalCode(
			"Pakistan",
			"PAK",
			"");
	public static final AffiliationGeopoliticalCode PANAMA = new AffiliationGeopoliticalCode(
			"Panama",
			"PAN",
			"");
	public static final AffiliationGeopoliticalCode PITCAIRN = new AffiliationGeopoliticalCode(
			"Pitcairn",
			"PCN",
			"");
	public static final AffiliationGeopoliticalCode PERU = new AffiliationGeopoliticalCode(
			"Peru",
			"PER",
			"");
	public static final AffiliationGeopoliticalCode PHILIPPINES = new AffiliationGeopoliticalCode(
			"Philippines",
			"PHL",
			"");
	public static final AffiliationGeopoliticalCode PALAU = new AffiliationGeopoliticalCode(
			"Palau",
			"PLW",
			"");
	public static final AffiliationGeopoliticalCode PAPUA_NEW_GUINEA = new AffiliationGeopoliticalCode(
			"Papua New Guinea",
			"PNG",
			"");
	public static final AffiliationGeopoliticalCode POLAND = new AffiliationGeopoliticalCode(
			"Poland",
			"POL",
			"");
	public static final AffiliationGeopoliticalCode PUERTO_RICO = new AffiliationGeopoliticalCode(
			"Puerto Rico",
			"PRI",
			"");
	public static final AffiliationGeopoliticalCode KOREA_DEMOCRATIC_PEOPLE_S_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Korea, Democratic People's Republic of",
			"PRK",
			"");
	public static final AffiliationGeopoliticalCode PORTUGAL = new AffiliationGeopoliticalCode(
			"Portugal",
			"PRT",
			"");
	public static final AffiliationGeopoliticalCode PARAGUAY = new AffiliationGeopoliticalCode(
			"Paraguay",
			"PRY",
			"");
	public static final AffiliationGeopoliticalCode PALESTINIAN_TERRITORY_OCCUPIED = new AffiliationGeopoliticalCode(
			"Palestinian Territory, Occupied",
			"PSE",
			"");
	public static final AffiliationGeopoliticalCode FRENCH_POLYNESIA = new AffiliationGeopoliticalCode(
			"French Polynesia",
			"PYF",
			"");
	public static final AffiliationGeopoliticalCode QATAR = new AffiliationGeopoliticalCode(
			"Qatar",
			"QAT",
			"");
	public static final AffiliationGeopoliticalCode REUNION = new AffiliationGeopoliticalCode(
			"Reunion",
			"REU",
			"");
	public static final AffiliationGeopoliticalCode ROMANIA = new AffiliationGeopoliticalCode(
			"Romania",
			"ROU",
			"");
	public static final AffiliationGeopoliticalCode RUSSIAN_FEDERATION = new AffiliationGeopoliticalCode(
			"Russian Federation",
			"RUS",
			"");
	public static final AffiliationGeopoliticalCode RWANDA = new AffiliationGeopoliticalCode(
			"Rwanda",
			"RWA",
			"");
	public static final AffiliationGeopoliticalCode SAUDI_ARABIA = new AffiliationGeopoliticalCode(
			"Saudi Arabia",
			"SAU",
			"");
	public static final AffiliationGeopoliticalCode SUDAN = new AffiliationGeopoliticalCode(
			"Sudan",
			"SDN",
			"");
	public static final AffiliationGeopoliticalCode SENEGAL = new AffiliationGeopoliticalCode(
			"Senegal",
			"SEN",
			"");
	public static final AffiliationGeopoliticalCode SINGAPORE = new AffiliationGeopoliticalCode(
			"Singapore",
			"SGP",
			"");
	public static final AffiliationGeopoliticalCode SOUTH_GEORGIA_AND_THE_SOUTH_SANDWICH_ISLANDS = new AffiliationGeopoliticalCode(
			"South Georgia and the South Sandwich Islands",
			"SGS",
			"");
	public static final AffiliationGeopoliticalCode SAINT_HELENA = new AffiliationGeopoliticalCode(
			"Saint Helena",
			"SHN",
			"");
	public static final AffiliationGeopoliticalCode SVALBARD_AND_JAN_MAYEN_ISLANDS = new AffiliationGeopoliticalCode(
			"Svalbard and Jan Mayen Islands",
			"SJM",
			"");
	public static final AffiliationGeopoliticalCode SOLOMON_ISLANDS = new AffiliationGeopoliticalCode(
			"Solomon Islands",
			"SLB",
			"");
	public static final AffiliationGeopoliticalCode SIERRA_LEONE = new AffiliationGeopoliticalCode(
			"Sierra Leone",
			"SLE",
			"");
	public static final AffiliationGeopoliticalCode EL_SALVADOR = new AffiliationGeopoliticalCode(
			"El Salvador",
			"SLV",
			"");
	public static final AffiliationGeopoliticalCode SAN_MARINO = new AffiliationGeopoliticalCode(
			"San Marino",
			"SMR",
			"");
	public static final AffiliationGeopoliticalCode SOMALIA = new AffiliationGeopoliticalCode(
			"Somalia",
			"SOM",
			"");
	public static final AffiliationGeopoliticalCode SAINT_PIERRE_AND_MIQUELON = new AffiliationGeopoliticalCode(
			"Saint Pierre and Miquelon",
			"SPM",
			"");
	public static final AffiliationGeopoliticalCode SERBIA = new AffiliationGeopoliticalCode(
			"Serbia",
			"SRB",
			"New entry after split of Serbia and Montenegro.");
	public static final AffiliationGeopoliticalCode SAO_TOME_AND_PRINCIPE = new AffiliationGeopoliticalCode(
			"Sao Tome and Principe",
			"STP",
			"");
	public static final AffiliationGeopoliticalCode UNION_OF_SOVIET_SOCIALIST_REPUBLICS_FORMER = new AffiliationGeopoliticalCode(
			"Union of Soviet Socialist Republics (former)",
			"SUHH",
			"USSR (1992)");
	public static final AffiliationGeopoliticalCode SURINAME = new AffiliationGeopoliticalCode(
			"Suriname",
			"SUR",
			"");
	public static final AffiliationGeopoliticalCode SLOVAKIA = new AffiliationGeopoliticalCode(
			"Slovakia",
			"SVK",
			"");
	public static final AffiliationGeopoliticalCode SLOVENIA = new AffiliationGeopoliticalCode(
			"Slovenia",
			"SVN",
			"");
	public static final AffiliationGeopoliticalCode SWEDEN = new AffiliationGeopoliticalCode(
			"Sweden",
			"SWE",
			"");
	public static final AffiliationGeopoliticalCode SWAZILAND = new AffiliationGeopoliticalCode(
			"Swaziland",
			"SWZ",
			"");
	public static final AffiliationGeopoliticalCode SEYCHELLES = new AffiliationGeopoliticalCode(
			"Seychelles",
			"SYC",
			"");
	public static final AffiliationGeopoliticalCode SYRIAN_ARAB_REPUBLIC = new AffiliationGeopoliticalCode(
			"Syrian Arab Republic",
			"SYR",
			"");
	public static final AffiliationGeopoliticalCode TURKS_AND_CAICOS_ISLANDS = new AffiliationGeopoliticalCode(
			"Turks and Caicos Islands",
			"TCA",
			"");
	public static final AffiliationGeopoliticalCode CHAD = new AffiliationGeopoliticalCode(
			"Chad",
			"TCD",
			"");
	public static final AffiliationGeopoliticalCode TOGO = new AffiliationGeopoliticalCode(
			"Togo",
			"TGO",
			"");
	public static final AffiliationGeopoliticalCode THAILAND = new AffiliationGeopoliticalCode(
			"Thailand",
			"THA",
			"");
	public static final AffiliationGeopoliticalCode TAJIKISTAN = new AffiliationGeopoliticalCode(
			"Tajikistan",
			"TJK",
			"");
	public static final AffiliationGeopoliticalCode TOKELAU = new AffiliationGeopoliticalCode(
			"Tokelau",
			"TKL",
			"");
	public static final AffiliationGeopoliticalCode TURKMENISTAN = new AffiliationGeopoliticalCode(
			"Turkmenistan",
			"TKM",
			"");
	public static final AffiliationGeopoliticalCode TIMOR_LESTE = new AffiliationGeopoliticalCode(
			"Timor-Leste",
			"TLS",
			"Formerly East Timor (2002)");
	public static final AffiliationGeopoliticalCode TONGA = new AffiliationGeopoliticalCode(
			"Tonga",
			"TON",
			"");
	public static final AffiliationGeopoliticalCode TRINIDAD_AND_TOBAGO = new AffiliationGeopoliticalCode(
			"Trinidad and Tobago",
			"TTO",
			"");
	public static final AffiliationGeopoliticalCode TUNISIA = new AffiliationGeopoliticalCode(
			"Tunisia",
			"TUN",
			"");
	public static final AffiliationGeopoliticalCode TURKEY = new AffiliationGeopoliticalCode(
			"Turkey",
			"TUR",
			"");
	public static final AffiliationGeopoliticalCode TUVALU = new AffiliationGeopoliticalCode(
			"Tuvalu",
			"TUV",
			"");
	public static final AffiliationGeopoliticalCode TAIWAN_PROVINCE_OF_CHINA = new AffiliationGeopoliticalCode(
			"Taiwan, Province of China",
			"TWN",
			"");
	public static final AffiliationGeopoliticalCode TANZANIA_UNITED_REPUBLIC_OF = new AffiliationGeopoliticalCode(
			"Tanzania, United Republic of",
			"TZA",
			"");
	public static final AffiliationGeopoliticalCode UGANDA = new AffiliationGeopoliticalCode(
			"Uganda",
			"UGA",
			"");
	public static final AffiliationGeopoliticalCode UKRAINE = new AffiliationGeopoliticalCode(
			"Ukraine",
			"UKR",
			"");
	public static final AffiliationGeopoliticalCode UNITED_STATES_MINOR_OUTLYING_ISLANDS = new AffiliationGeopoliticalCode(
			"United States Minor Outlying Islands",
			"UMI",
			"");
	public static final AffiliationGeopoliticalCode URUGUAY = new AffiliationGeopoliticalCode(
			"Uruguay",
			"URY",
			"");
	public static final AffiliationGeopoliticalCode UNITED_STATES = new AffiliationGeopoliticalCode(
			"United States",
			"USA",
			"");
	public static final AffiliationGeopoliticalCode UZBEKISTAN = new AffiliationGeopoliticalCode(
			"Uzbekistan",
			"UZB",
			"");
	public static final AffiliationGeopoliticalCode HOLY_SEE_VATICAN_CITY_STATE = new AffiliationGeopoliticalCode(
			"Holy See (Vatican City State)",
			"VAT",
			"");
	public static final AffiliationGeopoliticalCode SAINT_VINCENT_AND_THE_GRENADINES = new AffiliationGeopoliticalCode(
			"Saint Vincent and the Grenadines",
			"VCT",
			"");
	public static final AffiliationGeopoliticalCode VENEZUELA = new AffiliationGeopoliticalCode(
			"Venezuela",
			"VEN",
			"");
	public static final AffiliationGeopoliticalCode VIRGIN_ISLANDS_BRITISH = new AffiliationGeopoliticalCode(
			"Virgin Islands, British",
			"VGB",
			"");
	public static final AffiliationGeopoliticalCode VIRGIN_ISLANDS_U_S = new AffiliationGeopoliticalCode(
			"Virgin Islands, U.S.",
			"VIR",
			"");
	public static final AffiliationGeopoliticalCode VIET_NAM = new AffiliationGeopoliticalCode(
			"Viet Nam",
			"VNM",
			"");
	public static final AffiliationGeopoliticalCode VANUATU = new AffiliationGeopoliticalCode(
			"Vanuatu",
			"VUT",
			"Formerly New Hebrides (1980)");
	public static final AffiliationGeopoliticalCode WALLIS_AND_FUTUNA_ISLANDS = new AffiliationGeopoliticalCode(
			"Wallis and Futuna Islands",
			"WLF",
			"");
	public static final AffiliationGeopoliticalCode SAMOA = new AffiliationGeopoliticalCode(
			"Samoa",
			"WSM",
			"");
	public static final AffiliationGeopoliticalCode YEMEN = new AffiliationGeopoliticalCode(
			"Yemen",
			"YEM",
			"");
	public static final AffiliationGeopoliticalCode YUGOSLAVIA_FORMER = new AffiliationGeopoliticalCode(
			"Yugoslavia (former)",
			"YUCS",
			"(2003)");
	public static final AffiliationGeopoliticalCode SOUTH_AFRICA = new AffiliationGeopoliticalCode(
			"South Africa",
			"ZAF",
			"");
	public static final AffiliationGeopoliticalCode ZAMBIA = new AffiliationGeopoliticalCode(
			"Zambia",
			"ZMB",
			"");
	public static final AffiliationGeopoliticalCode ZIMBABWE = new AffiliationGeopoliticalCode(
			"Zimbabwe",
			"ZWE",
			"");

	private AffiliationGeopoliticalCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
