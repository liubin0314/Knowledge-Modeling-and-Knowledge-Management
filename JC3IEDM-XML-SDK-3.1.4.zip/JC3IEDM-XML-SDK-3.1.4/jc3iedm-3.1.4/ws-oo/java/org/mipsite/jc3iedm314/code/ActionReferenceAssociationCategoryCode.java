/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a specific ACTION-REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, ActionReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, ActionReferenceAssociationCategoryCode>();

	public static ActionReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionReferenceAssociationCategoryCode IS_AMPLIFIED_BY = new ActionReferenceAssociationCategoryCode(
			"Is amplified by",
			"ISAMPL",
			"The specific ACTION has additional detail provided in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_CHANGED_BY = new ActionReferenceAssociationCategoryCode(
			"Is changed by",
			"ISCHNG",
			"The specific ACTION is amended as the result of the provisions in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_CANCELLED_BY = new ActionReferenceAssociationCategoryCode(
			"Is cancelled by",
			"ISCNCL",
			"The specific ACTION is terminated in response to the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_DEFINED_BY = new ActionReferenceAssociationCategoryCode(
			"Is defined by",
			"ISDFND",
			"The specific ACTION is prescribed in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_DIRECTED_BY = new ActionReferenceAssociationCategoryCode(
			"Is directed by",
			"ISDRCT",
			"The specific ACTION is to be executed as ordered in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_DESCRIBED_BY = new ActionReferenceAssociationCategoryCode(
			"Is described by",
			"ISDSCR",
			"The specific ACTION is depicted in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_PROVIDED_BACKGROUND_INFORMATION_BY = new ActionReferenceAssociationCategoryCode(
			"Is provided background information by",
			"ISPRBK",
			"The specific ACTION is provided supplementary information in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_REFERENCED_BY = new ActionReferenceAssociationCategoryCode(
			"Is referenced by",
			"ISRFRN",
			"The specific ACTION is alluded to in the artefact cited in the specific REFERENCE.");
	public static final ActionReferenceAssociationCategoryCode IS_REPORTED_BY = new ActionReferenceAssociationCategoryCode(
			"Is reported by",
			"ISRPTD",
			"The specific ACTION is given a formal account in the artefact cited in the specific REFERENCE.");

	private ActionReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
