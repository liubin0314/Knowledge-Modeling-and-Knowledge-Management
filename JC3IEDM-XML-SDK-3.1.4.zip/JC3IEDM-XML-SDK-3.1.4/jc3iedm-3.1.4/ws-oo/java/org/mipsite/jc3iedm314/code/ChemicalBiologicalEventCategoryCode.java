/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ChemicalBiologicalEventCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CHEMICAL-BIOLOGICAL-EVENT.";
	}

	private static HashMap<String, ChemicalBiologicalEventCategoryCode> physicalToCode = new HashMap<String, ChemicalBiologicalEventCategoryCode>();

	public static ChemicalBiologicalEventCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ChemicalBiologicalEventCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ChemicalBiologicalEventCategoryCode BIOLOGICAL_ALARM = new ChemicalBiologicalEventCategoryCode(
			"Biological alarm",
			"BIOALM",
			"An action by which a biological detector is triggered or a group is warned.");
	public static final ChemicalBiologicalEventCategoryCode BIOLOGICAL_ATTACK = new ChemicalBiologicalEventCategoryCode(
			"Biological attack",
			"BIOATT",
			"Employing the use of biological materiel(s) [agent(s)] to kill, injure, or incapacitate, for a significant period of time, man or animals, and deny or hinder the use of areas, facilities or materiel, or defence against such employment.");
	public static final ChemicalBiologicalEventCategoryCode BIOLOGICAL_SAMPLING = new ChemicalBiologicalEventCategoryCode(
			"Biological sampling",
			"BIOSMP",
			"The action of detecting a biological contaminant.");
	public static final ChemicalBiologicalEventCategoryCode BIOLOGICAL_RELEASE_OTHER_THAN_ATTACK_ROTA = new ChemicalBiologicalEventCategoryCode(
			"Biological release other than attack (ROTA)",
			"BIROTA",
			"The release of a biological agent or toxin into the environment intentionally or accidentally but not for the intended purpose of conducting an attack.");
	public static final ChemicalBiologicalEventCategoryCode CHEMICAL_BIOLOGICAL_FACILITY_EVENT = new ChemicalBiologicalEventCategoryCode(
			"Chemical/biological facility event",
			"CBFAC",
			"An event that involves viable agent released to the atmosphere following a strike against a facility containing chemical warfare agent(s) and/or biological warfare agent(s).");
	public static final ChemicalBiologicalEventCategoryCode CHEMICAL_ALARM = new ChemicalBiologicalEventCategoryCode(
			"Chemical alarm",
			"CHMALM",
			"An action by which a chemical detector is triggered or a group is warned.");
	public static final ChemicalBiologicalEventCategoryCode CHEMICAL_ATTACK = new ChemicalBiologicalEventCategoryCode(
			"Chemical attack",
			"CHMATT",
			"Employing the use of chemical materiel(s) [agent(s)] to produce casualties in man or animals and damage to plants or materiel; or defence against such employment.");
	public static final ChemicalBiologicalEventCategoryCode CHEMICAL_SAMPLING = new ChemicalBiologicalEventCategoryCode(
			"Chemical sampling",
			"CHMSMP",
			"The action of detecting a chemical contaminant.");
	public static final ChemicalBiologicalEventCategoryCode CHEMICAL_RELEASE_OTHER_THAN_ATTACK_ROTA = new ChemicalBiologicalEventCategoryCode(
			"Chemical release other than attack (ROTA)",
			"CHROTA",
			"The release of chemicals or chemical agents into the environment intentionally or accidentally but not for the intended purpose of conducting an attack.");
	public static final ChemicalBiologicalEventCategoryCode NOT_KNOWN = new ChemicalBiologicalEventCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private ChemicalBiologicalEventCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
