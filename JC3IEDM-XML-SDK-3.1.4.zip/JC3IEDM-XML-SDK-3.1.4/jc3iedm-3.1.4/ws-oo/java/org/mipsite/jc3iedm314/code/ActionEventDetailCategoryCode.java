/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEventDetailCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-EVENT-DETAIL.";
	}

	private static HashMap<String, ActionEventDetailCategoryCode> physicalToCode = new HashMap<String, ActionEventDetailCategoryCode>();

	public static ActionEventDetailCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEventDetailCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEventDetailCategoryCode IED_TACTICAL_CHARACTERIZATION = new ActionEventDetailCategoryCode(
			"IED-TACTICAL-CHARACTERIZATION",
			"IEDTC",
			"An ACTION-EVENT-DETAIL that describes how an IED incident was conducted or intended to be conducted.");
	public static final ActionEventDetailCategoryCode NOT_OTHERWISE_SPECIFIED = new ActionEventDetailCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private ActionEventDetailCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
