/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusReserveIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific FACILITY has been placed in reserve.";
	}

	private static HashMap<String, FacilityStatusReserveIndicatorCode> physicalToCode = new HashMap<String, FacilityStatusReserveIndicatorCode>();

	public static FacilityStatusReserveIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusReserveIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusReserveIndicatorCode NO = new FacilityStatusReserveIndicatorCode(
			"No",
			"NO",
			"The specific FACILITY is not in reserve status.");
	public static final FacilityStatusReserveIndicatorCode YES = new FacilityStatusReserveIndicatorCode(
			"Yes",
			"YES",
			"The specific FACILITY is currently in reserve status.");

	private FacilityStatusReserveIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
