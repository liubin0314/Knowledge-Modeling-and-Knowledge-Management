/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypePerishabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a particular CONSUMABLE-MATERIEL-TYPE is liable to decay or spoil.";
	}

	private static HashMap<String, ConsumableMaterielTypePerishabilityIndicatorCode> physicalToCode = new HashMap<String, ConsumableMaterielTypePerishabilityIndicatorCode>();

	public static ConsumableMaterielTypePerishabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypePerishabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypePerishabilityIndicatorCode NO = new ConsumableMaterielTypePerishabilityIndicatorCode(
			"No",
			"NO",
			"The CONSUMABLE-MATERIEL-TYPE is not liable to decay or spoil.");
	public static final ConsumableMaterielTypePerishabilityIndicatorCode YES = new ConsumableMaterielTypePerishabilityIndicatorCode(
			"Yes",
			"YES",
			"The CONSUMABLE-MATERIEL-TYPE is liable to decay or spoil.");

	private ConsumableMaterielTypePerishabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
