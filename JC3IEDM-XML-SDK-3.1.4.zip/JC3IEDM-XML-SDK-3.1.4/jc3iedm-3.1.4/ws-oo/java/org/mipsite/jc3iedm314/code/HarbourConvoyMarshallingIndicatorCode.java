/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourConvoyMarshallingIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of supplying convoy-marshalling facilities.";
	}

	private static HashMap<String, HarbourConvoyMarshallingIndicatorCode> physicalToCode = new HashMap<String, HarbourConvoyMarshallingIndicatorCode>();

	public static HarbourConvoyMarshallingIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourConvoyMarshallingIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourConvoyMarshallingIndicatorCode NO = new HarbourConvoyMarshallingIndicatorCode(
			"No",
			"NO",
			"Convoy-marshalling facilities are not available at the harbour.");
	public static final HarbourConvoyMarshallingIndicatorCode YES = new HarbourConvoyMarshallingIndicatorCode(
			"Yes",
			"YES",
			"Convoy-marshalling facilities are available at the harbour.");

	private HarbourConvoyMarshallingIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
