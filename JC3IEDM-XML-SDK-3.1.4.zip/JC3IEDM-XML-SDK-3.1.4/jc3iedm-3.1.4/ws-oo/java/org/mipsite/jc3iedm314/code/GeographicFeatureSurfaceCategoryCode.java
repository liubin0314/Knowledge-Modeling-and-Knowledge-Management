/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureSurfaceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of surface of the GEOGRAPHIC-FEATURE.";
	}

	private static HashMap<String, GeographicFeatureSurfaceCategoryCode> physicalToCode = new HashMap<String, GeographicFeatureSurfaceCategoryCode>();

	public static GeographicFeatureSurfaceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureSurfaceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureSurfaceCategoryCode LIQUID_SURFACE = new GeographicFeatureSurfaceCategoryCode(
			"Liquid surface",
			"LQDSRF",
			"The boundary of a liquid with the atmosphere or solid.");
	public static final GeographicFeatureSurfaceCategoryCode NOT_OTHERWISE_SPECIFIED = new GeographicFeatureSurfaceCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final GeographicFeatureSurfaceCategoryCode SOLID_SURFACE = new GeographicFeatureSurfaceCategoryCode(
			"Solid surface",
			"SLDSRF",
			"The boundary of the ground with the atmosphere or liquid.");

	private GeographicFeatureSurfaceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
