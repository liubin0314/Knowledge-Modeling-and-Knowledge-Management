/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetDetailCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes a CANDIDATE-TARGET-DETAIL as being an item or a type.";
	}

	private static HashMap<String, CandidateTargetDetailCategoryCode> physicalToCode = new HashMap<String, CandidateTargetDetailCategoryCode>();

	public static CandidateTargetDetailCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetDetailCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetDetailCategoryCode CANDIDATE_TARGET_DETAIL_ITEM = new CandidateTargetDetailCategoryCode(
			"CANDIDATE-TARGET-DETAIL-ITEM",
			"CTDITM",
			"An instance of CANDIDATE-TARGET-DETAIL that is an OBJECT-ITEM.");
	public static final CandidateTargetDetailCategoryCode CANDIDATE_TARGET_DETAIL_TYPE = new CandidateTargetDetailCategoryCode(
			"CANDIDATE-TARGET-DETAIL-TYPE",
			"CTDTYP",
			"An instance of CANDIDATE-TARGET-DETAIL that is an OBJECT-TYPE.");

	private CandidateTargetDetailCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
