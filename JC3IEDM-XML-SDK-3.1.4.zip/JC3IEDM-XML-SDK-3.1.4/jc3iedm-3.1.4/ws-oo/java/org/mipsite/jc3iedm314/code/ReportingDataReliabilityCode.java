/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataReliabilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents, for intelligence purpose, the general appraisal of the source in graded terms to indicate the extent to which it has been proven it can be counted on or trusted in to do as expected.";
	}

	private static HashMap<String, ReportingDataReliabilityCode> physicalToCode = new HashMap<String, ReportingDataReliabilityCode>();

	public static ReportingDataReliabilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataReliabilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataReliabilityCode COMPLETELY_RELIABLE = new ReportingDataReliabilityCode(
			"Completely reliable",
			"A",
			"The source of the reported data can be considered as completely reliable, i.e. erroneous information cannot be produced.");
	public static final ReportingDataReliabilityCode USUALLY_RELIABLE = new ReportingDataReliabilityCode(
			"Usually reliable",
			"B",
			"The source of the reported data can be considered as usually reliable, i.e. erroneous information can be produced, but the probability of such events can be neglected.");
	public static final ReportingDataReliabilityCode FAIRLY_RELIABLE = new ReportingDataReliabilityCode(
			"Fairly reliable",
			"C",
			"The source of the reported data can be considered as fairly reliable, i.e. erroneous information can be produced, with a probability that cannot be neglected.");
	public static final ReportingDataReliabilityCode NOT_USUALLY_RELIABLE = new ReportingDataReliabilityCode(
			"Not usually reliable",
			"D",
			"The source of the reported data is not usually reliable, i.e. the probability of producing erroneous information is high (>30%).");
	public static final ReportingDataReliabilityCode UNRELIABLE = new ReportingDataReliabilityCode(
			"Unreliable",
			"E",
			"The source of the reported data is not reliable, i.e. the produced reported data can generally be considered as erroneous.");
	public static final ReportingDataReliabilityCode RELIABILITY_CANNOT_BE_JUDGED = new ReportingDataReliabilityCode(
			"Reliability cannot be judged",
			"F",
			"The reliability of the source of the reported data cannot be estimated.");

	private ReportingDataReliabilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
