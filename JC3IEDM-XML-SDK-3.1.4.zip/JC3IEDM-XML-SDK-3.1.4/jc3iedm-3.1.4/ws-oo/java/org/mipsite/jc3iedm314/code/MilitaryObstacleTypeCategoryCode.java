/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryObstacleTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MILITARY-OBSTACLE-TYPE.";
	}

	private static HashMap<String, MilitaryObstacleTypeCategoryCode> physicalToCode = new HashMap<String, MilitaryObstacleTypeCategoryCode>();

	public static MilitaryObstacleTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryObstacleTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryObstacleTypeCategoryCode ABATIS = new MilitaryObstacleTypeCategoryCode(
			"Abatis",
			"ABATIS",
			"A vehicular obstacle constructed by felling trees (leaving a 1-2 meter stump above the ground on both sides of a road, trail, gap, or defile) so that they fall, interlocking, toward the expected direction of enemy approach. The trees should remain attached to the stumps, be at a 45 degree angle to the roadway, and the obstacle itself should be at least 75 meters in depth to be most effective.");
	public static final MilitaryObstacleTypeCategoryCode ANTI_TANK_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Anti-tank obstacle",
			"ANTOBS",
			"A facility that is an obstacle that is designed or employed to disrupt, fix, turn or block the movement of tanks.");
	public static final MilitaryObstacleTypeCategoryCode ANTI_TANK_WALL = new MilitaryObstacleTypeCategoryCode(
			"Anti-tank wall",
			"ANTWAL",
			"A wall-like obstacle capable of stopping tanks.");
	public static final MilitaryObstacleTypeCategoryCode ANTI_TANK_DITCH = new MilitaryObstacleTypeCategoryCode(
			"Anti-tank ditch",
			"ATDTCH",
			"A facility that is a ditch obstacle designed to stop tanks.");
	public static final MilitaryObstacleTypeCategoryCode BARBED_WIRE_ENTANGLEMENT = new MilitaryObstacleTypeCategoryCode(
			"Barbed wire entanglement",
			"BARBEN",
			"An obstacle, consisting of twisted wires armed with barbs or sharp points.");
	public static final MilitaryObstacleTypeCategoryCode BARRIER_VEHICLE = new MilitaryObstacleTypeCategoryCode(
			"Barrier, vehicle",
			"BARVEH",
			"An obstruction made of vehicles erected to bar the advance of persons or vehicles, or to prevent access to a place.");
	public static final MilitaryObstacleTypeCategoryCode BEAM_POST_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Beam post obstacle",
			"BPSOBS",
			"A squared-off log or a large, oblong piece of timber, metal, or stone inserted in the ground to obstruct movement.");
	public static final MilitaryObstacleTypeCategoryCode CRATER_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Crater obstacle",
			"CRATER",
			"A pit or hole in the ground created by an explosion or an impact in order to be used as an obstacle.");
	public static final MilitaryObstacleTypeCategoryCode DITCH_OBSTACLE_NOT_OTHERWISE_SPECIFIED = new MilitaryObstacleTypeCategoryCode(
			"Ditch obstacle, not otherwise specified",
			"DCHNOS",
			"A channel constructed for the purpose of blocking movement.");
	public static final MilitaryObstacleTypeCategoryCode DRAGON_TEETH = new MilitaryObstacleTypeCategoryCode(
			"Dragon teeth",
			"DGT",
			"Regular spaced concrete or metal barriers laid in single or multiple rows to prevent vehicle movement.");
	public static final MilitaryObstacleTypeCategoryCode DEMOLITION_DEBRIS_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Demolition debris obstacle",
			"DMDBRS",
			"Debris obtained from the demolition of an object in order to be used as an obstacle.");
	public static final MilitaryObstacleTypeCategoryCode FALLING_BLOCK_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Falling block obstacle",
			"FBKOBS",
			"A structure that is maintained in an elevated position and can be dropped to form an obstacle.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_ANTI_PERSONNEL = new MilitaryObstacleTypeCategoryCode(
			"Minefield, anti-personnel",
			"MINEAP",
			"An obstacle made by laying mines of anti-personnel type laid with or without pattern.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_ANTI_TANK = new MilitaryObstacleTypeCategoryCode(
			"Minefield, anti-tank",
			"MINEAT",
			"An obstacle made by laying mines of anti-tank type laid with or without pattern.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_NOT_OTHERWISE_SPECIFIED = new MilitaryObstacleTypeCategoryCode(
			"Minefield, not otherwise specified",
			"MINEFD",
			"An obstacle made by laying mines of an unspecified type laid with or without pattern.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_MIXED = new MilitaryObstacleTypeCategoryCode(
			"Minefield, mixed",
			"MINEMX",
			"A minefield made by laying mines of both anti-personnel and anti-tank type laid with or without pattern.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_LAND = new MilitaryObstacleTypeCategoryCode(
			"Minefield, land",
			"MNFLLA",
			"An obstacle that is an area of land containing mines.");
	public static final MilitaryObstacleTypeCategoryCode MINEFIELD_MARITIME = new MilitaryObstacleTypeCategoryCode(
			"Minefield, maritime",
			"MNFLMA",
			"An obstacle that is made by laying maritime mines in a body of water with or without pattern.");
	public static final MilitaryObstacleTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new MilitaryObstacleTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MilitaryObstacleTypeCategoryCode ROADBLOCK = new MilitaryObstacleTypeCategoryCode(
			"Roadblock",
			"ROADBL",
			"A barrier or obstacle (usually covered by fire) used to block, or limit the movement of, hostile vehicles along a route.");
	public static final MilitaryObstacleTypeCategoryCode TRIP_WIRE = new MilitaryObstacleTypeCategoryCode(
			"Trip wire",
			"TRPWIR",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode TETRAHEDRON = new MilitaryObstacleTypeCategoryCode(
			"Tetrahedron",
			"TTRHDN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WALL_OBSTACLE = new MilitaryObstacleTypeCategoryCode(
			"Wall obstacle",
			"WALL",
			"A continuous, vertical structure, such as a concrete or rock wall created in order to be used as an obstacle.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_DOUBLE_APRON_FENCE = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, double apron fence",
			"WIRAFN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_DOUBLE_STRAND_CONCERTINA = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, double strand concertina",
			"WIRDCN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_DOUBLE_FENCE = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, double fence",
			"WIRDFN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_HIGH_WIRE_FENCE = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, high wire fence",
			"WIRHFN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_LOW_WIRE_FENCE = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, low wire fence",
			"WIRLFN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_NOT_OTHERWISE_SPECIFIED = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, not otherwise specified",
			"WIRNOS",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_SINGLE_CONCERTINA = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, single concertina",
			"WIRSCN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_SINGLE_FENCE = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, single fence",
			"WIRSFN",
			"No definition provided in APP-6A.");
	public static final MilitaryObstacleTypeCategoryCode WIRE_OBSTACLE_TRIPLE_STRAND_CONCERTINA = new MilitaryObstacleTypeCategoryCode(
			"Wire obstacle, triple strand concertina",
			"WIRTCN",
			"No definition provided in APP-6A.");

	private MilitaryObstacleTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
