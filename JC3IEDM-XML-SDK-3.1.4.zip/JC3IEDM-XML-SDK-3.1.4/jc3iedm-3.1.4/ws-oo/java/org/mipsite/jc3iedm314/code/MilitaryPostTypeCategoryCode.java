/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryPostTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type classification of a MILITARY-POST-TYPE.";
	}

	private static HashMap<String, MilitaryPostTypeCategoryCode> physicalToCode = new HashMap<String, MilitaryPostTypeCategoryCode>();

	public static MilitaryPostTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryPostTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryPostTypeCategoryCode ATTACK_HELICOPTER_COMMANDER = new MilitaryPostTypeCategoryCode(
			"Attack helicopter commander",
			"AHLCDR",
			"A MILITARY-POST-TYPE that is identified as the designated commander of an attack helicopter unit.");
	public static final MilitaryPostTypeCategoryCode AIR_LIAISON_OFFICER = new MilitaryPostTypeCategoryCode(
			"Air liaison officer",
			"AIRLSN",
			"A tactical air force or naval aviation officer attached to a ground or naval unit or formation as the advisor on tactical air operation matters.");
	public static final MilitaryPostTypeCategoryCode ALTERNATIVE_JAAT_CONTROLLER = new MilitaryPostTypeCategoryCode(
			"Alternative JAAT controller",
			"AJAATC",
			"A MILITARY-POST-TYPE that is identified as the designated alternate controller of a Joint Air Attack Team.");
	public static final MilitaryPostTypeCategoryCode ANAESTHETICS_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Anaesthetics physician",
			"ANSPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Anaesthetics.");
	public static final MilitaryPostTypeCategoryCode APPROVING_AUTHORITY = new MilitaryPostTypeCategoryCode(
			"Approving authority",
			"APAUTH",
			"A MILITARY-POST-TYPE that is identified as the authority with the right and power to approve plans, orders or other official documents.");
	public static final MilitaryPostTypeCategoryCode AIRBORNE_MISSION_COMMANDER = new MilitaryPostTypeCategoryCode(
			"Airborne mission commander",
			"ARBNMC",
			"A MILITARY-POST-TYPE that executes component�s rescue coordination centre (RCC) and coordinates the combat search and rescue (CSAR) effort between the combat search and rescue task force (CSARTF) and the RCC (or joint search and rescue centre) by monitoring the status of all CSARTF elements, requesting additional assets when needed, and ensuring the recovery and supporting forces arrive at their designated areas to accomplish the CSAR mission.");
	public static final MilitaryPostTypeCategoryCode ASSAULT_SUPPORT_COORDINATOR_AIRBORNE = new MilitaryPostTypeCategoryCode(
			"Assault support coordinator, airborne",
			"ASCAIR",
			"A MILITARY-POST-TYPE that provides air coordination and control during helicopter operations within the Marine Air Command and Control System (MACCS). Serves as an extension of Direct Air Support Centre (DASC) or Helicopter Direction Centre (HDC) in support of the air mission commander.");
	public static final MilitaryPostTypeCategoryCode AUTHORISED_COMMANDER = new MilitaryPostTypeCategoryCode(
			"Authorised commander",
			"AUTCDR",
			"A MILITARY-POST-TYPE that is identified as the duly appointed officer in charge of a unit, post, camp, or operation.");
	public static final MilitaryPostTypeCategoryCode DENTISTRY_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Dentistry physician",
			"DNTPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Dentistry.");
	public static final MilitaryPostTypeCategoryCode FORWARD_AIR_CONTROLLER = new MilitaryPostTypeCategoryCode(
			"Forward air controller",
			"FAC",
			"A MILITARY-POST-TYPE that is identified as the member of the tactical air control party who, from a forward ground or airborne position, controls aircraft in close air support of ground troops.");
	public static final MilitaryPostTypeCategoryCode FORWARD_AIR_CONTROLLER_AIRBORNE = new MilitaryPostTypeCategoryCode(
			"Forward air controller, airborne",
			"FACAIR",
			"A MILITARY-POST-TYPE that is a specifically trained and qualified aviation officer who exercises control from the air of aircraft engaged in close air support of ground troops. The forward air controller (airborne) is normally an airborne extension of the tactical air control party.");
	public static final MilitaryPostTypeCategoryCode FORWARD_OBSERVATION_OFFICER_AIR_OBSERVATION_POST = new MilitaryPostTypeCategoryCode(
			"Forward observation officer/air observation post",
			"FOOAOP",
			"A MILITARY-POST-TYPE that is identified as the observer operating with front line troops on the ground or in the air and trained to adjust ground or naval gunfire and pass back battlespace information.");
	public static final MilitaryPostTypeCategoryCode GROUND_MANOEUVRE_COMMANDER = new MilitaryPostTypeCategoryCode(
			"Ground manoeuvre commander",
			"GMCDR",
			"A MILITARY-POST-TYPE that is identified as the designated commander of a ground manoeuvre unit.");
	public static final MilitaryPostTypeCategoryCode GUNNER = new MilitaryPostTypeCategoryCode(
			"Gunner",
			"GUNNER",
			"A MILITARY-POST-TYPE that is identified as one who operates a gun.");
	public static final MilitaryPostTypeCategoryCode GYNAECOLOGY_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Gynaecology physician",
			"GYNPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Gynaecology.");
	public static final MilitaryPostTypeCategoryCode HEAD_NECK_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Head/neck physician",
			"HDNPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Head/neck.");
	public static final MilitaryPostTypeCategoryCode INTERNAL_MEDICINE_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Internal medicine physician",
			"INMPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Internal medicine.");
	public static final MilitaryPostTypeCategoryCode INTELLIGENCE_OFFICER = new MilitaryPostTypeCategoryCode(
			"Intelligence officer",
			"INTOFF",
			"A MILITARY-POST-TYPE that is identified as the officer who is responsible for activities relating to gathering and analysing information about an actual or potential foe.");
	public static final MilitaryPostTypeCategoryCode JAAT_CONTROLLER = new MilitaryPostTypeCategoryCode(
			"JAAT controller",
			"JAATC",
			"A MILITARY-POST-TYPE that is identified as the designated controller of a Joint Air Attack Team.");
	public static final MilitaryPostTypeCategoryCode LIAISON_OFFICER = new MilitaryPostTypeCategoryCode(
			"Liaison officer",
			"LIAISN",
			"A MILITARY-POST-TYPE responsible for liaison duties.");
	public static final MilitaryPostTypeCategoryCode MAINTENANCE_TECHNICIAN = new MilitaryPostTypeCategoryCode(
			"Maintenance technician",
			"MANTCH",
			"A MILITARY-POST-TYPE that is identified as the person specialised to take all actions to retain materiel in or to restore it to a specified condition.");
	public static final MilitaryPostTypeCategoryCode MICKEY_NET_CONTROLLER = new MilitaryPostTypeCategoryCode(
			"Mickey net controller",
			"MCKNET",
			"A MILITARY-POST-TYPE that is identified as the HAVE QUICK Mickey net controller.");
	public static final MilitaryPostTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new MilitaryPostTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MilitaryPostTypeCategoryCode OPERATIONS_OFFICER = new MilitaryPostTypeCategoryCode(
			"Operations officer",
			"OPSOFF",
			"A MILITARY-POST-TYPE that is identified as the officer who is responsible for activities relating to planning and directing military operations.");
	public static final MilitaryPostTypeCategoryCode ORTHOPAEDICS_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Orthopaedics physician",
			"ORTPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Orthopaedics.");
	public static final MilitaryPostTypeCategoryCode OTHER_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Other physician",
			"OTHPHY",
			"A MILITARY-POST-TYPE that is identified as a physician with an unidentified speciality.");
	public static final MilitaryPostTypeCategoryCode POINT_OF_CONTACT = new MilitaryPostTypeCategoryCode(
			"Point of contact",
			"POC",
			"A MILITARY-POST-TYPE responsible to coordinate details for each element of support required.");
	public static final MilitaryPostTypeCategoryCode PRIMARY_CARE_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Primary care physician",
			"PRCPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Primary care.");
	public static final MilitaryPostTypeCategoryCode PSYCHOLOGY_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Psychology physician",
			"PSYPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Psychology.");
	public static final MilitaryPostTypeCategoryCode PATHOLOGY_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Pathology physician",
			"PTHPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Pathology.");
	public static final MilitaryPostTypeCategoryCode RADIOLOGY_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Radiology physician",
			"RADPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Radiology.");
	public static final MilitaryPostTypeCategoryCode RIFLEMAN = new MilitaryPostTypeCategoryCode(
			"Rifleman",
			"RFLEMN",
			"A MILITARY-POST-TYPE that is identified as a soldier armed with a rifle.");
	public static final MilitaryPostTypeCategoryCode SAPPER = new MilitaryPostTypeCategoryCode(
			"Sapper",
			"SAPPER",
			"A MILITARY-POST-TYPE that is identified as one who designs and constructs military works for attack or defence.");
	public static final MilitaryPostTypeCategoryCode SCOUT = new MilitaryPostTypeCategoryCode(
			"Scout",
			"SCOUT",
			"A MILITARY-POST-TYPE that is identified as one sent out ahead of the main force in order to reconnoitre the position and movement of the enemy.");
	public static final MilitaryPostTypeCategoryCode SNIPER = new MilitaryPostTypeCategoryCode(
			"Sniper",
			"SNIPER",
			"A MILITARY-POST-TYPE that is identified as one who snipes, or shoots from concealment.");
	public static final MilitaryPostTypeCategoryCode SURGICAL_PHYSICIAN = new MilitaryPostTypeCategoryCode(
			"Surgical physician",
			"SURPHY",
			"A MILITARY-POST-TYPE that is identified as a physician specialising in Surgery.");
	public static final MilitaryPostTypeCategoryCode TACTICAL_AIR_CONTROLLER = new MilitaryPostTypeCategoryCode(
			"Tactical air controller",
			"TAC",
			"A MILITARY-POST-TYPE that is a subordinate operational component of a tactical air control system designed to provide air liaison to land forces and for the control of aircraft.");
	public static final MilitaryPostTypeCategoryCode TACTICAL_AIR_COORDINATOR_AIRBORNE = new MilitaryPostTypeCategoryCode(
			"Tactical air coordinator, airborne",
			"TACAIR",
			"A MILITARY-POST-TYPE that is an officer who coordinates, from an aircraft, the action of combat aircraft engaged in close support of ground or sea forces.");

	private MilitaryPostTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
