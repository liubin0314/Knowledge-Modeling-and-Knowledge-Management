/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonLanguageSkillGeneralProficiencyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general level of proficiency of a specific PERSON in a specific language skill.";
	}

	private static HashMap<String, PersonLanguageSkillGeneralProficiencyCode> physicalToCode = new HashMap<String, PersonLanguageSkillGeneralProficiencyCode>();

	public static PersonLanguageSkillGeneralProficiencyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonLanguageSkillGeneralProficiencyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonLanguageSkillGeneralProficiencyCode ELEMENTARY = new PersonLanguageSkillGeneralProficiencyCode(
			"Elementary",
			"ELEM",
			"Low performance ability.");
	public static final PersonLanguageSkillGeneralProficiencyCode EXCELLENT = new PersonLanguageSkillGeneralProficiencyCode(
			"Excellent",
			"EXCLNT",
			"Very high performance ability.");
	public static final PersonLanguageSkillGeneralProficiencyCode FAIR = new PersonLanguageSkillGeneralProficiencyCode(
			"Fair",
			"FAIR",
			"Moderate performance ability.");
	public static final PersonLanguageSkillGeneralProficiencyCode NOT_KNOWN = new PersonLanguageSkillGeneralProficiencyCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonLanguageSkillGeneralProficiencyCode NO_SIGNIFICANT_OR_PRACTICAL_PROFICIENCY = new PersonLanguageSkillGeneralProficiencyCode(
			"No significant or practical proficiency",
			"NONE",
			"No significant or practical proficiency.");
	public static final PersonLanguageSkillGeneralProficiencyCode VERY_GOOD = new PersonLanguageSkillGeneralProficiencyCode(
			"Very good",
			"VERY",
			"High performance ability.");

	private PersonLanguageSkillGeneralProficiencyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
