/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetDetailSchemeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes an identification scheme used for recording a CANDIDATE-TARGET-DETAIL.";
	}

	private static HashMap<String, CandidateTargetDetailSchemeCode> physicalToCode = new HashMap<String, CandidateTargetDetailSchemeCode>();

	public static CandidateTargetDetailSchemeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetDetailSchemeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetDetailSchemeCode ABCA = new CandidateTargetDetailSchemeCode(
			"ABCA",
			"ABCA",
			"Australian, British, Canadian and American target numbering system.");
	public static final CandidateTargetDetailSchemeCode BE = new CandidateTargetDetailSchemeCode(
			"BE",
			"BE",
			"Basic Encyclopedia.");
	public static final CandidateTargetDetailSchemeCode FIBE = new CandidateTargetDetailSchemeCode(
			"FIBE",
			"FIBE",
			"Field Initiated Basic Encyclopedia Numbering System.");
	public static final CandidateTargetDetailSchemeCode ORGANISATIONAL = new CandidateTargetDetailSchemeCode(
			"Organisational",
			"ORGANL",
			"Target numbering is given by the nominating organisation.");
	public static final CandidateTargetDetailSchemeCode SITE_NUMBER = new CandidateTargetDetailSchemeCode(
			"Site number",
			"SITENR",
			"An identification of an installation, facility or physical area of potential significance as objective for attack.");

	private CandidateTargetDetailSchemeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
