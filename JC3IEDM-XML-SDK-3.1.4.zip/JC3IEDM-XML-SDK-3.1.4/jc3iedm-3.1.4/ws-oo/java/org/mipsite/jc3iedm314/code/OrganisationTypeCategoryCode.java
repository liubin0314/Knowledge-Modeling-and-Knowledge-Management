/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ORGANISATION-TYPE.";
	}

	private static HashMap<String, OrganisationTypeCategoryCode> physicalToCode = new HashMap<String, OrganisationTypeCategoryCode>();

	public static OrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationTypeCategoryCode CIVILIAN_POST_TYPE = new OrganisationTypeCategoryCode(
			"CIVILIAN-POST-TYPE",
			"CIVPST",
			"An ORGANISATION-TYPE with a set of duties that are intended to be fulfilled by one person in private sector and non-military government organisations.");
	public static final OrganisationTypeCategoryCode GROUP_ORGANISATION_TYPE = new OrganisationTypeCategoryCode(
			"GROUP-ORGANISATION-TYPE",
			"GRPORG",
			"An ORGANISATION-TYPE that is non-formal in nature and classes together its members due to mutual or common circumstances.");
	public static final OrganisationTypeCategoryCode GOVERNMENT_ORGANISATION_TYPE = new OrganisationTypeCategoryCode(
			"GOVERNMENT-ORGANISATION-TYPE",
			"GVTORG",
			"An ORGANISATION-TYPE that controls and administers public policy either under a national or international mandate.");
	public static final OrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new OrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final OrganisationTypeCategoryCode PRIVATE_SECTOR_ORGANISATION_TYPE = new OrganisationTypeCategoryCode(
			"PRIVATE-SECTOR-ORGANISATION-TYPE",
			"PVSORG",
			"An ORGANISATION-TYPE that is a non-government organisation and is constituted for business, commerce, manufacturing, trade, relief or philanthropy.");

	private OrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
