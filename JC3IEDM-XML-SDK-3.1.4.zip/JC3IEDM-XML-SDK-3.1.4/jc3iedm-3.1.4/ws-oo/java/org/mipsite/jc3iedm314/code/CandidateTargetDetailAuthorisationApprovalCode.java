/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetDetailAuthorisationApprovalCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of approval that a specific CANDIDATE-TARGET-DETAIL is authorised for further consideration in planning military operations.";
	}

	private static HashMap<String, CandidateTargetDetailAuthorisationApprovalCode> physicalToCode = new HashMap<String, CandidateTargetDetailAuthorisationApprovalCode>();

	public static CandidateTargetDetailAuthorisationApprovalCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetDetailAuthorisationApprovalCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetDetailAuthorisationApprovalCode APPROVED_AND_AVAILABLE = new CandidateTargetDetailAuthorisationApprovalCode(
			"Approved and available",
			"APPAVL",
			"The specific CANDIDATE-TARGET-DETAIL is authorised for engagement.");
	public static final CandidateTargetDetailAuthorisationApprovalCode APPROVED_AND_EXCLUDED = new CandidateTargetDetailAuthorisationApprovalCode(
			"Approved and excluded",
			"APPEXC",
			"The specific CANDIDATE-TARGET-DETAIL is approved as a planning CANDIDATE-TARGET-LIST but is not authorised for engagement.");
	public static final CandidateTargetDetailAuthorisationApprovalCode NOT_APPROVED = new CandidateTargetDetailAuthorisationApprovalCode(
			"Not approved",
			"NOTAPP",
			"The specific CANDIDATE-TARGET-DETAIL is not to be used in planning.");

	private CandidateTargetDetailAuthorisationApprovalCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
