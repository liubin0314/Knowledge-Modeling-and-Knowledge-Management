/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GroupCharacteristicAgeGroupCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies the age group in a specific GROUP-CHARACTERISTIC.";
	}

	private static HashMap<String, GroupCharacteristicAgeGroupCode> physicalToCode = new HashMap<String, GroupCharacteristicAgeGroupCode>();

	public static GroupCharacteristicAgeGroupCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GroupCharacteristicAgeGroupCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GroupCharacteristicAgeGroupCode ADULT = new GroupCharacteristicAgeGroupCode(
			"Adult",
			"ADULT",
			"The group includes ages from 13 through 60 years.");
	public static final GroupCharacteristicAgeGroupCode CHILD = new GroupCharacteristicAgeGroupCode(
			"Child",
			"CHILD",
			"The group includes ages less than 13 years.");
	public static final GroupCharacteristicAgeGroupCode ELDERLY = new GroupCharacteristicAgeGroupCode(
			"Elderly",
			"ELDRLY",
			"The group includes ages over 60 years.");
	public static final GroupCharacteristicAgeGroupCode MIXED = new GroupCharacteristicAgeGroupCode(
			"Mixed",
			"MIXED",
			"The group includes a mixture of ages.");
	public static final GroupCharacteristicAgeGroupCode NOT_KNOWN = new GroupCharacteristicAgeGroupCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private GroupCharacteristicAgeGroupCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
