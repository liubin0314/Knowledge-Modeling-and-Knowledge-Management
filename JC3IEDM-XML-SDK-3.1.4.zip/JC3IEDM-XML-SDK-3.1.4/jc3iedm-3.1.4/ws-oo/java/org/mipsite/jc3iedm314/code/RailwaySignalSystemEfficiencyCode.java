/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailwaySignalSystemEfficiencyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the percentage value used to compute the inevitable delays caused by the type of signalling in use on the RAILWAY line.";
	}

	private static HashMap<String, RailwaySignalSystemEfficiencyCode> physicalToCode = new HashMap<String, RailwaySignalSystemEfficiencyCode>();

	public static RailwaySignalSystemEfficiencyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailwaySignalSystemEfficiencyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailwaySignalSystemEfficiencyCode _50_65 = new RailwaySignalSystemEfficiencyCode(
			"50-65%",
			"50",
			"The specific efficiency percentage represents rudimental signalling.");
	public static final RailwaySignalSystemEfficiencyCode _70_75 = new RailwaySignalSystemEfficiencyCode(
			"70-75%",
			"70",
			"The specific efficiency percentage represents normal block operations.");
	public static final RailwaySignalSystemEfficiencyCode _80_85 = new RailwaySignalSystemEfficiencyCode(
			"80-85%",
			"80",
			"The specific efficiency percentage represents automatic signalling and/or centralised traffic control.");
	public static final RailwaySignalSystemEfficiencyCode _85 = new RailwaySignalSystemEfficiencyCode(
			"85%",
			"85",
			"The specific efficiency percentage represents computerised traffic control.");

	private RailwaySignalSystemEfficiencyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
