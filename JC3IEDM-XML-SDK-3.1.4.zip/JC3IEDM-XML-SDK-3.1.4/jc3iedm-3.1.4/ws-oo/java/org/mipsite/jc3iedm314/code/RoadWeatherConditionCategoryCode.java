/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RoadWeatherConditionCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that describes the passability of a ROAD considering the impact of weather on that ROAD.";
	}

	private static HashMap<String, RoadWeatherConditionCategoryCode> physicalToCode = new HashMap<String, RoadWeatherConditionCategoryCode>();

	public static RoadWeatherConditionCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RoadWeatherConditionCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RoadWeatherConditionCategoryCode ALL_WEATHER = new RoadWeatherConditionCategoryCode(
			"All-weather",
			"AWR",
			"The specific value, which determines that the ROAD is passable, to all traffic in any weather except deep snow or flood (normally roads with waterproof surfaces).");
	public static final RoadWeatherConditionCategoryCode FAIR_WEATHER = new RoadWeatherConditionCategoryCode(
			"Fair-weather",
			"FWR",
			"The specific value, which determines that the ROAD is passable only in fair weather. Quickly becomes impassable in bad weather. Cannot be kept open by maintenance short of major construction.");
	public static final RoadWeatherConditionCategoryCode LIMITED_ALL_WEATHER = new RoadWeatherConditionCategoryCode(
			"Limited all-weather",
			"LAWR",
			"The specific value, which determines that the volume of ROAD traffic may be limited by bad weather. Heavy unrestricted use during adverse weather may cause complete breakdown of surface (normally roads with non-waterproof surfaces).");

	private RoadWeatherConditionCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
