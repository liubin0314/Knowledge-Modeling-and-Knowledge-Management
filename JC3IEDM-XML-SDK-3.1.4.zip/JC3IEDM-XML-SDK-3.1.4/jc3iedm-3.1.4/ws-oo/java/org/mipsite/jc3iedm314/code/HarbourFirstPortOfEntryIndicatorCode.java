/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourFirstPortOfEntryIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the port may be used by a vessel that needs to clear foreign goods and personnel through Customs and Immigration.";
	}

	private static HashMap<String, HarbourFirstPortOfEntryIndicatorCode> physicalToCode = new HashMap<String, HarbourFirstPortOfEntryIndicatorCode>();

	public static HarbourFirstPortOfEntryIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourFirstPortOfEntryIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourFirstPortOfEntryIndicatorCode NO = new HarbourFirstPortOfEntryIndicatorCode(
			"No",
			"NO",
			"The harbour cannot be used to clear foreign goods and personnel through Customs and Immigration.");
	public static final HarbourFirstPortOfEntryIndicatorCode YES = new HarbourFirstPortOfEntryIndicatorCode(
			"Yes",
			"YES",
			"The harbour can be used to clear foreign goods and personnel through Customs and Immigration.");

	private HarbourFirstPortOfEntryIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
