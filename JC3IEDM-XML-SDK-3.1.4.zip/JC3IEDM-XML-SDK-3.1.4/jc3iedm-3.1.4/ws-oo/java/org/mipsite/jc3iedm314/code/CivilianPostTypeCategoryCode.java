/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CivilianPostTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CIVILIAN-POST-TYPE.";
	}

	private static HashMap<String, CivilianPostTypeCategoryCode> physicalToCode = new HashMap<String, CivilianPostTypeCategoryCode>();

	public static CivilianPostTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CivilianPostTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CivilianPostTypeCategoryCode AID_ADMINISTRATOR = new CivilianPostTypeCategoryCode(
			"Aid administrator",
			"AIDADM",
			"A CIVILIAN-POST-TYPE whose job is to manage or direct the affairs of an organisation that provides relief services.");
	public static final CivilianPostTypeCategoryCode ALDERMAN = new CivilianPostTypeCategoryCode(
			"Alderman",
			"ALDRMN",
			"A CIVILIAN-POST-TYPE whose job entails the participation in the legislative body of town or city governments.");
	public static final CivilianPostTypeCategoryCode CORPORATE_EXECUTIVE = new CivilianPostTypeCategoryCode(
			"Corporate executive",
			"COREXC",
			"A CIVILIAN-POST-TYPE whose job entails the leadership in an executive or administrative function in a private sector business.");
	public static final CivilianPostTypeCategoryCode DEPARTMENT_HEAD = new CivilianPostTypeCategoryCode(
			"Department head",
			"DEPTHD",
			"A CIVILIAN-POST-TYPE whose job entails the leadership of a separate division or branch of an organisation.");
	public static final CivilianPostTypeCategoryCode GOVERNMENT_MINISTER = new CivilianPostTypeCategoryCode(
			"Government minister",
			"GOVMST",
			"A CIVILIAN-POST-TYPE whose job entails the lower level executive duties of the government.");
	public static final CivilianPostTypeCategoryCode GOVERNOR = new CivilianPostTypeCategoryCode(
			"Governor",
			"GOVRNR",
			"A CIVILIAN-POST-TYPE whose job is the executive leadership and administrative control over a group of people.");
	public static final CivilianPostTypeCategoryCode HEAD_OF_STATE = new CivilianPostTypeCategoryCode(
			"Head of state",
			"HEADST",
			"A CIVILIAN-POST-TYPE whose job is the supreme executive magistracy of a country.");
	public static final CivilianPostTypeCategoryCode MAYOR = new CivilianPostTypeCategoryCode(
			"Mayor",
			"MAYOR",
			"A CIVILIAN-POST-TYPE whose job is the chief officer of the municipal corporation of a city or borough.");
	public static final CivilianPostTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new CivilianPostTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final CivilianPostTypeCategoryCode POLICE_CHIEF = new CivilianPostTypeCategoryCode(
			"Police chief",
			"POLCHF",
			"A CIVILIAN-POST-TYPE whose job is the chief officer of a civil force to which is entrusted the duty of maintaining public order, enforcing regulations and detecting crime.");
	public static final CivilianPostTypeCategoryCode PUBLISHER = new CivilianPostTypeCategoryCode(
			"Publisher",
			"PUBLSR",
			"A CIVILIAN-POST-TYPE whose business is the issuing of books, newspapers, music, engravings, videos or the like, as the agent of the author or owner.");
	public static final CivilianPostTypeCategoryCode REGIONAL_ADMINISTRATOR = new CivilianPostTypeCategoryCode(
			"Regional administrator",
			"REGADM",
			"A CIVILIAN-POST-TYPE whose job is to manage or direct the affairs of a regional organisation.");
	public static final CivilianPostTypeCategoryCode RELEASE_AUTHORITY = new CivilianPostTypeCategoryCode(
			"Release authority",
			"RELATH",
			"A CIVILIAN-POST-TYPE whose job is to authorize the release of a product or information.");

	private CivilianPostTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
