/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that conveys additional information on the specified UNIT-TYPE.";
	}

	private static HashMap<String, UnitTypeQualifierCode> physicalToCode = new HashMap<String, UnitTypeQualifierCode>();

	public static UnitTypeQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeQualifierCode CORPS = new UnitTypeQualifierCode(
			"Corps",
			"CORPS",
			"The specified UNIT-TYPE supports a force of Corps level.");
	public static final UnitTypeQualifierCode DIVISION = new UnitTypeQualifierCode(
			"Division",
			"DIV",
			"The specified UNIT-TYPE operates at Division level.");
	public static final UnitTypeQualifierCode FORCE = new UnitTypeQualifierCode(
			"Force",
			"FORCE",
			"The specified UNIT-TYPE operates at Force level.");
	public static final UnitTypeQualifierCode HEAVY = new UnitTypeQualifierCode(
			"Heavy",
			"HEAVY",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode HIGH_MEDIUM_ALTITUDE_AIR_DEFENCE = new UnitTypeQualifierCode(
			"High/medium altitude air defence",
			"HMAD",
			"The specified UNIT-TYPE major equipment is able to intercept threats flying at high or medium altitude.");
	public static final UnitTypeQualifierCode LIGHT = new UnitTypeQualifierCode(
			"Light",
			"LIGHT",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode LONG_RANGE = new UnitTypeQualifierCode(
			"Long range",
			"LR",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode MEDIUM = new UnitTypeQualifierCode(
			"Medium",
			"MEDIUM",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode MEDIUM_RANGE = new UnitTypeQualifierCode(
			"Medium range",
			"MR",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode SHORT_RANGE = new UnitTypeQualifierCode(
			"Short range",
			"SR",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode STRATEGIC = new UnitTypeQualifierCode(
			"Strategic",
			"STRTGC",
			"The specified UNIT-TYPE operates at a strategic level of command.");
	public static final UnitTypeQualifierCode TACTICAL = new UnitTypeQualifierCode(
			"Tactical",
			"TACTCL",
			"The specified UNIT-TYPE operates at a tactical level of command.");
	public static final UnitTypeQualifierCode THEATRE = new UnitTypeQualifierCode(
			"Theatre",
			"THTRE",
			"The specified UNIT-TYPE supports a force at Theatre level.");
	public static final UnitTypeQualifierCode THEATRE_MISSILE_DEFENCE = new UnitTypeQualifierCode(
			"Theatre missile defence",
			"TMD",
			"No definition provided in APP-6A.");
	public static final UnitTypeQualifierCode VERY_SHORT_RANGE = new UnitTypeQualifierCode(
			"Very short range",
			"VSR",
			"No definition provided in APP-6A.");

	private UnitTypeQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
