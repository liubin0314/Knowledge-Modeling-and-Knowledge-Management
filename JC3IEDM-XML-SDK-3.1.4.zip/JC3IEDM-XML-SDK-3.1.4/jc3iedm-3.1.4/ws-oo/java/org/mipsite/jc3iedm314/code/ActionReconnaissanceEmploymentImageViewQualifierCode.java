/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionReconnaissanceEmploymentImageViewQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the recorded media based on the type of imagery the interpreter is viewing.";
	}

	private static HashMap<String, ActionReconnaissanceEmploymentImageViewQualifierCode> physicalToCode = new HashMap<String, ActionReconnaissanceEmploymentImageViewQualifierCode>();

	public static ActionReconnaissanceEmploymentImageViewQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionReconnaissanceEmploymentImageViewQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionReconnaissanceEmploymentImageViewQualifierCode DUAL_BAND_EO_AND_IR = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Dual band (EO and IR)",
			"DBEOIR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode DUAL_BAND_MID_INFRARED_AND_ELECTRO_OPTICAL = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Dual band (Mid infrared and Electro optical)",
			"DBMIEO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode ELECTRO_OPTICAL = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Electro optical",
			"ELCOPT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode MID_INFRARED = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Mid infrared",
			"MIDINF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode NON_STANDARD_ELECTRONICALLY_ENHANCED = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Non-standard, electronically enhanced",
			"NSELEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode THERMAL_INFRARED = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Thermal infrared",
			"THRINF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");
	public static final ActionReconnaissanceEmploymentImageViewQualifierCode VIDEO_SOFTCOPY_DISPLAY = new ActionReconnaissanceEmploymentImageViewQualifierCode(
			"Video/softcopy display",
			"VIDSFT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/6.");

	private ActionReconnaissanceEmploymentImageViewQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
