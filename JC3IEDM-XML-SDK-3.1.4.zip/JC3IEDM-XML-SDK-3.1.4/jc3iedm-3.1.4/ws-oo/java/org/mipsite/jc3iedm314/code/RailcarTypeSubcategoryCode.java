/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailcarTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of RAILCAR-TYPE.";
	}

	private static HashMap<String, RailcarTypeSubcategoryCode> physicalToCode = new HashMap<String, RailcarTypeSubcategoryCode>();

	public static RailcarTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailcarTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailcarTypeSubcategoryCode LOCOMOTIVE_DIESEL_ELECTRIC = new RailcarTypeSubcategoryCode(
			"Locomotive, diesel/electric",
			"LCMDSE",
			"A locomotive that uses diesel engine(s) to produce electricity for electric engine(s) that provide the engine with its source of tractive power.");
	public static final RailcarTypeSubcategoryCode LOCOMOTIVE_DIESEL = new RailcarTypeSubcategoryCode(
			"Locomotive, diesel",
			"LCMDSL",
			"A locomotive that uses diesel engine(s) as its source of tractive power.");
	public static final RailcarTypeSubcategoryCode LOCOMOTIVE_ELECTRIC = new RailcarTypeSubcategoryCode(
			"Locomotive, electric",
			"LCMELC",
			"A locomotive that uses electric engine(s) as its source of tractive power, the electricity being supplied from an external source, typically via a pantograph (overhead electrical cable).");
	public static final RailcarTypeSubcategoryCode LOCOMOTIVE_STEAM = new RailcarTypeSubcategoryCode(
			"Locomotive, steam",
			"LCMSTM",
			"A locomotive that uses the principle of heating water above its boiling point to produce steam, the expansion in a sealed vessel the pressure becomes the engine(s) source of tractive power.");
	public static final RailcarTypeSubcategoryCode LOCOMOTIVE_TENDER = new RailcarTypeSubcategoryCode(
			"Locomotive, tender",
			"LCMTND",
			"A locomotive tender is used to carry coal and water for a steam locomotive when not integral to the locomotive design.");
	public static final RailcarTypeSubcategoryCode NOT_KNOWN = new RailcarTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RailcarTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new RailcarTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RailcarTypeSubcategoryCode WAGON_ARTICULATED_VEHICLE_TRANSPORTER = new RailcarTypeSubcategoryCode(
			"Wagon, articulated vehicle transporter",
			"WGNART",
			"Rolling stock specifically designed to carry an articulated truck by rail (for example EUROSTAR).");
	public static final RailcarTypeSubcategoryCode WAGON_BRAKE = new RailcarTypeSubcategoryCode(
			"Wagon, brake",
			"WGNBRK",
			"Rolling stock used to assist with the control of a formed train, that when used are manned and contain auxiliary braking apparatus.");
	public static final RailcarTypeSubcategoryCode WAGON_CAR_TRANSPORTER = new RailcarTypeSubcategoryCode(
			"Wagon, car transporter",
			"WGNCAR",
			"Rolling stock specifically designed to carry civilian or military cars by rail (for example EURORAIL).");
	public static final RailcarTypeSubcategoryCode WAGON_CARGO_ENCLOSED = new RailcarTypeSubcategoryCode(
			"Wagon, cargo (enclosed)",
			"WGNCRG",
			"Rolling stock used to move boxed or palletised equipment/stores and closed by means of fixed doors either sliding or hinged.");
	public static final RailcarTypeSubcategoryCode WAGON_CARGO_SLIDING_SIDES = new RailcarTypeSubcategoryCode(
			"Wagon, cargo, sliding sides",
			"WGNCSS",
			"Rolling stock used to move boxed or palletised equipment/stores and closed by means of sliding curtained side panels.");
	public static final RailcarTypeSubcategoryCode WAGON_CATTLE = new RailcarTypeSubcategoryCode(
			"Wagon, cattle",
			"WGNCTL",
			"Rolling stock used to move livestock by rail.");
	public static final RailcarTypeSubcategoryCode WAGON_FLATBED = new RailcarTypeSubcategoryCode(
			"Wagon, flatbed",
			"WGNFLB",
			"Rolling stock used to move either large bulky cargoes, for example B vehicles, or large linear cargoes, for example logs/cut timber, replacement sections of track.");
	public static final RailcarTypeSubcategoryCode WAGON_BULK_FUEL = new RailcarTypeSubcategoryCode(
			"Wagon, bulk fuel",
			"WGNFUL",
			"Rolling stock used to move bulk fuel by rail. [Also often known as tank wagons.]");
	public static final RailcarTypeSubcategoryCode WAGON_HOPPER = new RailcarTypeSubcategoryCode(
			"Wagon, hopper",
			"WGNHPR",
			"Rolling stock used to move bulk loose material by rail and unloaded by gravity through bottom doors. [Mineral or foodstuffs e.g. grain are typical cargoes.]");
	public static final RailcarTypeSubcategoryCode WAGON_ISO_CONTAINER_S = new RailcarTypeSubcategoryCode(
			"Wagon, ISO container(s)",
			"WGNISO",
			"Rolling stock used to move standard ISO containers, either single or multiple containers.");
	public static final RailcarTypeSubcategoryCode WAGON_LIQUID = new RailcarTypeSubcategoryCode(
			"Wagon, liquid",
			"WGNLQD",
			"Rolling stock used to move bulk liquids by rail.");
	public static final RailcarTypeSubcategoryCode WAGON_MINERAL = new RailcarTypeSubcategoryCode(
			"Wagon, mineral",
			"WGNMNR",
			"Rolling stock used to move bulk mineral by rail with unloading facilities from either side.");
	public static final RailcarTypeSubcategoryCode WAGON_OPEN_CONTAINER = new RailcarTypeSubcategoryCode(
			"Wagon, open container",
			"WGNOPC",
			"Rolling stock used to move bulk loose items by rail.");
	public static final RailcarTypeSubcategoryCode WAGON_PASSENGER = new RailcarTypeSubcategoryCode(
			"Wagon, passenger",
			"WGNPAS",
			"Rolling stock used for the transportation of passengers.");
	public static final RailcarTypeSubcategoryCode WAGON_REFRIGERATED = new RailcarTypeSubcategoryCode(
			"Wagon, refrigerated",
			"WGNRFG",
			"Rolling stock used to move refrigerated cargoes by rail.");
	public static final RailcarTypeSubcategoryCode WAGON_TRACK_REPAIR_AND_MAINTENANCE = new RailcarTypeSubcategoryCode(
			"Wagon, track repair and maintenance",
			"WGNRPR",
			"Rolling stock used to repair (replace track) or maintain the railway track and track bed.");
	public static final RailcarTypeSubcategoryCode WAGON_SPECIAL_PURPOSE = new RailcarTypeSubcategoryCode(
			"Wagon, special purpose",
			"WGNSPP",
			"Rolling stock used to move specialised or outsized loads by rail, for example MBTs, other outsized loads.");
	public static final RailcarTypeSubcategoryCode WAGON_POTABLE_WATER = new RailcarTypeSubcategoryCode(
			"Wagon, potable water",
			"WGNWAT",
			"Rolling stock used to move potable water by rail.");
	public static final RailcarTypeSubcategoryCode WAGON_WARFLAT = new RailcarTypeSubcategoryCode(
			"Wagon, warflat",
			"WGNWFL",
			"Rolling stock used to move specific military loads, for example AIFVs (UK Warrior).");

	private RailcarTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
