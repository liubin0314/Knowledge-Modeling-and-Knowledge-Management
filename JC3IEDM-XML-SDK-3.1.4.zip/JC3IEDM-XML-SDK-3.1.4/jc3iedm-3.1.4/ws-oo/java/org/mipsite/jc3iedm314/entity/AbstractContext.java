/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractContext extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private TextTypeVar80 nameText; // optional
	private Ref<SecurityClassification> securityClassification; // optional
	private Set<Ref<ActionContext>> actionContextSet; // zero-one-or-more
	private Set<Ref<ContextAssessment>> assessmentSet; // zero-one-or-more
	private Set<Ref<ContextAssociation>> contextAssociationInObjectSet; // zero-one-or-more
	private Set<Ref<ContextAssociation>> contextAssociationInSubjectSet; // zero-one-or-more
	private Set<Ref<ContextObjectItemAssociation>> contextObjectItemAssociationSet; // zero-one-or-more
	private Set<Ref<ContextReportingDataAssociation>> contextReportingDataAssociationSet; // zero-one-or-more
	private Set<Ref<ContextElement>> elementSet; // zero-one-or-more

	// default constructor

	public AbstractContext() {
		this.actionContextSet = new HashSet<Ref<ActionContext>>();
		this.assessmentSet = new HashSet<Ref<ContextAssessment>>();
		this.contextAssociationInObjectSet = new HashSet<Ref<ContextAssociation>>();
		this.contextAssociationInSubjectSet = new HashSet<Ref<ContextAssociation>>();
		this.contextObjectItemAssociationSet = new HashSet<Ref<ContextObjectItemAssociation>>();
		this.contextReportingDataAssociationSet = new HashSet<Ref<ContextReportingDataAssociation>>();
		this.elementSet = new HashSet<Ref<ContextElement>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractContext.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractContext.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public TextTypeVar80 getNameText() {
		return this.nameText;
	}

	public void setNameText(TextTypeVar80 nameText) {
		this.nameText = nameText;
	}

	public Ref<SecurityClassification> getSecurityClassification() {
		return this.securityClassification;
	}

	public void setSecurityClassification(Ref<SecurityClassification> securityClassification) {
		this.securityClassification = securityClassification;
	}

	public Set<Ref<ActionContext>> getActionContextSet() {
		return this.actionContextSet;
	}

	public void addActionContext(Ref<ActionContext> actionContext) {
		this.actionContextSet.add(actionContext);
	}

	public Set<Ref<ContextAssessment>> getAssessmentSet() {
		return this.assessmentSet;
	}

	public void addAssessment(Ref<ContextAssessment> assessment) {
		this.assessmentSet.add(assessment);
	}

	public Set<Ref<ContextAssociation>> getContextAssociationInObjectSet() {
		return this.contextAssociationInObjectSet;
	}

	public void addContextAssociationInObject(Ref<ContextAssociation> contextAssociationInObject) {
		this.contextAssociationInObjectSet.add(contextAssociationInObject);
	}

	public Set<Ref<ContextAssociation>> getContextAssociationInSubjectSet() {
		return this.contextAssociationInSubjectSet;
	}

	public void addContextAssociationInSubject(Ref<ContextAssociation> contextAssociationInSubject) {
		this.contextAssociationInSubjectSet.add(contextAssociationInSubject);
	}

	public Set<Ref<ContextObjectItemAssociation>> getContextObjectItemAssociationSet() {
		return this.contextObjectItemAssociationSet;
	}

	public void addContextObjectItemAssociation(Ref<ContextObjectItemAssociation> contextObjectItemAssociation) {
		this.contextObjectItemAssociationSet.add(contextObjectItemAssociation);
	}

	public Set<Ref<ContextReportingDataAssociation>> getContextReportingDataAssociationSet() {
		return this.contextReportingDataAssociationSet;
	}

	public void addContextReportingDataAssociation(Ref<ContextReportingDataAssociation> contextReportingDataAssociation) {
		this.contextReportingDataAssociationSet.add(contextReportingDataAssociation);
	}

	public Set<Ref<ContextElement>> getElementSet() {
		return this.elementSet;
	}

	public void addElement(Ref<ContextElement> element) {
		this.elementSet.add(element);
	}
}
