/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RoadCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of ROAD.";
	}

	private static HashMap<String, RoadCategoryCode> physicalToCode = new HashMap<String, RoadCategoryCode>();

	public static RoadCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RoadCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RoadCategoryCode MOTORWAY = new RoadCategoryCode(
			"Motorway",
			"A",
			"The specific ROAD is a motorway or expressway.");
	public static final RoadCategoryCode MAIN = new RoadCategoryCode(
			"Main",
			"B",
			"The specific ROAD is a main road, highway or federal road.");
	public static final RoadCategoryCode REGIONAL = new RoadCategoryCode(
			"Regional",
			"C",
			"The specific ROAD is a regional, secondary or district road.");
	public static final RoadCategoryCode LOCAL = new RoadCategoryCode(
			"Local",
			"D",
			"The specific ROAD is a local road or street.");
	public static final RoadCategoryCode LANE = new RoadCategoryCode(
			"Lane",
			"E",
			"The specific ROAD is a track or lane.");
	public static final RoadCategoryCode NOT_OTHERWISE_SPECIFIED = new RoadCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RoadCategoryCode PEDESTRIAN = new RoadCategoryCode(
			"Pedestrian",
			"P",
			"The specific ROAD is a pedestrian road.");
	public static final RoadCategoryCode RAILWAY = new RoadCategoryCode(
			"Railway",
			"R",
			"The specific ROAD is a railway road.");
	public static final RoadCategoryCode TRACK = new RoadCategoryCode(
			"Track",
			"TRACK",
			"A rough path or road, typically one beaten by use rather than constructed.");

	private RoadCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
