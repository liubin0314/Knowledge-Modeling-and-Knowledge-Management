/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CbrnEventCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CBRN-EVENT.";
	}

	private static HashMap<String, CbrnEventCategoryCode> physicalToCode = new HashMap<String, CbrnEventCategoryCode>();

	public static CbrnEventCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CbrnEventCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CbrnEventCategoryCode CHEMICAL_BIOLOGICAL_EVENT = new CbrnEventCategoryCode(
			"CHEMICAL-BIOLOGICAL-EVENT",
			"CHMBIO",
			"A CBRN-EVENT involving chemical and/or biological materiel.");
	public static final CbrnEventCategoryCode NOT_KNOWN = new CbrnEventCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final CbrnEventCategoryCode RADIOACTIVE_EVENT = new CbrnEventCategoryCode(
			"RADIOACTIVE-EVENT",
			"RADCTV",
			"A CBRN-EVENT involving radioactive materiel(s).");
	public static final CbrnEventCategoryCode UNIDENTIFIED_RELEASE_OTHER_THAN_ATTACK_ROTA = new CbrnEventCategoryCode(
			"Unidentified release other than attack (ROTA)",
			"UNROTA",
			"The release of an unknown chemical, biological, nuclear, radiological materiel(s) [agent(s)] into the environment intentionally or accidentally but not for the intended purpose of conducting an attack.");

	private CbrnEventCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
