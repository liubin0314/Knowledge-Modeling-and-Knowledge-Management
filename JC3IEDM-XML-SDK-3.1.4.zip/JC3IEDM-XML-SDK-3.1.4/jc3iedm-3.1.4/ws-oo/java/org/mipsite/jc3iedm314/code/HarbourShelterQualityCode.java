/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourShelterQualityCode extends CodeDomain {

	public static String getComment() {
		return "The protection provided from wind, sea, and swell in the area where normal port operations are conducted.";
	}

	private static HashMap<String, HarbourShelterQualityCode> physicalToCode = new HashMap<String, HarbourShelterQualityCode>();

	public static HarbourShelterQualityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourShelterQualityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourShelterQualityCode EXCELLENT = new HarbourShelterQualityCode(
			"Excellent",
			"E",
			"The protection provided is excellent.");
	public static final HarbourShelterQualityCode FAIR = new HarbourShelterQualityCode(
			"Fair",
			"F",
			"The protection provided is fair.");
	public static final HarbourShelterQualityCode GOOD = new HarbourShelterQualityCode(
			"Good",
			"G",
			"The protection provided is good.");
	public static final HarbourShelterQualityCode POOR = new HarbourShelterQualityCode(
			"Poor",
			"P",
			"The protection provided is poor.");

	private HarbourShelterQualityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
