/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskMeteorologicalImpactCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a subjective indication of the effect of weather conditions on a specific operation.";
	}

	private static HashMap<String, ActionTaskMeteorologicalImpactCode> physicalToCode = new HashMap<String, ActionTaskMeteorologicalImpactCode>();

	public static ActionTaskMeteorologicalImpactCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskMeteorologicalImpactCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskMeteorologicalImpactCode ACCEPTABLE = new ActionTaskMeteorologicalImpactCode(
			"Acceptable",
			"ACCPTB",
			"The meteorological conditions will not affect the specific operation.");
	public static final ActionTaskMeteorologicalImpactCode MARGINAL = new ActionTaskMeteorologicalImpactCode(
			"Marginal",
			"MARGNL",
			"The meteorological conditions will render the specific operation with a moderate risk of failure.");
	public static final ActionTaskMeteorologicalImpactCode UNACCEPTABLE = new ActionTaskMeteorologicalImpactCode(
			"Unacceptable",
			"UNACC",
			"The meteorological conditions will render the specific operation with a high risk of failure.");

	private ActionTaskMeteorologicalImpactCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
