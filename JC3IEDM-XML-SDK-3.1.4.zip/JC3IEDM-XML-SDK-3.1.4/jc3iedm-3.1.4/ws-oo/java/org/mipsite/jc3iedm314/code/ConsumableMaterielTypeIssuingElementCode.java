/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeIssuingElementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a standard unit in which a specific CONSUMABLE-MATERIEL-TYPE is made available.";
	}

	private static HashMap<String, ConsumableMaterielTypeIssuingElementCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeIssuingElementCode>();

	public static ConsumableMaterielTypeIssuingElementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeIssuingElementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeIssuingElementCode BALE = new ConsumableMaterielTypeIssuingElementCode(
			"Bale",
			"BALE",
			"A large bound, often wrapped package of materiel.");
	public static final ConsumableMaterielTypeIssuingElementCode BARREL = new ConsumableMaterielTypeIssuingElementCode(
			"Barrel",
			"BARREL",
			"A large cylindrical container having a flat top and bottom of equal diameter.");
	public static final ConsumableMaterielTypeIssuingElementCode BULK = new ConsumableMaterielTypeIssuingElementCode(
			"Bulk",
			"BLK",
			"Issued en masse (usually applies to liquids).");
	public static final ConsumableMaterielTypeIssuingElementCode BOX = new ConsumableMaterielTypeIssuingElementCode(
			"Box",
			"BOX",
			"A rectangular container usually having a lid or cover.");
	public static final ConsumableMaterielTypeIssuingElementCode CASE = new ConsumableMaterielTypeIssuingElementCode(
			"Case",
			"CASE",
			"A container.");
	public static final ConsumableMaterielTypeIssuingElementCode COIL = new ConsumableMaterielTypeIssuingElementCode(
			"Coil",
			"COIL",
			"A series of connected spirals or concentric rings.");
	public static final ConsumableMaterielTypeIssuingElementCode CONTAINER = new ConsumableMaterielTypeIssuingElementCode(
			"Container",
			"CONTNR",
			"A receptacle for holding or carrying material.");
	public static final ConsumableMaterielTypeIssuingElementCode CRATE = new ConsumableMaterielTypeIssuingElementCode(
			"Crate",
			"CRATE",
			"A container, as a slatted wooden case.");
	public static final ConsumableMaterielTypeIssuingElementCode DAY_OF_SUPPLY = new ConsumableMaterielTypeIssuingElementCode(
			"Day of supply",
			"DAYSPL",
			"A Day of supply (at combat rate) is the amount of consumable materiel required to enable a formation (unit i.e. Division, Brigade etc) to carry out operations for 1 day.");
	public static final ConsumableMaterielTypeIssuingElementCode DRUM = new ConsumableMaterielTypeIssuingElementCode(
			"Drum",
			"DRM",
			"Issued in drums, the size of which is recorded in the issuing-unit-of-measure-code (usually applies to liquids) (e.g., 200-litre drums).");
	public static final ConsumableMaterielTypeIssuingElementCode JERRICAN = new ConsumableMaterielTypeIssuingElementCode(
			"Jerrican",
			"JERCAN",
			"A container that holds 20 litres.");
	public static final ConsumableMaterielTypeIssuingElementCode PACK = new ConsumableMaterielTypeIssuingElementCode(
			"Pack",
			"PAK",
			"Issuing unit of measure is packs, the size of which is recorded in the issuing-unit-of-measure-code and issuing-quantity.");
	public static final ConsumableMaterielTypeIssuingElementCode PALLET = new ConsumableMaterielTypeIssuingElementCode(
			"Pallet",
			"PAL",
			"Issued in units of standard NATO pallets.");
	public static final ConsumableMaterielTypeIssuingElementCode RATION = new ConsumableMaterielTypeIssuingElementCode(
			"Ration",
			"RATION",
			"A fixed portion.");
	public static final ConsumableMaterielTypeIssuingElementCode ROUND = new ConsumableMaterielTypeIssuingElementCode(
			"Round",
			"ROUND",
			"A single item of ammunition.");
	public static final ConsumableMaterielTypeIssuingElementCode UNIT = new ConsumableMaterielTypeIssuingElementCode(
			"Unit",
			"UNT",
			"Issued singly.");

	private ConsumableMaterielTypeIssuingElementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
