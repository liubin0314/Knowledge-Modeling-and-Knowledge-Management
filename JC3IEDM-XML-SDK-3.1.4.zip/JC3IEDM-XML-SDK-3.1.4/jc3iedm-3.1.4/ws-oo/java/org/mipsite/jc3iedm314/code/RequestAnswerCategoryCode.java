/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RequestAnswerCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of REQUEST-ANSWER.";
	}

	private static HashMap<String, RequestAnswerCategoryCode> physicalToCode = new HashMap<String, RequestAnswerCategoryCode>();

	public static RequestAnswerCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RequestAnswerCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RequestAnswerCategoryCode NO = new RequestAnswerCategoryCode(
			"No",
			"NO",
			"An answer in the negative.");
	public static final RequestAnswerCategoryCode UNANSWERABLE = new RequestAnswerCategoryCode(
			"Unanswerable",
			"UNA",
			"The information specified in the REQUEST cannot be obtained.");
	public static final RequestAnswerCategoryCode UNKNOWN = new RequestAnswerCategoryCode(
			"Unknown",
			"UNK",
			"Answer cannot be formulated due to the absence of information.");
	public static final RequestAnswerCategoryCode YES = new RequestAnswerCategoryCode(
			"Yes",
			"YES",
			"An answer in the affirmative.");

	private RequestAnswerCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
