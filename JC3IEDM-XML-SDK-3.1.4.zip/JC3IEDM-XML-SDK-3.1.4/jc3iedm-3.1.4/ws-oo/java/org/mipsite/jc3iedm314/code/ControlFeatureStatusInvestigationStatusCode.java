/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ControlFeatureStatusInvestigationStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the investigation status of the site encompassed by a specific CONTROL-FEATURE.";
	}

	private static HashMap<String, ControlFeatureStatusInvestigationStatusCode> physicalToCode = new HashMap<String, ControlFeatureStatusInvestigationStatusCode>();

	public static ControlFeatureStatusInvestigationStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ControlFeatureStatusInvestigationStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ControlFeatureStatusInvestigationStatusCode INVESTIGATION_DENIED = new ControlFeatureStatusInvestigationStatusCode(
			"Investigation denied",
			"DENIED",
			"The authority controlling the site associated to the specific control-feature did not allow a formal examination or study on it.");
	public static final ControlFeatureStatusInvestigationStatusCode INVESTIGATED_NEGATIVE = new ControlFeatureStatusInvestigationStatusCode(
			"Investigated, negative",
			"INVNEG",
			"There was a formal examination or study on the site associated to the specific control-feature, denying the reason of the investigation.");
	public static final ControlFeatureStatusInvestigationStatusCode INVESTIGATED_POSITIVE = new ControlFeatureStatusInvestigationStatusCode(
			"Investigated, positive",
			"INVPOS",
			"There was a formal examination or study on the site associated to the specific control-feature, confirming the reason of the investigation.");
	public static final ControlFeatureStatusInvestigationStatusCode NOT_KNOWN = new ControlFeatureStatusInvestigationStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ControlFeatureStatusInvestigationStatusCode NONE = new ControlFeatureStatusInvestigationStatusCode(
			"None",
			"NONE",
			"There has been no formal examination or study on the site associated to the specific control-feature.");
	public static final ControlFeatureStatusInvestigationStatusCode UNDER_INVESTIGATION = new ControlFeatureStatusInvestigationStatusCode(
			"Under investigation",
			"UNDINV",
			"A formal examination or study is been taken on the site associated to the specific control feature.");

	private ControlFeatureStatusInvestigationStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
