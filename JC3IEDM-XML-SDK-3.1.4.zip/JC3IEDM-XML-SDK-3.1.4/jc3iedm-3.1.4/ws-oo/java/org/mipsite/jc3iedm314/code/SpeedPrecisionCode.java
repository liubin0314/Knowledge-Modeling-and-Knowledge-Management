/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SpeedPrecisionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the maximum degree of discrimination or resolution for which speed is stated.";
	}

	private static HashMap<String, SpeedPrecisionCode> physicalToCode = new HashMap<String, SpeedPrecisionCode>();

	public static SpeedPrecisionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SpeedPrecisionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SpeedPrecisionCode KNOTS = new SpeedPrecisionCode(
			"Knots",
			"KNOTS",
			"The speed is defined to the precision of a knot.");
	public static final SpeedPrecisionCode KILOMETRES_PER_HOUR = new SpeedPrecisionCode(
			"Kilometres per hour",
			"KPH",
			"The speed is defined to the precision of kilometres per hour.");
	public static final SpeedPrecisionCode METRES_PER_SECOND = new SpeedPrecisionCode(
			"Metres per second",
			"MPS",
			"The speed is defined to the precision of metres per second.");

	private SpeedPrecisionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
