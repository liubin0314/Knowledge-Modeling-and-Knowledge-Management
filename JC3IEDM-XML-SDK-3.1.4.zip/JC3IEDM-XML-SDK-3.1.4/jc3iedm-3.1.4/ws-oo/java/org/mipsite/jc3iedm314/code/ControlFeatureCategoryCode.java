/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ControlFeatureCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CONTROL-FEATURE.";
	}

	private static HashMap<String, ControlFeatureCategoryCode> physicalToCode = new HashMap<String, ControlFeatureCategoryCode>();

	public static ControlFeatureCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ControlFeatureCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ControlFeatureCategoryCode AIRSPACE_CONTROL_MEANS = new ControlFeatureCategoryCode(
			"AIRSPACE-CONTROL-MEANS",
			"ACM",
			"A CONTROL-FEATURE that reserves airspace for specific airspace users, restricts the action of airspace users, controls the actions of specific airspace users, and/or requires airspace users to accomplish specific actions.");
	public static final ControlFeatureCategoryCode APPROACH_DIRECTION = new ControlFeatureCategoryCode(
			"APPROACH-DIRECTION",
			"APPRDR",
			"A CONTROL-FEATURE that specifies approach directional details for takeoff and landing.");
	public static final ControlFeatureCategoryCode NOT_OTHERWISE_SPECIFIED = new ControlFeatureCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ControlFeatureCategoryCode ROUTE = new ControlFeatureCategoryCode(
			"ROUTE",
			"ROUTE",
			"A CONTROL-FEATURE that is the prescribed course to be travelled from a specific point of origin to a specific destination.");
	public static final ControlFeatureCategoryCode ROUTE_SEGMENT = new ControlFeatureCategoryCode(
			"ROUTE-SEGMENT",
			"RTESEG",
			"A portion of a route usually without an intermediate stop, as defined by two consecutive significant points.");

	private ControlFeatureCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
