/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OperationalInformationGroupCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OPERATIONAL-INFORMATION-GROUP.";
	}

	private static HashMap<String, OperationalInformationGroupCategoryCode> physicalToCode = new HashMap<String, OperationalInformationGroupCategoryCode>();

	public static OperationalInformationGroupCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OperationalInformationGroupCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OperationalInformationGroupCategoryCode CORRELATED_ENEMY_AND_UNKNOWN = new OperationalInformationGroupCategoryCode(
			"Correlated enemy and unknown",
			"CORENU",
			"The specific OPERATIONAL-INFORMATION-GROUP represents aggregated data about opposing or unknown force elements. Both factual reports and estimates may be included as part of the OPERATIONAL-INFORMATION-GROUP.");
	public static final OperationalInformationGroupCategoryCode FRIENDLY_AND_NEUTRAL_ORGANISATIONAL = new OperationalInformationGroupCategoryCode(
			"Friendly and neutral (organisational)",
			"FRDNEU",
			"The specific OPERATIONAL-INFORMATION-GROUP represents essential data about friendly and neutral organisations. The data set includes as a minimum holdings, status, and location.");
	public static final OperationalInformationGroupCategoryCode FRIENDLY_AND_NEUTRAL_NON_ORGANISATIONAL = new OperationalInformationGroupCategoryCode(
			"Friendly and neutral (non-organisational)",
			"FRNENO",
			"The specific OPERATIONAL-INFORMATION-GROUP represents data about objects, such as facilities and control measures, that a given organisation controls or is responsible for directly.");
	public static final OperationalInformationGroupCategoryCode GLOBALLY_SIGNIFICANT = new OperationalInformationGroupCategoryCode(
			"Globally significant",
			"GLBSGN",
			"The specific OPERATIONAL-INFORMATION-GROUP represents data that cannot be aggregated and does not fall within the scope of other predefined subcategories.");
	public static final OperationalInformationGroupCategoryCode UNCORRELATED_ENEMY_AND_UNKNOWN = new OperationalInformationGroupCategoryCode(
			"Uncorrelated enemy and unknown",
			"UNCORR",
			"The specific OPERATIONAL-INFORMATION-GROUP represents factual data about individual detection or report of opposing or unknown force elements without the data being aggregated.");
	public static final OperationalInformationGroupCategoryCode PLANS_ORDERS = new OperationalInformationGroupCategoryCode(
			"Plans/Orders",
			"PLNORD",
			"The specific OPERATIONAL-INFORMATION-GROUP represents planning and/or order data that is to be distributed as a package.");

	private OperationalInformationGroupCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
