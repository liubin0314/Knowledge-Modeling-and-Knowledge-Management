/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-OBJECTIVE-TYPE.";
	}

	private static HashMap<String, ActionObjectiveTypeCategoryCode> physicalToCode = new HashMap<String, ActionObjectiveTypeCategoryCode>();

	public static ActionObjectiveTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveTypeCategoryCode ACTION_OBJECTIVE_TYPE_IMAGERY_PRODUCT = new ActionObjectiveTypeCategoryCode(
			"ACTION-OBJECTIVE-TYPE-IMAGERY-PRODUCT",
			"AOTIMG",
			"The intended characteristics of a specific ACTION-OBJECTIVE-TYPE-IMAGERY-PRODUCT that is an instance of MATERIEL-TYPE.");
	public static final ActionObjectiveTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ActionObjectiveTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private ActionObjectiveTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
