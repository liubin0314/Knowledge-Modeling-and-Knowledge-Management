/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusMineZoneRiskCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the known threat (risk) of a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusMineZoneRiskCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusMineZoneRiskCode>();

	public static MinefieldMaritimeStatusMineZoneRiskCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusMineZoneRiskCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusMineZoneRiskCode LITTLE = new MinefieldMaritimeStatusMineZoneRiskCode(
			"Little",
			"LITTLE",
			"The threat to a vessel is small.");
	public static final MinefieldMaritimeStatusMineZoneRiskCode SERIOUS = new MinefieldMaritimeStatusMineZoneRiskCode(
			"Serious",
			"SERIOS",
			"The threat to a vessel is serious.");
	public static final MinefieldMaritimeStatusMineZoneRiskCode VERY_GREAT = new MinefieldMaritimeStatusMineZoneRiskCode(
			"Very great",
			"VRYGRT",
			"The threat to a vessel is very large.");

	private MinefieldMaritimeStatusMineZoneRiskCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
