/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FACILITY-STATUS.";
	}

	private static HashMap<String, FacilityStatusCategoryCode> physicalToCode = new HashMap<String, FacilityStatusCategoryCode>();

	public static FacilityStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusCategoryCode AIRFIELD_STATUS = new FacilityStatusCategoryCode(
			"AIRFIELD-STATUS",
			"AIRFST",
			"A FACILITY-STATUS that is a record of conditions of a specific AIRFIELD.");
	public static final FacilityStatusCategoryCode MEDICAL_FACILITY_STATUS = new FacilityStatusCategoryCode(
			"MEDICAL-FACILITY-STATUS",
			"MEDFST",
			"A FACILITY-STATUS that is a record of condition of a specific medical facility.");
	public static final FacilityStatusCategoryCode MINEFIELD_MARITIME_STATUS = new FacilityStatusCategoryCode(
			"MINEFIELD-MARITIME-STATUS",
			"MNMAST",
			"A FACILITY-STATUS that is a record of condition of a specific MINEFIELD-MARITIME.");
	public static final FacilityStatusCategoryCode NOT_OTHERWISE_SPECIFIED = new FacilityStatusCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private FacilityStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
