/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PrivateSectorOrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of PRIVATE-SECTOR-ORGANISATION-TYPE.";
	}

	private static HashMap<String, PrivateSectorOrganisationTypeCategoryCode> physicalToCode = new HashMap<String, PrivateSectorOrganisationTypeCategoryCode>();

	public static PrivateSectorOrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PrivateSectorOrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PrivateSectorOrganisationTypeCategoryCode AGRICULTURAL = new PrivateSectorOrganisationTypeCategoryCode(
			"Agricultural",
			"AGRCTL",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is the production and processing of agricultural products.");
	public static final PrivateSectorOrganisationTypeCategoryCode DEFENCE_INDUSTRY = new PrivateSectorOrganisationTypeCategoryCode(
			"Defence industry",
			"DEFIND",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is defence in nature.");
	public static final PrivateSectorOrganisationTypeCategoryCode FISHING_INDUSTRY = new PrivateSectorOrganisationTypeCategoryCode(
			"Fishing industry",
			"FSHIND",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is the production and processing of seafood products.");
	public static final PrivateSectorOrganisationTypeCategoryCode MANUFACTURING = new PrivateSectorOrganisationTypeCategoryCode(
			"Manufacturing",
			"MFG",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is manufacturing in nature.");
	public static final PrivateSectorOrganisationTypeCategoryCode MULTI_NATIONAL = new PrivateSectorOrganisationTypeCategoryCode(
			"Multi-national",
			"MULTIN",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is multi-national in scope and nature.");
	public static final PrivateSectorOrganisationTypeCategoryCode NEWS_MEDIA = new PrivateSectorOrganisationTypeCategoryCode(
			"News media",
			"NEWSMD",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is the gathering and dissemination of news.");
	public static final PrivateSectorOrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new PrivateSectorOrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final PrivateSectorOrganisationTypeCategoryCode PHILANTHROPIC = new PrivateSectorOrganisationTypeCategoryCode(
			"Philanthropic",
			"PHLNTP",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is philanthropic in nature.");
	public static final PrivateSectorOrganisationTypeCategoryCode RETAIL = new PrivateSectorOrganisationTypeCategoryCode(
			"Retail",
			"RETAIL",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is retail in nature.");
	public static final PrivateSectorOrganisationTypeCategoryCode TRADE = new PrivateSectorOrganisationTypeCategoryCode(
			"Trade",
			"TRADE",
			"A PRIVATE-SECTOR-ORGANISATION-TYPE whose predominant business is trade in nature.");

	private PrivateSectorOrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
