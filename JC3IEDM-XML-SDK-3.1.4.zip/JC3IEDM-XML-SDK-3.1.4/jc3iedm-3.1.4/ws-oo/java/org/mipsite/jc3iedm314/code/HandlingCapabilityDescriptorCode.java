/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HandlingCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the HANDLING-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, HandlingCapabilityDescriptorCode> physicalToCode = new HashMap<String, HandlingCapabilityDescriptorCode>();

	public static HandlingCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HandlingCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HandlingCapabilityDescriptorCode BULK_LIQUID = new HandlingCapabilityDescriptorCode(
			"Bulk liquid",
			"BLKLIQ",
			"The numeric value representing the maximum amount of any unpackaged liquid.");
	public static final HandlingCapabilityDescriptorCode BULK_VOLUME = new HandlingCapabilityDescriptorCode(
			"Bulk volume",
			"BLKVOL",
			"The numeric value representing the maximum volume of any unpackaged mass.");
	public static final HandlingCapabilityDescriptorCode MAXIMUM_COUNT = new HandlingCapabilityDescriptorCode(
			"Maximum count",
			"MAXCNT",
			"The numeric value representing the maximum item count.");
	public static final HandlingCapabilityDescriptorCode MAXIMUM_CARGO_HEIGHT = new HandlingCapabilityDescriptorCode(
			"Maximum cargo height",
			"MCRHEI",
			"The one-dimensional linear measurement that represents the extreme vertical distance, measured from the lowest to the highest reference point, of any object.");
	public static final HandlingCapabilityDescriptorCode MAXIMUM_CARGO_LENGTH = new HandlingCapabilityDescriptorCode(
			"Maximum cargo length",
			"MCRLEN",
			"The one-dimensional linear measurement that represents the extreme horizontal distance, measured from side to side and perpendicular to the central axis, of any object.");
	public static final HandlingCapabilityDescriptorCode MAXIMUM_CARGO_WEIGHT = new HandlingCapabilityDescriptorCode(
			"Maximum cargo weight",
			"MCRWGT",
			"The numeric value representing the maximum weight of any cargo.");
	public static final HandlingCapabilityDescriptorCode MAXIMUM_CARGO_WIDTH = new HandlingCapabilityDescriptorCode(
			"Maximum cargo width",
			"MCRWID",
			"The one-dimensional linear measurement that represents the extreme horizontal distance, measured from side to side and parallel to the central axis, of any object.");
	public static final HandlingCapabilityDescriptorCode NEQ_LIMIT = new HandlingCapabilityDescriptorCode(
			"NEQ limit",
			"NEQLMT",
			"The numeric value representing the Net Explosive Quantity limit equivalent to TNT (trinitrotoluene) explosive power.");

	private HandlingCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
