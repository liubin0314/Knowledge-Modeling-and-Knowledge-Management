/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;

public abstract class AbstractActionEvent extends AbstractAction {

	// private fields

	private Set<Ref<AbstractActionEventDetail>> detailSet; // zero-one-or-more
	private Set<Ref<ActionEventStatus>> statusSet; // one-or-more

	// default constructor

	public AbstractActionEvent() {
		this.detailSet = new HashSet<Ref<AbstractActionEventDetail>>();
		this.statusSet = new HashSet<Ref<ActionEventStatus>>();
	}

	// getter & setter methods

	public Set<Ref<AbstractActionEventDetail>> getDetailSet() {
		return this.detailSet;
	}

	public void addDetail(Ref<AbstractActionEventDetail> detail) {
		this.detailSet.add(detail);
	}

	public Set<Ref<ActionEventStatus>> getStatusSet() {
		return this.statusSet;
	}

	public void addStatus(Ref<ActionEventStatus> status) {
		this.statusSet.add(status);
	}
}
