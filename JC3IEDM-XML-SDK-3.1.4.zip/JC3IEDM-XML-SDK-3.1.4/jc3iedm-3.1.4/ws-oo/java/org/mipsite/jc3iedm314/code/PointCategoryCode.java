/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PointCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of POINT.";
	}

	private static HashMap<String, PointCategoryCode> physicalToCode = new HashMap<String, PointCategoryCode>();

	public static PointCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PointCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PointCategoryCode ABSOLUTE_POINT = new PointCategoryCode(
			"ABSOLUTE-POINT",
			"ABS",
			"A POINT in a geodetic system.");
	public static final PointCategoryCode RELATIVE_POINT = new PointCategoryCode(
			"RELATIVE-POINT",
			"REL",
			"A POINT whose position is specified with respect to a specific RELATIVE-COORDINATE-SYSTEM.");

	private PointCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
