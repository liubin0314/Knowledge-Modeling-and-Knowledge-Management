/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeUnitedNationsNumberCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the United Nations (UN) Numbers that are four-digit numbers used world-wide in international commerce and transportation to identify hazardous chemicals or classes of hazardous materials.";
	}

	private static HashMap<String, ConsumableMaterielTypeUnitedNationsNumberCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeUnitedNationsNumberCode>();

	public static ConsumableMaterielTypeUnitedNationsNumberCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeUnitedNationsNumberCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1005 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1005",
			"1005",
			"Ammonia, anhydrous. Includes the agent(s): ammonia.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1008 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1008",
			"1008",
			"Boron trifluoride. Includes the agent(s): boron trifluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1016 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1016",
			"1016",
			"Carbon monoxide, compressed. Includes the agent(s): carbon monoxide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1017 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1017",
			"1017",
			"Chlorine. Includes the agent(s): chlorine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1040 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1040",
			"1040",
			"Ethylene oxide, or Ethylene oxide with nitrogen up to a total pressure of 1 mpa (10 bar) at 50 �C. Includes the agent(s): ethylene oxide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1045 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1045",
			"1045",
			"Fluorine, compressed. Includes the agent(s): fluorine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1048 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1048",
			"1048",
			"Hydrogen bromide, anhydrous. Includes the agent(s): hydrogen bromide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1050 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1050",
			"1050",
			"Hydrogen chloride, anhydrous. Includes the agent(s): hydrogen chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1051 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1051",
			"1051",
			"Hydrogen cyanide, stabilized containing less than 3% water. Includes the agent(s): hydrogen cyanide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1053 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1053",
			"1053",
			"Hydrogen sulphide. Includes the agent(s): hydrogen sulphide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1062 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1062",
			"1062",
			"Methyl bromide with not more than 2% chloropicrin. Includes the agent(s): methyl bromide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1064 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1064",
			"1064",
			"Methyl mercaptan. Includes the agent(s): methyl mercaptan.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1067 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1067",
			"1067",
			"Dinitrogen tetroxide (nitrogen dioxide). Includes the agent(s): nitrogen dioxide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1076 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1076",
			"1076",
			"Phosgene. Includes the agent(s): Phosgene; Diphosgene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1079 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1079",
			"1079",
			"Sulphur dioxide. Includes the agent(s) referred to as: sulphur dioxide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1080 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1080",
			"1080",
			"Sulphur hexafluoride. Includes the agent(s): sulphur hexafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1092 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1092",
			"1092",
			"Acrolein, stabilized. Includes the agent(s): acrolein.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1093 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1093",
			"1093",
			"Acrylonitrile, stabilized. Includes the agent(s): acrylonitrile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1098 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1098",
			"1098",
			"Allyl alcohol. Includes the agent(s): allyl alcohol.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1114 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1114",
			"1114",
			"Benzene. Includes the agent(s): benzene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1131 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1131",
			"1131",
			"Carbon disulphide. Includes the agent(s): carbon disulphide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1134 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1134",
			"1134",
			"Chlorobenzene. Includes the agent(s): chlorobenzene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1135 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1135",
			"1135",
			"Ethylene chlorohydrin. Includes the agent(s): chloroethanol.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1143 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1143",
			"1143",
			"Crotonaldehyde, stabilized. Includes the agent(s): crotonaldehyde.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1158 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1158",
			"1158",
			"Diisopropylamine. Includes the agent(s): diisopropylamine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1184 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1184",
			"1184",
			"Ethylene dichloride. Includes the agent(s): 1,2 dichloroethane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1198 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1198",
			"1198",
			"Formaldehyde solution, flammable. Includes the agent(s): formaldehyde.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1238 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1238",
			"1238",
			"Methyl chloroformate. Includes the agent(s): methyl chloroformate.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1244 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1244",
			"1244",
			"Methylhydrazine. Includes the agent(s): methyl hydrazine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1245 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1245",
			"1245",
			"Methyl isobutyl ketone. Includes the agent(s): methyl isobutyl ketone.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1268 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1268",
			"1268",
			"Petroleum distillates, N.O.S. or Petroleum products, N.O.S.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1282 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1282",
			"1282",
			"Pyridine. Includes the agent(s): pyridine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1294 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1294",
			"1294",
			"Toluene. Includes the agent(s): toluene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1338 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1338",
			"1338",
			"Phosphorus, amorphous. Includes the agent(s): red phosphorous.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1381 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1381",
			"1381",
			"Phosphorus, white or yellow, dry or under water or in solution. Includes the agent(s): white phosphorous.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1541 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1541",
			"1541",
			"Acetone cyanohydrin, stabilized. Includes the agent(s): acetone cyanohydrin.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1556 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1556",
			"1556",
			"Arsenic compound, liquid, N.O.S., inorganic, including: Arsenates, N.O.S., Arsenites, N.O.S.; and Arsenic sulphides, N.O.S. Includes the agent(s): Phenyldichloroarsine; Methyldichloroarsine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1557 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1557",
			"1557",
			"Arsenic compound, solid, N.O.S., inorganic, including: Arsenates, N.O.S.; Arsenites, N.O.S.; and Arsenic sulphides, N.O.S. Includes the agent(s): Lewisite.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1560 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1560",
			"1560",
			"Arsenic trichloride. Includes the agent(s): arsenic trichloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1569 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1569",
			"1569",
			"Bromoacetone. Includes the agent(s): bromoacetone.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1580 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1580",
			"1580",
			"Chloropicrin. Includes the agent(s): chloropicrin.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1589 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1589",
			"1589",
			"Cyanogen chloride, stabilized. Includes the agent(s): cyanogen chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1595 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1595",
			"1595",
			"Dimethyl sulphate. Includes the agent(s): dimethyl sulfate.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1605 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1605",
			"1605",
			"Ethylene dibromide. Includes the agent(s): ethylene dibromide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1693 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1693",
			"1693",
			"Tear gas substance, liquid or solid, N.O.S. Includes the agent(s): 2-Chlorobenzalmalononitrile (CS) (listed as 2810 in ERG).");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1695 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1695",
			"1695",
			"Chloroacetone, stabilized. Includes the agent(s): chloroacetone.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1697 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1697",
			"1697",
			"Chloroacetophenone. Includes the agent(s): Tear Gas (CN).");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1698 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1698",
			"1698",
			"Diphenylamine chloroarsine. Includes the agent(s): adamsite.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1699 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1699",
			"1699",
			"Diphenylchloroarsine, liquid or solid. Includes the agent(s): diphenylchloroarsine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1722 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1722",
			"1722",
			"Allyl chloroformate. Includes the agent(s): allyl chloroformate.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1741 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1741",
			"1741",
			"Boron trichloride. Includes the agent(s): boron trichloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1754 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1754",
			"1754",
			"Chlorosulphonic acid (with or without sulphur trioxide). Includes the agent(s): chlorosulphonic acid.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1790 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1790",
			"1790",
			"Hydrofluoric acid. Includes the agent(s): hydrogen fluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1809 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1809",
			"1809",
			"Phosphorus trichloride. Includes the agent(s): phosphorus trichloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1810 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1810",
			"1810",
			"Phosphorus oxychloride. Includes the agent(s): phosphorus oxychloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1830 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1830",
			"1830",
			"Sulphuric acid with more than 51% acid. Includes the agent(s): sulphuric acid.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1834 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1834",
			"1834",
			"Sulphuryl chloride. Includes the agent(s): sulphuryl chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1836 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1836",
			"1836",
			"Thionyl chloride. Includes the agent(s): thionyl chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1838 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1838",
			"1838",
			"Titanium tetrachloride. Includes the agent(s): titanium tetrachloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1859 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1859",
			"1859",
			"Silicon tetrafluoride. Includes the agent(s): silicon tetrafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1888 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1888",
			"1888",
			"Chloroform. Includes the agent(s): chloroform.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1889 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1889",
			"1889",
			"Cyanogen bromide. Includes the agent(s): cyanogen bromide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1897 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1897",
			"1897",
			"Tetrachloroethylene. Includes the agent(s): tetrachloroethylene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1911 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1911",
			"1911",
			"Diborane. Includes the agent(s): diborane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1972 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1972",
			"1972",
			"Methane, refrigerated liquid or natural gas, refrigerated liquid with high methane content. Includes the agent(s): methane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1978 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1978",
			"1978",
			"Propane. Includes the agent(s): propane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_1994 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 1994",
			"1994",
			"Iron pentacarbonyl. Includes the agent(s): iron pentacarbonyl.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2029 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2029",
			"2029",
			"Hydrazine, anhydrous. Includes the agent(s): hydrazine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2032 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2032",
			"2032",
			"Nitric acid, red fuming. Includes the agent(s): fuming nitric acid.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2055 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2055",
			"2055",
			"Styrene monomer, stabilized. Includes the agent(s): styrene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2188 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2188",
			"2188",
			"Arsine. Includes the agent(s): arsine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2194 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2194",
			"2194",
			"Selenium hexafluoride. Includes the agent(s): selenium hexafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2195 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2195",
			"2195",
			"Tellurium hexafluoride. Includes the agent(s): tellurium hexafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2196 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2196",
			"2196",
			"Tungsten hexafluoride. Includes the agent(s): tungsten hexafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2198 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2198",
			"2198",
			"Phosphorus pentafluoride. Includes the agent(s): phosphorus pentafluoride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2199 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2199",
			"2199",
			"Phosphine. Includes the agent(s): phosphine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2202 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2202",
			"2202",
			"Hydrogen selenide, anhydrous. Includes the agent(s): hydrogen selenide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2204 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2204",
			"2204",
			"Carbonyl sulphide. Includes the agent(s): carbonyl sulphide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2323 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2323",
			"2323",
			"Triethyl phosphate. Includes the agent(s): triethyl phosphite.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2329 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2329",
			"2329",
			"Trimethyl phosphate. Includes the agent(s): trimethyl phosphite.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2334 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2334",
			"2334",
			"Allylamine. Includes the agent(s): allyl amine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2382 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2382",
			"2382",
			"Dimethylhydrazine, symmetrical. Includes the agent(s): 1,1-dimethylhydrazine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2442 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2442",
			"2442",
			"Trichloroacetyl chloride. Includes the agent(s): trichloroacetyl chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2480 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2480",
			"2480",
			"Methyl isocyanate. Includes the agent(s): methyl isocyanate.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2485 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2485",
			"2485",
			"N-butyl isocyanate. Includes the agent(s): n-butyl isocyanate.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2521 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2521",
			"2521",
			"Diketene, stabilized. Includes the agent(s): diketene.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2534 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2534",
			"2534",
			"Methylchlorosilane. Includes the agent(s): methyl chlorosilane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2668 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2668",
			"2668",
			"Chloroacetonitrile. Includes the agent(s): chloroacetonitrile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2676 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2676",
			"2676",
			"Stibine. Includes the agent(s): stibine.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2692 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2692",
			"2692",
			"Boron tribromide. Includes the agent(s): boron tribromide.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2783 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2783",
			"2783",
			"Organophosphorus pesticide, solid, toxic. Includes the agent(s): parathion, malathion.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2810 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2810",
			"2810",
			"Toxic liquid, organic, N.O.S. Includes the agent(s): Tabun, Sarin, Soman, Cyclosarin, Mustard (Bis(2-chloroethyl)sulphide), Nitrogen Mustard (HN-1), Nitrogen Mustard (HN-2), Nitrogen Mustard (HN-3), thickened tabun, Thickened Soman, Thickened Cyclosarin, Thickened S+D23ulphur Mustard, Thickened VX, VX, Sulphur Mustard-T mixture, Levinstein mustard, Vx.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2811 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2811",
			"2811",
			"Toxic solid, organic, N.O.S. Includes the agent(s) referred to as: Phosgene Oxime; 3-Quinuclidinyl benzilate; Capsaicin.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2814 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2814",
			"2814",
			"Infectious substance, affecting humans. Includes the agent(s): Chikungunya virus; Crimean-Congo hemorrhagic fever virus; Dengue fever virus; Eastern equine encephalitis virus; Ebola virus; Hantaan virus; Junin virus; Lassa virus; Lymphocytic choriomeningitis virus; Machupo virus; Marburg virus; Monkeypox; Rift Valley Fever virus; Tick-borne encephalitis virus; Variola virus; Venezuelan equine encephalitis virus; Western equine encephalitis virus; Yellow fever virus; Japanese encephalitis virus; Coxiella burnetii; Bart quintana; Rickettsia prowasecki; Rickettsia rickettsii; Bacillus anthracis; Brucella abortus; Brucella melitensis; Brucella suis; Chlamydia psittaci; Clostridium botulinum; Francisella tularensis; Burkholderia mallei; Burkholderia pseudomallei; Salmonella typhi; Shigella dysenteriae; Vibrio cholerae; Yersinia pestis.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2831 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2831",
			"2831",
			"1,1,1-trichloroethane. Includes the agent(s): 1,1,1-trichloroethane.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2900 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2900",
			"2900",
			"Infectious substance, affecting animals only. Includes the agent(s): African swine fever virus; Highly pathogenic Avian influenza virus (synonym: fowl plague); Bluetongue virus; Foot and mouth disease virus; Goat pox virus; Herpes virus (Aujeszky�s disease); Hog cholera virus (synonym: Swine fever virus); Lyssa virus; Newcastle disease virus; Peste des petits ruminants virus; Porcine enterovirus type-9 (synonym: Swine vesicular disease virus); Rinderpest virus (synonym: Cattle plague; Sheep pox virus; Teschen disease virus; Vesicular stomatitis virus; Mycoplasma mycoides; Contagious bovine pleuropneumonia; Contagious Equine Metritis; Heartwater (Cowdria); Screwworm Myiasis (synonym: Blowfly; Cochliomyia hominivorax); Swine vesicular disease.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2908 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2908",
			"2908",
			"Radioactive material, expected package - empty packaging.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2909 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2909",
			"2909",
			"Radioactive material, excepted package - articles manufactured from natural uranium or depleted uranium or natural thorium.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2910 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2910",
			"2910",
			"Radioactive material, excepted package - limited quantity of material.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2911 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2911",
			"2911",
			"Radioactive material, excepted package - instruments or articles.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2912 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2912",
			"2912",
			"Radioactive material, low specific activity (LSA-I), non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2913 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2913",
			"2913",
			"Radioactive material, surface contaminated objects (SCO-I or SCO-II), non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2915 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2915",
			"2915",
			"Radioactive material, type A package, non-special form, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2916 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2916",
			"2916",
			"Radioactive material, type B(U) package, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2917 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2917",
			"2917",
			"Radioactive material, type B(M) package, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_2919 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 2919",
			"2919",
			"Radioactive material, transported under special arrangement, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3172 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3172",
			"3172",
			"Toxins, extracted from living sources, N.O.S. Includes the agent(s): Botulinum toxins; Clostidium perfringens toxins; Conotoxin; Ricin; Saxitoxin;Shiga toxin; Staphylococcus aureus toxins; Tetrodotoxin; Verotoxin; Microcystin; Trichothecene mycotoxin.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3246 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3246",
			"3246",
			"Methanesulphonyl chloride. Includes the agent(s): methanesulfonyl chloride.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3321 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3321",
			"3321",
			"Radioactive material, low specific activity (LSA-II), non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3322 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3322",
			"3322",
			"Radioactive material, low specific activity (LSA-III), non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3323 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3323",
			"3323",
			"Radioactive material, type C package, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3324 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3324",
			"3324",
			"Radioactive material, low specific activity (LSA-II), fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3325 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3325",
			"3325",
			"Radioactive material, low specific activity (LSA-III), fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3326 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3326",
			"3326",
			"Radioactive material, surface contaminated objects (SCO-I or SCO-II), fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3327 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3327",
			"3327",
			"Radioactive material, type A package, fissile, non-special form.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3328 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3328",
			"3328",
			"Radioactive material, type B(U) package, fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3329 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3329",
			"3329",
			"Radioactive material, type B(M) package, fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3330 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3330",
			"3330",
			"Radioactive material, type C package, fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3331 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3331",
			"3331",
			"Radioactive material, transported under special arrangement, fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3332 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3332",
			"3332",
			"Radioactive material, type A package, special form, non fissile or fissile-excepted.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode UN_DANGEROUS_GOODS_3333 = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"UN Dangerous Goods # 3333",
			"3333",
			"Radioactive material, type A package, special form, fissile.");
	public static final ConsumableMaterielTypeUnitedNationsNumberCode NOT_OTHERWISE_SPECIFIED = new ConsumableMaterielTypeUnitedNationsNumberCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private ConsumableMaterielTypeUnitedNationsNumberCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
