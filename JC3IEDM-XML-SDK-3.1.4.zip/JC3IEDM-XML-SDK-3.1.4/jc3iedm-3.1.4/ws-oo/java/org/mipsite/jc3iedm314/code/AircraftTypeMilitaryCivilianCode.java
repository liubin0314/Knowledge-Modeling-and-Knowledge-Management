/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeMilitaryCivilianCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether an aircraft is primarily intended for military or civilian use.";
	}

	private static HashMap<String, AircraftTypeMilitaryCivilianCode> physicalToCode = new HashMap<String, AircraftTypeMilitaryCivilianCode>();

	public static AircraftTypeMilitaryCivilianCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeMilitaryCivilianCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeMilitaryCivilianCode CIVILIAN = new AircraftTypeMilitaryCivilianCode(
			"Civilian",
			"CIVIL",
			"The AIRCRAFT-TYPE is primarily intended for civilian use.");
	public static final AircraftTypeMilitaryCivilianCode MILITARY = new AircraftTypeMilitaryCivilianCode(
			"Military",
			"MIL",
			"The AIRCRAFT-TYPE is primarily intended for military use.");
	public static final AircraftTypeMilitaryCivilianCode NOT_KNOWN = new AircraftTypeMilitaryCivilianCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private AircraftTypeMilitaryCivilianCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
