/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStartQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the role of starting date and time with respect to the period of effectiveness of a specific ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskStartQualifierCode> physicalToCode = new HashMap<String, ActionTaskStartQualifierCode>();

	public static ActionTaskStartQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStartQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStartQualifierCode AFTER = new ActionTaskStartQualifierCode(
			"After",
			"AFT",
			"Time intended is later than the time specified.");
	public static final ActionTaskStartQualifierCode AS_SOON_AS_POSSIBLE = new ActionTaskStartQualifierCode(
			"As soon as possible",
			"ASAP",
			"Begin the activity at the earliest possible time once execution is authorised.");
	public static final ActionTaskStartQualifierCode AS_SOON_AS_POSSIBLE_AFTER = new ActionTaskStartQualifierCode(
			"As soon as possible after",
			"ASAPAF",
			"Begin the activity at the earliest possible time after the specified start time.");
	public static final ActionTaskStartQualifierCode AS_SOON_AS_POSSIBLE_NOT_LATER_THAN = new ActionTaskStartQualifierCode(
			"As soon as possible not later than",
			"ASAPNL",
			"Begin the activity at the earliest possible time but not later than the specified start time.");
	public static final ActionTaskStartQualifierCode AT = new ActionTaskStartQualifierCode(
			"At",
			"AT",
			"Time intended is the time specified.");
	public static final ActionTaskStartQualifierCode BEFORE = new ActionTaskStartQualifierCode(
			"Before",
			"BEF",
			"Time intended is in advance of the time specified.");
	public static final ActionTaskStartQualifierCode NO_LATER_THAN = new ActionTaskStartQualifierCode(
			"No later than",
			"NLT",
			"Time specified is the latest.");
	public static final ActionTaskStartQualifierCode NOT_BEFORE = new ActionTaskStartQualifierCode(
			"Not before",
			"NOB",
			"Time specified is the earliest.");
	public static final ActionTaskStartQualifierCode ON_CALL = new ActionTaskStartQualifierCode(
			"On call",
			"ONCALL",
			"Time will be specified later by a dedicated call.");
	public static final ActionTaskStartQualifierCode ON_CODEWORD = new ActionTaskStartQualifierCode(
			"On codeword",
			"ONCDWD",
			"Begin the activity on receipt of codeword.");
	public static final ActionTaskStartQualifierCode TO_BE_DETERMINED = new ActionTaskStartQualifierCode(
			"To be determined",
			"TBD",
			"Time intended is to be determined later.");
	public static final ActionTaskStartQualifierCode UNKNOWN = new ActionTaskStartQualifierCode(
			"Unknown",
			"UNK",
			"Time intended is not known.");

	private ActionTaskStartQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
