/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkServiceSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a detailed type of service that a specific NETWORK is intended to provide.";
	}

	private static HashMap<String, NetworkServiceSubcategoryCode> physicalToCode = new HashMap<String, NetworkServiceSubcategoryCode>();

	public static NetworkServiceSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkServiceSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkServiceSubcategoryCode DIRECTORY = new NetworkServiceSubcategoryCode(
			"Directory",
			"DRCTRY",
			"A service provided through capabilities used by OSI applications, OSI management processes, other OSI layer entities, and telecommunication services, providing a dynamic \"name-to-address mapping\".");
	public static final NetworkServiceSubcategoryCode ELECTRONIC_MAIL = new NetworkServiceSubcategoryCode(
			"Electronic mail",
			"EMAIL",
			"A communications service that provides correspondence in the form of messages transmitted between user terminals over a network.");
	public static final NetworkServiceSubcategoryCode FILE_TRANSFER_PROTOCOL = new NetworkServiceSubcategoryCode(
			"File transfer protocol",
			"FTP",
			"A service that provides the basic elements of file sharing between hosts.");
	public static final NetworkServiceSubcategoryCode HYPERTEXT_TRANSFER_PROTOCOL = new NetworkServiceSubcategoryCode(
			"Hypertext transfer protocol",
			"HTTP",
			"A service provided through Hypertext Transfer Protocol (HTTP) that is an application-level protocol with the lightness and speed necessary for distributed, collaborative, hypermedia information systems.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_1 = new NetworkServiceSubcategoryCode(
			"IFF mode 1",
			"IFFM1",
			"A service that provides the data for IFF mode 1.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_2 = new NetworkServiceSubcategoryCode(
			"IFF mode 2",
			"IFFM2",
			"A service that provides the data for IFF mode 2.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_3 = new NetworkServiceSubcategoryCode(
			"IFF mode 3",
			"IFFM3",
			"A service that provides the data for IFF mode 3.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_3A = new NetworkServiceSubcategoryCode(
			"IFF mode 3A",
			"IFFM3A",
			"A service that provides the data for IFF mode 3A.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_4 = new NetworkServiceSubcategoryCode(
			"IFF mode 4",
			"IFFM4",
			"A service that provides the data for IFF mode 4.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_5 = new NetworkServiceSubcategoryCode(
			"IFF mode 5",
			"IFFM5",
			"A service that provides the data for IFF mode 5.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_C = new NetworkServiceSubcategoryCode(
			"IFF mode C",
			"IFFMC",
			"A service that provides the data for IFF mode C.");
	public static final NetworkServiceSubcategoryCode IFF_MODE_S = new NetworkServiceSubcategoryCode(
			"IFF mode S",
			"IFFMS",
			"A service that provides the data for IFF mode S.");
	public static final NetworkServiceSubcategoryCode LINK_1 = new NetworkServiceSubcategoryCode(
			"Link 1",
			"LNK1",
			"A service that provides the basic elements for the transmission of specific message of Link 1.");
	public static final NetworkServiceSubcategoryCode LINK_11 = new NetworkServiceSubcategoryCode(
			"Link 11",
			"LNK11",
			"A service that provides the basic elements for the transmission of specific message of Link 11.");
	public static final NetworkServiceSubcategoryCode LINK_11B = new NetworkServiceSubcategoryCode(
			"Link 11B",
			"LNK11B",
			"A service that provides the basic elements for the transmission of specific message of Link 11B.");
	public static final NetworkServiceSubcategoryCode LINK_14 = new NetworkServiceSubcategoryCode(
			"Link 14",
			"LNK14",
			"A service that provides the basic elements for the transmission of specific message of Link 14.");
	public static final NetworkServiceSubcategoryCode LINK_16_DATA = new NetworkServiceSubcategoryCode(
			"Link 16, data",
			"LNK16D",
			"A service that provides the basic elements for the transmission of data of Link 16.");
	public static final NetworkServiceSubcategoryCode LINK_16_VOICE = new NetworkServiceSubcategoryCode(
			"Link 16, voice",
			"LNK16V",
			"A service that provides the basic elements for the transmission of voice of Link 16.");
	public static final NetworkServiceSubcategoryCode LINK_22 = new NetworkServiceSubcategoryCode(
			"Link 22",
			"LNK22",
			"A service that provides the basic elements for the transmission of specific message of Link 22.");
	public static final NetworkServiceSubcategoryCode LINK_4 = new NetworkServiceSubcategoryCode(
			"Link 4",
			"LNK4",
			"A service that provides the basic elements for the transmission of specific message of Link 4.");
	public static final NetworkServiceSubcategoryCode MCI_MODE_1 = new NetworkServiceSubcategoryCode(
			"MCI Mode 1",
			"MCIMD1",
			"MCI gateway service proving DEM and MEM facilities.");
	public static final NetworkServiceSubcategoryCode MCI_MODE_2 = new NetworkServiceSubcategoryCode(
			"MCI Mode 2",
			"MCIMD2",
			"MCI gateway service proving MEM facilities.");
	public static final NetworkServiceSubcategoryCode MCI_MODE_3 = new NetworkServiceSubcategoryCode(
			"MCI Mode 3",
			"MCIMD3",
			"MCI gateway service proving DEM facilities.");
	public static final NetworkServiceSubcategoryCode MOBILE_PHONE = new NetworkServiceSubcategoryCode(
			"Mobile phone",
			"MOBILE",
			"A service that provides communication services to a non-fixed device.");
	public static final NetworkServiceSubcategoryCode NOT_OTHERWISE_SPECIFIED = new NetworkServiceSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkServiceSubcategoryCode PAGER = new NetworkServiceSubcategoryCode(
			"Pager",
			"PAGER",
			"A communications service making use of a small radio device which bleeps or vibrates to inform the wearer that someone wishes to contact them or that it has received a short text message.");
	public static final NetworkServiceSubcategoryCode REMOTE_ACCESS = new NetworkServiceSubcategoryCode(
			"Remote access",
			"RMTACC",
			"A service that enable the operation of a remote node from a local node.");
	public static final NetworkServiceSubcategoryCode TELEPHONE = new NetworkServiceSubcategoryCode(
			"Telephone",
			"TELEPH",
			"A service that provides communication services to a fixed device.");
	public static final NetworkServiceSubcategoryCode TELEX = new NetworkServiceSubcategoryCode(
			"Telex",
			"TELEX",
			"A communications service using a system consisting of teletypewriters connected to a telephonic network to send and receive signals.");
	public static final NetworkServiceSubcategoryCode TELNET = new NetworkServiceSubcategoryCode(
			"Telnet",
			"TELNET",
			"A service using the terminal emulation protocol of TCP/IP. Options give TELNET the ability to transfer binary data, support byte macros, emulate graphics terminals, and convey information to support centralised terminal management.");

	private NetworkServiceSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
