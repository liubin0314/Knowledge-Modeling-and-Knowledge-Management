/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionAircraftEmploymentDeplanementMethodCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the standard method of deplanement of a specific ACTION-RESOURCE in support of a specific ACTION.";
	}

	private static HashMap<String, ActionAircraftEmploymentDeplanementMethodCode> physicalToCode = new HashMap<String, ActionAircraftEmploymentDeplanementMethodCode>();

	public static ActionAircraftEmploymentDeplanementMethodCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionAircraftEmploymentDeplanementMethodCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionAircraftEmploymentDeplanementMethodCode ABSEIL = new ActionAircraftEmploymentDeplanementMethodCode(
			"Abseil",
			"ABSEIL",
			"To deplane using rappelling equipment while the aircraft is airborne.");
	public static final ActionAircraftEmploymentDeplanementMethodCode GRAVITY = new ActionAircraftEmploymentDeplanementMethodCode(
			"Gravity",
			"GRAVTY",
			"To deplane cargo without a parachute from the aircraft while it is airborne by gravitational force.");
	public static final ActionAircraftEmploymentDeplanementMethodCode HOVER = new ActionAircraftEmploymentDeplanementMethodCode(
			"Hover",
			"HOVER",
			"To deplane without any mechanical means from an aircraft hovering close to the ground.");
	public static final ActionAircraftEmploymentDeplanementMethodCode LAND = new ActionAircraftEmploymentDeplanementMethodCode(
			"Land",
			"LAND",
			"To deplane without any mechanical means from a landed aircraft.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARACHUTE_AUTOMATIC = new ActionAircraftEmploymentDeplanementMethodCode(
			"Parachute, automatic",
			"PARAUT",
			"To deplane from the aircraft while it is airborne with a parachute that will unfold itself automatically after leaving the aircraft.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARACHUTE = new ActionAircraftEmploymentDeplanementMethodCode(
			"Parachute",
			"PARCHT",
			"To deplane by jumping out of the aircraft while it is airborne and deploy a parachute before reaching the ground.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARACHUTE_EXTRACTION = new ActionAircraftEmploymentDeplanementMethodCode(
			"Parachute, extraction",
			"PAREXT",
			"To deplane from the aircraft while it is airborne with a parachute that will pull the cargo out of the aircraft, and then unfold the main parachute.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARAGLIDER = new ActionAircraftEmploymentDeplanementMethodCode(
			"Paraglider",
			"PARGLD",
			"To deplane by jumping out of the aircraft while it is airborne and deploy a paraglider before reaching the ground.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARACHUTE_LOW_ALTITUDE_EXTRACTION = new ActionAircraftEmploymentDeplanementMethodCode(
			"Parachute, low altitude extraction",
			"PARLAE",
			"To deplane from the aircraft while it is airborne with a parachute that will pull the cargo out of the aircraft.");
	public static final ActionAircraftEmploymentDeplanementMethodCode PARACHUTE_MANUAL = new ActionAircraftEmploymentDeplanementMethodCode(
			"Parachute, manual",
			"PARMAN",
			"To deplane by jumping out of the aircraft while it is airborne and manually deploy a parachute before reaching the ground.");
	public static final ActionAircraftEmploymentDeplanementMethodCode ROPE = new ActionAircraftEmploymentDeplanementMethodCode(
			"Rope",
			"ROPE",
			"To deplane using a rope while the aircraft is airborne.");
	public static final ActionAircraftEmploymentDeplanementMethodCode WEDGE = new ActionAircraftEmploymentDeplanementMethodCode(
			"Wedge",
			"WEDGE",
			"To deplane cargo from the aircraft by dropping it, using a wedge system.");
	public static final ActionAircraftEmploymentDeplanementMethodCode WINCH = new ActionAircraftEmploymentDeplanementMethodCode(
			"Winch",
			"WINCH",
			"To deplane by using a winch-operated cable while the aircraft is airborne.");

	private ActionAircraftEmploymentDeplanementMethodCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
