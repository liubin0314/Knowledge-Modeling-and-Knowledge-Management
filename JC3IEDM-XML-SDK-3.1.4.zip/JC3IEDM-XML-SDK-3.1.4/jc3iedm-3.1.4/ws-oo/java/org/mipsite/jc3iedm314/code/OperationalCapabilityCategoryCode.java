/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OperationalCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies a particular OPERATIONAL-CAPABILITY.";
	}

	private static HashMap<String, OperationalCapabilityCategoryCode> physicalToCode = new HashMap<String, OperationalCapabilityCategoryCode>();

	public static OperationalCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OperationalCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OperationalCapabilityCategoryCode AIRBORNE = new OperationalCapabilityCategoryCode(
			"Airborne",
			"AIRBRN",
			"The capability to carry out operations, either by paradrop or air landing, following an air movement.");
	public static final OperationalCapabilityCategoryCode AIR_DEFENCE = new OperationalCapabilityCategoryCode(
			"Air defence",
			"AIRDEF",
			"The capability to nullify or reduce the effectiveness of hostile air action.");
	public static final OperationalCapabilityCategoryCode AIR_TO_GROUND = new OperationalCapabilityCategoryCode(
			"Air to ground",
			"AIRGRD",
			"The capability to perform air to ground operations.");
	public static final OperationalCapabilityCategoryCode AIR_INTERDICTION = new OperationalCapabilityCategoryCode(
			"Air interdiction",
			"AIRINT",
			"Air operations conducted to destroy, neutralize, or delay the enemy's military potential before it can be brought to bear effectively against friendly forces at such distance from friendly forces that detailed integration of each air mission with the fire and movement of friendly forces is not required.");
	public static final OperationalCapabilityCategoryCode AMPHIBIOUS = new OperationalCapabilityCategoryCode(
			"Amphibious",
			"AMPH",
			"The capability to conduct an operation launched from the sea by military forces against a hostile or potentially hostile shore.");
	public static final OperationalCapabilityCategoryCode ANTI_SUBMARINE_WARFARE = new OperationalCapabilityCategoryCode(
			"Anti-submarine warfare",
			"ANTSUB",
			"Operations conducted with the intention of denying the enemy the effective use of his submarines.");
	public static final OperationalCapabilityCategoryCode AIR_ASSAULT = new OperationalCapabilityCategoryCode(
			"Air assault",
			"ARASLT",
			"The capability to perform a mission involving total integration of helicopter assets in their ground or air roles.");
	public static final OperationalCapabilityCategoryCode ARCTIC = new OperationalCapabilityCategoryCode(
			"Arctic",
			"ARC",
			"The capability to perform a mission involving an arctic operation.");
	public static final OperationalCapabilityCategoryCode AERIAL_REFUELLING = new OperationalCapabilityCategoryCode(
			"Aerial refuelling",
			"ARLRFL",
			"The capability to refuel aircraft in flight, which extends presence, increases range, and serves as a force multiplier.");
	public static final OperationalCapabilityCategoryCode ARTILLERY_SURVEY = new OperationalCapabilityCategoryCode(
			"Artillery survey",
			"ARTYSV",
			"The capability to calculate the coordinates and the altitude of an object/point and from which the bearings/azimuths to a number of reference objects are also known.");
	public static final OperationalCapabilityCategoryCode ATTACK = new OperationalCapabilityCategoryCode(
			"Attack",
			"ATTACK",
			"The capability to perform an offensive mission.");
	public static final OperationalCapabilityCategoryCode NBC_BIOLOGICAL = new OperationalCapabilityCategoryCode(
			"NBC, biological",
			"BIOMAT",
			"The capability to employ biological materiel to produce casualties in man or animals and damage to plants or materiel; or defence against such employment.");
	public static final OperationalCapabilityCategoryCode C2 = new OperationalCapabilityCategoryCode(
			"C2",
			"C2",
			"The capability to exercise the authority, responsibilities and activities of military commanders in direction and co-ordination or military forces and the implementation of orders related to the execution of operations.");
	public static final OperationalCapabilityCategoryCode CLOSE_AIR_SUPPORT = new OperationalCapabilityCategoryCode(
			"Close air support",
			"CAS",
			"The capability to perform an air action against hostile targets which are in close proximity to friendly forces and which require detailed integration of each air mission with the fire and movement of those forces.");
	public static final OperationalCapabilityCategoryCode NBC_DECONTAMINATION = new OperationalCapabilityCategoryCode(
			"NBC, decontamination",
			"CBRNDC",
			"The capability to make any person, object, or area safe by absorbing, destroying, neutralizing, making harmless, or removing, chemical or biological materiel, or by removing radioactive material clinging to or around it.");
	public static final OperationalCapabilityCategoryCode NBC_CHEMICAL_DECONTAMINATION = new OperationalCapabilityCategoryCode(
			"NBC, chemical decontamination",
			"CHMDEC",
			"The capability to make any person, object, or area safe by absorbing, destroying, neutralizing, making harmless, or removing, chemical materiel.");
	public static final OperationalCapabilityCategoryCode NBC_CHEMICAL = new OperationalCapabilityCategoryCode(
			"NBC, chemical",
			"CHMMAT",
			"The capability to employ chemical materiel to kill, injure, or incapacitate for a significant period of time, man or animals, and deny or hinder the use of areas, facilities or materiel; or defence against such employment.");
	public static final OperationalCapabilityCategoryCode NBC_CHEMICAL_SMOKE = new OperationalCapabilityCategoryCode(
			"NBC, chemical, smoke",
			"CHMSMK",
			"The capability to employ chemical materiel released as a cloud of smoke or defence against such employment.");
	public static final OperationalCapabilityCategoryCode CIVILIAN_LAW_ENFORCEMENT = new OperationalCapabilityCategoryCode(
			"Civilian law enforcement",
			"CIVLWE",
			"The capability to conduct civilian law enforcement operations.");
	public static final OperationalCapabilityCategoryCode COMMAND_OPERATIONS = new OperationalCapabilityCategoryCode(
			"Command operations",
			"CMDOPS",
			"No definition provided in APP-6A.");
	public static final OperationalCapabilityCategoryCode COUNTER_INTELLIGENCE = new OperationalCapabilityCategoryCode(
			"Counter intelligence",
			"CNTRIN",
			"The capability to conduct activities that are concerned with identifying and counteracting the threat to security posed by hostile intelligence services or organisations, or by individuals engaged in espionage, sabotage, subversion or terrorism.");
	public static final OperationalCapabilityCategoryCode CENTRAL_INTELLIGENCE = new OperationalCapabilityCategoryCode(
			"Central intelligence",
			"CTRINT",
			"No definition provided in APP-6A.");
	public static final OperationalCapabilityCategoryCode ELECTRONIC_RANGING = new OperationalCapabilityCategoryCode(
			"Electronic ranging",
			"ELCRNG",
			"The capability to establish target distance electronically.");
	public static final OperationalCapabilityCategoryCode ENGINEER_COMBAT = new OperationalCapabilityCategoryCode(
			"Engineer, combat",
			"ENGCBT",
			"The capability to perform engineer functions in direct support of combat operations.");
	public static final OperationalCapabilityCategoryCode ENGINEER_CONSTRUCTION = new OperationalCapabilityCategoryCode(
			"Engineer, construction",
			"ENGCN",
			"The capability to build various facilities in direct support of military operations.");
	public static final OperationalCapabilityCategoryCode ENGINEER_CONSTRUCTION_NAVAL = new OperationalCapabilityCategoryCode(
			"Engineer, construction naval",
			"ENGCNN",
			"The capability to build various facilities in direct support of naval operations.");
	public static final OperationalCapabilityCategoryCode ELECTRONIC_WARFARE = new OperationalCapabilityCategoryCode(
			"Electronic warfare",
			"EW",
			"The capability involving the use of electromagnetic energy to determine, exploit, reduce, or prevent hostile use of the electromagnetic spectrum and action to retain its effective use by friendly forces.");
	public static final OperationalCapabilityCategoryCode ELECTRONIC_WARFARE_DIRECTION_FINDING = new OperationalCapabilityCategoryCode(
			"Electronic warfare, direction finding",
			"EWDF",
			"The capability for obtaining bearings of radio frequency emitters by using a directional antenna and a display unit on an intercept receiver or ancillary equipment.");
	public static final OperationalCapabilityCategoryCode ELECTRONIC_WARFARE_INTERCEPT = new OperationalCapabilityCategoryCode(
			"Electronic warfare, intercept",
			"EWINTC",
			"The capability to intercept intentional or unintentional radiated electromagnetic energy for the purpose of immediate threat recognition.");
	public static final OperationalCapabilityCategoryCode ELECTRONIC_WARFARE_JAMMING = new OperationalCapabilityCategoryCode(
			"Electronic warfare, jamming",
			"EWJAM",
			"The capability to deliver radiation, re-radiation or reflection of electromagnetic energy with the object of impairing the use of electronic devices, equipment or systems being used by an enemy.");
	public static final OperationalCapabilityCategoryCode FINANCE = new OperationalCapabilityCategoryCode(
			"Finance",
			"FINANC",
			"The capability to provide financial advice and guidance, support for the procurement process, providing pay and disbursing support.");
	public static final OperationalCapabilityCategoryCode INTERROGATION = new OperationalCapabilityCategoryCode(
			"Interrogation",
			"INTERO",
			"The capability to procure information by direct questioning of a person under the control of a questioner.");
	public static final OperationalCapabilityCategoryCode JOINT_INTELLIGENCE = new OperationalCapabilityCategoryCode(
			"Joint intelligence",
			"JNTINT",
			"The capability to produce intelligence from elements of more than one Service.");
	public static final OperationalCapabilityCategoryCode LABOUR = new OperationalCapabilityCategoryCode(
			"Labour",
			"LABOUR",
			"The capability to provide labour services.");
	public static final OperationalCapabilityCategoryCode LEGAL = new OperationalCapabilityCategoryCode(
			"Legal",
			"LEGAL",
			"The capability to provide legal services.");
	public static final OperationalCapabilityCategoryCode MAINTENANCE = new OperationalCapabilityCategoryCode(
			"Maintenance",
			"MAINT",
			"The capability to provide supply and repair services to keep a force in condition to carry out its mission.");
	public static final OperationalCapabilityCategoryCode MARINE = new OperationalCapabilityCategoryCode(
			"Marine",
			"MARINE",
			"The capability to perform maritime/littoral operations.");
	public static final OperationalCapabilityCategoryCode MARITIME = new OperationalCapabilityCategoryCode(
			"Maritime",
			"MARTME",
			"The capability to perform maritime/deep water operations.");
	public static final OperationalCapabilityCategoryCode MINE_COUNTERMEASURE = new OperationalCapabilityCategoryCode(
			"Mine countermeasure",
			"MCM",
			"The capability to prevent or reduce damage or danger from mines.");
	public static final OperationalCapabilityCategoryCode MEDICAL_EVACUATION = new OperationalCapabilityCategoryCode(
			"Medical evacuation",
			"MEDEVC",
			"The capability for timely and efficient movement of patients while providing en route medical care to and between medical treatment facilities.");
	public static final OperationalCapabilityCategoryCode MILITARY_INTELLIGENCE_AERIAL_EXPLOITATION = new OperationalCapabilityCategoryCode(
			"Military intelligence, aerial exploitation",
			"MIAREX",
			"No definition provided in APP-6A.");
	public static final OperationalCapabilityCategoryCode MILITARY_INTELLIGENCE_OPERATION = new OperationalCapabilityCategoryCode(
			"Military intelligence, operation",
			"MIOPS",
			"The capability to provide information required for the planning and conducting campaigns and major operations to accomplish strategic objectives within theatres or areas of operations.");
	public static final OperationalCapabilityCategoryCode MILITARY_INTELLIGENCE_TACTICAL_EXPLOITATION = new OperationalCapabilityCategoryCode(
			"Military intelligence, tactical exploitation",
			"MITCEX",
			"The capability to use information required for the planning and conducting tactical operations.");
	public static final OperationalCapabilityCategoryCode MAINTENANCE_ELECTRO_OPTICAL = new OperationalCapabilityCategoryCode(
			"Maintenance, electro-optical",
			"MNTELO",
			"The capability to maintain electro-optical materiel in or to restore it to a specified condition.");
	public static final OperationalCapabilityCategoryCode MAINTENANCE_ORDNANCE = new OperationalCapabilityCategoryCode(
			"Maintenance, ordnance",
			"MNTOD",
			"The capability to maintain ordnance (ammunition) in or to restore it to a specified condition.");
	public static final OperationalCapabilityCategoryCode MAINTENANCE_ORDNANCE_MISSILE = new OperationalCapabilityCategoryCode(
			"Maintenance, ordnance missile",
			"MNTODM",
			"The capability to maintain ordnance missile (materiel) in or to restore it to a specified condition.");
	public static final OperationalCapabilityCategoryCode MOUNTAIN = new OperationalCapabilityCategoryCode(
			"Mountain",
			"MOUNTN",
			"The capability to conduct military operations in mountainous areas.");
	public static final OperationalCapabilityCategoryCode MORTUARY_GRAVES_REGISTRY = new OperationalCapabilityCategoryCode(
			"Mortuary/graves registry",
			"MRTGRR",
			"The capability to provide care and disposition of deceased personnel.");
	public static final OperationalCapabilityCategoryCode MORALE_WELFARE_RECREATION = new OperationalCapabilityCategoryCode(
			"Morale, welfare recreation",
			"MWR",
			"The capability to provide morale, welfare and recreation services in support of military personnel.");
	public static final OperationalCapabilityCategoryCode NBC_NUCLEAR = new OperationalCapabilityCategoryCode(
			"NBC, nuclear",
			"NUCMAT",
			"No definition provided in APP-6A.");
	public static final OperationalCapabilityCategoryCode PERSONNEL_SERVICES = new OperationalCapabilityCategoryCode(
			"Personnel services",
			"PERSVC",
			"The capability to provide the support services needed by military and civilian personnel.");
	public static final OperationalCapabilityCategoryCode PEACE_SUPPORT = new OperationalCapabilityCategoryCode(
			"Peace support",
			"PSO",
			"The capability to conduct multi-functional operations involving military forces and diplomatic and humanitarian agencies. The operations are designed to achieve humanitarian goals or a long term peace settlement.");
	public static final OperationalCapabilityCategoryCode PUBLIC_AFFAIRS = new OperationalCapabilityCategoryCode(
			"Public affairs",
			"PUBAF",
			"The capability to provide those public information, command information, and community relations activities directed towards the general public.");
	public static final OperationalCapabilityCategoryCode PUBLIC_AFFAIRS_BROADCAST = new OperationalCapabilityCategoryCode(
			"Public affairs, broadcast",
			"PUBAFB",
			"The capability to provide those public information, command information, and community relation activities over a broadcast medium, such as radio or TV, directed towards the general public.");
	public static final OperationalCapabilityCategoryCode PUBLIC_AFFAIRS_JOINT_INFORMATION = new OperationalCapabilityCategoryCode(
			"Public affairs, joint information",
			"PUBAFJ",
			"The capability to provide those public information, command information, and community relations activities directed towards the general public in a joint services environment.");
	public static final OperationalCapabilityCategoryCode NBC_RADIOLOGICAL = new OperationalCapabilityCategoryCode(
			"NBC, radiological",
			"RADMAT",
			"The capability to employ radiological materiel to produce casualties in man or animals and damage to plants or materiel; or defence against such employment.");
	public static final OperationalCapabilityCategoryCode RAILWAY = new OperationalCapabilityCategoryCode(
			"Railway",
			"RAILWY",
			"The capability to provide rail services.");
	public static final OperationalCapabilityCategoryCode RECONNAISSANCE = new OperationalCapabilityCategoryCode(
			"Reconnaissance",
			"RECCE",
			"The capability to obtain, by visual observation or other detection methods, information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographical, or geographic characteristics of a particular area.");
	public static final OperationalCapabilityCategoryCode RECOVERY = new OperationalCapabilityCategoryCode(
			"Recovery",
			"RECVRY",
			"The capability to contact, protect and extract personnel, small groups or units, or materiel.");
	public static final OperationalCapabilityCategoryCode REPLACEMENT_HOLDING = new OperationalCapabilityCategoryCode(
			"Replacement holding",
			"REPLHO",
			"The capability to provide personnel to take the place of other personnel who depart a unit.");
	public static final OperationalCapabilityCategoryCode SEARCH_AND_RESCUE = new OperationalCapabilityCategoryCode(
			"Search and rescue",
			"SAR",
			"The capability to use aircraft, surface craft, submarines, specialised rescue teams, and equipment to search for and rescue personnel in distress on land or sea.");
	public static final OperationalCapabilityCategoryCode SCOUT = new OperationalCapabilityCategoryCode(
			"Scout",
			"SCOUT",
			"The capability to move out ahead of the main force in order to reconnoitre the position or movements of the enemy.");
	public static final OperationalCapabilityCategoryCode SIGNAL_FORWARD_COMMUNICATIONS = new OperationalCapabilityCategoryCode(
			"Signal, forward communications",
			"SGFC",
			"The capability to provide tactical communications in the combat zone.");
	public static final OperationalCapabilityCategoryCode SIGNAL_NODE_CENTRE = new OperationalCapabilityCategoryCode(
			"Signal, node centre",
			"SGNC",
			"The capability in signal services to manage, operate and control a communications node centre.");
	public static final OperationalCapabilityCategoryCode SIGNAL_NODE_LARGE_EXTENSION = new OperationalCapabilityCategoryCode(
			"Signal, node, large extension",
			"SGNLE",
			"The capability in signal services to manage, operate and control a communications large extension node.");
	public static final OperationalCapabilityCategoryCode SIGNAL_NODE_SMALL_EXTENSION = new OperationalCapabilityCategoryCode(
			"Signal, node, small extension",
			"SGNSE",
			"The capability in signal services to manage, operate and control a communications small extension node.");
	public static final OperationalCapabilityCategoryCode SIGNAL_RADIO_RELAY = new OperationalCapabilityCategoryCode(
			"Signal, radio relay",
			"SGRDRL",
			"The capability in signal services to manage, operate and control a communications radio relay.");
	public static final OperationalCapabilityCategoryCode SIGNAL_RADIO_TACTICAL_SATELLITE = new OperationalCapabilityCategoryCode(
			"Signal, radio tactical satellite",
			"SGRDTA",
			"The capability in signal services to manage, operate and control a tactical satellite terminal.");
	public static final OperationalCapabilityCategoryCode SIGNAL_RADIO_TELETYPE = new OperationalCapabilityCategoryCode(
			"Signal, radio teletype",
			"SGRDTE",
			"The capability in signal services to manage, operate and control a radio teletype communications.");
	public static final OperationalCapabilityCategoryCode SIGNAL_SUPPORT = new OperationalCapabilityCategoryCode(
			"Signal, support",
			"SGSPT",
			"The capability to provide personnel and equipment from other forces for the establishment of a special or supplementary communications system.");
	public static final OperationalCapabilityCategoryCode SIGNALS_INTELLIGENCE_SIGINT = new OperationalCapabilityCategoryCode(
			"Signals intelligence (SIGINT)",
			"SIGINT",
			"The capability to provide intelligence derived from communications, electronics, and instrumentation signals.");
	public static final OperationalCapabilityCategoryCode SIGNAL_RADIO = new OperationalCapabilityCategoryCode(
			"Signal, radio",
			"SIGRAD",
			"The capability in signal services to manage, operate and control a radio communications.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_I = new OperationalCapabilityCategoryCode(
			"Supply (class I)",
			"SPLC1",
			"The capability to provide combat/fresh rations, water and personal, health and welfare items.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_II = new OperationalCapabilityCategoryCode(
			"Supply (class II)",
			"SPLC2",
			"The capability to provide materiel.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_III = new OperationalCapabilityCategoryCode(
			"Supply (class III)",
			"SPLC3",
			"The capability to provide fuel and lubricants.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_III_AVIATION = new OperationalCapabilityCategoryCode(
			"Supply (class III aviation)",
			"SPLC3A",
			"The capability to provide aviation fuel and lubricants.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_IV = new OperationalCapabilityCategoryCode(
			"Supply (class IV)",
			"SPLC4",
			"The capability to provide construction materials.");
	public static final OperationalCapabilityCategoryCode SUPPLY_CLASS_V = new OperationalCapabilityCategoryCode(
			"Supply (class V)",
			"SPLC5",
			"The capability to provide ammunition, explosives and chemical agents.");
	public static final OperationalCapabilityCategoryCode SUPPLY_LAUNDRY_BATH = new OperationalCapabilityCategoryCode(
			"Supply, laundry/bath",
			"SPLLDB",
			"The capability to provide laundry and/or bath services.");
	public static final OperationalCapabilityCategoryCode SUPPLY_WATER = new OperationalCapabilityCategoryCode(
			"Supply (water)",
			"SPLWAT",
			"The capability to provide drinking water.");
	public static final OperationalCapabilityCategoryCode SURVEILLANCE = new OperationalCapabilityCategoryCode(
			"Surveillance",
			"SRV",
			"The capability to perform systematic observation of aerospace, surface or subsurface areas, places, persons, or things by visual, aural, electronic, photographic, or other means.");
	public static final OperationalCapabilityCategoryCode SURVEILLANCE_GROUND_MODULE = new OperationalCapabilityCategoryCode(
			"Surveillance, ground module",
			"SRVGM",
			"The capability to manage and operate a ground module for a surveillance system.");
	public static final OperationalCapabilityCategoryCode SURVEILLANCE_LONG_RANGE = new OperationalCapabilityCategoryCode(
			"Surveillance, long range",
			"SRVLR",
			"The capability to perform, from long range, systematic observation of aerospace, surface or subsurface areas, places, persons, or things by visual, aural, electronic, photographic, or other means from a ground station.");
	public static final OperationalCapabilityCategoryCode SURVEILLANCE_METEOROLOGICAL = new OperationalCapabilityCategoryCode(
			"Surveillance, meteorological",
			"SRVMET",
			"The capability to perform systematic observation of meteorological conditions.");
	public static final OperationalCapabilityCategoryCode SURVEILLANCE_SENSOR = new OperationalCapabilityCategoryCode(
			"Surveillance, sensor",
			"SRVSEN",
			"The capability to manage, operate and maintain sensor surveillance assets.");
	public static final OperationalCapabilityCategoryCode TACTICAL_AIR_RECONNAISSANCE = new OperationalCapabilityCategoryCode(
			"Tactical air reconnaissance",
			"TAIRRE",
			"The capability to use of air vehicles to obtain information concerning terrain, weather, and the disposition, composition, movement, installations, lines of communications, electronic and communication emissions of enemy forces. Also included are artillery and naval gunfire adjustment, and systematic and random observation of ground battle areas, targets, and/ or sectors of airspace.");
	public static final OperationalCapabilityCategoryCode TARGET_ACQUISITION = new OperationalCapabilityCategoryCode(
			"Target acquisition",
			"TGT",
			"The capability to manage, operate and maintain target acquisition assets.");
	public static final OperationalCapabilityCategoryCode TARGET_ACQUISITION_FLASH = new OperationalCapabilityCategoryCode(
			"Target acquisition, flash",
			"TGTAFL",
			"The capability to manage, operate and maintain flash target acquisition assets.");
	public static final OperationalCapabilityCategoryCode TARGET_ACQUISITION_RADAR = new OperationalCapabilityCategoryCode(
			"Target acquisition, radar",
			"TGTARD",
			"The capability to manage, operate and maintain radar target acquisition assets.");
	public static final OperationalCapabilityCategoryCode TARGET_ACQUISITION_SOUND = new OperationalCapabilityCategoryCode(
			"Target acquisition, sound",
			"TGTASD",
			"The capability to manage, operate and maintain sound target acquisition assets.");
	public static final OperationalCapabilityCategoryCode TARGETING = new OperationalCapabilityCategoryCode(
			"Targeting",
			"TGTNG",
			"The capability to provide targeting services.");
	public static final OperationalCapabilityCategoryCode THEATRE_MISSILE_DEFENCE = new OperationalCapabilityCategoryCode(
			"Theatre missile defence",
			"THTMSD",
			"The capability to manage, operate and maintain theatre missile defence assets.");
	public static final OperationalCapabilityCategoryCode TRAINING = new OperationalCapabilityCategoryCode(
			"Training",
			"TRAIN",
			"A capability that enables an equipment to be used to train personnel.");
	public static final OperationalCapabilityCategoryCode TRANSPORTATION_APOD_APOE = new OperationalCapabilityCategoryCode(
			"Transportation, APOD/APOE",
			"TRNAPD",
			"The capability to provide transportation services at aerial ports where cargo or personnel arrive or depart.");
	public static final OperationalCapabilityCategoryCode TRANSPORTATION_MISSILE = new OperationalCapabilityCategoryCode(
			"Transportation, missile",
			"TRNMSL",
			"The capability to provide equipment for transportation of missiles.");
	public static final OperationalCapabilityCategoryCode TRANSPORTATION_MOVEMENT_CONTROL = new OperationalCapabilityCategoryCode(
			"Transportation, movement control",
			"TRNMVC",
			"The capability to provide planning, routing, scheduling and control of personnel and freight movements over lines of communication.");
	public static final OperationalCapabilityCategoryCode TRANSPORTATION_SPOD_SPOE = new OperationalCapabilityCategoryCode(
			"Transportation, SPOD/SPOE",
			"TRNSPD",
			"The capability to provide transportation services at seaports where cargo or personnel arrive or depart.");
	public static final OperationalCapabilityCategoryCode UTILITY = new OperationalCapabilityCategoryCode(
			"Utility",
			"UTILTY",
			"The capability to provide utilities (water, gas, electric, et al).");
	public static final OperationalCapabilityCategoryCode WATER_PURIFICATION = new OperationalCapabilityCategoryCode(
			"Water purification",
			"WATER",
			"The capability to provide clean potable drinking/bathing water.");

	private OperationalCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
