/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourFireFightingCapabilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of fire fighting capability available at a specific HARBOUR.";
	}

	private static HashMap<String, HarbourFireFightingCapabilityCode> physicalToCode = new HashMap<String, HarbourFireFightingCapabilityCode>();

	public static HarbourFireFightingCapabilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourFireFightingCapabilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourFireFightingCapabilityCode AFLOAT = new HarbourFireFightingCapabilityCode(
			"Afloat",
			"AFLOAT",
			"Fire fighting assets are located onboard vessels that may or may not be specifically fitted for a fire-fighting role.");
	public static final HarbourFireFightingCapabilityCode ASHORE = new HarbourFireFightingCapabilityCode(
			"Ashore",
			"ASHORE",
			"Fire fighting assets are either provided from fixed land based assets, hydrants, or mobile land based equipment, fire engines, pumps.");
	public static final HarbourFireFightingCapabilityCode NOT_OTHERWISE_SPECIFIED = new HarbourFireFightingCapabilityCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private HarbourFireFightingCapabilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
