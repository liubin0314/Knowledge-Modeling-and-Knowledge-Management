/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractCbrnEvent extends AbstractActionEvent {

	// private fields

	private CbrnEventSubcategoryCode cbrnEventSubcategoryCode; // optional
	private CbrnEventAlarmResultIndicatorCode alarmResultIndicatorCode; // optional
	private CbrnEventConfirmationTestIndicatorCode confirmationTestIndicatorCode; // optional
	private CbrnEventMaterielContainerTypeCode materielContainerTypeCode; // optional
	private CountType4 materielContainerTotalCount; // optional

	// default constructor

	public AbstractCbrnEvent() {
		// no assignment
	}

	// getter & setter methods

	public CbrnEventSubcategoryCode getCbrnEventSubcategoryCode() {
		return this.cbrnEventSubcategoryCode;
	}

	public void setCbrnEventSubcategoryCode(CbrnEventSubcategoryCode cbrnEventSubcategoryCode) {
		this.cbrnEventSubcategoryCode = cbrnEventSubcategoryCode;
	}

	public CbrnEventAlarmResultIndicatorCode getAlarmResultIndicatorCode() {
		return this.alarmResultIndicatorCode;
	}

	public void setAlarmResultIndicatorCode(CbrnEventAlarmResultIndicatorCode alarmResultIndicatorCode) {
		this.alarmResultIndicatorCode = alarmResultIndicatorCode;
	}

	public CbrnEventConfirmationTestIndicatorCode getConfirmationTestIndicatorCode() {
		return this.confirmationTestIndicatorCode;
	}

	public void setConfirmationTestIndicatorCode(CbrnEventConfirmationTestIndicatorCode confirmationTestIndicatorCode) {
		this.confirmationTestIndicatorCode = confirmationTestIndicatorCode;
	}

	public CbrnEventMaterielContainerTypeCode getMaterielContainerTypeCode() {
		return this.materielContainerTypeCode;
	}

	public void setMaterielContainerTypeCode(CbrnEventMaterielContainerTypeCode materielContainerTypeCode) {
		this.materielContainerTypeCode = materielContainerTypeCode;
	}

	public CountType4 getMaterielContainerTotalCount() {
		return this.materielContainerTotalCount;
	}

	public void setMaterielContainerTotalCount(CountType4 materielContainerTotalCount) {
		this.materielContainerTotalCount = materielContainerTotalCount;
	}
}
