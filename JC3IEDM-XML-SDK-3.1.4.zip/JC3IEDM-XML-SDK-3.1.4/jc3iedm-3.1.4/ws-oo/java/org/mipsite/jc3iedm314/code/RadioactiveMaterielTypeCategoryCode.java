/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RadioactiveMaterielTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of RADIOACTIVE-MATERIEL-TYPE.";
	}

	private static HashMap<String, RadioactiveMaterielTypeCategoryCode> physicalToCode = new HashMap<String, RadioactiveMaterielTypeCategoryCode>();

	public static RadioactiveMaterielTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RadioactiveMaterielTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RadioactiveMaterielTypeCategoryCode CESIUM_137 = new RadioactiveMaterielTypeCategoryCode(
			"Cesium-137",
			"CESIUM",
			"A radioactive isotope of the chemical element of atomic number 55, a soft, silvery, rare, extremely reactive metal of the alkali metal group.");
	public static final RadioactiveMaterielTypeCategoryCode COBALT_60 = new RadioactiveMaterielTypeCategoryCode(
			"Cobalt-60",
			"COBALT",
			"A radioactive isotope of the chemical element of atomic number 27, a hard silvery-white magnetic metal.");
	public static final RadioactiveMaterielTypeCategoryCode FRESH_REACTOR_FUEL = new RadioactiveMaterielTypeCategoryCode(
			"Fresh reactor fuel",
			"FRFUEL",
			"Nuclear reactor fuel that has not yet been used in a live nuclear reactor.");
	public static final RadioactiveMaterielTypeCategoryCode IODINE_133 = new RadioactiveMaterielTypeCategoryCode(
			"Iodine-133",
			"IODINE",
			"A radioactive isotope of the chemical element of atomic number 53, a halogen forming black crystals and a violet vapour.");
	public static final RadioactiveMaterielTypeCategoryCode NOT_KNOWN = new RadioactiveMaterielTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RadioactiveMaterielTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new RadioactiveMaterielTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RadioactiveMaterielTypeCategoryCode NUCLEAR_RELEASE_OTHER_THAN_ATTACK_ROTA = new RadioactiveMaterielTypeCategoryCode(
			"Nuclear release other than attack (ROTA)",
			"NROTA",
			"An intended or non-intended release of nuclear radiation from a non-militarily significant source or weapon.");
	public static final RadioactiveMaterielTypeCategoryCode NUCLEAR_WEAPON_FALLOUT = new RadioactiveMaterielTypeCategoryCode(
			"Nuclear weapon fallout",
			"NUCFLT",
			"Radioactive residues originating in a nuclear explosion.");
	public static final RadioactiveMaterielTypeCategoryCode PLUTONIUM_239 = new RadioactiveMaterielTypeCategoryCode(
			"Plutonium-239",
			"PLTNUM",
			"A radioactive isotope of the chemical element of atomic number 94, a dense silvery radioactive metal of the actinide series, used as a fuel in nuclear reactors and as an explosive in nuclear fission weapons.");
	public static final RadioactiveMaterielTypeCategoryCode SPENT_REACTOR_FUEL = new RadioactiveMaterielTypeCategoryCode(
			"Spent reactor fuel",
			"SPFUEL",
			"Nuclear reactor fuel that has been used in a live nuclear reactor.");
	public static final RadioactiveMaterielTypeCategoryCode TOXIC_INDUSTRIAL_MATERIAL = new RadioactiveMaterielTypeCategoryCode(
			"Toxic industrial material",
			"TOXMAT",
			"A generic term for radioactive compounds in solid, liquid, aerosolised or gaseous form. These may be used, or stored for use, for industrial, commercial, medical, military or domestic purposes.");

	private RadioactiveMaterielTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
