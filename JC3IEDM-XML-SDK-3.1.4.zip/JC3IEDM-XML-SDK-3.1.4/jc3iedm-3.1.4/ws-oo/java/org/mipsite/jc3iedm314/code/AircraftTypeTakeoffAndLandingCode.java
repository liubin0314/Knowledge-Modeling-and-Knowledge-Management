/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeTakeoffAndLandingCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the takeoff and landing designation of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeTakeoffAndLandingCode> physicalToCode = new HashMap<String, AircraftTypeTakeoffAndLandingCode>();

	public static AircraftTypeTakeoffAndLandingCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeTakeoffAndLandingCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeTakeoffAndLandingCode NOT_KNOWN = new AircraftTypeTakeoffAndLandingCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeTakeoffAndLandingCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeTakeoffAndLandingCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AircraftTypeTakeoffAndLandingCode SHORT_TAKEOFF_LANDING = new AircraftTypeTakeoffAndLandingCode(
			"Short takeoff/landing",
			"STOL",
			"An aircraft whose designation indicates it is capable of short takeoff and landing.");
	public static final AircraftTypeTakeoffAndLandingCode VERTICAL_SHORT_TAKEOFF_LANDING = new AircraftTypeTakeoffAndLandingCode(
			"Vertical short takeoff/landing",
			"VSTOL",
			"An aircraft whose designation indicates it is capable of vertical/short takeoff and landing.");
	public static final AircraftTypeTakeoffAndLandingCode VERTICAL_TAKEOFF_LANDING = new AircraftTypeTakeoffAndLandingCode(
			"Vertical takeoff/landing",
			"VTOL",
			"An aircraft whose designation indicates it is capable of vertical takeoff and landing.");

	private AircraftTypeTakeoffAndLandingCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
