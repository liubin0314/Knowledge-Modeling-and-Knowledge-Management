/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of GEOGRAPHIC-FEATURE-STATUS.";
	}

	private static HashMap<String, GeographicFeatureStatusCategoryCode> physicalToCode = new HashMap<String, GeographicFeatureStatusCategoryCode>();

	public static GeographicFeatureStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureStatusCategoryCode LIQUID_BODY_STATUS = new GeographicFeatureStatusCategoryCode(
			"LIQUID-BODY-STATUS",
			"LQDBDY",
			"A GEOGRAPHIC-FEATURE-STATUS that is a record of condition of a specific liquid body.");
	public static final GeographicFeatureStatusCategoryCode LIQUID_SURFACE_STATUS = new GeographicFeatureStatusCategoryCode(
			"LIQUID-SURFACE-STATUS",
			"LQDSRF",
			"A GEOGRAPHIC-FEATURE-STATUS that is a record of condition of a specific liquid surface.");
	public static final GeographicFeatureStatusCategoryCode SOLID_SURFACE_STATUS = new GeographicFeatureStatusCategoryCode(
			"SOLID-SURFACE-STATUS",
			"SLDSRF",
			"A GEOGRAPHIC-FEATURE-STATUS that is a record of condition of a specific solid surface.");

	private GeographicFeatureStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
