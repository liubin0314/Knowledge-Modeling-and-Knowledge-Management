/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class TargetEngagementAuthorityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of employment authorised for a specific TARGET.";
	}

	private static HashMap<String, TargetEngagementAuthorityCode> physicalToCode = new HashMap<String, TargetEngagementAuthorityCode>();

	public static TargetEngagementAuthorityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<TargetEngagementAuthorityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final TargetEngagementAuthorityCode AVAILABLE = new TargetEngagementAuthorityCode(
			"Available",
			"AVLB",
			"Authority for engagement of the target and is not a high payoff target.");
	public static final TargetEngagementAuthorityCode EXCLUDED = new TargetEngagementAuthorityCode(
			"Excluded",
			"EXCL",
			"Engagement of the target is not permitted.");
	public static final TargetEngagementAuthorityCode HIGH_PAYOFF_TARGET = new TargetEngagementAuthorityCode(
			"High payoff target",
			"HPOTGT",
			"Engagement of the target is available and is accorded the highest priority.");
	public static final TargetEngagementAuthorityCode NOT_KNOWN = new TargetEngagementAuthorityCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private TargetEngagementAuthorityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
