/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between a subject PLAN-ORDER and an object PLAN-ORDER in a specific PLAN-ORDER-ASSOCIATION.";
	}

	private static HashMap<String, PlanOrderAssociationCategoryCode> physicalToCode = new HashMap<String, PlanOrderAssociationCategoryCode>();

	public static PlanOrderAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderAssociationCategoryCode IS_AMENDED_BY = new PlanOrderAssociationCategoryCode(
			"Is amended by",
			"ISAMND",
			"The provisions of subject PLAN-ORDER are altered by the provisions of the object PLAN-ORDER. Note: One of the uses for this value is to establish a relationship between an OPORDER and a FRAGO.");
	public static final PlanOrderAssociationCategoryCode IS_DISSOCIATED_FROM = new PlanOrderAssociationCategoryCode(
			"Is dissociated from",
			"ISDTCH",
			"The relationship of the subject PLAN-ORDER with the object PLAN-ORDER is deleted.");
	public static final PlanOrderAssociationCategoryCode IS_ORDER_FOR = new PlanOrderAssociationCategoryCode(
			"Is order for",
			"ISORDR",
			"The subject PLAN-ORDER specifies additional content to make the object PLAN-ORDER into an operational order.");
	public static final PlanOrderAssociationCategoryCode IS_SUPERSEDED_BY = new PlanOrderAssociationCategoryCode(
			"Is superseded by",
			"ISSPRD",
			"The subject PLAN-ORDER is superseded by the object PLAN-ORDER in its entirety.");
	public static final PlanOrderAssociationCategoryCode IS_SUPPORTED_BY = new PlanOrderAssociationCategoryCode(
			"Is supported by",
			"ISSUPP",
			"The subject PLAN-ORDER is supported by the related object PLAN-ORDER. Note: This value is intended for a situation where an annex (such as fire support) is managed separately but is an inherent part of a plan or order.");

	private PlanOrderAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
