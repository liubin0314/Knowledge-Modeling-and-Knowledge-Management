/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryOrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MILITARY-ORGANISATION-TYPE.";
	}

	private static HashMap<String, MilitaryOrganisationTypeCategoryCode> physicalToCode = new HashMap<String, MilitaryOrganisationTypeCategoryCode>();

	public static MilitaryOrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryOrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryOrganisationTypeCategoryCode EXECUTIVE_MILITARY_ORGANISATION_TYPE = new MilitaryOrganisationTypeCategoryCode(
			"EXECUTIVE-MILITARY-ORGANISATION-TYPE",
			"EXCMIL",
			"A MILITARY-ORGANISATION-TYPE whose function is to manage and direct the military establishment.");
	public static final MilitaryOrganisationTypeCategoryCode MILITARY_POST_TYPE = new MilitaryOrganisationTypeCategoryCode(
			"MILITARY-POST-TYPE",
			"MILPST",
			"A MILITARY-ORGANISATION-TYPE with a set of duties that can be fulfilled by one person.");
	public static final MilitaryOrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new MilitaryOrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MilitaryOrganisationTypeCategoryCode TASK_FORMATION_TYPE = new MilitaryOrganisationTypeCategoryCode(
			"TASK-FORMATION-TYPE",
			"TASK",
			"An ORGANISATION-TYPE that is constituted on a temporary or semi-permanent basis for the purpose of carrying out a specific operation, mission or task.");
	public static final MilitaryOrganisationTypeCategoryCode UNIT_TYPE = new MilitaryOrganisationTypeCategoryCode(
			"UNIT-TYPE",
			"UNIT",
			"A MILITARY-ORGANISATION-TYPE whose structure is prescribed by competent authority.");

	private MilitaryOrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
