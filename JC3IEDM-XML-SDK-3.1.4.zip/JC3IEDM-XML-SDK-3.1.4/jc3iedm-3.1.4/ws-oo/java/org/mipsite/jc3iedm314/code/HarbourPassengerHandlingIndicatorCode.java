/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourPassengerHandlingIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of handling passengers.";
	}

	private static HashMap<String, HarbourPassengerHandlingIndicatorCode> physicalToCode = new HashMap<String, HarbourPassengerHandlingIndicatorCode>();

	public static HarbourPassengerHandlingIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourPassengerHandlingIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourPassengerHandlingIndicatorCode NO = new HarbourPassengerHandlingIndicatorCode(
			"No",
			"NO",
			"Passenger handling facilities are not available at the harbour.");
	public static final HarbourPassengerHandlingIndicatorCode YES = new HarbourPassengerHandlingIndicatorCode(
			"Yes",
			"YES",
			"Passenger handling facilities are available at the harbour.");

	private HarbourPassengerHandlingIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
