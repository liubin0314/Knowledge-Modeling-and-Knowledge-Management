/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEffectSeverityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the degree of seriousness of a specific ACTION-EFFECT.";
	}

	private static HashMap<String, ActionEffectSeverityCode> physicalToCode = new HashMap<String, ActionEffectSeverityCode>();

	public static ActionEffectSeverityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEffectSeverityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEffectSeverityCode MINOR_DISRUPTION = new ActionEffectSeverityCode(
			"Minor disruption",
			"MINDSR",
			"A subjective judgement by the reporting organisation that the specific ACTION resulted in minor disorder with respect to the object or class that is the focus of the ACTION-EFFECT.");
	public static final ActionEffectSeverityCode NOT_KNOWN = new ActionEffectSeverityCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionEffectSeverityCode NO_DISRUPTION = new ActionEffectSeverityCode(
			"No disruption",
			"NODSRP",
			"A subjective judgement by the reporting organisation that the specific ACTION resulted in no disorder with respect to the object or class that is the focus of the ACTION-EFFECT.");
	public static final ActionEffectSeverityCode SEVERE_DISRUPTION = new ActionEffectSeverityCode(
			"Severe disruption",
			"SEVDSR",
			"A subjective judgement by the reporting organisation that the specific ACTION resulted in severe disorder with respect to the object or class that is the focus of the ACTION-EFFECT.");
	public static final ActionEffectSeverityCode TOTAL_DISRUPTION = new ActionEffectSeverityCode(
			"Total disruption",
			"TOTDSR",
			"A subjective judgement by the reporting organisation that the specific ACTION resulted in complete disorder with respect to the object or class that is the focus of the ACTION-EFFECT.");

	private ActionEffectSeverityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
