/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTemporalAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of chronological relationship of a subject ACTION to an object ACTION for a specific ACTION-TEMPORAL-ASSOCIATION.";
	}

	private static HashMap<String, ActionTemporalAssociationCategoryCode> physicalToCode = new HashMap<String, ActionTemporalAssociationCategoryCode>();

	public static ActionTemporalAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTemporalAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTemporalAssociationCategoryCode ENDS_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Ends after end of",
			"ENDEND",
			"The subject ACTION ends after the object ACTION ends.");
	public static final ActionTemporalAssociationCategoryCode ENDS_NO_EARLIER_THAN_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Ends no earlier than after end of",
			"ENDENE",
			"The subject ACTION ends no earlier than the end of the object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode ENDS_NO_LATER_THAN_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Ends no later than after end of",
			"ENDENL",
			"The subject ACTION ends no later than the end of object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode ENDS_NO_EARLIER_THAN_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Ends no earlier than after start of",
			"ENDSNE",
			"The subject ACTION ends no earlier than the start of the object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode ENDS_NO_LATER_THAN_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Ends no later than after start of",
			"ENDSNL",
			"The subject ACTION ends no later than the start of object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode ENDS_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Ends after start of",
			"ENDSTR",
			"The subject ACTION ends after the object ACTION starts.");
	public static final ActionTemporalAssociationCategoryCode STARTS_AT_AND_ENDS_AT_THE_SAME_TIME_AS = new ActionTemporalAssociationCategoryCode(
			"Starts at and ends at the same time as",
			"SAEAST",
			"The two ACTIONs are concurrent.");
	public static final ActionTemporalAssociationCategoryCode STARTS_BEFORE_AND_ENDS_BEFORE_END_OF = new ActionTemporalAssociationCategoryCode(
			"Starts before and ends before end of",
			"SAENDO",
			"The subject ACTION begins before the object ACTION and ends before the object ACTION ends.");
	public static final ActionTemporalAssociationCategoryCode STARTS_AT_THE_SAME_TIME_AND_ENDS_AFTER = new ActionTemporalAssociationCategoryCode(
			"Starts at the same time and ends after",
			"SASTEA",
			"The subject ACTION begins concurrently with the object ACTION, but will extend beyond the object ACTION.");
	public static final ActionTemporalAssociationCategoryCode STARTS_DURING_AND_ENDS_AT_THE_SAME_TIME_AS = new ActionTemporalAssociationCategoryCode(
			"Starts during and ends at the same time as",
			"SBEAST",
			"The start of the object ACTION precedes that of the subject ACTION, but they will end concurrently.");
	public static final ActionTemporalAssociationCategoryCode STARTS_DURING_AND_ENDS_AFTER = new ActionTemporalAssociationCategoryCode(
			"Starts during and ends after",
			"SDUREA",
			"The subject ACTION is sequential but overlapping with the object ACTION.");
	public static final ActionTemporalAssociationCategoryCode STARTS_AND_ENDS_DURING = new ActionTemporalAssociationCategoryCode(
			"Starts and ends during",
			"SDUREB",
			"The subject ACTION starts after the start of object ACTION and ends before the end of object ACTION.");
	public static final ActionTemporalAssociationCategoryCode STARTS_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Starts after end of",
			"STREND",
			"The subject ACTION starts after the object ACTION ends.");
	public static final ActionTemporalAssociationCategoryCode STARTS_NO_EARLIER_THAN_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Starts no earlier than after end of",
			"STRENE",
			"The subject ACTION starts no earlier than the end of the object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode STARTS_NO_LATER_THAN_AFTER_END_OF = new ActionTemporalAssociationCategoryCode(
			"Starts no later than after end of",
			"STRENL",
			"The subject ACTION starts no later than the end of object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode STARTS_NO_EARLIER_THAN_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Starts no earlier than after start of",
			"STRSNE",
			"The subject ACTION starts no earlier than the start of the object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode STARTS_NO_LATER_THAN_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Starts no later than after start of",
			"STRSNL",
			"The subject ACTION starts no later than the start of object ACTION augmented by a fixed duration.");
	public static final ActionTemporalAssociationCategoryCode STARTS_AFTER_START_OF = new ActionTemporalAssociationCategoryCode(
			"Starts after start of",
			"STRSTR",
			"The subject ACTION starts after the object ACTION starts.");

	private ActionTemporalAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
