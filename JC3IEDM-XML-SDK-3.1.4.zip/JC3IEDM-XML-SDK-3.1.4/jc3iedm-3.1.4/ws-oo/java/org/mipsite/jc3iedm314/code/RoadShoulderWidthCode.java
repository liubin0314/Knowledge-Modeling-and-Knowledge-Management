/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RoadShoulderWidthCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the average horizontal distance measured from side to side and perpendicular to the central axis of a specific hard shoulder (lane/area beside a highway for broken-down or not running vehicles).";
	}

	private static HashMap<String, RoadShoulderWidthCode> physicalToCode = new HashMap<String, RoadShoulderWidthCode>();

	public static RoadShoulderWidthCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RoadShoulderWidthCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RoadShoulderWidthCode OVER_2M = new RoadShoulderWidthCode(
			"Over 2m",
			"1",
			"The specific hard shoulder is over 2 metres.");
	public static final RoadShoulderWidthCode _1_TO_2M = new RoadShoulderWidthCode(
			"1 to 2m",
			"2",
			"The specific hard shoulder is between 1 and 2 metres.");
	public static final RoadShoulderWidthCode UNDER_1M = new RoadShoulderWidthCode(
			"Under 1m",
			"3",
			"The specific hard shoulder is under 1 metre.");

	private RoadShoulderWidthCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
