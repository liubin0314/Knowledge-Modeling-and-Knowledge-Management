/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class StorageCapabilityConditionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of storage condition.";
	}

	private static HashMap<String, StorageCapabilityConditionCode> physicalToCode = new HashMap<String, StorageCapabilityConditionCode>();

	public static StorageCapabilityConditionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<StorageCapabilityConditionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final StorageCapabilityConditionCode CLIMATE_CONTROLLED = new StorageCapabilityConditionCode(
			"Climate controlled",
			"CC",
			"The specific STORAGE-CAPABILITY provides climate controlled conditions.");
	public static final StorageCapabilityConditionCode COVERED = new StorageCapabilityConditionCode(
			"Covered",
			"CS",
			"The specific STORAGE-CAPABILITY provides covered conditions.");
	public static final StorageCapabilityConditionCode HARDENED = new StorageCapabilityConditionCode(
			"Hardened",
			"HS",
			"The specific STORAGE-CAPABILITY provides hardened conditions.");
	public static final StorageCapabilityConditionCode OPEN = new StorageCapabilityConditionCode(
			"Open",
			"OS",
			"The specific STORAGE-CAPABILITY provides open conditions.");

	private StorageCapabilityConditionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
