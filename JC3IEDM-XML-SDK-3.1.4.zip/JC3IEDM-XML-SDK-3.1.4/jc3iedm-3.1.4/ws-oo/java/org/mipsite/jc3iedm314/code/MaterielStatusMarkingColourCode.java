/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusMarkingColourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the colour of the markings of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusMarkingColourCode> physicalToCode = new HashMap<String, MaterielStatusMarkingColourCode>();

	public static MaterielStatusMarkingColourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusMarkingColourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusMarkingColourCode BLACK = new MaterielStatusMarkingColourCode(
			"Black",
			"BLACK",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode BLUE = new MaterielStatusMarkingColourCode(
			"Blue",
			"BLUE",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode BROWN = new MaterielStatusMarkingColourCode(
			"Brown",
			"BROWN",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode GREEN = new MaterielStatusMarkingColourCode(
			"Green",
			"GREEN",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode GREY = new MaterielStatusMarkingColourCode(
			"Grey",
			"GREY",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode NOT_KNOWN = new MaterielStatusMarkingColourCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusMarkingColourCode NOT_OTHERWISE_SPECIFIED = new MaterielStatusMarkingColourCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaterielStatusMarkingColourCode ORANGE = new MaterielStatusMarkingColourCode(
			"Orange",
			"ORANGE",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode PURPLE = new MaterielStatusMarkingColourCode(
			"Purple",
			"PURPLE",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode RED = new MaterielStatusMarkingColourCode(
			"Red",
			"RED",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode SILVER = new MaterielStatusMarkingColourCode(
			"Silver",
			"SILVER",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode TAN = new MaterielStatusMarkingColourCode(
			"Tan",
			"TAN",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode WHITE = new MaterielStatusMarkingColourCode(
			"White",
			"WHITE",
			"Self defined.");
	public static final MaterielStatusMarkingColourCode YELLOW = new MaterielStatusMarkingColourCode(
			"Yellow",
			"YELLOW",
			"Self defined.");

	private MaterielStatusMarkingColourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
