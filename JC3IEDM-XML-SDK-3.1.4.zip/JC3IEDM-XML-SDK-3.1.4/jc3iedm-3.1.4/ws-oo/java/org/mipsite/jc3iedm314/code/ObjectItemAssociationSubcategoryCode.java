/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAssociationSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed type of relationship between the subject OBJECT-ITEM that is an ORGANISATION and the object OBJECT-ITEM that is an ORGANISATION in a specific OBJECT-ITEM-ASSOCIATION.";
	}

	private static HashMap<String, ObjectItemAssociationSubcategoryCode> physicalToCode = new HashMap<String, ObjectItemAssociationSubcategoryCode>();

	public static ObjectItemAssociationSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAssociationSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAssociationSubcategoryCode HAS_ADMINISTRATIVE_CONTROL_OF = new ObjectItemAssociationSubcategoryCode(
			"Has administrative control of",
			"ADMCON",
			"Direction or exercise of authority over subordinate or other organizations in respect to administrative matters such as personnel management, supply, services, and other matters not included in the operational missions of the subordinate or other organizations.");
	public static final ObjectItemAssociationSubcategoryCode HAS_AS_ALTERNATE = new ObjectItemAssociationSubcategoryCode(
			"Has as alternate",
			"ALTFOR",
			"The subject ORGANISATION has the object ORGANISATION as able to execute its functions should the need arise.");
	public static final ObjectItemAssociationSubcategoryCode HAS_ASSIGNED = new ObjectItemAssociationSubcategoryCode(
			"Has assigned",
			"ASGND",
			"An object ORGANISATION is placed in the subject ORGANISATION where such placement is relatively permanent, and/or where such \"subject\" organisation controls and administers the \"object\" organisation for its primary functions.");
	public static final ObjectItemAssociationSubcategoryCode HAS_AT_PRIORITY_CALL = new ObjectItemAssociationSubcategoryCode(
			"Has at priority call",
			"ATPRCL",
			"A precedence applied to the task of an artillery unit to provide fire to a formation/unit on a guaranteed basis.");
	public static final ObjectItemAssociationSubcategoryCode HAS_ATTACHED = new ObjectItemAssociationSubcategoryCode(
			"Has attached",
			"ATTACH",
			"The placement of units in an organisation where such placement is relatively temporary.");
	public static final ObjectItemAssociationSubcategoryCode COORDINATED_AIR_SEA_PROCEDURE_ONE = new ObjectItemAssociationSubcategoryCode(
			"Coordinated air/sea procedure one",
			"CASP1",
			"An air-defence capable warship ORGANISATION is under tactical control of the Air Defence Commander.");
	public static final ObjectItemAssociationSubcategoryCode COORDINATED_AIR_SEA_PROCEDURE_TWO = new ObjectItemAssociationSubcategoryCode(
			"Coordinated air/sea procedure two",
			"CASP2",
			"An air-defence capable warship ORGANISATION is working closely with the shore based Air Defence Commander. Tactical control of the ship remains with the Officer in Tactical Command.");
	public static final ObjectItemAssociationSubcategoryCode COORDINATED_AIR_SEA_PROCEDURE_THREE = new ObjectItemAssociationSubcategoryCode(
			"Coordinated air/sea procedure three",
			"CASP3",
			"A warship ORGANISATION that is unable to contribute to the Recognized Air Picture but requires receiving it normally via the Joint Anti-Air Warfare Shore Coordination net.");
	public static final ObjectItemAssociationSubcategoryCode COORDINATED_AIR_SEA_PROCEDURE_FOUR = new ObjectItemAssociationSubcategoryCode(
			"Coordinated air/sea procedure four",
			"CASP4",
			"An air-defence capable warship ORGANISATION, entering or berthed in a port or anchorage, which is able to assist the SOC/CAOC in whose sector the port or anchorage is located.");
	public static final ObjectItemAssociationSubcategoryCode HAS_FULL_COMMAND_OF = new ObjectItemAssociationSubcategoryCode(
			"Has full command of",
			"COMD",
			"The military authority and responsibility of a superior officer to issue orders to subordinates.");
	public static final ObjectItemAssociationSubcategoryCode HAS_DETACHED = new ObjectItemAssociationSubcategoryCode(
			"Has detached",
			"DETACH",
			"The subject ORGANISATION has the object ORGANISATION separated from its main organisation for duty elsewhere.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_DIRECT_SUPPORT = new ObjectItemAssociationSubcategoryCode(
			"Has in direct support",
			"DIRSUP",
			"The support provided by a unit not attached to or under command of the supported unit or formation, but required to give priority to the support required by that unit or formation.");
	public static final ObjectItemAssociationSubcategoryCode REINFORCES = new ObjectItemAssociationSubcategoryCode(
			"Reinforces",
			"FORCE",
			"The subject ORGANISATION is made available to the object ORGANISATION commander for the purpose of supplementing an in-place force.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_GENERAL_SUPPORT_REINFORCING = new ObjectItemAssociationSubcategoryCode(
			"Has in general support reinforcing",
			"GENSRI",
			"General Support Reinforcing artillery has the mission of supporting the forces as a whole and, on a secondary basis, of providing reinforcing fire for another artillery unit.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_GENERAL_SUPPORT = new ObjectItemAssociationSubcategoryCode(
			"Has in general support",
			"GENSUP",
			"The support that is given to the supported force as a whole and not to any particular subdivision thereof.");
	public static final ObjectItemAssociationSubcategoryCode HAS_CAPTURED = new ObjectItemAssociationSubcategoryCode(
			"Has captured",
			"HSCPTD",
			"The subject ORGANISATION has taken possession, as a result of forceful means, of the object ORGANISATION.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_SUPPORT_OF = new ObjectItemAssociationSubcategoryCode(
			"Has in support of",
			"HSNSPT",
			"Term designating the support provided to another unit, formation or organisation while remaining under the initial command.");
	public static final ObjectItemAssociationSubcategoryCode IS_CO_OPERATING_WITH = new ObjectItemAssociationSubcategoryCode(
			"Is co-operating with",
			"ISCPER",
			"Working or acting together.");
	public static final ObjectItemAssociationSubcategoryCode HAS_ON_CALL = new ObjectItemAssociationSubcategoryCode(
			"Has on call",
			"ONCALL",
			"A term used to specify that a pre-arranged concentration, air strike or final protective fire may be called for.");
	public static final ObjectItemAssociationSubcategoryCode HAS_OPERATIONAL_COMMAND_OF = new ObjectItemAssociationSubcategoryCode(
			"Has operational command of",
			"OPCOMD",
			"The authority granted to a commander to assign missions or tasks to subordinate commanders, to deploy units, to reassign forces, and to retain or delegate operational and/or tactical control as may be deemed necessary.");
	public static final ObjectItemAssociationSubcategoryCode HAS_OPERATIONAL_CONTROL_OF = new ObjectItemAssociationSubcategoryCode(
			"Has operational control of",
			"OPCON",
			"The authority delegated to a commander to direct forces assigned so that the commander may accomplish specific missions or tasks which are usually limited by function, time, or location; to deploy units concerned, and to retain or assign tactical control of those units. It does not include authority to assign separate employment of components of the units concerned.");
	public static final ObjectItemAssociationSubcategoryCode HAS_ORGANIC = new ObjectItemAssociationSubcategoryCode(
			"Has organic",
			"ORGANC",
			"The subject ORGANISATION normally has the object ORGANISATION under command in garrison.");
	public static final ObjectItemAssociationSubcategoryCode HAS_REINFORCING = new ObjectItemAssociationSubcategoryCode(
			"Has reinforcing",
			"REINFC",
			"In artillery usage, a tactical mission in which one artillery unit augments the fire of another artillery unit.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_RESERVE = new ObjectItemAssociationSubcategoryCode(
			"Has in reserve",
			"RESERV",
			"The object ORGANISATION constitutes a force that may be committed into combat only on the order of the commander of the subject ORGANISATION.");
	public static final ObjectItemAssociationSubcategoryCode PLAYS_THE_ROLE_OF = new ObjectItemAssociationSubcategoryCode(
			"Plays the role of",
			"ROLE",
			"The subject ORGANISATION plays the role of an object ORGANISATION.");
	public static final ObjectItemAssociationSubcategoryCode IS_THE_SAME_AS = new ObjectItemAssociationSubcategoryCode(
			"Is the same as",
			"SAME",
			"The subject ORGANISATION is deemed to be the same as the object ORGANISATION.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_AMMUNITION = new ObjectItemAssociationSubcategoryCode(
			"Support services - ammunition",
			"SPTAMM",
			"Supporting unit satisfies all ammunition resupply requirements of the supported unit including crew-served weapons and artillery.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_ENGINEERING = new ObjectItemAssociationSubcategoryCode(
			"Support services - engineering",
			"SPTENG",
			"Supporting unit satisfies engineering support requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_MEDICAL = new ObjectItemAssociationSubcategoryCode(
			"Support services - medical",
			"SPTMED",
			"Supporting unit satisfies medical requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_MOVEMENT = new ObjectItemAssociationSubcategoryCode(
			"Support services - movement",
			"SPTMVT",
			"Supporting unit coordinates and provides road credits for the movement of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_PER_ADM_RPL = new ObjectItemAssociationSubcategoryCode(
			"Support services - per adm rpl",
			"SPTPAR",
			"Supporting unit satisfies all personnel administration and replacement requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_POL = new ObjectItemAssociationSubcategoryCode(
			"Support services - POL",
			"SPTPOL",
			"Supporting unit satisfies fuel/POL supply requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_POSTAL = new ObjectItemAssociationSubcategoryCode(
			"Support services - postal",
			"SPTPST",
			"Supporting unit satisfies postal requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_RATIONS = new ObjectItemAssociationSubcategoryCode(
			"Support services - rations",
			"SPTRAT",
			"Supporting unit satisfies food replenishment requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_REP_REC_EVC = new ObjectItemAssociationSubcategoryCode(
			"Support services - rep, rec, evc",
			"SPTRRE",
			"Supporting unit satisfies 2nd and 3rd line repair, recovery and evacuation requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_SUPPLY = new ObjectItemAssociationSubcategoryCode(
			"Support services - supply",
			"SPTSPL",
			"Supporting unit satisfies supply requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode SUPPORT_SERVICES_TRANSPORT = new ObjectItemAssociationSubcategoryCode(
			"Support services - transport",
			"SPTTRN",
			"Supporting unit satisfies 2nd and 3rd line transport requirements of the supported unit.");
	public static final ObjectItemAssociationSubcategoryCode HAS_TACTICAL_CONTROL_OF = new ObjectItemAssociationSubcategoryCode(
			"Has tactical control of",
			"TACCNT",
			"The detailed, and, usually, local direction and control of movements or manoeuvres necessary to accomplish missions or tasks assigned.");
	public static final ObjectItemAssociationSubcategoryCode HAS_TACTICAL_COMMAND_OF = new ObjectItemAssociationSubcategoryCode(
			"Has tactical command of",
			"TACCOM",
			"The authority delegated to a commander to assign tasks to forces under his command for the accomplishment of the mission assigned by higher authority.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_CLOSE_SUPPORT = new ObjectItemAssociationSubcategoryCode(
			"Has in close support",
			"CLSSUP",
			"That action of the supporting force against targets or objectives that are sufficiently near the supported force as to require detailed integration or coordination of the supporting action with the fire, movement, or other actions of the supported force.");
	public static final ObjectItemAssociationSubcategoryCode HAS_COORDINATION_AUTHORITY_OVER = new ObjectItemAssociationSubcategoryCode(
			"Has coordination authority over",
			"COAUTH",
			"The authority granted to a commander or individual assigned responsibility for coordinating specific functions or activities involving forces of two or more countries or commands, or two or more services or two or more forces of the same service.");
	public static final ObjectItemAssociationSubcategoryCode HAS_IN_MUTUAL_SUPPORT = new ObjectItemAssociationSubcategoryCode(
			"Has in mutual support",
			"MUTSUP",
			"That support which units render each other against an enemy, because of their assigned tasks, their position relative to each other and to the enemy, and their inherent capabilities.");
	public static final ObjectItemAssociationSubcategoryCode HAS_LOGISTICAL_CONTROL_OF = new ObjectItemAssociationSubcategoryCode(
			"Has logistical control of",
			"LOGCON",
			"Logistic Control (LOGCON) is that authority granted to a Commander over assigned logistics units and organizations in the JOA, including National Support Elements (NSE) that empowers him to synchronize, prioritize, and integrate their logistics functions and activities to accomplish the joint mission.");

	private ObjectItemAssociationSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
