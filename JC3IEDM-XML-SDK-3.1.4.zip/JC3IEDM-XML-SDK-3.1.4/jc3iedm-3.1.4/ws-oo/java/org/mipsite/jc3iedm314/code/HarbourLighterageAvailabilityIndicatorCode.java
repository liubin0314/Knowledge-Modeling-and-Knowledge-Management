/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourLighterageAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the possibility for transferring goods from a ship to a wharf or another ship using a boat, usu. flat-bottomed at a specific maritime port.";
	}

	private static HashMap<String, HarbourLighterageAvailabilityIndicatorCode> physicalToCode = new HashMap<String, HarbourLighterageAvailabilityIndicatorCode>();

	public static HarbourLighterageAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourLighterageAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourLighterageAvailabilityIndicatorCode NO = new HarbourLighterageAvailabilityIndicatorCode(
			"No",
			"NO",
			"Lighters are not available at the harbour.");
	public static final HarbourLighterageAvailabilityIndicatorCode YES = new HarbourLighterageAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Lighters are available at the harbour.");

	private HarbourLighterageAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
