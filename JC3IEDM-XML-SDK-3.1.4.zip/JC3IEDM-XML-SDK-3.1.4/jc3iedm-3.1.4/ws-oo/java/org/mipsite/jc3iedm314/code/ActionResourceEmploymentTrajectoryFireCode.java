/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceEmploymentTrajectoryFireCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of trajectory to be used in firing of a specific ACTION-RESOURCE in support of a specific ACTION.";
	}

	private static HashMap<String, ActionResourceEmploymentTrajectoryFireCode> physicalToCode = new HashMap<String, ActionResourceEmploymentTrajectoryFireCode>();

	public static ActionResourceEmploymentTrajectoryFireCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceEmploymentTrajectoryFireCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceEmploymentTrajectoryFireCode HIGH = new ActionResourceEmploymentTrajectoryFireCode(
			"High",
			"HIGH",
			"The ACTION-RESOURCE uses an elevation of more than 45 degrees (800 mils) when firing.");
	public static final ActionResourceEmploymentTrajectoryFireCode LOW = new ActionResourceEmploymentTrajectoryFireCode(
			"Low",
			"LOW",
			"The ACTION-RESOURCE uses an elevation up to 45 degrees (800 mils) when firing.");

	private ActionResourceEmploymentTrajectoryFireCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
