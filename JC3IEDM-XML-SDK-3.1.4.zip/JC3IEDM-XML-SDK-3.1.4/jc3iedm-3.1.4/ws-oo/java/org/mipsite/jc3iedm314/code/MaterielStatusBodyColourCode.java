/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusBodyColourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the current colour scheme of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusBodyColourCode> physicalToCode = new HashMap<String, MaterielStatusBodyColourCode>();

	public static MaterielStatusBodyColourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusBodyColourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusBodyColourCode AUBURN = new MaterielStatusBodyColourCode(
			"Auburn",
			"AUBURN",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BEIGE = new MaterielStatusBodyColourCode(
			"Beige",
			"BEIGE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BLACK = new MaterielStatusBodyColourCode(
			"Black",
			"BLACK",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BLUE = new MaterielStatusBodyColourCode(
			"Blue",
			"BLUE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BLUE_LIGHT = new MaterielStatusBodyColourCode(
			"Blue, light",
			"BLUELG",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BRONZE = new MaterielStatusBodyColourCode(
			"Bronze",
			"BRONZE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode BROWN = new MaterielStatusBodyColourCode(
			"Brown",
			"BROWN",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CAMOUFLAGE_DESERT_GREY = new MaterielStatusBodyColourCode(
			"Camouflage, desert, grey",
			"CAMDSG",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CAMOUFLAGE_DESERT_RED = new MaterielStatusBodyColourCode(
			"Camouflage, desert, red",
			"CAMDSR",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CAMOUFLAGE_WINTER = new MaterielStatusBodyColourCode(
			"Camouflage, winter",
			"CAMWNT",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CAMOUFLAGE_WOODLAND = new MaterielStatusBodyColourCode(
			"Camouflage, woodland",
			"CAMWOD",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CHROME = new MaterielStatusBodyColourCode(
			"Chrome",
			"CHROME",
			"Self defined.");
	public static final MaterielStatusBodyColourCode COPPER = new MaterielStatusBodyColourCode(
			"Copper",
			"COPPER",
			"Self defined.");
	public static final MaterielStatusBodyColourCode CREAM = new MaterielStatusBodyColourCode(
			"Cream",
			"CREAM",
			"Self defined.");
	public static final MaterielStatusBodyColourCode GOLD = new MaterielStatusBodyColourCode(
			"Gold",
			"GOLD",
			"Self defined.");
	public static final MaterielStatusBodyColourCode GREEN = new MaterielStatusBodyColourCode(
			"Green",
			"GREEN",
			"Self defined.");
	public static final MaterielStatusBodyColourCode GREEN_DARK = new MaterielStatusBodyColourCode(
			"Green, dark",
			"GREEND",
			"Self defined.");
	public static final MaterielStatusBodyColourCode GREEN_LIGHT = new MaterielStatusBodyColourCode(
			"Green, light",
			"GREENL",
			"Self defined.");
	public static final MaterielStatusBodyColourCode GREY = new MaterielStatusBodyColourCode(
			"Grey",
			"GREY",
			"Self defined.");
	public static final MaterielStatusBodyColourCode LAVENDER = new MaterielStatusBodyColourCode(
			"Lavender",
			"LAVNDR",
			"Self defined.");
	public static final MaterielStatusBodyColourCode MAROON = new MaterielStatusBodyColourCode(
			"Maroon",
			"MAROON",
			"Self defined.");
	public static final MaterielStatusBodyColourCode MULTICOLOURED = new MaterielStatusBodyColourCode(
			"Multicoloured",
			"MULTI",
			"Self defined.");
	public static final MaterielStatusBodyColourCode NOT_KNOWN = new MaterielStatusBodyColourCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusBodyColourCode NOT_OTHERWISE_SPECIFIED = new MaterielStatusBodyColourCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaterielStatusBodyColourCode ORANGE = new MaterielStatusBodyColourCode(
			"Orange",
			"ORANGE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode PURPLE = new MaterielStatusBodyColourCode(
			"Purple",
			"PURPLE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode RED = new MaterielStatusBodyColourCode(
			"Red",
			"RED",
			"Self defined.");
	public static final MaterielStatusBodyColourCode RUST = new MaterielStatusBodyColourCode(
			"Rust",
			"RUST",
			"Self defined.");
	public static final MaterielStatusBodyColourCode SILVER = new MaterielStatusBodyColourCode(
			"Silver",
			"SILVER",
			"Self defined.");
	public static final MaterielStatusBodyColourCode TAN = new MaterielStatusBodyColourCode(
			"Tan",
			"TAN",
			"Self defined.");
	public static final MaterielStatusBodyColourCode TURQUOISE = new MaterielStatusBodyColourCode(
			"Turquoise",
			"TURQSE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode WHITE = new MaterielStatusBodyColourCode(
			"White",
			"WHITE",
			"Self defined.");
	public static final MaterielStatusBodyColourCode YELLOW = new MaterielStatusBodyColourCode(
			"Yellow",
			"YELLOW",
			"Self defined.");

	private MaterielStatusBodyColourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
