/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SolidSurfaceStatusSurfaceConditionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the physical status of a solid surface area.";
	}

	private static HashMap<String, SolidSurfaceStatusSurfaceConditionCode> physicalToCode = new HashMap<String, SolidSurfaceStatusSurfaceConditionCode>();

	public static SolidSurfaceStatusSurfaceConditionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SolidSurfaceStatusSurfaceConditionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SolidSurfaceStatusSurfaceConditionCode DUST = new SolidSurfaceStatusSurfaceConditionCode(
			"Dust",
			"DUST",
			"A characterisation of an area covered with fine dry particles of matter.");
	public static final SolidSurfaceStatusSurfaceConditionCode EARTH = new SolidSurfaceStatusSurfaceConditionCode(
			"Earth",
			"EARTH",
			"A characteristic of an area covered with soil.");
	public static final SolidSurfaceStatusSurfaceConditionCode FLOOD = new SolidSurfaceStatusSurfaceConditionCode(
			"Flood",
			"FLOOD",
			"A characterisation of an area covered or submerged temporarily in water.");
	public static final SolidSurfaceStatusSurfaceConditionCode ICE = new SolidSurfaceStatusSurfaceConditionCode(
			"Ice",
			"ICE",
			"A characterisation of an area covered with a layer or mass of frozen water.");
	public static final SolidSurfaceStatusSurfaceConditionCode NOT_KNOWN = new SolidSurfaceStatusSurfaceConditionCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final SolidSurfaceStatusSurfaceConditionCode NOT_OTHERWISE_SPECIFIED = new SolidSurfaceStatusSurfaceConditionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final SolidSurfaceStatusSurfaceConditionCode SAND = new SolidSurfaceStatusSurfaceConditionCode(
			"Sand",
			"SAND",
			"A characterisation of an area covered with small, loose grains of worn or disintegrated rock.");
	public static final SolidSurfaceStatusSurfaceConditionCode SNOW = new SolidSurfaceStatusSurfaceConditionCode(
			"Snow",
			"SNOW",
			"A characterisation of an area covered with snow.");

	private SolidSurfaceStatusSurfaceConditionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
