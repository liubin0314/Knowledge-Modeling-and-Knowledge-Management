/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusFireModeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of weapons employment constraint for a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusFireModeCode> physicalToCode = new HashMap<String, OrganisationStatusFireModeCode>();

	public static OrganisationStatusFireModeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusFireModeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusFireModeCode HOLD_FIRE = new OrganisationStatusFireModeCode(
			"Hold fire",
			"HLDFIR",
			"An emergency order to stop firing; missiles in flight must be prevented from intercepting, if technically possible.");
	public static final OrganisationStatusFireModeCode NOT_KNOWN = new OrganisationStatusFireModeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusFireModeCode WEAPONS_FREE = new OrganisationStatusFireModeCode(
			"Weapons free",
			"WPNFRE",
			"A weapon control order imposing a status whereby weapons systems may be fired at any target not positively identified as friendly.");
	public static final OrganisationStatusFireModeCode WEAPONS_TIGHT = new OrganisationStatusFireModeCode(
			"Weapons tight",
			"WPNTGT",
			"A weapon control order imposing a status whereby weapons systems may be fired only at targets recognised as hostile.");
	public static final OrganisationStatusFireModeCode WEAPONS_HOLD = new OrganisationStatusFireModeCode(
			"Weapons hold",
			"WPNHLD",
			"A weapon control order imposing a status whereby weapons systems may only be fired in self defence or in response to a formal order.");

	private OrganisationStatusFireModeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
