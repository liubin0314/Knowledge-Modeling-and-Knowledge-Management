/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationTypeCommandAndControlCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the command and control classification of an ORGANISATION-TYPE.";
	}

	private static HashMap<String, OrganisationTypeCommandAndControlCategoryCode> physicalToCode = new HashMap<String, OrganisationTypeCommandAndControlCategoryCode>();

	public static OrganisationTypeCommandAndControlCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationTypeCommandAndControlCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationTypeCommandAndControlCategoryCode AIR_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Air operations centre",
			"AIROPC",
			"The ORGANISATION-TYPE from which aircraft and air warning functions of combat air operations are directed, controlled, and executed. It is the senior agency of the air force component commander from which command and control of air operations are coordinated with other components and services.");
	public static final OrganisationTypeCommandAndControlCategoryCode AIR_CONTROL_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Air control centre",
			"ARCNTC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode AIR_OPERATIONS_COORDINATION_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Air operations coordination centre",
			"AROPCC",
			"The ORGANISATION-TYPE of a tactical air control system collocated with a corps headquarters or an appropriate land force headquarters, which coordinates and directs close air support and other tactical air support.");
	public static final OrganisationTypeCommandAndControlCategoryCode AIR_SUPPORT_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Air support operations centre",
			"ARSOPC",
			"The ORGANISATION-TYPE of a tactical air control system collocated with a corps headquarters or an appropriate land force headquarters, which coordinates and directs close air support and other tactical air support.");
	public static final OrganisationTypeCommandAndControlCategoryCode AIRBORNE_WARNING_AND_CONTROL_SYSTEM = new OrganisationTypeCommandAndControlCategoryCode(
			"Airborne warning and control system",
			"AWACS",
			"The ORGANISATION-TYPE that is an Airborne Warning and Control System (AWACS) aircraft that provides all-weather surveillance, command, control and communications needed by commanders of air defence forces.");
	public static final OrganisationTypeCommandAndControlCategoryCode COMBINED_AIR_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Combined air operations centre",
			"CAOC",
			"The ORGANISATION-TYPE that is staffed by members of more than one nation, established for planning, directing, and executing combined air operations in support of the combined force commander's operation or campaign objectives.");
	public static final OrganisationTypeCommandAndControlCategoryCode COORDINATION_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Coordination centre",
			"CC",
			"The ORGANISATION-TYPE is a coordination centre.");
	public static final OrganisationTypeCommandAndControlCategoryCode CONTROL_AND_REPORTING_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Control and reporting centre",
			"CNTRPC",
			"The ORGANISATION-TYPE that serves as the senior ground radar element of the theatre air control system (TACS). Mission is to detect, identify, and verify airborne targets in assigned area. CRC also provides decentralized execution of air defence and airspace control, provides early warning to air and ground elements and manages subordinate radar units.");
	public static final OrganisationTypeCommandAndControlCategoryCode CONTROL_AND_REPORTING_POST = new OrganisationTypeCommandAndControlCategoryCode(
			"Control and reporting post",
			"CNTRPP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode COMMAND_POST = new OrganisationTypeCommandAndControlCategoryCode(
			"Command post",
			"CP",
			"The ORGANISATION-TYPE is a command post.");
	public static final OrganisationTypeCommandAndControlCategoryCode DIRECT_AIR_SUPPORT_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Direct air support centre",
			"DASC",
			"The ORGANISATION-TYPE that is the principal air control agency of the U.S. Marine air command and control system responsible for the direction and control of air operations directly supporting the ground combat element. It processes and coordinates requests for immediate air support and coordinates air missions requiring integration with ground forces and other supporting arms.");
	public static final OrganisationTypeCommandAndControlCategoryCode DIRECT_AIR_SUPPORT_CENTRE_AIRBORNE = new OrganisationTypeCommandAndControlCategoryCode(
			"Direct air support centre, airborne",
			"DASCAR",
			"The ORGANISATION-TYPE that is the principal air control agency of the U.S. Marine air command and control system, operating in an airborne platform responsible for the direction and control of air operations directly supporting the ground combat element.");
	public static final OrganisationTypeCommandAndControlCategoryCode FORWARD_AIR_CONTROL_PARTY = new OrganisationTypeCommandAndControlCategoryCode(
			"Forward air control party",
			"FACC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1395/5.");
	public static final OrganisationTypeCommandAndControlCategoryCode GROUND_BASED_AIR_DEFENCE_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Ground based air defence operations centre",
			"GRBOPC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode HEADQUARTERS = new OrganisationTypeCommandAndControlCategoryCode(
			"Headquarters",
			"HQ",
			"The ORGANISATION-TYPE is a headquarters.");
	public static final OrganisationTypeCommandAndControlCategoryCode MARINE_TACTICAL_AIR_COMMAND_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Marine tactical air command centre",
			"MTACMC",
			"The ORGANISATION-TYPE that is the senior U.S. Marine command and control agency providing centralized command for Marine Air Ground Task Forces, and serves as the command post for the aviation combat element (ACE) commander.");
	public static final OrganisationTypeCommandAndControlCategoryCode MARINE_TACTICAL_AIR_DIRECTION_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Marine tactical air direction centre",
			"MTADRC",
			"The ORGANISATION-TYPE that is under the overall control of the tactical air control centre (afloat) or tactical air command centre, from which aircraft and air warning service functions of tactical air operations in an area of concern are directed.");
	public static final OrganisationTypeCommandAndControlCategoryCode MARINE_TACTICAL_AIR_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Marine tactical air operations centre",
			"MTAOPC",
			"The ORGANISATION-TYPE that is the principal air control agency of the U.S. Marine air command and control system responsible for airspace control and management. It provides real-time surveillance, direction, positive control, and navigational assistance for friendly aircraft. It performs real-time direction and control of all anti-air warfare operations, to include manned interceptors and surface-to-air weapons. It is subordinate to the tactical air command centre.");
	public static final OrganisationTypeCommandAndControlCategoryCode NOT_KNOWN = new OrganisationTypeCommandAndControlCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationTypeCommandAndControlCategoryCode NOT_OTHERWISE_SPECIFIED = new OrganisationTypeCommandAndControlCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final OrganisationTypeCommandAndControlCategoryCode OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Operations centre",
			"OC",
			"The ORGANISATION-TYPE is an operations centre.");
	public static final OrganisationTypeCommandAndControlCategoryCode RECOGNISED_AIR_PICTURE_PRODUCTION_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Recognised air picture production centre",
			"RAPPRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode SURFACE_TO_AIR_MISSILE_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Surface-to-air missile-operations centre",
			"SAMOPC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode SQUADRON_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Squadron operations centre",
			"SQDOPC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");
	public static final OrganisationTypeCommandAndControlCategoryCode TACTICAL_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Tactical operations centre",
			"TACOPC",
			"A physical grouping of those elements of general and special staff concerned with the current tactical operations and the tactical support thereof.");
	public static final OrganisationTypeCommandAndControlCategoryCode TACTICAL_AIR_CONTROL_PARTY = new OrganisationTypeCommandAndControlCategoryCode(
			"Tactical air control party",
			"TACP",
			"The ORGANISATION-TYPE that is an agency that provides assistance in the submission of pre-planned and immediate air support requests, as well as providing terminal control for supporting aircraft. It is an integral part of each combat unit from division down to battalion level and serves as an air advisor to each manoeuvre unit.");
	public static final OrganisationTypeCommandAndControlCategoryCode WING_OPERATIONS_CENTRE = new OrganisationTypeCommandAndControlCategoryCode(
			"Wing operations centre",
			"WNGOPC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1874/4.");

	private OrganisationTypeCommandAndControlCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
