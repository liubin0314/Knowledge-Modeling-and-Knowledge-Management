/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldAirTrafficControlPresenceIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific AIRFIELD provides air traffic control.";
	}

	private static HashMap<String, AirfieldAirTrafficControlPresenceIndicatorCode> physicalToCode = new HashMap<String, AirfieldAirTrafficControlPresenceIndicatorCode>();

	public static AirfieldAirTrafficControlPresenceIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldAirTrafficControlPresenceIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldAirTrafficControlPresenceIndicatorCode NO = new AirfieldAirTrafficControlPresenceIndicatorCode(
			"No",
			"NO",
			"The specific AIRFIELD does not provide air traffic control.");
	public static final AirfieldAirTrafficControlPresenceIndicatorCode YES = new AirfieldAirTrafficControlPresenceIndicatorCode(
			"Yes",
			"YES",
			"The specific AIRFIELD provides air traffic control.");

	private AirfieldAirTrafficControlPresenceIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
