/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionObjectiveType extends AbstractActionObjective {

	// private fields

	private ActionObjectiveTypeCategoryCode actionObjectiveTypeCategoryCode; // mandatory
	private TextTypeVar20 priorityText; // optional
	private QuantityType12_3 quantity; // optional
	private Ref<CandidateTargetDetailType> candidateTargetDetailType; // optional
	private Ref<AbstractObjectType> objectType; // mandatory

	// default constructor

	public AbstractActionObjectiveType() {
		// no assignment
	}

	// getter & setter methods

	public ActionObjectiveTypeCategoryCode getActionObjectiveTypeCategoryCode() {
		if (this.actionObjectiveTypeCategoryCode == null) {
			throw new NullValueException("AbstractActionObjectiveType.actionObjectiveTypeCategoryCode");
		}
		return this.actionObjectiveTypeCategoryCode;
	}

	public void setActionObjectiveTypeCategoryCode(ActionObjectiveTypeCategoryCode actionObjectiveTypeCategoryCode) {
		this.actionObjectiveTypeCategoryCode = actionObjectiveTypeCategoryCode;
	}

	public TextTypeVar20 getPriorityText() {
		return this.priorityText;
	}

	public void setPriorityText(TextTypeVar20 priorityText) {
		this.priorityText = priorityText;
	}

	public QuantityType12_3 getQuantity() {
		return this.quantity;
	}

	public void setQuantity(QuantityType12_3 quantity) {
		this.quantity = quantity;
	}

	public Ref<CandidateTargetDetailType> getCandidateTargetDetailType() {
		return this.candidateTargetDetailType;
	}

	public void setCandidateTargetDetailType(Ref<CandidateTargetDetailType> candidateTargetDetailType) {
		this.candidateTargetDetailType = candidateTargetDetailType;
	}

	public Ref<AbstractObjectType> getObjectType() {
		if (this.objectType == null) {
			throw new NullValueException("AbstractActionObjectiveType.objectType");
		}
		return this.objectType;
	}

	public void setObjectType(Ref<AbstractObjectType> objectType) {
		this.objectType = objectType;
	}
}
