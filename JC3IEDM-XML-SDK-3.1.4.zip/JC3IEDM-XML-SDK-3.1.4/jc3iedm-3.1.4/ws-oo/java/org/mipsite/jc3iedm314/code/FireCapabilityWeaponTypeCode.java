/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FireCapabilityWeaponTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general type of weapon that an EQUIPMENT-TYPE is qualified to employ.";
	}

	private static HashMap<String, FireCapabilityWeaponTypeCode> physicalToCode = new HashMap<String, FireCapabilityWeaponTypeCode>();

	public static FireCapabilityWeaponTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FireCapabilityWeaponTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FireCapabilityWeaponTypeCode CONVENTIONAL = new FireCapabilityWeaponTypeCode(
			"Conventional",
			"CONV",
			"The capability to deliver weapons which are not nuclear.");
	public static final FireCapabilityWeaponTypeCode DUAL_CAPABLE = new FireCapabilityWeaponTypeCode(
			"Dual capable",
			"DUAL",
			"The capability of executing both conventional and nuclear missions.");
	public static final FireCapabilityWeaponTypeCode NON_COMBAT_CAPABLE = new FireCapabilityWeaponTypeCode(
			"Non combat capable",
			"NCC",
			"The inability to deliver any type of weapon.");
	public static final FireCapabilityWeaponTypeCode NOT_KNOWN = new FireCapabilityWeaponTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FireCapabilityWeaponTypeCode NOT_OTHERWISE_SPECIFIED = new FireCapabilityWeaponTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final FireCapabilityWeaponTypeCode NUCLEAR = new FireCapabilityWeaponTypeCode(
			"Nuclear",
			"NUC",
			"The capability to deliver nuclear weapons.");

	private FireCapabilityWeaponTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
