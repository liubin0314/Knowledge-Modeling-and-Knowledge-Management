/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourRefuellingTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the refuelling means available at the specific HARBOUR.";
	}

	private static HashMap<String, HarbourRefuellingTypeCode> physicalToCode = new HashMap<String, HarbourRefuellingTypeCode>();

	public static HarbourRefuellingTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourRefuellingTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourRefuellingTypeCode BUNKERING_BARGE = new HarbourRefuellingTypeCode(
			"Bunkering, barge",
			"BKRBRG",
			"A mobile facility that is a barge whose sole purpose is the refuelling of vessels.");
	public static final HarbourRefuellingTypeCode FIXED_INSTALLATION = new HarbourRefuellingTypeCode(
			"Fixed installation",
			"FXDINS",
			"A static facility from which vessels can refuel.");
	public static final HarbourRefuellingTypeCode NOT_OTHERWISE_SPECIFIED = new HarbourRefuellingTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final HarbourRefuellingTypeCode TANKER_ROAD = new HarbourRefuellingTypeCode(
			"Tanker, road",
			"TNKRRD",
			"A mobile facility that is a road fuel tanker used for refuelling vessels whilst moored alongside a jetty, basin, quay or berth.");

	private HarbourRefuellingTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
