/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AtmosphereInversionLayerCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the height of the inversion layer in the atmosphere. The stability class describes the degree of mixing of released material in the atmosphere.";
	}

	private static HashMap<String, AtmosphereInversionLayerCode> physicalToCode = new HashMap<String, AtmosphereInversionLayerCode>();

	public static AtmosphereInversionLayerCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AtmosphereInversionLayerCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AtmosphereInversionLayerCode A = new AtmosphereInversionLayerCode(
			"A",
			"A",
			"Top of inversion layer lower than 800 metres above ground.");
	public static final AtmosphereInversionLayerCode B = new AtmosphereInversionLayerCode(
			"B",
			"B",
			"Top of inversion layer lower than 400 metres above ground.");
	public static final AtmosphereInversionLayerCode C = new AtmosphereInversionLayerCode(
			"C",
			"C",
			"Top of inversion layer lower than 200 metres above ground.");

	private AtmosphereInversionLayerCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
