/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusColourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the known status of mined channels of a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusColourCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusColourCode>();

	public static MinefieldMaritimeStatusColourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusColourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusColourCode GREEN = new MinefieldMaritimeStatusColourCode(
			"Green",
			"GREEN",
			"Established channel/RTE where information does not exist on enemy mining or all known mines in the channel have been countered.");
	public static final MinefieldMaritimeStatusColourCode RED = new MinefieldMaritimeStatusColourCode(
			"Red",
			"RED",
			"Channel where mines are known to be present.");
	public static final MinefieldMaritimeStatusColourCode YELLOW = new MinefieldMaritimeStatusColourCode(
			"Yellow",
			"YELLOW",
			"Channel where the degree of danger has been reduced by mine counter measure operations.");

	private MinefieldMaritimeStatusColourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
