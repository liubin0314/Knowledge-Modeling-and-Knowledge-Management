/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a specific ORGANISATION-REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, OrganisationReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, OrganisationReferenceAssociationCategoryCode>();

	public static OrganisationReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationReferenceAssociationCategoryCode IS_APPROVAL_AUTHORITY_FOR = new OrganisationReferenceAssociationCategoryCode(
			"Is approval authority for",
			"ISAPRL",
			"The specific ORGANISATION is authorised to approve the artefact cited in the specific REFERENCE.");
	public static final OrganisationReferenceAssociationCategoryCode IS_CLASSIFICATION_AUTHORITY_FOR = new OrganisationReferenceAssociationCategoryCode(
			"Is classification authority for",
			"ISCLSF",
			"The specific ORGANISATION is classification authority for the artefact cited in the specific REFERENCE.");
	public static final OrganisationReferenceAssociationCategoryCode IS_CONFIGURATION_MANAGER_OF = new OrganisationReferenceAssociationCategoryCode(
			"Is configuration manager of",
			"ISCNGF",
			"The specific ORGANISATION is responsible for maintaining the configuration of the artefact cited in the specific REFERENCE.");
	public static final OrganisationReferenceAssociationCategoryCode IS_CREATOR_OF = new OrganisationReferenceAssociationCategoryCode(
			"Is creator of",
			"ISCRTR",
			"The specific ORGANISATION is responsible for producing the artefact cited in the specific REFERENCE.");
	public static final OrganisationReferenceAssociationCategoryCode IS_PLANNER_OF = new OrganisationReferenceAssociationCategoryCode(
			"Is planner of",
			"ISPLNR",
			"The specific ORGANISATION is responsible for the planning aspects of the artefact cited in the specific REFERENCE.");
	public static final OrganisationReferenceAssociationCategoryCode IS_RELEASE_AUTHORITY_FOR = new OrganisationReferenceAssociationCategoryCode(
			"Is release authority for",
			"ISRLSA",
			"The specific ORGANISATION is release authority for the artefact cited in the specific REFERENCE.");

	private OrganisationReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
