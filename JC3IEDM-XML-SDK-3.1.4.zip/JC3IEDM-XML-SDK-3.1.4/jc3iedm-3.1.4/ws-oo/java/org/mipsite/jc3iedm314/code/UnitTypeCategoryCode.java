/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of UNIT-TYPE.";
	}

	private static HashMap<String, UnitTypeCategoryCode> physicalToCode = new HashMap<String, UnitTypeCategoryCode>();

	public static UnitTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeCategoryCode COMBAT = new UnitTypeCategoryCode(
			"Combat",
			"COMBAT",
			"A UNIT-TYPE who closes with and destroys enemy forces or provides firepower and destructive capabilities in the battlespace.");
	public static final UnitTypeCategoryCode COMBAT_SERVICE_SUPPORT = new UnitTypeCategoryCode(
			"Combat service support",
			"COMSER",
			"A UNIT-TYPE tasked to provide support to combat forces, primarily in the fields of administration and logistics.");
	public static final UnitTypeCategoryCode COMBAT_SUPPORT = new UnitTypeCategoryCode(
			"Combat support",
			"COMSPT",
			"A UNIT-TYPE that provides critical combat functions in conjunction with combat arms units and soldiers.");
	public static final UnitTypeCategoryCode NOT_KNOWN = new UnitTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final UnitTypeCategoryCode SPECIAL_OPERATIONS_FORCES = new UnitTypeCategoryCode(
			"Special operations forces",
			"SOF",
			"A UNIT-TYPE that provides unique capabilities of special reconnaissance, direct action and military assistance in order to undertake difficult, dangerous and sometimes politically sensitive missions for the theatre commander.");

	private UnitTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
