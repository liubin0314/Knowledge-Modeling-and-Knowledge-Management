/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeManningCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether an aircraft is designed to be manned or unmanned.";
	}

	private static HashMap<String, AircraftTypeManningCode> physicalToCode = new HashMap<String, AircraftTypeManningCode>();

	public static AircraftTypeManningCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeManningCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeManningCode MANNED = new AircraftTypeManningCode(
			"Manned",
			"MANNED",
			"The AIRCRAFT-TYPE is designed to be manned.");
	public static final AircraftTypeManningCode NOT_KNOWN = new AircraftTypeManningCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeManningCode UNMANNED = new AircraftTypeManningCode(
			"Unmanned",
			"UNMANN",
			"The AIRCRAFT-TYPE is designed to be unmanned.");
	public static final AircraftTypeManningCode UNMANNED_NOT_REMOTELY_PILOTED = new AircraftTypeManningCode(
			"Unmanned not remotely piloted",
			"UNMNRP",
			"The AIRCRAFT-TYPE is designed to be unmanned and not remotely piloted.");
	public static final AircraftTypeManningCode UNMANNED_REMOTELY_PILOTED = new AircraftTypeManningCode(
			"Unmanned remotely piloted",
			"UNMRP",
			"The AIRCRAFT-TYPE is designed to be unmanned and remotely piloted.");

	private AircraftTypeManningCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
