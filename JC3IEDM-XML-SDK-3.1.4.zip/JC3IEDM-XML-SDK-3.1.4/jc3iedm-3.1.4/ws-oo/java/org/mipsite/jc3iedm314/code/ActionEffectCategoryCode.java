/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEffectCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-EFFECT with respect to item or type.";
	}

	private static HashMap<String, ActionEffectCategoryCode> physicalToCode = new HashMap<String, ActionEffectCategoryCode>();

	public static ActionEffectCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEffectCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEffectCategoryCode ACTION_EFFECT_ITEM = new ActionEffectCategoryCode(
			"ACTION-EFFECT-ITEM",
			"AEITEM",
			"An ACTION-EFFECT of a specific ACTION in accomplishing its aim in relation to a specific OBJECT-ITEM.");
	public static final ActionEffectCategoryCode ACTION_EFFECT_TYPE = new ActionEffectCategoryCode(
			"ACTION-EFFECT-TYPE",
			"AETYPE",
			"An ACTION-EFFECT of a specific ACTION in accomplishing its aim in relation to a specific OBJECT-TYPE.");

	private ActionEffectCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
