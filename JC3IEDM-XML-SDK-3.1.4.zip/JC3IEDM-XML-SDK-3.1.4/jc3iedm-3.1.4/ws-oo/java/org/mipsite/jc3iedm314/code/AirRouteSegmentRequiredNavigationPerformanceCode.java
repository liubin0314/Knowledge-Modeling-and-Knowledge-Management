/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirRouteSegmentRequiredNavigationPerformanceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the required navigation performance when flying routes for which external route navigation aids are not provided.";
	}

	private static HashMap<String, AirRouteSegmentRequiredNavigationPerformanceCode> physicalToCode = new HashMap<String, AirRouteSegmentRequiredNavigationPerformanceCode>();

	public static AirRouteSegmentRequiredNavigationPerformanceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirRouteSegmentRequiredNavigationPerformanceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirRouteSegmentRequiredNavigationPerformanceCode _12_5 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"12.5",
			"125NM",
			"12.5 Nautical Mile navigation accuracy.");
	public static final AirRouteSegmentRequiredNavigationPerformanceCode _1 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"1",
			"1NM",
			"1 Nautical Mile navigation accuracy.");
	public static final AirRouteSegmentRequiredNavigationPerformanceCode _20 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"20",
			"20NM",
			"20 Nautical Mile navigation accuracy.");
	public static final AirRouteSegmentRequiredNavigationPerformanceCode _4 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"4",
			"4NM",
			"4 Nautical Mile navigation accuracy.");
	public static final AirRouteSegmentRequiredNavigationPerformanceCode _5 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"5",
			"5NM",
			"5 Nautical Mile navigation accuracy.");
	public static final AirRouteSegmentRequiredNavigationPerformanceCode _6 = new AirRouteSegmentRequiredNavigationPerformanceCode(
			"6",
			"6NM",
			"6 Nautical Mile navigation accuracy.");

	private AirRouteSegmentRequiredNavigationPerformanceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
