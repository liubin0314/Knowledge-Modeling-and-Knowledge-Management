/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IedTacticalCharacterizationUseSequenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies enemy use of an IED as a primary, secondary, or tertiary form of attack, independent of intended outcome.";
	}

	private static HashMap<String, IedTacticalCharacterizationUseSequenceCode> physicalToCode = new HashMap<String, IedTacticalCharacterizationUseSequenceCode>();

	public static IedTacticalCharacterizationUseSequenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IedTacticalCharacterizationUseSequenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IedTacticalCharacterizationUseSequenceCode PRIMARY = new IedTacticalCharacterizationUseSequenceCode(
			"Primary",
			"PRI",
			"This is the initial IED employed in the target area.");
	public static final IedTacticalCharacterizationUseSequenceCode SECONDARY = new IedTacticalCharacterizationUseSequenceCode(
			"Secondary",
			"SEC",
			"This is an additional device emplaced in the target area to attack individuals or vehicles after the initial event.");
	public static final IedTacticalCharacterizationUseSequenceCode TERTIARY = new IedTacticalCharacterizationUseSequenceCode(
			"Tertiary",
			"TER",
			"This is an additional device emplaced in the target area to attack individuals or vehicles after the initial and secondary events.");
	public static final IedTacticalCharacterizationUseSequenceCode NOT_KNOWN = new IedTacticalCharacterizationUseSequenceCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private IedTacticalCharacterizationUseSequenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
