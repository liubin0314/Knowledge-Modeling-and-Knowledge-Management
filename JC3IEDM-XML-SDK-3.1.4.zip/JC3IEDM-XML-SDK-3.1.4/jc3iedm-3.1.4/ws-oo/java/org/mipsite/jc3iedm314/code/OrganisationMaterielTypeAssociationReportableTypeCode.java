/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationMaterielTypeAssociationReportableTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ORGANISATION-MATERIEL-TYPE-ASSOCIATION.";
	}

	private static HashMap<String, OrganisationMaterielTypeAssociationReportableTypeCode> physicalToCode = new HashMap<String, OrganisationMaterielTypeAssociationReportableTypeCode>();

	public static OrganisationMaterielTypeAssociationReportableTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationMaterielTypeAssociationReportableTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationMaterielTypeAssociationReportableTypeCode LAND_FORCES_REPORTABLE_ITEM_LIST = new OrganisationMaterielTypeAssociationReportableTypeCode(
			"Land forces reportable item list",
			"LFRIL",
			"A designation of the additional reference given to a MATERIEL-TYPE that has not been assigned a value from Reportable Item Code list but still needed in Land Forces Reportable Item List.");
	public static final OrganisationMaterielTypeAssociationReportableTypeCode REPORTABLE_ITEM_CODE = new OrganisationMaterielTypeAssociationReportableTypeCode(
			"Reportable item code",
			"RIC",
			"A designation of the additional reference given to a MATERIEL-TYPE as assigned in the official list containing Reportable Item Codes issued by NATO.");

	private OrganisationMaterielTypeAssociationReportableTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
