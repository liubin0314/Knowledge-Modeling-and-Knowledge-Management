/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAddressAuthorisationIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether the OBJECT-ITEM is permitted by command authority to use a specific ELECTRONIC-ADDRESS.";
	}

	private static HashMap<String, ObjectItemAddressAuthorisationIndicatorCode> physicalToCode = new HashMap<String, ObjectItemAddressAuthorisationIndicatorCode>();

	public static ObjectItemAddressAuthorisationIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAddressAuthorisationIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAddressAuthorisationIndicatorCode NO = new ObjectItemAddressAuthorisationIndicatorCode(
			"No",
			"NO",
			"The specific OBJECT-ITEM is not authorised to use the specific ELECTRONIC-ADDRESS.");
	public static final ObjectItemAddressAuthorisationIndicatorCode YES = new ObjectItemAddressAuthorisationIndicatorCode(
			"Yes",
			"YES",
			"The specific OBJECT-ITEM is authorised to use the specific ELECTRONIC-ADDRESS.");

	private ObjectItemAddressAuthorisationIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
