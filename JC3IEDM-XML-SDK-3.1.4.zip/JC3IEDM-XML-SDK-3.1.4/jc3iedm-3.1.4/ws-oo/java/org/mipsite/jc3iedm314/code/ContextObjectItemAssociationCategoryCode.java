/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextObjectItemAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between a specific CONTEXT and a specific OBJECT-ITEM in a specific CONTEXT-OBJECT-ITEM-ASSOCIATION.";
	}

	private static HashMap<String, ContextObjectItemAssociationCategoryCode> physicalToCode = new HashMap<String, ContextObjectItemAssociationCategoryCode>();

	public static ContextObjectItemAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextObjectItemAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextObjectItemAssociationCategoryCode INCLUDES = new ContextObjectItemAssociationCategoryCode(
			"Includes",
			"INCLDE",
			"The specific CONTEXT includes the OBJECT-ITEM as part of the information encompassed by the CONTEXT.");
	public static final ContextObjectItemAssociationCategoryCode IS_RELEVANT_TO = new ContextObjectItemAssociationCategoryCode(
			"Is relevant to",
			"ISRELV",
			"The specific CONTEXT has significance with respect to a specific OBJECT-ITEM.");

	private ContextObjectItemAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
