/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BerthMajorVesselClassCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of vessels to be serviced.";
	}

	private static HashMap<String, BerthMajorVesselClassCode> physicalToCode = new HashMap<String, BerthMajorVesselClassCode>();

	public static BerthMajorVesselClassCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BerthMajorVesselClassCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BerthMajorVesselClassCode BARGE = new BerthMajorVesselClassCode(
			"Barge",
			"BARGE",
			"A long flat-bottomed vessel for carrying freight on canals, rivers, etc.");
	public static final BerthMajorVesselClassCode BREAKBULK = new BerthMajorVesselClassCode(
			"Breakbulk",
			"BRKBLK",
			"Dry cargo-carrying vessel capable of handling break bulk cargo.");
	public static final BerthMajorVesselClassCode CONTAINER = new BerthMajorVesselClassCode(
			"Container",
			"CONTNR",
			"A vessel specially constructed and equipped to carry standard containers.");
	public static final BerthMajorVesselClassCode NOT_OTHERWISE_SPECIFIED = new BerthMajorVesselClassCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final BerthMajorVesselClassCode RORO = new BerthMajorVesselClassCode(
			"RoRo",
			"RORO",
			"Vessel 40 metres or more having capability for Roll-on / Roll-off cargo.");

	private BerthMajorVesselClassCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
