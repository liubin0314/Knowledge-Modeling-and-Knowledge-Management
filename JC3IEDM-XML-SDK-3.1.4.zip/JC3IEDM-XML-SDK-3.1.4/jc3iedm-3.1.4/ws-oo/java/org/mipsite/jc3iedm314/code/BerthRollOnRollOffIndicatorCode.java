/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BerthRollOnRollOffIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether or not the BERTH has roll on/roll off capabilities.";
	}

	private static HashMap<String, BerthRollOnRollOffIndicatorCode> physicalToCode = new HashMap<String, BerthRollOnRollOffIndicatorCode>();

	public static BerthRollOnRollOffIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BerthRollOnRollOffIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BerthRollOnRollOffIndicatorCode NO = new BerthRollOnRollOffIndicatorCode(
			"No",
			"NO",
			"Roll on / roll off capabilities are not available at the berth.");
	public static final BerthRollOnRollOffIndicatorCode YES = new BerthRollOnRollOffIndicatorCode(
			"Yes",
			"YES",
			"Roll on / roll off capabilities are available at the berth.");

	private BerthRollOnRollOffIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
