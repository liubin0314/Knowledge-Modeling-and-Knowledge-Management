/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MedicalFacilityStatusIntervalCasualtyTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the categorisation of casualties according to the type of illness or injury in a specific MEDICAL-FACILITY-STATUS-INTERVAL-CASUALTY-TYPE.";
	}

	private static HashMap<String, MedicalFacilityStatusIntervalCasualtyTypeCode> physicalToCode = new HashMap<String, MedicalFacilityStatusIntervalCasualtyTypeCode>();

	public static MedicalFacilityStatusIntervalCasualtyTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MedicalFacilityStatusIntervalCasualtyTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MedicalFacilityStatusIntervalCasualtyTypeCode BATTLE_STRESS_PSYCHIATRIC = new MedicalFacilityStatusIntervalCasualtyTypeCode(
			"Battle stress/psychiatric",
			"BTLSTR",
			"Casualties are the result of battle stress or psychiatric reasons.");
	public static final MedicalFacilityStatusIntervalCasualtyTypeCode DISEASED = new MedicalFacilityStatusIntervalCasualtyTypeCode(
			"Diseased",
			"DISEAS",
			"Casualties are the result of disease.");
	public static final MedicalFacilityStatusIntervalCasualtyTypeCode NON_BATTLE_INJURY = new MedicalFacilityStatusIntervalCasualtyTypeCode(
			"Non-battle injury",
			"NONBAT",
			"Casualties are the result of non-battle injury.");
	public static final MedicalFacilityStatusIntervalCasualtyTypeCode WOUNDED_IN_ACTION = new MedicalFacilityStatusIntervalCasualtyTypeCode(
			"Wounded in action",
			"WOUND",
			"Casualties are the result of being wounded in action.");

	private MedicalFacilityStatusIntervalCasualtyTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
