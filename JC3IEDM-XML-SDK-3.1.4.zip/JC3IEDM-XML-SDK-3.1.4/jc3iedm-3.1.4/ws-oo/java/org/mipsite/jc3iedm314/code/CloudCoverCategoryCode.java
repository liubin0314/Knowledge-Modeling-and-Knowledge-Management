/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CloudCoverCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the prevailing class of a specific CLOUD-COVER.";
	}

	private static HashMap<String, CloudCoverCategoryCode> physicalToCode = new HashMap<String, CloudCoverCategoryCode>();

	public static CloudCoverCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CloudCoverCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CloudCoverCategoryCode CLOUDS = new CloudCoverCategoryCode(
			"Clouds",
			"C",
			"A weather condition in which the sky or part of the sky is covered or partly covered by clouds.");
	public static final CloudCoverCategoryCode RADIOACTIVE_CLOUD = new CloudCoverCategoryCode(
			"Radioactive cloud",
			"RDACCL",
			"A cloud that contains the hot gases, smoke, dust and other particulate matter from the nuclear bomb itself or other sources that are carried aloft.");
	public static final CloudCoverCategoryCode SMOKE = new CloudCoverCategoryCode(
			"Smoke",
			"SMOKE",
			"A weather condition in which the sky or part of the sky is covered by smoke.");

	private CloudCoverCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
