/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStatusPlanningIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes at the reporting time whether an ACTION-TASK is completed in the planning process.";
	}

	private static HashMap<String, ActionTaskStatusPlanningIndicatorCode> physicalToCode = new HashMap<String, ActionTaskStatusPlanningIndicatorCode>();

	public static ActionTaskStatusPlanningIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStatusPlanningIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStatusPlanningIndicatorCode NO = new ActionTaskStatusPlanningIndicatorCode(
			"No",
			"NO",
			"Additional ACTION-TASKs are expected to be added or linked to this or an associated ACTION-TASK or further refinement of the specific ACTION-TASK is intended.");
	public static final ActionTaskStatusPlanningIndicatorCode YES = new ActionTaskStatusPlanningIndicatorCode(
			"Yes",
			"YES",
			"The associated ACTION-TASK specification is complete.");

	private ActionTaskStatusPlanningIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
