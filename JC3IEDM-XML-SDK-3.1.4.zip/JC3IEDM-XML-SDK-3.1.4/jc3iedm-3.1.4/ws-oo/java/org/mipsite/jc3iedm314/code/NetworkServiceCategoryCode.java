/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkServiceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a general type of service that a specific NETWORK is intended to provide.";
	}

	private static HashMap<String, NetworkServiceCategoryCode> physicalToCode = new HashMap<String, NetworkServiceCategoryCode>();

	public static NetworkServiceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkServiceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkServiceCategoryCode DATA_TRANSFER = new NetworkServiceCategoryCode(
			"Data transfer",
			"DATTRF",
			"A service for the electronic transfer of data.");
	public static final NetworkServiceCategoryCode FACSIMILE = new NetworkServiceCategoryCode(
			"Facsimile",
			"FAX",
			"A service provided by means of electronic scanning of a document, transmitting it as data by telecommunications links, and producing an exact copy at the receiver.");
	public static final NetworkServiceCategoryCode IDENTIFICATION_FRIEND_OR_FOE = new NetworkServiceCategoryCode(
			"Identification friend or foe",
			"IFF",
			"A system using electromagnetic transmissions to which equipment carried by friendly forces automatically responds, for example, by emitting pulses, thereby distinguishing themselves from enemy forces.");
	public static final NetworkServiceCategoryCode IMAGE = new NetworkServiceCategoryCode(
			"Image",
			"IMAGE",
			"A service for electronic transfer of static or slowly refreshed images.");
	public static final NetworkServiceCategoryCode MCI = new NetworkServiceCategoryCode(
			"MCI",
			"MCI",
			"MIP Common Interface service.");
	public static final NetworkServiceCategoryCode MESSAGE_HANDLING_SERVICE = new NetworkServiceCategoryCode(
			"Message handling service",
			"MHS",
			"An application service that provides a generalised facility for exchanging electronic messages between systems.");
	public static final NetworkServiceCategoryCode NOT_OTHERWISE_SPECIFIED = new NetworkServiceCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkServiceCategoryCode TACTICAL_DATA_LINK = new NetworkServiceCategoryCode(
			"Tactical data link",
			"TDL",
			"One or more data links organised within a given architecture and supporting a standard set of binary messages exchanged between users of that system, for use in military operations.");
	public static final NetworkServiceCategoryCode VIDEO_SERVICE = new NetworkServiceCategoryCode(
			"Video service",
			"VIDSVC",
			"A service for electronic transfer of video information.");
	public static final NetworkServiceCategoryCode VOICE_SERVICE = new NetworkServiceCategoryCode(
			"Voice service",
			"VOCSVC",
			"A service for electronic transfer of voice information.");

	private NetworkServiceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
