/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EngineeringCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a specific ENGINEERING-CAPABILITY in terms of a measurable quantity.";
	}

	private static HashMap<String, EngineeringCapabilityDescriptorCode> physicalToCode = new HashMap<String, EngineeringCapabilityDescriptorCode>();

	public static EngineeringCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EngineeringCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EngineeringCapabilityDescriptorCode RATE = new EngineeringCapabilityDescriptorCode(
			"Rate",
			"RATE",
			"The numeric value that denotes the rate at which an ENGINEERING-CAPABILITY of an object can be accomplished.");
	public static final EngineeringCapabilityDescriptorCode TIME = new EngineeringCapabilityDescriptorCode(
			"Time",
			"TIME",
			"The time normally required for an ENGINEERING-CAPABILITY of an object to be executed.");

	private EngineeringCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
