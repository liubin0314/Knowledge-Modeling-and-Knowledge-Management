/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeEstablishmentOperationalModeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the operational mode for which a specific OBJECT-TYPE-ESTABLISHMENT is authorised.";
	}

	private static HashMap<String, ObjectTypeEstablishmentOperationalModeCode> physicalToCode = new HashMap<String, ObjectTypeEstablishmentOperationalModeCode>();

	public static ObjectTypeEstablishmentOperationalModeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeEstablishmentOperationalModeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeEstablishmentOperationalModeCode CIVIL_SUPPORT = new ObjectTypeEstablishmentOperationalModeCode(
			"Civil support",
			"CV",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for civil support operations.");
	public static final ObjectTypeEstablishmentOperationalModeCode HUMANITARIAN_SUPPORT = new ObjectTypeEstablishmentOperationalModeCode(
			"Humanitarian support",
			"HU",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for humanitarian support operations.");
	public static final ObjectTypeEstablishmentOperationalModeCode INTERNAL_SECURITY = new ObjectTypeEstablishmentOperationalModeCode(
			"Internal security",
			"IS",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for internal security operations.");
	public static final ObjectTypeEstablishmentOperationalModeCode PEACE = new ObjectTypeEstablishmentOperationalModeCode(
			"Peace",
			"PE",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for conditions of peace.");
	public static final ObjectTypeEstablishmentOperationalModeCode PEACE_KEEPING = new ObjectTypeEstablishmentOperationalModeCode(
			"Peace keeping",
			"PK",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for peace keeping operations.");
	public static final ObjectTypeEstablishmentOperationalModeCode PEACE_SUPPORT = new ObjectTypeEstablishmentOperationalModeCode(
			"Peace support",
			"PSO",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for peace support operations.");
	public static final ObjectTypeEstablishmentOperationalModeCode WAR = new ObjectTypeEstablishmentOperationalModeCode(
			"War",
			"WA",
			"An indication that the specified OBJECT-TYPE-ESTABLISHMENT is designated for war.");

	private ObjectTypeEstablishmentOperationalModeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
