/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskTimingHourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the notional start of the ACTION in terms of an hour with defined operational meaning.";
	}

	private static HashMap<String, ActionTaskTimingHourCode> physicalToCode = new HashMap<String, ActionTaskTimingHourCode>();

	public static ActionTaskTimingHourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskTimingHourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskTimingHourCode F = new ActionTaskTimingHourCode(
			"F",
			"F",
			"The time designated for the start of cross-FLOT aviation operations.");
	public static final ActionTaskTimingHourCode G = new ActionTaskTimingHourCode(
			"G",
			"G",
			"The time on which an order (normally national) is given to deploy a unit.");
	public static final ActionTaskTimingHourCode H = new ActionTaskTimingHourCode(
			"H",
			"H",
			"1. The specific time at which an operation or exercise commences or is due to commence. It is also the time at which the Line of Departure is crossed by the leading element in an attack. 2. In amphibious operations, the time at which the first waterborne wave of an amphibious assault lands on a beach.");
	public static final ActionTaskTimingHourCode K = new ActionTaskTimingHourCode(
			"K",
			"K",
			"The time on which a convoy system is introduced or is due to be introduced on any particular land convoy route or sea convoy lane.");
	public static final ActionTaskTimingHourCode L = new ActionTaskTimingHourCode(
			"L",
			"L",
			"In amphibious or airmobile operations, the time at which the first helicopter of the heliborne assault wave touches down in the landing zone (LZ).");
	public static final ActionTaskTimingHourCode P = new ActionTaskTimingHourCode(
			"P",
			"P",
			"In airborne operations, the time at which the lead parachute element is to arrive over the parachute impact point to begin operations.");
	public static final ActionTaskTimingHourCode T = new ActionTaskTimingHourCode(
			"T",
			"T",
			"The time of Transfer of Authority.");
	public static final ActionTaskTimingHourCode Y = new ActionTaskTimingHourCode(
			"Y",
			"Y",
			"In airmobile operations the time at which the first helicopter in the first wave departs the \"Pick-up-Point\"(PUP).");

	private ActionTaskTimingHourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
