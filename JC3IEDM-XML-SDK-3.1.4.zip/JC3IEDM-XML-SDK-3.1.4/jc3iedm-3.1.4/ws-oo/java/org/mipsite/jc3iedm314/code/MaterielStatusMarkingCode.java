/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusMarkingCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of marking of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusMarkingCode> physicalToCode = new HashMap<String, MaterielStatusMarkingCode>();

	public static MaterielStatusMarkingCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusMarkingCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusMarkingCode NOT_KNOWN = new MaterielStatusMarkingCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusMarkingCode NOT_OTHERWISE_SPECIFIED = new MaterielStatusMarkingCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaterielStatusMarkingCode NUMBERS = new MaterielStatusMarkingCode(
			"Numbers",
			"NUMBER",
			"A set of integers.");
	public static final MaterielStatusMarkingCode STRIPE = new MaterielStatusMarkingCode(
			"Stripe",
			"STRIPE",
			"A long narrow band distinguished, as by colour, from the surrounding material or surface. This value includes band.");
	public static final MaterielStatusMarkingCode STRIPES = new MaterielStatusMarkingCode(
			"Stripes",
			"STRIPS",
			"Multiple long narrow bands distinguished, as by colour, from the surrounding material or surface. This value includes bands.");
	public static final MaterielStatusMarkingCode SYMBOLS = new MaterielStatusMarkingCode(
			"Symbols",
			"SYMBOL",
			"A token for identification.");
	public static final MaterielStatusMarkingCode WRITING = new MaterielStatusMarkingCode(
			"Writing",
			"WRITNG",
			"Language symbols or characters written or imprinted on a surface.");

	private MaterielStatusMarkingCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
