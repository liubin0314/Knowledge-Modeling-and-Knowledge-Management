/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionResourceEmployment extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private AngleTypeRangeAngle7_4 azimuthFireAngle; // optional
	private ActionResourceEmploymentMethodOfControlCode methodOfControlCode; // optional
	private ActionResourceEmploymentTrajectoryFireCode trajectoryFireCode; // optional
	private Ref<AbstractActionObjective> actionObjective; // optional

	// default constructor

	public AbstractActionResourceEmployment() {
		// no assignment
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractActionResourceEmployment.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractActionResourceEmployment.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public AngleTypeRangeAngle7_4 getAzimuthFireAngle() {
		return this.azimuthFireAngle;
	}

	public void setAzimuthFireAngle(AngleTypeRangeAngle7_4 azimuthFireAngle) {
		this.azimuthFireAngle = azimuthFireAngle;
	}

	public ActionResourceEmploymentMethodOfControlCode getMethodOfControlCode() {
		return this.methodOfControlCode;
	}

	public void setMethodOfControlCode(ActionResourceEmploymentMethodOfControlCode methodOfControlCode) {
		this.methodOfControlCode = methodOfControlCode;
	}

	public ActionResourceEmploymentTrajectoryFireCode getTrajectoryFireCode() {
		return this.trajectoryFireCode;
	}

	public void setTrajectoryFireCode(ActionResourceEmploymentTrajectoryFireCode trajectoryFireCode) {
		this.trajectoryFireCode = trajectoryFireCode;
	}

	public Ref<AbstractActionObjective> getActionObjective() {
		return this.actionObjective;
	}

	public void setActionObjective(Ref<AbstractActionObjective> actionObjective) {
		this.actionObjective = actionObjective;
	}
}
