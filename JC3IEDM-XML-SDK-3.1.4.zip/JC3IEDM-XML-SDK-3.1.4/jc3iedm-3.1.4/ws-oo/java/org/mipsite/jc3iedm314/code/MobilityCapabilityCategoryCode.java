/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MobilityCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MOBILITY-CAPABILITY.";
	}

	private static HashMap<String, MobilityCapabilityCategoryCode> physicalToCode = new HashMap<String, MobilityCapabilityCategoryCode>();

	public static MobilityCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MobilityCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MobilityCapabilityCategoryCode AIRBORNE = new MobilityCapabilityCategoryCode(
			"Airborne",
			"AIRBRN",
			"The capability to be employed, following transport by air, in an assault debarkation either by parachuting or touchdown.");
	public static final MobilityCapabilityCategoryCode AIR_COMPOSITE = new MobilityCapabilityCategoryCode(
			"Air, composite",
			"AIRCMP",
			"The capability to move through the air by means that combine deriving lift from fixed wings or from aerofoils that rotate.");
	public static final MobilityCapabilityCategoryCode AIR_FIXED_WING = new MobilityCapabilityCategoryCode(
			"Air, fixed wing",
			"AIRFW",
			"The capability to move through the air by deriving lift from fixed wings.");
	public static final MobilityCapabilityCategoryCode AIR_LIGHTER_THAN_AIR = new MobilityCapabilityCategoryCode(
			"Air, lighter than air",
			"AIRLGT",
			"The capability of an air vehicle to remain airborne and move by displacing a weight of air greater than its own.");
	public static final MobilityCapabilityCategoryCode AIR_ROTARY_WING = new MobilityCapabilityCategoryCode(
			"Air, rotary wing",
			"AIRRW",
			"The capability to move through the air by deriving lift from aerofoils that rotate.");
	public static final MobilityCapabilityCategoryCode AMPHIBIOUS = new MobilityCapabilityCategoryCode(
			"Amphibious",
			"AMPH",
			"The capability of a device to operate both on land and in water.");
	public static final MobilityCapabilityCategoryCode ANIMAL_MOUNTED = new MobilityCapabilityCategoryCode(
			"Animal, mounted",
			"ANIMNT",
			"The capability to move by using an animal as a carrier.");
	public static final MobilityCapabilityCategoryCode ARCTIC = new MobilityCapabilityCategoryCode(
			"Arctic",
			"ARCTIC",
			"The capability to move on or through ice.");
	public static final MobilityCapabilityCategoryCode DISMOUNTED = new MobilityCapabilityCategoryCode(
			"Dismounted",
			"DSMNTD",
			"The capability of moving on foot.");
	public static final MobilityCapabilityCategoryCode LAND_RAILED = new MobilityCapabilityCategoryCode(
			"Land, railed",
			"LNDRAI",
			"The capability of a device to move along rails.");
	public static final MobilityCapabilityCategoryCode LAND_SELF_PROPELLED = new MobilityCapabilityCategoryCode(
			"Land, self-propelled",
			"LNDSPP",
			"The capability of a device to move over land under its own power.");
	public static final MobilityCapabilityCategoryCode LAND_TRACKED = new MobilityCapabilityCategoryCode(
			"Land, tracked",
			"LNDTRC",
			"The capability of a device to move on caterpillar treads.");
	public static final MobilityCapabilityCategoryCode LAND_TOWED = new MobilityCapabilityCategoryCode(
			"Land, towed",
			"LNDTWD",
			"The capability of a device to move by means of external propulsion (mechanical or animal).");
	public static final MobilityCapabilityCategoryCode LAND_WHEELED = new MobilityCapabilityCategoryCode(
			"Land, wheeled",
			"LNDWHL",
			"The capability of a device to move on wheels.");
	public static final MobilityCapabilityCategoryCode MILITARY_LOAD_CLASSIFICATION = new MobilityCapabilityCategoryCode(
			"Military load classification",
			"MLC",
			"The characteristics, required for planning, of those CONTROL-FEATUREs, FACILITYs and MATERIELs or CONTROL-FEATURE-TYPEs, FACILITY-TYPEs and EQUIPMENT-TYPEs, and ORGANISATION-TYPEs that represents the standard system in which a route, bridge or raft is assigned class number(s) representing the load it can carry. Vehicles are also assigned number(s) indicating the minimum class of route, bridge or raft they are authorized to use.");
	public static final MobilityCapabilityCategoryCode ROAD_MARCH = new MobilityCapabilityCategoryCode(
			"Road march",
			"ROADMR",
			"The capability of a formation moving on a road.");
	public static final MobilityCapabilityCategoryCode SELF_DEPLOYABLE = new MobilityCapabilityCategoryCode(
			"Self-deployable",
			"SELFDP",
			"The capability of a device to be brought into effective action by its own means.");
	public static final MobilityCapabilityCategoryCode WATER_BAY = new MobilityCapabilityCategoryCode(
			"Water, bay",
			"WATBAY",
			"The capability of a device to navigate in bays.");
	public static final MobilityCapabilityCategoryCode WATER_CANAL = new MobilityCapabilityCategoryCode(
			"Water, canal",
			"WATCNL",
			"The capability of a device to navigate canals.");
	public static final MobilityCapabilityCategoryCode WATER_CREEK = new MobilityCapabilityCategoryCode(
			"Water, creek",
			"WATCRK",
			"The capability of a device to navigate in creeks.");
	public static final MobilityCapabilityCategoryCode WATER_FJORD = new MobilityCapabilityCategoryCode(
			"Water, fjord",
			"WATFJR",
			"The capability of a device to navigate fjords.");
	public static final MobilityCapabilityCategoryCode WATER_LAKE = new MobilityCapabilityCategoryCode(
			"Water, lake",
			"WATLAK",
			"The capability of a device to navigate lakes.");
	public static final MobilityCapabilityCategoryCode WATER_NONTIDAL = new MobilityCapabilityCategoryCode(
			"Water, nontidal",
			"WATNTD",
			"The capability of a device to navigate non-tidal waters.");
	public static final MobilityCapabilityCategoryCode WATER_RIVER = new MobilityCapabilityCategoryCode(
			"Water, river",
			"WATRVR",
			"The capability of a device to navigate rivers.");
	public static final MobilityCapabilityCategoryCode WATER_SEA = new MobilityCapabilityCategoryCode(
			"Water, sea",
			"WATSEA",
			"The capability of a device to navigate seas.");
	public static final MobilityCapabilityCategoryCode WATER_SUBSURFACE = new MobilityCapabilityCategoryCode(
			"Water, subsurface",
			"WATSUB",
			"The capability of a device to move on or under the water surface.");
	public static final MobilityCapabilityCategoryCode WATER_SURFACE = new MobilityCapabilityCategoryCode(
			"Water, surface",
			"WATSUR",
			"The capability of a device to move on the water surface.");
	public static final MobilityCapabilityCategoryCode WATER_SWAMP = new MobilityCapabilityCategoryCode(
			"Water, swamp",
			"WATSWM",
			"The capability of a device to navigate swamps.");
	public static final MobilityCapabilityCategoryCode WATER_TIDAL = new MobilityCapabilityCategoryCode(
			"Water, tidal",
			"WATTDL",
			"The capability of a device to navigate tidal waters.");

	private MobilityCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
