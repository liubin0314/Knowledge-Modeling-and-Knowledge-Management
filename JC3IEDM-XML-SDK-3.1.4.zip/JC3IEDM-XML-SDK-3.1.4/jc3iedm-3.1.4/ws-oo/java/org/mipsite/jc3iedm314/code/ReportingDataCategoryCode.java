/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents, for usual operational purposes, the nature of a specific REPORTING-DATA.";
	}

	private static HashMap<String, ReportingDataCategoryCode> physicalToCode = new HashMap<String, ReportingDataCategoryCode>();

	public static ReportingDataCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataCategoryCode ASSUMED = new ReportingDataCategoryCode(
			"Assumed",
			"ASS",
			"A REPORTING-DATA that points to data that is considered to be valid without being based on fact or observation.");
	public static final ReportingDataCategoryCode ERRONEOUS = new ReportingDataCategoryCode(
			"Erroneous",
			"ERR",
			"A REPORTING-DATA that points to data that is wrong.");
	public static final ReportingDataCategoryCode INFERRED = new ReportingDataCategoryCode(
			"Inferred",
			"INFER",
			"A REPORTING-DATA that points to data derived from multiple sources.");
	public static final ReportingDataCategoryCode PLANNED = new ReportingDataCategoryCode(
			"Planned",
			"PLAN",
			"A REPORTING-DATA that points to data expected to be true in the future.");
	public static final ReportingDataCategoryCode PREDICTED = new ReportingDataCategoryCode(
			"Predicted",
			"PRDCTD",
			"A REPORTING-DATA that points to data that results from extrapolating, estimating, or foretelling a future condition or state.");
	public static final ReportingDataCategoryCode REPORTED = new ReportingDataCategoryCode(
			"Reported",
			"REP",
			"A REPORTING-DATA that points to data based on fact or observation.");

	private ReportingDataCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
