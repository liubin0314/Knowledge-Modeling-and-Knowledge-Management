/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldStatusFlightSupportCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the capability of a specific AIRFIELD to function under defined flight rules.";
	}

	private static HashMap<String, AirfieldStatusFlightSupportCategoryCode> physicalToCode = new HashMap<String, AirfieldStatusFlightSupportCategoryCode>();

	public static AirfieldStatusFlightSupportCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldStatusFlightSupportCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldStatusFlightSupportCategoryCode IFR = new AirfieldStatusFlightSupportCategoryCode(
			"IFR",
			"IFR",
			"The specific AIRFIELD is capable of operating according to Instrument or Visual Flight Rules.");
	public static final AirfieldStatusFlightSupportCategoryCode NOT_KNOWN = new AirfieldStatusFlightSupportCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AirfieldStatusFlightSupportCategoryCode VFR = new AirfieldStatusFlightSupportCategoryCode(
			"VFR",
			"VFR",
			"The specific AIRFIELD can only operate according to Visual Flight Rules.");

	private AirfieldStatusFlightSupportCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
