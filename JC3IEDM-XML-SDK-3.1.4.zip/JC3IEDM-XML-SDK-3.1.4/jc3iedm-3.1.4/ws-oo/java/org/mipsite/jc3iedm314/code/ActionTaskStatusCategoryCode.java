/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the perceived class of a specific ACTION-TASK at a given time.";
	}

	private static HashMap<String, ActionTaskStatusCategoryCode> physicalToCode = new HashMap<String, ActionTaskStatusCategoryCode>();

	public static ActionTaskStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStatusCategoryCode ORDER = new ActionTaskStatusCategoryCode(
			"Order",
			"ORD",
			"An ACTION-TASK-STATUS indicating that the ACTION-TASK has been directed to be executed.");
	public static final ActionTaskStatusCategoryCode PLAN = new ActionTaskStatusCategoryCode(
			"Plan",
			"PLAN",
			"An ACTION-TASK-STATUS indicating that the ACTION-TASK is a plan.");

	private ActionTaskStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
