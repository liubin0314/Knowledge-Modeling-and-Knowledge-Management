/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourFireFightingIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of supplying fire-fighting facilities.";
	}

	private static HashMap<String, HarbourFireFightingIndicatorCode> physicalToCode = new HashMap<String, HarbourFireFightingIndicatorCode>();

	public static HarbourFireFightingIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourFireFightingIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourFireFightingIndicatorCode NO = new HarbourFireFightingIndicatorCode(
			"No",
			"NO",
			"The harbour is not capable of supplying fire-fighting facilities.");
	public static final HarbourFireFightingIndicatorCode YES = new HarbourFireFightingIndicatorCode(
			"Yes",
			"YES",
			"The harbour is capable of supplying fire-fighting facilities.");

	private HarbourFireFightingIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
