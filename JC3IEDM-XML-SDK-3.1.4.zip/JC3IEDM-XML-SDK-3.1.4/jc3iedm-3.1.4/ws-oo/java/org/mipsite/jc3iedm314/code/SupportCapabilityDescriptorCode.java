/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SupportCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the SUPPORT-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, SupportCapabilityDescriptorCode> physicalToCode = new HashMap<String, SupportCapabilityDescriptorCode>();

	public static SupportCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SupportCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SupportCapabilityDescriptorCode BED_COUNT = new SupportCapabilityDescriptorCode(
			"Bed count",
			"BEDCNT",
			"The numeric value denoting the number of hospital beds, fully outfitted with the necessary equipment and nursing personnel, available.");
	public static final SupportCapabilityDescriptorCode BULK_LIQUID = new SupportCapabilityDescriptorCode(
			"Bulk liquid",
			"BLKLIQ",
			"The numeric value representing the maximum amount of any unpackaged liquid.");
	public static final SupportCapabilityDescriptorCode BULK_VOLUME = new SupportCapabilityDescriptorCode(
			"Bulk volume",
			"BLKVOL",
			"The numeric value representing the maximum volume of any unpackaged mass.");
	public static final SupportCapabilityDescriptorCode MAXIMUM_COUNT = new SupportCapabilityDescriptorCode(
			"Maximum count",
			"MAXCNT",
			"The numeric value representing the maximum item count.");
	public static final SupportCapabilityDescriptorCode OPERATING_TABLE_COUNT = new SupportCapabilityDescriptorCode(
			"Operating table count",
			"OPRCNT",
			"The numeric value denoting the number of operational operating rooms, fully outfitted with the necessary equipment and surgical personnel, available to treat injuries and illness.");

	private SupportCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
