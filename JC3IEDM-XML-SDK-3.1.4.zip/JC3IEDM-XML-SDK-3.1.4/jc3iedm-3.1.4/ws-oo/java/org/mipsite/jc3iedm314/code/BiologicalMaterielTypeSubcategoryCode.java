/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BiologicalMaterielTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of a specific BIOLOGICAL-MATERIEL-TYPE.";
	}

	private static HashMap<String, BiologicalMaterielTypeSubcategoryCode> physicalToCode = new HashMap<String, BiologicalMaterielTypeSubcategoryCode>();

	public static BiologicalMaterielTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BiologicalMaterielTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BiologicalMaterielTypeSubcategoryCode CHLAMYDIA = new BiologicalMaterielTypeSubcategoryCode(
			"Chlamydia",
			"CHLMYD",
			"A very small parasitic bacterium that, like a virus, requires the biochemical mechanisms of another cell in order to reproduce.");
	public static final BiologicalMaterielTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new BiologicalMaterielTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final BiologicalMaterielTypeSubcategoryCode RICKETTSIAE = new BiologicalMaterielTypeSubcategoryCode(
			"Rickettsiae",
			"RCKETS",
			"Any of a group of very small bacteria that cause typhus and other febrile diseases.");

	private BiologicalMaterielTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
