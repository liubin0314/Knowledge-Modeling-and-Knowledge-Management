/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EngineeringEquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ENGINEERING-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, EngineeringEquipmentTypeCategoryCode> physicalToCode = new HashMap<String, EngineeringEquipmentTypeCategoryCode>();

	public static EngineeringEquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EngineeringEquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EngineeringEquipmentTypeCategoryCode BRIDGE_LAUNCHING_VEHICLE_ARMOURED = new EngineeringEquipmentTypeCategoryCode(
			"Bridge launching vehicle, armoured",
			"BRDLVA",
			"A bridge that is carried on an armoured vehicle and is deployed from the vehicle for immediate use (VBPP, AVLB).");
	public static final EngineeringEquipmentTypeCategoryCode BRIDGE_VEHICLE = new EngineeringEquipmentTypeCategoryCode(
			"Bridge vehicle",
			"BRDVEH",
			"A vehicle used to deliver a bridge.");
	public static final EngineeringEquipmentTypeCategoryCode BRIDGING = new EngineeringEquipmentTypeCategoryCode(
			"Bridging",
			"BRIDGG",
			"Equipment designed for the crossing of gaps and other obstacles.");
	public static final EngineeringEquipmentTypeCategoryCode CONSTRUCTION_VEHICLE = new EngineeringEquipmentTypeCategoryCode(
			"Construction vehicle",
			"CNSTVE",
			"A vehicle generally used in the construction trade.");
	public static final EngineeringEquipmentTypeCategoryCode CONSTRUCTION = new EngineeringEquipmentTypeCategoryCode(
			"Construction",
			"CONST",
			"An equipment used to build a facility.");
	public static final EngineeringEquipmentTypeCategoryCode CRANE = new EngineeringEquipmentTypeCategoryCode(
			"Crane",
			"CRANE",
			"A machine for raising and lowering heavy weights; in its usual form it consists of a vertical post capable of rotation on its axis, a projecting arm or 'jib' over which passes the chain or rope from which the weight is suspended, and a barrel round which the chain or rope is wound.");
	public static final EngineeringEquipmentTypeCategoryCode DITCHER = new EngineeringEquipmentTypeCategoryCode(
			"Ditcher",
			"DITCHR",
			"A machine used to make ditches.");
	public static final EngineeringEquipmentTypeCategoryCode DOZER = new EngineeringEquipmentTypeCategoryCode(
			"Dozer",
			"DOZER",
			"A heavy caterpillar tractor fitted with a broad steel blade in front, used for removing obstacles, levelling uneven surfaces, etc.");
	public static final EngineeringEquipmentTypeCategoryCode EARTHMOVER = new EngineeringEquipmentTypeCategoryCode(
			"Earthmover",
			"ERTHMV",
			"A vehicle designed for the excavation or shifting of large quantities of earth.");
	public static final EngineeringEquipmentTypeCategoryCode GRADER = new EngineeringEquipmentTypeCategoryCode(
			"Grader",
			"GRADER",
			"A wheeled machine for levelling the ground.");
	public static final EngineeringEquipmentTypeCategoryCode MECHANISED_BRIDGE_LAYER = new EngineeringEquipmentTypeCategoryCode(
			"Mechanised bridge layer",
			"MCBRLY",
			"A tracked vehicle designed to carry and lay a removable bridge.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_CLEARER = new EngineeringEquipmentTypeCategoryCode(
			"Mine clearer",
			"MINCLR",
			"A vehicle whose purpose is to remove or destroy mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_CLEARING = new EngineeringEquipmentTypeCategoryCode(
			"Mine-clearing",
			"MINECL",
			"An equipment whose purpose is to remove or destroy mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_DETECTION = new EngineeringEquipmentTypeCategoryCode(
			"Mine-detection",
			"MINEDT",
			"An equipment whose purpose is to detect the presence of mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINEFIELD_MARKING = new EngineeringEquipmentTypeCategoryCode(
			"Minefield marking",
			"MINEMR",
			"An equipment used to delimit a minefield.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_LAYING = new EngineeringEquipmentTypeCategoryCode(
			"Mine-laying",
			"MINLAY",
			"An equipment whose purpose is to lay mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_LAYER = new EngineeringEquipmentTypeCategoryCode(
			"Mine layer",
			"MINLYR",
			"A vehicle whose purpose is to lay mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_LAYER_ARMOURED_VEHICLE_MOUNTED = new EngineeringEquipmentTypeCategoryCode(
			"Mine layer, armoured vehicle mounted",
			"MNLYAR",
			"An armoured vehicle whose purpose is to lay mines.");
	public static final EngineeringEquipmentTypeCategoryCode MINE_LAYER_TRAILER_MOUNTED = new EngineeringEquipmentTypeCategoryCode(
			"Mine layer, trailer mounted",
			"MNLYTR",
			"A trailer whose purpose is to lay mines.");
	public static final EngineeringEquipmentTypeCategoryCode NOT_KNOWN = new EngineeringEquipmentTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final EngineeringEquipmentTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new EngineeringEquipmentTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final EngineeringEquipmentTypeCategoryCode PILE_DRIVER = new EngineeringEquipmentTypeCategoryCode(
			"Pile driver",
			"PILDRV",
			"A machine for driving piles into the ground, usually consisting of a heavy block of iron, suspended in a frame between two vertical guide-posts, and alternately let fall upon the pile-head, and raised by steam, manual, or other power; some, working with steam, act on the principle of the steam-hammer.");
	public static final EngineeringEquipmentTypeCategoryCode POWER_SHOVEL = new EngineeringEquipmentTypeCategoryCode(
			"Power shovel",
			"POWSHV",
			"A mechanically powered spade-like implement, consisting of a broad blade of metal or other material, attached to a handle and used for raising and removing quantities of earth, grain, coal or other loose material.");
	public static final EngineeringEquipmentTypeCategoryCode ROCK_CRUSHER = new EngineeringEquipmentTypeCategoryCode(
			"Rock crusher",
			"RCKCRH",
			"A machine used to break down rocks.");
	public static final EngineeringEquipmentTypeCategoryCode TACTICAL_FLOATING_BRIDGE = new EngineeringEquipmentTypeCategoryCode(
			"Tactical floating bridge",
			"TFBRID",
			"A bridge that can be laid on floating structure to permit crossing.");

	private EngineeringEquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
