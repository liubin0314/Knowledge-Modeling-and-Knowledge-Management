/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GroupCharacteristicMaladyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies the type of ill health, ailment or disease in a specific GROUP-CHARACTERISTIC.";
	}

	private static HashMap<String, GroupCharacteristicMaladyCode> physicalToCode = new HashMap<String, GroupCharacteristicMaladyCode>();

	public static GroupCharacteristicMaladyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GroupCharacteristicMaladyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GroupCharacteristicMaladyCode AFRICAN_TRYPANOSOMIASIS = new GroupCharacteristicMaladyCode(
			"African trypanosomiasis",
			"AFRTRP",
			"Any of several diseases caused by a trypanosome and usually transmitted by biting insects, including sleeping sickness and Chagas' disease.");
	public static final GroupCharacteristicMaladyCode AIDS_HIV = new GroupCharacteristicMaladyCode(
			"AIDS/HIV",
			"AIDS",
			"Acquired immune deficiency syndrome, a condition caused by a virus transmitted in the body fluids, marked by severe loss of resistance to infection and so ultimately fatal.");
	public static final GroupCharacteristicMaladyCode AMEBIASIS_AMOEBIC_DYSENTRY = new GroupCharacteristicMaladyCode(
			"Amebiasis/Amoebic dysentry",
			"AMBDYS",
			"An acute inflammatory amebiasis of the colon, marked by severe pain and diarrhoea and caused by the amoeba Entamoeba Histolytica.");
	public static final GroupCharacteristicMaladyCode ANTHRAX = new GroupCharacteristicMaladyCode(
			"Anthrax",
			"ANTHRX",
			"A bacterial disease caused by the spore-forming Bacillus anthracis, a Gram positive, rod-shaped bacterium. There are 3 types of anthrax in humans: cutaneous anthrax, acquired when a spore enters the skin through a cut or an abrasion; gastrointestinal tract anthrax, contracted from eating contaminated food, primarily meat from an animal that died of the disease; and pulmonary (inhalation) anthrax from breathing in airborne anthrax spores.");
	public static final GroupCharacteristicMaladyCode ANTIMICROBIAL_RESISTANCE = new GroupCharacteristicMaladyCode(
			"Antimicrobial resistance",
			"ANTMRS",
			"Antimicrobial resistance, a condition encouraged by agricultural and animal uses of drugs and is due to under-use of drugs in poorer countries and over-use in wealthy countries.");
	public static final GroupCharacteristicMaladyCode ARBOVIRUS_INFECTION_NEC = new GroupCharacteristicMaladyCode(
			"Arbovirus infection (NEC)",
			"ARBVRS",
			"Viruses that are maintained in nature principally, or to an important extent, through biological transmission between susceptible vertebrate hosts by haematophagous arthropods; they multiply and produce viraemia in the vertebrates, multiply in the tissues of arthropods and are passed on to the new vertebrates by the bites of arthropod after a period of extrinsic incubation. Examples are Dengue and Yellow Fever.");
	public static final GroupCharacteristicMaladyCode BOTULISM = new GroupCharacteristicMaladyCode(
			"Botulism",
			"BOTULM",
			"Botulism is an intoxication caused by extremely potent toxins produced by the bacterium Clostridium botulinum preformed in foods.");
	public static final GroupCharacteristicMaladyCode BRUCELLOSIS = new GroupCharacteristicMaladyCode(
			"Brucellosis",
			"BRUCLS",
			"A disease caused by bacteria of the genus Brucella usually transmitted from animals to man through ingestion, contact, inhalation or inoculation.");
	public static final GroupCharacteristicMaladyCode BURULI_ULCER = new GroupCharacteristicMaladyCode(
			"Buruli ulcer",
			"BURULI",
			"A Mycobacterium ulcerans, whose source is unknown, that causes painless swelling in the skin and causes severely deforming ulcers.");
	public static final GroupCharacteristicMaladyCode CAMPYLOBACTER = new GroupCharacteristicMaladyCode(
			"Campylobacter",
			"CAMPLB",
			"Campylobacters are bacteria that are a major cause of diarrhoeal illness in humans and are generally regarded as the most common bacterial cause of gastroenteritis worldwide. Campylobacteriosis is the disease caused by the presence of campylobacters.");
	public static final GroupCharacteristicMaladyCode CHAGAS_DISEASE = new GroupCharacteristicMaladyCode(
			"Chagas disease",
			"CHAGAS",
			"A disease caused by trypanosomes transmitted by bloodsucking bugs, endemic in S. America and causing damage to the heart and central nervous system.");
	public static final GroupCharacteristicMaladyCode CHANCROID = new GroupCharacteristicMaladyCode(
			"Chancroid",
			"CHANCR",
			"A genital ulcer disease caused by the Gram-negative bacillus H. ducreyi and results in superficial ulcerations, often with suppurant regional lymphadenopathy.");
	public static final GroupCharacteristicMaladyCode CHICKEN_POX = new GroupCharacteristicMaladyCode(
			"Chicken pox",
			"CHCKPX",
			"An acute contagious viral disease, usually of young children, characterised by skin eruption and a slight fever.");
	public static final GroupCharacteristicMaladyCode CHLAMYDIA = new GroupCharacteristicMaladyCode(
			"Chlamydia",
			"CHLMDA",
			"A virus-like bacterium of the genus Chlamydia, which comprises Gram-negative coccoids that reproduce as intracellular parasites in vertebrates and occasionally anthropods and is classified as a major cause of sexually transmited diseases (STDs).");
	public static final GroupCharacteristicMaladyCode CHOLERA_EPIDEMIC_DYSENTERY = new GroupCharacteristicMaladyCode(
			"Cholera/epidemic dysentery",
			"CHOLRA",
			"An infectious and often fatal disease of the small intestine caused by the mainly water-borne bacterium Vibrio cholerae, resulting in severe vomiting and diarrhoea.");
	public static final GroupCharacteristicMaladyCode COCCIDIOIDOMYCOSIS = new GroupCharacteristicMaladyCode(
			"Coccidioidomycosis",
			"COCCID",
			"A fungus disease that usually affects the lungs of humans and other animals, caused by the fungus Coccidioides immitis.");
	public static final GroupCharacteristicMaladyCode CROUP = new GroupCharacteristicMaladyCode(
			"Croup",
			"CROUP",
			"Croup is a viral infection that causes a brassy, barking cough in young children.");
	public static final GroupCharacteristicMaladyCode CRYPTOSPORIDOIOSIS = new GroupCharacteristicMaladyCode(
			"Cryptosporidoiosis",
			"CRYPTS",
			"A diarrhoeal disease caused by a microscopic parasite, Cryptosporidium parvum. It is one of the most common causes of waterborne disease (drinking and recreational) in humans.");
	public static final GroupCharacteristicMaladyCode CYCLOSPORA = new GroupCharacteristicMaladyCode(
			"Cyclospora",
			"CYCLSP",
			"A parasite composed of one cell, too small to be seen without a microscope. Cyclospora is spread by people ingesting something, for example, water or food that was contaminated with infected stool.");
	public static final GroupCharacteristicMaladyCode DENGUE = new GroupCharacteristicMaladyCode(
			"Dengue",
			"DENGUE",
			"An infectious viral disease of the tropics, transmitted by mosquitoes and causing a fever and acute pains in the joints.");
	public static final GroupCharacteristicMaladyCode DIPTHERIA = new GroupCharacteristicMaladyCode(
			"Diptheria",
			"DIPTHR",
			"Diphtheria is a bacterial infection caused by Corynebacterium diphtheriae, and can occur as a toxic or nontoxic strain. It spreads through close contact with a person infected with diphtheria.");
	public static final GroupCharacteristicMaladyCode DONOVANOSIS = new GroupCharacteristicMaladyCode(
			"Donovanosis",
			"DONOVA",
			"A chronic, slowly progressive, mildly contagious disease of venereal origin, characterized by granulomatous ulceration of the genitalia and neighboring sites, with little or no tendency to spontaneous healing.");
	public static final GroupCharacteristicMaladyCode DRACUNCULIASIS = new GroupCharacteristicMaladyCode(
			"Dracunculiasis",
			"DRACUN",
			"A parasitic disease caused by the parasitic worm Drarunculus medinensis or \"guinea worm\".");
	public static final GroupCharacteristicMaladyCode E_COLI_0157_H7_VEROTOXIGENIC_E_COLI = new GroupCharacteristicMaladyCode(
			"E. Coli 0157:H7/verotoxigenic E Coli",
			"ECOLI",
			"A strain of the bacterium Escherichia coli that produces a powerful toxin and can cause severe illness. The infection often causes severe bloody diarrhoea and abdominal cramps; sometimes the infection causes non-bloody diarrhoea or no symptoms. Usually little or no fever is present, and the illness resolves in 5 to 10 days.");
	public static final GroupCharacteristicMaladyCode EHRLICHIOSIS = new GroupCharacteristicMaladyCode(
			"Ehrlichiosis",
			"EHRLCH",
			"A tick borne disease caused by several bacterial species in the genus Ehrlichia, characterized by fever and swollen lymph nodes.");
	public static final GroupCharacteristicMaladyCode ENCEPHALITIS = new GroupCharacteristicMaladyCode(
			"Encephalitis",
			"ENCPHL",
			"Viruses that are maintained in nature through biological transmission between susceptible vertebrate hosts by blood feeding arthropods (mosquitoes, psychodids, ceratopogonids, and ticks) usually resulting in a brain inflammation.");
	public static final GroupCharacteristicMaladyCode ERYSIPELAS = new GroupCharacteristicMaladyCode(
			"Erysipelas",
			"ERYSPL",
			"A streptococcal infection of the skin and subcutaneous tissue caused by a streptococcus and marked by spreading inflammation.");
	public static final GroupCharacteristicMaladyCode FILARIASIS = new GroupCharacteristicMaladyCode(
			"Filariasis",
			"FILARS",
			"A tropical disease caused by the presence of filarial worms esp. in the lymph vessels.");
	public static final GroupCharacteristicMaladyCode GASTROENTERITIS_UNDER_2S_ONLY = new GroupCharacteristicMaladyCode(
			"Gastroenteritis (under 2s only)",
			"GASTRE",
			"A rotavirus infection of the stomach and small and large intestines caused by a variety of viruses that results in vomiting or diarrhoea.");
	public static final GroupCharacteristicMaladyCode GIARDIASIS = new GroupCharacteristicMaladyCode(
			"Giardiasis",
			"GIARDS",
			"A diarrhoeal disease caused by a microscopic parasite, Giardia intestinalis that lives in the intestine of people and animals. It is one of the most common causes of waterborne disease (drinking and recreational) in humans.");
	public static final GroupCharacteristicMaladyCode GONORRHEA = new GroupCharacteristicMaladyCode(
			"Gonorrhea",
			"GONORH",
			"Gonorrhea, a common sexually transmitted disease (STD), is caused by Neisseria gonorrhoeae, a bacterium that can grow and multiply easily in mucous membranes of the body.");
	public static final GroupCharacteristicMaladyCode H_INFLUENZAE_INVASIVE = new GroupCharacteristicMaladyCode(
			"H. influenzae, invasive",
			"HINFLZ",
			"A bacterial infection and one of the leading causes of bacterial meningitis in children under 5 years of age.");
	public static final GroupCharacteristicMaladyCode HANTAVIRUS_INFECTION = new GroupCharacteristicMaladyCode(
			"Hantavirus infection",
			"HANTAV",
			"Hantaviruses are carried by rodents, especially the deer mouse. You can become infected by exposure to their droppings, and the first signs of sickness (especially fever and muscle aches) appear 1 to 5 weeks later, followed by shortness of breath and coughing. Once this phase begins, the disease progresses rapidly, necessitating hospitalisation and often ventilation within 24 hours.");
	public static final GroupCharacteristicMaladyCode HEMORRHAGIC_FEVER = new GroupCharacteristicMaladyCode(
			"Hemorrhagic fever",
			"HEMRHG",
			"A severe multisystem syndrome (multisystem in that multiple organ systems in the body are affected).� Characteristically, the overall vascular system is damaged, and the body's ability to regulate itself is impaired.� These symptoms are often accompanied by hemorrhage (bleeding); however, the bleeding is itself rarely life-threatening.");
	public static final GroupCharacteristicMaladyCode HEPATITIS_A = new GroupCharacteristicMaladyCode(
			"Hepatitis A",
			"HEPATA",
			"A liver disease caused by the hepatitis A virus (HAV).");
	public static final GroupCharacteristicMaladyCode HEPATITIS_B = new GroupCharacteristicMaladyCode(
			"Hepatitis B",
			"HEPATB",
			"A serious disease caused by a virus that attacks the liver. The virus, which is called hepatitis B virus (HBV), can cause lifelong infection, cirrhosis (scarring) of the liver, liver cancer, liver failure, and death.");
	public static final GroupCharacteristicMaladyCode HEPATITIS_C = new GroupCharacteristicMaladyCode(
			"Hepatitis C",
			"HEPATC",
			"A liver disease caused by the Hepatitis C virus (HCV), which is found in the blood of persons who have the disease. HCV is spread by contact with the blood of an infected person.");
	public static final GroupCharacteristicMaladyCode HIV_INFECTION = new GroupCharacteristicMaladyCode(
			"HIV infection",
			"HIV",
			"Human Immunodeficiency Virus, either of 2 retroviruses (HIV-1, HIV-2) that causes AIDS.");
	public static final GroupCharacteristicMaladyCode HUMAN_MONKEYPOX = new GroupCharacteristicMaladyCode(
			"Human monkeypox",
			"HMNMPX",
			"A rare smallpox like disease acquired from monkeys or squirrels but does occasionally spread from man to man in unvaccinated communities.");
	public static final GroupCharacteristicMaladyCode HYDATID_INFECTION = new GroupCharacteristicMaladyCode(
			"Hydatid infection",
			"HYDATD",
			"A disease that results from being infected with the larval stage of Echinococcus multilocularis, a microscopic tapeworm (1-4 millimeters) found in foxes, coyotes, dogs, and cats.");
	public static final GroupCharacteristicMaladyCode INFECTIVE_ENTERITIS = new GroupCharacteristicMaladyCode(
			"Infective enteritis",
			"INFENT",
			"An intestinal inflammation.");
	public static final GroupCharacteristicMaladyCode INFLUENZA = new GroupCharacteristicMaladyCode(
			"Influenza",
			"INFLUN",
			"A highly contagious virus infection causing fever, severe aching, and catarrh, often occurring in epidemics.");
	public static final GroupCharacteristicMaladyCode LEGIONELLOSIS = new GroupCharacteristicMaladyCode(
			"Legionellosis",
			"LEGION",
			"An infection caused by the bacterium Legionella pneumophila usually transmitted by mists that come from a water source (e.g., air conditioning cooling towers, whirlpool spas, showers) contaminated with Legionella bacteria.");
	public static final GroupCharacteristicMaladyCode LEISHMANIASIS = new GroupCharacteristicMaladyCode(
			"Leishmaniasis",
			"LSHMNA",
			"Any of several diseases caused by parasitic protozoans of the genus Leishmania transmitted by the bite of sandflies.");
	public static final GroupCharacteristicMaladyCode LEISHMANIASIS_CUTANEOUS = new GroupCharacteristicMaladyCode(
			"Leishmaniasis, cutaneous",
			"LSHMNC",
			"A disease, resulting in skin sores, caused by the parasitic protozoans of the genus Leishmania transmitted by sand flies.");
	public static final GroupCharacteristicMaladyCode LEISHMANIASIS_MUCOCUTANEOUS = new GroupCharacteristicMaladyCode(
			"Leishmaniasis, mucocutaneous",
			"LSHMNM",
			"A disease, resulting in sores around the nose or mouth, caused by the parasitic protozoans of the genus Leishmania transmitted by sand flies.");
	public static final GroupCharacteristicMaladyCode LEISHMANIASIS_VISCERAL = new GroupCharacteristicMaladyCode(
			"Leishmaniasis, visceral",
			"LSHMNV",
			"A disease, resulting in damage to some of the internal organs of the body (for example, spleen, liver, bone marrow), caused by the parasitic protozoans of the genus Leishmania transmitted by sand flies.");
	public static final GroupCharacteristicMaladyCode LEPROSY = new GroupCharacteristicMaladyCode(
			"Leprosy",
			"LEPRSY",
			"A contagious bacterial disease that affects the skin, mucous membranes, and nerves, causing disfigurement.");
	public static final GroupCharacteristicMaladyCode LEPTOSPIROSIS = new GroupCharacteristicMaladyCode(
			"Leptospirosis",
			"LEPTOS",
			"Leptospirosis is a bacterial disease that affects humans and animals. It is caused by bacteria of the genus Leptospira found in water contaminated with the urine of infected animals.");
	public static final GroupCharacteristicMaladyCode LISTERIOSIS = new GroupCharacteristicMaladyCode(
			"Listeriosis",
			"LISTRS",
			"A serious infection caused by eating food contaminated with the bacterium Listeria monocytogenes.");
	public static final GroupCharacteristicMaladyCode LYME_DISEASE = new GroupCharacteristicMaladyCode(
			"Lyme disease",
			"LYME",
			"An infectious disease caused by the bacterium, Borrelia burgdorferi, transmitted by the bite of infected deer ticks.");
	public static final GroupCharacteristicMaladyCode LYMPHOGRANULOMA_VENEREUM = new GroupCharacteristicMaladyCode(
			"Lymphogranuloma venereum",
			"LYMPHG",
			"A disease, caused by infection with L1, L2, or L3 serovars of Chlamydia trachomatis, usually sexually transmitted, characterized by genital lesions, suppurative regional lymphadenopathy, or hemorrhagic proctitis.");
	public static final GroupCharacteristicMaladyCode MALARIA = new GroupCharacteristicMaladyCode(
			"Malaria",
			"MALARA",
			"An intermittent and remittent fever caused by a protozoan parasite of the genus Plasmodium, introduced by the bite of a mosquito.");
	public static final GroupCharacteristicMaladyCode MEASLES = new GroupCharacteristicMaladyCode(
			"Measles",
			"MEASLS",
			"An acute infectious viral disease marked by red spots on the skin.");
	public static final GroupCharacteristicMaladyCode MENINGITIS = new GroupCharacteristicMaladyCode(
			"Meningitis",
			"MENING",
			"An infection of the fluid of a person's spinal cord and the fluid that surrounds the brain.");
	public static final GroupCharacteristicMaladyCode MENINGITIS_ENCEPHALIS_VIRAL = new GroupCharacteristicMaladyCode(
			"Meningitis/encephalis viral",
			"MENNGE",
			"An infection of the fluid of a person's spinal cord and the fluid that surrounds the brain usually caused by a viral infection.");
	public static final GroupCharacteristicMaladyCode MENINGITIS_OTHER_BACTERIAL = new GroupCharacteristicMaladyCode(
			"Meningitis, other bacterial",
			"MENNGO",
			"An infection of the fluid of a person's spinal cord and the fluid that surrounds the brain usually caused by a bacterial infection.");
	public static final GroupCharacteristicMaladyCode MENINGITIS_PNEUMONOCOCCAL = new GroupCharacteristicMaladyCode(
			"Meningitis, pneumonococcal",
			"MENNGP",
			"An infection of the fluid of a person's spinal cord and the fluid that surrounds the brain usually caused by a Streptococcus pneumoniae bacteria.");
	public static final GroupCharacteristicMaladyCode MENINGOCOCCAL_DISEASE = new GroupCharacteristicMaladyCode(
			"Meningococcal disease",
			"MNNGOC",
			"An infection of the fluid of a person's spinal cord and the fluid that surrounds the brain usually caused by a Neisseria meningitidis bacteria.");
	public static final GroupCharacteristicMaladyCode MUMPS = new GroupCharacteristicMaladyCode(
			"Mumps",
			"MUMPS",
			"An acute viral illness acquired by respiratory droplets.");
	public static final GroupCharacteristicMaladyCode ORNITHOSIS = new GroupCharacteristicMaladyCode(
			"Ornithosis",
			"ORNTHS",
			"An illness characterized by fever, chills, headache, photophobia, cough, and myalgia.");
	public static final GroupCharacteristicMaladyCode PARATYPHOID_FEVER = new GroupCharacteristicMaladyCode(
			"Paratyphoid fever",
			"PRTPHY",
			"An acute intestinal disease that resembles typhoid fever and is caused by any of three bacteria of the genus Salmonella.");
	public static final GroupCharacteristicMaladyCode PERTUSSIS = new GroupCharacteristicMaladyCode(
			"Pertussis",
			"PRTUSS",
			"An acute infectious disease (Whooping Cough) caused by the bacterium Bordetella pertussis, a small aerobic gram-negative rod.");
	public static final GroupCharacteristicMaladyCode PLAGUE = new GroupCharacteristicMaladyCode(
			"Plague",
			"PLAGUE",
			"A contagious bacterial disease characterized by fever and delirium, with the formation of buboes (bubonic plague) and sometimes infection of the lungs (pneumonic plague).");
	public static final GroupCharacteristicMaladyCode PNEUMONIA_PNEUMOCOCCAL = new GroupCharacteristicMaladyCode(
			"Pneumonia, pneumococcal",
			"PNEUMO",
			"A disease that results from the infection of the air passages and lungs by certain germs.");
	public static final GroupCharacteristicMaladyCode POLIOMYELITIS = new GroupCharacteristicMaladyCode(
			"Poliomyelitis",
			"POLIO",
			"Acute onset of a flaccid paralysis of one or more limbs with decreased or absent tendon reflexes in the affected limbs, without other apparent cause, and without sensory or cognitive loss.");
	public static final GroupCharacteristicMaladyCode PUERPERAL_FEVER = new GroupCharacteristicMaladyCode(
			"Puerperal fever",
			"PUERPL",
			"An infection of the genital tract and of the blood stream after birth.");
	public static final GroupCharacteristicMaladyCode Q_FEVER = new GroupCharacteristicMaladyCode(
			"Q fever",
			"QFEVER",
			"A zoonotic disease caused by Coxiella burnetii, a species of bacteria that is distributed globally.");
	public static final GroupCharacteristicMaladyCode RABIES_HUMAN = new GroupCharacteristicMaladyCode(
			"Rabies, human",
			"RABIES",
			"A contagious and fatal viral disease of dogs and other mammals, transmissible through the saliva to humans etc. and causing madness and convulsions; hydrophobia.");
	public static final GroupCharacteristicMaladyCode RELAPSING_FEVER = new GroupCharacteristicMaladyCode(
			"Relapsing fever",
			"RLPSNG",
			"An infection caused by the spirochetes Borrelia hermsii and B. turicatae and is transmitted to humans principally by the bites of the infected ticks.");
	public static final GroupCharacteristicMaladyCode RHEUMATIC_FEVER_ACUTE = new GroupCharacteristicMaladyCode(
			"Rheumatic fever, acute",
			"RHEUMA",
			"An inflammatory illness that occurs as a delayed sequela of group A streptococcal infection.");
	public static final GroupCharacteristicMaladyCode RIFT_VALLEY_FEVER = new GroupCharacteristicMaladyCode(
			"Rift valley fever",
			"RIFTVF",
			"An acute, fever-causing viral disease that affects domestic animals (such as cattle, buffalo, sheep, goats, and camels) and humans. RVF is most commonly associated with mosquito-borne epidemics during years of unusually heavy rainfall.");
	public static final GroupCharacteristicMaladyCode ROCKY_MOUNTAIN_SPOTTED_FEVER = new GroupCharacteristicMaladyCode(
			"Rocky mountain spotted fever",
			"RCKYMT",
			"A rickettsial illness caused by Rickettsia rickettsii, a species of bacteria that is spread to humans by ixodid (hard) ticks.");
	public static final GroupCharacteristicMaladyCode ROSS_RIVER_VIRUS_INFECTION = new GroupCharacteristicMaladyCode(
			"Ross river virus infection",
			"ROSSRV",
			"A mosquito borne virus found only in Australia.");
	public static final GroupCharacteristicMaladyCode RUBELLA = new GroupCharacteristicMaladyCode(
			"Rubella",
			"RUBELA",
			"A virus, also referred to as German Measles, classified as a togavirus, genus Rubivirus.");
	public static final GroupCharacteristicMaladyCode RUBELLA_CONGENITAL = new GroupCharacteristicMaladyCode(
			"Rubella, congenital",
			"RUBELC",
			"A Rubella infection characterized by congenital cataracts in infants born following maternal rubella infection in early pregnancy.");
	public static final GroupCharacteristicMaladyCode SALMONELLOSIS = new GroupCharacteristicMaladyCode(
			"Salmonellosis",
			"SALMNL",
			"An infection with a bacterium called Salmonella usually acquired from contaminated food, water, or contact with infected animals.");
	public static final GroupCharacteristicMaladyCode SEPTICEMIA = new GroupCharacteristicMaladyCode(
			"Septicemia",
			"SEPTCM",
			"A systematic disease caused by pathogenic organisms or other toxins in the bloodstream.");
	public static final GroupCharacteristicMaladyCode SCARLET_FEVER = new GroupCharacteristicMaladyCode(
			"Scarlet fever",
			"SCRLET",
			"A disease caused by a bacteria called group A streptococcus, usually transmitted by contact with the sick person because this germ is carried in the mouth and nasal fluids.");
	public static final GroupCharacteristicMaladyCode SCHISTOSOMIASIS_INTESTINAL_PARASITES = new GroupCharacteristicMaladyCode(
			"Schistosomiasis/intestinal parasites",
			"SCHSTO",
			"A parasitic tropical flatworm of the genus Schistosoma, carried by freshwater snails and infesting the blood vessels of birds and mammals, causing bilharzia in humans.");
	public static final GroupCharacteristicMaladyCode SEVERE_ACUTE_RESPIRATORY_SYNDROME_SARS = new GroupCharacteristicMaladyCode(
			"Severe acute respiratory syndrome (SARS)",
			"SARS",
			"A respiratory illness spread by direct close person-to-person contact with infectious material (for example, respiratory secretions) from a person who has SARS.");
	public static final GroupCharacteristicMaladyCode SEXUALLY_TRANSMITTED_INFECTIONS = new GroupCharacteristicMaladyCode(
			"Sexually transmitted infections",
			"SXLTRN",
			"Any of various diseases contracted chiefly by sexual intercourse with a person already infected; a sexually transmitted disease.");
	public static final GroupCharacteristicMaladyCode SHIGELLOSIS = new GroupCharacteristicMaladyCode(
			"Shigellosis",
			"SHGLLS",
			"An infectious disease caused by a group of bacteria called Shigella, usually passing from person to person from stools or soiled fingers of one person to the mouth of another person.");
	public static final GroupCharacteristicMaladyCode SMALLPOX = new GroupCharacteristicMaladyCode(
			"Smallpox",
			"SMLLPX",
			"An infectious disease caused by the variola virus usually transmitted from person to person or through direct contact with infected bodily fluids or contaminated objects such as bedding or clothing.");
	public static final GroupCharacteristicMaladyCode STREPTOCOCCUS_GROUP_A_INVASIVE = new GroupCharacteristicMaladyCode(
			"Streptococcus, group A, invasive",
			"STREPT",
			"A bacterium often found in the throat and on the skin and spread through direct contact with mucus from the nose or throat of persons who are infected or through contact with infected wounds or sores on the skin.");
	public static final GroupCharacteristicMaladyCode SYPHILIS_ALL = new GroupCharacteristicMaladyCode(
			"Syphilis (All)",
			"SYPHLA",
			"A complex sexually transmitted disease (STD) caused by the bacterium Treponema pallidum usually passed from person to person through direct contact with a syphilis sore. Sores occur mainly on the external genitals, vagina, anus, or in the rectum.");
	public static final GroupCharacteristicMaladyCode SYPHILIS_CONGENITAL = new GroupCharacteristicMaladyCode(
			"Syphilis, congenital",
			"SYPHLC",
			"A condition caused by infection in utero with Treponema pallidum. The infection of an infant whose mother had untreated or inadequately treated syphilis at delivery.");
	public static final GroupCharacteristicMaladyCode SYPHILIS_EARLY_SYMPTOMATIC = new GroupCharacteristicMaladyCode(
			"Syphilis, early symptomatic",
			"SYPHLE",
			"A subcategory of latent syphilis. When initial infection has occurred within the previous 12 months, latent syphilis is classified as early latent.");
	public static final GroupCharacteristicMaladyCode SYPHILIS_LATENT = new GroupCharacteristicMaladyCode(
			"Syphilis, latent",
			"SYPHLL",
			"A stage of infection caused by T. pallidum in which organisms persist in the body of the infected person without causing symptoms or signs.");
	public static final GroupCharacteristicMaladyCode SYPHILIS_PRIMARY_SECONDARY = new GroupCharacteristicMaladyCode(
			"Syphilis, primary/secondary",
			"SYPHLP",
			"A stage of infection with Treponema pallidum characterized by one or more chancres (ulcers); chancres might differ considerably in clinical appearance and by localized or diffuse mucocutaneous lesions, often with generalized lymphadenopathy.");
	public static final GroupCharacteristicMaladyCode TETANUS = new GroupCharacteristicMaladyCode(
			"Tetanus",
			"TETANS",
			"An acute, often fatal, disease caused by exotoxin produced by Clostridium tetani. Spores are widely distributed in soil and in the intestines and feces of some animals. Usually enters the body through a wound.");
	public static final GroupCharacteristicMaladyCode TOXIC_SHOCK_SYNDROME = new GroupCharacteristicMaladyCode(
			"Toxic shock syndrome",
			"TOXSHK",
			"A toxin caused syndrome manifested by sudden onset of fever, chills, vomiting, diarrhoea, muscle pains and rash associated with use of tampons and intravaginal contraceptive devices in women and occurs as a complication of skin abscesses or surgery.");
	public static final GroupCharacteristicMaladyCode TOXOPLASMOSIS = new GroupCharacteristicMaladyCode(
			"Toxoplasmosis",
			"TOXPLS",
			"An infection caused by a single-celled parasite called Toxoplasma gondii, usually resulting from accidental ingestion of contaminated cat feces, or ingestion of raw or partly cooked meat, especially pork, lamb, or venison, or by touching your hands to your mouth after handling undercooked meat, or through contamination of knives, utensils, cutting boards and other foods that have had contact with raw meat.");
	public static final GroupCharacteristicMaladyCode TRANSMISSIBLE_SPONGIFORM_ENCEPHALOPATHIES = new GroupCharacteristicMaladyCode(
			"Transmissible spongiform encephalopathies",
			"TRNSSP",
			"A disease of the brain.");
	public static final GroupCharacteristicMaladyCode TRICHINOSIS = new GroupCharacteristicMaladyCode(
			"Trichinosis",
			"TRCHNS",
			"Caused by eating raw or undercooked pork and wild game products infected with the larvae of a species of worm called Trichinella.");
	public static final GroupCharacteristicMaladyCode TRYPANOSOMIASIS = new GroupCharacteristicMaladyCode(
			"Trypanosomiasis",
			"TRYPNS",
			"A parasite �Trypanosoma brucei rhodesiense� transmitted disease (Sleeping Sickness) caused by the bite of the Tsetse fly.");
	public static final GroupCharacteristicMaladyCode TUBERCULOSIS_PULMONARY = new GroupCharacteristicMaladyCode(
			"Tuberculosis, pulmonary",
			"TUBERC",
			"A disease caused by bacteria called Mycobacterium tuberculosis. The bacteria can attack any part of your body, but they usually attack the lungs. It is spread through the air from one person to another.");
	public static final GroupCharacteristicMaladyCode TULAREMIA = new GroupCharacteristicMaladyCode(
			"Tularemia",
			"TULARM",
			"An infectious disease caused by a hardy bacterium, Francisella tularensis, found in animals (especially rodents, rabbits, and hares). It is contracted through the bite of an infected insect or other arthropod (usually a tick or deerfly), handling infected animal carcasses, eating or drinking contaminated food or water, or breathing in F. tularensis.");
	public static final GroupCharacteristicMaladyCode TYPHOID_FEVER = new GroupCharacteristicMaladyCode(
			"Typhoid fever",
			"TYPHOD",
			"A life-threatening illness caused by the bacterium Salmonella Typhi, that lives only in humans. It can be contracted if you eat food or drink beverages that have been handled by a person who is shedding S. Typhi or if sewage contaminated with S. Typhi bacteria gets into the water you use for drinking or washing food.");
	public static final GroupCharacteristicMaladyCode TYPHUS_FEVER = new GroupCharacteristicMaladyCode(
			"Typhus fever",
			"TYPHUS",
			"Any of several forms of an infectious disease caused by micro-organisms of the genus Rickettsia, especially when flea-borne as in endemic typhus, louse-borne as in epidemic typhus, or mite-borne as in scrub typhus.");
	public static final GroupCharacteristicMaladyCode URETHRITIS_NON_GONOCOCCAL = new GroupCharacteristicMaladyCode(
			"Urethritis, non-gonococcal",
			"URTHRT",
			"Urethral inflammation that is not the result of infection with Neisseria gonorrhoeae.");
	public static final GroupCharacteristicMaladyCode VARICELLA_ACTIVE_DUTY_ONLY = new GroupCharacteristicMaladyCode(
			"Varicella, active duty only",
			"VARCLL",
			"A virus of the herpes family that can result in bacterial infection of the skin, swelling of the brain, and pneumonia. It is spread by coughing and sneezing (highly contagious).");
	public static final GroupCharacteristicMaladyCode VIRAL_HAEMORRAGIC_FEVERS_NOT_OTHERWISE_SPECIFIED = new GroupCharacteristicMaladyCode(
			"Viral haemorragic fevers, not otherwise specified",
			"VRHAEM",
			"A group of illnesses that are caused by several distinct families of viruses. In general, the term \"viral hemorrhagic fever\" is used to describe a severe multisystem syndrome.");
	public static final GroupCharacteristicMaladyCode WATER_BORNE_ILLNESS_2_OR_MORE_RELATED_CASES = new GroupCharacteristicMaladyCode(
			"Water-borne illness (2 or more related cases)",
			"WTRBRN",
			"A range of syndromes, including acute dehydrating diarrhoea (cholera), prolonged febrile illness with abdominal symptoms (typhoid fever), acute bloody diarrhoea (dysentery), and chronic diarrhoea (Brainerd diarrhoea). Usually caused by contaminated surface water sources and large poorly functioning municipal water distribution systems.");
	public static final GroupCharacteristicMaladyCode YELLOW_FEVER = new GroupCharacteristicMaladyCode(
			"Yellow fever",
			"YELLWF",
			"A tropical virus disease with fever and jaundice, transmitted by the mosquito and often fatal.");
	public static final GroupCharacteristicMaladyCode YERSINOSIS_NEC = new GroupCharacteristicMaladyCode(
			"Yersinosis (NEC)",
			"YERSNS",
			"An infectious disease caused by a bacterium of the genus Yersinia usually acquired by eating contaminated food, especially raw or undercooked pork products.");
	public static final GroupCharacteristicMaladyCode NOT_OTHERWISE_SPECIFIED = new GroupCharacteristicMaladyCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private GroupCharacteristicMaladyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
