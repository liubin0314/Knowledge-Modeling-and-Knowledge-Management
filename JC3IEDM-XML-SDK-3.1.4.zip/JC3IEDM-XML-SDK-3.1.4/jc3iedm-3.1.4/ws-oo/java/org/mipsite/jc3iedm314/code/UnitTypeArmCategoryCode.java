/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeArmCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the designation of a military branch for a particular UNIT-TYPE.";
	}

	private static HashMap<String, UnitTypeArmCategoryCode> physicalToCode = new HashMap<String, UnitTypeArmCategoryCode>();

	public static UnitTypeArmCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeArmCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeArmCategoryCode ANTI_ARMOUR = new UnitTypeArmCategoryCode(
			"Anti-armour",
			"AARMOR",
			"A UNIT-TYPE whose principal designation is the employment of direct fire weapon systems against armoured vehicles.");
	public static final UnitTypeArmCategoryCode ADMINISTRATIVE = new UnitTypeArmCategoryCode(
			"Administrative",
			"ADMIN",
			"A UNIT-TYPE whose principal designation the management and execution of all military matters not included in strategy or tactics.");
	public static final UnitTypeArmCategoryCode AIR_DEFENCE = new UnitTypeArmCategoryCode(
			"Air defence",
			"AIRDEF",
			"A UNIT-TYPE whose principal designation is the employment of weapon systems against hostile air assets.");
	public static final UnitTypeArmCategoryCode ARMOURED_ANTI_ARMOUR = new UnitTypeArmCategoryCode(
			"Armoured anti armour",
			"ARMANT",
			"A UNIT-TYPE equipped with armoured vehicles whose principal designation is the employment of direct fire weapon systems against armoured vehicles.");
	public static final UnitTypeArmCategoryCode ARMOUR = new UnitTypeArmCategoryCode(
			"Armour",
			"ARMOUR",
			"A UNIT-TYPE whose principal designation is the employment of tanks or other armoured direct fire weapon systems.");
	public static final UnitTypeArmCategoryCode ARTILLERY = new UnitTypeArmCategoryCode(
			"Artillery",
			"ARTLRY",
			"A UNIT-TYPE whose principal designation is the employment of large guns, cannon or ordnance in support of manoeuvre units.");
	public static final UnitTypeArmCategoryCode AVIATION = new UnitTypeArmCategoryCode(
			"Aviation",
			"AV",
			"A UNIT-TYPE whose principal designation is the employment of aircraft capable of performing a variety of battlespace functions, including reconnaissance, air operations, and tactical lift.");
	public static final UnitTypeArmCategoryCode AVIATION_COMPOSITE = new UnitTypeArmCategoryCode(
			"Aviation, composite",
			"AVACOM",
			"A UNIT-TYPE whose designation indicates employment of a mix of fixed wing, rotary wing and/or VSTOL aircraft.");
	public static final UnitTypeArmCategoryCode AVIATION_FIXED_WING = new UnitTypeArmCategoryCode(
			"Aviation, fixed wing",
			"AVAFW",
			"A UNIT-TYPE whose designation indicates employment of fixed-wing assets in the air regime.");
	public static final UnitTypeArmCategoryCode AVIATION_ROTARY_WING = new UnitTypeArmCategoryCode(
			"Aviation, rotary wing",
			"AVARW",
			"A UNIT-TYPE whose designation indicates employment of rotary-wing assets in the air regime.");
	public static final UnitTypeArmCategoryCode AVIATION_VSTOL = new UnitTypeArmCategoryCode(
			"Aviation, VSTOL",
			"AVAVST",
			"A UNIT-TYPE whose designation indicates employment of vertical/short takeoff and landing assets in the air regime.");
	public static final UnitTypeArmCategoryCode NBC = new UnitTypeArmCategoryCode(
			"NBC",
			"CBRN",
			"A UNIT-TYPE whose principal designation is chemical, biological, radiological, or nuclear materiel defence.");
	public static final UnitTypeArmCategoryCode ENGINEER = new UnitTypeArmCategoryCode(
			"Engineer",
			"ENG",
			"A UNIT-TYPE whose principal designation is major construction, demolition, and extensive camouflage projects.");
	public static final UnitTypeArmCategoryCode EXPLOSIVE_ORDNANCE_DISPOSAL = new UnitTypeArmCategoryCode(
			"Explosive ordnance disposal",
			"EOD",
			"A UNIT-TYPE whose principal designation is the detection, identification, field evaluation, rendering-safe, recovery and final disposal of unexploded explosive ordnance.");
	public static final UnitTypeArmCategoryCode FIELD_ARTILLERY = new UnitTypeArmCategoryCode(
			"Field artillery",
			"FA",
			"A UNIT-TYPE whose principal designation is the employment of tube artillery in support of manoeuvre units.");
	public static final UnitTypeArmCategoryCode FIRE_SUPPORT = new UnitTypeArmCategoryCode(
			"Fire support",
			"FIRSPT",
			"A UNIT-TYPE whose principal designation is the employment of fire, coordinated with the manoeuvre of forces, to destroy neutralize or suppress the enemy.");
	public static final UnitTypeArmCategoryCode HEADQUARTERS_AND_SIGNALS = new UnitTypeArmCategoryCode(
			"Headquarters and signals",
			"HQSIGS",
			"A UNIT-TYPE whose principal designation is to provide staff and communication equipment to set up a command and control element.");
	public static final UnitTypeArmCategoryCode HEADQUARTERS_STAFF = new UnitTypeArmCategoryCode(
			"Headquarters staff",
			"HQSTF",
			"A UNIT-TYPE whose principal designation is to provide staff to man a command and control element.");
	public static final UnitTypeArmCategoryCode INFANTRY = new UnitTypeArmCategoryCode(
			"Infantry",
			"INF",
			"A UNIT-TYPE whose principal designation is the employment of non-mechanised or lorry-(truck-)borne infantry.");
	public static final UnitTypeArmCategoryCode INFORMATION_WARFARE = new UnitTypeArmCategoryCode(
			"Information warfare",
			"INFWAR",
			"A UNIT-TYPE whose principal designation is to achieve information superiority by affecting a hostile's information, information-based processes and information systems, while defending one's own information, information-based processes and information systems.");
	public static final UnitTypeArmCategoryCode INTERNAL_SECURITY_FORCES = new UnitTypeArmCategoryCode(
			"Internal security forces",
			"ISFRCE",
			"A UNIT-TYPE whose principal designation is maintenance of a state of law and order prevailing within a nation.");
	public static final UnitTypeArmCategoryCode LAW_ENFORCEMENT = new UnitTypeArmCategoryCode(
			"Law enforcement",
			"LAWENF",
			"A UNIT-TYPE whose principal designation is the provision of law enforcement services.");
	public static final UnitTypeArmCategoryCode LANDING_SUPPORT = new UnitTypeArmCategoryCode(
			"Landing support",
			"LNDSPT",
			"A UNIT-TYPE whose principal designation is the provision of landing support services.");
	public static final UnitTypeArmCategoryCode LOGISTICS = new UnitTypeArmCategoryCode(
			"Logistics",
			"LOG",
			"A UNIT-TYPE whose principal designation is the planning and support of the movement and maintenance of forces.");
	public static final UnitTypeArmCategoryCode MAINTENANCE = new UnitTypeArmCategoryCode(
			"Maintenance",
			"MAINT",
			"A UNIT-TYPE whose principal designation is the repair and maintenance of equipment.");
	public static final UnitTypeArmCategoryCode MANOEUVRE = new UnitTypeArmCategoryCode(
			"Manoeuvre",
			"MANOV",
			"A UNIT-TYPE whose principal designation is the employment of forces in the battlespace through movement in combination with fire, or fire potential, to achieve a position of advantage in respect to the enemy in order to accomplish the mission.");
	public static final UnitTypeArmCategoryCode MEDICAL = new UnitTypeArmCategoryCode(
			"Medical",
			"MEDCL",
			"A UNIT-TYPE whose principal designation is the provision of medical and dental services and the evacuation of casualties.");
	public static final UnitTypeArmCategoryCode MILITARY_INTELLIGENCE = new UnitTypeArmCategoryCode(
			"Military intelligence",
			"MILINT",
			"A UNIT-TYPE whose principal designation is the processing of information concerning foreign nations, hostile or potentially hostile forces or elements, or areas of actual or potential operations.");
	public static final UnitTypeArmCategoryCode MISSILE_SURFACE_TO_SURFACE = new UnitTypeArmCategoryCode(
			"Missile, surface-to-surface",
			"MSL",
			"A UNIT-TYPE whose principal designation is the employment of surface-based missiles to fire at surface targets.");
	public static final UnitTypeArmCategoryCode MISSILE_SURFACE_TO_AIR = new UnitTypeArmCategoryCode(
			"Missile, surface-to-air",
			"MSLSTA",
			"A UNIT-TYPE whose principal designation is the employment of surface-based missiles to fire at air targets.");
	public static final UnitTypeArmCategoryCode NOT_KNOWN = new UnitTypeArmCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final UnitTypeArmCategoryCode NOT_OTHERWISE_SPECIFIED = new UnitTypeArmCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final UnitTypeArmCategoryCode RECONNAISSANCE = new UnitTypeArmCategoryCode(
			"Reconnaissance",
			"RECCE",
			"A UNIT-TYPE whose principal designation is to obtain, by visual observation or other detection methods, information about the activities and resources of an enemy or potential enemy; or to secure data concerning the meteorological, hydrographic, or geographic characteristics of a particular area.");
	public static final UnitTypeArmCategoryCode ROCKET = new UnitTypeArmCategoryCode(
			"Rocket",
			"ROCKET",
			"A UNIT-TYPE whose principal designation is the employment of rockets in support of manoeuvre units.");
	public static final UnitTypeArmCategoryCode SIGNAL = new UnitTypeArmCategoryCode(
			"Signal",
			"SIG",
			"A UNIT-TYPE whose principal designation is the provision of communications bearer systems.");
	public static final UnitTypeArmCategoryCode SUPPLY = new UnitTypeArmCategoryCode(
			"Supply",
			"SUPPLY",
			"A UNIT-TYPE whose principal designation is the provision of all material and items used in the equipping, supporting and maintaining of military forces.");
	public static final UnitTypeArmCategoryCode TRANSPORTATION = new UnitTypeArmCategoryCode(
			"Transportation",
			"TRNPTN",
			"A UNIT-TYPE whose principal designation is the provision of transport for assets.");
	public static final UnitTypeArmCategoryCode TRANSPORTATION_AND_SUPPLY = new UnitTypeArmCategoryCode(
			"Transportation and supply",
			"TRSSUP",
			"A UNIT-TYPE whose principal designation is the provision of transport for assets and the distribution of supplies.");

	private UnitTypeArmCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
