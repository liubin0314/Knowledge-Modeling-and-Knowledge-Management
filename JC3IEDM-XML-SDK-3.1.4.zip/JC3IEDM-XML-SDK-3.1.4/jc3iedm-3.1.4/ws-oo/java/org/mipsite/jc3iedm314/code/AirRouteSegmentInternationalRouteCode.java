/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirRouteSegmentInternationalRouteCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the domestic/international status of the AIR-ROUTE-SEGMENT.";
	}

	private static HashMap<String, AirRouteSegmentInternationalRouteCode> physicalToCode = new HashMap<String, AirRouteSegmentInternationalRouteCode>();

	public static AirRouteSegmentInternationalRouteCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirRouteSegmentInternationalRouteCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirRouteSegmentInternationalRouteCode DOMESTIC = new AirRouteSegmentInternationalRouteCode(
			"Domestic",
			"DOMSTC",
			"The AIR-ROUTE-SEGMENT is domestic.");
	public static final AirRouteSegmentInternationalRouteCode INTERNATIONAL = new AirRouteSegmentInternationalRouteCode(
			"International",
			"INTERN",
			"The AIR-ROUTE-SEGMENT is international.");

	private AirRouteSegmentInternationalRouteCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
