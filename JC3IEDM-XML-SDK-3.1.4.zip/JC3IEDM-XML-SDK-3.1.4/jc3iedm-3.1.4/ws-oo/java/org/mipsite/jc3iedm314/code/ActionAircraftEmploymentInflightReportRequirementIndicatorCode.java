/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionAircraftEmploymentInflightReportRequirementIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether there is a requirement for the flight leader to provide a report of mission accomplishments.";
	}

	private static HashMap<String, ActionAircraftEmploymentInflightReportRequirementIndicatorCode> physicalToCode = new HashMap<String, ActionAircraftEmploymentInflightReportRequirementIndicatorCode>();

	public static ActionAircraftEmploymentInflightReportRequirementIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionAircraftEmploymentInflightReportRequirementIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionAircraftEmploymentInflightReportRequirementIndicatorCode NO = new ActionAircraftEmploymentInflightReportRequirementIndicatorCode(
			"No",
			"NO",
			"The flight leader is not to provide a report of mission accomplishments.");
	public static final ActionAircraftEmploymentInflightReportRequirementIndicatorCode YES = new ActionAircraftEmploymentInflightReportRequirementIndicatorCode(
			"Yes",
			"YES",
			"The flight leader is to provide a report of mission accomplishments.");

	private ActionAircraftEmploymentInflightReportRequirementIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
