/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskEndQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the role of ending date and time with respect to the period of effectiveness of a specific ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskEndQualifierCode> physicalToCode = new HashMap<String, ActionTaskEndQualifierCode>();

	public static ActionTaskEndQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskEndQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskEndQualifierCode AFTER = new ActionTaskEndQualifierCode(
			"After",
			"AFT",
			"Time intended is later than the time specified.");
	public static final ActionTaskEndQualifierCode AS_SOON_AS_POSSIBLE = new ActionTaskEndQualifierCode(
			"As soon as possible",
			"ASAP",
			"End the activity at the earliest possible time once execution is authorised.");
	public static final ActionTaskEndQualifierCode AS_SOON_AS_POSSIBLE_AFTER = new ActionTaskEndQualifierCode(
			"As soon as possible after",
			"ASAPAF",
			"End the activity at the earliest possible time after the specified end time.");
	public static final ActionTaskEndQualifierCode AS_SOON_AS_POSSIBLE_NOT_LATER_THAN = new ActionTaskEndQualifierCode(
			"As soon as possible not later than",
			"ASAPNL",
			"End the activity at the earliest possible time but not later than the specified end time.");
	public static final ActionTaskEndQualifierCode AT = new ActionTaskEndQualifierCode(
			"At",
			"AT",
			"Time intended is the time specified.");
	public static final ActionTaskEndQualifierCode BEFORE = new ActionTaskEndQualifierCode(
			"Before",
			"BEF",
			"Time intended is in advance of the time specified.");
	public static final ActionTaskEndQualifierCode INDEFINITE = new ActionTaskEndQualifierCode(
			"Indefinite",
			"INDEF",
			"Time is unlimited.");
	public static final ActionTaskEndQualifierCode NO_LATER_THAN = new ActionTaskEndQualifierCode(
			"No later than",
			"NLT",
			"Time specified is the latest.");
	public static final ActionTaskEndQualifierCode NOT_BEFORE = new ActionTaskEndQualifierCode(
			"Not before",
			"NOB",
			"Time specified is the earliest.");
	public static final ActionTaskEndQualifierCode TO_BE_DETERMINED = new ActionTaskEndQualifierCode(
			"To be determined",
			"TBD",
			"Time intended to be determined later.");
	public static final ActionTaskEndQualifierCode UNKNOWN = new ActionTaskEndQualifierCode(
			"Unknown",
			"UNK",
			"Time intended is not known.");
	public static final ActionTaskEndQualifierCode UNTIL_FURTHER_NOTICE = new ActionTaskEndQualifierCode(
			"Until further notice",
			"UNTFRN",
			"Continue the activity unless it is specifically authorised to stop.");

	private ActionTaskEndQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
