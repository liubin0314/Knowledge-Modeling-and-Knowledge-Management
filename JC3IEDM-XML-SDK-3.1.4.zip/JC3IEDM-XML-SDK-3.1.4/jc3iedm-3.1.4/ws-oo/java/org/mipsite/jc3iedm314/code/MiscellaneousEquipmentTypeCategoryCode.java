/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MiscellaneousEquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MISCELLANEOUS-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, MiscellaneousEquipmentTypeCategoryCode> physicalToCode = new HashMap<String, MiscellaneousEquipmentTypeCategoryCode>();

	public static MiscellaneousEquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MiscellaneousEquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MiscellaneousEquipmentTypeCategoryCode AGRICULTURAL_MATERIAL = new MiscellaneousEquipmentTypeCategoryCode(
			"Agricultural material",
			"AGRCTL",
			"Equipment specifically designed to be used for an agricultural purpose.");
	public static final MiscellaneousEquipmentTypeCategoryCode AIR_COMPRESSOR = new MiscellaneousEquipmentTypeCategoryCode(
			"Air compressor",
			"AIRCMP",
			"A machine for compressing air for use as a motive power.");
	public static final MiscellaneousEquipmentTypeCategoryCode AIRCRAFT_REFUELLING = new MiscellaneousEquipmentTypeCategoryCode(
			"Aircraft refuelling",
			"AIRREF",
			"Equipment designed to facilitate aerial refuelling.");
	public static final MiscellaneousEquipmentTypeCategoryCode AIR_OBSTRUCTION_LIGHTING = new MiscellaneousEquipmentTypeCategoryCode(
			"Air-obstruction lighting",
			"AROBSL",
			"A lighting system put on top of a vertical obstacle to air navigation.");
	public static final MiscellaneousEquipmentTypeCategoryCode BEACON_LIGHT = new MiscellaneousEquipmentTypeCategoryCode(
			"Beacon, light",
			"BCNLGT",
			"A light that is used for the determination of bearings, courses, or locations.");
	public static final MiscellaneousEquipmentTypeCategoryCode BINOCULARS = new MiscellaneousEquipmentTypeCategoryCode(
			"Binoculars",
			"BINOCL",
			"A field-glass in the use of which both eyes are employed in viewing an object.");
	public static final MiscellaneousEquipmentTypeCategoryCode BOTTLE = new MiscellaneousEquipmentTypeCategoryCode(
			"Bottle",
			"BOTTLE",
			"A container with a narrow neck, used for storing liquids, or a large metal cylinder holding liquefied gas.");
	public static final MiscellaneousEquipmentTypeCategoryCode CABLE = new MiscellaneousEquipmentTypeCategoryCode(
			"Cable",
			"CABLE",
			"A strong thick rope of hemp or wire.");
	public static final MiscellaneousEquipmentTypeCategoryCode CABLE_REEL = new MiscellaneousEquipmentTypeCategoryCode(
			"Cable, reel",
			"CABLER",
			"A large roll of strong thick rope of hemp or wire wound onto a drum or spindle.");
	public static final MiscellaneousEquipmentTypeCategoryCode CONTAINER_DELIVERY_SYSTEM = new MiscellaneousEquipmentTypeCategoryCode(
			"Container delivery system",
			"CNTDLS",
			"A system for aerial delivery of supplies and small items of equipment from low or high altitudes into a small area.");
	public static final MiscellaneousEquipmentTypeCategoryCode CONTAINER = new MiscellaneousEquipmentTypeCategoryCode(
			"Container",
			"CONTNR",
			"A receptacle in which material is held or carried.");
	public static final MiscellaneousEquipmentTypeCategoryCode DECOY = new MiscellaneousEquipmentTypeCategoryCode(
			"Decoy",
			"DECOY",
			"An imitation in any sense of a person, object or phenomenon which is intended to deceive enemy surveillance devices or mislead enemy evaluation.");
	public static final MiscellaneousEquipmentTypeCategoryCode DEMOLITION_EQUIPMENT = new MiscellaneousEquipmentTypeCategoryCode(
			"Demolition equipment",
			"DEMOEQ",
			"Equipment specifically designed to be used in executing demolition tasks.");
	public static final MiscellaneousEquipmentTypeCategoryCode DISPENSER = new MiscellaneousEquipmentTypeCategoryCode(
			"Dispenser",
			"DSPNSR",
			"A device that is used to carry and release submunitions.");
	public static final MiscellaneousEquipmentTypeCategoryCode ELECTRONIC_MEDIA_DETACHED_PHYSICAL_STORAGE = new MiscellaneousEquipmentTypeCategoryCode(
			"Electronic media, detached physical storage",
			"ELCMED",
			"A discrete physical storage device (e.g., CD, DVD, USB stick, etc.).");
	public static final MiscellaneousEquipmentTypeCategoryCode FILM = new MiscellaneousEquipmentTypeCategoryCode(
			"Film",
			"FILM",
			"A thin flexible transparent material for recording imagery.");
	public static final MiscellaneousEquipmentTypeCategoryCode FLAG = new MiscellaneousEquipmentTypeCategoryCode(
			"Flag",
			"FLAG",
			"A piece of bunting or other material usually oblong or square attached by one edge to a staff or pole and fixed to a float, mine, buoy in order to mark its location.");
	public static final MiscellaneousEquipmentTypeCategoryCode GENERATOR = new MiscellaneousEquipmentTypeCategoryCode(
			"Generator",
			"GENER",
			"An apparatus for the production of electricity.");
	public static final MiscellaneousEquipmentTypeCategoryCode GUIDANCE = new MiscellaneousEquipmentTypeCategoryCode(
			"Guidance",
			"GUIDNC",
			"Equipment used to show the way or direct movement.");
	public static final MiscellaneousEquipmentTypeCategoryCode HAZARD_LIGHT = new MiscellaneousEquipmentTypeCategoryCode(
			"Hazard light",
			"HAZLGT",
			"A light source that is designed to identify the source or location of a hazard.");
	public static final MiscellaneousEquipmentTypeCategoryCode HOUSEHOLD_HARDWARE = new MiscellaneousEquipmentTypeCategoryCode(
			"Household hardware",
			"HOUSHD",
			"Goods and utensils such as locks, tools, and cutlery and other items used within a domestic unit.");
	public static final MiscellaneousEquipmentTypeCategoryCode LAMP = new MiscellaneousEquipmentTypeCategoryCode(
			"Lamp",
			"LAMP",
			"An equipment that is used to provide light to illuminate the location of an equipment, e.g a buoy.");
	public static final MiscellaneousEquipmentTypeCategoryCode LOW_ALTITUDE_PARACHUTE_EXTRACTION_SYSTEM = new MiscellaneousEquipmentTypeCategoryCode(
			"Low altitude parachute extraction system",
			"LAPSE",
			"A low-level, self-contained system capable of delivering heavy loads into an area where air landing is not feasible from an optimum aircraft wheel altitude of 5 to 10 feet above ground level.");
	public static final MiscellaneousEquipmentTypeCategoryCode LINE = new MiscellaneousEquipmentTypeCategoryCode(
			"Line",
			"LINE",
			"A piece of rope, cord, wire serving a special purpose.");
	public static final MiscellaneousEquipmentTypeCategoryCode MAGNETIC_TAPE = new MiscellaneousEquipmentTypeCategoryCode(
			"Magnetic tape",
			"MAGTPE",
			"A tape coated or impregnated with a magnetic material or made of magnetic material intended for data recording.");
	public static final MiscellaneousEquipmentTypeCategoryCode MARKER = new MiscellaneousEquipmentTypeCategoryCode(
			"Marker",
			"MARKER",
			"A visual or electronic aid used to mark a designated point or area.");
	public static final MiscellaneousEquipmentTypeCategoryCode MACHINERY = new MiscellaneousEquipmentTypeCategoryCode(
			"Machinery",
			"MCHNRY",
			"Machines or machine parts in general.");
	public static final MiscellaneousEquipmentTypeCategoryCode MEGAPHONE = new MiscellaneousEquipmentTypeCategoryCode(
			"Megaphone",
			"MEGPHN",
			"A non-electronic instrument for carrying sound a long distance.");
	public static final MiscellaneousEquipmentTypeCategoryCode NOT_KNOWN = new MiscellaneousEquipmentTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MiscellaneousEquipmentTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new MiscellaneousEquipmentTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MiscellaneousEquipmentTypeCategoryCode PAPER = new MiscellaneousEquipmentTypeCategoryCode(
			"Paper",
			"PAPER",
			"A substance composed of fibres for writing, printing or drawing on.");
	public static final MiscellaneousEquipmentTypeCategoryCode PHOTOGRAPHIC = new MiscellaneousEquipmentTypeCategoryCode(
			"Photographic",
			"PHOTOG",
			"Equipment associated with photography.");
	public static final MiscellaneousEquipmentTypeCategoryCode PRINTING_MACHINE = new MiscellaneousEquipmentTypeCategoryCode(
			"Printing machine",
			"PRTMAC",
			"A machine capable of printing documents");
	public static final MiscellaneousEquipmentTypeCategoryCode ROPE = new MiscellaneousEquipmentTypeCategoryCode(
			"Rope",
			"ROPE",
			"A piece of stout cord made of twisted strands of hemp, sisal, cotton, nylon, wire or other similar material.");
	public static final MiscellaneousEquipmentTypeCategoryCode SIGNAL_LIGHT = new MiscellaneousEquipmentTypeCategoryCode(
			"Signal light",
			"SIGLGT",
			"A light source designed to be used for communication using a predefined code system of on and off flashes.");
	public static final MiscellaneousEquipmentTypeCategoryCode SMOKE_GENERATOR = new MiscellaneousEquipmentTypeCategoryCode(
			"Smoke generator",
			"SMKGEN",
			"A system used to generate smoke in the battlespace.");
	public static final MiscellaneousEquipmentTypeCategoryCode SEARCHLIGHT = new MiscellaneousEquipmentTypeCategoryCode(
			"Searchlight",
			"SRCHLT",
			"An electric arc-lamp fitted with a reflector and suspended in a frame so that it may throw a beam of light in any desired direction; used in naval defence and for signalling purposes, etc.");
	public static final MiscellaneousEquipmentTypeCategoryCode TANK = new MiscellaneousEquipmentTypeCategoryCode(
			"Tank",
			"TANK",
			"A large receptacle or storage chamber, especially for liquid or gas.");
	public static final MiscellaneousEquipmentTypeCategoryCode TOOL = new MiscellaneousEquipmentTypeCategoryCode(
			"Tool",
			"TOOL",
			"A thing with which some operation is performed; a means of effecting something; an instrument.");

	private MiscellaneousEquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
