/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of NETWORK.";
	}

	private static HashMap<String, NetworkCategoryCode> physicalToCode = new HashMap<String, NetworkCategoryCode>();

	public static NetworkCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkCategoryCode BROADCAST = new NetworkCategoryCode(
			"Broadcast",
			"BRDCST",
			"A broadcast network used to transport voice and/or data.");
	public static final NetworkCategoryCode MULTICAST = new NetworkCategoryCode(
			"Multicast",
			"MLTCST",
			"A mode of transmission where information is conveyed from one sender to a determined number of receivers");
	public static final NetworkCategoryCode NOT_KNOWN = new NetworkCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NetworkCategoryCode NOT_OTHERWISE_SPECIFIED = new NetworkCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkCategoryCode POINT_TO_POINT = new NetworkCategoryCode(
			"Point-to-point",
			"PTTOPT",
			"A transmission where information is transferred between two nodes.");

	private NetworkCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
