/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusMineDetectionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of the means of detection of a mine in a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusMineDetectionCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusMineDetectionCode>();

	public static MinefieldMaritimeStatusMineDetectionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusMineDetectionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusMineDetectionCode SIGHTED = new MinefieldMaritimeStatusMineDetectionCode(
			"Sighted",
			"SGHTD",
			"The location of mines in the lane swept by visual means.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ACOUSTIC_AF = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept acoustic, AF",
			"SWACAF",
			"The location of mines by use of a sweep designed to operate the acoustic firing system of a mine, audio frequency.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ACOUSTIC_COMBINED = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept acoustic, combined",
			"SWACCO",
			"The location of mines by use of a sweep designed to operate the acoustic firing system of a mine, MF and LF frequency 30 to 15000HZ.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ACOUSTIC_EXPLOSIVE = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept acoustic, explosive",
			"SWACEX",
			"The location of mines by use of a sweep using the detonation of explosive charges to actuate the acoustic sensors in the mine.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ACOUSTIC_INFLUENCE = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept acoustic, influence",
			"SWACIN",
			"The location of mines by acoustic detonation of sea mines by the generation of underwater acoustic noise.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ACOUSTIC_LF = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept acoustic, LF",
			"SWACLF",
			"The location of mines by use of a sweep designed to operate the acoustic firing system of a mine, low frequency, up to 30Hz.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_BOTTOM_TEAM_SWEEP = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, bottom team sweep",
			"SWBTTS",
			"The location of on the liquid bottom surface by use of divers working as a co-ordinated search group.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_CIRCULAR_SNAGLINE_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, circular snagline search",
			"SWCRSS",
			"The location of mines by use of a circular snagline search by divers.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_DIVING = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, diving",
			"SWDVNG",
			"The location of mines by divers entering the water to neutralize/destroy mines.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_ENCLOSED_WATERGRID_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, enclosed watergrid search",
			"SWENWS",
			"The location of mines by use of an enclosed water grid search.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_JACKSTAY_SNAGLINE_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, jackstay snagline search",
			"SWJASS",
			"The location of mines by use of a jackstay snagline search by divers.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MAGNETIC_CLOSED_LOOP = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept magnetic, closed loop",
			"SWMACL",
			"The location of mines by use of a conducting cable, loop shaped through which is passed a high current, towed behind a minesweeper.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MAGNETIC_INFLUENCE = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept magnetic, influence",
			"SWMAIN",
			"A sweep designed to locate the mine by operating the magnetic firing system of a mine.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_ANTENNA = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, antenna",
			"SWMEAN",
			"The location of mines in the lane swept with either a single or multiple ship rig and is designed to ensure that the sweep wire is not brought into contact with the mines antenna until the mine is a safe distance astern.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical",
			"SWMECH",
			"The location of mines in the lane swept by mechanical means.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_CHAIN = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, chain",
			"SWMECN",
			"The location of mines in the lane swept by mechanical means, chains, normally fixed between two or more minesweeping vessels, dragged across the sea bed.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MAGNETIC_ELECTRODE = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept magnetic, electrode",
			"SWMEEL",
			"The location of mines by use of two buoyant conducting cables, an electrode fitted between each leg, the electrical circuit being completed through the seawater.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_NET = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, net",
			"SWMENE",
			"The location of mines in the lane swept by mechanical means, nets normally fixed between two or more minesweeping vessels.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MAGNETIC_OPEN_LOOP = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept magnetic, open loop",
			"SWMEOL",
			"The location of mines by use of a conducting cable, open loop shaped through which is passed a high current, towed behind a minesweeper.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_OROPESA = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, oropesa",
			"SWMEOR",
			"The location of mines that consists of sweep wires streamed one or both quarters, with a kite to keep them down to a set depth astern of the ship and otters controlled by floats to spread the wires horizontally apart.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_SNAGLINE = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, snagline",
			"SWMESN",
			"The location of mines by use of a wire to catch the snagline of a moored mine.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MAGNETIC_SOLENOID = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept magnetic, solenoid",
			"SWMESO",
			"The location of mines by use of large number of horizontal coils through which a small current is passed.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_MECHANICAL_TEAM = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept mechanical, team",
			"SWMETE",
			"The location of mines by towing either a mechanical or influence gear through the liquid with the intention of cutting or destruction of mines. Sweep wire towed between two or more ships using only kites to keep the sweep down.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_PROGRESSIVE_GRID_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, progressive grid search",
			"SWPRGS",
			"The location of mines by use of a progressive grid search.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_RUNNING_JACKSTAY_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, running jackstay search",
			"SWRNJS",
			"The location of mines by use of a running jackstay search, diver(s).");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_SONAR_SEARCH = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, sonar search",
			"SWSNSE",
			"The location of mines by usage of sonar equipment.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_TOWED_FREE_DIVER = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, towed free diver",
			"SWTWFD",
			"The location of mines by use of a towed free diver.");
	public static final MinefieldMaritimeStatusMineDetectionCode SWEPT_UNDERWATER_SLED = new MinefieldMaritimeStatusMineDetectionCode(
			"Swept, underwater sled",
			"SWUNDS",
			"The location of mines by use of an underwater sled, diver.");

	private MinefieldMaritimeStatusMineDetectionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
