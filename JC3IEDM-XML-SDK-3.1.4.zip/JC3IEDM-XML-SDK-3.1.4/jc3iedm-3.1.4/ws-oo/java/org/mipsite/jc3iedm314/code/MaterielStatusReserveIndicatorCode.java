/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusReserveIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific MATERIEL has been placed in reserve.";
	}

	private static HashMap<String, MaterielStatusReserveIndicatorCode> physicalToCode = new HashMap<String, MaterielStatusReserveIndicatorCode>();

	public static MaterielStatusReserveIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusReserveIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusReserveIndicatorCode NO = new MaterielStatusReserveIndicatorCode(
			"No",
			"NO",
			"The specific MATERIEL is not in reserve status.");
	public static final MaterielStatusReserveIndicatorCode YES = new MaterielStatusReserveIndicatorCode(
			"Yes",
			"YES",
			"The specific MATERIEL is currently in reserve status.");

	private MaterielStatusReserveIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
