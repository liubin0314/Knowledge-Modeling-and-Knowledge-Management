/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataCredibilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents, for normal operational use, the degree of trustworthiness of the data referenced by a specific REPORTING-DATA.";
	}

	private static HashMap<String, ReportingDataCredibilityCode> physicalToCode = new HashMap<String, ReportingDataCredibilityCode>();

	public static ReportingDataCredibilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataCredibilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataCredibilityCode INDETERMINATE = new ReportingDataCredibilityCode(
			"Indeterminate",
			"IND",
			"Basis for the estimate cannot be ascertained.");
	public static final ReportingDataCredibilityCode REPORTED_AS_A_FACT = new ReportingDataCredibilityCode(
			"Reported as a fact",
			"RPTFCT",
			"Data is reported by different sources whose integrity is not in question.");
	public static final ReportingDataCredibilityCode REPORTED_AS_PLAUSIBLE = new ReportingDataCredibilityCode(
			"Reported as plausible",
			"RPTPLA",
			"Reported data is considered as possible or probable.");
	public static final ReportingDataCredibilityCode REPORTED_AS_UNCERTAIN = new ReportingDataCredibilityCode(
			"Reported as uncertain",
			"RPTUNC",
			"Reported data is open to or can be viewed with suspicion.");

	private ReportingDataCredibilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
