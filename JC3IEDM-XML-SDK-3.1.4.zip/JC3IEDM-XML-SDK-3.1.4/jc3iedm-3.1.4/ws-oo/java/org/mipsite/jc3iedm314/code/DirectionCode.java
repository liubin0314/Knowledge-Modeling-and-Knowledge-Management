/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class DirectionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a specific direction.";
	}

	private static HashMap<String, DirectionCode> physicalToCode = new HashMap<String, DirectionCode>();

	public static DirectionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<DirectionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final DirectionCode ALL_DIRECTIONS = new DirectionCode(
			"All directions",
			"ALL",
			"In any or all directions at one time.");
	public static final DirectionCode EAST = new DirectionCode(
			"East",
			"E",
			"The cardinal point at 90 degrees to True North.");
	public static final DirectionCode EAST_NORTHEAST = new DirectionCode(
			"East Northeast",
			"ENE",
			"The specific direction midway between East and Northeast referenced to True North.");
	public static final DirectionCode EAST_SOUTHEAST = new DirectionCode(
			"East Southeast",
			"ESE",
			"The specific direction midway between East and Southeast referenced to True North.");
	public static final DirectionCode NORTH = new DirectionCode(
			"North",
			"N",
			"The cardinal point at 0 degree to True North.");
	public static final DirectionCode NORTHEAST = new DirectionCode(
			"Northeast",
			"NE",
			"The cardinal point at 45 degrees to True North.");
	public static final DirectionCode NORTH_NORTHEAST = new DirectionCode(
			"North Northeast",
			"NNE",
			"The specific direction midway between North and Northeast referenced to True North.");
	public static final DirectionCode NORTH_NORTHWEST = new DirectionCode(
			"North Northwest",
			"NNW",
			"The specific direction midway between North and Northwest referenced to True North.");
	public static final DirectionCode NORTHWEST = new DirectionCode(
			"Northwest",
			"NW",
			"The cardinal point at 315 degrees to True North.");
	public static final DirectionCode SOUTH = new DirectionCode(
			"South",
			"S",
			"The cardinal point at 180 degrees to True North.");
	public static final DirectionCode SOUTHEAST = new DirectionCode(
			"Southeast",
			"SE",
			"The cardinal point at 135 degrees to True North.");
	public static final DirectionCode SOUTH_SOUTHEAST = new DirectionCode(
			"South Southeast",
			"SSE",
			"The specific direction midway between South and Southeast referenced to True North.");
	public static final DirectionCode SOUTH_SOUTHWEST = new DirectionCode(
			"South Southwest",
			"SSW",
			"The specific direction midway between South and Southwest referenced to True North.");
	public static final DirectionCode SOUTHWEST = new DirectionCode(
			"Southwest",
			"SW",
			"The cardinal point at 225 degrees to True North.");
	public static final DirectionCode WEST = new DirectionCode(
			"West",
			"W",
			"The cardinal point at 270 degrees to True North.");
	public static final DirectionCode WEST_NORTHWEST = new DirectionCode(
			"West Northwest",
			"WNW",
			"The specific direction midway between West and Northwest referenced to True North.");
	public static final DirectionCode WEST_SOUTHWEST = new DirectionCode(
			"West Southwest",
			"WSW",
			"The specific direction midway between West and Southwest referenced to True North.");

	private DirectionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
