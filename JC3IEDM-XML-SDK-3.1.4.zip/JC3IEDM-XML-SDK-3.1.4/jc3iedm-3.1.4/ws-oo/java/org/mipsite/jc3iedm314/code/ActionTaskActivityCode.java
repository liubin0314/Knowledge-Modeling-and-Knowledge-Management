/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskActivityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of activity prescribed by the ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskActivityCode> physicalToCode = new HashMap<String, ActionTaskActivityCode>();

	public static ActionTaskActivityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskActivityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskActivityCode ACQUIRE = new ActionTaskActivityCode(
			"Acquire",
			"ACQUIR",
			"To detect the presence and location of a target in sufficient detail to permit identification.");
	public static final ActionTaskActivityCode ADVANCE = new ActionTaskActivityCode(
			"Advance",
			"ADVANC",
			"To move towards an objective in some form of tactical formation. This is a transitional phase between operations which may or may not result in contact with the enemy.");
	public static final ActionTaskActivityCode AEROMEDICAL_EVACUATION = new ActionTaskActivityCode(
			"Aeromedical evacuation",
			"AEREVA",
			"To move patients under medical supervision to and between medical treatment facilities by air transportation.");
	public static final ActionTaskActivityCode AERIAL_REFUELLING = new ActionTaskActivityCode(
			"Aerial refuelling",
			"AERRFL",
			"To refuel aircraft in flight, which extends presence, increases range, and serves as a force multiplier.");
	public static final ActionTaskActivityCode AIRBORNE_EARLY_WARNING = new ActionTaskActivityCode(
			"Airborne early warning",
			"AEW",
			"To provide airborne early warning and surveillance.");
	public static final ActionTaskActivityCode AIRBORNE_EARLY_WARNING_AND_CONTROL = new ActionTaskActivityCode(
			"Airborne early warning and control",
			"AEWCON",
			"To provide airborne early warning, surveillance and the control of airborne weapon systems.");
	public static final ActionTaskActivityCode AIR_DEFENCE = new ActionTaskActivityCode(
			"Air defence",
			"AIRDEF",
			"To protect and defend an area, a strike attack, an installation or naval forces.");
	public static final ActionTaskActivityCode AIRLAND = new ActionTaskActivityCode(
			"Airland",
			"AIRLND",
			"To move a unit by air and disembark or unload it, after the aircraft has landed or while a helicopter is hovering.");
	public static final ActionTaskActivityCode AIR_SUPERIORITY = new ActionTaskActivityCode(
			"Air superiority",
			"AIRSUP",
			"To obtain a degree of dominance in the air battle of one force over another in order to permit the conduct of operations by the former and its related land, sea and air forces at a given time and place without prohibitive interference by the opposite force.");
	public static final ActionTaskActivityCode AIR_TO_AIR_SWEEP = new ActionTaskActivityCode(
			"Air-to-air sweep",
			"AIRSWP",
			"To conduct an offensive mission by fighter aircraft to seek out and destroy enemy aircraft or targets of opportunity in an allotted area of operations.");
	public static final ActionTaskActivityCode AMBUSH = new ActionTaskActivityCode(
			"Ambush",
			"AMBUSH",
			"To conduct a surprise attack by fire or other destructive means, from concealed positions on a moving or temporarily halted force or group of personnel.");
	public static final ActionTaskActivityCode AMPHIBIOUS_OPERATION = new ActionTaskActivityCode(
			"Amphibious operation",
			"AMPH",
			"To mount an operation launched from the sea by naval and land forces against a hostile, or potentially hostile shore.");
	public static final ActionTaskActivityCode AMPHIBIOUS_WARFARE = new ActionTaskActivityCode(
			"Amphibious warfare",
			"AMPHWF",
			"To conduct warfare that includes the launch of naval and land forces from sea against a hostile, or potentially hostile shore.");
	public static final ActionTaskActivityCode ANALYSE = new ActionTaskActivityCode(
			"Analyse",
			"ANALYS",
			"To review in order to identify significant facts for subsequent interpretation.");
	public static final ActionTaskActivityCode ANTI_AIR_WARFARE = new ActionTaskActivityCode(
			"Anti-air warfare",
			"ANARWF",
			"To conduct warfare with the purpose of defending friendly forces, against the threat aircraft and airborne weapons, whether launched from air, surface, or sub-surface platforms.");
	public static final ActionTaskActivityCode ANTI_SUBMARINE_WARFARE = new ActionTaskActivityCode(
			"Anti-submarine warfare",
			"ANSBWF",
			"To conduct warfare with the intention of denying the opponent the effective use of his submarines.");
	public static final ActionTaskActivityCode ANTI_SURFACE_WARFARE = new ActionTaskActivityCode(
			"Anti-surface warfare",
			"ANSFWF",
			"To conduct warfare against an adversary�s surface forces or merchant ships to achieve sea control or sea denial, to disrupt his SLOC (Sea Lines of Communication) or to defend against surface threat.");
	public static final ActionTaskActivityCode ANTI_ARMOUR = new ActionTaskActivityCode(
			"Anti-armour",
			"ANTARM",
			"To destroy armoured targets.");
	public static final ActionTaskActivityCode AIR_ASSAULT = new ActionTaskActivityCode(
			"Air assault",
			"ARASLT",
			"To mount an operation in which assault forces (combat, combat service, and combat service support), using the firepower, mobility, and total integration of helicopter assets, maneuver on the battlefield under the control of the ground or air manoeuvre commander to engage and destroy enemy forces or to seize and hold key terrain.");
	public static final ActionTaskActivityCode AIRBORNE_ASSAULT = new ActionTaskActivityCode(
			"Airborne assault",
			"ARBNAS",
			"In an airborne operation, a phase beginning with delivery by air of the assault echelon of the force into the objective area and extending through attack of assault objectives and consolidation of the initial airhead.");
	public static final ActionTaskActivityCode AIRBORNE_COMMAND_AND_CONTROL = new ActionTaskActivityCode(
			"Airborne command and control",
			"ARCCTL",
			"To conduct battlespace command and control operations from an airborne platform.");
	public static final ActionTaskActivityCode AIRDROP_HEAVY_EQUIPMENT = new ActionTaskActivityCode(
			"Airdrop, heavy equipment",
			"ARDREQ",
			"To unload heavy equipment from an aircraft in flight.");
	public static final ActionTaskActivityCode AIRDROP = new ActionTaskActivityCode(
			"Airdrop",
			"ARDROP",
			"To deliver personnel or cargo from aircraft in flight.");
	public static final ActionTaskActivityCode AIR_INTERDICTION_BATTLEFIELD = new ActionTaskActivityCode(
			"Air interdiction, battlefield",
			"ARINTR",
			"To conduct air operations to destroy, neutralize, or delay the enemy's military potential on the battlefield before it can be brought to bear effectively against friendly forces at such distance from friendly forces that detailed integration of each air mission with the fire and movement of friendly forces is not required.");
	public static final ActionTaskActivityCode AIRLIFT_SPECIAL_ASSIGNMENT = new ActionTaskActivityCode(
			"Airlift, special assignment",
			"ARLFSA",
			"To require a special airlift for which a need of special consideration due to the number of passengers involved or the weight or size of cargo, the urgency of movement, sensitivity, other valid factors such as the presence of the chairman of the joint chiefs of staff -directed or -coordinated exercises, that preclude the use of channel airlift.");
	public static final ActionTaskActivityCode AIRLIFT_THEATRE = new ActionTaskActivityCode(
			"Airlift, theatre",
			"ARLFTR",
			"To provide air movement and delivery of personnel and equipment directly into objective areas through air landing, airdrop, extraction, or other delivery techniques; and the air logistic support of all theatre forces, including those engaged in combat operations, to meet specific theatre objectives and requirements.");
	public static final ActionTaskActivityCode ARMED_ASSAULT = new ActionTaskActivityCode(
			"Armed assault",
			"ARMAS",
			"To perform a short, violent, but well ordered, attack against a local objective such as a gun emplacement, a fort or a machine-gun nest.");
	public static final ActionTaskActivityCode ARREST_LEGAL = new ActionTaskActivityCode(
			"Arrest, legal",
			"ARRLGL",
			"To seize and detain a person under authority of the law.");
	public static final ActionTaskActivityCode ARREST_OBSTRUCT = new ActionTaskActivityCode(
			"Arrest/obstruct",
			"ARROBS",
			"To stop or check the motion, progress, growth, or spread of something.");
	public static final ActionTaskActivityCode AIR_TRAFFIC_CONTROL = new ActionTaskActivityCode(
			"Air traffic control",
			"ARTCTL",
			"To provide air traffic control service to flights in control areas.");
	public static final ActionTaskActivityCode ASSEMBLE = new ActionTaskActivityCode(
			"Assemble",
			"ASSMBL",
			"To join together multiple objects in the same area.");
	public static final ActionTaskActivityCode ATTACK_NOT_OTHERWISE_SPECIFIED = new ActionTaskActivityCode(
			"Attack, not otherwise specified",
			"ATTACK",
			"To conduct a type of offensive action characterised by coordinated employment of firepower and manoeuvre to close with and destroy or capture the enemy.");
	public static final ActionTaskActivityCode ATTACK_DIVERSION = new ActionTaskActivityCode(
			"Attack, diversion",
			"ATTDVR",
			"To conduct an attack wherein a force attacks, or threatens to attack, a target other than the main target for the purpose of drawing enemy defences away from the main effort.");
	public static final ActionTaskActivityCode ATTACK_ELECTRONIC = new ActionTaskActivityCode(
			"Attack, electronic",
			"ATTEL",
			"To conduct electronic warfare involving the use of electromagnetic energy, directed energy or anti-radiation weapons to attack personnel, facilities, or equipment with the intent of degrading, neutralizing, or destroying enemy combat capability and is considered a form of fires.");
	public static final ActionTaskActivityCode ATTACK_MAIN = new ActionTaskActivityCode(
			"Attack, main",
			"ATTMN",
			"To conduct the principal attack or effort into which the commander throws the full weight of the offensive power at his disposal. An attack directed against the chief objective of the campaign or battle.");
	public static final ActionTaskActivityCode ATTRIT = new ActionTaskActivityCode(
			"Attrit",
			"ATTRIT",
			"To reduce of the effectiveness of a force by causing loss of personnel and materiel.");
	public static final ActionTaskActivityCode ATTACK_SUPPORTING = new ActionTaskActivityCode(
			"Attack, supporting",
			"ATTSPT",
			"To conduct an offensive operation carried out in conjunction with a main attack and designed to achieve one or more of the following: a. deceive the enemy; b. destroy or pin down enemy forces which could interfere with the main attack; c. control ground whose occupation by the enemy will hinder the main attack; or d. force the enemy to commit reserves prematurely or in an indecisive area.");
	public static final ActionTaskActivityCode AVOID = new ActionTaskActivityCode(
			"Avoid",
			"AVOID",
			"To miss or take evading action.");
	public static final ActionTaskActivityCode AIR_WARNING_AIR_CONTROL = new ActionTaskActivityCode(
			"Air warning/air control",
			"AWACS",
			"To provide information about enemy air activity that poses immediate threat to friendly forces and monitors and directs the use of airspace.");
	public static final ActionTaskActivityCode BIOLOGICAL_SAMPLING = new ActionTaskActivityCode(
			"Biological sampling",
			"BIOSMP",
			"To collect samples for testing for biological hazards.");
	public static final ActionTaskActivityCode BUILD_UP = new ActionTaskActivityCode(
			"Build-up",
			"BLDUP",
			"To attain prescribed strength of units and prescribed levels of vehicles, equipment, stores and supplies.");
	public static final ActionTaskActivityCode BLOCK = new ActionTaskActivityCode(
			"Block",
			"BLOCK",
			"To deny the enemy access to an area or to prevent his advance in a direction or along an avenue of approach.");
	public static final ActionTaskActivityCode BREAKUP = new ActionTaskActivityCode(
			"Breakup",
			"BRAKUP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1299/19.");
	public static final ActionTaskActivityCode BREACH = new ActionTaskActivityCode(
			"Breach",
			"BREACH",
			"To break through or secure a passage through an enemy defence, obstacle, minefield, or fortification.");
	public static final ActionTaskActivityCode BYPASS = new ActionTaskActivityCode(
			"Bypass",
			"BYPASS",
			"To manoeuvre around an obstacle, position, or enemy force in order to maintain the momentum of advance.");
	public static final ActionTaskActivityCode CONSTITUTE_AN_ADVANCE_GUARD = new ActionTaskActivityCode(
			"Constitute an advance guard",
			"CADVGD",
			"To provide a security element whose primary task is to move ahead of the main body and protect the main force by fighting to gain time, whilst also observing and reporting information.");
	public static final ActionTaskActivityCode COMMAND_AND_CONTROL = new ActionTaskActivityCode(
			"Command and control",
			"CANDC",
			"To exercise authority and direction over assigned and attached forces in the accomplishment of the mission.");
	public static final ActionTaskActivityCode CANALISE = new ActionTaskActivityCode(
			"Canalise",
			"CANLSE",
			"To restrict operations to a narrow zone by use of existing or reinforcing obstacles or by fire or bombing. (Army)--A tactical task used to restrict operations to a narrow zone by the use of obstacles, fires, and/or unit manoeuvring or positioning.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL_BARRIER = new ActionTaskActivityCode(
			"Combat air patrol, barrier",
			"CAPBAR",
			"To conduct a patrol by fighter aircraft that is employed between a force and an objective area as a barrier across the probable direction of enemy attack. Used as far from the force as control conditions permit, to give added protection against raids along the most direct approach routes.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL_INGRESS = new ActionTaskActivityCode(
			"Combat air patrol, ingress",
			"CAPNGR",
			"Combat air patrol flown in support of friendly aircraft as the aircraft ingress into enemy territory.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL_PROTECT = new ActionTaskActivityCode(
			"Combat air patrol, protect",
			"CAPPRT",
			"An aircraft patrol flying over an objective area in order to protect friendly forces.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL_RESCUE = new ActionTaskActivityCode(
			"Combat air patrol, rescue",
			"CAPRES",
			"To protect the search and rescue task forces during recovery operations.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL_SURFACE = new ActionTaskActivityCode(
			"Combat air patrol, surface",
			"CAPSRF",
			"Combat air patrol flown in support of surface vessels conducting maritime operations.");
	public static final ActionTaskActivityCode CAPTURE = new ActionTaskActivityCode(
			"Capture",
			"CAPTUR",
			"To take possession of an object, normally by force; it frequently involves movement as a preliminary phase.");
	public static final ActionTaskActivityCode CARRIER_LAUNCH = new ActionTaskActivityCode(
			"Carrier launch",
			"CARLNC",
			"To launch aircraft from a naval platform.");
	public static final ActionTaskActivityCode CARRIER_RECOVERY = new ActionTaskActivityCode(
			"Carrier recovery",
			"CARREC",
			"To recover aircraft on a naval platform.");
	public static final ActionTaskActivityCode CONSTITUTE_BRIDGEHEAD_FORCE = new ActionTaskActivityCode(
			"Constitute bridgehead force",
			"CBRHDF",
			"To form the force during an obstacle crossing which seizes or controls ground in order to permit the continuous embarkation, landing or crossing of troops or materiel and to provide manoeuvre space.");
	public static final ActionTaskActivityCode CONSTITUTE_BREAKOUT_FORCE = new ActionTaskActivityCode(
			"Constitute breakout force",
			"CBRKOF",
			"To form the force during an obstacle crossing which is tasked with the continuation of the operation.");
	public static final ActionTaskActivityCode CODEWORD_ACTIVITY = new ActionTaskActivityCode(
			"Codeword activity",
			"CDWDAC",
			"To conduct an activity described by the action-task-detail-text.");
	public static final ActionTaskActivityCode CONSTITUTE_A_FLANK_GUARD = new ActionTaskActivityCode(
			"Constitute a flank guard",
			"CFLKGD",
			"To provide a security element whose primary task is to protect the main force by fighting on the designated flank to gain time, whilst also observing and reporting information.");
	public static final ActionTaskActivityCode RELEASE_CHAFF = new ActionTaskActivityCode(
			"Release CHAFF",
			"CHAFF",
			"To deploy strips of frequency-cut metal foil, wire or metalized glass fibre to reflect electromagnetic energy, usually dropped from aircraft or expelled from shells or rockets as a radar countermeasure.");
	public static final ActionTaskActivityCode CHEMICAL_SAMPLING = new ActionTaskActivityCode(
			"Chemical sampling",
			"CHMSMP",
			"To collect samples for testing for chemical hazards.");
	public static final ActionTaskActivityCode CONSTITUTE_IN_PLACE_FORCE = new ActionTaskActivityCode(
			"Constitute in-place force",
			"CINPLF",
			"To form the force during an obstacle crossing which provides fire and other support to the bridgehead force.");
	public static final ActionTaskActivityCode CLOSE_AIR_SUPPORT = new ActionTaskActivityCode(
			"Close air support",
			"CLARSP",
			"Air action against hostile targets which are in close proximity to friendly forces and which require detailed integration of each air mission with the fire and movement of those forces.");
	public static final ActionTaskActivityCode CLOSE = new ActionTaskActivityCode(
			"Close",
			"CLOSE",
			"To prevent a FACILITY or FEATURE from performing its intended function.");
	public static final ActionTaskActivityCode CLEAR_AIR = new ActionTaskActivityCode(
			"Clear, air",
			"CLRAIR",
			"To clear the air to gain either temporary or permanent air superiority or control in a given sector.");
	public static final ActionTaskActivityCode CLEAR_LAND_COMBAT = new ActionTaskActivityCode(
			"Clear, land combat",
			"CLRLND",
			"To remove all enemy forces from a specific location, area, or zone.");
	public static final ActionTaskActivityCode CLEAR_OBSTACLE = new ActionTaskActivityCode(
			"Clear, obstacle",
			"CLROBS",
			"To totally eliminate or neutralize an obstacle; a task that is usually performed by follow-on engineers and is not done under fire.");
	public static final ActionTaskActivityCode CLEAR_RADIO_NET = new ActionTaskActivityCode(
			"Clear, radio net",
			"CLRRAD",
			"To eliminate transmissions on a tactical radio net in order to allow a higher precedence transmission to occur.");
	public static final ActionTaskActivityCode CONSTITUTE_A_MAIN_BODY = new ActionTaskActivityCode(
			"Constitute a main body",
			"CMAINB",
			"To constitute the main force for a specific operation.");
	public static final ActionTaskActivityCode CONDUCT_FORWARD_PASSAGE_OF_LINES = new ActionTaskActivityCode(
			"Conduct forward passage of lines",
			"CNFPSL",
			"An operation in which an incoming force attacks through a unit (outgoing force).that is in contact with the enemy.");
	public static final ActionTaskActivityCode CONFISCATE = new ActionTaskActivityCode(
			"Confiscate",
			"CNFSTE",
			"To deprive a person of his property as forfeited by public authority.");
	public static final ActionTaskActivityCode CONDUCT_REARWARD_PASSAGE_OF_LINES = new ActionTaskActivityCode(
			"Conduct rearward passage of lines",
			"CNRPSL",
			"An operation when a force (outgoing force) effecting a movement to the rear passes through the sector of a unit (incoming force).");
	public static final ActionTaskActivityCode CONDUCT_ROAD_SERVICE = new ActionTaskActivityCode(
			"Conduct road service",
			"CNRSVC",
			"To enable the movement of a number of specific units.");
	public static final ActionTaskActivityCode CONSOLIDATE_A_POSITION = new ActionTaskActivityCode(
			"Consolidate a position",
			"CNSLDT",
			"To organise and strengthen a newly captured position so that it can be used against the enemy.");
	public static final ActionTaskActivityCode COMBAT_AIR_PATROL = new ActionTaskActivityCode(
			"Combat air patrol",
			"COARPL",
			"An aircraft patrol provided over an objective area, the force protected, the critical area of a combat zone, or in an air defence area, for the purpose of intercepting and destroying hostile aircraft before they reach their targets.");
	public static final ActionTaskActivityCode COMMUNICATIONS_C3I = new ActionTaskActivityCode(
			"Communications (C3I)",
			"COMC3I",
			"To provide communication means such as data links or radio for the purpose of communication, command, control and intelligence.");
	public static final ActionTaskActivityCode COMMUNICATION_INTELLIGENCE_COLLECTION = new ActionTaskActivityCode(
			"Communication, intelligence collection",
			"COMINC",
			"To gather communication intelligence in order to meet current operational requirements.");
	public static final ActionTaskActivityCode COMMUNICATIONS_RELAY = new ActionTaskActivityCode(
			"Communications relay",
			"COMREL",
			"To employ an aircraft to serve as a communications relay.");
	public static final ActionTaskActivityCode CONSTRUCT = new ActionTaskActivityCode(
			"Construct",
			"CONSTR",
			"To build, dig or create an object.");
	public static final ActionTaskActivityCode CONTAIN = new ActionTaskActivityCode(
			"Contain",
			"CONTAN",
			"To stop, hold, or surround the forces of the enemy or to cause the enemy to centre activity on a given front and to prevent his withdrawing any part of his forces for use elsewhere. (Army)--A tactical task to restrict enemy movement.");
	public static final ActionTaskActivityCode COOPERATE = new ActionTaskActivityCode(
			"Cooperate",
			"COOPER",
			"To work or act together.");
	public static final ActionTaskActivityCode COURIER = new ActionTaskActivityCode(
			"Courier",
			"COURER",
			"To travel as a courier.");
	public static final ActionTaskActivityCode COVER = new ActionTaskActivityCode(
			"Cover",
			"COVER",
			"To operate as a force apart to protect the main body by fighting to gain time while also observing and reporting information and preventing enemy ground observation of an direct fire against the main body.");
	public static final ActionTaskActivityCode CONSTITUTE_A_RESERVE = new ActionTaskActivityCode(
			"Constitute a reserve",
			"CRESRV",
			"To constitute a force which may be committed into combat only on the order of the commander of the ORGANISATION who so designated the reserve force.");
	public static final ActionTaskActivityCode CROSS = new ActionTaskActivityCode(
			"Cross",
			"CROSS",
			"To move over a FEATURE or FACILITY.");
	public static final ActionTaskActivityCode CONSTITUTE_A_REAR_GUARD = new ActionTaskActivityCode(
			"Constitute a rear guard",
			"CRRGD",
			"To provide a security element whose primary task is to move (or remain) at the rear of the main body and protect the main force by fighting to gain time, whilst also observing and reporting information.");
	public static final ActionTaskActivityCode COUNTER_ATTACK = new ActionTaskActivityCode(
			"Counter attack",
			"CTRATK",
			"To mount an offensive operation in which an attack by a part or all of a defending force is made against an enemy attacking force, for such specific purposes as regaining ground lost, cutting off or destroying lead enemy units, and with the general objective of regaining the initiative and denying the enemy the attainment of his goal or purpose in attacking.");
	public static final ActionTaskActivityCode COUNTER_BATTERY_FIRE = new ActionTaskActivityCode(
			"Counter-battery fire",
			"CTRBYF",
			"To deliver fire for the purpose of destroying or neutralizing indirect fire weapons systems.");
	public static final ActionTaskActivityCode COUNTER_ATTACK_BY_FIRE = new ActionTaskActivityCode(
			"Counter attack by fire",
			"CTRFIR",
			"To deny the enemy his goal in attacking through fire into an engagement area to defeat or destroy an enemy force.");
	public static final ActionTaskActivityCode DAZZLE = new ActionTaskActivityCode(
			"Dazzle",
			"DAZZLE",
			"To confuse the enemy by temporary loss of vision or a temporary reduction in visual acuity; may also be applied to effects on optics.");
	public static final ActionTaskActivityCode DECEPTION_ELECTRONIC = new ActionTaskActivityCode(
			"Deception, electronic",
			"DCPTEL",
			"In electronic countermeasures, the deliberate radiation, re-radiation, alteration, absorption or reflection of electromagnetic energy in a manner intended to confuse, distract or seduce an enemy or his electronic systems.");
	public static final ActionTaskActivityCode DEBARK = new ActionTaskActivityCode(
			"Debark",
			"DEBARK",
			"To unload troops with their supplies and equipment from a ship.");
	public static final ActionTaskActivityCode DECEIVE = new ActionTaskActivityCode(
			"Deceive",
			"DECEIV",
			"To employ measures designed to mislead the enemy by manipulation, distortion, or falsification of evidence to induce him to react in a manner prejudicial to his interests.");
	public static final ActionTaskActivityCode DECONTAMINATION_SERVICES = new ActionTaskActivityCode(
			"Decontamination services",
			"DECSVC",
			"To provide purification making any person, object, or area safe by absorbing, destroying, neutralizing, making harmless, or removing, chemical or biological agents, or by removing radioactive material clinging to or around it.");
	public static final ActionTaskActivityCode DEFENSIVE_COUNTER_AIR = new ActionTaskActivityCode(
			"Defensive counter air",
			"DEFCNT",
			"To conduct air operations to attain and maintain a desired degree of air superiority by the destruction or neutralization of enemy forces, conducted near to or over friendly territory and generally reactive to the initiative of the enemy air forces.");
	public static final ActionTaskActivityCode DEFENCE_DESTRUCTION = new ActionTaskActivityCode(
			"Defence destruction",
			"DEFDST",
			"To destroy enemy defences in a specific area by any means.");
	public static final ActionTaskActivityCode DEFEAT = new ActionTaskActivityCode(
			"Defeat",
			"DEFEAT",
			"To diminish the effectiveness of the enemy to the extent that he is unable to participate further in the battle or at least cannot fulfil his intention.");
	public static final ActionTaskActivityCode DEFEND = new ActionTaskActivityCode(
			"Defend",
			"DEFEND",
			"To hold a defined object against an enemy attack; to halt or ward off an attack in order to defeat or destroy the enemy.");
	public static final ActionTaskActivityCode DEFLECT = new ActionTaskActivityCode(
			"Deflect",
			"DEFLCT",
			"To prevent an enemy force from following the intended course.");
	public static final ActionTaskActivityCode DEFENCE_SUPPRESSION = new ActionTaskActivityCode(
			"Defence suppression",
			"DEFSUP",
			"To neutralize, destroy or temporarily degrade enemy defences in a specific area by physical attack and/or electronic warfare.");
	public static final ActionTaskActivityCode DELAY = new ActionTaskActivityCode(
			"Delay",
			"DELAY",
			"To slow the momentum of the enemy by conducting an operation in which the force under pressure trades time for space. The aim is to inflict the maximum damage on the enemy without becoming decisively engaged.");
	public static final ActionTaskActivityCode CONSTITUTE_A_DEMOLITION_FIRING_PARTY = new ActionTaskActivityCode(
			"Constitute a demolition firing party",
			"DEMFRP",
			"To provide the party at the site which is technically responsible for the demolition.");
	public static final ActionTaskActivityCode CONSTITUTE_A_DEMOLITION_GUARD = new ActionTaskActivityCode(
			"Constitute a demolition guard",
			"DEMGRD",
			"To provide a local force positioned to ensure that a target is not captured by an enemy before orders are given for its demolition and before the demolition has been successfully fired.");
	public static final ActionTaskActivityCode DEMOLISH = new ActionTaskActivityCode(
			"Demolish",
			"DEMO",
			"To destroy structures, facilities, or materiel by use of fire, water, explosives, mechanical, or other means.");
	public static final ActionTaskActivityCode DENY = new ActionTaskActivityCode(
			"Deny",
			"DENY",
			"To prevent access by blocking, disrupting, dislocating and/or bringing fire to bear.");
	public static final ActionTaskActivityCode DEPLOY = new ActionTaskActivityCode(
			"Deploy",
			"DEPLOY",
			"To move and adopt tactical formation or dispersal in a specific location.");
	public static final ActionTaskActivityCode DESCRIBE = new ActionTaskActivityCode(
			"Describe",
			"DESCRB",
			"To state the characteristics, appearance, etc. of an object.");
	public static final ActionTaskActivityCode DESTROY = new ActionTaskActivityCode(
			"Destroy",
			"DESTRY",
			"To physically render an enemy force combat-ineffective or damaging a target so that it cannot function as intended, nor be restored to a usable condition without being entirely rebuilt.");
	public static final ActionTaskActivityCode DETECT = new ActionTaskActivityCode(
			"Detect",
			"DETECT",
			"To discover by any means of the presence of a person, object or phenomenon of potential military significance.");
	public static final ActionTaskActivityCode DISENGAGE = new ActionTaskActivityCode(
			"Disengage",
			"DISENG",
			"To break off an action.");
	public static final ActionTaskActivityCode DISRUPT = new ActionTaskActivityCode(
			"Disrupt",
			"DISRPT",
			"To break apart an enemy's formation and tempo, to interrupt the enemy's timetable, to cause premature commitment of forces, and/or splinter their attack using integrated fire planning and obstacle effect.");
	public static final ActionTaskActivityCode DIVE = new ActionTaskActivityCode(
			"Dive",
			"DIVE",
			"To descend or plunge into or underwater or some other liquid.");
	public static final ActionTaskActivityCode DIVERT = new ActionTaskActivityCode(
			"Divert",
			"DIVERT",
			"To draw the attention and forces of an enemy from the point of the principal operation; an attack, alarm, or feint which diverts attention.");
	public static final ActionTaskActivityCode ATTACK_DELIBERATE = new ActionTaskActivityCode(
			"Attack, deliberate",
			"DLBATK",
			"To conduct a type of offensive action characterised by pre-planned coordinated employment of firepower and manoeuvre to close with and destroy or capture the enemy.");
	public static final ActionTaskActivityCode DRONE_LAUNCH = new ActionTaskActivityCode(
			"Drone launch",
			"DRONL",
			"To perform the launching of drones.");
	public static final ActionTaskActivityCode DISTRIBUTE = new ActionTaskActivityCode(
			"Distribute",
			"DSTRBT",
			"To divide or dispense in portions.");
	public static final ActionTaskActivityCode DUMPING = new ActionTaskActivityCode(
			"Dumping",
			"DUMPNG",
			"To position stocks to meet future requirements.");
	public static final ActionTaskActivityCode ELECTRONIC_COUNTER_MEASURES = new ActionTaskActivityCode(
			"Electronic counter measures",
			"ELCCNM",
			"To perform electronic warfare actions to prevent or reduce an enemy�s effective use of the electromagnetic spectrum through the use of electromagnetic energy. There are three subdivisions of electronic countermeasures: electronic jamming, electronic deception and electronic neutralization.");
	public static final ActionTaskActivityCode ELECTRONIC_WARFARE = new ActionTaskActivityCode(
			"Electronic warfare",
			"ELCWAR",
			"To exploit the electromagnetic spectrum encompassing; the search for, interception of electromagnetic emissions, the employment of electromagnetic energy, including directed energy, to reduce or prevent hostile use of the electromagnetic spectrum, and the actions to ensure its effective use by friendly forces.");
	public static final ActionTaskActivityCode ELECTRONIC_WARFARE_SUPPORT = new ActionTaskActivityCode(
			"Electronic warfare support",
			"ELCWRS",
			"To search for, intercept, locate, record measures and analyse radiated electromagnetic energy for the purpose of exploiting such radiations in support of military operations. Thus, ESM provides a source of EW information required to conduct ECM, ECCM, threat detection, warning, avoidance, target acquisition, and homing.");
	public static final ActionTaskActivityCode EMBARK = new ActionTaskActivityCode(
			"Embark",
			"EMBARK",
			"To put personnel and/or vehicles and their associated stores and equipment into ships or aircraft.");
	public static final ActionTaskActivityCode ENGAGE = new ActionTaskActivityCode(
			"Engage",
			"ENGAGE",
			"To bring the enemy under fire.");
	public static final ActionTaskActivityCode ENVELOP = new ActionTaskActivityCode(
			"Envelop",
			"ENVLP",
			"To conduct an offensive manoeuvre in which the main attacking force passes around or over the enemy's principal defensive positions with the aim of securing objectives to the enemy's rear.");
	public static final ActionTaskActivityCode ESCORT = new ActionTaskActivityCode(
			"Escort",
			"ESCRT",
			"To accompany and protect another force or convoy.");
	public static final ActionTaskActivityCode EVACUATE = new ActionTaskActivityCode(
			"Evacuate",
			"EVACT",
			"To clear materiel and personnel from a given locality.");
	public static final ActionTaskActivityCode EXFILTRATE = new ActionTaskActivityCode(
			"Exfiltrate",
			"EXFLTR",
			"To withdraw from a dangerous position.");
	public static final ActionTaskActivityCode EXPLOIT = new ActionTaskActivityCode(
			"Exploit",
			"EXPLT",
			"To take advantage of a successful attack by mounting an offensive operation to follow-up and harass a dislocated enemy with the aim of further disorganising him in depth. This may provide the opportunity to capture ground which was not part of the objective of the original attack.");
	public static final ActionTaskActivityCode FIX = new ActionTaskActivityCode(
			"Fix",
			"FIX",
			"To prevent the enemy from moving any part of his force from a specific location for a specific period of time.");
	public static final ActionTaskActivityCode FIX_ACOUSTIC = new ActionTaskActivityCode(
			"Fix, acoustic",
			"FIXACO",
			"To determine a position using acoustic data.");
	public static final ActionTaskActivityCode FIX_ELECTROMAGNETIC = new ActionTaskActivityCode(
			"Fix, electromagnetic",
			"FIXELM",
			"To determine a position using electromagnetic data.");
	public static final ActionTaskActivityCode FIX_ELECTRO_OPTICAL = new ActionTaskActivityCode(
			"Fix, electro-optical",
			"FIXELO",
			"To determine a position using electro-optical data.");
	public static final ActionTaskActivityCode FUNCTIONAL_CHECK_FLIGHT = new ActionTaskActivityCode(
			"Functional check flight",
			"FNCHFL",
			"To conduct a test flight to ensure the general aircraft safety after maintenance/repair, and to ensure the aircraft is fully serviceable for operations.");
	public static final ActionTaskActivityCode FOLLOW_AND_ASSUME = new ActionTaskActivityCode(
			"Follow and assume",
			"FOLASS",
			"To operate as a committed force that follows a force conducting an offensive operation, and is prepared to continue the mission of the force it is following when that force is fixed, attrited, or otherwise unable to continue. Such a force is not a reserve but is committed to accomplish specified tasks.");
	public static final ActionTaskActivityCode FOLLOW_AND_SUPPORT = new ActionTaskActivityCode(
			"Follow and support",
			"FOLSPT",
			"To operate as a committed force that follows and supports the mission accomplishment of a force conducting an offensive operation. Such a force is not a reserve, but is committed to accomplish specified tasks.");
	public static final ActionTaskActivityCode FORWARD_AIR_CONTROL = new ActionTaskActivityCode(
			"Forward air control",
			"FRWDAC",
			"To direct the action of combat aircraft engaged in close air support of land forces from a forward position on the ground or in the air.");
	public static final ActionTaskActivityCode GENERATE_CHEMICAL_SMOKE = new ActionTaskActivityCode(
			"Generate chemical smoke",
			"GENCHS",
			"To produce chemical smoke to act as a form of cover to protect ongoing operations.");
	public static final ActionTaskActivityCode GUARD = new ActionTaskActivityCode(
			"Guard",
			"GUARD",
			"To protect the main body by fighting to gain time while also observing and reporting information.");
	public static final ActionTaskActivityCode HARASS = new ActionTaskActivityCode(
			"Harass",
			"HARASS",
			"To mount an operation or fire plan designed to curtail movement and, by threat of losses, to lower the morale of enemy troops.");
	public static final ActionTaskActivityCode ATTACK_HASTY = new ActionTaskActivityCode(
			"Attack, hasty",
			"HASTY",
			"To conduct a type of offensive action using firepower and manoeuvre to close with and destroy or capture the enemy. Planning and coordination will normally be limited, as the attack will be carried out at short notice.");
	public static final ActionTaskActivityCode HIDE = new ActionTaskActivityCode(
			"Hide",
			"HIDE",
			"To occupy an area in which an ORGANISATION or FACILITY may conceal itself before operations or before moving into battle positions.");
	public static final ActionTaskActivityCode HOLD_DEFENSIVE = new ActionTaskActivityCode(
			"Hold, defensive",
			"HLDDEF",
			"To maintain or retain possession by force, a position or area in defensive operations.");
	public static final ActionTaskActivityCode HOLD_OFFENSIVE = new ActionTaskActivityCode(
			"Hold, offensive",
			"HLDOFF",
			"To exert sufficient pressure in an offensive operation by means of combat power, to prevent the movement or redeployment of enemy forces.");
	public static final ActionTaskActivityCode HOST_NATION_SUPPORT = new ActionTaskActivityCode(
			"Host nation support",
			"HONASP",
			"Civil and military assistance rendered in peace, crisis and war by a host nation to Allied forces and NATO organisations which are located on or in transit through the host nation's territory. The basis of such assistance is commitments arising from the NATO Alliance or from bilateral or multilateral agreements concluded between the host nation, NATO organisations and (the) nation(s) having forces operating on the host nation's territory.");
	public static final ActionTaskActivityCode IDENTIFY = new ActionTaskActivityCode(
			"Identify",
			"IDENT",
			"To determine the identification of a particular class of object, recognising the friendly or enemy character of an object, or detecting the presence of an object.");
	public static final ActionTaskActivityCode IDENTIFY_PRECISE = new ActionTaskActivityCode(
			"Identify, precise",
			"IDENTP",
			"To determine by any act or means additional information of a detected person, object or phenomenon, in a detailed, accurate and trusted way.");
	public static final ActionTaskActivityCode ILLUMINATE = new ActionTaskActivityCode(
			"Illuminate",
			"ILLUMN",
			"To provide battlespace lighting by employing searchlight or pyrotechnic illuminants using diffusion or reflection.");
	public static final ActionTaskActivityCode IMAGERY_INTELLIGENCE_GATHERING = new ActionTaskActivityCode(
			"Imagery intelligence gathering",
			"IMINGT",
			"To gather imagery for intelligence purposes.");
	public static final ActionTaskActivityCode INFILTRATE = new ActionTaskActivityCode(
			"Infiltrate",
			"INFILT",
			"To move a force, broken down as individuals or small groups, over, through or around enemy positions with the aim of avoiding detection.");
	public static final ActionTaskActivityCode INFORMATION_OPERATIONS = new ActionTaskActivityCode(
			"Information operations",
			"INFOOP",
			"To conduct an operation that includes actions to influence decision makers in support of political and military objectives by affecting other�s information, information based processes, command and control systems and communications and information systems while exploiting and protecting one�s own information and/or information systems.");
	public static final ActionTaskActivityCode INTERCEPT = new ActionTaskActivityCode(
			"Intercept",
			"INTCEP",
			"To conduct Electronic Warfare Support operations with a view to searching, locating, recording and analysing radiated electromagnetic energy for the purposes of supporting an operation.");
	public static final ActionTaskActivityCode INTELLIGENCE_COLLECTION = new ActionTaskActivityCode(
			"Intelligence collection",
			"INTCOL",
			"To gather information from all available sources to meet an intelligence requirement. Specifically, a logical plan for transforming the essential elements of information into orders or requests to sources within a required time limit.");
	public static final ActionTaskActivityCode INTERDICT = new ActionTaskActivityCode(
			"Interdict",
			"INTDCT",
			"To divert, disrupt, delay, or destroy the enemy's surface military potential before it can be used effectively against friendly forces.");
	public static final ActionTaskActivityCode ISOLATE = new ActionTaskActivityCode(
			"Isolate",
			"ISOLAT",
			"To seal off (both physically and psychologically) an enemy from its sources of support, to deny an enemy freedom of movement, and prevent an enemy unit from having contact with other enemy forces. An enemy must not be allowed sanctuary within its present position.");
	public static final ActionTaskActivityCode ISSUE_MEDIA_ARTICLE = new ActionTaskActivityCode(
			"Issue media article",
			"ISSMDA",
			"To send forth; publish; put into circulation a non-fictional essay, especially one included with others in a newspaper, magazine, or journal.");
	public static final ActionTaskActivityCode ISSUE_MEDIA_DOCUMENTARY = new ActionTaskActivityCode(
			"Issue media documentary",
			"ISSMDD",
			"To send forth; publish; put into circulation any document published on a media that provides a factual record or report.");
	public static final ActionTaskActivityCode ISSUE_PRESS_RELEASE = new ActionTaskActivityCode(
			"Issue press release",
			"ISSPRS",
			"To send forth; publish; put into circulation an official statement issued to media for information.");
	public static final ActionTaskActivityCode JAM = new ActionTaskActivityCode(
			"Jam",
			"JAM",
			"To deliberately radiate, re-radiate or reflect electromagnetic energy with the object of impairing the use of electronic devices, equipment or systems being used by the enemy.");
	public static final ActionTaskActivityCode LAY = new ActionTaskActivityCode(
			"Lay",
			"LAY",
			"To place on a surface, esp. horizontally or in the proper or specified place.");
	public static final ActionTaskActivityCode LEAGUER = new ActionTaskActivityCode(
			"Leaguer",
			"LEAGR",
			"To adopt a defended formation as a temporary defensive measure in areas of low or moderate risk of combat (usually applied to Coy/Sqn level).");
	public static final ActionTaskActivityCode LIFT = new ActionTaskActivityCode(
			"Lift",
			"LIFT",
			"To transport assets using non-organic means, by sea, land or air.");
	public static final ActionTaskActivityCode LIFT_ADMINISTRATIVE = new ActionTaskActivityCode(
			"Lift, administrative",
			"LIFTAD",
			"Airlift normally provided by specifically identifiable aircraft assigned to organisations or commands for internal administration.");
	public static final ActionTaskActivityCode LOCATE = new ActionTaskActivityCode(
			"Locate",
			"LOCATE",
			"To establish the position or presence of an object.");
	public static final ActionTaskActivityCode MAINTAIN = new ActionTaskActivityCode(
			"Maintain",
			"MAINTN",
			"To provide services to keep equipment in condition to carry out its function.");
	public static final ActionTaskActivityCode MAP = new ActionTaskActivityCode(
			"Map",
			"MAP",
			"To create a graphic representation, usually on a plane surface and at an established scale, of natural or artificial features on the surface of a part or the whole of the earth or other planetary body. The features are positioned relative to a coordinate reference system.");
	public static final ActionTaskActivityCode MARK = new ActionTaskActivityCode(
			"Mark",
			"MARK",
			"To make visible (by the use of light/IR/laser/arty) an object in order to allow its identification by another object (usually as a precursor to the use of direct fire weapons).");
	public static final ActionTaskActivityCode MASS_FORCES = new ActionTaskActivityCode(
			"Mass forces",
			"MASSFR",
			"To concentrate large quantities of military equipment and personnel.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_11 = new ActionTaskActivityCode(
			"MCM operation stage 11",
			"MCM11",
			"Mine Counter Measure operation stage 11.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_12 = new ActionTaskActivityCode(
			"MCM operation stage 12",
			"MCM12",
			"Mine Counter Measure operation stage 12.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_13 = new ActionTaskActivityCode(
			"MCM operation stage 13",
			"MCM13",
			"Mine Counter Measure operation stage 13.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_14 = new ActionTaskActivityCode(
			"MCM operation stage 14",
			"MCM14",
			"Mine Counter Measure operation stage 14.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_31 = new ActionTaskActivityCode(
			"MCM operation stage 31",
			"MCM31",
			"Mine Counter Measure operation stage 31.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_32 = new ActionTaskActivityCode(
			"MCM operation stage 32",
			"MCM32",
			"Mine Counter Measure operation stage 32.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_33 = new ActionTaskActivityCode(
			"MCM operation stage 33",
			"MCM33",
			"Mine Counter Measure operation stage 33.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_34 = new ActionTaskActivityCode(
			"MCM operation stage 34",
			"MCM34",
			"Mine Counter Measure operation stage 34.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_35 = new ActionTaskActivityCode(
			"MCM operation stage 35",
			"MCM35",
			"Mine Counter Measure operation stage 35.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_36 = new ActionTaskActivityCode(
			"MCM operation stage 36",
			"MCM36",
			"Mine Counter Measure operation stage 36.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_37 = new ActionTaskActivityCode(
			"MCM operation stage 37",
			"MCM37",
			"Mine Counter Measure operation stage 37.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_38 = new ActionTaskActivityCode(
			"MCM operation stage 38",
			"MCM38",
			"Mine Counter Measure operation stage 38.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_39 = new ActionTaskActivityCode(
			"MCM operation stage 39",
			"MCM39",
			"Mine Counter Measure operation stage 39.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_41 = new ActionTaskActivityCode(
			"MCM operation stage 41",
			"MCM41",
			"Mine Counter Measure operation stage 41.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_42 = new ActionTaskActivityCode(
			"MCM operation stage 42",
			"MCM42",
			"Mine Counter Measure operation stage 42.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_43 = new ActionTaskActivityCode(
			"MCM operation stage 43",
			"MCM43",
			"Mine Counter Measure operation stage 43.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_44 = new ActionTaskActivityCode(
			"MCM operation stage 44",
			"MCM44",
			"Mine Counter Measure operation stage 44.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_45 = new ActionTaskActivityCode(
			"MCM operation stage 45",
			"MCM45",
			"Mine Counter Measure operation stage 45.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_46 = new ActionTaskActivityCode(
			"MCM operation stage 46",
			"MCM46",
			"Mine Counter Measure operation stage 46.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_47 = new ActionTaskActivityCode(
			"MCM operation stage 47",
			"MCM47",
			"Mine Counter Measure operation stage 47.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_48 = new ActionTaskActivityCode(
			"MCM operation stage 48",
			"MCM48",
			"Mine Counter Measure operation stage 48.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_50 = new ActionTaskActivityCode(
			"MCM operation stage 50",
			"MCM50",
			"Mine Counter Measure operation stage 50.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_51 = new ActionTaskActivityCode(
			"MCM operation stage 51",
			"MCM51",
			"Mine Counter Measure operation stage 51.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_52 = new ActionTaskActivityCode(
			"MCM operation stage 52",
			"MCM52",
			"Mine Counter Measure operation stage 52.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_53 = new ActionTaskActivityCode(
			"MCM operation stage 53",
			"MCM53",
			"Mine Counter Measure operation stage 53.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_54 = new ActionTaskActivityCode(
			"MCM operation stage 54",
			"MCM54",
			"Mine Counter Measure operation stage 54.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_55 = new ActionTaskActivityCode(
			"MCM operation stage 55",
			"MCM55",
			"Mine Counter Measure operation stage 55.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_56 = new ActionTaskActivityCode(
			"MCM operation stage 56",
			"MCM56",
			"Mine Counter Measure operation stage 56.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_57 = new ActionTaskActivityCode(
			"MCM operation stage 57",
			"MCM57",
			"Mine Counter Measure operation stage 57.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_58A = new ActionTaskActivityCode(
			"MCM operation stage 58A",
			"MCM58A",
			"Mine Counter Measure operation stage 58A.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_58B = new ActionTaskActivityCode(
			"MCM operation stage 58B",
			"MCM58B",
			"Mine Counter Measure operation stage 58B.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_58C = new ActionTaskActivityCode(
			"MCM operation stage 58C",
			"MCM58C",
			"Mine Counter Measure operation stage 58C.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_59 = new ActionTaskActivityCode(
			"MCM operation stage 59",
			"MCM59",
			"Mine Counter Measure operation stage 59.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_61 = new ActionTaskActivityCode(
			"MCM operation stage 61",
			"MCM61",
			"Mine Counter Measure operation stage 61.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_62 = new ActionTaskActivityCode(
			"MCM operation stage 62",
			"MCM62",
			"Mine Counter Measure operation stage 62.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_63 = new ActionTaskActivityCode(
			"MCM operation stage 63",
			"MCM63",
			"Mine Counter Measure operation stage 63.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_71 = new ActionTaskActivityCode(
			"MCM operation stage 71",
			"MCM71",
			"Mine Counter Measure operation stage 71.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_72 = new ActionTaskActivityCode(
			"MCM operation stage 72",
			"MCM72",
			"Mine Counter Measure operation stage 72.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_73 = new ActionTaskActivityCode(
			"MCM operation stage 73",
			"MCM73",
			"Mine Counter Measure operation stage 73.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_74 = new ActionTaskActivityCode(
			"MCM operation stage 74",
			"MCM74",
			"Mine Counter Measure operation stage 74.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_75 = new ActionTaskActivityCode(
			"MCM operation stage 75",
			"MCM75",
			"Mine Counter Measure operation stage 75.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_81 = new ActionTaskActivityCode(
			"MCM operation stage 81",
			"MCM81",
			"Mine Counter Measure operation stage 81.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_82 = new ActionTaskActivityCode(
			"MCM operation stage 82",
			"MCM82",
			"Mine Counter Measure operation stage 82.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_83 = new ActionTaskActivityCode(
			"MCM operation stage 83",
			"MCM83",
			"Mine Counter Measure operation stage 83.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_84 = new ActionTaskActivityCode(
			"MCM operation stage 84",
			"MCM84",
			"Mine Counter Measure operation stage 84.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_85 = new ActionTaskActivityCode(
			"MCM operation stage 85",
			"MCM85",
			"Mine Counter Measure operation stage 85.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_86 = new ActionTaskActivityCode(
			"MCM operation stage 86",
			"MCM86",
			"Mine Counter Measure operation stage 86.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_87 = new ActionTaskActivityCode(
			"MCM operation stage 87",
			"MCM87",
			"Mine Counter Measure operation stage 87.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_88 = new ActionTaskActivityCode(
			"MCM operation stage 88",
			"MCM88",
			"Mine Counter Measure operation stage 88.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_89 = new ActionTaskActivityCode(
			"MCM operation stage 89",
			"MCM89",
			"Mine Counter Measure operation stage 89.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_91 = new ActionTaskActivityCode(
			"MCM operation stage 91",
			"MCM91",
			"Mine Counter Measure operation stage 91.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_92 = new ActionTaskActivityCode(
			"MCM operation stage 92",
			"MCM92",
			"Mine Counter Measure operation stage 92.");
	public static final ActionTaskActivityCode MCM_OPERATION_STAGE_93 = new ActionTaskActivityCode(
			"MCM operation stage 93",
			"MCM93",
			"Mine Counter Measure operation stage 93.");
	public static final ActionTaskActivityCode MCM_ATTRITION = new ActionTaskActivityCode(
			"MCM, attrition",
			"MCMATT",
			"To conduct continuous application of Mine Countermeasures (MCM) to keep the risk from mines to all vessels as low as possible. Appropriate to minefields that are being replenished.");
	public static final ActionTaskActivityCode MCM_CHECK = new ActionTaskActivityCode(
			"MCM, check",
			"MCMCHK",
			"To conduct a Mine Countermeasures (MCM) operation to check that as far as possible no maritime mines are left after the previous MCM operation.");
	public static final ActionTaskActivityCode MCM_EXPLORATORY = new ActionTaskActivityCode(
			"MCM, exploratory",
			"MCMEXP",
			"To conduct a Mine Countermeasures (MCM) operation in which a sample of the route or area is subjected to MCM procedures to determine the presence or absence of mines.");
	public static final ActionTaskActivityCode MCM_LEAD_THROUGH = new ActionTaskActivityCode(
			"MCM, lead through",
			"MCMLDT",
			"To assist traffic in the transit of parts of a mined area which have previously been subject to Mine Countermeasures (MCM) operations.");
	public static final ActionTaskActivityCode MCM_LIMITED_CLEARING = new ActionTaskActivityCode(
			"MCM, limited clearing",
			"MCMLMC",
			"To clear particular types of mines from an area, channel or route.");
	public static final ActionTaskActivityCode MCM_PRECURSOR = new ActionTaskActivityCode(
			"MCM, precursor",
			"MCMPRE",
			"To carry out operations in an area or channel using relatively safe methods and techniques in order to reduce the risk to mine countermeasures (MCM) vessels.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA",
			"MCMSA",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-ALPHA",
			"MCMSAA",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-CHARLIE",
			"MCMSAC",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-DELTA",
			"MCMSAD",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-GOLF",
			"MCMSAG",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-HOTEL",
			"MCMSAH",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-MIKE",
			"MCMSAM",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_ALPHA_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-ALPHA-ZULU",
			"MCMSAZ",
			"Mine Countermeasures Operation Standard Letter Suffixes ALPHA-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_BRAVO = new ActionTaskActivityCode(
			"MCM-SLS-BRAVO",
			"MCMSB",
			"Mine Countermeasures Operation Standard Letter Suffixes BRAVO.");
	public static final ActionTaskActivityCode MCM_SLS_BRAVO_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-BRAVO-ZULU",
			"MCMSBZ",
			"Mine Countermeasures Operation Standard Letter Suffixes BRAVO-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE",
			"MCMSC",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-ALPHA",
			"MCMSCA",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-CHARLIE",
			"MCMSCC",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-DELTA",
			"MCMSCD",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-GOLF",
			"MCMSCG",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-HOTEL",
			"MCMSCH",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-MIKE",
			"MCMSCM",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_CHARLIE_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-CHARLIE-ZULU",
			"MCMSCZ",
			"Mine Countermeasures Operation Standard Letter Suffixes CHARLIE-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO = new ActionTaskActivityCode(
			"MCM-SLS-ECHO",
			"MCMSE",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-ALPHA",
			"MCMSEA",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-CHARLIE",
			"MCMSEC",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-DELTA",
			"MCMSED",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-GOLF",
			"MCMSEG",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-HOTEL",
			"MCMSEH",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-MIKE",
			"MCMSEM",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_ECHO_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-ECHO-ZULU",
			"MCMSEZ",
			"Mine Countermeasures Operation Standard Letter Suffixes ECHO-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_LIMA = new ActionTaskActivityCode(
			"MCM-SLS-LIMA",
			"MCMSL",
			"Mine Countermeasures Operation Standard Letter Suffixes LIMA.");
	public static final ActionTaskActivityCode MCM_SLS_LIMA_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-LIMA-ALPHA",
			"MCMSLA",
			"Mine Countermeasures Operation Standard Letter Suffixes LIMA-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_LIMA_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-LIMA-HOTEL",
			"MCMSLH",
			"Mine Countermeasures Operation Standard Letter Suffixes LIMA-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_LIMA_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-LIMA-MIKE",
			"MCMSLM",
			"Mine Countermeasures Operation Standard Letter Suffixes LIMA-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_LIMA_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-LIMA-ZULU",
			"MCMSLZ",
			"Mine Countermeasures Operation Standard Letter Suffixes LIMA-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA = new ActionTaskActivityCode(
			"MCM-SLS-PAPA",
			"MCMSP",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-ALPHA",
			"MCMSPA",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-CHARLIE",
			"MCMSPC",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-GOLF",
			"MCMSPG",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-HOTEL",
			"MCMSPH",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-MIKE",
			"MCMSPM",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_PAPA_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-PAPA-ZULU",
			"MCMSPZ",
			"Mine Countermeasures Operation Standard Letter Suffixes PAPA-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_ROMEO = new ActionTaskActivityCode(
			"MCM-SLS-ROMEO",
			"MCMSR",
			"Mine Countermeasures Operation Standard Letter Suffixes ROMEO.");
	public static final ActionTaskActivityCode MCM_SLS_ROMEO_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-ROMEO-DELTA",
			"MCMSRD",
			"Mine Countermeasures Operation Standard Letter Suffixes ROMEO-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_ROMEO_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-ROMEO-HOTEL",
			"MCMSRH",
			"Mine Countermeasures Operation Standard Letter Suffixes ROMEO-HOTEL.");
	public static final ActionTaskActivityCode MCM_SURVEY = new ActionTaskActivityCode(
			"MCM, survey",
			"MCMSRV",
			"To collect environmental data which may be used in support of current and future mine countermeasures (MCM) operations.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA",
			"MCMSS",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-ALPHA",
			"MCMSSA",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-CHARLIE",
			"MCMSSC",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-DELTA",
			"MCMSSD",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-GOLF",
			"MCMSSG",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-HOTEL",
			"MCMSSH",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-MIKE",
			"MCMSSM",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_SIERRA_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-SIERRA-ZULU",
			"MCMSSZ",
			"Mine Countermeasures Operation Standard Letter Suffixes SIERRA-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_UNIFORM = new ActionTaskActivityCode(
			"MCM-SLS-UNIFORM",
			"MCMSU",
			"Mine Countermeasures Operation Standard Letter Suffixes UNIFORM.");
	public static final ActionTaskActivityCode MCM_SLS_UNIFORM_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-UNIFORM-HOTEL",
			"MCMSUH",
			"Mine Countermeasures Operation Standard Letter Suffixes UNIFORM-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_UNIFORM_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-UNIFORM-ZULU",
			"MCMSUZ",
			"Mine Countermeasures Operation Standard Letter Suffixes UNIFORM-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR",
			"MCMSV",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_ALPHA = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-ALPHA",
			"MCMSVA",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-ALPHA.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_CHARLIE = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-CHARLIE",
			"MCMSVC",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-CHARLIE.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_DELTA = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-DELTA",
			"MCMSVD",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-DELTA.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_GOLF = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-GOLF",
			"MCMSVG",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-GOLF.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_HOTEL = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-HOTEL",
			"MCMSVH",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-HOTEL.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_MIKE = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-MIKE",
			"MCMSVM",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-MIKE.");
	public static final ActionTaskActivityCode MCM_SLS_VICTOR_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-VICTOR-ZULU",
			"MCMSVZ",
			"Mine Countermeasures Operation Standard Letter Suffixes VICTOR-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_WHISKEY = new ActionTaskActivityCode(
			"MCM-SLS-WHISKEY",
			"MCMSW",
			"Mine Countermeasures Operation Standard Letter Suffixes WHISKEY.");
	public static final ActionTaskActivityCode MCM_SLS_WHISKEY_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-WHISKEY-ZULU",
			"MCMSWZ",
			"Mine Countermeasures Operation Standard Letter Suffixes WHISKEY-ZULU.");
	public static final ActionTaskActivityCode MCM_SLS_ZULU_ZULU = new ActionTaskActivityCode(
			"MCM-SLS-ZULU-ZULU",
			"MCMSZZ",
			"Mine Countermeasures Operation Standard Letter Suffixes ZULU-ZULU.");
	public static final ActionTaskActivityCode MCM_TIME_LIMITED = new ActionTaskActivityCode(
			"MCM, time limited",
			"MCMTML",
			"To conduct a minesweeping and/or minehunting carried out when time available before ships are passed through a mined area, (or suspected mined area), is insufficient to carry out clearance operations.");
	public static final ActionTaskActivityCode MEDICAL_EVACUATION = new ActionTaskActivityCode(
			"Medical evacuation",
			"MEDEVC",
			"To move any person who is wounded, injured or ill to/between medical treatment facilities.");
	public static final ActionTaskActivityCode METEOROLOGICAL = new ActionTaskActivityCode(
			"Meteorological",
			"METBAL",
			"To gather meteorological information such as humidity, pressure, and temperature characteristics of Earth�s atmosphere.");
	public static final ActionTaskActivityCode MINE_COUNTERMEASURES = new ActionTaskActivityCode(
			"Mine countermeasures",
			"MINCM",
			"To perform mine countermeasures.");
	public static final ActionTaskActivityCode MINE_WARFARE = new ActionTaskActivityCode(
			"Mine warfare",
			"MINEWF",
			"To conduct warfare that includes the actions of laying mines and actions taken to counter the threat of an adversary (referred to as Mine Countermeasures).");
	public static final ActionTaskActivityCode MINE_LAYING = new ActionTaskActivityCode(
			"Mine-laying",
			"MINLAY",
			"To emplace or deploy one or more mines.");
	public static final ActionTaskActivityCode MINESWEEPING_LAND = new ActionTaskActivityCode(
			"Minesweeping, land",
			"MINSWP",
			"To search for or clear mines using mechanical or explosion gear, which physically removes or destroys the mine, or produces, in the area, the influence fields necessary to actuate it.");
	public static final ActionTaskActivityCode MISSION_STAGING = new ActionTaskActivityCode(
			"Mission staging",
			"MISSTG",
			"To perform the assembly of aircraft for the completion of a mission or other activity.");
	public static final ActionTaskActivityCode MINE_HUNTING_MARITIME = new ActionTaskActivityCode(
			"Mine hunting, maritime",
			"MNHUNT",
			"To locate and dispose of individual mines by means of detection equipment with the employment of ships, airborne equipment and/or divers.");
	public static final ActionTaskActivityCode MINESWEEPING_MARITIME = new ActionTaskActivityCode(
			"Minesweeping, maritime",
			"MNSWMA",
			"To search for or counter mines by maritime minesweepers using mechanical or explosive gear, which physically removes or destroys the mine, or by producing, in the volume, the influence field necessary to actuate it.");
	public static final ActionTaskActivityCode MAINTAIN_ON_CALL_AIRBORNE_ALERT = new ActionTaskActivityCode(
			"Maintain on call airborne alert",
			"MNTAIR",
			"To keep combat equipped aircraft airborne and prepared for immediate action. Airborne alert is designed to reduce reaction time and to increase the survivability factor.");
	public static final ActionTaskActivityCode MAINTAIN_ON_CALL_GROUND_ALERT = new ActionTaskActivityCode(
			"Maintain on call ground alert",
			"MNTGRD",
			"To keep aircraft on the ground/runway/deck fully serviced and armed, with combat crews in readiness to take off within a specified short period of time after receipt of a mission order.");
	public static final ActionTaskActivityCode MOP_UP = new ActionTaskActivityCode(
			"Mop up",
			"MOPUP",
			"To liquidate the remnants of enemy resistance in an area that has been surrounded or isolated, or through which other units have passed without eliminating all active resistance.");
	public static final ActionTaskActivityCode MOVE = new ActionTaskActivityCode(
			"Move",
			"MOVE",
			"To change position from one location to another.");
	public static final ActionTaskActivityCode PATROL_MARITIME = new ActionTaskActivityCode(
			"Patrol, maritime",
			"MPA",
			"To fly over an area, monitor and, where necessary, destroy hostile aircraft, as well as protect friendly shipping in the vicinity of the objective area.");
	public static final ActionTaskActivityCode MARITIME_INTERDICTION_OPERATIONS = new ActionTaskActivityCode(
			"Maritime interdiction operations",
			"MRITOP",
			"To conduct an operation that encompasses seaborne enforcement measures to interdict the movement of certain types of designated items into or out of a nation or specific area.");
	public static final ActionTaskActivityCode NAVAL_CONTROL_OF_SHIPPING = new ActionTaskActivityCode(
			"Naval control of shipping",
			"NACLSP",
			"Control exercised by naval authorities of movement, routing, reporting, convoy organisation and tactical diversion of Allied merchant shipping. It does not include the employment or active protection of such shipping.");
	public static final ActionTaskActivityCode NEUTRALIZE_CHEMICAL = new ActionTaskActivityCode(
			"Neutralize, chemical",
			"NTRCHM",
			"To make safe or non-toxic an object contaminated with a chemical agent.");
	public static final ActionTaskActivityCode NEUTRALIZE_COMBAT = new ActionTaskActivityCode(
			"Neutralize, combat",
			"NTRCOM",
			"To render ineffective or unusable in military operations.");
	public static final ActionTaskActivityCode NEUTRALIZE_EXPLOSIVE = new ActionTaskActivityCode(
			"Neutralize, explosive",
			"NTREXP",
			"To render bombs, mines, missiles and booby traps into a safe state.");
	public static final ActionTaskActivityCode NUCLEAR_SAMPLING = new ActionTaskActivityCode(
			"Nuclear sampling",
			"NUCSMP",
			"To collect samples for testing for nuclear hazards.");
	public static final ActionTaskActivityCode NAVAL_PLATFORM_FLIGHT_OPERATIONS = new ActionTaskActivityCode(
			"Naval platform flight operations",
			"NVLPLF",
			"To launch or recover aircraft by a naval platform.");
	public static final ActionTaskActivityCode OBSCURE = new ActionTaskActivityCode(
			"Obscure",
			"OBSCUR",
			"To cover something by a smoke screen.");
	public static final ActionTaskActivityCode OBSERVE = new ActionTaskActivityCode(
			"Observe",
			"OBSRV",
			"To provide continuous view, and the potential for reports on the activity of an ACTION-OBJECTIVE.");
	public static final ActionTaskActivityCode OCCUPY = new ActionTaskActivityCode(
			"Occupy",
			"OCCUPY",
			"To move onto an objective, key terrain, or other manmade or natural terrain area without opposition and control that entire area.");
	public static final ActionTaskActivityCode OFFENSIVE_AIR_SUPPORT = new ActionTaskActivityCode(
			"Offensive air support",
			"OFFAIR",
			"To provide support by the air forces on land or sea in offensive operations.");
	public static final ActionTaskActivityCode OFFENSIVE_COUNTER_AIR = new ActionTaskActivityCode(
			"Offensive counter air",
			"OFFCNA",
			"To conduct an operation to destroy, disrupt or limit enemy air power as close to its source as possible.");
	public static final ActionTaskActivityCode ORGANISE_CONFERENCE = new ActionTaskActivityCode(
			"Organise conference",
			"ORGCNF",
			"To organise a meeting for discussion, esp. a regular one held by an association or organisation.");
	public static final ActionTaskActivityCode ORGANISE_MEDIA_INTERVIEW = new ActionTaskActivityCode(
			"Organise media interview",
			"ORGMED",
			"To organise a conversation between a reporter etc. and a person of public interest, used as a basis of a broadcast or publication.");
	public static final ActionTaskActivityCode ORGANISE_RECREATIONAL_ACTIVITIES = new ActionTaskActivityCode(
			"Organise recreational activities",
			"ORGRCR",
			"To organise a refreshing or entertaining activity.");
	public static final ActionTaskActivityCode ORGANISE_SOCIAL_EVENTS = new ActionTaskActivityCode(
			"Organise social events",
			"ORGSCL",
			"To organise any social gathering, esp. one organised by a club or congregation.");
	public static final ActionTaskActivityCode ORGANISE_SPORTING_EVENTS = new ActionTaskActivityCode(
			"Organise sporting events",
			"ORGSPT",
			"To organise any game or competitive activity, esp. an outdoor one involving physical exertion.");
	public static final ActionTaskActivityCode PATROL = new ActionTaskActivityCode(
			"Patrol",
			"PATROL",
			"To gather information or to carry out a destructive, harassing, mopping-up, or security mission.");
	public static final ActionTaskActivityCode PENETRATE = new ActionTaskActivityCode(
			"Penetrate",
			"PENTRT",
			"To break through the enemy's defence or to disrupt the enemy's defensive systems.");
	public static final ActionTaskActivityCode PHOTO_MAPPING = new ActionTaskActivityCode(
			"Photo mapping",
			"PHOTO",
			"To collect a series of photographs from which it is possible to create maps.");
	public static final ActionTaskActivityCode PLAN = new ActionTaskActivityCode(
			"Plan",
			"PLAN",
			"To create a detailed formulation of a programme of action.");
	public static final ActionTaskActivityCode PREPARATORY_FIRE = new ActionTaskActivityCode(
			"Preparatory fire",
			"PREFIR",
			"To deliver fire on a target preparatory to an assault.");
	public static final ActionTaskActivityCode PREPARE = new ActionTaskActivityCode(
			"Prepare",
			"PREPR",
			"To establish certain conditions.");
	public static final ActionTaskActivityCode PROCURE = new ActionTaskActivityCode(
			"Procure",
			"PROCUR",
			"To buy whatever is needed to fulfil a certain action.");
	public static final ActionTaskActivityCode PROTECTION_ELECTRONIC = new ActionTaskActivityCode(
			"Protection, electronic",
			"PROTEL",
			"That division of electronic warfare involving actions taken to ensure effective friendly use of the electromagnetic spectrum despite the enemy's use of electromagnetic energy.");
	public static final ActionTaskActivityCode PROVIDE_ACCOMMODATION = new ActionTaskActivityCode(
			"Provide accommodation",
			"PRVACC",
			"To provide room for receiving people, esp. a place to live or lodgings.");
	public static final ActionTaskActivityCode PROVIDE_AGRICULTURAL_SUPPORT = new ActionTaskActivityCode(
			"Provide agricultural support",
			"PRVAGR",
			"To provide advice or supplies for cultivating the soil and rearing animals.");
	public static final ActionTaskActivityCode PROVIDE_BEDDING = new ActionTaskActivityCode(
			"Provide bedding",
			"PRVBDD",
			"To provide (1) sleeping accommodation or (2) mattress and bedclothes.");
	public static final ActionTaskActivityCode PROVIDE_CAMPS = new ActionTaskActivityCode(
			"Provide camps",
			"PRVCMP",
			"To provide temporary accommodation of various kinds, usually consisting of huts or tents, for detainees, homeless persons, and other emergency use.");
	public static final ActionTaskActivityCode PROVIDE_CONSTRUCTION_SERVICES = new ActionTaskActivityCode(
			"Provide construction services",
			"PRVCNS",
			"To provide labour and materiel for construction of facilities.");
	public static final ActionTaskActivityCode PROVIDE_EDUCATION_SERVICES = new ActionTaskActivityCode(
			"Provide education services",
			"PRVEDU",
			"To provide labour and materiel for the educational process.");
	public static final ActionTaskActivityCode PROVIDE_HEALTHCARE_SERVICES = new ActionTaskActivityCode(
			"Provide healthcare services",
			"PRVHLT",
			"To provide labour and materiel for maintaining the general health and welfare.");
	public static final ActionTaskActivityCode PROVIDE_INFRASTRUCTURE = new ActionTaskActivityCode(
			"Provide infrastructure",
			"PRVINF",
			"To provide basic facilities such as roads, bridges, and sewers.");
	public static final ActionTaskActivityCode PROVIDE_LAUNDRY_SERVICES = new ActionTaskActivityCode(
			"Provide laundry services",
			"PRVLND",
			"To provide labour and materiel for laundering of clothes or linens.");
	public static final ActionTaskActivityCode PROVIDE_REPAIR_SERVICES = new ActionTaskActivityCode(
			"Provide repair services",
			"PRVRPR",
			"To provide labour and materiel to restore objects to unimpaired condition.");
	public static final ActionTaskActivityCode PROVIDE_SECURITY_SERVICES = new ActionTaskActivityCode(
			"Provide security services",
			"PRVSCY",
			"To provide labour and materiel to assure safety of personnel and facilities.");
	public static final ActionTaskActivityCode PROVIDE_SHELTER = new ActionTaskActivityCode(
			"Provide shelter",
			"PRVSHL",
			"To provide housing.");
	public static final ActionTaskActivityCode PROVIDE_STORAGE_SERVICES = new ActionTaskActivityCode(
			"Provide storage services",
			"PRVSTG",
			"To provide services for storage.");
	public static final ActionTaskActivityCode PROVIDE_TRANSHIPMENT_SERVICES = new ActionTaskActivityCode(
			"Provide transhipment services",
			"PRVTRS",
			"To provide movement of cargo from one ship or train or container to another for further shipment.");
	public static final ActionTaskActivityCode PSYCHOLOGICAL_WARFARE = new ActionTaskActivityCode(
			"Psychological warfare",
			"PSYCHW",
			"To use propaganda or other means designed to undermine the morale or allegiance of one's opponents.");
	public static final ActionTaskActivityCode PUBLISH_MEDIA_ARTICLE = new ActionTaskActivityCode(
			"Publish media article",
			"PUBMDA",
			"To make generally known a non-fictional essay, esp. one included with others in a newspaper, magazine, journal, etc.");
	public static final ActionTaskActivityCode PUBLISH_MEDIA_DOCUMENTARY = new ActionTaskActivityCode(
			"Publish media documentary",
			"PUBMDD",
			"To make generally known any document published on a media that provides a factual record or report.");
	public static final ActionTaskActivityCode PUBLISH_PRESS_RELEASE = new ActionTaskActivityCode(
			"Publish press release",
			"PUBPRS",
			"To make generally known an official statement issued to media for information.");
	public static final ActionTaskActivityCode PURSUE = new ActionTaskActivityCode(
			"Pursue",
			"PURSUE",
			"To continue offensive operations designed to catch or cut off a hostile force attempting to escape, with the aim of destroying it. Typically, contact is maintained and risk taken to harass relentlessly, thereby turning the pursuit into a rout.");
	public static final ActionTaskActivityCode RADIO_RADAR_CALIBRATION = new ActionTaskActivityCode(
			"Radio/radar calibration",
			"RCALIB",
			"To fly on a specific route in order to allow calibration of radars and radios.");
	public static final ActionTaskActivityCode RECONNAISSANCE_ARMED = new ActionTaskActivityCode(
			"Reconnaissance, armed",
			"RECARM",
			"To locate and attack targets of opportunity, i.e. enemy material, personnel, and facilities in assigned surface communications routes, and not for the purpose of attacking specific briefed targets.");
	public static final ActionTaskActivityCode RECONNAISSANCE = new ActionTaskActivityCode(
			"Reconnaissance",
			"RECCE",
			"To conduct a mission to obtain by visual operations or other detection methods information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic or geographic characteristics of a particular area.");
	public static final ActionTaskActivityCode RECONNAISSANCE_IN_FORCE = new ActionTaskActivityCode(
			"Reconnaissance in force",
			"RECCEF",
			"To conduct an offensive operation designed to discover and/or test the enemy's strength, or to obtain other information.");
	public static final ActionTaskActivityCode RECONNAISSANCE_LAND = new ActionTaskActivityCode(
			"Reconnaissance, land",
			"RECCEL",
			"To obtain information concerning terrain, weather, and the disposition, composition, movement, installations, lines of communications, electronic and communication emissions of enemy forces. Also included are artillery and naval gunfire adjustment, and systematic and random observation of ground battle areas, targets, and/or sectors of airspace.");
	public static final ActionTaskActivityCode RECONNAISSANCE_SHADOW = new ActionTaskActivityCode(
			"Reconnaissance, shadow",
			"RECCES",
			"To observe an enemy unit or force, usually as a sequel to surveillance or reconnaissance, for the purpose of reporting its composition, location, movement, and any other relevant information.");
	public static final ActionTaskActivityCode RECONNAISSANCE_ECM = new ActionTaskActivityCode(
			"Reconnaissance, ECM",
			"RECECM",
			"To detect ECM activities and resources of an enemy or potential enemy in a particular area.");
	public static final ActionTaskActivityCode RECONSTITUTE = new ActionTaskActivityCode(
			"Reconstitute",
			"RECONS",
			"To attain prescribed strength of units and prescribed levels of vehicles, equipment, stores and supplies. The process will only take place after a unit/formation combat effectiveness has been reduced.");
	public static final ActionTaskActivityCode RECOVER = new ActionTaskActivityCode(
			"Recover",
			"RECOVR",
			"To retrieve any lost, incapacitated or captured object.");
	public static final ActionTaskActivityCode RECONNAISSANCE_PHOTOGRAPHIC = new ActionTaskActivityCode(
			"Reconnaissance, photographic",
			"RECPHO",
			"To obtain, by photographic means, information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographical, or geographical characteristics of a particular area.");
	public static final ActionTaskActivityCode RECONNAISSANCE_RADAR = new ActionTaskActivityCode(
			"Reconnaissance, radar",
			"RECRAD",
			"To obtain, by radar detection methods, information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographical, or geographical characteristics of a particular area.");
	public static final ActionTaskActivityCode RECONNAISSANCE_TARGET = new ActionTaskActivityCode(
			"Reconnaissance, target",
			"RECTGT",
			"To obtain information about the activities and resources of a target.");
	public static final ActionTaskActivityCode RECUPERATE = new ActionTaskActivityCode(
			"Recuperate",
			"RECUPR",
			"To rest a unit after it has been in action. Some reconstitution may take place as well.");
	public static final ActionTaskActivityCode RECONNAISSANCE_VISUAL = new ActionTaskActivityCode(
			"Reconnaissance, visual",
			"RECVIS",
			"To obtain visual information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographical, or geographical characteristics of a particular area.");
	public static final ActionTaskActivityCode REDEPLOY = new ActionTaskActivityCode(
			"Redeploy",
			"REDEPL",
			"To transfer a unit, an individual, or supplies deployed in one area to another area, or to another location within the area, for the purpose of further employment.");
	public static final ActionTaskActivityCode REFILL = new ActionTaskActivityCode(
			"Refill",
			"REFILL",
			"To fill again.");
	public static final ActionTaskActivityCode REFORM = new ActionTaskActivityCode(
			"Reform",
			"REFORM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1299/19.");
	public static final ActionTaskActivityCode REFUEL = new ActionTaskActivityCode(
			"Refuel",
			"REFUEL",
			"To take on more fuel.");
	public static final ActionTaskActivityCode REINFORCE = new ActionTaskActivityCode(
			"Reinforce",
			"REINF",
			"To move or make a force available to another commander for the purpose of supplementing the in-place forces.");
	public static final ActionTaskActivityCode REORGANISE = new ActionTaskActivityCode(
			"Reorganise",
			"REORG",
			"To change a task organisation for a particular operation. (Normally takes place before an operation). This includes the transfer of authority.");
	public static final ActionTaskActivityCode REPAIR = new ActionTaskActivityCode(
			"Repair",
			"REPAIR",
			"To restore an item to serviceable condition through correction of a specific failure or unserviceable condition.");
	public static final ActionTaskActivityCode RESCUE = new ActionTaskActivityCode(
			"Rescue",
			"RESCUE",
			"To use aircraft, surface craft (land or water), submarines, specialized rescue teams, and equipment to rescue personnel in distress on land or at sea.");
	public static final ActionTaskActivityCode REST = new ActionTaskActivityCode(
			"Rest",
			"REST",
			"To impose a specified period of inactivity on an ORGANISATION that is out of contact with the enemy.");
	public static final ActionTaskActivityCode RESUPPLY = new ActionTaskActivityCode(
			"Resupply",
			"RESUPL",
			"To replenish stocks in order to maintain the required levels of supply.");
	public static final ActionTaskActivityCode RETAIN = new ActionTaskActivityCode(
			"Retain",
			"RETAIN",
			"To occupy and hold a terrain feature to ensure it is free of enemy occupation or use.");
	public static final ActionTaskActivityCode RETIRE = new ActionTaskActivityCode(
			"Retire",
			"RETIRE",
			"To move a force out of contact with the enemy with the expectation of no further significant contact.");
	public static final ActionTaskActivityCode RELIEF_IN_PLACE = new ActionTaskActivityCode(
			"Relief in place",
			"RLFPLC",
			"To conduct an operation in which, by direction of higher authority, all or part of a unit is replaced in an area by the incoming unit. The responsibilities of the replaced elements for the mission and the assigned zone of operations are transferred to the incoming unit. The incoming unit continues the operation as ordered.");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_ALPHA = new ActionTaskActivityCode(
			"Rendezvous procedure alpha",
			"RNDZVA",
			"To rendezvous using a procedure directed by a radar control station, whether ground based, seaborne, or airborne (anchor rendezvous).");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_BRAVO = new ActionTaskActivityCode(
			"Rendezvous procedure bravo",
			"RNDZVB",
			"To rendezvous using a heading based procedure which utilises air-to-air equipment of both tanker and receiver. The tanker controls the procedure.");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_CHARLIE = new ActionTaskActivityCode(
			"Rendezvous procedure charlie",
			"RNDZVC",
			"To rendezvous using a heading based procedure which allows receivers with an airborne intercept (AI) radar to control the procedure once positive AI radar contact is established.");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_DELTA = new ActionTaskActivityCode(
			"Rendezvous procedure delta",
			"RNDZVD",
			"To rendezvous using a procedure that requires the receiver to maintain an agreed track and the tanker to maintain the reciprocal track, offset a pre-determined distance (point parallel).");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_ECHO = new ActionTaskActivityCode(
			"Rendezvous procedure echo",
			"RNDZVE",
			"To rendezvous using a procedure for use in support of a combat air patrol (CAP). It is particularly useful during periods of EMCON constraints.");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_FOXTROT = new ActionTaskActivityCode(
			"Rendezvous procedure foxtrot",
			"RNDZVF",
			"To rendezvous using a procedure where the tanker and receiver operate from the same base.");
	public static final ActionTaskActivityCode RENDEZVOUS_PROCEDURE_GOLF = new ActionTaskActivityCode(
			"Rendezvous procedure golf",
			"RNDZVG",
			"To rendezvous using a procedure that facilitates join-up on a common track; receivers may have departed either from the same or different bases (enroute).");
	public static final ActionTaskActivityCode RENDEZVOUS = new ActionTaskActivityCode(
			"Rendezvous",
			"RNDZVS",
			"To achieve a pre-arranged meeting at a given time and place.");
	public static final ActionTaskActivityCode SEARCH_AND_RESCUE = new ActionTaskActivityCode(
			"Search and rescue",
			"SAR",
			"To use aircraft, surface craft, submarines, specialized rescue teams and equipment to search for and rescue personnel in distress on land or at sea.");
	public static final ActionTaskActivityCode SEARCH_AND_RESCUE_COMBAT_EXFILTRATE = new ActionTaskActivityCode(
			"Search and rescue, combat, exfiltrate",
			"SARCME",
			"To remove personnel from areas under enemy control by specially trained personnel qualified to penetrate to the site of an incident by land or parachute, render medical aid, accomplish survival methods, and rescue survivors.");
	public static final ActionTaskActivityCode SEARCH_AND_RESCUE_COMBAT_INFILTRATE = new ActionTaskActivityCode(
			"Search and rescue, combat, infiltrate",
			"SARCMI",
			"To move through or into an area or territory occupied by either friendly or enemy troops or organisations specially trained personnel qualified to penetrate to the site of an incident by land or parachute, render medical aid, accomplish survival methods, and rescue survivors.");
	public static final ActionTaskActivityCode SEARCH_AND_RESCUE_PLANE_GUARD = new ActionTaskActivityCode(
			"Search and rescue, plane guard",
			"SARPLG",
			"Helicopter maintains station in vicinity of carrier for potential SAR during flight operations.");
	public static final ActionTaskActivityCode SCOUT = new ActionTaskActivityCode(
			"Scout",
			"SCOUT",
			"To collect intelligence without engaging enemy forces.");
	public static final ActionTaskActivityCode SCREEN = new ActionTaskActivityCode(
			"Screen",
			"SCREEN",
			"To operate as a security element whose primary task is to observe, identify and report information, and which only fights in self-protection.");
	public static final ActionTaskActivityCode SCRAMBLE = new ActionTaskActivityCode(
			"Scramble",
			"SCRMBL",
			"To launch or take-off an aircraft as quickly as possible, usually followed by mission instructions.");
	public static final ActionTaskActivityCode SECURE = new ActionTaskActivityCode(
			"Secure",
			"SECURE",
			"To gain possession of a position or terrain feature, with or without force, and to make such disposition as will prevent, as far as possible, its destruction or loss by enemy action.");
	public static final ActionTaskActivityCode SECURITY = new ActionTaskActivityCode(
			"Security",
			"SECURT",
			"To take measures necessary to achieve protection against espionage, sabotage, subversion and terrorism, as well as against loss or unauthorised disclosure.");
	public static final ActionTaskActivityCode SEIZE = new ActionTaskActivityCode(
			"Seize",
			"SEIZE",
			"To clear a designated area and obtain control of it.");
	public static final ActionTaskActivityCode SENSOR_IMPLANT = new ActionTaskActivityCode(
			"Sensor implant",
			"SENSIM",
			"To insert a piece of equipment which detects, and may indicate, and/or record objects and activities by means of energy or particles emitted, reflected, or modified by objects.");
	public static final ActionTaskActivityCode SERVE_AS_AN_ASSAULT_ECHELON = new ActionTaskActivityCode(
			"Serve as an assault echelon",
			"SERASE",
			"To serve as an element of a force which is scheduled for initial assault on the objective area.");
	public static final ActionTaskActivityCode SERVE_AS_AN_ATTACK_ECHELON = new ActionTaskActivityCode(
			"Serve as an attack echelon",
			"SERATE",
			"To serve as a fraction of a command in the direction of depth, to which an attack mission is assigned.");
	public static final ActionTaskActivityCode SEARCH = new ActionTaskActivityCode(
			"Search",
			"SERCH",
			"No definition provided in APP-6A.");
	public static final ActionTaskActivityCode SERVE_AS_THE_FOLLOW_ON_ECHELON = new ActionTaskActivityCode(
			"Serve as the follow-on echelon",
			"SERFLO",
			"To serve as, in amphibious operations, that echelon of the assault troops, vehicles, aircraft equipment, and supplies which, though not needed to initiate the assault, is required to support and sustain the assault.");
	public static final ActionTaskActivityCode SERVE_AS_THE_FIRST_OPERATIONAL_ECHELON = new ActionTaskActivityCode(
			"Serve as the first operational echelon",
			"SERFOE",
			"To serve as a fraction of a command, to which the first mission is assigned or which forms the forward line of own troops or which is first troops in the theatre.");
	public static final ActionTaskActivityCode SERVE_AS_THE_FORWARD_ECHELON = new ActionTaskActivityCode(
			"Serve as the forward echelon",
			"SERFRE",
			"To serve as a forward subdivision of a headquarters.");
	public static final ActionTaskActivityCode SERVE_AS_THE_FIRST_TACTICAL_ECHELON = new ActionTaskActivityCode(
			"Serve as the first tactical echelon",
			"SERFTE",
			"To serve as a fraction of a tactical command, to which a primary mission is assigned.");
	public static final ActionTaskActivityCode SERVE_AS_THE_FOLLOW_UP_ECHELON = new ActionTaskActivityCode(
			"Serve as the follow-up echelon",
			"SERFUE",
			"To serve as, in air transport operations, an element moved into the objective area after the assault echelon.");
	public static final ActionTaskActivityCode SERVE_AS_THE_REAR_ECHELON = new ActionTaskActivityCode(
			"Serve as the rear echelon",
			"SERREE",
			"To serve as elements of a force which are not required in the objective area.");
	public static final ActionTaskActivityCode SERVE_AS_THE_RESERVE_ECHELON = new ActionTaskActivityCode(
			"Serve as the reserve echelon",
			"SERRSE",
			"To serve as a fraction of a command in the direction of depth, which is an assigned reserve.");
	public static final ActionTaskActivityCode SERVE_AS_THE_SEA_ECHELON = new ActionTaskActivityCode(
			"Serve as the sea echelon",
			"SERSEA",
			"To serve as a portion of the assault shipping which withdraws from, or remains out of, the transport area during an amphibious landing and operates in designated areas to seaward in an on-call or unscheduled status.");
	public static final ActionTaskActivityCode SERVE_AS_THE_SECOND_OPERATIONAL_ECHELON = new ActionTaskActivityCode(
			"Serve as the second operational echelon",
			"SERSOE",
			"To serve as a fraction of an operational command either in the direction of depth or as a follow up on the timeline, to which a secondary operational mission is assigned.");
	public static final ActionTaskActivityCode SERVE_AS_A_SUPPORT_ECHELON = new ActionTaskActivityCode(
			"Serve as a support echelon",
			"SERSPE",
			"To serve as a fraction of a command in the direction of depth, to which a support mission is assigned.");
	public static final ActionTaskActivityCode SERVE_AS_THE_SECOND_TACTICAL_ECHELON = new ActionTaskActivityCode(
			"Serve as the second tactical echelon",
			"SERSTE",
			"To serve as a fraction of a tactical command either in the direction of depth or as a follow up on the timeline, to which a secondary tactical mission is assigned.");
	public static final ActionTaskActivityCode SERVE_AS_A_STRATEGIC_RESERVE = new ActionTaskActivityCode(
			"Serve as a strategic reserve",
			"SERSTR",
			"To serve as a fraction of a command in the direction of depth, which is an assigned strategic reserve.");
	public static final ActionTaskActivityCode SERVE_AS_THE_THEATRE_RESERVE = new ActionTaskActivityCode(
			"Serve as the theatre reserve",
			"SERTHR",
			"To serve as a fraction of a command in the direction of depth, which is an assigned theatre reserve.");
	public static final ActionTaskActivityCode SET_UP = new ActionTaskActivityCode(
			"Set up",
			"SETUP",
			"To prepare or establish a FACILITY, ORGANISATION or FEATURE.");
	public static final ActionTaskActivityCode SIGNALS_INTELLIGENCE_GATHERING = new ActionTaskActivityCode(
			"Signals intelligence gathering",
			"SINGA",
			"To intercept and gather electronic and communications transmissions for intelligence purposes.");
	public static final ActionTaskActivityCode SPECIAL_OPERATIONS = new ActionTaskActivityCode(
			"Special operations",
			"SPCOPS",
			"A mission conducted by specially designated, organised, trained and equipped forces using operational techniques and modes of employment not standard to conventional forces. These activities are conducted across the full range of military operations independently or in coordination with operations of conventional forces to achieve political, military, psychological and economic objectives. Politico-military considerations may require clandestine, covert or discrete techniques and the acceptance of a degree of physical and political risk not associated with conventional operations.");
	public static final ActionTaskActivityCode SPREAD = new ActionTaskActivityCode(
			"Spread",
			"SPREAD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1299/19.");
	public static final ActionTaskActivityCode SUPPORT_CONTINGENCY = new ActionTaskActivityCode(
			"Support, contingency",
			"SPTCON",
			"To involve in emergency, military forces due to natural disasters, terrorists, subversives, or by required military operations. Due to the uncertainty of the situation, contingencies require plans, rapid response, and special procedures to ensure the safety and readiness of personnel, installations, and equipment.");
	public static final ActionTaskActivityCode SUPPORT_ELECTRONIC = new ActionTaskActivityCode(
			"Support, electronic",
			"SPTELC",
			"To provide information required for decisions involving electronic warfare operations and other tactical actions such as threat avoidance, targeting, and homing.");
	public static final ActionTaskActivityCode SEARCH_BY_FIRE = new ActionTaskActivityCode(
			"Search by fire",
			"SRCHFR",
			"To distribute fire in depth by successive changes in the elevation of the gun.");
	public static final ActionTaskActivityCode SEARCH_AND_RESCUE_COMBAT = new ActionTaskActivityCode(
			"Search and rescue, combat",
			"SRCRES",
			"To detect, locate, identify and rescue downed aircrew in hostile territory in crisis and wartime and, when appropriate, isolated military personnel in distress, who are equipped and trained to receive CSAR support, throughout a theatre of operations.");
	public static final ActionTaskActivityCode STRIKE_CONTROL_AND_RECONNAISSANCE = new ActionTaskActivityCode(
			"Strike control and reconnaissance",
			"STRCON",
			"To conduct reconnaissance strike control and reconnaissance operations.");
	public static final ActionTaskActivityCode STRIKE_WARFARE = new ActionTaskActivityCode(
			"Strike warfare",
			"STRWAF",
			"To conduct warfare that includes strikes against targets ashore using carrier-based strike aircraft, sea-launched cruise missiles, naval guns, and special operations forces.");
	public static final ActionTaskActivityCode SUBMARINE_WARFARE = new ActionTaskActivityCode(
			"Submarine warfare",
			"SUBWAF",
			"To conduct warfare that includes the use of submarines.");
	public static final ActionTaskActivityCode SUPPRESS = new ActionTaskActivityCode(
			"Suppress",
			"SUPPRS",
			"To provide fire which neutralizes or temporarily degrades the capabilities of enemy forces within a specific area. This makes no assumptions as to enemy casualties; it may be a transitory effect.");
	public static final ActionTaskActivityCode SUPPORT = new ActionTaskActivityCode(
			"Support",
			"SUPPRT",
			"To aid, protect, complement or sustain any other object.");
	public static final ActionTaskActivityCode SURVEILLANCE_ELECTRONIC = new ActionTaskActivityCode(
			"Surveillance, electronic",
			"SURVEL",
			"The systematic observation of aerospace, surface or subsurface areas, places, persons, or things, by electronic means.");
	public static final ActionTaskActivityCode SURVEILLANCE = new ActionTaskActivityCode(
			"Surveillance",
			"SURVLE",
			"To observe aerospace, surface or subsurface areas, places, persons, or things, by visual, aural electronic, photographic, or other means.");
	public static final ActionTaskActivityCode SUSTAINING_OPERATIONS_AFLOAT_AND_ASHORE = new ActionTaskActivityCode(
			"Sustaining operations afloat and ashore",
			"SUSOAA",
			"To conduct an operation in which maritime forces continue to provide direct and indirect support to combat operations ashore, and help in sustaining land and air forces by maintaining sealift and keeping SLOC (Sea Lines of Communication) open.");
	public static final ActionTaskActivityCode SWEEP = new ActionTaskActivityCode(
			"Sweep",
			"SWEEP",
			"An offensive mission by fighter aircraft to seek out and destroy enemy aircraft and other targets of opportunity in an allocated area of operations.");
	public static final ActionTaskActivityCode TACTICAL_AIR_RECONNAISSANCE = new ActionTaskActivityCode(
			"Tactical air reconnaissance",
			"TCARRC",
			"Air action, which consist of the collection of information of intelligence from the air or through the use of airborne sensors.");
	public static final ActionTaskActivityCode TARGET_DILUTION = new ActionTaskActivityCode(
			"Target dilution",
			"TGTDLT",
			"To minimize the probability of acquisition of real targets by creating false targets in the vicinity of real targets by means of electronic spoofing or use of decoys.");
	public static final ActionTaskActivityCode THREATEN = new ActionTaskActivityCode(
			"Threaten",
			"THREAT",
			"To menace the enemy by manoeuvre or action.");
	public static final ActionTaskActivityCode TOW_TARGET = new ActionTaskActivityCode(
			"Tow, target",
			"TOWTGT",
			"To tow a target used for gunnery practice.");
	public static final ActionTaskActivityCode TRAIN = new ActionTaskActivityCode(
			"Train",
			"TRAIN",
			"To develop, maintain or improve the readiness of individuals or units.");
	public static final ActionTaskActivityCode TRAIN_OPERATIONS = new ActionTaskActivityCode(
			"Train, operations",
			"TRANOP",
			"Training operations or exercises. This training includes: a. delivery of personnel and equipment; b. Assault operations; c. Loading exercises and local orientation fights of short duration; and d. Manoeuvres and/or exercises as agreed upon by services concerned and/or as authorized by the joint chiefs of staff.");
	public static final ActionTaskActivityCode TRANSPORT = new ActionTaskActivityCode(
			"Transport",
			"TRANS",
			"To move assets using any means by sea, land or air to a specified objective.");
	public static final ActionTaskActivityCode TRANSPORT_ASSAULT_AIRLAND = new ActionTaskActivityCode(
			"Transport, assault airland",
			"TRNSAA",
			"To transport cargo and/or passengers delivered by air-landing the aircraft to a combat zone.");
	public static final ActionTaskActivityCode TRAVERSE = new ActionTaskActivityCode(
			"Traverse",
			"TRVRS",
			"To travel over a designated route.");
	public static final ActionTaskActivityCode TURN = new ActionTaskActivityCode(
			"Turn",
			"TURN",
			"To compel an enemy force to move from an avenue of approach or movement corridor to another.");
	public static final ActionTaskActivityCode UNCONVENTIONAL_WARFARE = new ActionTaskActivityCode(
			"Unconventional warfare",
			"UNCONW",
			"To conduct operations for military, political or economic purposes within an area occupied by the enemy and making use of the local inhabitants and resources.");
	public static final ActionTaskActivityCode UTILITY_FLIGHT = new ActionTaskActivityCode(
			"Utility flight",
			"UTILTY",
			"To conduct a flight in which the aircraft has the capability of performing multiple missions.");
	public static final ActionTaskActivityCode VERIFY = new ActionTaskActivityCode(
			"Verify",
			"VERIFY",
			"To testify to, to assert, to affirm or confirm, as true or certain.");
	public static final ActionTaskActivityCode WITHDRAW_UNDER_PRESSURE = new ActionTaskActivityCode(
			"Withdraw under pressure",
			"WDRPRS",
			"To disengage from the enemy when the enemy has sufficient contact with friendly forces to interfere with the withdrawal.");
	public static final ActionTaskActivityCode WITHDRAW = new ActionTaskActivityCode(
			"Withdraw",
			"WITHDR",
			"To disengage a force in contact from an enemy force.");
	public static final ActionTaskActivityCode WITNESS = new ActionTaskActivityCode(
			"Witness",
			"WITNES",
			"To observe an activity in an official capacity with a view of providing evidence.");
	public static final ActionTaskActivityCode WILD_WEASEL = new ActionTaskActivityCode(
			"Wild weasel",
			"WLDWSL",
			"To identify, locate, and physically suppress or destroy ground based enemy air defence systems that employ sensors radiating electromagnetic energy.");

	private ActionTaskActivityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
