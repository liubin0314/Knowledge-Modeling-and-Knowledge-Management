/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AffiliationFunctionalGroupCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the category of functional group.";
	}

	private static HashMap<String, AffiliationFunctionalGroupCode> physicalToCode = new HashMap<String, AffiliationFunctionalGroupCode>();

	public static AffiliationFunctionalGroupCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AffiliationFunctionalGroupCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AffiliationFunctionalGroupCode CRIMINAL = new AffiliationFunctionalGroupCode(
			"Criminal",
			"CRIMIN",
			"Affiliation is directed to a group that is organised for the conduct of criminal activity.");
	public static final AffiliationFunctionalGroupCode EXERCISE = new AffiliationFunctionalGroupCode(
			"Exercise",
			"EXER",
			"Affiliation is directed to a group that exists solely for the purpose of practice, rehearsal or training in the conduct of operations.");
	public static final AffiliationFunctionalGroupCode FINANCIAL = new AffiliationFunctionalGroupCode(
			"Financial",
			"FINANC",
			"Affiliation is directed to a group that provides financial support.");
	public static final AffiliationFunctionalGroupCode MULTINATIONAL = new AffiliationFunctionalGroupCode(
			"Multinational",
			"MULTIN",
			"Affiliation is directed to a group whose charter is based on a treaty signed by multiple nations.");
	public static final AffiliationFunctionalGroupCode NOT_KNOWN = new AffiliationFunctionalGroupCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AffiliationFunctionalGroupCode NOT_OTHERWISE_SPECIFIED = new AffiliationFunctionalGroupCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AffiliationFunctionalGroupCode POLITICAL = new AffiliationFunctionalGroupCode(
			"Political",
			"POLTCL",
			"Affiliation is directed to a group that is involved within a political area of activity and concerned with politics or has ties to a political party.");
	public static final AffiliationFunctionalGroupCode TERRORIST = new AffiliationFunctionalGroupCode(
			"Terrorist",
			"TERRST",
			"Affiliation is directed to a group that is organised for the conduct of terrorist activity.");
	public static final AffiliationFunctionalGroupCode TRIBAL = new AffiliationFunctionalGroupCode(
			"Tribal",
			"TRIBAL",
			"Affiliation is directed to a unit of socio-political organization consisting of a number of families, clans, or other groups who share a common ancestry and culture.");

	private AffiliationFunctionalGroupCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
