/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ElectronicEquipmentTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ELECTRONIC-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, ElectronicEquipmentTypeCategoryCode> physicalToCode = new HashMap<String, ElectronicEquipmentTypeCategoryCode>();

	public static ElectronicEquipmentTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ElectronicEquipmentTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ElectronicEquipmentTypeCategoryCode C3I = new ElectronicEquipmentTypeCategoryCode(
			"C3I",
			"C3I",
			"Equipment specifically designed to be used for Command, Control, Communications and Intelligence (C3I) support.");
	public static final ElectronicEquipmentTypeCategoryCode COMMUNICATION = new ElectronicEquipmentTypeCategoryCode(
			"Communication",
			"COM",
			"A group of interrelated communications equipment utilising the electromagnetic spectrum for the transmission and/or receiving of speech and data information.");
	public static final ElectronicEquipmentTypeCategoryCode DATA_PROCESSING = new ElectronicEquipmentTypeCategoryCode(
			"Data-processing",
			"DPE",
			"Equipment for storing, sharing and manipulation of data.");
	public static final ElectronicEquipmentTypeCategoryCode ELECTRONIC_WARFARE = new ElectronicEquipmentTypeCategoryCode(
			"Electronic warfare",
			"EW",
			"An equipment used for military action involving the use of electromagnetic energy to determine, exploit, reduce, or prevent hostile use of the electromagnetic spectrum and action to retain its effective use by friendly forces.");
	public static final ElectronicEquipmentTypeCategoryCode FIRE_CONTROL = new ElectronicEquipmentTypeCategoryCode(
			"Fire control",
			"FRC",
			"A group of interrelated fire control equipments and/or instruments designed for use with a weapon or group of weapons.");
	public static final ElectronicEquipmentTypeCategoryCode INSTRUMENT_LANDING_SYSTEM = new ElectronicEquipmentTypeCategoryCode(
			"Instrument landing system",
			"ILS",
			"An ELECTRONIC-EQUIPMENT-TYPE that provides aircraft with horizontal and vertical guidance just before landing and during landing, and at certain fixed points, indicates the distance to the reference point of landing.");
	public static final ElectronicEquipmentTypeCategoryCode NAVIGATIONAL_AID = new ElectronicEquipmentTypeCategoryCode(
			"Navigational aid",
			"NAV",
			"Any electronic device which provides point-to-point guidance information or position data.");
	public static final ElectronicEquipmentTypeCategoryCode NOT_KNOWN = new ElectronicEquipmentTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ElectronicEquipmentTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ElectronicEquipmentTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ElectronicEquipmentTypeCategoryCode PUBLIC_ADDRESS_SYSTEM = new ElectronicEquipmentTypeCategoryCode(
			"Public address system",
			"PAS",
			"A device capable of delivering voice messages.");
	public static final ElectronicEquipmentTypeCategoryCode RADAR = new ElectronicEquipmentTypeCategoryCode(
			"Radar",
			"RADAR",
			"Radio equipment based on emission of radio waves towards an object and analysis of the waves returned by that object or emitted in response to excitation by the received waves.");
	public static final ElectronicEquipmentTypeCategoryCode SENSOR = new ElectronicEquipmentTypeCategoryCode(
			"Sensor",
			"SEN",
			"A device that detects or measures a physical property and records, indicates, or otherwise responds to it.");

	private ElectronicEquipmentTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
