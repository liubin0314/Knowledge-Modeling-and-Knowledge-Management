/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeEstablishmentEnvironmentConditionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the environmental conditions for which a specific OBJECT-TYPE-ESTABLISHMENT is authorised.";
	}

	private static HashMap<String, ObjectTypeEstablishmentEnvironmentConditionCode> physicalToCode = new HashMap<String, ObjectTypeEstablishmentEnvironmentConditionCode>();

	public static ObjectTypeEstablishmentEnvironmentConditionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeEstablishmentEnvironmentConditionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeEstablishmentEnvironmentConditionCode ARCTIC = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Arctic",
			"ARC",
			"An indication that the specified establishment is authorised for use in arctic conditions.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode DESERT = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Desert",
			"DES",
			"An indication that the specified establishment is authorised for use in desert conditions.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode JUNGLE = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Jungle",
			"JUN",
			"An indication that the specified establishment is authorised for use in jungle conditions.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode MOUNTAIN = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Mountain",
			"MOUNTN",
			"An indication that the specified establishment is authorised for use in mountain conditions.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode NOT_KNOWN = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode NOT_OTHERWISE_SPECIFIED = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode TEMPERATE = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Temperate",
			"TMP",
			"An indication that the specified establishment is authorised for use in temperate conditions.");
	public static final ObjectTypeEstablishmentEnvironmentConditionCode TROPICAL = new ObjectTypeEstablishmentEnvironmentConditionCode(
			"Tropical",
			"TRP",
			"An indication that the specified establishment is authorised for use in tropical conditions.");

	private ObjectTypeEstablishmentEnvironmentConditionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
