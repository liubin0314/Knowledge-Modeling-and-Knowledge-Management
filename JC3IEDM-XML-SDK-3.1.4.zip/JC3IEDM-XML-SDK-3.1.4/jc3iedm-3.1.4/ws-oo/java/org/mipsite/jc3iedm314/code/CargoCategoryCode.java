/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CargoCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of cargo that is subject to a HANDLING-CAPABILITY or a STORAGE-CAPABILITY.";
	}

	private static HashMap<String, CargoCategoryCode> physicalToCode = new HashMap<String, CargoCategoryCode>();

	public static CargoCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CargoCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CargoCategoryCode AIRCRAFT = new CargoCategoryCode(
			"Aircraft",
			"ACFT",
			"The specific cargo consists of aircraft.");
	public static final CargoCategoryCode AGRICULTURAL_PRODUCTS = new CargoCategoryCode(
			"Agricultural products",
			"AGP",
			"The specific cargo consists of agricultural products.");
	public static final CargoCategoryCode AMMUNITION = new CargoCategoryCode(
			"Ammunition",
			"AMMO",
			"The specific cargo consists of ammunition.");
	public static final CargoCategoryCode ARMS_AMMUNITION_AND_EXPLOSIVES = new CargoCategoryCode(
			"Arms, ammunition and explosives",
			"ARAMEX",
			"The specific cargo consists of arms, ammunition and explosives.");
	public static final CargoCategoryCode BOATS = new CargoCategoryCode(
			"Boats",
			"BOATS",
			"The specific cargo consists of boats.");
	public static final CargoCategoryCode BULK_CARGO = new CargoCategoryCode(
			"Bulk cargo",
			"BULK",
			"The specific cargo consists of bulk.");
	public static final CargoCategoryCode CHEMICALS = new CargoCategoryCode(
			"Chemicals",
			"CHE",
			"The specific cargo consists of chemical products.");
	public static final CargoCategoryCode REEFER_CARGO_CHILL = new CargoCategoryCode(
			"Reefer cargo (chill)",
			"CHILL",
			"The specific cargo consists of reefer cargo (chill).");
	public static final CargoCategoryCode CLASSIFIED_OR_PROTECTED_CARGO = new CargoCategoryCode(
			"Classified or protected cargo",
			"CLASS",
			"The specific cargo consists of classified or protected cargo.");
	public static final CargoCategoryCode COAL = new CargoCategoryCode(
			"Coal",
			"COL",
			"The specific cargo consists of coal.");
	public static final CargoCategoryCode CONSTRUCTION_MATERIALS = new CargoCategoryCode(
			"Construction materials",
			"CON",
			"The specific cargo consists of construction materials.");
	public static final CargoCategoryCode CONTAINERS = new CargoCategoryCode(
			"Containers",
			"CTR",
			"The specific cargo consists of containers.");
	public static final CargoCategoryCode DRY_CARGO = new CargoCategoryCode(
			"Dry cargo",
			"DRY",
			"The specific cargo consists of dry cargo.");
	public static final CargoCategoryCode FORESTRY_PRODUCTS = new CargoCategoryCode(
			"Forestry products",
			"FOP",
			"The specific cargo consists of forestry products.");
	public static final CargoCategoryCode REEFER_CARGO_FREEZE = new CargoCategoryCode(
			"Reefer cargo (freeze)",
			"FREEZE",
			"The specific cargo consists of reefer cargo (freeze).");
	public static final CargoCategoryCode GENERAL_CARGO = new CargoCategoryCode(
			"General cargo",
			"GEN",
			"The specific cargo consists of general cargo.");
	public static final CargoCategoryCode HAZARDOUS_MATERIAL = new CargoCategoryCode(
			"Hazardous material",
			"HAZMAT",
			"The specific cargo consists of general cargo composed of hazardous material.");
	public static final CargoCategoryCode HEAVY_EQUIPMENT = new CargoCategoryCode(
			"Heavy equipment",
			"HYEQPT",
			"The specific cargo consists of heavy equipment.");
	public static final CargoCategoryCode LIQUID_CARGO = new CargoCategoryCode(
			"Liquid cargo",
			"LIQUID",
			"The specific cargo consists of liquid cargo.");
	public static final CargoCategoryCode MILITARY_ASSOCIATED_CARGO = new CargoCategoryCode(
			"Military associated cargo",
			"MAC",
			"The specific cargo consists of military associated cargo.");
	public static final CargoCategoryCode MAIL = new CargoCategoryCode(
			"Mail",
			"MAIL",
			"The specific cargo consists of mail.");
	public static final CargoCategoryCode MATERIAL = new CargoCategoryCode(
			"Material",
			"MAT",
			"The specific cargo consists of material.");
	public static final CargoCategoryCode MATERIAL_AND_EQUIPMENT = new CargoCategoryCode(
			"Material and equipment",
			"MCH",
			"The specific cargo consists of material and equipment.");
	public static final CargoCategoryCode MEDICAL_SUPPLIES = new CargoCategoryCode(
			"Medical supplies",
			"MED",
			"The specific cargo consists of medical supplies.");
	public static final CargoCategoryCode MINERALS_METALS = new CargoCategoryCode(
			"Minerals/metals",
			"MIM",
			"The specific cargo consists of minerals/metals.");
	public static final CargoCategoryCode OTHER = new CargoCategoryCode(
			"Other",
			"OTR",
			"The specific cargo consists of other cargo.");
	public static final CargoCategoryCode PASSENGERS = new CargoCategoryCode(
			"Passengers",
			"PAX",
			"The specific cargo consists of passengers.");
	public static final CargoCategoryCode PERSONNEL = new CargoCategoryCode(
			"Personnel",
			"PERS",
			"The specific cargo consists of personnel.");
	public static final CargoCategoryCode PETROLEUM_OILS_AND_LUBRICANTS = new CargoCategoryCode(
			"Petroleum, oils and lubricants",
			"POL",
			"The specific cargo consists of petroleum, oils and lubricants.");
	public static final CargoCategoryCode PRISONERS_OF_WAR = new CargoCategoryCode(
			"Prisoners of war",
			"POW",
			"The specific cargo consists of prisoners of war.");
	public static final CargoCategoryCode SPECIAL_CARGO = new CargoCategoryCode(
			"Special cargo",
			"SPECL",
			"The specific cargo consists of special cargo.");
	public static final CargoCategoryCode SUBSISTENCE = new CargoCategoryCode(
			"Subsistence",
			"SUBS",
			"The specific cargo consists of subsistence.");
	public static final CargoCategoryCode SUGAR = new CargoCategoryCode(
			"Sugar",
			"SUG",
			"The specific cargo consists of sugar.");
	public static final CargoCategoryCode TEXTILES_AND_TEXTILE_APPAREL = new CargoCategoryCode(
			"Textiles and textile apparel",
			"TEX",
			"The specific cargo consists of textiles and textile apparels.");
	public static final CargoCategoryCode TROOPS = new CargoCategoryCode(
			"Troops",
			"TROOPS",
			"The specific cargo consists of troops.");
	public static final CargoCategoryCode VEHICLE_NON_MILITARY = new CargoCategoryCode(
			"Vehicle (non-military)",
			"VEH",
			"The specific cargo consists of non-military vehicles.");
	public static final CargoCategoryCode VEHICLE_TRACKED = new CargoCategoryCode(
			"Vehicle (tracked)",
			"VEHT",
			"The specific cargo consists of tracked vehicles.");
	public static final CargoCategoryCode VEHICLE_WHEELED = new CargoCategoryCode(
			"Vehicle (wheeled)",
			"VEHW",
			"The specific cargo consists of wheeled vehicles.");
	public static final CargoCategoryCode WOUNDED = new CargoCategoryCode(
			"Wounded",
			"WOUND",
			"The specific cargo consists of wounded persons.");

	private CargoCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
