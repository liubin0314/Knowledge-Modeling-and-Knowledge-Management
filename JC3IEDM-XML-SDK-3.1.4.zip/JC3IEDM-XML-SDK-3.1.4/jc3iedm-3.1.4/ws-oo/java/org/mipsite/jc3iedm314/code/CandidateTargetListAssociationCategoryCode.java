/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetListAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CANDIDATE-TARGET-LIST-ASSOCIATION.";
	}

	private static HashMap<String, CandidateTargetListAssociationCategoryCode> physicalToCode = new HashMap<String, CandidateTargetListAssociationCategoryCode>();

	public static CandidateTargetListAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetListAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetListAssociationCategoryCode HAS_AS_A_COMPONENT = new CandidateTargetListAssociationCategoryCode(
			"Has as a component",
			"COMPNT",
			"The subject CANDIDATE-TARGET-LIST incorporates the object CANDIDATE-TARGET-LIST in its entirety.");
	public static final CandidateTargetListAssociationCategoryCode INCORPORATES_PARTS_OF = new CandidateTargetListAssociationCategoryCode(
			"Incorporates parts of",
			"INCPRT",
			"The subject CANDIDATE-TARGET-LIST uses details from the object CANDIDATE-TARGET-LIST.");
	public static final CandidateTargetListAssociationCategoryCode PRECEDES = new CandidateTargetListAssociationCategoryCode(
			"Precedes",
			"PRECED",
			"The subject CANDIDATE-TARGET-LIST must be considered ahead of the object CANDIDATE-TARGET-LIST.");
	public static final CandidateTargetListAssociationCategoryCode REPLACES = new CandidateTargetListAssociationCategoryCode(
			"Replaces",
			"REPLAC",
			"The subject CANDIDATE-TARGET-LIST is substituted for the object CANDIDATE-TARGET-LIST in its entirety.");

	private CandidateTargetListAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
