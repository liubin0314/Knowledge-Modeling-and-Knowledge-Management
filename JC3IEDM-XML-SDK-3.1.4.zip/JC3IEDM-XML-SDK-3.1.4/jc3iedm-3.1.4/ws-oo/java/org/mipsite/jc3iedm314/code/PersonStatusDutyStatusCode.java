/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonStatusDutyStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the availability of a specific PERSON for duty at a military or civilian post of employment.";
	}

	private static HashMap<String, PersonStatusDutyStatusCode> physicalToCode = new HashMap<String, PersonStatusDutyStatusCode>();

	public static PersonStatusDutyStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonStatusDutyStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonStatusDutyStatusCode ABSENT = new PersonStatusDutyStatusCode(
			"Absent",
			"ABS",
			"Not present at the place of duty for an as yet unspecified reason and has not been posted as either deceased or missing.");
	public static final PersonStatusDutyStatusCode AT_DUTY = new PersonStatusDutyStatusCode(
			"At duty",
			"ADU",
			"Present at the place of duty.");
	public static final PersonStatusDutyStatusCode ASSUMED_KILLED_IN_ACTION = new PersonStatusDutyStatusCode(
			"Assumed killed in action",
			"AKIA",
			"Subjectively judged by the reporting organisation that due to the nature of the destruction of the equipment, the individual is assumed dead.");
	public static final PersonStatusDutyStatusCode ARRESTED = new PersonStatusDutyStatusCode(
			"Arrested",
			"ARR",
			"Being held by friendly forces military police or civilian police force on suspicion of having committed an offence against either military or civil law.");
	public static final PersonStatusDutyStatusCode DECEASED = new PersonStatusDutyStatusCode(
			"Deceased",
			"DEC",
			"A status indicating that a PERSON is dead.");
	public static final PersonStatusDutyStatusCode DESERTED = new PersonStatusDutyStatusCode(
			"Deserted",
			"DESRTD",
			"The PERSON has left the place of duty permanently without permission.");
	public static final PersonStatusDutyStatusCode HOSPITALISED = new PersonStatusDutyStatusCode(
			"Hospitalised",
			"HSP",
			"A status indicating that a PERSON is in a hospital.");
	public static final PersonStatusDutyStatusCode HOSTAGE = new PersonStatusDutyStatusCode(
			"Hostage",
			"HST",
			"Has been captured by opposing forces or a terrorist organisation and is being held for the purpose of negotiation.");
	public static final PersonStatusDutyStatusCode MISSING = new PersonStatusDutyStatusCode(
			"Missing",
			"MIS",
			"Is missing but has not been posted as absent or deceased.");
	public static final PersonStatusDutyStatusCode NOT_KNOWN = new PersonStatusDutyStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonStatusDutyStatusCode ON_LEAVE = new PersonStatusDutyStatusCode(
			"On leave",
			"OLV",
			"A status indicating that a PERSON is absent from duty with permission.");
	public static final PersonStatusDutyStatusCode PRISONER_OF_WAR = new PersonStatusDutyStatusCode(
			"Prisoner of war",
			"POW",
			"Has been captured by opposing forces and is being held in internment.");

	private PersonStatusDutyStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
