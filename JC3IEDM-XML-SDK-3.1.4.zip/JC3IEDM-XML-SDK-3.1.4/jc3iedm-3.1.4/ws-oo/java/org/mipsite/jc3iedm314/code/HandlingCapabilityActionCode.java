/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HandlingCapabilityActionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of a specific HANDLING-CAPABILITY.";
	}

	private static HashMap<String, HandlingCapabilityActionCode> physicalToCode = new HashMap<String, HandlingCapabilityActionCode>();

	public static HandlingCapabilityActionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HandlingCapabilityActionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HandlingCapabilityActionCode HOIST = new HandlingCapabilityActionCode(
			"Hoist",
			"HOIST",
			"The specific HANDLING-CAPABILITY to raise or haul up.");
	public static final HandlingCapabilityActionCode LOAD = new HandlingCapabilityActionCode(
			"Load",
			"LOAD",
			"The specific HANDLING-CAPABILITY involves loading.");
	public static final HandlingCapabilityActionCode LOAD_OR_UNLOAD = new HandlingCapabilityActionCode(
			"Load or unload",
			"LOADUN",
			"The specific HANDLING-CAPABILITY involves both loading and unloading.");
	public static final HandlingCapabilityActionCode UNLOAD = new HandlingCapabilityActionCode(
			"Unload",
			"UNLOAD",
			"The specific HANDLING-CAPABILITY involves unloading.");

	private HandlingCapabilityActionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
