/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MineStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the status of a mine.";
	}

	private static HashMap<String, MineStatusCode> physicalToCode = new HashMap<String, MineStatusCode>();

	public static MineStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MineStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MineStatusCode ACTIVATED_MINE = new MineStatusCode(
			"Activated mine",
			"ACTVED",
			"The specified mine has been activated through either influence or control signal.");
	public static final MineStatusCode CLASSIFIED_MINE = new MineStatusCode(
			"Classified mine",
			"CLSSFD",
			"The specified mine has been located and has been evaluated by a competent authority.");
	public static final MineStatusCode COUNTERMINED_MINE = new MineStatusCode(
			"Countermined mine",
			"CNTRMN",
			"The specified mine has been exploded by the shock of a nearby explosion of another mine or independent explosive charge.");
	public static final MineStatusCode IDENTIFIED_MINE = new MineStatusCode(
			"Identified mine",
			"IDNTMN",
			"The specified mine has been located, has been processed by a competent authority and its exact nature is known.");
	public static final MineStatusCode MINE_LEFT_IN_PLACE = new MineStatusCode(
			"Mine left in place",
			"MNLFPL",
			"The specified mine is located and remains in its original location.");
	public static final MineStatusCode MARKED_MINE = new MineStatusCode(
			"Marked mine",
			"MRKDMN",
			"The specified mine is located and its presence is indicated by some form of physical identification device.");
	public static final MineStatusCode NEUTRALIZED_MINE = new MineStatusCode(
			"Neutralized mine",
			"NEUTRL",
			"The specified mine is rendered, by external means, permanently incapable of firing, although it may remain dangerous to handle. The mine case may remain virtually intact.");
	public static final MineStatusCode RECOVERED_MINE = new MineStatusCode(
			"Recovered mine",
			"RECVRD",
			"The specified mine is salvaged as nearly intact as possible to permit further investigation for intelligence and/or evaluation purposes.");
	public static final MineStatusCode REMOVED_MINE = new MineStatusCode(
			"Removed mine",
			"REMOVD",
			"The specified mine is taken out of an area where its detonation would be unacceptable.");
	public static final MineStatusCode RENDERED_SAFE_MINE = new MineStatusCode(
			"Rendered safe mine",
			"RNDERD",
			"The specified mine is made safe by the application of special explosive ordnance disposal methods and tools for the interruption of function or separation of essential components of unexploded ordnance to prevent an unacceptable detonation.");
	public static final MineStatusCode SUNK_MINE = new MineStatusCode(
			"Sunk mine",
			"SUNKMN",
			"The specified mine has lost its buoyancy.");

	private MineStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
