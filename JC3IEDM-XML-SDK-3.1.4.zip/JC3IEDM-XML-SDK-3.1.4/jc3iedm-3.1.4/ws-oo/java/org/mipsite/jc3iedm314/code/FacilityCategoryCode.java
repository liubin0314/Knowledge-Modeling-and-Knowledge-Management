/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FACILITY.";
	}

	private static HashMap<String, FacilityCategoryCode> physicalToCode = new HashMap<String, FacilityCategoryCode>();

	public static FacilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityCategoryCode AIRFIELD = new FacilityCategoryCode(
			"AIRFIELD",
			"AIRFLD",
			"A FACILITY that is an area prepared for the accommodation (including any buildings, installations, or equipment) landing and take off of aircraft.");
	public static final FacilityCategoryCode ANCHORAGE = new FacilityCategoryCode(
			"ANCHORAGE",
			"ANCHOR",
			"A FACILITY that is a place where vessels anchor.");
	public static final FacilityCategoryCode APRON = new FacilityCategoryCode(
			"APRON",
			"APRON",
			"A FACILITY that is an area intended for parking, loading, unloading and/or servicing.");
	public static final FacilityCategoryCode BASIN = new FacilityCategoryCode(
			"BASIN",
			"BASIN",
			"A FACILITY that is an open area of water, usually artificial and enclosed by dock gates lined with wharves, warehouses and berths to enable vessels to load and unload.");
	public static final FacilityCategoryCode BERTH = new FacilityCategoryCode(
			"BERTH",
			"BERTH",
			"A FACILITY that is a space or length in the water at a harbour allocated to or reserved for a vessel to dock and moor for loading or unloading.");
	public static final FacilityCategoryCode BRIDGE = new FacilityCategoryCode(
			"BRIDGE",
			"BRIDGE",
			"A FACILITY that is a structure (including overpass and viaduct), fixed or moveable, spanning and/or providing passage over an object.");
	public static final FacilityCategoryCode DRY_DOCK = new FacilityCategoryCode(
			"DRY-DOCK",
			"DRYDCK",
			"A FACILITY that provides an enclosure for maintenance, building or repairing ships, from which water can be pumped out.");
	public static final FacilityCategoryCode HARBOUR = new FacilityCategoryCode(
			"HARBOUR",
			"HARBOR",
			"A FACILITY that is a restricted body of water, an anchorage, or other limited coastal water area and its water approaches from which and in which shipping operations are projected or supported.");
	public static final FacilityCategoryCode JETTY = new FacilityCategoryCode(
			"JETTY",
			"JETTY",
			"A FACILITY that is a platform that may be fixed or floating extending from a shore, normally attached to a wharf or the shore, and which allows access to a vessel lying alongside, used to secure, protect and provide landing and docking for vessels.");
	public static final FacilityCategoryCode MILITARY_OBSTACLE = new FacilityCategoryCode(
			"MILITARY-OBSTACLE",
			"MILOBS",
			"A FACILITY designed to stop, impede, or divert movement of amphibious or ground forces.");
	public static final FacilityCategoryCode NETWORK = new FacilityCategoryCode(
			"NETWORK",
			"NETWRK",
			"A FACILITY that provides bearer services for communication and information services and is composed of one or more links and nodes.");
	public static final FacilityCategoryCode NOT_OTHERWISE_SPECIFIED = new FacilityCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final FacilityCategoryCode QUAY = new FacilityCategoryCode(
			"QUAY",
			"QUAY",
			"A FACILITY that is a solidly constructed platform, usually parallel to the shoreline of navigable water, alongside which a vessel can be docked or berthed and, on which, the vessel can be accessed and cargo can be loaded or unloaded on one side of the vessel only.");
	public static final FacilityCategoryCode RAILWAY = new FacilityCategoryCode(
			"RAILWAY",
			"RALWAY",
			"A FACILITY that is a track or set of tracks made of steel rails along which trains run.");
	public static final FacilityCategoryCode ROAD = new FacilityCategoryCode(
			"ROAD",
			"ROAD",
			"A FACILITY that is a path or way with a specially prepared surface.");
	public static final FacilityCategoryCode RUNWAY = new FacilityCategoryCode(
			"RUNWAY",
			"RUNWAY",
			"A FACILITY that is a specifically prepared surface along which aircraft take off and land.");
	public static final FacilityCategoryCode SLIPWAY = new FacilityCategoryCode(
			"SLIPWAY",
			"SLPWAY",
			"A FACILITY that provides a sloping surface or inclined structure leading down to the water.");

	private FacilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
