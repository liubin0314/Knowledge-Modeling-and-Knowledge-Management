/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-RESOURCE with respect to item or type.";
	}

	private static HashMap<String, ActionResourceCategoryCode> physicalToCode = new HashMap<String, ActionResourceCategoryCode>();

	public static ActionResourceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceCategoryCode ACTION_RESOURCE_ITEM = new ActionResourceCategoryCode(
			"ACTION-RESOURCE-ITEM",
			"RI",
			"An OBJECT-ITEM (FACILITY, FEATURE, MATERIEL, ORGANISATION, or PERSON) to be used, excluded from use, being used, or having been used, in conducting a specific ACTION.");
	public static final ActionResourceCategoryCode ACTION_RESOURCE_TYPE = new ActionResourceCategoryCode(
			"ACTION-RESOURCE-TYPE",
			"RT",
			"An OBJECT-TYPE (FACILITY-TYPE, FEATURE-TYPE, MATERIEL-TYPE, ORGANISATION-TYPE, or PERSON-TYPE) to be used, excluded from use, being used, or having been used, in conducting a specific ACTION.");

	private ActionResourceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
