/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AmmunitionTypeMineMaritimeFiringCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the firing mechanism for a maritime mine.";
	}

	private static HashMap<String, AmmunitionTypeMineMaritimeFiringCode> physicalToCode = new HashMap<String, AmmunitionTypeMineMaritimeFiringCode>();

	public static AmmunitionTypeMineMaritimeFiringCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AmmunitionTypeMineMaritimeFiringCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AmmunitionTypeMineMaritimeFiringCode ACOUSTIC_AUDIO_FREQUENCY = new AmmunitionTypeMineMaritimeFiringCode(
			"Acoustic audio frequency",
			"ACOUAF",
			"A (maritime) mine firing mechanism with an acoustic audio circuit which responds to the acoustic field of a ship or sweep.");
	public static final AmmunitionTypeMineMaritimeFiringCode ACOUSTIC_HIGH_FREQUENCY = new AmmunitionTypeMineMaritimeFiringCode(
			"Acoustic high frequency",
			"ACOUHF",
			"A (maritime) mine firing mechanism with an acoustic high frequency circuit, 20 to 50 Hz, which responds to the acoustic field of a ship or sweep.");
	public static final AmmunitionTypeMineMaritimeFiringCode ACOUSTIC_LOW_FREQUENCY = new AmmunitionTypeMineMaritimeFiringCode(
			"Acoustic low frequency",
			"ACOULF",
			"A (maritime) mine firing mechanism with an acoustic low frequency circuit, less than 2 Hz, which responds to the acoustic field of a ship or sweep.");
	public static final AmmunitionTypeMineMaritimeFiringCode ACOUSTIC = new AmmunitionTypeMineMaritimeFiringCode(
			"Acoustic",
			"ACOUST",
			"A (maritime) mine firing mechanism with an acoustic circuit which responds to the acoustic field of a ship or sweep.");
	public static final AmmunitionTypeMineMaritimeFiringCode ACTIVE = new AmmunitionTypeMineMaritimeFiringCode(
			"Active",
			"ACTIVE",
			"A (maritime) mine firing mechanism actuated by the reflection from a target of a signal emitted by the mine.");
	public static final AmmunitionTypeMineMaritimeFiringCode ANTENNA = new AmmunitionTypeMineMaritimeFiringCode(
			"Antenna",
			"ANTENA",
			"A contact (maritime) mine firing mechanism which, when touched by a ferrous object, set up galvanic action to fire the mine. The antenna generally takes the form of a special section in the mooring cable, and/or special cable suspended above the mine by a float.");
	public static final AmmunitionTypeMineMaritimeFiringCode COARSE_ANTI_SWEEP = new AmmunitionTypeMineMaritimeFiringCode(
			"Coarse, anti-sweep",
			"COARAS",
			"A (maritime) mine firing mechanism fitted that is regarded as coarse firing.");
	public static final AmmunitionTypeMineMaritimeFiringCode COMBINATION_OVERLAP = new AmmunitionTypeMineMaritimeFiringCode(
			"Combination, overlap",
			"COMBIN",
			"A (maritime) mine firing mechanism that fires depending upon the previous simultaneous or subsequent reception of signals resulting from other influences, such as acoustic and pressure.");
	public static final AmmunitionTypeMineMaritimeFiringCode CONTACT = new AmmunitionTypeMineMaritimeFiringCode(
			"Contact",
			"CONTCT",
			"A (maritime) mine firing mechanism that is designed to fire by physical contact between the target mine or its appendages.");
	public static final AmmunitionTypeMineMaritimeFiringCode FITTED_WITH_DELAYED_ARMING_OR_RISING_MECHANISM = new AmmunitionTypeMineMaritimeFiringCode(
			"Fitted with delayed arming or rising mechanism",
			"FITWDA",
			"A (maritime) mine firing mechanism fitted with a timing mechanism that keeps the mine circuits open (off) for a preset time after laying. If fitted with also a rising mechanism the release and rising of the mine can be delayed by means of a device fitted to either the sinker or to the windings of the mooring cable.");
	public static final AmmunitionTypeMineMaritimeFiringCode FITTED_WITH_SHIP_COUNTER = new AmmunitionTypeMineMaritimeFiringCode(
			"Fitted with ship counter",
			"FITWSC",
			"A (maritime) mine firing mechanism fitted with a ship counting mechanism, a tactical device.");
	public static final AmmunitionTypeMineMaritimeFiringCode INFLUENCE = new AmmunitionTypeMineMaritimeFiringCode(
			"Influence",
			"INFLUN",
			"A (maritime) mine firing mechanism actuated by the effect of a target on some physical condition in the vicinity of the mine or on radiations emanating from the mine.");
	public static final AmmunitionTypeMineMaritimeFiringCode MAGNETIC = new AmmunitionTypeMineMaritimeFiringCode(
			"Magnetic",
			"MAGNET",
			"A (maritime) mine firing mechanism with a magnetic influence circuit that responds to the magnetic field of a ship.");
	public static final AmmunitionTypeMineMaritimeFiringCode MAGNETIC_H_HORIZONTAL_COMPONENT = new AmmunitionTypeMineMaritimeFiringCode(
			"Magnetic H, horizontal component",
			"MAGNHH",
			"A (maritime) mine firing mechanism with a magnetic influence circuit that responds to the horizontal component of the magnetic field of a ship.");
	public static final AmmunitionTypeMineMaritimeFiringCode MAGNETIC_T_TOTAL_COMPONENT = new AmmunitionTypeMineMaritimeFiringCode(
			"Magnetic T, total component",
			"MAGNTT",
			"A (maritime) mine with a magnetic influence circuit that responds to the total component of the magnetic field of a ship.");
	public static final AmmunitionTypeMineMaritimeFiringCode MAGNETIC_V_VERTICAL_COMPONENT = new AmmunitionTypeMineMaritimeFiringCode(
			"Magnetic V, vertical component",
			"MAGNVV",
			"A (maritime) mine firing mechanism with a magnetic influence circuit which responds to the vertical component of the magnetic field of a ship.");
	public static final AmmunitionTypeMineMaritimeFiringCode MINEHUNTING_SONAR_DECOY = new AmmunitionTypeMineMaritimeFiringCode(
			"Minehunting sonar decoy",
			"MINHSD",
			"A small object with a large sonar signal, or inert minelike objects, Non-mine Bottom Objects (NOMBOs).");
	public static final AmmunitionTypeMineMaritimeFiringCode MULTI_LOOK_MINES = new AmmunitionTypeMineMaritimeFiringCode(
			"Multi-look mines",
			"MULTLM",
			"A type of maritime mine actuation.");
	public static final AmmunitionTypeMineMaritimeFiringCode NOT_KNOWN = new AmmunitionTypeMineMaritimeFiringCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AmmunitionTypeMineMaritimeFiringCode NOT_OTHERWISE_SPECIFIED = new AmmunitionTypeMineMaritimeFiringCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AmmunitionTypeMineMaritimeFiringCode PASSIVE = new AmmunitionTypeMineMaritimeFiringCode(
			"Passive",
			"PASIVE",
			"A (maritime) mine firing mechanism that does not emit a signal to detect the presence of a target.");
	public static final AmmunitionTypeMineMaritimeFiringCode PRESSURE = new AmmunitionTypeMineMaritimeFiringCode(
			"Pressure",
			"PRESUR",
			"A (maritime) mine firing mechanism with a pressure sensitive circuit which responds to the pressure variation as a result of a ship or sweep.");
	public static final AmmunitionTypeMineMaritimeFiringCode SENSITIVE_FOR_NORMAL_TARGET = new AmmunitionTypeMineMaritimeFiringCode(
			"Sensitive for normal target",
			"SENFNT",
			"A (maritime) mine firing mechanism that may actuated by a small change in its influence field.");
	public static final AmmunitionTypeMineMaritimeFiringCode SEQUENCE = new AmmunitionTypeMineMaritimeFiringCode(
			"Sequence",
			"SEQUEN",
			"A (maritime) mine firing mechanism that has a firing circuit which requires actuation by a predetermined sequence of influences of predetermined magnitude.");
	public static final AmmunitionTypeMineMaritimeFiringCode VERY_SENSITIVE_ANTI_SWEEPER = new AmmunitionTypeMineMaritimeFiringCode(
			"Very sensitive, anti sweeper",
			"VERSEN",
			"A (maritime) mine firing mechanism that is fitted with a sensitive firing mechanism that react to a small influences of pressure, acoustic or magnetic (for magnetic values of less than 200 nanotesla are sufficient.)");

	private AmmunitionTypeMineMaritimeFiringCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
