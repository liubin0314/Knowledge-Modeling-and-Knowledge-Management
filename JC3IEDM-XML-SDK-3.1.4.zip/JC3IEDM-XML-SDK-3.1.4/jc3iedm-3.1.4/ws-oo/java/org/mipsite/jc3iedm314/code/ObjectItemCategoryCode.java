/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OBJECT-ITEM.";
	}

	private static HashMap<String, ObjectItemCategoryCode> physicalToCode = new HashMap<String, ObjectItemCategoryCode>();

	public static ObjectItemCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemCategoryCode FACILITY = new ObjectItemCategoryCode(
			"FACILITY",
			"FA",
			"An OBJECT-ITEM that is built, installed or established to serve some particular purpose and is identified by the service it provides rather than by its content.");
	public static final ObjectItemCategoryCode FEATURE = new ObjectItemCategoryCode(
			"FEATURE",
			"FE",
			"An OBJECT-ITEM that encompasses meteorological, geographic, and control features of military significance.");
	public static final ObjectItemCategoryCode MATERIEL = new ObjectItemCategoryCode(
			"MATERIEL",
			"MA",
			"An OBJECT-ITEM that is equipment, apparatus or supplies of military interest without distinction as to its application for administrative or combat purposes.");
	public static final ObjectItemCategoryCode NOT_KNOWN = new ObjectItemCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ObjectItemCategoryCode ORGANISATION = new ObjectItemCategoryCode(
			"ORGANISATION",
			"OR",
			"An OBJECT-ITEM that is an administrative or functional structure.");
	public static final ObjectItemCategoryCode PERSON = new ObjectItemCategoryCode(
			"PERSON",
			"PE",
			"An OBJECT-ITEM that is a human being to whom military or civilian significance is attached.");

	private ObjectItemCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
