/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeEstablishmentCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OBJECT-TYPE-ESTABLISHMENT when the established and detail OBJECT-TYPEs are instances of MATERIEL-TYPE.";
	}

	private static HashMap<String, ObjectTypeEstablishmentCategoryCode> physicalToCode = new HashMap<String, ObjectTypeEstablishmentCategoryCode>();

	public static ObjectTypeEstablishmentCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeEstablishmentCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeEstablishmentCategoryCode COMPLETE_EQUIPMENT_SCHEDULE = new ObjectTypeEstablishmentCategoryCode(
			"Complete equipment schedule",
			"CES",
			"A list of the associated ancillaries, accessories, tools, literature and spares which, when scheduled together, form a composite vehicle, equipment or store.");
	public static final ObjectTypeEstablishmentCategoryCode PARTS_CATALOGUE = new ObjectTypeEstablishmentCategoryCode(
			"Parts catalogue",
			"PCG",
			"A list showing the disassembly build order of an equipment, identifying the assemblies, sub-assemblies and components which comprise the equipment (or assemblies and sub-assemblies).");

	private ObjectTypeEstablishmentCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
