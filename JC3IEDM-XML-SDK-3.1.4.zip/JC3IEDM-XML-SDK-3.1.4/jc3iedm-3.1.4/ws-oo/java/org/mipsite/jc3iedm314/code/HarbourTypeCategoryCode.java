/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of HARBOUR-TYPE.";
	}

	private static HashMap<String, HarbourTypeCategoryCode> physicalToCode = new HashMap<String, HarbourTypeCategoryCode>();

	public static HarbourTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourTypeCategoryCode CANAL_OR_LAKE = new HarbourTypeCategoryCode(
			"Canal or lake",
			"CANAL",
			"A harbour located in the interior portion of a canal or lake that is connected with the sea by a navigable waterway.");
	public static final HarbourTypeCategoryCode COASTAL_BREAKWATER = new HarbourTypeCategoryCode(
			"Coastal (Breakwater)",
			"COASTB",
			"A coastal harbour lying behind a man-made breakwater constructed to provide shelter, or supplement inadequate shelter already provided by natural sources.");
	public static final HarbourTypeCategoryCode COASTAL_NATURAL = new HarbourTypeCategoryCode(
			"Coastal (Natural)",
			"COASTN",
			"A coastal harbour sheltered from the wind and sea by virtue of its location within a natural coastal indentation or in the protective lee of an island, cape, reef or other natural barrier.");
	public static final HarbourTypeCategoryCode COASTAL_TIDE_GATES = new HarbourTypeCategoryCode(
			"Coastal (Tide Gates)",
			"COASTT",
			"A coastal harbour, the waters of which are constrained by locks or other mechanical devices in order to provide sufficient water to float vessels at all stages of the tide.");
	public static final HarbourTypeCategoryCode INLAND_WATER_WAY = new HarbourTypeCategoryCode(
			"Inland water way",
			"INLAND",
			"A harbour located in the interior portion of a river, canal or lake that is not connected with the sea by a navigable waterway.");
	public static final HarbourTypeCategoryCode OPEN_ROADSTEAD = new HarbourTypeCategoryCode(
			"Open roadstead",
			"OPENRD",
			"A port, which has no artificial barrier to provide shelter from the wind, sea and swell.");
	public static final HarbourTypeCategoryCode RIVER_BASINS = new HarbourTypeCategoryCode(
			"River (Basins)",
			"RIVERB",
			"A river harbour in which slips for vessels have been excavated in the banks, obliquely or at right angles to the axis of the stream.");
	public static final HarbourTypeCategoryCode RIVER_NATURAL = new HarbourTypeCategoryCode(
			"River (Natural)",
			"RIVERN",
			"A harbour located on a river, the waters of which are not retained by any artificial means. The facilities may consist of quays or wharves parallel to the banks of the stream, or piers or jetties, which extend into the stream.");
	public static final HarbourTypeCategoryCode RIVER_TIDE_GATES = new HarbourTypeCategoryCode(
			"River (Tide Gates)",
			"RIVERT",
			"A river harbour, the waters of which are constrained by locks or other mechanical devices in order to provide sufficient water to float vessels at all stages of the tide.");

	private HarbourTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
