/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetListAuthorisationIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether a specific CANDIDATE-TARGET-LIST is authorised further consideration in planning military operations.";
	}

	private static HashMap<String, CandidateTargetListAuthorisationIndicatorCode> physicalToCode = new HashMap<String, CandidateTargetListAuthorisationIndicatorCode>();

	public static CandidateTargetListAuthorisationIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetListAuthorisationIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetListAuthorisationIndicatorCode NO = new CandidateTargetListAuthorisationIndicatorCode(
			"No",
			"NO",
			"The specific CANDIDATE-TARGET-LIST is not authorised further consideration in planning military operations.");
	public static final CandidateTargetListAuthorisationIndicatorCode YES = new CandidateTargetListAuthorisationIndicatorCode(
			"Yes",
			"YES",
			"The subject CANDIDATE-TARGET-LIST is authorised further consideration in planning military operations.");

	private CandidateTargetListAuthorisationIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
