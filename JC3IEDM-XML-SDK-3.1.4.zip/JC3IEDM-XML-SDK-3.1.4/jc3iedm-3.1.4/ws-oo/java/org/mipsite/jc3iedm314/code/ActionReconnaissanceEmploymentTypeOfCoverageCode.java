/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionReconnaissanceEmploymentTypeOfCoverageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of coverage required.";
	}

	private static HashMap<String, ActionReconnaissanceEmploymentTypeOfCoverageCode> physicalToCode = new HashMap<String, ActionReconnaissanceEmploymentTypeOfCoverageCode>();

	public static ActionReconnaissanceEmploymentTypeOfCoverageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionReconnaissanceEmploymentTypeOfCoverageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AFLOAT = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Afloat",
			"AFLOA",
			"Reconnaissance of vessels afloat.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AFLOAT_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Afloat, oblique",
			"AFLOAO",
			"Reconnaissance of vessels afloat, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AFLOAT_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Afloat, vertical",
			"AFLOAV",
			"Reconnaissance of vessels afloat, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_COVER = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area cover",
			"AREAC",
			"Photographic coverage of a specific area.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_COVER_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area cover, oblique",
			"AREACO",
			"Photographic coverage of a specific area, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_COVER_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area cover, vertical",
			"AREACV",
			"Photographic coverage of a specific area, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_SEARCH = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area search",
			"AREAS",
			"Visual search of a specified area and photographing targets of military significance.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_SEARCH_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area search, oblique",
			"AREASO",
			"Visual search of a specified area and photographing targets of military significance, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode AREA_SEARCH_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Area search, vertical",
			"AREASV",
			"Visual search of a specified area and photographing targets of military significance, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode BEST_POSSIBLE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Best possible",
			"BP",
			"Use this data item when a specific type of coverage need not be specified.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode BEST_POSSIBLE_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Best possible, oblique",
			"BPO",
			"Use this data item when a specific type of coverage need not be specified, except for an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode BEST_POSSIBLE_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Best possible, vertical",
			"BPV",
			"Use this data item when a specific type of coverage need not be specified, except for vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode LINE_SEARCH = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Line search",
			"LINESE",
			"Reconnaissance along a specific line of communications, such as a road, railway or waterway, to detect fleeting targets and activities in general.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode PINPOINT = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Pinpoint",
			"PINPT",
			"Reconnaissance of a precisely identified point that locates a very small target.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode PINPOINT_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Pinpoint, oblique",
			"PINPTO",
			"Reconnaissance of a precisely identified point that locates a very small target, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode PINPOINT_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Pinpoint, vertical",
			"PINPTV",
			"Reconnaissance of a precisely identified point that locates a very small target, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode ROUTE_RECONNAISSANCE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Route reconnaissance",
			"ROUTE",
			"Visual reconnaissance of a route or lines of communication with photos of targets of military significance.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode ROUTE_RECONNAISSANCE_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Route reconnaissance, oblique",
			"ROUTEO",
			"Visual reconnaissance of a route or lines of communication with photos of targets of military significance, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode ROUTE_RECONNAISSANCE_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Route reconnaissance, vertical",
			"ROUTEV",
			"Visual reconnaissance of a route or lines of communication with photos of targets of military significance, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode SPECIFIC_SEARCH = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Specific search",
			"SPECS",
			"Reconnaissance of a limited number of points for specific information.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode SPECIFIC_SEARCH_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Specific search, oblique",
			"SPECSO",
			"Reconnaissance of a limited number of points for specific information, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode SPECIFIC_SEARCH_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Specific search, vertical",
			"SPECSV",
			"Reconnaissance of a limited number of points for specific information, at vertical angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode STRIP = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Strip",
			"STRIP",
			"Continuous photography of a strip of the earth's surface.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode STRIP_OBLIQUE = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Strip, oblique",
			"STRIPO",
			"Continuous photography of a strip of the earth's surface, at an oblique angle.");
	public static final ActionReconnaissanceEmploymentTypeOfCoverageCode STRIP_VERTICAL = new ActionReconnaissanceEmploymentTypeOfCoverageCode(
			"Strip, vertical",
			"STRIPV",
			"Continuous photography of a strip of the earth's surface, at vertical angle.");

	private ActionReconnaissanceEmploymentTypeOfCoverageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
