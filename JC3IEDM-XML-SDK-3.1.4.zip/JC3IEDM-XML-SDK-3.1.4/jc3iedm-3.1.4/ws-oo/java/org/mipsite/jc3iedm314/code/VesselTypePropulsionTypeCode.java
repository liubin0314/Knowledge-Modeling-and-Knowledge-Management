/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VesselTypePropulsionTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of power used to move the vessel.";
	}

	private static HashMap<String, VesselTypePropulsionTypeCode> physicalToCode = new HashMap<String, VesselTypePropulsionTypeCode>();

	public static VesselTypePropulsionTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VesselTypePropulsionTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VesselTypePropulsionTypeCode AIR_INDEPENDENT_PROPULSION = new VesselTypePropulsionTypeCode(
			"Air independent propulsion",
			"AIP",
			"The VESSEL-TYPE is powered by air independent propulsion.");
	public static final VesselTypePropulsionTypeCode COMBINED_DIESEL_AND_GAS_TURBINE = new VesselTypePropulsionTypeCode(
			"Combined diesel and gas turbine",
			"CODAG",
			"The VESSEL-TYPE is powered by combined diesel and gas turbine.");
	public static final VesselTypePropulsionTypeCode COMBINED_DIESEL_OR_GAS_TURBINE = new VesselTypePropulsionTypeCode(
			"Combined diesel or gas turbine",
			"CODOG",
			"The VESSEL-TYPE is powered by combined diesel or gas turbine.");
	public static final VesselTypePropulsionTypeCode COMBINED_GAS_OR_GAS_TURBINE = new VesselTypePropulsionTypeCode(
			"Combined gas or gas turbine",
			"COGOG",
			"The VESSEL-TYPE is powered by combined gas or gas turbine.");
	public static final VesselTypePropulsionTypeCode COMBINED_NUCLEAR_AND_STEAM = new VesselTypePropulsionTypeCode(
			"Combined nuclear and steam",
			"CONAS",
			"The VESSEL-TYPE is powered by combined nuclear and steam.");
	public static final VesselTypePropulsionTypeCode COMBINED_STEAM_AND_GAS_TURBINE = new VesselTypePropulsionTypeCode(
			"Combined steam and gas turbine",
			"COSAG",
			"The VESSEL-TYPE is powered by combined steam and gas turbine.");
	public static final VesselTypePropulsionTypeCode DIESEL_ELECTRIC = new VesselTypePropulsionTypeCode(
			"Diesel electric",
			"DE",
			"The VESSEL-TYPE is powered by diesel electric.");
	public static final VesselTypePropulsionTypeCode DIESEL_ENGINE = new VesselTypePropulsionTypeCode(
			"Diesel engine",
			"DG",
			"The VESSEL-TYPE is powered by diesel engine.");
	public static final VesselTypePropulsionTypeCode DIESEL_GENERATOR = new VesselTypePropulsionTypeCode(
			"Diesel generator",
			"DM",
			"The VESSEL-TYPE is powered by diesel generator.");
	public static final VesselTypePropulsionTypeCode DIESEL_ENGINE_WATER_JET = new VesselTypePropulsionTypeCode(
			"Diesel engine/water jet",
			"DMWJ",
			"The VESSEL-TYPE is powered by diesel engine/water jet.");
	public static final VesselTypePropulsionTypeCode ELECTRIC_MOTOR = new VesselTypePropulsionTypeCode(
			"Electric motor",
			"EM",
			"The VESSEL-TYPE is powered by electric motor.");
	public static final VesselTypePropulsionTypeCode GASOLINE_ENGINE = new VesselTypePropulsionTypeCode(
			"Gasoline engine",
			"GTU",
			"The VESSEL-TYPE is powered by gasoline engine.");
	public static final VesselTypePropulsionTypeCode GAS_TURBINE = new VesselTypePropulsionTypeCode(
			"Gas turbine",
			"NUC",
			"The VESSEL-TYPE is powered by gas turbine.");
	public static final VesselTypePropulsionTypeCode NUCLEAR = new VesselTypePropulsionTypeCode(
			"Nuclear",
			"NUCE",
			"The VESSEL-TYPE is powered by nuclear.");
	public static final VesselTypePropulsionTypeCode NUCLEAR_TURBO_ELECTRIC = new VesselTypePropulsionTypeCode(
			"Nuclear turbo-electric",
			"OARS",
			"The VESSEL-TYPE is powered by nuclear turbo-electric.");
	public static final VesselTypePropulsionTypeCode OARS = new VesselTypePropulsionTypeCode(
			"Oars",
			"PJ",
			"The VESSEL-TYPE is powered by oars.");
	public static final VesselTypePropulsionTypeCode PUMP_JET = new VesselTypePropulsionTypeCode(
			"Pump jet",
			"PM",
			"The VESSEL-TYPE is powered by pump jet.");
	public static final VesselTypePropulsionTypeCode SAIL = new VesselTypePropulsionTypeCode(
			"Sail",
			"SAIL",
			"The VESSEL-TYPE is powered by Sail.");
	public static final VesselTypePropulsionTypeCode TURBO_ELECTRIC = new VesselTypePropulsionTypeCode(
			"Turbo-electric",
			"TE",
			"The VESSEL-TYPE is powered by turbo-electric.");
	public static final VesselTypePropulsionTypeCode TURBINE = new VesselTypePropulsionTypeCode(
			"Turbine",
			"TU",
			"The VESSEL-TYPE is powered by turbine.");
	public static final VesselTypePropulsionTypeCode WATER_JET = new VesselTypePropulsionTypeCode(
			"Water jet",
			"WJ",
			"The VESSEL-TYPE is powered by water jet.");

	private VesselTypePropulsionTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
