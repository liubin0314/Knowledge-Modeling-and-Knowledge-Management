/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of GEOGRAPHIC-FEATURE-TYPE.";
	}

	private static HashMap<String, GeographicFeatureTypeCategoryCode> physicalToCode = new HashMap<String, GeographicFeatureTypeCategoryCode>();

	public static GeographicFeatureTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureTypeCategoryCode CONTINENT = new GeographicFeatureTypeCategoryCode(
			"Continent",
			"CONTNT",
			"Any of the world's main continuous expanses of land.");
	public static final GeographicFeatureTypeCategoryCode COASTAL_HYDROGRAPHY = new GeographicFeatureTypeCategoryCode(
			"Coastal hydrography",
			"CSTLHY",
			"Natural features representing different aspects of interchange between water and land.");
	public static final GeographicFeatureTypeCategoryCode INLAND_WATER = new GeographicFeatureTypeCategoryCode(
			"Inland water",
			"INLNDW",
			"A sea, lake, river, etc situated in the interior of a land mass.");
	public static final GeographicFeatureTypeCategoryCode LANDFORM = new GeographicFeatureTypeCategoryCode(
			"Landform",
			"LNDFRM",
			"Natural features of the earth's surface.");
	public static final GeographicFeatureTypeCategoryCode NOT_KNOWN = new GeographicFeatureTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final GeographicFeatureTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new GeographicFeatureTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final GeographicFeatureTypeCategoryCode SNOW_ICE = new GeographicFeatureTypeCategoryCode(
			"Snow/ice",
			"SNOWIC",
			"Natural features that are characterised by frozen water.");
	public static final GeographicFeatureTypeCategoryCode WETLAND = new GeographicFeatureTypeCategoryCode(
			"Wetland",
			"WETLND",
			"A saturated area, at times covered with water.");

	private GeographicFeatureTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
