/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeIssuingUnitOfMeasureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the unit of measure of which a standard quantity (unit) of a specific CONSUMABLE-MATERIEL-TYPE is made available.";
	}

	private static HashMap<String, ConsumableMaterielTypeIssuingUnitOfMeasureCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeIssuingUnitOfMeasureCode>();

	public static ConsumableMaterielTypeIssuingUnitOfMeasureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeIssuingUnitOfMeasureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode CUBIC_METRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Cubic metre",
			"CM",
			"The standard international unit of volume in the metric system.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode CENTIMETRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Centimetre",
			"CNTMTR",
			"1/100th of a metre.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode DOZEN = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Dozen",
			"DOZEN",
			"A set of twelve.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode EACH = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Each",
			"EA",
			"Singly.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode GRAM = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Gram",
			"GRAM",
			"1/1,000th of a kilogram.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode GROSS = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Gross",
			"GROSS",
			"A group of 144.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode KILOTON = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Kiloton",
			"KILTON",
			"A unit of explosive power, equal to that of one thousand tons of TNT.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode KILOMETRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Kilometre",
			"KM",
			"1,000 metres.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode LITRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Litre",
			"LI",
			"1/1,000th of a cubic metre.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode LONG_TON = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Long ton",
			"LONGTN",
			"A measure of weight, legally 1016.05 kilograms normally referenced to the displacement of a vessel.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode METRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Metre",
			"METRE",
			"The standard international unit of linear measure in the metric system.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode MILLIGRAM = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Milligram",
			"MILGRM",
			"1/1,000,000th of a kilogram (1/1,000th of a gram).");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode MILLILITRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Millilitre",
			"MILLTR",
			"1/1,000,000th of a cubic metre (1/1,000th of a litre).");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode MILLIMETRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Millimetre",
			"MILMTR",
			"1/1,000th of a metre.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode METRIC_TON = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Metric ton",
			"MTRCTN",
			"1,000 kilograms.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode SHORT_TON = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Short ton",
			"SHRTTN",
			"A measure of weight, legally 907.19 kilograms.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode SQUARE_METRE = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Square metre",
			"SQM",
			"The standard international unit of area in the metric system.");
	public static final ConsumableMaterielTypeIssuingUnitOfMeasureCode KILOGRAM = new ConsumableMaterielTypeIssuingUnitOfMeasureCode(
			"Kilogram",
			"KG",
			"The standard international unit of mass in the metric system.");

	private ConsumableMaterielTypeIssuingUnitOfMeasureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
