/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusTrainingCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the assessed training status of a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusTrainingCode> physicalToCode = new HashMap<String, OrganisationStatusTrainingCode>();

	public static OrganisationStatusTrainingCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusTrainingCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusTrainingCode AMBER = new OrganisationStatusTrainingCode(
			"Amber",
			"AMBER",
			"A status indicating that the training level of an ORGANISATION is between 60% and 80%.");
	public static final OrganisationStatusTrainingCode GREEN = new OrganisationStatusTrainingCode(
			"Green",
			"GREEN",
			"A status indicating that the training level of an ORGANISATION is greater than 80%.");
	public static final OrganisationStatusTrainingCode NOT_KNOWN = new OrganisationStatusTrainingCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusTrainingCode RED = new OrganisationStatusTrainingCode(
			"Red",
			"RED",
			"A status indicating that the training level of an ORGANISATION is less than 60%.");

	private OrganisationStatusTrainingCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
