/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RequestImmediateInterestIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether the information sought in a request is of immediate interest.";
	}

	private static HashMap<String, RequestImmediateInterestIndicatorCode> physicalToCode = new HashMap<String, RequestImmediateInterestIndicatorCode>();

	public static RequestImmediateInterestIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RequestImmediateInterestIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RequestImmediateInterestIndicatorCode NO = new RequestImmediateInterestIndicatorCode(
			"No",
			"NO",
			"The request has no immediate interest, i.e. it can be reported at the normal delivery time.");
	public static final RequestImmediateInterestIndicatorCode YES = new RequestImmediateInterestIndicatorCode(
			"Yes",
			"YES",
			"The request has an immediate interest, i.e. it must be immediately reported.");

	private RequestImmediateInterestIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
