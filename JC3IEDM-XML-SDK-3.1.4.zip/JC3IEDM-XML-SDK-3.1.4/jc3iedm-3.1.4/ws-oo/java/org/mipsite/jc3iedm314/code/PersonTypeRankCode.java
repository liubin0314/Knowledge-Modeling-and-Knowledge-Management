/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonTypeRankCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a designation for a military, naval, or civil grade that establishes the relative position or status of a specific PERSON-TYPE in an organisation.";
	}

	private static HashMap<String, PersonTypeRankCode> physicalToCode = new HashMap<String, PersonTypeRankCode>();

	public static PersonTypeRankCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonTypeRankCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonTypeRankCode ENLISTED_PRIVATE = new PersonTypeRankCode(
			"Enlisted private",
			"EPTE",
			"A military person in the armed forces without an officer's commission, warrant or other rank conferring leadership over other servicemen.");
	public static final PersonTypeRankCode NCO_NOT_OTHERWISE_SPECIFIED = new PersonTypeRankCode(
			"NCO, not otherwise specified",
			"NCO",
			"An enlisted member of the armed forces appointed to a rank conferring leadership over other servicemen.");
	public static final PersonTypeRankCode NOT_KNOWN = new PersonTypeRankCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonTypeRankCode OF_1 = new PersonTypeRankCode(
			"OF-1",
			"OF1",
			"Officer rank of Lieutenant/Second Lieutenant/Midshipman/Sub-Lieutenant/Pilot Officer/Flying Officer.");
	public static final PersonTypeRankCode OF_10 = new PersonTypeRankCode(
			"OF-10",
			"OF10",
			"Officer rank of Field Marshal/Fleet Admiral/General of the Air Force.");
	public static final PersonTypeRankCode OF_2 = new PersonTypeRankCode(
			"OF-2",
			"OF2",
			"Officer rank of Captain/Lieutenant/Flight Lieutenant.");
	public static final PersonTypeRankCode OF_3 = new PersonTypeRankCode(
			"OF-3",
			"OF3",
			"Officer rank of Major/Lieutenant-Commander/Squadron Leader.");
	public static final PersonTypeRankCode OF_4 = new PersonTypeRankCode(
			"OF-4",
			"OF4",
			"Officer rank of Lieutenant Colonel/Commander/Wing Commander.");
	public static final PersonTypeRankCode OF_5 = new PersonTypeRankCode(
			"OF-5",
			"OF5",
			"Officer rank of Colonel/Captain (under 6 years seniority) /Group Captain.");
	public static final PersonTypeRankCode OF_6 = new PersonTypeRankCode(
			"OF-6",
			"OF6",
			"Officer rank of Brigadier/Captain (over 6 years seniority)/Air Commodore.");
	public static final PersonTypeRankCode OF_7 = new PersonTypeRankCode(
			"OF-7",
			"OF7",
			"Officer rank of Major General/Rear Admiral/Air Vice Marshal.");
	public static final PersonTypeRankCode OF_8 = new PersonTypeRankCode(
			"OF-8",
			"OF8",
			"Officer rank of Lieutenant General/Vice Admiral/Air Marshal.");
	public static final PersonTypeRankCode OF_9 = new PersonTypeRankCode(
			"OF-9",
			"OF9",
			"Officer rank of General/Admiral/Air Chief Marshal.");
	public static final PersonTypeRankCode OFFICER_NOT_OTHERWISE_SPECIFIED = new PersonTypeRankCode(
			"Officer, not otherwise specified",
			"OFFR",
			"A military person who is invested with authority by means of a commission in the armed forces.");
	public static final PersonTypeRankCode OR_1 = new PersonTypeRankCode(
			"OR-1",
			"OR1",
			"Other rank of Private (Class 4)/Seaman Recruit/Basic Airman.");
	public static final PersonTypeRankCode OR_2 = new PersonTypeRankCode(
			"OR-2",
			"OR2",
			"Other rank of Private (Class1-3)/Seaman Apprentice/Airman.");
	public static final PersonTypeRankCode OR_3 = new PersonTypeRankCode(
			"OR-3",
			"OR3",
			"Other rank of Lance Corporal/Seaman/Airman First Class.");
	public static final PersonTypeRankCode OR_4 = new PersonTypeRankCode(
			"OR-4",
			"OR4",
			"Other rank of Corporal/Petty Officer Third Class/Senior Airman/Sergeant.");
	public static final PersonTypeRankCode OR_5 = new PersonTypeRankCode(
			"OR-5",
			"OR5",
			"Other rank of Sergeant (Junior)/Petty Officer Second Class/Staff Sergeant.");
	public static final PersonTypeRankCode OR_6 = new PersonTypeRankCode(
			"OR-6",
			"OR6",
			"Other rank of Sergeant (3 Years Seniority)/Petty Officer First Class/Technical Sergeant.");
	public static final PersonTypeRankCode OR_7 = new PersonTypeRankCode(
			"OR-7",
			"OR7",
			"Other rank of Staff Sergeant/Chief Petty Officer First Class/Master Sergeant.");
	public static final PersonTypeRankCode OR_8 = new PersonTypeRankCode(
			"OR-8",
			"OR8",
			"Other rank of Warrant Officer Class 2/Senior Chief Petty Officer/Senior Master Sergeant.");
	public static final PersonTypeRankCode OR_9 = new PersonTypeRankCode(
			"OR-9",
			"OR9",
			"Other rank of Warrant Officer Class 1/Master Chief Petty Officer/Chief Master Sergeant.");
	public static final PersonTypeRankCode OTHER_RANKS = new PersonTypeRankCode(
			"Other ranks",
			"OTHR",
			"All military PERSON-TYPEs who do not hold an officer's commission in the armed forces.");

	private PersonTypeRankCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
