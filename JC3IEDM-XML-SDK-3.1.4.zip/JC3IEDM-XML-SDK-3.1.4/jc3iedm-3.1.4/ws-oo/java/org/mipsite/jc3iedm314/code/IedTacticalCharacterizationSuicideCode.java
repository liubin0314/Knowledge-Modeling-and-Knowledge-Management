/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IedTacticalCharacterizationSuicideCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether an IED was initiated by an operator at a time of his/her choosing in which the operator intentionally kills himself/herself as part of the attack.";
	}

	private static HashMap<String, IedTacticalCharacterizationSuicideCode> physicalToCode = new HashMap<String, IedTacticalCharacterizationSuicideCode>();

	public static IedTacticalCharacterizationSuicideCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IedTacticalCharacterizationSuicideCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IedTacticalCharacterizationSuicideCode NO = new IedTacticalCharacterizationSuicideCode(
			"No",
			"NO",
			"The specific value that indicates the operator does not intentionally kill himself/herself as part of the attack.");
	public static final IedTacticalCharacterizationSuicideCode YES = new IedTacticalCharacterizationSuicideCode(
			"Yes",
			"YES",
			"An IED initiated by an insurgent/terrorist at a time of his/her choosing in which the operator intentionally kills himself/herself as part of the attack or to deny his/her capture.");
	public static final IedTacticalCharacterizationSuicideCode NOT_KNOWN = new IedTacticalCharacterizationSuicideCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private IedTacticalCharacterizationSuicideCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
