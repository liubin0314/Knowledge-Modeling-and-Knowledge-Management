/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailwaySignalSystemCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of signal system used for the RAILWAY.";
	}

	private static HashMap<String, RailwaySignalSystemCode> physicalToCode = new HashMap<String, RailwaySignalSystemCode>();

	public static RailwaySignalSystemCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailwaySignalSystemCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailwaySignalSystemCode COLOUR_LIGHT = new RailwaySignalSystemCode(
			"Colour light",
			"CL",
			"The specific value that represents a signal, which gives indication by the colour of the light only.");
	public static final RailwaySignalSystemCode COLOUR_POSITION = new RailwaySignalSystemCode(
			"Colour position",
			"CP",
			"The specific value that represents a signal giving indications by the colour and position of two or more lights.");
	public static final RailwaySignalSystemCode ELECTRIC_LIGHT = new RailwaySignalSystemCode(
			"Electric light",
			"EL",
			"The specific value that represents an electric light system.");
	public static final RailwaySignalSystemCode NOT_KNOWN = new RailwaySignalSystemCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RailwaySignalSystemCode POSITION_LIGHT = new RailwaySignalSystemCode(
			"Position light",
			"PL",
			"The specific value that represents a signal to which indications are given by the position of two or more lights.");
	public static final RailwaySignalSystemCode SEMAPHORE = new RailwaySignalSystemCode(
			"Semaphore",
			"SF",
			"The specific value that represents a signal in which the day indicators are given by changing positions of a semaphore arm and the night indications are given by coloured lights.");
	public static final RailwaySignalSystemCode INCONCLUSIVE_ANALYSIS = new RailwaySignalSystemCode(
			"Inconclusive analysis",
			"Z",
			"The specific value that indicates that the analysis of the system is inconclusive.");

	private RailwaySignalSystemCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
