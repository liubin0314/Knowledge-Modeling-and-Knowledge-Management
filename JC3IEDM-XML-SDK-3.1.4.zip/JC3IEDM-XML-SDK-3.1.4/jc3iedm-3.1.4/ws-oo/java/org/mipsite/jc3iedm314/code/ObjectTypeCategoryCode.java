/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OBJECT-TYPE.";
	}

	private static HashMap<String, ObjectTypeCategoryCode> physicalToCode = new HashMap<String, ObjectTypeCategoryCode>();

	public static ObjectTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeCategoryCode FACILITY_TYPE = new ObjectTypeCategoryCode(
			"FACILITY-TYPE",
			"FA",
			"An OBJECT-TYPE that is intended to be built, installed or established to serve some particular purpose and is identified by the service it is intended to provided rather than by its content.");
	public static final ObjectTypeCategoryCode FEATURE_TYPE = new ObjectTypeCategoryCode(
			"FEATURE-TYPE",
			"FE",
			"An OBJECT-TYPE that encompasses meteorological, geographic, and control features of military significance.");
	public static final ObjectTypeCategoryCode MATERIEL_TYPE = new ObjectTypeCategoryCode(
			"MATERIEL-TYPE",
			"MA",
			"An OBJECT-TYPE that represents equipment, apparatus or supplies of military interest without distinction to its application for administrative or combat purposes.");
	public static final ObjectTypeCategoryCode NOT_KNOWN = new ObjectTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ObjectTypeCategoryCode ORGANISATION_TYPE = new ObjectTypeCategoryCode(
			"ORGANISATION-TYPE",
			"OR",
			"An OBJECT-TYPE that represents administrative or functional structures.");
	public static final ObjectTypeCategoryCode PERSON_TYPE = new ObjectTypeCategoryCode(
			"PERSON-TYPE",
			"PE",
			"An OBJECT-TYPE that represents human beings about whom information is to be held.");

	private ObjectTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
