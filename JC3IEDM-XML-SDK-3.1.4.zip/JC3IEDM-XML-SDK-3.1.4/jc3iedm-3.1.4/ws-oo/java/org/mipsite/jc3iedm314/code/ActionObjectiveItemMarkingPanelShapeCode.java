/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveItemMarkingPanelShapeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the shape of the marking panel.";
	}

	private static HashMap<String, ActionObjectiveItemMarkingPanelShapeCode> physicalToCode = new HashMap<String, ActionObjectiveItemMarkingPanelShapeCode>();

	public static ActionObjectiveItemMarkingPanelShapeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveItemMarkingPanelShapeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveItemMarkingPanelShapeCode H_SHAPE = new ActionObjectiveItemMarkingPanelShapeCode(
			"H shape",
			"HSHAPE",
			"The panel is in the shape of the letter H.");
	public static final ActionObjectiveItemMarkingPanelShapeCode I_SHAPE = new ActionObjectiveItemMarkingPanelShapeCode(
			"I shape",
			"ISHAPE",
			"The panel is in the shape of the letter I.");
	public static final ActionObjectiveItemMarkingPanelShapeCode NOT_KNOWN = new ActionObjectiveItemMarkingPanelShapeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionObjectiveItemMarkingPanelShapeCode NOT_OTHERWISE_SPECIFIED = new ActionObjectiveItemMarkingPanelShapeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionObjectiveItemMarkingPanelShapeCode T_SHAPE = new ActionObjectiveItemMarkingPanelShapeCode(
			"T shape",
			"TSHAPE",
			"The panel is in the shape of the letter T.");
	public static final ActionObjectiveItemMarkingPanelShapeCode X_SHAPE = new ActionObjectiveItemMarkingPanelShapeCode(
			"X shape",
			"XSHAPE",
			"The panel is in the shape of the letter X.");

	private ActionObjectiveItemMarkingPanelShapeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
