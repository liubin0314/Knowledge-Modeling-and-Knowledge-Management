/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UxoStatusExposureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the visual status of a specific Unexploded Explosive Ordnance.";
	}

	private static HashMap<String, UxoStatusExposureCode> physicalToCode = new HashMap<String, UxoStatusExposureCode>();

	public static UxoStatusExposureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UxoStatusExposureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UxoStatusExposureCode FULLY_EXPOSED = new UxoStatusExposureCode(
			"Fully exposed",
			"FULEXP",
			"A status indicating that a specific Unexploded Explosive Ordnance is fully exposed.");
	public static final UxoStatusExposureCode NOT_KNOWN = new UxoStatusExposureCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final UxoStatusExposureCode NOT_OTHERWISE_SPECIFIED = new UxoStatusExposureCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final UxoStatusExposureCode PARTIALLY_EXPOSED = new UxoStatusExposureCode(
			"Partially exposed",
			"PRTEX",
			"A status indicating that a specific Unexploded Explosive Ordnance is partially exposed.");
	public static final UxoStatusExposureCode PARTIALLY_EXPOSED_BODY = new UxoStatusExposureCode(
			"Partially exposed, body",
			"PRTEXB",
			"A status indicating that the body of a specific Unexploded Explosive Ordnance is partially exposed.");
	public static final UxoStatusExposureCode PARTIALLY_EXPOSED_NOSE = new UxoStatusExposureCode(
			"Partially exposed, nose",
			"PRTEXN",
			"A status indicating that the nose of a specific Unexploded Explosive Ordnance is partially exposed.");
	public static final UxoStatusExposureCode PARTIALLY_EXPOSED_SIDE = new UxoStatusExposureCode(
			"Partially exposed, side",
			"PRTEXS",
			"A status indicating that the side of a specific Unexploded Explosive Ordnance is partially exposed.");
	public static final UxoStatusExposureCode PARTIALLY_EXPOSED_TAIL = new UxoStatusExposureCode(
			"Partially exposed, tail",
			"PRTEXT",
			"A status indicating that the tail of a specific Unexploded Explosive Ordnance is partially exposed.");
	public static final UxoStatusExposureCode UNEXPOSED = new UxoStatusExposureCode(
			"Unexposed",
			"UNEXPD",
			"A status indicating that a specific Unexploded Explosive Ordnance is not exposed.");

	private UxoStatusExposureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
