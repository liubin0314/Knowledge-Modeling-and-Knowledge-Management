/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeArmSpecialisationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that qualifies the functional specialisation of a particular UNIT-TYPE.";
	}

	private static HashMap<String, UnitTypeArmSpecialisationCode> physicalToCode = new HashMap<String, UnitTypeArmSpecialisationCode>();

	public static UnitTypeArmSpecialisationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeArmSpecialisationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeArmSpecialisationCode AIR_DEFENCE_COMPOSITE_WEAPONS = new UnitTypeArmSpecialisationCode(
			"Air defence, composite weapons",
			"ADCOMP",
			"An air-defence UNIT-TYPE whose primary function is to combat aircraft by the means of both guns and missiles.");
	public static final UnitTypeArmSpecialisationCode AIR_DEFENCE_GUN = new UnitTypeArmSpecialisationCode(
			"Air defence, gun",
			"ADGUN",
			"An air-defence UNIT-TYPE whose primary function is to combat aircraft by the means of guns.");
	public static final UnitTypeArmSpecialisationCode AIR_DEFENCE_MISSILE = new UnitTypeArmSpecialisationCode(
			"Air defence, missile",
			"ADMSL",
			"An air-defence UNIT-TYPE whose primary function is to combat aircraft by the means of missiles.");
	public static final UnitTypeArmSpecialisationCode AERIAL_EXPLOITATION = new UnitTypeArmSpecialisationCode(
			"Aerial exploitation",
			"AIREXP",
			"A UNIT-TYPE whose primary function is to take full advantage of any information that was obtained from aerial sources.");
	public static final UnitTypeArmSpecialisationCode ANTISUBMARINE_WARFARE_AVIATION = new UnitTypeArmSpecialisationCode(
			"Antisubmarine warfare aviation",
			"ANTSUB",
			"A UNIT-TYPE whose primary function is to combat submarines by the means of air assets.");
	public static final UnitTypeArmSpecialisationCode APOD_APOE = new UnitTypeArmSpecialisationCode(
			"APOD/APOE",
			"APOD",
			"A UNIT-TYPE whose primary function is to provide transportation services at aerial ports where cargo or personnel arrive or depart.");
	public static final UnitTypeArmSpecialisationCode ARMOUR_RECOVERY = new UnitTypeArmSpecialisationCode(
			"Armour recovery",
			"ARMREC",
			"A UNIT-TYPE whose primary function is to recover armoured vehicles unable to move by their own means.");
	public static final UnitTypeArmSpecialisationCode ARTILLERY_SURVEY = new UnitTypeArmSpecialisationCode(
			"Artillery survey",
			"ARTSVY",
			"A UNIT-TYPE whose primary function is to calculate the coordinates and altitude of object/point and from which the bearings/azimuths to a number of reference objects are also known.");
	public static final UnitTypeArmSpecialisationCode ATTACK_AVIATION = new UnitTypeArmSpecialisationCode(
			"Attack aviation",
			"ATTACK",
			"An aviation UNIT-TYPE whose primary function is to perform an offensive mission.");
	public static final UnitTypeArmSpecialisationCode AVIATION_SECURITY_FORCES = new UnitTypeArmSpecialisationCode(
			"Aviation security forces",
			"AVASEC",
			"A UNIT-TYPE whose primary function is to maintain a state of law and order within air facilities or assets.");
	public static final UnitTypeArmSpecialisationCode BIOLOGICAL = new UnitTypeArmSpecialisationCode(
			"Biological",
			"BIOLOG",
			"A UNIT-TYPE whose primary function is to employ biological agents to produce casualties in man or animals and damage to plants or materiel; or defend against such employment.");
	public static final UnitTypeArmSpecialisationCode BIOLOGICAL_RECONNAISSANCE = new UnitTypeArmSpecialisationCode(
			"Biological reconnaissance",
			"BIOREC",
			"A UNIT-TYPE whose primary function is to obtain information about the presence, nature and concentration of biological agents in the environment.");
	public static final UnitTypeArmSpecialisationCode BRIDGING = new UnitTypeArmSpecialisationCode(
			"Bridging",
			"BRDGG",
			"An engineer UNIT-TYPE whose primary function is to build bridges or to provide means to cross dry cuts or water courses.");
	public static final UnitTypeArmSpecialisationCode BORDER_PATROL = new UnitTypeArmSpecialisationCode(
			"Border patrol",
			"BRDRPT",
			"A UNIT-TYPE whose primary function is to provide patrol along the borders.");
	public static final UnitTypeArmSpecialisationCode C2_AVIATION = new UnitTypeArmSpecialisationCode(
			"C2 aviation",
			"C2AVA",
			"A UNIT-TYPE whose primary function is to serve as a command and control element.");
	public static final UnitTypeArmSpecialisationCode CAVALRY = new UnitTypeArmSpecialisationCode(
			"Cavalry",
			"CAVLRY",
			"A UNIT-TYPE whose primary function is to fight in armoured vehicles.");
	public static final UnitTypeArmSpecialisationCode NBC_RECONNAISSANCE = new UnitTypeArmSpecialisationCode(
			"NBC reconnaissance",
			"CBRNRC",
			"A UNIT-TYPE whose primary function is to obtain information about the presence, nature and concentration of CBRN agents in the environment.");
	public static final UnitTypeArmSpecialisationCode CHEMICAL = new UnitTypeArmSpecialisationCode(
			"Chemical",
			"CHMCAL",
			"A UNIT-TYPE whose primary function is to employ chemical agents to kill, injure, or incapacitate for a significant period of time, man or animals, and deny or hinder the use of areas, facilities or materiel; or defend against such employment.");
	public static final UnitTypeArmSpecialisationCode CHEMICAL_RECONNAISSANCE = new UnitTypeArmSpecialisationCode(
			"Chemical, reconnaissance",
			"CHMREC",
			"A UNIT-TYPE whose primary function is to obtain information about the presence, nature and concentration of chemical agents in the environment.");
	public static final UnitTypeArmSpecialisationCode CHEMICAL_SMOKE_DECONTAMINATION = new UnitTypeArmSpecialisationCode(
			"Chemical, smoke/decontamination",
			"CHMSMD",
			"A UNIT-TYPE whose primary function is to make any person, object, or area safe by absorbing, destroying, neutralizing, making harmless, or removing, chemical agents.");
	public static final UnitTypeArmSpecialisationCode CHEMICAL_SMOKE = new UnitTypeArmSpecialisationCode(
			"Chemical, smoke",
			"CHMSMK",
			"A UNIT-TYPE whose primary function is to employ chemical agents released as a cloud of smoke or defend against such employment.");
	public static final UnitTypeArmSpecialisationCode CIVIL_AFFAIRS = new UnitTypeArmSpecialisationCode(
			"Civil affairs",
			"CIVAFR",
			"A UNIT-TYPE whose primary function is either to facilitate the relationships between the forces engaged on a theatre of operations and the civilian authorities of the countries in the theatre, the international organisations and the local populations, or to coordinate the actions led for the benefit of the concerned countries in order to preserve or restore the functioning of the institutions and public services as well as that of those services essential for the life of the populations of that country.");
	public static final UnitTypeArmSpecialisationCode CIVILIAN_LAW_ENFORCEMENT = new UnitTypeArmSpecialisationCode(
			"Civilian law enforcement",
			"CIVLWE",
			"A UNIT-TYPE whose primary function is to conduct civilian law enforcement operations.");
	public static final UnitTypeArmSpecialisationCode CENTRAL_INTELLIGENCE = new UnitTypeArmSpecialisationCode(
			"Central intelligence",
			"CNTINT",
			"No definition provided in APP-6A.");
	public static final UnitTypeArmSpecialisationCode COUNTER_INTELLIGENCE = new UnitTypeArmSpecialisationCode(
			"Counter intelligence",
			"CNTRIN",
			"A UNIT-TYPE whose primary function is to conduct activities that are concerned with identifying and counteracting the threat to security posed by hostile intelligence services or organisations, or by individuals engaged in espionage, sabotage, subversion or terrorism.");
	public static final UnitTypeArmSpecialisationCode COMBAT_SEARCH_AND_RESCUE_AVIATION = new UnitTypeArmSpecialisationCode(
			"Combat search and rescue aviation",
			"CSAR",
			"A UNIT-TYPE whose primary function is to search for and rescue personnel in distress on land or sea in enemy-controlled territory.");
	public static final UnitTypeArmSpecialisationCode DECONTAMINATION = new UnitTypeArmSpecialisationCode(
			"Decontamination",
			"DECONT",
			"A UNIT-TYPE whose primary function is to make any person, object, or area safe by absorbing, destroying, neutralizing, making harmless, or removing, chemical or biological agents, or by removing radioactive material clinging to or around it.");
	public static final UnitTypeArmSpecialisationCode DENTAL = new UnitTypeArmSpecialisationCode(
			"Dental",
			"DENTAL",
			"A UNIT-TYPE whose primary function is to provide dental care.");
	public static final UnitTypeArmSpecialisationCode DISMOUNTED_SECURITY_FORCES = new UnitTypeArmSpecialisationCode(
			"Dismounted security forces",
			"DISSEC",
			"A UNIT-TYPE whose primary function is to maintain a state of law and order and whose primary mode of operation is on foot.");
	public static final UnitTypeArmSpecialisationCode ENGINEER_CONSTRUCTION = new UnitTypeArmSpecialisationCode(
			"Engineer, construction",
			"ENCNST",
			"A UNIT-TYPE whose primary function is to build various facilities in direct support of military operations.");
	public static final UnitTypeArmSpecialisationCode ENGINEER_RECONNAISSANCE = new UnitTypeArmSpecialisationCode(
			"Engineer, reconnaissance",
			"ENGREC",
			"A UNIT-TYPE whose primary function is to obtain, by visual observation or other detection methods, information required for site surveys prior to construction or demolition.");
	public static final UnitTypeArmSpecialisationCode ENGINEER_ROAD_RAILWAYS = new UnitTypeArmSpecialisationCode(
			"Engineer, road/railways",
			"ENGRRW",
			"A UNIT-TYPE whose primary functions includes construction or demolition of roads and railways in support of military operations.");
	public static final UnitTypeArmSpecialisationCode ELECTRONIC_WARFARE = new UnitTypeArmSpecialisationCode(
			"Electronic warfare",
			"EW",
			"A UNIT-TYPE whose primary function is to use electromagnetic energy to determine, exploit, reduce, or prevent hostile use of the electromagnetic spectrum and to perform actions in order to retain its effective use by friendly forces.");
	public static final UnitTypeArmSpecialisationCode ELECTRONIC_WARFARE_DIRECTION_FINDING = new UnitTypeArmSpecialisationCode(
			"Electronic warfare, direction finding",
			"EWDF",
			"A UNIT-TYPE whose primary function is to obtain bearings of radio frequency emitters by using a directional antenna and a display unit on an intercept receiver or ancillary equipment.");
	public static final UnitTypeArmSpecialisationCode ELECTRONIC_WARFARE_INTERCEPT = new UnitTypeArmSpecialisationCode(
			"Electronic warfare, intercept",
			"EWINTC",
			"A UNIT-TYPE whose primary function is to intercept intentional or unintentional radiated electromagnetic energy for the purpose of immediate threat recognition.");
	public static final UnitTypeArmSpecialisationCode ELECTRONIC_WARFARE_JAMMING = new UnitTypeArmSpecialisationCode(
			"Electronic warfare, jamming",
			"EWJAM",
			"A UNIT-TYPE whose primary function is to deliver radiation, re-radiation or reflection of electromagnetic energy with the object of impairing the use of electronic devices, equipment or systems being used by an enemy.");
	public static final UnitTypeArmSpecialisationCode FIELD_ARTILLERY_HOWITZER_GUN = new UnitTypeArmSpecialisationCode(
			"Field artillery, howitzer/gun",
			"FAHOW",
			"A UNIT-TYPE whose principal designation is the employment of howitzers or artillery guns in support of manoeuvre units.");
	public static final UnitTypeArmSpecialisationCode FIELD_ARTILLERY_MULTI_ROCKET_LAUNCHER = new UnitTypeArmSpecialisationCode(
			"Field artillery, multi rocket launcher",
			"FAMLRS",
			"A UNIT-TYPE whose principal designation is the employment of multi rocket launchers in support of manoeuvre units.");
	public static final UnitTypeArmSpecialisationCode FIELD_ARTILLERY_MORTAR = new UnitTypeArmSpecialisationCode(
			"Field artillery, mortar",
			"FAMORT",
			"A UNIT-TYPE whose principal designation is the employment of mortars in support of manoeuvre units.");
	public static final UnitTypeArmSpecialisationCode FIELD_ARTILLERY_ROCKET_LAUNCHER = new UnitTypeArmSpecialisationCode(
			"Field artillery, rocket launcher",
			"FARCKL",
			"A UNIT-TYPE whose principal designation is the employment of rocket launchers in support of manoeuvre units.");
	public static final UnitTypeArmSpecialisationCode FIELD_ARTILLERY_SINGLE_ROCKET_LAUNCHER = new UnitTypeArmSpecialisationCode(
			"Field artillery, single rocket launcher",
			"FASLRS",
			"A UNIT-TYPE whose principal designation is the employment of single rocket launchers in support of manoeuvre units.");
	public static final UnitTypeArmSpecialisationCode FINANCE = new UnitTypeArmSpecialisationCode(
			"Finance",
			"FINANC",
			"A UNIT-TYPE whose primary function is to provide financial services.");
	public static final UnitTypeArmSpecialisationCode HANDLING_LOADING_UNLOADING = new UnitTypeArmSpecialisationCode(
			"Handling, loading/unloading",
			"HNDLDG",
			"A UNIT-TYPE whose primary function is to transfer materiel in or out of transportation means such as trains, ships or planes.");
	public static final UnitTypeArmSpecialisationCode INTERROGATION = new UnitTypeArmSpecialisationCode(
			"Interrogation",
			"INTERO",
			"A UNIT-TYPE whose primary function is to procure information by direct questioning of a person under the control of a questioner.");
	public static final UnitTypeArmSpecialisationCode JOINT_INTELLIGENCE = new UnitTypeArmSpecialisationCode(
			"Joint intelligence",
			"JNTINT",
			"A UNIT-TYPE whose primary function is to produce intelligence from elements of more than one Service.");
	public static final UnitTypeArmSpecialisationCode LABOUR = new UnitTypeArmSpecialisationCode(
			"Labour",
			"LABOUR",
			"A UNIT-TYPE whose primary function is to provide labour services.");
	public static final UnitTypeArmSpecialisationCode LEGAL_SERVICES = new UnitTypeArmSpecialisationCode(
			"Legal services",
			"LEGAL",
			"A UNIT-TYPE whose primary function is to provide legal services.");
	public static final UnitTypeArmSpecialisationCode MINE_COUNTERMEASURE_AVIATION = new UnitTypeArmSpecialisationCode(
			"Mine countermeasure aviation",
			"MCMAVA",
			"A UNIT-TYPE whose primary function is to prevent or reduce damage or danger from mines by using airborne means.");
	public static final UnitTypeArmSpecialisationCode MEDICAL_EVACUATION_AVIATION = new UnitTypeArmSpecialisationCode(
			"Medical evacuation aviation",
			"MEDEVC",
			"An aviation UNIT-TYPE whose primary function is to move patients by air means in a timely and efficient manner while providing en route medical care to and between medical treatment facilities.");
	public static final UnitTypeArmSpecialisationCode MEDICAL_TRANSPORT = new UnitTypeArmSpecialisationCode(
			"Medical transport",
			"MEDTRS",
			"A UNIT-TYPE whose primary function is to move patients between medical treatment facilities while providing en route medical care.");
	public static final UnitTypeArmSpecialisationCode MEDICAL_TREATMENT = new UnitTypeArmSpecialisationCode(
			"Medical treatment",
			"MEDTRT",
			"A UNIT-TYPE whose primary function is to perform interventions or treatment under supervision of a physician.");
	public static final UnitTypeArmSpecialisationCode METEOROLOGICAL = new UnitTypeArmSpecialisationCode(
			"Meteorological",
			"METEO",
			"A UNIT-TYPE whose primary function is to perform systematic observation of meteorological conditions and/or forecast future meteorological conditions.");
	public static final UnitTypeArmSpecialisationCode MILITARY_POLICE = new UnitTypeArmSpecialisationCode(
			"Military police",
			"MILPOL",
			"A UNIT-TYPE whose primary function is to provide police services.");
	public static final UnitTypeArmSpecialisationCode MILITARY_INTELLIGENCE_OPERATIONS = new UnitTypeArmSpecialisationCode(
			"Military intelligence, operations",
			"MIOPS",
			"A military intelligence UNIT-TYPE whose primary function is to provide information required for the planning and conducting campaigns and major operations to accomplish strategic objectives within theatres or areas of operations.");
	public static final UnitTypeArmSpecialisationCode MAINTENANCE_ELECTRONICS_ARMAMENT = new UnitTypeArmSpecialisationCode(
			"Maintenance, electronics/armament",
			"MNTELC",
			"A UNIT-TYPE whose primary function is to maintain electronics and armament (materiel) in or to restore it to operational condition.");
	public static final UnitTypeArmSpecialisationCode MAINTENANCE_ELECTRO_OPTICAL = new UnitTypeArmSpecialisationCode(
			"Maintenance, electro-optical",
			"MNTELO",
			"A UNIT-TYPE whose primary function is to maintain electro-optical materiel in or to restore it to operational condition.");
	public static final UnitTypeArmSpecialisationCode MAINTENANCE_HEAVY = new UnitTypeArmSpecialisationCode(
			"Maintenance, heavy",
			"MNTHVY",
			"A UNIT-TYPE whose primary function is to accomplish supply and repair actions necessary to keep the heavy equipment of a force in condition to carry out its mission.");
	public static final UnitTypeArmSpecialisationCode MAINTENANCE_MISSILE = new UnitTypeArmSpecialisationCode(
			"Maintenance, missile",
			"MNTMSL",
			"A UNIT-TYPE whose primary function is to maintain ordnance missile (materiel) in or to restore it to operational condition.");
	public static final UnitTypeArmSpecialisationCode MAINTENANCE_ORDNANCE = new UnitTypeArmSpecialisationCode(
			"Maintenance, ordnance",
			"MNTORD",
			"A UNIT-TYPE whose primary function is to maintain ordnance (ammunition) in or to restore it to operational condition.");
	public static final UnitTypeArmSpecialisationCode MORTUARY_GRAVES_REGISTRY = new UnitTypeArmSpecialisationCode(
			"Mortuary/graves registry",
			"MRTGRR",
			"A UNIT-TYPE whose primary function is to provide care and disposition of deceased personnel.");
	public static final UnitTypeArmSpecialisationCode MOVEMENT_CONTROL = new UnitTypeArmSpecialisationCode(
			"Movement control",
			"MVTCNT",
			"A UNIT-TYPE whose primary function is to provide planning, routing, scheduling and control of personnel and freight movements over lines of communication.");
	public static final UnitTypeArmSpecialisationCode MORALE_WELFARE_RECREATION = new UnitTypeArmSpecialisationCode(
			"Morale/welfare/recreation",
			"MWR",
			"A UNIT-TYPE whose primary function is to provide morale, welfare and recreation services in support of military personnel.");
	public static final UnitTypeArmSpecialisationCode NUCLEAR = new UnitTypeArmSpecialisationCode(
			"Nuclear",
			"NUCRAD",
			"A UNIT-TYPE whose primary function is to defend or protect against radiological or nuclear materiel dangers.");
	public static final UnitTypeArmSpecialisationCode PERSONNEL_SERVICES = new UnitTypeArmSpecialisationCode(
			"Personnel services",
			"PERSVC",
			"A UNIT-TYPE whose primary function is to provide services related to personnel administration.");
	public static final UnitTypeArmSpecialisationCode PIPELINE = new UnitTypeArmSpecialisationCode(
			"Pipeline",
			"PIPELN",
			"A UNIT-TYPE whose primary function is to construct, maintain or operate pipelines.");
	public static final UnitTypeArmSpecialisationCode POSTAL = new UnitTypeArmSpecialisationCode(
			"Postal",
			"POSTAL",
			"A UNIT-TYPE whose primary function is to provide postal services.");
	public static final UnitTypeArmSpecialisationCode PSYCHOLOGICAL = new UnitTypeArmSpecialisationCode(
			"Psychological",
			"PSYCH",
			"A UNIT-TYPE whose primary function is to provide treatment dealing with the mental and emotional state of a person.");
	public static final UnitTypeArmSpecialisationCode PSYCHOLOGICAL_OPERATIONS = new UnitTypeArmSpecialisationCode(
			"Psychological operations",
			"PSYOP",
			"A UNIT-TYPE whose primary function is to provide convey selected information and indicators to foreign audiences to influence their emotions, motives, objective reasoning, and ultimately the behaviour of foreign governments, organisations, groups, and individuals.");
	public static final UnitTypeArmSpecialisationCode PUBLIC_AFFAIRS = new UnitTypeArmSpecialisationCode(
			"Public affairs",
			"PUBAF",
			"A UNIT-TYPE whose primary function is to provide public information, command information, and community relations activities directed towards the general public.");
	public static final UnitTypeArmSpecialisationCode PUBLIC_AFFAIRS_BROADCAST = new UnitTypeArmSpecialisationCode(
			"Public affairs, broadcast",
			"PUBAFB",
			"A UNIT-TYPE whose primary function is to provide public information, command information, and community relation activities over a broadcast medium, such as radio or TV, directed towards the general public.");
	public static final UnitTypeArmSpecialisationCode PUBLIC_AFFAIRS_JOINT_INFORMATION = new UnitTypeArmSpecialisationCode(
			"Public affairs, joint information",
			"PUBAFJ",
			"A UNIT-TYPE whose primary function is to provide public information, command information, and community relations activities directed towards the general public in a joint services environment.");
	public static final UnitTypeArmSpecialisationCode QUARTERMASTER = new UnitTypeArmSpecialisationCode(
			"Quartermaster",
			"QM",
			"A UNIT-TYPE whose primary function is to provide lodging and rations for the troops.");
	public static final UnitTypeArmSpecialisationCode RAILWAY_SECURITY_FORCES = new UnitTypeArmSpecialisationCode(
			"Railway security forces",
			"RAILSE",
			"A UNIT-TYPE whose primary function is to maintain a state of law and order within railway facilities or assets.");
	public static final UnitTypeArmSpecialisationCode RANGER = new UnitTypeArmSpecialisationCode(
			"Ranger",
			"RANGER",
			"A UNIT-TYPE of rapidly deployable airborne light infantry organized and trained to conduct highly complex joint direct action operations in coordination with or in support of other special operations units of all services.");
	public static final UnitTypeArmSpecialisationCode RECONNAISSANCE_AVIATION = new UnitTypeArmSpecialisationCode(
			"Reconnaissance aviation",
			"RECAVA",
			"A UNIT-TYPE whose primary function is to obtain, by airborne means and through visual observation or other detection methods, information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographical, or geographic characteristics of a particular area.");
	public static final UnitTypeArmSpecialisationCode RECOVERY = new UnitTypeArmSpecialisationCode(
			"Recovery",
			"RECOVR",
			"A UNIT-TYPE whose primary function is to recover vehicles unable to move by their own means.");
	public static final UnitTypeArmSpecialisationCode REFUEL_AVIATION = new UnitTypeArmSpecialisationCode(
			"Refuel aviation",
			"REFAVA",
			"A UNIT-TYPE whose primary function is to deliver fuel to other aircraft while in flight.");
	public static final UnitTypeArmSpecialisationCode RELIGIOUS_CHAPLAIN = new UnitTypeArmSpecialisationCode(
			"Religious/chaplain",
			"RELCHP",
			"A UNIT-TYPE whose primary function is to provide religious services.");
	public static final UnitTypeArmSpecialisationCode REPLACEMENT_HOLDING = new UnitTypeArmSpecialisationCode(
			"Replacement holding",
			"REPLHO",
			"A UNIT-TYPE whose primary function is to provide personnel to take the place of other personnel who depart a unit.");
	public static final UnitTypeArmSpecialisationCode RIVERINE_SECURITY_FORCES = new UnitTypeArmSpecialisationCode(
			"Riverine security forces",
			"RIVSEC",
			"A UNIT-TYPE whose primary function is to maintain a state of law and order and that operates on or along a river.");
	public static final UnitTypeArmSpecialisationCode SEARCH_AND_RESCUE_AVIATION = new UnitTypeArmSpecialisationCode(
			"Search and rescue aviation",
			"SARAVA",
			"An aviation UNIT-TYPE whose primary function is to search for and rescue personnel in distress on land or sea.");
	public static final UnitTypeArmSpecialisationCode SCOUT = new UnitTypeArmSpecialisationCode(
			"Scout",
			"SCOUT",
			"A UNIT-TYPE whose primary function is to patrol an area.");
	public static final UnitTypeArmSpecialisationCode SEAL = new UnitTypeArmSpecialisationCode(
			"SEAL",
			"SEAL",
			"A UNIT-TYPE whose primary function is Sea Air Land operations.");
	public static final UnitTypeArmSpecialisationCode SECURITY_POLICE_AIR = new UnitTypeArmSpecialisationCode(
			"Security police, air",
			"SECPOL",
			"A UNIT-TYPE whose primary function is to provide security police services for air-related facilities or assets.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_COMMAND_OPERATIONS = new UnitTypeArmSpecialisationCode(
			"Signal, command operations",
			"SGCMDO",
			"No definition provided in APP-6A.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_ELECTRONIC_RANGING = new UnitTypeArmSpecialisationCode(
			"Signal, electronic ranging",
			"SGELCR",
			"A UNIT-TYPE whose primary function is to establish target distance electronically.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_NODE_CENTRE = new UnitTypeArmSpecialisationCode(
			"Signal, node centre",
			"SGNC",
			"A UNIT-TYPE whose primary function is to manage, operate and control a communications node centre.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_NODE_LARGE_EXTENSION = new UnitTypeArmSpecialisationCode(
			"Signal, node, large extension",
			"SGNLE",
			"A UNIT-TYPE whose primary function is to manage, operate and control a communications large extension node.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_NODE_SMALL_EXTENSION = new UnitTypeArmSpecialisationCode(
			"Signal, node, small extension",
			"SGNSE",
			"A UNIT-TYPE whose primary function is to manage, operate and control a communications small extension node.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_RADIO = new UnitTypeArmSpecialisationCode(
			"Signal, radio",
			"SGRAD",
			"A UNIT-TYPE whose primary function is to manage, operate and control radio communications.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_RADIO_RELAY = new UnitTypeArmSpecialisationCode(
			"Signal, radio relay",
			"SGRDRL",
			"A UNIT-TYPE whose primary function is to manage, operate and control a communications radio relay.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_SUPPORT = new UnitTypeArmSpecialisationCode(
			"Signal support",
			"SGSPT",
			"A UNIT-TYPE whose primary function is to provide personnel and equipment from other forces for the establishment of a special or supplementary communications system.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_TACTICAL_SATELLITE = new UnitTypeArmSpecialisationCode(
			"Signal, tactical satellite",
			"SGTACS",
			"A UNIT-TYPE whose primary function is to manage, operate and control a tactical satellite terminal.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_TELETYPE_CENTRE = new UnitTypeArmSpecialisationCode(
			"Signal, teletype centre",
			"SGTELC",
			"A UNIT-TYPE whose primary function is to manage, operate and control radio-teletype communications.");
	public static final UnitTypeArmSpecialisationCode SIGNAL_TELEPHONE_SWITCH = new UnitTypeArmSpecialisationCode(
			"Signal, telephone switch",
			"SGTELS",
			"A UNIT-TYPE whose primary function is to manage, operate and control a tactical telephone switch.");
	public static final UnitTypeArmSpecialisationCode SHORE_PATROL = new UnitTypeArmSpecialisationCode(
			"Shore patrol",
			"SHRPAT",
			"A UNIT-TYPE whose primary function is to provide shore patrol services.");
	public static final UnitTypeArmSpecialisationCode SIGNALS_INTELLIGENCE = new UnitTypeArmSpecialisationCode(
			"Signals intelligence",
			"SIGINT",
			"A UNIT-TYPE whose primary function is to provide intelligence derived from communications, electronics, and instrumentation signals.");
	public static final UnitTypeArmSpecialisationCode SPECIAL_BOAT = new UnitTypeArmSpecialisationCode(
			"Special boat",
			"SPBOAT",
			"No definition provided in APP-6A.");
	public static final UnitTypeArmSpecialisationCode SPECIAL_FORCES = new UnitTypeArmSpecialisationCode(
			"Special forces",
			"SPCFOR",
			"A UNIT-TYPE, selected, trained and organised to special levels, whose primary function is to be employed in pursuit of strategic objectives.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_I = new UnitTypeArmSpecialisationCode(
			"Supply, class I",
			"SPLC1",
			"A UNIT-TYPE whose primary function is to provide combat/fresh rations, water and personal, health and welfare items.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_II = new UnitTypeArmSpecialisationCode(
			"Supply, class II",
			"SPLC2",
			"A UNIT-TYPE whose primary function is to provide materiel.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_III = new UnitTypeArmSpecialisationCode(
			"Supply, class III",
			"SPLC3",
			"A UNIT-TYPE whose primary function is to provide fuel and lubricants.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_III_AVIATION = new UnitTypeArmSpecialisationCode(
			"Supply, class III aviation",
			"SPLC3A",
			"A UNIT-TYPE whose primary function is to provide aviation fuel and lubricants.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_IV = new UnitTypeArmSpecialisationCode(
			"Supply, class IV",
			"SPLC4",
			"A UNIT-TYPE whose primary function is to provide construction materials.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_CLASS_V = new UnitTypeArmSpecialisationCode(
			"Supply, class V",
			"SPLC5",
			"A UNIT-TYPE whose primary function is to provide ammunition, explosives and chemical agents.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_LAUNDRY_BATH = new UnitTypeArmSpecialisationCode(
			"Supply, laundry/bath",
			"SPLLDB",
			"A UNIT-TYPE whose primary function is to provide laundry and/or bath services.");
	public static final UnitTypeArmSpecialisationCode SUPPLY_WATER = new UnitTypeArmSpecialisationCode(
			"Supply, water",
			"SPLWAT",
			"A UNIT-TYPE whose primary function is to provide drinking water.");
	public static final UnitTypeArmSpecialisationCode SPOD_SPOE = new UnitTypeArmSpecialisationCode(
			"SPOD/SPOE",
			"SPOD",
			"A UNIT-TYPE whose primary function is to provide transportation services at sea ports where cargo or personnel arrive or depart.");
	public static final UnitTypeArmSpecialisationCode SPECIAL_OPERATIONS_SUPPORT = new UnitTypeArmSpecialisationCode(
			"Special operations support",
			"SPOPSP",
			"A UNIT-TYPE whose primary function is to support special operations forces.");
	public static final UnitTypeArmSpecialisationCode SPECIAL_SSNR = new UnitTypeArmSpecialisationCode(
			"Special SSNR",
			"SPSSNR",
			"No definition provided in APP-6A.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE_SENSOR_SCM = new UnitTypeArmSpecialisationCode(
			"Surveillance, sensor, SCM",
			"SRSNSC",
			"No definition provided in APP-6A.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE = new UnitTypeArmSpecialisationCode(
			"Surveillance",
			"SRV",
			"A UNIT-TYPE whose primary function is to perform systematic observation of aerospace, surface or subsurface areas, places, persons, or things by visual, aural, electronic, photographic, or other means.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE_GROUND_STATION_MODULE = new UnitTypeArmSpecialisationCode(
			"Surveillance, ground station module",
			"SRVGSM",
			"A UNIT-TYPE whose primary function is to manage and operate a ground module for a surveillance system.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE_GROUND_SURVEILLANCE_RADAR = new UnitTypeArmSpecialisationCode(
			"Surveillance, ground surveillance radar",
			"SRVGSR",
			"A UNIT-TYPE whose primary function is to manage and operate a ground radar for a surveillance system.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE_LONG_RANGE = new UnitTypeArmSpecialisationCode(
			"Surveillance, long range",
			"SRVLR",
			"A UNIT-TYPE whose primary function is to perform, from long range, systematic observation of aerospace, surface or subsurface areas, places, persons, or things by visual, aural, electronic, photographic, or other means from a ground station.");
	public static final UnitTypeArmSpecialisationCode SURVEILLANCE_SENSOR = new UnitTypeArmSpecialisationCode(
			"Surveillance, sensor",
			"SRVSEN",
			"A UNIT-TYPE whose primary function is to manage and operate sensor surveillance assets.");
	public static final UnitTypeArmSpecialisationCode SURGICAL = new UnitTypeArmSpecialisationCode(
			"Surgical",
			"SURG",
			"A UNIT-TYPE whose primary function is to provide surgical services.");
	public static final UnitTypeArmSpecialisationCode TACTICAL_EXPLOITATION = new UnitTypeArmSpecialisationCode(
			"Tactical exploitation",
			"TACEXP",
			"A military intelligence UNIT-TYPE whose primary function is to use information required for the planning and conducting tactical operations.");
	public static final UnitTypeArmSpecialisationCode TARGET_ACQUISITION = new UnitTypeArmSpecialisationCode(
			"Target acquisition",
			"TGTACQ",
			"A UNIT-TYPE whose primary function is to manage and operate target acquisition assets.");
	public static final UnitTypeArmSpecialisationCode TARGET_ACQUISITION_OPTICAL = new UnitTypeArmSpecialisationCode(
			"Target acquisition, optical",
			"TGTAOP",
			"A UNIT-TYPE whose primary function is to manage and operate optical target acquisition assets.");
	public static final UnitTypeArmSpecialisationCode TARGET_ACQUISITION_RADAR = new UnitTypeArmSpecialisationCode(
			"Target acquisition, radar",
			"TGTARD",
			"A UNIT-TYPE whose primary function is to manage and operate radar target acquisition assets.");
	public static final UnitTypeArmSpecialisationCode TARGET_ACQUISITION_SOUND = new UnitTypeArmSpecialisationCode(
			"Target acquisition, sound",
			"TGTASD",
			"A UNIT-TYPE whose primary function is to manage and operate sound target acquisition assets.");
	public static final UnitTypeArmSpecialisationCode TARGETING = new UnitTypeArmSpecialisationCode(
			"Targeting",
			"TGTNG",
			"A UNIT-TYPE whose primary function is to provide targeting services.");
	public static final UnitTypeArmSpecialisationCode TOPOGRAPHICAL_SURVEY = new UnitTypeArmSpecialisationCode(
			"Topographical survey",
			"TOPO",
			"A UNIT-TYPE whose primary function is to produce maps and other topographical information.");
	public static final UnitTypeArmSpecialisationCode TRANSPORTATION_MISSILE = new UnitTypeArmSpecialisationCode(
			"Transportation, missile",
			"TRNMSL",
			"A UNIT-TYPE whose primary function is to provide equipment for transportation of missiles.");
	public static final UnitTypeArmSpecialisationCode TRANSPORTATION_RAILWAYS = new UnitTypeArmSpecialisationCode(
			"Transportation, railways",
			"TRNRLY",
			"A UNIT-TYPE whose primary function is to provide transportation by means of railways.");
	public static final UnitTypeArmSpecialisationCode UNMANNED_AERIAL_VEHICLE = new UnitTypeArmSpecialisationCode(
			"Unmanned aerial vehicle",
			"UAV",
			"A UNIT-TYPE whose primary function is to utilise unmanned air assets.");
	public static final UnitTypeArmSpecialisationCode UNDERWATER_DEMOLITION = new UnitTypeArmSpecialisationCode(
			"Underwater demolition",
			"UDT",
			"A UNIT-TYPE whose primary function is to damage or destroy equipment or facilities laying totally or partially in water and that moves under the water surface to achieve this.");
	public static final UnitTypeArmSpecialisationCode UTILITY_AVIATION = new UnitTypeArmSpecialisationCode(
			"Utility aviation",
			"UTLAVA",
			"An aviation UNIT-TYPE whose primary function is to transport equipment or personnel.");
	public static final UnitTypeArmSpecialisationCode VETERINARY = new UnitTypeArmSpecialisationCode(
			"Veterinary",
			"VET",
			"A UNIT-TYPE whose primary function is to provide medical or surgical treatment for animals.");
	public static final UnitTypeArmSpecialisationCode WATER_PURIFICATION = new UnitTypeArmSpecialisationCode(
			"Water purification",
			"WATER",
			"A UNIT-TYPE whose primary function is to provide clean potable drinking/bathing water.");

	private UnitTypeArmSpecialisationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
