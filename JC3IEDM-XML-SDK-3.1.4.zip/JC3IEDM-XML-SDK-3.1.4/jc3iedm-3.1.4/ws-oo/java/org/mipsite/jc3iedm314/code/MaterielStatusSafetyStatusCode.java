/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusSafetyStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the arming state of a specific MATERIEL that is a weapon or ammunition.";
	}

	private static HashMap<String, MaterielStatusSafetyStatusCode> physicalToCode = new HashMap<String, MaterielStatusSafetyStatusCode>();

	public static MaterielStatusSafetyStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusSafetyStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusSafetyStatusCode ARMED = new MaterielStatusSafetyStatusCode(
			"Armed",
			"ARMED",
			"The specific MATERIEL is ready to fire or explode.");
	public static final MaterielStatusSafetyStatusCode NEUTRALIZED = new MaterielStatusSafetyStatusCode(
			"Neutralized",
			"NUTRLD",
			"The specific MATERIEL has been rendered incapable of firing or exploding, although it may remain dangerous to handle.");
	public static final MaterielStatusSafetyStatusCode NOT_KNOWN = new MaterielStatusSafetyStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusSafetyStatusCode SAFE = new MaterielStatusSafetyStatusCode(
			"Safe",
			"SAFE",
			"The state in which material cannot function and in which it is safe to handle and transport.");
	public static final MaterielStatusSafetyStatusCode UNASSEMBLED = new MaterielStatusSafetyStatusCode(
			"Unassembled",
			"UNASMB",
			"The specific MATERIEL is dismantled or taken apart so that it is not operable, but it can be operable if reassembled.");

	private MaterielStatusSafetyStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
