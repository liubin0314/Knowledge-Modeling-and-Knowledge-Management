/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SupportCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of SUPPORT-CAPABILITY.";
	}

	private static HashMap<String, SupportCapabilityCategoryCode> physicalToCode = new HashMap<String, SupportCapabilityCategoryCode>();

	public static SupportCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SupportCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SupportCapabilityCategoryCode BEDDING = new SupportCapabilityCategoryCode(
			"Bedding",
			"BEDDNG",
			"The capability to provide bedding.");
	public static final SupportCapabilityCategoryCode COMPRESSED_AIR = new SupportCapabilityCategoryCode(
			"Compressed air",
			"CMPAIR",
			"The capability to provide air at more than atmospheric pressure - often used to power mechanical devices or to provide a portable supply of oxygen.");
	public static final SupportCapabilityCategoryCode DECK = new SupportCapabilityCategoryCode(
			"Deck",
			"DECK",
			"The capability to provide deck supplies.");
	public static final SupportCapabilityCategoryCode EDUCATION = new SupportCapabilityCategoryCode(
			"Education",
			"EDUCTN",
			"The capability to provide education services.");
	public static final SupportCapabilityCategoryCode ELECTRICAL = new SupportCapabilityCategoryCode(
			"Electrical",
			"ELECTR",
			"The capability to provide electrical power.");
	public static final SupportCapabilityCategoryCode ENGINE = new SupportCapabilityCategoryCode(
			"Engine",
			"ENGINE",
			"The capability to provide engine supplies.");
	public static final SupportCapabilityCategoryCode FOOD_RATIONS = new SupportCapabilityCategoryCode(
			"Food/rations",
			"FODRAT",
			"The capability to provide food.");
	public static final SupportCapabilityCategoryCode FUEL_HEATING = new SupportCapabilityCategoryCode(
			"Fuel, heating",
			"FUELHE",
			"The capability to provide fuel for heating.");
	public static final SupportCapabilityCategoryCode HELICOPTER_PLATFORM = new SupportCapabilityCategoryCode(
			"Helicopter platform",
			"HELPLT",
			"The capability to provide a surface for helicopter take off and landing.");
	public static final SupportCapabilityCategoryCode HEALTHCARE = new SupportCapabilityCategoryCode(
			"Healthcare",
			"HLTHCR",
			"The capability to provide health care services.");
	public static final SupportCapabilityCategoryCode INFRASTRUCTURE_SUPPORT = new SupportCapabilityCategoryCode(
			"Infrastructure support",
			"INFSTR",
			"The capability to provide infrastructure support.");
	public static final SupportCapabilityCategoryCode LAUNDRY = new SupportCapabilityCategoryCode(
			"Laundry",
			"LUNDRY",
			"The capability to provide laundry services.");
	public static final SupportCapabilityCategoryCode MEDICAL = new SupportCapabilityCategoryCode(
			"Medical",
			"MEDCAL",
			"The capability to treat people for illnesses and injuries.");
	public static final SupportCapabilityCategoryCode MEDICAL_SUPPLIES = new SupportCapabilityCategoryCode(
			"Medical supplies",
			"MEDSPL",
			"The capability to provide medicine.");
	public static final SupportCapabilityCategoryCode MESSING = new SupportCapabilityCategoryCode(
			"Messing",
			"MESSNG",
			"The capability to provide a place providing meals and recreational facilities.");
	public static final SupportCapabilityCategoryCode PERSONAL_EQUIPMENT = new SupportCapabilityCategoryCode(
			"Personal equipment",
			"PERSEQ",
			"The capability to provide clothing.");
	public static final SupportCapabilityCategoryCode RECREATION = new SupportCapabilityCategoryCode(
			"Recreation",
			"RECRTN",
			"The capability to provide recreation services.");
	public static final SupportCapabilityCategoryCode SECURITY = new SupportCapabilityCategoryCode(
			"Security",
			"SECRTY",
			"The capability to provide security services.");
	public static final SupportCapabilityCategoryCode SEWAGE = new SupportCapabilityCategoryCode(
			"Sewage",
			"SEWAGE",
			"The capability to provide sewage and refuse disposal.");
	public static final SupportCapabilityCategoryCode SHELTER = new SupportCapabilityCategoryCode(
			"Shelter",
			"SHLTER",
			"The capability to provide shelter.");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_I = new SupportCapabilityCategoryCode(
			"Supply (class I)",
			"SPLC1",
			"The capability to provide combat/fresh rations, water and personal, health and welfare items.");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_II = new SupportCapabilityCategoryCode(
			"Supply (class II)",
			"SPLC2",
			"The capability to provide materiel (supplies for which allowances are established by tables of organisation and equipment).");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_III = new SupportCapabilityCategoryCode(
			"Supply (class III)",
			"SPLC3",
			"The capability to provide fuel and lubricants.");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_III_AVIATION = new SupportCapabilityCategoryCode(
			"Supply (class III aviation)",
			"SPLC3A",
			"The capability to provide aviation fuel and lubricants.");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_IV = new SupportCapabilityCategoryCode(
			"Supply (class IV)",
			"SPLC4",
			"The capability to provide construction materials (supplies for which initial issue allowances are not prescribed by approved issue tables).");
	public static final SupportCapabilityCategoryCode SUPPLY_CLASS_V = new SupportCapabilityCategoryCode(
			"Supply (class V)",
			"SPLC5",
			"The capability to provide ammunition, explosives and chemical agents.");
	public static final SupportCapabilityCategoryCode WATER = new SupportCapabilityCategoryCode(
			"Water",
			"WATER",
			"The capability to provide potable water.");

	private SupportCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
