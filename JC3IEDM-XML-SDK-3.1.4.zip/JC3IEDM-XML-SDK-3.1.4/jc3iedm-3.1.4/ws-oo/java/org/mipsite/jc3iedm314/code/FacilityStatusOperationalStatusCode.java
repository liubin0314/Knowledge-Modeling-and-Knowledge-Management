/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusOperationalStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the operational status of a specific FACILITY.";
	}

	private static HashMap<String, FacilityStatusOperationalStatusCode> physicalToCode = new HashMap<String, FacilityStatusOperationalStatusCode>();

	public static FacilityStatusOperationalStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusOperationalStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusOperationalStatusCode MARGINALLY_OPERATIONAL = new FacilityStatusOperationalStatusCode(
			"Marginally operational",
			"MOPS",
			"Subjectively judged by the reporting organisation to be marginally capable of performing the missions or functions for which it is organised or designed.");
	public static final FacilityStatusOperationalStatusCode NOT_KNOWN = new FacilityStatusOperationalStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FacilityStatusOperationalStatusCode NOT_OPERATIONAL = new FacilityStatusOperationalStatusCode(
			"Not operational",
			"NOP",
			"Subjectively judged by the reporting organisation to be permanently not capable of performing the missions or functions for which it is organised or designed.");
	public static final FacilityStatusOperationalStatusCode OPERATIONAL = new FacilityStatusOperationalStatusCode(
			"Operational",
			"OPR",
			"Subjectively judged by the reporting organisation to be capable of performing the missions or functions for which it is organised or designed.");
	public static final FacilityStatusOperationalStatusCode SUBSTANTIALLY_OPERATIONAL = new FacilityStatusOperationalStatusCode(
			"Substantially operational",
			"SOPS",
			"Subjectively judged by the reporting organisation to have minor deficiencies that limit its capability to perform the missions or functions for which it is organised or designed.");
	public static final FacilityStatusOperationalStatusCode TEMPORARILY_NOT_OPERATIONAL = new FacilityStatusOperationalStatusCode(
			"Temporarily not operational",
			"TNOPS",
			"Subjectively judged by the reporting organisation to be temporarily not capable of performing the missions or functions for which it is organised or designed.");

	private FacilityStatusOperationalStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
