/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of PLAN.";
	}

	private static HashMap<String, PlanCategoryCode> physicalToCode = new HashMap<String, PlanCategoryCode>();

	public static PlanCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanCategoryCode OPERATIONS_PLAN = new PlanCategoryCode(
			"Operations plan",
			"OPLAN",
			"A mechanism which a command uses to plan/prepare to conduct military operations.");
	public static final PlanCategoryCode NOT_OTHERWISE_SPECIFIED = new PlanCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private PlanCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
