/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ElectronicEquipmentTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of ELECTRONIC-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, ElectronicEquipmentTypeSubcategoryCode> physicalToCode = new HashMap<String, ElectronicEquipmentTypeSubcategoryCode>();

	public static ElectronicEquipmentTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ElectronicEquipmentTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ElectronicEquipmentTypeSubcategoryCode AMATEUR_RADIO_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Amateur radio device",
			"AMTRAD",
			"The transmission and reception of radio-frequency electromagnetic waves as a means of communication usually as a hobby.");
	public static final ElectronicEquipmentTypeSubcategoryCode AUDIO_STORAGE_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Audio storage device",
			"AUDSTD",
			"A device, usually film, tapes, or Laser Disk used for the storage of sound.");
	public static final ElectronicEquipmentTypeSubcategoryCode BEACON = new ElectronicEquipmentTypeSubcategoryCode(
			"Beacon",
			"BEACON",
			"An electronic source that emits a distinctive or characteristic signal used for the determination of bearings, courses, or locations.");
	public static final ElectronicEquipmentTypeSubcategoryCode BRAHMS = new ElectronicEquipmentTypeSubcategoryCode(
			"Brahms",
			"BRAHMS",
			"A voice encryption Terminal that provides secure speech over a civil or military phone system.");
	public static final ElectronicEquipmentTypeSubcategoryCode BATHYTHERMOGRAPH_EXPENDABLE = new ElectronicEquipmentTypeSubcategoryCode(
			"Bathythermograph, expendable",
			"BTHTGE",
			"An expendable device that records the ocean temperature at various depths. Used to assist in the determination of characteristics of sound propagation and sonar detection.");
	public static final ElectronicEquipmentTypeSubcategoryCode BATHYTHERMOGRAPH = new ElectronicEquipmentTypeSubcategoryCode(
			"Bathythermograph",
			"BTHTGH",
			"A device that records the ocean temperature at various depths. Used to assist in the determination of characteristics of sound propagation and sonar detection.");
	public static final ElectronicEquipmentTypeSubcategoryCode BUOY_CALIBRATION = new ElectronicEquipmentTypeSubcategoryCode(
			"Buoy, calibration",
			"BUOYCL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode C2IS = new ElectronicEquipmentTypeSubcategoryCode(
			"C2IS",
			"C2IS",
			"Equipment specifically designed to use as a command and control information system.");
	public static final ElectronicEquipmentTypeSubcategoryCode COMBAT_DIRECTION_FINDING = new ElectronicEquipmentTypeSubcategoryCode(
			"Combat direction finding",
			"CBDCFD",
			"A system that may be hardened or ruggedized for use in combat employed for determining the bearing of an electromagnetic emission.");
	public static final ElectronicEquipmentTypeSubcategoryCode CLASSIC_WIZARD = new ElectronicEquipmentTypeSubcategoryCode(
			"Classic wizard",
			"CLSWZD",
			"A High Frequency Direction Finding ocean surveillance system.");
	public static final ElectronicEquipmentTypeSubcategoryCode COMMUNICATION_ANTENNA = new ElectronicEquipmentTypeSubcategoryCode(
			"Communication antenna",
			"COMANT",
			"An equipment for sending or receiving electromagnetic waves.");
	public static final ElectronicEquipmentTypeSubcategoryCode COMPUTER_PERIPHERAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Computer peripheral",
			"COMPER",
			"Any device that can communicate with a computer.");
	public static final ElectronicEquipmentTypeSubcategoryCode COMMUNICATION_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Communication system",
			"COMSYS",
			"A set of equipment designed for communications purposes.");
	public static final ElectronicEquipmentTypeSubcategoryCode COMMUNICATION_VEHICLE = new ElectronicEquipmentTypeSubcategoryCode(
			"Communication vehicle",
			"COMVEH",
			"A vehicle equipped with communication devices.");
	public static final ElectronicEquipmentTypeSubcategoryCode CATHODE_RAY_TUBE = new ElectronicEquipmentTypeSubcategoryCode(
			"Cathode ray tube",
			"CTRYTB",
			"A high-vacuum tube in which cathode rays produce a luminous image on a fluorescent screen.");
	public static final ElectronicEquipmentTypeSubcategoryCode COVERED_RADIO_TELETYPE = new ElectronicEquipmentTypeSubcategoryCode(
			"Covered radio teletype",
			"CVRRAD",
			"A tactical format or encipher relay of messages.");
	public static final ElectronicEquipmentTypeSubcategoryCode DATA_LINK = new ElectronicEquipmentTypeSubcategoryCode(
			"Data link",
			"DATLNK",
			"The equipment providing the means of transmitting and receiving data.");
	public static final ElectronicEquipmentTypeSubcategoryCode DM_40_APSS_CUBIC = new ElectronicEquipmentTypeSubcategoryCode(
			"DM-40 (APSS/cubic)",
			"DM40AP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode DATA_LINK_OPTICAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Data link, optical",
			"DTLOPT",
			"Those parts of two data terminal equipments that are controlled by a protocol along with the interconnecting optical data circuit, that together enable data transfer.");
	public static final ElectronicEquipmentTypeSubcategoryCode DATA_LINK_RADIO = new ElectronicEquipmentTypeSubcategoryCode(
			"Data link, radio",
			"DTLRAD",
			"Those parts of two data terminal equipments that are controlled by a protocol along with the interconnecting radio data circuit, that together enable data transfer.");
	public static final ElectronicEquipmentTypeSubcategoryCode ELECTRONIC_SUPPORT_MEASURE = new ElectronicEquipmentTypeSubcategoryCode(
			"Electronic support measure",
			"ELSPSM",
			"Equipment that provides detection, identification, and direction-finding for radar and communication signals emanating from ships, aircraft, submarines, and other emitters.");
	public static final ElectronicEquipmentTypeSubcategoryCode ELECTROOPTICAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Electrooptical",
			"ELTOPT",
			"Equipment that deals with the translation of electromagnetic radiation in the visible and infrared portion of the spectrum into a format suitable for electronic application and vice versa.");
	public static final ElectronicEquipmentTypeSubcategoryCode FORWARD_LOOKING_INFRARED = new ElectronicEquipmentTypeSubcategoryCode(
			"Forward looking infrared",
			"FLIR",
			"An airborne, electro-optical thermal imaging device that detects far-infrared energy, converts the energy into an electronic signal, and provides a visible image for day or night viewing. Also called FLIR.");
	public static final ElectronicEquipmentTypeSubcategoryCode GPS_RECEIVER_COMMERCIAL = new ElectronicEquipmentTypeSubcategoryCode(
			"GPS receiver, commercial",
			"GPSCOM",
			"A commercial electronic system that receives and translates signals from global positioning system satellites.");
	public static final ElectronicEquipmentTypeSubcategoryCode GPS_RECEIVER_MILITARY = new ElectronicEquipmentTypeSubcategoryCode(
			"GPS receiver, military",
			"GPSMIL",
			"A military electronic system that receives and translates signals from global positioning system satellites.");
	public static final ElectronicEquipmentTypeSubcategoryCode HIGH_FREQUENCY_DIRECTION_FINDER_BULLSEYE = new ElectronicEquipmentTypeSubcategoryCode(
			"High frequency direction finder, Bullseye",
			"HFDFBL",
			"Equipment that uses a circularly-disposed antenna array, looks similar to a bulls-eye, and can detect, locate and identify targets at long range.");
	public static final ElectronicEquipmentTypeSubcategoryCode HIGH_FREQUENCY_DIRECTION_FINDER_OUTBOARD = new ElectronicEquipmentTypeSubcategoryCode(
			"High frequency direction finder, Outboard",
			"HFDFOT",
			"A direction finder that can detect, locate, and identify targets at long range. OUTBOARD - Organizational Unit Tactical Baseline Operational Area Radio Detection.");
	public static final ElectronicEquipmentTypeSubcategoryCode HIGH_FREQUENCY_DIRECTION_FINDER = new ElectronicEquipmentTypeSubcategoryCode(
			"High frequency direction finder",
			"HFRDFD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode IDENTIFICATION_FRIEND_FOE = new ElectronicEquipmentTypeSubcategoryCode(
			"Identification friend/foe",
			"IDNTFF",
			"A system using electromagnetic transmissions to which equipment carried by friendly forces automatically responds.");
	public static final ElectronicEquipmentTypeSubcategoryCode INSTRUMENT_LANDING_SYSTEM_LOCALISER = new ElectronicEquipmentTypeSubcategoryCode(
			"Instrument landing system localiser",
			"ILSLOC",
			"A system of horizontal guidance embodied in the instrument landing system which indicates the horizontal deviation of the aircraft from its optimum path of descent along the axis of the runway.");
	public static final ElectronicEquipmentTypeSubcategoryCode INFRARED_DETECTION_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Infrared detection system",
			"INDETS",
			"Equipment used to detect signals that fall within the region of the electromagnetic spectrum between the long wavelength extreme of the visible spectrum (about 0.7 micrometers) and the shortest microwaves (about 1 millimetre).");
	public static final ElectronicEquipmentTypeSubcategoryCode INTERCEPT_RECEIVER = new ElectronicEquipmentTypeSubcategoryCode(
			"Intercept receiver",
			"INTERC",
			"A receiver utilising the electromagnetic spectrum for the interception of speech and data information.");
	public static final ElectronicEquipmentTypeSubcategoryCode INTEGRATED_UNDERWATER_SURVEILLANCE_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Integrated underwater surveillance system",
			"INUWSS",
			"Fixed, mobile, and deployable acoustic listening arrays that provide a means for submarine detection.");
	public static final ElectronicEquipmentTypeSubcategoryCode LOW_FREQUENCY_ACTIVE_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Low frequency active system",
			"LFRACS",
			"Large shipboard sonar that uses intense sound for long-range surveillance and detecting submarines.");
	public static final ElectronicEquipmentTypeSubcategoryCode LOW_FREQUENCY_ANALYSIS_AND_RECORDING_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Low frequency analysis and recording system",
			"LFRARC",
			"System that detects sounds emitted by submarines using a hydrophone lowered from a passive omnidirectional sonobuoy. Also known as LOFAR system.");
	public static final ElectronicEquipmentTypeSubcategoryCode LOW_LIGHT_LEVEL_TELEVISION = new ElectronicEquipmentTypeSubcategoryCode(
			"Low light level television",
			"LGLVTV",
			"Television-type system that uses ambient light to reduce the value of the ratio of brightness between target and background and the brightness of the background that is used for day/night surveillance, target acquisition, fire control, fire adjustment, target identification, and target tracking; the LLLTV cannot �see� in complete darkness, it needs some ambient light from the atmosphere, moon, stars etc.");
	public static final ElectronicEquipmentTypeSubcategoryCode LORAN_C = new ElectronicEquipmentTypeSubcategoryCode(
			"LORAN-C",
			"LORANC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode LOUDSPEAKER = new ElectronicEquipmentTypeSubcategoryCode(
			"Loudspeaker",
			"LOUDSP",
			"An instrument for converting variations in an applied electrical current or voltage into corresponding sound waves.");
	public static final ElectronicEquipmentTypeSubcategoryCode MBR_POSITION = new ElectronicEquipmentTypeSubcategoryCode(
			"MBR position",
			"MBRPOS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode MEGAPHONE = new ElectronicEquipmentTypeSubcategoryCode(
			"Megaphone",
			"MEGPHN",
			"An electronic instrument for carrying sound a long distance.");
	public static final ElectronicEquipmentTypeSubcategoryCode MAGNETIC_ANOMALY_DETECTOR = new ElectronicEquipmentTypeSubcategoryCode(
			"Magnetic anomaly detector",
			"MGANDT",
			"A device that detects minute natural or man-made variations in the Earth's magnetic field and is used to detect submarines from aircraft.");
	public static final ElectronicEquipmentTypeSubcategoryCode MINI_RANGER_MODEL = new ElectronicEquipmentTypeSubcategoryCode(
			"Mini-ranger model",
			"MINIRN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode MARKER_BACK_COURSE = new ElectronicEquipmentTypeSubcategoryCode(
			"Marker, back course",
			"MRKRBA",
			"A marker beacon that indicates the final approach fix, where approach descent is commenced.");
	public static final ElectronicEquipmentTypeSubcategoryCode MARKER_INNER = new ElectronicEquipmentTypeSubcategoryCode(
			"Marker, inner",
			"MRKRIN",
			"A marker beacon used with an Instrument Landing System Category II precision approach located between the middle marker and the end of the ILS runway that indicates that the pilot is at the designated decision height.");
	public static final ElectronicEquipmentTypeSubcategoryCode MARKER_MIDDLE = new ElectronicEquipmentTypeSubcategoryCode(
			"Marker, middle",
			"MRKRMD",
			"A marker beacon that defines a point along the glide path of an Instrument Landing System (ILS) normally located at or near the point of decision height (ILS Category I).");
	public static final ElectronicEquipmentTypeSubcategoryCode MARKER_OUTER = new ElectronicEquipmentTypeSubcategoryCode(
			"Marker, outer",
			"MRKROU",
			"A marker beacon at or near the glide path intercept altitude of an instrument landing system approach.");
	public static final ElectronicEquipmentTypeSubcategoryCode NESTOR = new ElectronicEquipmentTypeSubcategoryCode(
			"NESTOR",
			"NESTOR",
			"A secure voice communication security systems device.");
	public static final ElectronicEquipmentTypeSubcategoryCode NIGHT_OBSERVATION_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Night observation device",
			"NGOBDV",
			"A scope, goggles, camera or other device that uses either ambient light amplification or thermal imaging using the infrared spectrum enabling vision during periods of low light.");
	public static final ElectronicEquipmentTypeSubcategoryCode NOT_KNOWN = new ElectronicEquipmentTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ElectronicEquipmentTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new ElectronicEquipmentTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ElectronicEquipmentTypeSubcategoryCode OPTICAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Optical",
			"OPTICL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/7.");
	public static final ElectronicEquipmentTypeSubcategoryCode PANORAMIC_VIEW = new ElectronicEquipmentTypeSubcategoryCode(
			"Panoramic view",
			"PANOVW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1677/7.");
	public static final ElectronicEquipmentTypeSubcategoryCode PHOTOGRAPHIC = new ElectronicEquipmentTypeSubcategoryCode(
			"Photographic",
			"PHOTOG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode PINS = new ElectronicEquipmentTypeSubcategoryCode(
			"Pins",
			"PINS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode PARKHILL = new ElectronicEquipmentTypeSubcategoryCode(
			"PARKHILL",
			"PRKHLL",
			"A secure voice communications terminal.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADIO_BROADCAST_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radio broadcast device",
			"RADBRD",
			"Organised wireless broadcasting in sound as a medium of communication or as an art form.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADIO_DIRECTION_FINDING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radio, direction finding",
			"RADDFD",
			"Equipment that uses radio signal intercepts and their azimuths to determine a location of a transmitter.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADIO_GUIDANCE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radio, guidance",
			"RADGDN",
			"Remote control of the motion of a craft or vehicle by means of radio waves.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADIO_TELEPHONE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radio, telephone",
			"RADTLP",
			"Telephone set that may be carried by a person and that uses a radio link with a telepoint base station or a base station of a mobile radio communication cellular system.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADIO_TELETYPE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radio, teletype",
			"RADTLT",
			"The system for communication by teleprinter over radio circuits (RATT).");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_INVERSE_SYNTHETIC_APERTURE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, inverse synthetic aperture",
			"RDISAR",
			"A high-resolution radar that tracks a moving object by using a stationary single radiating antenna element that transmits when the moving object is at sequential positions on its line of movement. Used in maritime surveillance.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_OVER_THE_HORIZON = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, over-the-horizon",
			"RDOTHR",
			"A radar system that makes use of the atmospheric reflection and refraction phenomena to extend its range of detection beyond line of sight.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_AIR_DEFENCE_TRACKING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, air defence tracking",
			"RDRADT",
			"A radar used specifically in an air-defence tracking mode.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_AIRBORNE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, airborne",
			"RDRARB",
			"A radar carried through the air by an aircraft.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_AIR_SURVEILLANCE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, air-surveillance",
			"RDRARS",
			"The radar used for systematic observation of air space by electronic or other means, primarily for the purpose of identifying and determining the movements of aircraft and missiles, friendly and enemy, in the air space under observation.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_ADVANCED_SYNTHETIC_APERTURE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, advanced synthetic aperture",
			"RDRASA",
			"A multimode real-time, high-resolution reconnaissance system carried on an aircraft with all-weather, day-night, and long-range mapping capabilities. ASARS detects and accurately locates stationary and moving ground targets.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_AIR_TRAFFIC_CONTROL = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, air-traffic control",
			"RDRATC",
			"A radar used for monitoring air traffic.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_BOMB_NAVIGATION = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, bomb navigation",
			"RDRBNV",
			"A radar used specifically for bomb navigation.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_COUNTER_ARTILLERY = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, counter-artillery",
			"RDRCAT",
			"A radar used to detect and locate enemy artillery weapon systems.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_COUNTER_BATTERY_RANGING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, counter-battery ranging",
			"RDRCBR",
			"Weapon locating radar capable of locating guns, mortars and rockets.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_COUNTER_MORTAR_RANGING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, counter-mortar ranging",
			"RDRCMR",
			"Mortar locating radar capable of locating mortars.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_DIRECTION_FINDING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, direction finding",
			"RDRDFD",
			"The radar used for determining the bearing of an electromagnetic emission.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_EARTH_SATELLITE_SPACE_TRACKING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, earth satellite/space tracking",
			"RDREST",
			"A radar used for tracking satellite or other objects in space.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_EARLY_WARNING_ACQUISITION = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, early warning/acquisition",
			"RDREWA",
			"A radar used for early notification of the launch or approach of unknown weapons or weapon carriers.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_FIRE_CONTROL = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, fire-control",
			"RDRFC",
			"Radar used to provide target information inputs to a weapon fire control system.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_GROUND_SURVEILLANCE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, ground surveillance",
			"RDRGRS",
			"Radar with the normal function of maintaining continuous watch over an area.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_GUIDANCE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, guidance",
			"RDRGUD",
			"A radar that provides information used to guide an object such as a missile to a target.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_HEIGHT_FINDING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, height-finding",
			"RDRHFD",
			"A radar used to display the distance between an aircraft datum and the surface vertically below as determined by a reflecting radar transmission.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_HIGH_RESOLUTION = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, high resolution",
			"RDRHRL",
			"A radar that provides detailed information on the size and shape of a target and surface imaging.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_JOINT_SURVEILLANCE_TARGET_ATTACK = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, joint surveillance target attack",
			"RDRJST",
			"A long-range, air-to-ground surveillance system designed to locate, classify and track ground targets in all weather conditions.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_METEOROLOGICAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, meteorological",
			"RDRMET",
			"A radar used to observe and measure meteorological conditions.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_NAVIGATION = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, navigation",
			"RDRNAV",
			"A navigation radar is a means by which direction and/or position is assessed when moving from one point to another. The radar facilitates navigation by determining position and may also provide vector information for calculating direction and speed.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_PRIMARY = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, primary",
			"RDRPRI",
			"A radar that is designated to be the primary in a particular platform.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_RANGING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, ranging",
			"RDRRNG",
			"A radar used for the process of establishing target distance.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_SCOPE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar scope",
			"RDRSCP",
			"A cathode ray oscilloscope on the screen of which radar echoes are represented for observation.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_SIDE_LOOKING = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, side-looking",
			"RDRSLR",
			"A radar, viewing at right angles to the axis of the vehicle, which produces a presentation of terrain or moving targets.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_SIDE_LOOKING_AIRBORNE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, side-looking airborne",
			"RDSLAR",
			"An airborne radar, viewing at right angles to the axis of the vehicle, which produces a presentation of terrain or moving targets.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_SYNTHETIC_APERTURE = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, synthetic aperture",
			"RDSNRS",
			"A high-resolution radar that simulates a large aperture by using a single radiating antenna element installed on a moving platform and transmitting at sequential positions on a line.");
	public static final ElectronicEquipmentTypeSubcategoryCode RANGEFINDER_LASER = new ElectronicEquipmentTypeSubcategoryCode(
			"Rangefinder, laser",
			"RNGLAS",
			"A device that uses laser energy for determining the distance from the device to a place or object.");
	public static final ElectronicEquipmentTypeSubcategoryCode RADAR_RELOCATABLE_OVER_THE_HORIZON = new ElectronicEquipmentTypeSubcategoryCode(
			"Radar, relocatable over-the-horizon",
			"RROTHR",
			"A relocatable radar system makes use of the atmospheric reflection and refraction phenomena to extend its range of detection beyond line of sight.");
	public static final ElectronicEquipmentTypeSubcategoryCode REMOTE_INTRUSION_DETECTION_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Remote intrusion detection device",
			"RTINDD",
			"An equipment used to detect objects moving into or within an area of interest.");
	public static final ElectronicEquipmentTypeSubcategoryCode RAYDIST_DIRECTOR = new ElectronicEquipmentTypeSubcategoryCode(
			"Raydist director",
			"RYDSTD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode RAYDIST_NON_DIRECTOR = new ElectronicEquipmentTypeSubcategoryCode(
			"Raydist non-director",
			"RYDSTN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode SOUND_RANGING = new ElectronicEquipmentTypeSubcategoryCode(
			"Sound ranging",
			"SDRANG",
			"A device used for the process of establishing target distance using sound.");
	public static final ElectronicEquipmentTypeSubcategoryCode SOUND_SURVEILLANCE_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Sound surveillance system",
			"SDSVST",
			"High-gain long fixed arrays in deep ocean basins that provide deep-water long-range detection capability using acoustic signals.");
	public static final ElectronicEquipmentTypeSubcategoryCode SHIPBOARD_EMITTER_LOCATOR = new ElectronicEquipmentTypeSubcategoryCode(
			"Shipboard emitter locator",
			"SHETLC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode SHIPBOARD_INERTIAL_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Shipboard inertial system",
			"SHINST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode SINGLE_SIDE_BAND = new ElectronicEquipmentTypeSubcategoryCode(
			"Single side band",
			"SNGSDE",
			"A secure voice communications security systems device.");
	public static final ElectronicEquipmentTypeSubcategoryCode SONAR = new ElectronicEquipmentTypeSubcategoryCode(
			"Sonar",
			"SONAR",
			"SOund NAvigation Ranging. A sonic device used primarily for the detection and location of underwater objects.");
	public static final ElectronicEquipmentTypeSubcategoryCode SWITCHBOARD = new ElectronicEquipmentTypeSubcategoryCode(
			"Switchboard",
			"SWCBRD",
			"A board for frame bearing a set of switches for connecting and disconnecting the various circuits of an electrical system, such as a telegraph or telephone.");
	public static final ElectronicEquipmentTypeSubcategoryCode TACTICAL_AIR_NAVIGATION = new ElectronicEquipmentTypeSubcategoryCode(
			"Tactical air navigation",
			"TACTAN",
			"An electronic air navigation system operating on an ultra high frequency, able to provide continuous bearing and slant range to a selected station.");
	public static final ElectronicEquipmentTypeSubcategoryCode TACTICAL_AIR_RECONNAISSANCE_PHOTO_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Tactical air reconnaissance photo system",
			"TARPHS",
			"Photographic sensor that obtains photographic information from the air that is installed on a tactical air vehicle.");
	public static final ElectronicEquipmentTypeSubcategoryCode TELEPHONE = new ElectronicEquipmentTypeSubcategoryCode(
			"Telephone",
			"TELEPH",
			"A device for conveying sound and other digital services from a subscriber to a network.");
	public static final ElectronicEquipmentTypeSubcategoryCode TELEVISION = new ElectronicEquipmentTypeSubcategoryCode(
			"Television",
			"TELEVS",
			"A device for the transmission of signals representing scenes, images of the scenes being reproduced on a screen as they are received.");
	public static final ElectronicEquipmentTypeSubcategoryCode TELEGRAPH = new ElectronicEquipmentTypeSubcategoryCode(
			"Telegraph",
			"TELGPH",
			"Pertaining to or designating equipments connected to the end of a subscriber�s line or telegraph circuit, which can either establish or receive calls, or store and retransmit signals, and which can be uniquely identified.");
	public static final ElectronicEquipmentTypeSubcategoryCode TELEPHONE_SWITCH = new ElectronicEquipmentTypeSubcategoryCode(
			"Telephone switch",
			"TELSWT",
			"A device for making and breaking the connections in a telephone system.");
	public static final ElectronicEquipmentTypeSubcategoryCode TELETYPE = new ElectronicEquipmentTypeSubcategoryCode(
			"Teletype",
			"TELTYP",
			"A telegraph instrument for transmitting telegraph messages as they are typed on a keyboard and printing incoming ones.");
	public static final ElectronicEquipmentTypeSubcategoryCode THERMAL_INFRARED = new ElectronicEquipmentTypeSubcategoryCode(
			"Thermal infrared",
			"THEINF",
			"A device that detects emitted infrared energy from both target and background, converts the infrared wavelengths to the visual spectrum.");
	public static final ElectronicEquipmentTypeSubcategoryCode THREAT_WARNING_SYSTEM = new ElectronicEquipmentTypeSubcategoryCode(
			"Threat warning system",
			"THRTWS",
			"A system that provides platform threat warning or targeting support through passive reception of electromagnetic energy.");
	public static final ElectronicEquipmentTypeSubcategoryCode TORAN = new ElectronicEquipmentTypeSubcategoryCode(
			"Toran",
			"TORAN",
			"A hyperbolic radio navigation system offering coverage in the Bay of Biscay and the Western Approaches.");
	public static final ElectronicEquipmentTypeSubcategoryCode TRANSIT_RECEIVER = new ElectronicEquipmentTypeSubcategoryCode(
			"Transit receiver",
			"TRNRCV",
			"A satellite based navigation system.");
	public static final ElectronicEquipmentTypeSubcategoryCode TRANSMITTER_MICROWAVE = new ElectronicEquipmentTypeSubcategoryCode(
			"Transmitter, microwave",
			"TRTMWV",
			"An apparatus producing microwave frequency energy intended to be radiated by an antenna, normally for the purpose of radio communication.");
	public static final ElectronicEquipmentTypeSubcategoryCode VIDEO_BROADCAST_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Video broadcast device",
			"VIDBRD",
			"A device that stores images to be displayed on a television screen or other cathode-ray tube device.");
	public static final ElectronicEquipmentTypeSubcategoryCode VINSON = new ElectronicEquipmentTypeSubcategoryCode(
			"VINSON",
			"VINSON",
			"A secure device for voice and FM communications.");
	public static final ElectronicEquipmentTypeSubcategoryCode VISUAL_STORAGE_DEVICE = new ElectronicEquipmentTypeSubcategoryCode(
			"Visual storage device",
			"VISSTR",
			"A device, usually film, tape, Digital Video Device (DVD) or Laser Disk used for the storage of pictures.");
	public static final ElectronicEquipmentTypeSubcategoryCode VISUAL = new ElectronicEquipmentTypeSubcategoryCode(
			"Visual",
			"VISUAL",
			"Equipment that uses the visual portion of the electromagnetic spectrum.");
	public static final ElectronicEquipmentTypeSubcategoryCode VERTICAL_LINE_ARRAY_DIFAR = new ElectronicEquipmentTypeSubcategoryCode(
			"Vertical line array difar",
			"VLAD",
			"An expendable, non-repairable sonobuoy known as VLAD (DIFAR is short for Directional Frequency Analysis and Recording System) designed to increase the detection of signals of interest in an environment where there is an ever-increasing amount of ambient noise.");
	public static final ElectronicEquipmentTypeSubcategoryCode VISUAL_BRG_RADAR_RANGE = new ElectronicEquipmentTypeSubcategoryCode(
			"Visual BRG/radar range",
			"VSLBRG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1200/1.");
	public static final ElectronicEquipmentTypeSubcategoryCode WARNING_AND_CONTROL_SYSTEM_AIRBORNE = new ElectronicEquipmentTypeSubcategoryCode(
			"Warning and control system, airborne",
			"WCSAIR",
			"Search and height finding radars and communications equipment (AWACS) designed to provide air surveillance and to control airborne weapons systems usually carried by an aircraft.");

	private ElectronicEquipmentTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
