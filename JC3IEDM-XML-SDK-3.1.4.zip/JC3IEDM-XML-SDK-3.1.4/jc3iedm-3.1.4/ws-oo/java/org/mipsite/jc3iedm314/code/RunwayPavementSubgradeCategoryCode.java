/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RunwayPavementSubgradeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the pavement subgrade classification, which is part of the standard ICAO (International Civil Aviation Organization) method of reporting pavement strength for pavements with bearing strength greater than 5,700 kilograms (12,500 pounds).";
	}

	private static HashMap<String, RunwayPavementSubgradeCategoryCode> physicalToCode = new HashMap<String, RunwayPavementSubgradeCategoryCode>();

	public static RunwayPavementSubgradeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RunwayPavementSubgradeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RunwayPavementSubgradeCategoryCode HIGH = new RunwayPavementSubgradeCategoryCode(
			"High",
			"A",
			"The specific value that indicates that the pavement subgrade is characterised by a (spring constant) K value greater than 400 pci (pavement condition index) for rigid pavements, and by a (California Bearing Ratio) CBR value above 13% for flexible pavements.");
	public static final RunwayPavementSubgradeCategoryCode MEDIUM = new RunwayPavementSubgradeCategoryCode(
			"Medium",
			"B",
			"The specific value that indicates that the pavement subgrade is characterised by a (spring constant) K value between 201 to 400 pci (pavement condition index) for rigid pavements, and by (California Bearing Ratio) CBR of 9 to 13% for flexible pavements.");
	public static final RunwayPavementSubgradeCategoryCode LOW = new RunwayPavementSubgradeCategoryCode(
			"Low",
			"C",
			"The specific value that indicates that the pavement subgrade is characterised by a (spring constant) K value between 100 and 200 pci (pavement condition index) for rigid pavements, and by (California Bearing Ratio) CBR of 5 to 8% for flexible pavements.");
	public static final RunwayPavementSubgradeCategoryCode ULTRA_LOW = new RunwayPavementSubgradeCategoryCode(
			"Ultra-low",
			"D",
			"The specific value that indicates that the pavement subgrade is characterised by a (spring constant) K value less than 100 pci (pavement condition index) for rigid pavements, and by a (California Bearing Ratio) CBR value less than 5% for flexible pavements.");

	private RunwayPavementSubgradeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
