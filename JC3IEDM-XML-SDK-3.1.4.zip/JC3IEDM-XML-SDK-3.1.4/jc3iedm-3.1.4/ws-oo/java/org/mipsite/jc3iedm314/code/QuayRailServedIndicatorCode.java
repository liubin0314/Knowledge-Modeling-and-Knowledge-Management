/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class QuayRailServedIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the QUAY has railway facilities.";
	}

	private static HashMap<String, QuayRailServedIndicatorCode> physicalToCode = new HashMap<String, QuayRailServedIndicatorCode>();

	public static QuayRailServedIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<QuayRailServedIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final QuayRailServedIndicatorCode NO = new QuayRailServedIndicatorCode(
			"No",
			"NO",
			"Railway services are not available at the quay.");
	public static final QuayRailServedIndicatorCode YES = new QuayRailServedIndicatorCode(
			"Yes",
			"YES",
			"Railway services are available at the quay.");

	private QuayRailServedIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
