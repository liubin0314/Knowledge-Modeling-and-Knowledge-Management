/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionMaritimeEmploymentVesselTransitInstructionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value providing lead through instructions for a convoy or vessel to pass through a maritime minefield.";
	}

	private static HashMap<String, ActionMaritimeEmploymentVesselTransitInstructionCode> physicalToCode = new HashMap<String, ActionMaritimeEmploymentVesselTransitInstructionCode>();

	public static ActionMaritimeEmploymentVesselTransitInstructionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionMaritimeEmploymentVesselTransitInstructionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionMaritimeEmploymentVesselTransitInstructionCode INFORM = new ActionMaritimeEmploymentVesselTransitInstructionCode(
			"Inform",
			"INFORM",
			"Proceed independently.");
	public static final ActionMaritimeEmploymentVesselTransitInstructionCode LEAD = new ActionMaritimeEmploymentVesselTransitInstructionCode(
			"Lead",
			"LEAD",
			"Lead through.");
	public static final ActionMaritimeEmploymentVesselTransitInstructionCode STOP = new ActionMaritimeEmploymentVesselTransitInstructionCode(
			"Stop",
			"STOP",
			"No passage allowed.");

	private ActionMaritimeEmploymentVesselTransitInstructionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
