/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VesselTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of VESSEL-TYPE.";
	}

	private static HashMap<String, VesselTypeCategoryCode> physicalToCode = new HashMap<String, VesselTypeCategoryCode>();

	public static VesselTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VesselTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VesselTypeCategoryCode UNCLASSIFIED_MISCELLANEOUS_UNIT = new VesselTypeCategoryCode(
			"Unclassified miscellaneous unit",
			"IX",
			"Ship, vessel or craft whose designation has not been classified.");
	public static final VesselTypeCategoryCode NOT_KNOWN = new VesselTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final VesselTypeCategoryCode SUBSURFACE_VESSEL_TYPE = new VesselTypeCategoryCode(
			"SUBSURFACE-VESSEL-TYPE",
			"SUBSRF",
			"A vessel principally designed to operate under the water surface.");
	public static final VesselTypeCategoryCode SURFACE_VESSEL_TYPE = new VesselTypeCategoryCode(
			"SURFACE-VESSEL-TYPE",
			"SURFAC",
			"A vessel principally designed to operate on the water surface.");

	private VesselTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
