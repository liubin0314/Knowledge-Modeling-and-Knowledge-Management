/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataEntityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the physical name of the referenced table.";
	}

	private static HashMap<String, ReportingDataEntityCategoryCode> physicalToCode = new HashMap<String, ReportingDataEntityCategoryCode>();

	public static ReportingDataEntityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataEntityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataEntityCategoryCode ACT_EFFECT = new ReportingDataEntityCategoryCode(
			"ACT_EFFECT",
			"ACTEFF",
			"");
	public static final ReportingDataEntityCategoryCode ACT_EVENT_DET = new ReportingDataEntityCategoryCode(
			"ACT_EVENT_DET",
			"ACTEVD",
			"");
	public static final ReportingDataEntityCategoryCode ACT_EVENT_STAT = new ReportingDataEntityCategoryCode(
			"ACT_EVENT_STAT",
			"ACTEVS",
			"");
	public static final ReportingDataEntityCategoryCode ACT_LOC = new ReportingDataEntityCategoryCode(
			"ACT_LOC",
			"ACTLOC",
			"");
	public static final ReportingDataEntityCategoryCode ACT_TASK_STAT = new ReportingDataEntityCategoryCode(
			"ACT_TASK_STAT",
			"ACTTST",
			"");
	public static final ReportingDataEntityCategoryCode CONTXT_ASSESS = new ReportingDataEntityCategoryCode(
			"CONTXT_ASSESS",
			"CNTASS",
			"");
	public static final ReportingDataEntityCategoryCode CTGTDET_AUTH = new ReportingDataEntityCategoryCode(
			"CTGTDET_AUTH",
			"CTDAUT",
			"");
	public static final ReportingDataEntityCategoryCode CTGTLST_AUTH = new ReportingDataEntityCategoryCode(
			"CTGTLST_AUTH",
			"CTLAUT",
			"");
	public static final ReportingDataEntityCategoryCode CTGTLST = new ReportingDataEntityCategoryCode(
			"CTGTLST",
			"CTLIST",
			"");
	public static final ReportingDataEntityCategoryCode HOLDING_TRNSF = new ReportingDataEntityCategoryCode(
			"HOLDING_TRNSF",
			"HLDTRF",
			"");
	public static final ReportingDataEntityCategoryCode HOLDING = new ReportingDataEntityCategoryCode(
			"HOLDING",
			"HOLDNG",
			"");
	public static final ReportingDataEntityCategoryCode NETWRK_SERVICE_STAT = new ReportingDataEntityCategoryCode(
			"NETWRK_SERVICE_STAT",
			"NTSRST",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_ADDR = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_ADDR",
			"OIADDR",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_AFFL = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_AFFL",
			"OIAFFL",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_ASSOC_STAT = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_ASSOC_STAT",
			"OIASST",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_CAPAB = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_CAPAB",
			"OICAPA",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_GROUP_ACCT = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_GROUP_ACCT",
			"OIGRPA",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_HSTLY_STAT = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_HSTLY_STAT",
			"OIHSTS",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_LOC = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_LOC",
			"OILOCA",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_STAT = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_STAT",
			"OISTAT",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_TYPE = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_TYPE",
			"OITYPE",
			"");
	public static final ReportingDataEntityCategoryCode ORG_STRUCT = new ReportingDataEntityCategoryCode(
			"ORG_STRUCT",
			"ORGSTR",
			"");
	public static final ReportingDataEntityCategoryCode REQUEST_ANS = new ReportingDataEntityCategoryCode(
			"REQUEST_ANS",
			"REQANS",
			"");
	public static final ReportingDataEntityCategoryCode TARGET_PRSNL_PROTECT = new ReportingDataEntityCategoryCode(
			"TARGET_PRSNL_PROTECT",
			"TPRSPR",
			"");
	public static final ReportingDataEntityCategoryCode ACT_CMT = new ReportingDataEntityCategoryCode(
			"ACT_CMT",
			"ACTCMT",
			"");
	public static final ReportingDataEntityCategoryCode OBJ_ITEM_CMT = new ReportingDataEntityCategoryCode(
			"OBJ_ITEM_CMT",
			"OICMT",
			"");

	private ReportingDataEntityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
