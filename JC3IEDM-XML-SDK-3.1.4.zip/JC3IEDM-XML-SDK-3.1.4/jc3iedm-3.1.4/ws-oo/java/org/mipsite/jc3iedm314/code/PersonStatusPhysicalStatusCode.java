/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonStatusPhysicalStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general physical status of a specific PERSON.";
	}

	private static HashMap<String, PersonStatusPhysicalStatusCode> physicalToCode = new HashMap<String, PersonStatusPhysicalStatusCode>();

	public static PersonStatusPhysicalStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonStatusPhysicalStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonStatusPhysicalStatusCode FIT = new PersonStatusPhysicalStatusCode(
			"Fit",
			"FT",
			"A status indicating that a PERSON is considered as having normal physical capabilities.");
	public static final PersonStatusPhysicalStatusCode INCAPACITATED_NOT_WALKING = new PersonStatusPhysicalStatusCode(
			"Incapacitated, not walking",
			"IN",
			"A status indicating that a PERSON is so seriously incapacitated that the person is not capable of walking and can only be moved by stretcher.");
	public static final PersonStatusPhysicalStatusCode INCAPACITATED_WALKING = new PersonStatusPhysicalStatusCode(
			"Incapacitated, walking",
			"IW",
			"A status indicating that a PERSON is incapacitated, but is capable of walking.");
	public static final PersonStatusPhysicalStatusCode NOT_KNOWN = new PersonStatusPhysicalStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonStatusPhysicalStatusCode SLIGHTLY_INCAPACITATED = new PersonStatusPhysicalStatusCode(
			"Slightly incapacitated",
			"SI",
			"A status indicating that a PERSON is incapacitated, but without any major reduction of normal physical capabilities.");

	private PersonStatusPhysicalStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
