/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkFrequencyModulationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the modulation of a specific NETWORK.";
	}

	private static HashMap<String, NetworkFrequencyModulationCode> physicalToCode = new HashMap<String, NetworkFrequencyModulationCode>();

	public static NetworkFrequencyModulationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkFrequencyModulationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkFrequencyModulationCode DOUBLE_SIDE_BAND = new NetworkFrequencyModulationCode(
			"Double side band",
			"DBSBND",
			"The modulation of a wave by varying its amplitude across the whole channel.");
	public static final NetworkFrequencyModulationCode FREQUENCY_MODULATION = new NetworkFrequencyModulationCode(
			"Frequency modulation",
			"FRQMOD",
			"The modulation of a radio or other wave by variation of its frequency.");
	public static final NetworkFrequencyModulationCode FREQUENCY_SHIFT_KEYING = new NetworkFrequencyModulationCode(
			"Frequency shift keying",
			"FRQSHF",
			"The modulation of a radio or other wave by shifting central frequency of the signal.");
	public static final NetworkFrequencyModulationCode LOWER_SIDE_BAND = new NetworkFrequencyModulationCode(
			"Lower side band",
			"LWSBND",
			"The modulation of a wave by varying its amplitude with modulation on the lower side band of the channel.");
	public static final NetworkFrequencyModulationCode PHASE_SHIFT_KEYING = new NetworkFrequencyModulationCode(
			"Phase shift keying",
			"PHSHKY",
			"The modulation of a radio or other wave by shifting phase of the signal.");
	public static final NetworkFrequencyModulationCode UPPER_SIDE_BAND = new NetworkFrequencyModulationCode(
			"Upper side band",
			"UPSBND",
			"The modulation of a wave by varying its amplitude with modulation on the upper side band of the channel.");

	private NetworkFrequencyModulationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
