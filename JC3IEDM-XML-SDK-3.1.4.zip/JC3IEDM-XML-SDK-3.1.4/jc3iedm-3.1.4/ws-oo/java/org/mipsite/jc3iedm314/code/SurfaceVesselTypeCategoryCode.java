/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SurfaceVesselTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of surface vessel.";
	}

	private static HashMap<String, SurfaceVesselTypeCategoryCode> physicalToCode = new HashMap<String, SurfaceVesselTypeCategoryCode>();

	public static SurfaceVesselTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SurfaceVesselTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SurfaceVesselTypeCategoryCode AUXILIARY_SHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Auxiliary ship, general",
			"AA",
			"General designator for all naval auxiliary ship types.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_RESCUE_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Auxiliary rescue craft",
			"AAR",
			"Vessel designed for local rescue operations inshore or offshore.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_ASSAULT_VEHICLE = new SurfaceVesselTypeCategoryCode(
			"Amphibious assault vehicle",
			"AAV",
			"Wheeled vehicle designed to carry assault troops in amphibious operations.");
	public static final SurfaceVesselTypeCategoryCode DEPOT_SHIP_TENDER = new SurfaceVesselTypeCategoryCode(
			"Depot ship/tender",
			"AB",
			"Usually a large ship designed to provide support and depot facilities to other vessels of a specific type.");
	public static final SurfaceVesselTypeCategoryCode BUOY_TENDER = new SurfaceVesselTypeCategoryCode(
			"Buoy tender",
			"ABU",
			"Ship 40 metres or more employed for the placing and tending of buoys and aids to navigation in coastal and adjoining waters.");
	public static final SurfaceVesselTypeCategoryCode BUOY_TENDER_HEAVY_LIFT = new SurfaceVesselTypeCategoryCode(
			"Buoy tender, heavy lift",
			"ABUD",
			"Ship 40 metres or more employed for the placing and tending of buoys and aids to navigation in coastal and adjoining waters with heavy lift capability.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_TENDER = new SurfaceVesselTypeCategoryCode(
			"Destroyer tender",
			"AD",
			"Ships of any size but usually large, employed primarily to furnish facilities and services for the support and repair of destroyer type ships.");
	public static final SurfaceVesselTypeCategoryCode DEPERMING_SHIP = new SurfaceVesselTypeCategoryCode(
			"Deperming ship",
			"ADG",
			"Ship designed for deperming operations.");
	public static final SurfaceVesselTypeCategoryCode AMMUNITION_SHIP = new SurfaceVesselTypeCategoryCode(
			"Ammunition ship",
			"AE",
			"Ship about 120 metres or more capable of transporting 5000 or more tons of ammunition and capable of providing underway replenishment of ammunition.");
	public static final SurfaceVesselTypeCategoryCode AMMUNITION_SHIP_SMALL = new SurfaceVesselTypeCategoryCode(
			"Ammunition ship, small",
			"AEL",
			"Ship between 40-120 metres handling less than 5000 tons of ammunition and capable of providing underway replenishment of ammunition.");
	public static final SurfaceVesselTypeCategoryCode MISSILE_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Missile support ship",
			"AEM",
			"Ship larger than 40 metres employed primarily to transport missiles.");
	public static final SurfaceVesselTypeCategoryCode AMMUNITION_SHIP_TRANSPORT = new SurfaceVesselTypeCategoryCode(
			"Ammunition ship, transport",
			"AET",
			"Ship capable of transporting 5000 or more tons of ammunition but lacking sophisticated underway replenishment capabilities.");
	public static final SurfaceVesselTypeCategoryCode AMMUNITION_SHIP_TRANSPORT_SMALL = new SurfaceVesselTypeCategoryCode(
			"Ammunition ship, transport, small",
			"AETL",
			"Ship capable of handling less than 5000 tons of ammunition but lacking sophisticated underway replenishment capabilities.");
	public static final SurfaceVesselTypeCategoryCode STORES_SHIP_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Stores ship (naval)",
			"AF",
			"Ship 60 metres or more capable of underway replenishment of ships with refrigerated and dry provisions. May carry ammunition and POL but main emphasis is on dry provisions.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_FLOATING_DRYDOCK_LARGE = new SurfaceVesselTypeCategoryCode(
			"Auxiliary floating drydock, large",
			"AFDB",
			"Floating dock capable of docking ships of all sizes.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_FLOATING_DRYDOCK_SMALL = new SurfaceVesselTypeCategoryCode(
			"Auxiliary floating drydock, small",
			"AFDL",
			"Floating dock capable of docking small ships.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_FLOATING_DRYDOCK_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Auxiliary floating drydock, medium",
			"AFDM",
			"Floating dock capable of docking medium and small ships.");
	public static final SurfaceVesselTypeCategoryCode STORES_SHIP_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Stores ship, small (naval)",
			"AFL",
			"Ship under 60 metres capable of underway replenishment of ships with refrigerated and dry provisions. May carry ammunition and POL but main emphasis is on dry provisions.");
	public static final SurfaceVesselTypeCategoryCode COMBAT_STORES_SHIP_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Combat stores ship (naval)",
			"AFS",
			"Large ship, usually over 165 metres capable of underway alongside replenishment of ships with refrigerated and dry provisions, technical spares, ammunition, and general stores. May carry POL but main emphasis is on mixed replenishment.");
	public static final SurfaceVesselTypeCategoryCode STORES_SHIP_TRANSPORT = new SurfaceVesselTypeCategoryCode(
			"Stores ship, transport",
			"AFT",
			"Ship capable of transporting 5000 or more tons of refrigerated and dry provisions, technical spares and general stores but lacking sophisticated underway replenishment capabilities.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_MISCELLANEOUS = new SurfaceVesselTypeCategoryCode(
			"Auxiliary, miscellaneous",
			"AG",
			"Ship 40 metres or more employed in general or multi-purpose functions of support, training, R&D, or a testing nature.");
	public static final SurfaceVesselTypeCategoryCode ICE_BREAKER = new SurfaceVesselTypeCategoryCode(
			"Ice breaker",
			"AGB",
			"Armed ship in size range 70 metres or more used primarily for icebreaking duties.");
	public static final SurfaceVesselTypeCategoryCode ICE_BREAKER_SMALL = new SurfaceVesselTypeCategoryCode(
			"Ice breaker, small",
			"AGBL",
			"Armed ship in size range under 70 metres used primarily for icebreaking duties.");
	public static final SurfaceVesselTypeCategoryCode ICE_BREAKER_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Ice breaker, nuclear powered",
			"AGBN",
			"Armed ship in size range 70 metres or more used primarily for icebreaking duties. It has nuclear power.");
	public static final SurfaceVesselTypeCategoryCode COMMUNICATIONS_SHIP_SMALL = new SurfaceVesselTypeCategoryCode(
			"Communications ship, small",
			"AGCL",
			"Small auxiliary optimised for communications duties.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_VESSELS_SUPPORT_SHIP_TENDER = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures vessels support ship (tender)",
			"AGCM",
			"A ship of any size employed primarily to furnish facilities and services for the support, repair and limited command of mine countermeasures vessels.");
	public static final SurfaceVesselTypeCategoryCode DEEP_SUBMERGENCE_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Deep submergence support ship",
			"AGDS",
			"A ship with special facilities to support deep submergence diving operations.");
	public static final SurfaceVesselTypeCategoryCode RESEARCH_SHIP = new SurfaceVesselTypeCategoryCode(
			"Research ship",
			"AGE",
			"Ship 49 metres or more used to conduct tests, experiments and/or research.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_FLAG_OR_COMMAND_SHIP = new SurfaceVesselTypeCategoryCode(
			"Auxiliary flag or command ship",
			"AGF",
			"Ship 55 metres or more used to provide afloat communications facilities and accommodation for a force commander and his operations staff.");
	public static final SurfaceVesselTypeCategoryCode INSTRUMENTATION_SHIP_HYDROACOUSTIC_RANGE = new SurfaceVesselTypeCategoryCode(
			"Instrumentation ship, hydroacoustic range",
			"AGH",
			"Ship specially fitted with instrumentation for hydro acoustic range operations.");
	public static final SurfaceVesselTypeCategoryCode INTELLIGENCE_COLLECTOR = new SurfaceVesselTypeCategoryCode(
			"Intelligence collector",
			"AGI",
			"Ship specially fitted for and primarily employed in the collection of electronic intelligence.");
	public static final SurfaceVesselTypeCategoryCode MISSILE_RANGE_INSTRUMENTATION_SHIP = new SurfaceVesselTypeCategoryCode(
			"Missile range instrumentation ship",
			"AGM",
			"Ship employed at sea to provide telemetry and recover missiles.");
	public static final SurfaceVesselTypeCategoryCode SUPPORT_SHIP_MISSILE_RANGE = new SurfaceVesselTypeCategoryCode(
			"Support ship, missile range",
			"AGMS",
			"Ship employed in missile range support operations.");
	public static final SurfaceVesselTypeCategoryCode OCEANOGRAPHIC_RESEARCH_SHIP_POLAR = new SurfaceVesselTypeCategoryCode(
			"Oceanographic research ship, polar",
			"AGOB",
			"Ship which conducts multi-discipline research at sea in oceanographic radiomagnetics, meteorology and oceanography, specially fitted for ice operations. Must have icebreaker bow.");
	public static final SurfaceVesselTypeCategoryCode OCEANOGRAPHIC_RESEARCH_SHIP = new SurfaceVesselTypeCategoryCode(
			"Oceanographic research ship",
			"AGOR",
			"Ship which conducts multi-discipline research at sea in oceanographic radiomagnetics, meteorology and oceanography.");
	public static final SurfaceVesselTypeCategoryCode SURVEILLANCE_SHIP_OCEAN = new SurfaceVesselTypeCategoryCode(
			"Surveillance ship, ocean",
			"AGOS",
			"No definition provided in STANAG 1166.");
	public static final SurfaceVesselTypeCategoryCode PATROL_TORPEDO_BOAT_SUPPORT_SHIP_TENDER = new SurfaceVesselTypeCategoryCode(
			"Patrol/torpedo boat support ship tender",
			"AGP",
			"Ship of any size employed primarily to furnish facilities and services for the support and repair of small patrol craft, the primary function being support.");
	public static final SurfaceVesselTypeCategoryCode RADAR_PICKET_SHIP_UNARMED = new SurfaceVesselTypeCategoryCode(
			"Radar picket ship, unarmed",
			"AGR",
			"Unarmed surface ship employed for radar picket duty.");
	public static final SurfaceVesselTypeCategoryCode SURVEY_SHIP = new SurfaceVesselTypeCategoryCode(
			"Survey ship",
			"AGS",
			"Ship 40 metres or more employed to conduct hydrographic and limited oceanographic surveys.");
	public static final SurfaceVesselTypeCategoryCode SURVEY_SHIP_POLAR = new SurfaceVesselTypeCategoryCode(
			"Survey ship, polar",
			"AGSA",
			"Ship used for surveying arctic/antarctic areas.");
	public static final SurfaceVesselTypeCategoryCode SURVEY_SHIP_COASTAL = new SurfaceVesselTypeCategoryCode(
			"Survey ship, coastal",
			"AGSC",
			"Ship 40 metres or more employed to conduct hydrographic and limited oceanographic surveys only in coastal and inshore waters.");
	public static final SurfaceVesselTypeCategoryCode LAUNCHING_SHIP_SATELLITE = new SurfaceVesselTypeCategoryCode(
			"Launching ship, satellite",
			"AGSL",
			"Ship employed in monitoring satellite launching operations.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_SHIP_TARGET = new SurfaceVesselTypeCategoryCode(
			"Service ship, target",
			"AGT",
			"Ship employed in servicing surface targets.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_SHIP_TORPEDO_TARGET = new SurfaceVesselTypeCategoryCode(
			"Service ship, torpedo/target",
			"AGTT",
			"Ship employed in servicing torpedoes and sub-surface targets.");
	public static final SurfaceVesselTypeCategoryCode HOSPITAL_SHIP = new SurfaceVesselTypeCategoryCode(
			"Hospital ship",
			"AH",
			"Ship of at least 40 metres which provides 3rd line medical and surgical care. Declared to and protected by the ICRC (International Committee of the Red Cross/red crescent (TU ships only)) and marked accordingly.");
	public static final SurfaceVesselTypeCategoryCode CARGO_SHIP_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Cargo ship (naval)",
			"AK",
			"Ship at least 80 metres employed to transport general cargo and provisions. No underway replenishment facilities.");
	public static final SurfaceVesselTypeCategoryCode CARGO_SHIP_LIGHT_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Cargo ship, light (naval)",
			"AKL",
			"Ship at least 40 - 80 metres employed to transport general cargo and provisions. No underway replenishment facilities.");
	public static final SurfaceVesselTypeCategoryCode CARGO_SHIP_ROLL_ON_ROLL_OFF_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Cargo ship, roll-on roll-off (naval)",
			"AKR",
			"Ship at least 40 metres overall designed to transport vehicles, guns and tanks in a non-combatant situation. Must have roll-on/roll-off capability for vehicles.");
	public static final SurfaceVesselTypeCategoryCode STORES_SHIP_ISSUE_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Stores ship issue (naval)",
			"AKS",
			"Ship 40 metres or more used to provide supplies and services.");
	public static final SurfaceVesselTypeCategoryCode STORES_SHIP_ISSUE_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Stores ship issue, small (naval)",
			"AKSL",
			"Ship less than 40 metres or more used to provide supplies and services.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_FERRY_CARGO_SHIP = new SurfaceVesselTypeCategoryCode(
			"Aircraft ferry/cargo ship",
			"AKV",
			"Ship at least 80 metres employed to transport general cargo and provisions. No underway replenishment facilities, employed to transport aircraft and aircraft spares.");
	public static final SurfaceVesselTypeCategoryCode LIGHT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Light ship",
			"ALS",
			"Ship actually moored or anchored in a fixed position showing navigational aiding light(s).");
	public static final SurfaceVesselTypeCategoryCode CABLE_NETLAYING_SHIP = new SurfaceVesselTypeCategoryCode(
			"Cable/netlaying ship",
			"AN",
			"Ship equipped for cable or netlaying.");
	public static final SurfaceVesselTypeCategoryCode CABLE_NETLAYING_SHIP_SMALL = new SurfaceVesselTypeCategoryCode(
			"Cable/netlaying ship, small",
			"ANL",
			"Smaller ship equipped for cable or netlaying.");
	public static final SurfaceVesselTypeCategoryCode OILER_TANKER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Oiler/tanker, general",
			"AO",
			"General designator for oilers.");
	public static final SurfaceVesselTypeCategoryCode COMBAT_SUPPORT_SHIP_FAST_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Combat support ship, fast (naval)",
			"AOE",
			"Large ship over 230 metres, capable of speeds of 25 knots - 46.3 km/hr or more and/or providing rapid and simultaneous underway replenishment of ships at sea with POL, ammunition, refrigerated and dry provisions, spare parts and general stores. Primary emphasis is on POL replenishment.");
	public static final SurfaceVesselTypeCategoryCode OILER_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Oiler, small (naval)",
			"AOL",
			"Ship in size range 60-100 metres capable of furnishing underway replenishment of POL products.");
	public static final SurfaceVesselTypeCategoryCode OILER_REPLENISHMENT_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Oiler replenishment, (naval)",
			"AOR",
			"Ship of at least 140 metres capable of providing rapid replenishment of POL and solid store products.");
	public static final SurfaceVesselTypeCategoryCode OILER_REPLENISHMENT_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Oiler replenishment, small (naval)",
			"AORL",
			"Ship between 40-140 metres capable of providing rapid replenishment of POL and solid store products.");
	public static final SurfaceVesselTypeCategoryCode SPECIAL_LIQUID_SHIP = new SurfaceVesselTypeCategoryCode(
			"Special liquid ship",
			"AOS",
			"Ship 40 metres or more designed to transport a special kind of propellant or other non-nuclear associated liquid cargo.");
	public static final SurfaceVesselTypeCategoryCode RADIOLOGICAL_LIQUID_SHIP = new SurfaceVesselTypeCategoryCode(
			"Radiological liquid ship",
			"AOSR",
			"Ship 40 metres or more designed to transport radioactive liquids.");
	public static final SurfaceVesselTypeCategoryCode OILER_TRANSPORT_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Oiler transport (naval)",
			"AOT",
			"Ship usually exceeding 120 metres capable of transporting POL products but not specially fitted to provide underway replenishment.");
	public static final SurfaceVesselTypeCategoryCode OILER_TRANSPORT_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Oiler transport, small (naval)",
			"AOTL",
			"Ship between 40-120 metres capable of transporting POL products but not specially fitted to provide underway replenishment.");
	public static final SurfaceVesselTypeCategoryCode PERSONNEL_TRANSPORT = new SurfaceVesselTypeCategoryCode(
			"Personnel transport",
			"AP",
			"Ship of at least 120 metres employed to transport troops, their supplies and equipment.");
	public static final SurfaceVesselTypeCategoryCode BARRACKS_SHIP = new SurfaceVesselTypeCategoryCode(
			"Barracks ship",
			"APB",
			"A self-propelled of any size employed as a mobile base facility and support ship for the crews of other vessels (usually small craft) and has no repair facilities.");
	public static final SurfaceVesselTypeCategoryCode PRIMARY_CASUALTY_RECEIVING_SHIP = new SurfaceVesselTypeCategoryCode(
			"Primary casualty receiving ship",
			"APCR",
			"Ship of at least 40 metres whose primary purpose is to provide 3rd line medical and surgical care. Not declared by ICRC/red crescent (TU ships only). May be armed and carrying secure communications.");
	public static final SurfaceVesselTypeCategoryCode CASUALTY_TRANSPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Casualty transport ship",
			"APCT",
			"Ship of at least 40 metres whose primary purpose is sustaining post operative casualties during transport out of theatre. Not declared by ICRC/red crescent (TU ships only). May be armed and carrying secure communications.");
	public static final SurfaceVesselTypeCategoryCode BARRACKS_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Barracks craft",
			"APL",
			"Ship of at least 120 metres employed to transport troops, their supplies and equipment but also with capability of providing barrack facilities.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP = new SurfaceVesselTypeCategoryCode(
			"Repair ship",
			"AR",
			"Ship of at least 120 metres or more employed as a mobile repair facility providing limited support to various types of ships. Not a lifting ship. Repair primary function, support secondary.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_BATTLE_DAMAGE = new SurfaceVesselTypeCategoryCode(
			"Repair ship, battle damage",
			"ARB",
			"Ship of at least 120 metres or more employed as a mobile repair facility providing limited support to various types of ships. Not a lifting ship. Repair primary function, support secondary and optimised for repair of battle damage.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_CABLE = new SurfaceVesselTypeCategoryCode(
			"Repair ship, cable",
			"ARC",
			"Ship 40 metres or more employed to lay, retrieve and maintain submarine cables.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_REPAIR_DOCK = new SurfaceVesselTypeCategoryCode(
			"Auxiliary repair dock",
			"ARD",
			"Dry dock with repair facilities for all ship sizes.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_AUXILIARY_REPAIR_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Dry dock, auxiliary, repair, medium",
			"ARDM",
			"Medium and small ship employed as a mobile repair facility providing limited support to various types of ships. Not a lifting ship. Repair primary function, support secondary.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_HEAVY_HULL = new SurfaceVesselTypeCategoryCode(
			"Repair ship, heavy, hull",
			"ARH",
			"Ship of at least 120 metres or more employed as a mobile repair facility providing limited support to various types of ships. Not a lifting ship. Repair primary function, support secondary and optimised for extensive repairs to ships hulls.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_SMALL = new SurfaceVesselTypeCategoryCode(
			"Repair ship, small",
			"ARL",
			"Ship 40-120 metres capable of providing mobile repair facilities and possible limited support to smaller boats.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_RADIOLOGICAL = new SurfaceVesselTypeCategoryCode(
			"Repair ship, radiological",
			"ARR",
			"Ship optimised to provide mobile repairs to radiological installations and facilities.");
	public static final SurfaceVesselTypeCategoryCode SALVAGE_SHIP = new SurfaceVesselTypeCategoryCode(
			"Salvage ship",
			"ARS",
			"Ship at least 40 metres used to provide mobile salvage, repairs, diving and rescue services.");
	public static final SurfaceVesselTypeCategoryCode SALVAGE_SHIP_LIFTING = new SurfaceVesselTypeCategoryCode(
			"Salvage ship, lifting",
			"ARSD",
			"Ship at least 40 metres used to provide mobile salvage, repairs, diving and rescue services, must have heavy lifting capability.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_SHIP_AIRCRAFT = new SurfaceVesselTypeCategoryCode(
			"Repair ship, aircraft",
			"ARV",
			"Ship of any size used to repair helicopters, aircraft and aircraft engines.");
	public static final SurfaceVesselTypeCategoryCode SUBMARINE_TENDER = new SurfaceVesselTypeCategoryCode(
			"Submarine tender",
			"AS",
			"Ship of at least 120 metres or more that provides mobile base facilities and support for submarines.");
	public static final SurfaceVesselTypeCategoryCode SUBMARINE_TENDER_SMALL = new SurfaceVesselTypeCategoryCode(
			"Submarine tender, small",
			"ASL",
			"Ship between 40-120 metres, which provide mobile base facilities and support for submarines.");
	public static final SurfaceVesselTypeCategoryCode SUBMARINE_RESCUE_SHIP = new SurfaceVesselTypeCategoryCode(
			"Submarine rescue ship",
			"ASR",
			"Any ship equipped to rescue personnel entrapped in a sunken submarine.");
	public static final SurfaceVesselTypeCategoryCode SPACE_VEHICLE_RECOVERY_SHIP = new SurfaceVesselTypeCategoryCode(
			"Space vehicle recovery ship",
			"ASVR",
			"Any ship equipped to recover space capsules following space flights.");
	public static final SurfaceVesselTypeCategoryCode TUG_OCEAN_GOING = new SurfaceVesselTypeCategoryCode(
			"Tug, ocean-going",
			"AT",
			"General designator for tugs capable of operating in open ocean waters.");
	public static final SurfaceVesselTypeCategoryCode TUG_OCEAN_GOING_AUXILIARY = new SurfaceVesselTypeCategoryCode(
			"Tug, ocean-going, auxiliary",
			"ATA",
			"Seagoing tug employed to tow navy ships and craft. Usually about 40-50 metres.");
	public static final SurfaceVesselTypeCategoryCode TUG_OCEAN_GOING_FLEET = new SurfaceVesselTypeCategoryCode(
			"Tug, ocean-going, fleet",
			"ATF",
			"Seagoing tug employed to tow navy ships and craft. Usually about 40-50 metres, but equipped to operate with fleets.");
	public static final SurfaceVesselTypeCategoryCode TUG_OCEAN_GOING_RESCUE = new SurfaceVesselTypeCategoryCode(
			"Tug, ocean-going, rescue",
			"ATR",
			"Seagoing tug employed to tow navy ships and craft. Usually about 40-50 metres, but equipped to operate with fleets and extensively equipped for fire fighting and rescue operations.");
	public static final SurfaceVesselTypeCategoryCode TUG_OCEAN_GOING_OR_SHIP_SALVAGE_RESCUE = new SurfaceVesselTypeCategoryCode(
			"Tug, ocean-going or ship salvage/rescue",
			"ATS",
			"Ship that can provide salvage, repair, diving and rescue services, and tow ships and craft.");
	public static final SurfaceVesselTypeCategoryCode AVIATION_TENDER = new SurfaceVesselTypeCategoryCode(
			"Aviation tender",
			"AV",
			"General designator for vessels that have repair and support facilities for aircraft.");
	public static final SurfaceVesselTypeCategoryCode AVIATION_LOGISTIC_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Aviation logistic support ship",
			"AVB",
			"Large ship equipped to provide aviation logistic support.");
	public static final SurfaceVesselTypeCategoryCode AVIATION_TENDER_GUIDED_MISSILE_SUPPORT = new SurfaceVesselTypeCategoryCode(
			"Aviation tender, guided missile support",
			"AVM",
			"Ship with supply and support facilities for airborne guided missiles.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_RESCUE_VESSEL = new SurfaceVesselTypeCategoryCode(
			"Aircraft rescue vessel",
			"AVR",
			"Any ship equipped to rescue personnel trapped in a sunken aircraft. May also have facilities to salvage sunken aircraft.");
	public static final SurfaceVesselTypeCategoryCode AVIATION_SUPPLY_SHIP = new SurfaceVesselTypeCategoryCode(
			"Aviation supply ship",
			"AVS",
			"Ship equipped to carry and supply aviation stores.");
	public static final SurfaceVesselTypeCategoryCode AUXILIARY_AIRCRAFT_LANDING_TRAINING_SHIP = new SurfaceVesselTypeCategoryCode(
			"Auxiliary aircraft landing training ship",
			"AVT",
			"Training carrier for command and fleet carrier qualification requirements.");
	public static final SurfaceVesselTypeCategoryCode WATER_TENDER_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Water tender (naval)",
			"AWT",
			"Ship used primarily for transporting potable water.");
	public static final SurfaceVesselTypeCategoryCode DISTILLING_SHIP_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Distilling ship (naval)",
			"AWW",
			"Ship capable of distilling and transporting potable water.");
	public static final SurfaceVesselTypeCategoryCode TRAINING_SHIP_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Training ship (naval)",
			"AX",
			"Large ocean-going ship designed to serve as a training ship.");
	public static final SurfaceVesselTypeCategoryCode TRAINING_SHIP_SMALL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Training ship, small (naval)",
			"AXL",
			"Large non-ocean-going ship designed to serve as a training ship.");
	public static final SurfaceVesselTypeCategoryCode TRAINING_SHIP_SAIL_NAVAL = new SurfaceVesselTypeCategoryCode(
			"Training ship sail (naval)",
			"AXS",
			"Naval sail training ship.");
	public static final SurfaceVesselTypeCategoryCode BATTLESHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Battleship, general",
			"BB",
			"Capital surface ship designed for surface action with a reasonable compromise between speed, protection and armament that may include guided missiles. A very large, heavily armoured vessel.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GUN = new SurfaceVesselTypeCategoryCode(
			"Cruiser, gun",
			"CA",
			"Cruiser with guns 15 cm (6 inch) or larger as its main armament and with no missile systems.");
	public static final SurfaceVesselTypeCategoryCode CATAMARAN = new SurfaceVesselTypeCategoryCode(
			"Catamaran",
			"CAT",
			"Sail or engine powered vessel with twin hulls.");
	public static final SurfaceVesselTypeCategoryCode CATBOAT = new SurfaceVesselTypeCategoryCode(
			"Catboat",
			"CATBAT",
			"Small fishing vessel of specific design, usually powered by sail.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Cruiser, general",
			"CC",
			"General designator for all cruiser type ships of 140 metres or more. A fast warship of medium tonnage with a long cruising radius and les firepower and armour than a battleship.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Cruiser, guided missile",
			"CG",
			"Cruiser with one or more force guided missile systems as its main armament.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GUIDED_MISSILE_HELICOPTER_CAPABLE = new SurfaceVesselTypeCategoryCode(
			"Cruiser, guided missile, helicopter capable",
			"CGH",
			"Cruiser with one or more force guided missile systems as its main armament, fitted with a flight deck with a primary mission of operating and maintaining helicopters.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GUIDED_MISSILE_HELICOPTER_CAPABLE_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Cruiser, guided missile, helicopter capable, nuclear powered",
			"CGHN",
			"Cruiser with one or more force guided missile systems as its main armament, fitted with a flight deck with a primary mission of operating and maintaining helicopters but with nuclear power.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_GUIDED_MISSILE_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Cruiser, guided missile, nuclear powered",
			"CGN",
			"Cruiser with one or more force guided missile systems as its main armament and having nuclear power.");
	public static final SurfaceVesselTypeCategoryCode CRUISER_HELICOPTER_CAPABLE = new SurfaceVesselTypeCategoryCode(
			"Cruiser, helicopter capable",
			"CH",
			"General designator for all cruiser type ships of 140 metres or more, fitted with a flight deck with a primary mission of operating and maintaining helicopters.");
	public static final SurfaceVesselTypeCategoryCode CUTTER = new SurfaceVesselTypeCategoryCode(
			"Cutter",
			"CUTTER",
			"Sailing vessel of cutter design.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, general",
			"CV",
			"General designator for aircraft/multi-role aircraft carrier.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, guided missile",
			"CVG",
			"Designator for multi-role aircraft carriers, fitted with one or more force guided missile systems.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_GUIDED_MISSILE_NUCLEAR_POWER = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, guided missile, nuclear power",
			"CVGN",
			"Designator for multi-role aircraft carriers, fitted with one or more force guided missile systems, nuclear powered.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_HELICOPTER_VSTOL = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, helicopter/VSTOL",
			"CVH",
			"Aircraft carrier without arrest gear/catapult operating VSTOL aircraft and/or helicopters that is not an amphibious or minewarfare ship.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_HELICOPTER_VSTOL_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, helicopter/VSTOL, guided missile",
			"CVHG",
			"Aircraft carrier without arrest gear/catapult operating VSTOL aircraft and/or helicopters which is not an amphibious or minewarfare ship, fitted with one or more force guided missile systems.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_HELICOPTER_VSTOL_GUIDED_MISSILE_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, helicopter/VSTOL, guided missile, nuclear powered",
			"CVHGN",
			"Aircraft carrier without arrest gear/catapult operating VSTOL aircraft and/or helicopters which is not an amphibious or minewarfare ship, fitted with one or more force guided missile systems and with nuclear power.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_HELICOPTER_VSTOL_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, helicopter/VSTOL, nuclear powered",
			"CVHN",
			"Aircraft carrier without arrest gear/catapult operating VSTOL aircraft and/or helicopters that is not an amphibious or minewarfare ship, having nuclear power.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_LIGHT = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, light",
			"CVL",
			"Designator for multi-role aircraft carriers under a certain tonnage (tbd).");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_LIGHT_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, light, guided missile",
			"CVLG",
			"Designator for multi-role aircraft carriers, fitted with one or more force guided missile systems under a certain tonnage (tbd).");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_NUCLEAR_POWERED = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, nuclear powered",
			"CVN",
			"Designator for multi-role aircraft carriers with nuclear power.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_ASW = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, ASW",
			"CVS",
			"Carrier capable of operating VSTOL and/or helicopters in sustained anti-submarine warfare (ASW) area operations and escort duties.");
	public static final SurfaceVesselTypeCategoryCode AIRCRAFT_CARRIER_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Aircraft carrier, training",
			"CVT",
			"Designator for multi-role aircraft carriers used primarily in a training role.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Destroyer, general",
			"DD",
			"General designator for destroyer type ships. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Destroyer, guided missile",
			"DDG",
			"A destroyer type ship fitted with one more force guided missile systems. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_HELICOPTER_CAPABLE_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Destroyer, helicopter capable, guided missile",
			"DDGH",
			"A destroyer type ship fitted with one more force guided missile systems and with a flight deck with a primary mission of operating and maintaining helicopters. Major surface combatant in range of about 95 to 140 metres whole general mission is to operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_HELICOPTER_CAPABLE = new SurfaceVesselTypeCategoryCode(
			"Destroyer, helicopter capable",
			"DDH",
			"A destroyer type ship fitted with a flight deck with a primary mission of operating and maintaining helicopters. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Destroyer, training",
			"DDT",
			"A destroyer type ship used primarily in a training role. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_ESCORT = new SurfaceVesselTypeCategoryCode(
			"Destroyer, escort",
			"DE",
			"A destroyer type ship optimised for escort duties. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode DHOW = new SurfaceVesselTypeCategoryCode(
			"Dhow",
			"DHOW",
			"Sailing vessel, usually associated with middle eastern countries of specific design. May be powered by engine or sails, usually used for transportation purposes.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Frigate, general",
			"FF",
			"General designator for frigate. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role. Generally has lighter surface armament than a Destroyer, general.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Frigate, guided missile",
			"FFG",
			"A frigate fitted with one or more force guided missile systems. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_GUIDED_MISSILE_HELICOPTER_CAPABLE = new SurfaceVesselTypeCategoryCode(
			"Frigate, guided missile, helicopter capable",
			"FFGH",
			"A frigate fitted with one or more force guided missile systems and a flight deck with a primary mission of operating and maintaining helicopters. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_HELICOPTER_CAPABLE = new SurfaceVesselTypeCategoryCode(
			"Frigate, helicopter capable",
			"FFH",
			"A frigate fitted with a flight deck with a primary mission of operating and maintaining helicopters. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_SMALL_OR_CORVETTE = new SurfaceVesselTypeCategoryCode(
			"Frigate, small or corvette",
			"FFL",
			"General designator for frigate but smaller. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role. Generally has lighter surface armament than a Destroyer, general. Classification determined by armament or capability.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_SMALL_OR_CORVETTE_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Frigate, small or corvette, guided missile",
			"FFLG",
			"General designator for frigate fitted with one or more force guided missile systems. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role. Generally has lighter surface armament than a Destroyer, general. Classification determined by armament or capability.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Frigate, training",
			"FFT",
			"General designator for frigate used primarily in a training role. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role. Generally has lighter surface armament than a Destroyer, general. Classification determined by armament or capability.");
	public static final SurfaceVesselTypeCategoryCode CORVETTE = new SurfaceVesselTypeCategoryCode(
			"Corvette",
			"FS",
			"A speedy, lightly armed warship smaller than a destroyer.");
	public static final SurfaceVesselTypeCategoryCode HOUSEBOAT = new SurfaceVesselTypeCategoryCode(
			"Houseboat",
			"HUSBAT",
			"Vessel designed or converted to provide living accommodation.");
	public static final SurfaceVesselTypeCategoryCode KETCH = new SurfaceVesselTypeCategoryCode(
			"Ketch",
			"KETCH",
			"Vessel of specific design, usually powered by sail.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_AMPHIBIOUS_RE_SUPPLY_CARGO = new SurfaceVesselTypeCategoryCode(
			"Lighter, amphibious, re-supply, cargo",
			"LARC",
			"A lighter designed to carry cargo for the re-supply of landing forces.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_AMPHIBIOUS_RE_SUPPLY_VEHICLE = new SurfaceVesselTypeCategoryCode(
			"Lighter, amphibious, re-supply, vehicle",
			"LARCV",
			"A lighter designed to carry cargo and vehicles for the re-supply of landing forces.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Landing craft",
			"LC",
			"General designation for amphibious landing craft.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Landing craft, air cushion",
			"LCAC",
			"High speed (40 knots - 74 km/hr) assault landing craft capable of travelling over land and water from over-the-horizon distances 12-200nm - 22-370 km using air cushion/gas turbine propulsion.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_FORCE_FLAGSHIP_OR_AMPHIBIOUS_COMMAND_SHIP = new SurfaceVesselTypeCategoryCode(
			"Amphibious force flagship or amphibious command ship",
			"LCC",
			"Command ship for amphibious task force and landing operations. May carry a limited number of troops and supplies for the headquarters element of the landing force.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_FIRE_SUPPORT = new SurfaceVesselTypeCategoryCode(
			"Landing craft, fire support",
			"LCFS",
			"Landing craft optimised to provide fire support with guns or rockets during amphibious assaults. Probably does not carry troops.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_MECHANIZED = new SurfaceVesselTypeCategoryCode(
			"Landing craft, mechanized",
			"LCM",
			"Landing craft in size range 15-25 metres capable of carrying 1 tank or 50-200 troops. Must have landing ramp.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_MEDIUM_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Landing craft, medium, air cushion",
			"LCMJ",
			"Landing craft in size range 15-25 metres capable of carrying 1 tank or 50-200 troops. Must have landing ramp. It is an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_PERSONNEL = new SurfaceVesselTypeCategoryCode(
			"Landing craft, personnel",
			"LCP",
			"Landing craft in size range 7.5-30 metres overall suitable only for carrying personnel. May be fast and/or ramped.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_PERSONNEL_ARMOURED = new SurfaceVesselTypeCategoryCode(
			"Landing craft, personnel, armoured",
			"LCPA",
			"Landing craft in size range 7.5-30 metres overall suitable only for carrying personnel. May be fast and/or ramped and armoured for protection.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_PERSONNEL_LARGE = new SurfaceVesselTypeCategoryCode(
			"Landing craft, personnel, large",
			"LCPL",
			"11 metre landing control boat used primarily to control amphibious seaborne assault waves.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_TANK = new SurfaceVesselTypeCategoryCode(
			"Landing craft, tank",
			"LCT",
			"Landing craft in size range 15-25 metres capable of carrying 1 tank or 50-200 troops. Must have landing ramp and is optimised for carrying and landing tanks and vehicles.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_UTILITY = new SurfaceVesselTypeCategoryCode(
			"Landing craft, utility",
			"LCU",
			"All-purpose landing craft in size range 25-55 metres and full load of 120-500 tons with landing ramp/other landing facilities used for handling 2-3 tanks or 300-450 troops.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_UTILITY_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Landing craft, utility, air cushion",
			"LCUJ",
			"All-purpose landing craft in size range 25-55 metres and full load of 120-500 tons with landing ramp/other landing facilities used for handling 2-3 tanks or 300-450 troops with an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_VEHICLE_PERSONNEL = new SurfaceVesselTypeCategoryCode(
			"Landing craft, vehicle personnel",
			"LCVP",
			"Landing craft in size range 7.5-30 metres capable of carrying a light vehicle in place of troops. Must have bow ramp.");
	public static final SurfaceVesselTypeCategoryCode LANDING_CRAFT_SWIMMER_SUPPORT = new SurfaceVesselTypeCategoryCode(
			"Landing craft, swimmer support",
			"LCW",
			"High-speed craft utilised primarily for underwater demolition and/or special warfare operations.");
	public static final SurfaceVesselTypeCategoryCode SWIMMER_DELIVERY_VEHICLE = new SurfaceVesselTypeCategoryCode(
			"Swimmer delivery vehicle",
			"LDW",
			"Amphibious ship designed to operate swimmers.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_FIRE_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Amphibious fire support ship",
			"LFS",
			"Landing ship converted for use in amphibious assaults. Armament is usually rocket launchers, but may also have bombardment guns. May or may not carry troops.");
	public static final SurfaceVesselTypeCategoryCode ASSAULT_CRAFT_GUN_EQUIPPED = new SurfaceVesselTypeCategoryCode(
			"Assault craft, gun equipped",
			"LG",
			"Assault landing craft equipped with guns.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_ASSAULT_SHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Amphibious assault ship, general",
			"LHA",
			"A large general purpose ship which embarks and lands elements of an assault force in both organic helicopters and organic landing craft. Capable of carrying about 1800 assault troops. Must have internal stowage and ramp, and flooded well capability for vehicles or craft.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_ASSAULT_SHIP_MULTI_PURPOSE = new SurfaceVesselTypeCategoryCode(
			"Amphibious assault ship, multi-purpose",
			"LHD",
			"A large multi-purpose amphibious ship that embarks and lands elements of a landing force by helicopter, landing craft and amphibious vehicles. Can also conduct sea control and power projection missions with VSTOL aircraft and ASW helicopters.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_CARGO_SHIP = new SurfaceVesselTypeCategoryCode(
			"Amphibious cargo ship",
			"LKA",
			"Ship which carries supplies for amphibious assaults and can land the same in its own organic landing craft.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_SHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Amphibious ship, general",
			"LL",
			"General designator for amphibious vessels.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_ASSAULT_SHIP_BEACHING = new SurfaceVesselTypeCategoryCode(
			"Amphibious assault ship, beaching",
			"LLB",
			"Amphibious ship designed for beaching operations.");
	public static final SurfaceVesselTypeCategoryCode ASSAULT_SHIP_PERSONNEL = new SurfaceVesselTypeCategoryCode(
			"Assault ship, personnel",
			"LLP",
			"Amphibious ship designed specifically to carry personnel.");
	public static final SurfaceVesselTypeCategoryCode ASSAULT_SHIP_TANK = new SurfaceVesselTypeCategoryCode(
			"Assault ship, tank",
			"LLT",
			"Assault ship optimised for carrying tanks.");
	public static final SurfaceVesselTypeCategoryCode ASSAULT_CRAFT_MISSILE_EQUIPPED = new SurfaceVesselTypeCategoryCode(
			"Assault craft, missile equipped",
			"LM",
			"Landing craft equipped with other than force guided missiles.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_TRANSPORT_DOCK = new SurfaceVesselTypeCategoryCode(
			"Amphibious transport, dock",
			"LPD",
			"Ship that carries about 1000 troops. Capable of carrying up to 9 LCM (Landing craft, mechanized). Primarily a troop ship and armoured car carrier, with considerable internal berthing space. Must have permanent helicopter platform.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_ASSAULT_SHIP_HELICOPTER = new SurfaceVesselTypeCategoryCode(
			"Amphibious assault ship, helicopter",
			"LPH",
			"A large helicopter carrier with the mission of transporting and landing about 1800 assault troops with its organic aircraft. Employment of organic landing craft is not a principle function.");
	public static final SurfaceVesselTypeCategoryCode AMPHIBIOUS_TRANSPORT_PERSONNEL = new SurfaceVesselTypeCategoryCode(
			"Amphibious transport, personnel",
			"LPP",
			"A large ship capable of carrying 1300-1500 assault troops and capable of landing them in its own organic landing craft.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Landing ship, general",
			"LS",
			"General designator for an amphibious landing ship.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_DOCK = new SurfaceVesselTypeCategoryCode(
			"Landing ship, dock",
			"LSD",
			"Primarily a tank and vehicle carrier but capable of transporting 150-400 assault troops and launch them embarked in organic landing craft without off-loading in the landing area. Need not have a helicopter platform.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_LOGISTICS = new SurfaceVesselTypeCategoryCode(
			"Landing ship, logistics",
			"LSL",
			"Landing ship capable of carrying initial, second and follow-on echelon equipment, vehicles and troops. Normally ramped, not part of initial assault force.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Landing ship, medium",
			"LSM",
			"Ship in size range 45-85 metres, capable of beaching to land troops and/or tanks. Must have bow doors and/or landing ramp.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_TANK = new SurfaceVesselTypeCategoryCode(
			"Landing ship, tank",
			"LST",
			"Ship in size range 85-100 metres employed to transport troops, vehicles and tanks for amphibious assault. Must have bow doors and/or landing ramp.");
	public static final SurfaceVesselTypeCategoryCode LANDING_SHIP_VEHICLE = new SurfaceVesselTypeCategoryCode(
			"Landing ship, vehicle",
			"LSV",
			"Ship in size range 45-60 metres overall, intended primarily to carry vehicles. Must have bow doors and/or landing ramp. Not capable of beaching.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_VESSEL_UNSPECIFIED = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures vessel, unspecified",
			"MC",
			"General designator for mine countermeasures vessel with no specification.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_COMMAND_AND_SUPPORT = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures command and support",
			"MCCS",
			"An armed combatant fitted for the command and support of MCM vessels and their equipment.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_VESSEL_DIVING = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures vessel, diving",
			"MCD",
			"A mine countermeasures vessel specially equipped to carry out and support diving operations.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_VESSEL_HOVERCRAFT = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures vessel, hovercraft",
			"MCJ",
			"A mine countermeasures vessel that is air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_VESSEL_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures vessel, general",
			"MCMV",
			"General designator for mine countermeasures vessels.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures support ship",
			"MCS",
			"An armed combatant fitted for the control and support of MCM vessels in combat situations. Has limited facilities for repair of Mine countermeasures vessels and their equipment.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_SUPPORT_SHIP_SMALL = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures support ship, small",
			"MCSL",
			"A smaller armed combatant fitted for the control and diminished support of MCM vessels in combat situations. Has limited facilities for repair of Mine countermeasures vessels and their equipment.");
	public static final SurfaceVesselTypeCategoryCode MINE_COUNTERMEASURES_CRAFT_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Mine countermeasures craft, training",
			"MCT",
			"A vessel used primarily in a mine countermeasures training role.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Minehunter, general",
			"MH",
			"Ship equipped with specific equipment to hunt mines.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_AUXILIARY = new SurfaceVesselTypeCategoryCode(
			"Minehunter, auxiliary",
			"MHA",
			"Any seagoing ship not designed as a mine hunter but converted to such use.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_COASTAL = new SurfaceVesselTypeCategoryCode(
			"Minehunter, coastal",
			"MHC",
			"Ship equipped with specific equipment to hunt mines and designed to operate in coastal waters.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_COASTAL_WITH_DRONE = new SurfaceVesselTypeCategoryCode(
			"Minehunter, coastal with drone",
			"MHCD",
			"Ship equipped with specific equipment to hunt mines by the use of a drone.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_INSHORE = new SurfaceVesselTypeCategoryCode(
			"Minehunter, inshore",
			"MHI",
			"Ship equipped with specific equipment to hunt mines and designed for operating in more shallow waters or estuaries.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_OCEAN = new SurfaceVesselTypeCategoryCode(
			"Minehunter, ocean",
			"MHO",
			"Ship equipped with specific equipment to hunt mines and designed for operating in ocean waters.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_SWEEPER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Minehunter/sweeper, general",
			"MHS",
			"A mine warfare craft equipped for both hunting and sweeping mines.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_SWEEPER_COASTAL = new SurfaceVesselTypeCategoryCode(
			"Minehunter/sweeper, coastal",
			"MHSC",
			"A mine warfare craft equipped for both hunting and sweeping mines, limited to coastal waters.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_SWEEPER_W_DRONE = new SurfaceVesselTypeCategoryCode(
			"Minehunter/sweeper w/drone",
			"MHSD",
			"A mine warfare craft equipped for both hunting and sweeping mines by the use of a drone.");
	public static final SurfaceVesselTypeCategoryCode MINEHUNTER_SWEEPER_OCEAN = new SurfaceVesselTypeCategoryCode(
			"Minehunter/sweeper, ocean",
			"MHSO",
			"A mine warfare craft equipped for both hunting and sweeping mines and capable of operating in open ocean waters.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Minelayer, general",
			"ML",
			"A ship with a primary mission of laying mines.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_AUXILIARY = new SurfaceVesselTypeCategoryCode(
			"Minelayer, auxiliary",
			"MLA",
			"Any fishing or merchant ship having both capability and mission to lay mines.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_COASTAL = new SurfaceVesselTypeCategoryCode(
			"Minelayer, coastal",
			"MLC",
			"Minelayer in size range 50 - 85 metres overall.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_INSHORE = new SurfaceVesselTypeCategoryCode(
			"Minelayer, inshore",
			"MLI",
			"Minelayer in size range 25 - 50 metres overall.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_OCEAN = new SurfaceVesselTypeCategoryCode(
			"Minelayer, ocean",
			"MLO",
			"Large ship over 85 metres used primarily for minelaying.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_RIVER = new SurfaceVesselTypeCategoryCode(
			"Minelayer, river",
			"MLR",
			"Small minelayer 15 metres or less suitable only for operations on rivers or in protected roadsteads.");
	public static final SurfaceVesselTypeCategoryCode MINELAYER_SUPPORT_SHIP = new SurfaceVesselTypeCategoryCode(
			"Minelayer, support ship",
			"MLS",
			"A large armed ship (over 90 metres) capable of extensive minelaying, but not capable of speeds over 30 knots - 55 km/hr, with the facilities for command and control of mine warfare ships and boats in combat environment. Has limited support capability.");
	public static final SurfaceVesselTypeCategoryCode MINE_WARFARE_VESSEL_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Mine warfare vessel, general",
			"MM",
			"General designator for mine warfare vessels.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, general",
			"MS",
			"Ship designed to sweep mines.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_AUXILIARY = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, auxiliary",
			"MSA",
			"Any seagoing ship not designed as a minesweeper but converted to such use.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_BOAT = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, boat",
			"MSB",
			"Minesweeper less than 12.5 metres.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal",
			"MSC",
			"Non-magnetic minesweeper between 40-70 metres.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL_W_DRONE_S = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal w/drone(s)",
			"MSCD",
			"Coastal minesweeper capable of deploying and/or controlling unmanned remote controlled or towed vehicle(s) used for clearing mines.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal, air cushion",
			"MSCJ",
			"Non-magnetic minesweeper between 40-70 metres with an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal, hydrofoil",
			"MSCK",
			"Non-magnetic minesweeper between 40-70 metres, fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL_SPECIAL = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal, special",
			"MSCS",
			"A minesweeper fitted with special to type mine-sweeping devices, for use within coastal waters.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_COASTAL_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, coastal, training",
			"MSCT",
			"Non-magnetic minesweeper between 40-70 metres, used primarily in a training role.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_DRONE = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, drone",
			"MSD",
			"Unmanned remotely controlled or towed vehicle capable of clearing mines.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_FLEET = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, fleet",
			"MSF",
			"Minesweeper in size range 46 metres or more that cannot be regarded as being non-magnetic.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_FLEET_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, fleet, air cushion",
			"MSFJ",
			"Minesweeper in size range 46 metres or more that cannot be regarded as being non-magnetic, with an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_FLEET_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, fleet, hydrofoil",
			"MSFK",
			"Minesweeper in size range 46 metres or more which cannot be regarded as being non-magnetic, fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_INSHORE = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, inshore",
			"MSI",
			"Minesweeper between 20-40 metres. Intended and equipped for inshore minesweeping.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_INSHORE_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, inshore, air cushion",
			"MSIJ",
			"Minesweeper between 20-40 metres. Intended and equipped for inshore minesweeping with an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_LIGHT = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, light",
			"MSL",
			"A small vessel designed to sweep mines.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_OCEAN = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, ocean",
			"MSO",
			"Non-magnetic minesweeper 46 metres or more designed for open ocean operations.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_RIVER = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, river",
			"MSR",
			"Shallow water minesweeper in size range 12.5 - 25 metres which has been armoured to provide protection for crew in close combat situations. In the USN a converted lCM-6 known as MSM.");
	public static final SurfaceVesselTypeCategoryCode MINESWEEPER_SPECIAL_DEVICE = new SurfaceVesselTypeCategoryCode(
			"Minesweeper, special device",
			"MSS",
			"A minesweeper fitted with special to type minesweeping devices.");
	public static final SurfaceVesselTypeCategoryCode MOTOR_YACHT = new SurfaceVesselTypeCategoryCode(
			"Motor yacht",
			"MYAC",
			"Vessel, usually associated with luxury living accommodation, powered by inboard engines.");
	public static final SurfaceVesselTypeCategoryCode NOT_KNOWN = new SurfaceVesselTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final SurfaceVesselTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new SurfaceVesselTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, general",
			"PB",
			"Coastal patrol unit intended for a basically coastal guarding function. Includes any coastal patrol ship under 45 metres which cannot qualify as a PG in armament. May be unarmed.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_FAST = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, fast",
			"PBF",
			"Coastal patrol unit intended for a basically coastal guarding function. Includes any coastal patrol ship under 45 metres which cannot qualify as a PG in armament. May be unarmed and capable of at least 35 knots - 65 km/hr.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, hydrofoil",
			"PBK",
			"Coastal patrol unit intended for a basically coastal guarding function. Includes any coastal patrol ship under 45 metres that cannot qualify as a Patrol ship, gun equipped, general in armament. May be unarmed and fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_OFFSHORE = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, offshore",
			"PBO",
			"Coastal patrol unit in size 45-60 metres designed for use in offshore waters. May or may not be armed with guns.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_RIVER_ROADSTEAD = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, river/roadstead",
			"PBR",
			"Lightly armed unit generally suitable by design only for operations in sheltered waters, such as rivers and roadsteads.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_SUBMARINE_CHASER_ESCORT_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, submarine chaser/escort, general",
			"PC",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_COASTAL_ESCORT = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, coastal escort",
			"PCE",
			"Vessel in size range 55-75 metres designed and fitted primarily for ASW role and coastal duty. NOTE: Improved seakeeping, vice mere large size, distinguishes Patrol craft, coastal escort from Patrol craft, submarine chaser/escort, general, and vessels lacking this should be typed as Patrol craft, submarine chaser/escort, general.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_SUBMARINE_CHASER_FAST = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, submarine chaser fast",
			"PCF",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in the anti submarine warfare role capable of at least 35 knots - 65 km/hr.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_AIR_CUSHION_FAST = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, air cushion, fast",
			"PCFJ",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role capable of at least 35 knots - 65 km/hr and has either an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_HYDROFOIL_FAST = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, hydrofoil, fast",
			"PCFK",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role. It is capable of at least 35 knots and is fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, hydrofoil",
			"PCK",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role and is fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode SUBMARINE_CHASER = new SurfaceVesselTypeCategoryCode(
			"Submarine chaser",
			"PCS",
			"Patrol craft optimised for the ASW role.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, training",
			"PCT",
			"Vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role and used primarily in a training role.");
	public static final SurfaceVesselTypeCategoryCode PATROL_SHIP_GUN_EQUIPPED_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Patrol ship, gun equipped, general",
			"PG",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament.");
	public static final SurfaceVesselTypeCategoryCode PATROL_SHIP_ICEBREAKER = new SurfaceVesselTypeCategoryCode(
			"Patrol ship, icebreaker",
			"PGB",
			"Any ship designed as an icebreaker but employed primarily in a patrol mission. The icebreaking capability is to facilitate the patrol function through ice, rather than to support the movement of other ships.");
	public static final SurfaceVesselTypeCategoryCode PATROL_SHIP_FAST = new SurfaceVesselTypeCategoryCode(
			"Patrol ship, fast",
			"PGF",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament and be capable of at least 35 knots - 65 km/hr.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, guided missile",
			"PGG",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament and is fitted with one or more force guided missile systems.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_GUIDED_MISSILE_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, guided missile, air cushion",
			"PGGJ",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament. It is fitted with one or more force guided missile systems and is either an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_GUIDED_MISSILE_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, guided missile, hydrofoil",
			"PGGK",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament. It is fitted with one or more force guided missile systems and is fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, hydrofoil",
			"PGK",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament and is fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_GUIDED_MISSILE_MOTOR_GUNBOAT = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, guided missile (Motor gunboat)",
			"PGM",
			"Patrol, blockade and surveillance ship in range 45-85 metres overall. Designed to operate in other than open ocean areas. Has special mission of attacking hostile ships. Must have at least 76mm main armament and is fitted with guns and other than force guided missile systems. Also known as motor gunboat.");
	public static final SurfaceVesselTypeCategoryCode PATROL_SHIP_ANTI_SUBMARINE_WARFARE = new SurfaceVesselTypeCategoryCode(
			"Patrol ship, anti-submarine warfare",
			"PGS",
			"ASW (anti-submarine warfare) patrol ship in size range 45 - 85 metres fitted with medium range sonar and ASW weapons.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_HOVERCRAFT = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, hovercraft",
			"PHJ",
			"A high-speed patrol hovercraft that can conduct surveillance screening and special operations and is operated by naval or marine forces.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_HOVERCRAFT_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, hovercraft, guided missile",
			"PHJM",
			"A high-speed patrol hovercraft, which can conduct surveillance screening and special operations and is operated by naval or marine forces and is fitted with other than force guided missile systems.");
	public static final SurfaceVesselTypeCategoryCode PATROL_COMBATANT_HOVERCRAFT_MINE_WARFARE = new SurfaceVesselTypeCategoryCode(
			"Patrol combatant, hovercraft, mine-warfare",
			"PHJS",
			"A high-speed patrol hovercraft which is used primarily in minewarfare.");
	public static final SurfaceVesselTypeCategoryCode PATROL_VESSEL_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Patrol vessel, general",
			"PP",
			"General designator for patrol vessels.");
	public static final SurfaceVesselTypeCategoryCode PATROL_SHIP_OFFSHORE = new SurfaceVesselTypeCategoryCode(
			"Patrol ship, offshore",
			"PSO",
			"Coastal patrol unit in size over 60 metres designed for use in offshore waters. May or may not be armed with guns.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_TORPEDO = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, torpedo",
			"PT",
			"High-speed (35 knots) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes.");
	public static final SurfaceVesselTypeCategoryCode ATTACK_BOAT_GUIDED_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Attack boat, guided missile",
			"PTG",
			"High speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres with torpedoes and with a force guided missile system.");
	public static final SurfaceVesselTypeCategoryCode ATTACK_BOAT_GUIDED_MISSILE_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Attack boat, guided missile, air cushion",
			"PTGJ",
			"High speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes and with a force guided missile system and is of an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode ATTACK_BOAT_GUIDED_MISSILE_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Attack boat, guided missile, hydrofoil",
			"PTGK",
			"High speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes and with force guided missile system and hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode ATTACK_BOAT_GUIDED_MISSILE_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Attack boat, guided missile, training",
			"PTGT",
			"High speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes and with force guided missile system and used primarily in a training role.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_BOAT_AIR_CUSHION = new SurfaceVesselTypeCategoryCode(
			"Torpedo boat, air cushion",
			"PTJ",
			"High-speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes with either an air cushion or surface effect design.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_BOAT_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Torpedo boat, hydrofoil",
			"PTK",
			"High-speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes, fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_BOAT_SMALL = new SurfaceVesselTypeCategoryCode(
			"Torpedo boat, small",
			"PTL",
			"High-speed (35 knots - 65 km/hr) anti-surface ship patrol craft smaller in size range 20 - 30 metres fitted with torpedoes.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_BOAT_SMALL_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Torpedo boat, small, hydrofoil",
			"PTLK",
			"High-speed (35 knots - 65 km/hr) anti-surface ship patrol craft smaller in size range 20 - 30 metres fitted with torpedoes and hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_BOAT_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Torpedo boat, training",
			"PTT",
			"High-speed (35 knots - 65 km/hr) anti-surface ship patrol craft in size range 20 - 30 metres fitted with torpedoes and used primarily in a training role.");
	public static final SurfaceVesselTypeCategoryCode JUNK = new SurfaceVesselTypeCategoryCode(
			"Junk",
			"QJ",
			"Sail/motor powered vessel, usually associated with China, of wooden construction designed with high bow and poop deck area. Usually used for transportation purposes.");
	public static final SurfaceVesselTypeCategoryCode ROW_BOAT = new SurfaceVesselTypeCategoryCode(
			"Row boat",
			"QR",
			"Vessel powered by oars.");
	public static final SurfaceVesselTypeCategoryCode SEAPLANE = new SurfaceVesselTypeCategoryCode(
			"Seaplane",
			"QS",
			"Aircraft designed to take-off/land on water.");
	public static final SurfaceVesselTypeCategoryCode RUNABOUT = new SurfaceVesselTypeCategoryCode(
			"Runabout",
			"RABOUT",
			"Vessel of no specific design used for utility purposes.");
	public static final SurfaceVesselTypeCategoryCode RACING_CRUISER = new SurfaceVesselTypeCategoryCode(
			"Racing cruiser",
			"RCRUSR",
			"Sailing vessel designed specifically for ocean racing. May have auxiliary inboard engines.");
	public static final SurfaceVesselTypeCategoryCode SCHOONER = new SurfaceVesselTypeCategoryCode(
			"Schooner",
			"SCHOON",
			"Sailing vessel of schooner design.");
	public static final SurfaceVesselTypeCategoryCode SLOOP = new SurfaceVesselTypeCategoryCode(
			"Sloop",
			"SLOOP",
			"Sailing vessel of sloop design.");
	public static final SurfaceVesselTypeCategoryCode SPEEDBOAT = new SurfaceVesselTypeCategoryCode(
			"Speedboat",
			"SPDBAT",
			"Small, sleek boat capable of high speeds with or without outboard engines.");
	public static final SurfaceVesselTypeCategoryCode SPECIAL_WARFARE_CRAFT_LIGHT = new SurfaceVesselTypeCategoryCode(
			"Special warfare craft, light",
			"SWCL",
			"A light craft specifically designed for special warfare operations.");
	public static final SurfaceVesselTypeCategoryCode SPECIAL_WARFARE_CRAFT_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Special warfare craft, medium",
			"SWCM",
			"A medium craft specifically designed for special warfare operations.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Hovercraft, general",
			"TJ",
			"A vehicle or craft that can be supported by a cushion of air ejected downwards against a surface close below it, and can in principle travel over any relatively smooth surface (as a body of water, marshland, gently sloping land) while having no significant contact with it.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_TRANSPORT_CARGO = new SurfaceVesselTypeCategoryCode(
			"Hovercraft, transport cargo",
			"TJC",
			"Hovercraft capable of carrying vehicles and cargo. Not fitted to carry passengers.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_FERRY = new SurfaceVesselTypeCategoryCode(
			"Hovercraft, ferry",
			"TJF",
			"Hovercraft fitted to carry passengers and/or vehicles.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_ICE_BREAKER = new SurfaceVesselTypeCategoryCode(
			"Hovercraft ice breaker",
			"TJGB",
			"Hovercraft specially fitted to assist in icebreaking.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_SCIENTIFIC_RESEARCH_SURVEY = new SurfaceVesselTypeCategoryCode(
			"Hovercraft, scientific research/survey",
			"TJGS",
			"Non-military hovercraft specially equipped for research or survey duties.");
	public static final SurfaceVesselTypeCategoryCode HOVERCRAFT_SMALL = new SurfaceVesselTypeCategoryCode(
			"Hovercraft, small",
			"TJL",
			"Non-military hovercraft under ?? Metres.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, general",
			"TM",
			"General designator for non-naval ship designed to transport cargo or passengers.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_DRY_CARGO_BREAK_BULK = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, dry cargo, break bulk",
			"TMA",
			"Non-naval dry cargo carrying ship capable of handling break bulk cargo.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_BULK_CARRIER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, bulk carrier",
			"TMB",
			"Non-naval ship designed to carry dry cargo in bulk form.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_CONTAINER_NON_SELF_SUSTAINED = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, container, non-self-sustained",
			"TMC",
			"Non-naval ship designed to carry cargo in loadable and unloadable containers. Not equipped to handle the containers with own equipment.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_CONTAINER_SELF_SUSTAINED = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, container, self-sustained",
			"TMCS",
			"Non-naval ship designed to carry cargo in loadable and unloadable containers and equipped with its own handling equipment.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_DREDGER = new SurfaceVesselTypeCategoryCode(
			"Merchant, dredger",
			"TMD",
			"Non-naval ship designed to dredge channels in open seas.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_ROLL_ON_ROLL_OFF_RO_RO = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, roll-on, roll-off (ro/ro)",
			"TME",
			"Non-naval ship 40 metres or more, having capability for roll-on/roll-off cargo.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_CAR_PASSENGER_FERRY = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, car/passenger ferry",
			"TMF",
			"Non-naval ship or craft designed to run a ferry service of both cars and passengers.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_RAILROAD_CAR_FERRY = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, railroad car ferry",
			"TMFR",
			"Non-naval ship or craft designed to ferry railroad cars.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_ICEBREAKER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, icebreaker",
			"TMGB",
			"Non-naval ship used primarily for icebreaking.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_SCIENTIFIC_RESEARCH_SURVEY = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, scientific research/survey",
			"TMGS",
			"Non-naval ship employed to conduct scientific research.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_HEAVY_LIFT = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, heavy lift",
			"TMH",
			"Non-naval ship fitted with heavy duty crane or derrick for heavy lift.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_INLAND_WATERWAY = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, inland waterway",
			"TMI",
			"Non-naval ship primarily used to transport cargo via inland waterways.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_CABLE_LAYER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, cable layer",
			"TMK",
			"Non-naval ship designed to lay and/or retrieve cables.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_LASH = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, lash",
			"TML",
			"Non-naval ship equipped with gantry crane, capable of embarking and disembarking pre-loaded standard sized barge (lash lighters).");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_SEABEE = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, seabee",
			"TMLS",
			"Non-naval barge carrying ship with a stern elevator, capable of embarking and disembarking barges of non-standard size.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_METEOROLOGICAL = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, meteorological",
			"TMM",
			"Non-naval ship designed primarily to monitor meteorological conditions.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_TANKER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, tanker",
			"TMO",
			"Non-naval ship designed to transport liquids (or gases).");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_REPLENISHMENT_OILER_SMALL = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, replenishment oiler small",
			"TMOL",
			"Non-naval ship able to provide replenishment to ships at sea of POL and solid store products. Less than 120 metres in size.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_REPLENISHMENT_OILER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, replenishment oiler",
			"TMOR",
			"Non-naval ship able to provide replenishment to ships at sea of POL and solid store products. Over 120 metres in size.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_SPECIAL_LIQUIDS = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, special liquids",
			"TMOS",
			"Non-naval ship 40 metres or more designed to transport a special kind of propellant or other non-nuclear associated liquid cargo.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_LIQUID_GAS = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, liquid gas",
			"TMOT",
			"Non-naval ship designed to transport liquid gas.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_PASSENGER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, passenger",
			"TMP",
			"Non-naval ship designed primarily to transport passengers.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_REFRIGERATED = new SurfaceVesselTypeCategoryCode(
			"Merchant, refrigerated",
			"TMR",
			"Non-naval ship designed primarily to transport cargo in refrigerated spaces.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_SPACE_MISSILE_ASSOCIATED = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, space/missile associated",
			"TMS",
			"Non-naval ship designed or converted primarily to support space and missile programmes.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_TUG_OCEAN_GOING = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, tug, ocean-going",
			"TMT",
			"Non-naval sea-going tug with horsepower of 1000 or more, length usually over 60 metres.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_TUG_OCEAN_GOING_RESCUE = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, tug, ocean-going rescue",
			"TMTR",
			"Non-naval sea-going tug with horsepower of 1000 or more, length usually over 60 metres and extensively equipped for fire fighting and rescue operations.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_TUG_OCEAN_GOING_SALVAGE = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, tug, ocean-going salvage",
			"TMTS",
			"Non-naval sea-going tug that can provide towing, salvage, repair, diving and rescue services to ships and craft.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_WATER_TENDER = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, water tender",
			"TMWT",
			"Non-naval ship designed primarily for transporting potable water.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_DISTILLING = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, distilling",
			"TMWW",
			"Non-naval ship capable of distilling and transporting potable water.");
	public static final SurfaceVesselTypeCategoryCode MERCHANT_SHIP_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Merchant ship, training",
			"TMX",
			"Non-naval ship used primarily for training purposes.");
	public static final SurfaceVesselTypeCategoryCode TRIMARAN = new SurfaceVesselTypeCategoryCode(
			"Trimaran",
			"TRIHUL",
			"Sail or engine powered vessel with three hulls.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, general",
			"TU",
			"Fishing vessel over 30 metres.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_BASE_SHIP = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, base ship",
			"TUB",
			"Fishing vessel support ship (other than supplying fuel/water only).");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_WHALE_CATCHER = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, whale catcher",
			"TUC",
			"Fishing vessel equipped to engage in whale hunting.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_FACTORY_SHIP = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, factory ship",
			"TUF",
			"Fishing vessel equipped to prepare fish or other seafood into commercial products.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_INSPECTION = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, inspection",
			"TUI",
			"Any ship other than naval used for inspection of fishing vessels.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_REFRIGERATED = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, refrigerated",
			"TUR",
			"Fishing vessel equipped with refrigerated holds.");
	public static final SurfaceVesselTypeCategoryCode FISHERIES_RESEARCH_SHIP = new SurfaceVesselTypeCategoryCode(
			"Fisheries research ship",
			"TUS",
			"Vessel equipped to conduct fisheries research.");
	public static final SurfaceVesselTypeCategoryCode FISHING_VESSEL_TRAINING = new SurfaceVesselTypeCategoryCode(
			"Fishing vessel, training",
			"TUT",
			"Vessel used to train personnel in fisheries techniques.");
	public static final SurfaceVesselTypeCategoryCode WHALE_FACTORY_SHIP = new SurfaceVesselTypeCategoryCode(
			"Whale factory ship",
			"TUW",
			"Vessel equipped to prepare whales into commercial products.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_POLICE = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, police",
			"VPB",
			"Police operated coastal patrol unit intended for a basically coastal guarding function. Includes any coastal patrol ship under 45 metres that cannot qualify as a Patrol ship, gun equipped, general in armament. May be unarmed.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_POLICE = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, police",
			"VPC",
			"Police operated vessel in size range 35-55 metres designed and fitted primarily for escort duties in ASW role.");
	public static final SurfaceVesselTypeCategoryCode ARMED_POLICE_GUNBOAT = new SurfaceVesselTypeCategoryCode(
			"Armed police gunboat",
			"VPG",
			"Armed vessel operated by police. Size may vary.");
	public static final SurfaceVesselTypeCategoryCode POLICE_DIVING_TENDER = new SurfaceVesselTypeCategoryCode(
			"Police diving tender",
			"VYDT",
			"Police operated craft usually 40 metres or less equipped to provide support for divers.");
	public static final SurfaceVesselTypeCategoryCode POLICE_LAUNCH = new SurfaceVesselTypeCategoryCode(
			"Police launch",
			"VYFL",
			"Police operated small craft less than 20 metres employed in sheltered waters for transporting personnel.");
	public static final SurfaceVesselTypeCategoryCode DESTROYER_COAST_GUARD = new SurfaceVesselTypeCategoryCode(
			"Destroyer, coast guard",
			"WDD",
			"A coast guard destroyer type ship. Major surface combatant in range of about 95 to 140 metres whole general mission is to conduct operations with strike, ASW and amphibious forces, and to perform screening and convoy duties. May have helicopters not especially fitted for ASW.");
	public static final SurfaceVesselTypeCategoryCode FRIGATE_COAST_GUARD = new SurfaceVesselTypeCategoryCode(
			"Frigate, coast guard",
			"WFF",
			"A coast guard frigate. A surface combatant in size range of about 75-150 metres. Fitted primarily to fulfil an ASW role. Generally has lighter surface armament than a Destroyer, general.");
	public static final SurfaceVesselTypeCategoryCode CORVETTE_COAST_GUARD = new SurfaceVesselTypeCategoryCode(
			"Corvette, coast guard",
			"WFFL",
			"General designator for frigate. A coast guard surface combatant in size range of about 75-150 metres, fitted primarily to fulfil an ASW role.");
	public static final SurfaceVesselTypeCategoryCode SEAPLANE_COAST_GUARD = new SurfaceVesselTypeCategoryCode(
			"Seaplane, coast guard",
			"WQS",
			"Coast guard aircraft capable of operating from water.");
	public static final SurfaceVesselTypeCategoryCode YACHT = new SurfaceVesselTypeCategoryCode(
			"Yacht",
			"YAC",
			"Vessel with one or more sails as primary source of power.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_MISCELLANEOUS = new SurfaceVesselTypeCategoryCode(
			"Service craft, miscellaneous",
			"YAG",
			"Craft, usually under 40 metres overall employed in general or multi-purpose functions of support, training, R&D or test in nature.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_EXPERIMENTAL = new SurfaceVesselTypeCategoryCode(
			"Service craft, experimental",
			"YAGE",
			"Craft, usually under 40 metres overall employed in general or multi-purpose functions of support, training, R&D or test in nature and used for experimental purposes.");
	public static final SurfaceVesselTypeCategoryCode EXPERIMENTAL_WEAPON_TESTING_BARGE = new SurfaceVesselTypeCategoryCode(
			"Experimental weapon testing barge",
			"YAGEN",
			"Barge used for experimental weapon testing.");
	public static final SurfaceVesselTypeCategoryCode COMMAND_CRAFT_MISCELLANEOUS = new SurfaceVesselTypeCategoryCode(
			"Command craft, miscellaneous",
			"YAGF",
			"Craft 40 metres or less employed as a command ship but not designed for use at sea.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_SURFACE_EFFECT_EXPERIMENTAL = new SurfaceVesselTypeCategoryCode(
			"Service craft, surface effect, experimental",
			"YAGK",
			"Craft, usually under 40 metres overall employed in general or multi-purpose functions of support, training, R&D or test in nature. It is used for experimental purposes with a surface effect design.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_TARGET = new SurfaceVesselTypeCategoryCode(
			"Service craft, target",
			"YAGT",
			"Craft 45 metres or less employed as a target in support of gunnery or missile firing training.");
	public static final SurfaceVesselTypeCategoryCode SUPPORT_BARGE_MISSILE = new SurfaceVesselTypeCategoryCode(
			"Support barge, missile",
			"YAM",
			"Any self-propelled craft specially fitted and employed primarily in support of missile R&D, missile testing, associated training and/or space flights in coastal waters, but not at sea.");
	public static final SurfaceVesselTypeCategoryCode YAWL = new SurfaceVesselTypeCategoryCode(
			"Yawl",
			"YAWL",
			"Sailing vessel of yawl design.");
	public static final SurfaceVesselTypeCategoryCode BARGE_NON_SELF_PROPELLED = new SurfaceVesselTypeCategoryCode(
			"Barge, non-self propelled",
			"YB",
			"A vessel that has no power of its own and must be towed.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_OPEN = new SurfaceVesselTypeCategoryCode(
			"Lighter, open",
			"YC",
			"Barge-like vessel used in loading and unloading ships or in transporting loads for short distances.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_OPEN_CARGO = new SurfaceVesselTypeCategoryCode(
			"Lighter, open, cargo",
			"YCK",
			"Barge-like vessel used in loading and unloading ships or in transporting loads for short distances, but open and used for transporting cargo.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_AIRCRAFT_TRANSPORT = new SurfaceVesselTypeCategoryCode(
			"Lighter, aircraft transport",
			"YCV",
			"Barge-like vessel used in loading and unloading ships or in transporting loads for short distances, optimised for transporting aircraft.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_CRANE = new SurfaceVesselTypeCategoryCode(
			"Floating crane",
			"YD",
			"Barge-like vessels usually non-self-propelled equipped with a crane.");
	public static final SurfaceVesselTypeCategoryCode DEGAUSSING_VESSEL = new SurfaceVesselTypeCategoryCode(
			"Degaussing vessel",
			"YDG",
			"Vessel of any size used for degaussing purposes.");
	public static final SurfaceVesselTypeCategoryCode DIVING_TENDER = new SurfaceVesselTypeCategoryCode(
			"Diving tender",
			"YDT",
			"Craft usually 40 metres or less equipped to provide support for divers.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_AMMUNITION = new SurfaceVesselTypeCategoryCode(
			"Lighter, ammunition",
			"YE",
			"Craft 40 metres or less used for transporting ammunition.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_COVERED_FERRY = new SurfaceVesselTypeCategoryCode(
			"Lighter, covered, ferry",
			"YF",
			"Self-propelled transport craft under 40 metres.");
	public static final SurfaceVesselTypeCategoryCode FERRY_BOAT = new SurfaceVesselTypeCategoryCode(
			"Ferry boat",
			"YFB",
			"Boat or craft designed to provide ferry service in coastal and protected waters.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_COVERED_DRY_DOCK_COMPANION = new SurfaceVesselTypeCategoryCode(
			"Lighter, covered, dry dock companion",
			"YFC",
			"Craft used to support the operations of a dry dock other than workshops.");
	public static final SurfaceVesselTypeCategoryCode YARD_FLOATING_DRYDOCK = new SurfaceVesselTypeCategoryCode(
			"Yard floating drydock",
			"YFD",
			"General designator for floating dry docks.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_OPEN_LARGE = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, open, large",
			"YFDB",
			"Non-self-propelled open-ended dry dock 200 metres or more.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_OPEN_SMALL = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, open, small",
			"YFDL",
			"Non-self-propelled open-ended dry dock less than 60 metres.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_OPEN_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, open, medium",
			"YFDM",
			"Non-self-propelled open ended dry dock between 60-200 metres.");
	public static final SurfaceVesselTypeCategoryCode LAUNCH = new SurfaceVesselTypeCategoryCode(
			"Launch",
			"YFL",
			"Small craft less than 20 metres employed in sheltered waters for transporting personnel.");
	public static final SurfaceVesselTypeCategoryCode LAUNCH_COVERED_LARGE = new SurfaceVesselTypeCategoryCode(
			"Launch, covered, large",
			"YFLB",
			"Small craft over 20 metres employed in sheltered waters for transporting personnel.");
	public static final SurfaceVesselTypeCategoryCode LAUNCH_HYDROFOIL = new SurfaceVesselTypeCategoryCode(
			"Launch, hydrofoil",
			"YFLK",
			"Small craft less than 20 metres employed in sheltered waters for transporting personnel, but fitted with hydrofoils.");
	public static final SurfaceVesselTypeCategoryCode LAUNCH_COVERED = new SurfaceVesselTypeCategoryCode(
			"Launch, covered",
			"YFLN",
			"Small craft less than 20 metres employed in sheltered waters for transporting personnel but with covered areas.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_COMPANION_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Dry dock companion craft",
			"YFND",
			"Craft used to support the operations of a dry dock.");
	public static final SurfaceVesselTypeCategoryCode BARGE_SPECIAL_PURPOSE_NON_SELF_PROPELLED = new SurfaceVesselTypeCategoryCode(
			"Barge, special purpose, non-self propelled",
			"YFNX",
			"Barge used for various designated special purposes.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_POWER_BARGE = new SurfaceVesselTypeCategoryCode(
			"Floating power barge",
			"YFP",
			"Craft capable of providing auxiliary power.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_COVERED_REFRIGERATED = new SurfaceVesselTypeCategoryCode(
			"Lighter, covered, refrigerated",
			"YFR",
			"Refrigerated cargo transport craft 40 metres or less.");
	public static final SurfaceVesselTypeCategoryCode RANGE_TENDER = new SurfaceVesselTypeCategoryCode(
			"Range tender",
			"YFRT",
			"Craft used for safety and utility purposes on ranges.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER_TORPEDO_TRANSPORT = new SurfaceVesselTypeCategoryCode(
			"Lighter, torpedo transport",
			"YFT",
			"Self-propelled craft 40 metres or less employed for transporting torpedoes.");
	public static final SurfaceVesselTypeCategoryCode HARBOUR_UTILITY_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Harbour utility craft",
			"YFU",
			"Former landing craft, utility in size range 25-55 metres and full load of 120-500 tons with landing ramp/other landing facilities employed for general cargo transport purposes.");
	public static final SurfaceVesselTypeCategoryCode BARGE_GARBAGE = new SurfaceVesselTypeCategoryCode(
			"Barge, garbage",
			"YGG",
			"Self-propelled craft used for the collection of garbage.");
	public static final SurfaceVesselTypeCategoryCode SURVEY_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Survey craft",
			"YGS",
			"Small craft used for survey purposes in sheltered waters.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_TARGET = new SurfaceVesselTypeCategoryCode(
			"Floating target",
			"YGT",
			"Craft built to simulate a target.");
	public static final SurfaceVesselTypeCategoryCode BARGE_TARGET = new SurfaceVesselTypeCategoryCode(
			"Barge, target",
			"YGTN",
			"Self-propelled craft used to simulate a target.");
	public static final SurfaceVesselTypeCategoryCode AMBULANCE_BOAT = new SurfaceVesselTypeCategoryCode(
			"Ambulance boat",
			"YH",
			"Craft 40 metres or less employed to transport sick/wounded and/or medical personnel.");
	public static final SurfaceVesselTypeCategoryCode BARGE_HEATING = new SurfaceVesselTypeCategoryCode(
			"Barge, heating",
			"YHT",
			"Craft of any size used to provide heat to moored ships or ship facilities.");
	public static final SurfaceVesselTypeCategoryCode LIGHTER = new SurfaceVesselTypeCategoryCode(
			"Lighter",
			"YL",
			"General designator for lighters.");
	public static final SurfaceVesselTypeCategoryCode SALVAGE_LIFT_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Salvage lift craft",
			"YLC",
			"Craft of 40 metres or less employed to raise sunken ships. Lift capacity about 60 tons.");
	public static final SurfaceVesselTypeCategoryCode BARGE_GARBAGE_2 = new SurfaceVesselTypeCategoryCode(
			"Barge, garbage 2",
			"YLG",
			"Craft, probably self-propelled, used for collecting garbage from ships.");
	public static final SurfaceVesselTypeCategoryCode WARPING_TUG = new SurfaceVesselTypeCategoryCode(
			"Warping tug",
			"YLWT",
			"Tug used for warping ships in berths.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_DREDGER = new SurfaceVesselTypeCategoryCode(
			"Floating dredger",
			"YM",
			"Craft employed as a dredge.");
	public static final SurfaceVesselTypeCategoryCode DREDGER_NON_SELF_PROPELLED = new SurfaceVesselTypeCategoryCode(
			"Dredger, non self-propelled",
			"YMN",
			"Craft employed as a dredge. It is not self-propelled.");
	public static final SurfaceVesselTypeCategoryCode NET_CARGO_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Net cargo craft",
			"YNC",
			"Craft 40 metres or less used to store and transport harbour defence craft.");
	public static final SurfaceVesselTypeCategoryCode GATE_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Gate craft",
			"YNG",
			"Craft used for control or maintenance of harbour defence equipment.");
	public static final SurfaceVesselTypeCategoryCode NET_TENDER_BOOM = new SurfaceVesselTypeCategoryCode(
			"Net tender, boom",
			"YNT",
			"Craft 40 metres or less used to maintain nets, booms and other harbour defence equipment. May/may not be able to lay and recover same.");
	public static final SurfaceVesselTypeCategoryCode BARGE_FUEL_OIL = new SurfaceVesselTypeCategoryCode(
			"Barge, fuel oil",
			"YO",
			"Craft of any design 60 metres or less used to store and transport POL products.");
	public static final SurfaceVesselTypeCategoryCode BARGE_GASOLINE = new SurfaceVesselTypeCategoryCode(
			"Barge, gasoline",
			"YOG",
			"Craft 60 metres or less used to store and transport clean petroleum products.");
	public static final SurfaceVesselTypeCategoryCode BARGE_SPECIAL_LIQUID = new SurfaceVesselTypeCategoryCode(
			"Barge, special liquid",
			"YOM",
			"Craft 60 metres or less designed to transport fluids other than POL products or water in harbour areas.");
	public static final SurfaceVesselTypeCategoryCode OIL_RECOVERY_VESSEL = new SurfaceVesselTypeCategoryCode(
			"Oil recovery vessel",
			"YOR",
			"A vessel specifically designed for pollution control/oil recovery operations.");
	public static final SurfaceVesselTypeCategoryCode BARGE_OIL_STORAGE = new SurfaceVesselTypeCategoryCode(
			"Barge, oil storage",
			"YOS",
			"POL (petroleum oil and lubricant) storage barge that cannot be towed around the harbour.");
	public static final SurfaceVesselTypeCategoryCode BARGE_DISPOSAL_NUCLEAR_WASTE = new SurfaceVesselTypeCategoryCode(
			"Barge, disposal, nuclear waste",
			"YOSR",
			"Barge specifically designed for the disposal of nuclear waste.");
	public static final SurfaceVesselTypeCategoryCode BARGE_OIL_STORAGE_SUBMERSIBLE = new SurfaceVesselTypeCategoryCode(
			"Barge, oil storage, submersible",
			"YOSS",
			"POL (Petroleum oil and lubricants) storage barge that cannot be towed around the harbour but does sink below the water surface when filled.");
	public static final SurfaceVesselTypeCategoryCode PATROL_CRAFT_HARBOR = new SurfaceVesselTypeCategoryCode(
			"Patrol craft, harbor",
			"YP",
			"Craft used primarily for training personnel for service aboard patrol types. However, may be armed and used as a Patrol boat, general.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_BARRACKS = new SurfaceVesselTypeCategoryCode(
			"Floating barracks",
			"YPB",
			"Craft used as accommodation for vessels crews.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_PILE_DRIVER = new SurfaceVesselTypeCategoryCode(
			"Floating pile driver",
			"YPD",
			"Craft used as a pile driver.");
	public static final SurfaceVesselTypeCategoryCode BARGE_PONTOON_STORAGE = new SurfaceVesselTypeCategoryCode(
			"Barge, pontoon storage",
			"YPK",
			"Craft used to stow pontoons.");
	public static final SurfaceVesselTypeCategoryCode TORPEDO_RETRIEVER_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Torpedo retriever craft",
			"YPT",
			"Craft used primarily to retrieve spent torpedoes during exercises. However may be armed and used as a harbour patrol craft as an auxiliary duty.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_WORKSHOP_REPAIR = new SurfaceVesselTypeCategoryCode(
			"Floating workshop, repair",
			"YR",
			"Craft about 30 metres fitted out as a general or special purpose mobile workshop.");
	public static final SurfaceVesselTypeCategoryCode BARGE_REPAIR_AND_BERTHING = new SurfaceVesselTypeCategoryCode(
			"Barge, repair and berthing",
			"YRB",
			"Craft which both serves as a floating work ship and has berthing facilities for the assigned personnel. May/may not provide messing facilities as well.");
	public static final SurfaceVesselTypeCategoryCode BARGE_REPAIR_BERTHING_AND_MESSING = new SurfaceVesselTypeCategoryCode(
			"Barge, repair, berthing and messing",
			"YRBM",
			"Craft which both serves as a floating work ship and has berthing facilities for the assigned personnel. It provides messing facilities.");
	public static final SurfaceVesselTypeCategoryCode CABLE_TENDER_YARD_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Cable tender yard craft",
			"YRC",
			"Craft under 30 metres used to lay, retrieve and maintain submarine cables.");
	public static final SurfaceVesselTypeCategoryCode BARGE_CABLE = new SurfaceVesselTypeCategoryCode(
			"Barge, cable",
			"YRCN",
			"Craft used to carry cables for laying.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_WORKSHOP = new SurfaceVesselTypeCategoryCode(
			"Dry dock, floating, workshop",
			"YRD",
			"Non-self- propelled dry dock with workshop facilities.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_CLOSED_LARGE = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, closed, large",
			"YRDB",
			"Non-self-propelled dry dock, closed bow and stern over 200 metres.");
	public static final SurfaceVesselTypeCategoryCode FLOATING_DRY_DOCK_WORKSHOP_HULL = new SurfaceVesselTypeCategoryCode(
			"Floating dry dock workshop (hull)",
			"YRDH",
			"Non-self- propelled dry dock with workshop facilities optimised for hull repairs.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_CLOSED_SMALL = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, closed, small",
			"YRDL",
			"Non-self-propelled dry dock, closed bow and stern under 60 metres.");
	public static final SurfaceVesselTypeCategoryCode DRY_DOCK_FLOATING_CLOSED_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Dry dock floating, closed, medium",
			"YRDM",
			"Non-self-propelled dry dock, closed bow and stern between 60-200 metres.");
	public static final SurfaceVesselTypeCategoryCode TANK_CLEANING_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Tank cleaning craft",
			"YRG",
			"Craft equipped for steam cleaning liquid storage tanks or ships.");
	public static final SurfaceVesselTypeCategoryCode BARGE_NUCLEAR_SHIP_SUPPORT = new SurfaceVesselTypeCategoryCode(
			"Barge, nuclear ship support",
			"YRNS",
			"Craft used to transport radioactive materials.");
	public static final SurfaceVesselTypeCategoryCode BARGE_RADIOLOGICAL_REPAIR = new SurfaceVesselTypeCategoryCode(
			"Barge, radiological repair",
			"YRR",
			"Barge used to repair and/or service radioactive equipment.");
	public static final SurfaceVesselTypeCategoryCode REPAIR_BARGE_NUCLEAR_PROPULSION = new SurfaceVesselTypeCategoryCode(
			"Repair barge, nuclear propulsion",
			"YRRN",
			"Barge optimised to repair nuclear propulsion plants.");
	public static final SurfaceVesselTypeCategoryCode BARGE_SALVAGE = new SurfaceVesselTypeCategoryCode(
			"Barge, salvage",
			"YRST",
			"Any utility barge used for salvage.");
	public static final SurfaceVesselTypeCategoryCode BARGE_SELF_PROPELLED = new SurfaceVesselTypeCategoryCode(
			"Barge, self-propelled",
			"YS",
			"General designator for self-propelled barges.");
	public static final SurfaceVesselTypeCategoryCode TUG_HARBOUR = new SurfaceVesselTypeCategoryCode(
			"Tug, harbour",
			"YT",
			"General designator for craft capable of towing naval ships in sheltered or protected seas.");
	public static final SurfaceVesselTypeCategoryCode TUG_HARBOUR_LARGE = new SurfaceVesselTypeCategoryCode(
			"Tug, harbour, large",
			"YTB",
			"Coastal/harbour tug between 30-40 metres with total horsepower of 1300 or more.");
	public static final SurfaceVesselTypeCategoryCode DIVING_TENDER_2 = new SurfaceVesselTypeCategoryCode(
			"Diving tender 2",
			"YTD",
			"Small craft optimised to act as tender for diving operations.");
	public static final SurfaceVesselTypeCategoryCode TUG_HARBOUR_SMALL = new SurfaceVesselTypeCategoryCode(
			"Tug, harbour, small",
			"YTL",
			"Harbour tug under 20 metres with total horsepower under 500.");
	public static final SurfaceVesselTypeCategoryCode TUG_HARBOUR_MEDIUM = new SurfaceVesselTypeCategoryCode(
			"Tug, harbour, medium",
			"YTM",
			"Harbour tug between 20-40 metres with total horsepower between 500 and 1300.");
	public static final SurfaceVesselTypeCategoryCode FIRE_RESCUE_BOAT_SMALL = new SurfaceVesselTypeCategoryCode(
			"Fire/rescue boat, small",
			"YTR",
			"Harbour craft extensively equipped for firefighting. For this type that capability is more important than horsepower alone. Must have several fire monitors.");
	public static final SurfaceVesselTypeCategoryCode TRAINING_CRAFT_SAIL = new SurfaceVesselTypeCategoryCode(
			"Training craft, sail",
			"YTS",
			"Sailing craft of any size used for training.");
	public static final SurfaceVesselTypeCategoryCode CRAFT_TORPEDO_TRIALS = new SurfaceVesselTypeCategoryCode(
			"Craft, torpedo trials",
			"YTT",
			"Craft used at sea for torpedo trials.");
	public static final SurfaceVesselTypeCategoryCode DRONE_AIRCRAFT_CATAPULT_CONTROL_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Drone aircraft, catapult control craft",
			"YV",
			"Craft equipped with catapult for the launching of drone aircraft and after launch capable of serving as the control craft for the drone.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_SEAPLANE = new SurfaceVesselTypeCategoryCode(
			"Service craft, seaplane",
			"YVS",
			"Craft used to rescue, tow, service or support seaplanes.");
	public static final SurfaceVesselTypeCategoryCode BARGE_WATER = new SurfaceVesselTypeCategoryCode(
			"Barge, water",
			"YW",
			"Craft used to transport and store potable water.");
	public static final SurfaceVesselTypeCategoryCode HULK_OR_RELIC = new SurfaceVesselTypeCategoryCode(
			"Hulk or relic",
			"YXR",
			"Any unused/historic ship.");
	public static final SurfaceVesselTypeCategoryCode TRAINING_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Training craft",
			"YXT",
			"General designator for any craft used for training purposes.");
	public static final SurfaceVesselTypeCategoryCode SERVICE_CRAFT_YARD_GENERAL = new SurfaceVesselTypeCategoryCode(
			"Service craft, yard, general",
			"YY",
			"General designator for yard service craft.");
	public static final SurfaceVesselTypeCategoryCode PATROL_BOAT_CUSTOMS = new SurfaceVesselTypeCategoryCode(
			"Patrol boat, customs",
			"ZPB",
			"Customs operated coastal patrol unit intended for a basically coastal guarding function. Includes any coastal patrol ship under 45 metres which cannot qualify as a PG in armament. May be unarmed.");
	public static final SurfaceVesselTypeCategoryCode FISHERIES_PATROL_CRAFT = new SurfaceVesselTypeCategoryCode(
			"Fisheries patrol craft",
			"ZPC",
			"Fisheries service operated vessel (fisheries patrol craft) in size range 35-55 metres designed and fitted primarily for escort duties in ASW role.");
	public static final SurfaceVesselTypeCategoryCode ARMED_CUSTOMS_GUNBOAT = new SurfaceVesselTypeCategoryCode(
			"Armed customs gunboat",
			"ZPG",
			"Armed vessel operated by customs. Size may vary.");
	public static final SurfaceVesselTypeCategoryCode CUSTOMS_LAUNCH = new SurfaceVesselTypeCategoryCode(
			"Customs launch",
			"ZYFL",
			"Customs operated small craft less than 20 metres employed in sheltered waters for transporting personnel.");
	public static final SurfaceVesselTypeCategoryCode FIRE_TUG = new SurfaceVesselTypeCategoryCode(
			"Fire tug",
			"ZYTB",
			"Coastal/harbour tug operated by customs fire service, between 30-40 metres with total horsepower of 1300 or more.");
	public static final SurfaceVesselTypeCategoryCode FIRE_SERVICE_RESCUE_TENDER = new SurfaceVesselTypeCategoryCode(
			"Fire service rescue tender",
			"ZYTR",
			"Harbour craft operated by customs fire service extensively equipped for firefighting. For this type that capability is more important than horsepower alone. Must have several fire monitors.");

	private SurfaceVesselTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
