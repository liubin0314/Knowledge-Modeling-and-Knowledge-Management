/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionElectronicWarfareEmploymentCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents an electronic or mechanical technique.";
	}

	private static HashMap<String, ActionElectronicWarfareEmploymentCategoryCode> physicalToCode = new HashMap<String, ActionElectronicWarfareEmploymentCategoryCode>();

	public static ActionElectronicWarfareEmploymentCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionElectronicWarfareEmploymentCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionElectronicWarfareEmploymentCategoryCode ACOUSTIC_SIMULATION_OF_SURFACE_AND_SUBSURFACE_FORCES = new ActionElectronicWarfareEmploymentCategoryCode(
			"Acoustic simulation of surface and subsurface forces",
			"ACOUST",
			"Imitating or controlling the signature of a ship to mislead or deceive the enemy.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CHAFF_BLANKET = new ActionElectronicWarfareEmploymentCategoryCode(
			"Chaff, blanket",
			"CHAFBL",
			"Employed to offset unfriendly radar detection capability by dispensing a blanket of chaff over a designated area.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CHAFF_BURST = new ActionElectronicWarfareEmploymentCategoryCode(
			"Chaff, burst",
			"CHAFBU",
			"Chaff drops at intervals short enough to appear on radar displays as an individual target.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CHAFF_CORRIDOR = new ActionElectronicWarfareEmploymentCategoryCode(
			"Chaff, corridor",
			"CHAFCO",
			"To offset unfriendly radar detection capability by dispensing a heavy continuous trail of chaff from an aircraft in a corridor fashion as it approaches the radar.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CHAFF_SELF_PROTECTION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Chaff, self-protection",
			"CHAFSE",
			"Employed to offset unfriendly radar detection and associated weapons employment by dispensing singular or limited bursts of chaff.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CONCEALMENT_OF_FORCES = new ActionElectronicWarfareEmploymentCategoryCode(
			"Concealment of forces",
			"CONCEL",
			"Can be accomplished by using sounds to mask unavoidable operational noises.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CONTROLLED_BREACHES_OF_COMMUNICATION_SECURITY = new ActionElectronicWarfareEmploymentCategoryCode(
			"Controlled breaches of communication security",
			"CONTRL",
			"The deliberate act of conveying through friendly communications false or misleading information to support an overall cover and deception plan.");
	public static final ActionElectronicWarfareEmploymentCategoryCode CRYPTOGRAPHIC_INTRUSION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Cryptographic intrusion",
			"CRYPTO",
			"A sophisticated imitative communications deception (ICD) technique whereby SIGINT personnel gain access to the enemy�s communication system and introduce bogus messages enciphered in the enemy�s own crypto system.");
	public static final ActionElectronicWarfareEmploymentCategoryCode DECEIVE_FALSE_ACTIVITY = new ActionElectronicWarfareEmploymentCategoryCode(
			"Deceive, false activity",
			"DCFLAC",
			"The increase or decrease of friendly activity.");
	public static final ActionElectronicWarfareEmploymentCategoryCode DECEIVE_FALSE_PEAKS = new ActionElectronicWarfareEmploymentCategoryCode(
			"Deceive, false peaks",
			"DCFLPK",
			"This technique is the reverse of false traffic levels and serves the purpose of simulating unusual activity on a communication net.");
	public static final ActionElectronicWarfareEmploymentCategoryCode DECEIVE_FALSE_TARGET_GENERATION_OR_SPOOFING = new ActionElectronicWarfareEmploymentCategoryCode(
			"Deceive, false target generation or spoofing",
			"DCFLTA",
			"A method of deceiving the enemy by creating false targets.");
	public static final ActionElectronicWarfareEmploymentCategoryCode DECEIVE_FALSE_TRAFFIC_LEVELS = new ActionElectronicWarfareEmploymentCategoryCode(
			"Deceive, false traffic levels",
			"DCFLTR",
			"This technique is applied on a communications net over a period of days to create the impression of normal operations.");
	public static final ActionElectronicWarfareEmploymentCategoryCode DECEIVE_MULTIPLE_FALSE_TARGETS = new ActionElectronicWarfareEmploymentCategoryCode(
			"Deceive, multiple false targets",
			"DCMLFL",
			"Used to generate multiple false targets.");
	public static final ActionElectronicWarfareEmploymentCategoryCode ELECTRONIC_COVER = new ActionElectronicWarfareEmploymentCategoryCode(
			"Electronic cover",
			"ELECCO",
			"The variance of location and usage of emitters in tactical units to alter the stereotype patterns associated with those electromagnetic signatures.");
	public static final ActionElectronicWarfareEmploymentCategoryCode ELECTRONIC_WARFARE_SELF_PROTECTION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Electronic warfare, self-protection",
			"EWSELF",
			"A method of transmitting radiation to prevent enemy detection.");
	public static final ActionElectronicWarfareEmploymentCategoryCode INVERSE_GAIN_MODULATION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Inverse gain modulation",
			"INVGNM",
			"The method of breaking a lock on a conical scan tracking radar by providing false azimuth information.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_BARRAGE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, barrage",
			"JAMBAR",
			"The simultaneous jamming of a number of adjacent channels or frequencies.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_COMMUNICATIONS_NOISE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, communications noise",
			"JAMCOM",
			"The broadcast or rebroadcast of any type of noise or other transmission intended to render the victim communications frequency unusable.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_DECEPTIVE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, deceptive",
			"JAMDEC",
			"A method of transmitting signals which will prevent or reduce the enemy�s use of the communication portion of the electromagnetic spectrum, without his being aware of the source of emissions.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_REPEATER = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, repeater",
			"JAMREP",
			"The intercept of the intended victim signal, which is then altered and retransmitted for the purpose of falsifying or disrupting information flow.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_SPOT = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, spot",
			"JAMSPT",
			"The jamming of a specific channel or frequency.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_SWEEP_LOCK_ON = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, sweep lock-on",
			"JAMSWL",
			"The employment of a sweeping receiver with a jammer that locks on a detected victim signal and performs spot jamming.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_SWEEP = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, sweep",
			"JAMSWP",
			"Used for search for and jam signals automatically over a broad frequency band employing a sweeping technique.");
	public static final ActionElectronicWarfareEmploymentCategoryCode JAM_TRANSPONDER = new ActionElectronicWarfareEmploymentCategoryCode(
			"Jam, transponder",
			"JAMTRS",
			"Automatically transmits a predetermined signal and is programmed to respond to a specific type of victim signal.");
	public static final ActionElectronicWarfareEmploymentCategoryCode NUISANCE_INTRUSION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Nuisance intrusion",
			"NUISNC",
			"An ICD technique whereby SIGINT/EW personnel gain entry into the enemy�s communications net as a bonafide subscriber, to harass and distract the enemy.");
	public static final ActionElectronicWarfareEmploymentCategoryCode PADDING = new ActionElectronicWarfareEmploymentCategoryCode(
			"Padding",
			"PADDNG",
			"This method involves the insertion of dummy code or cipher groups into individual valid encrypted messages.");
	public static final ActionElectronicWarfareEmploymentCategoryCode PILL = new ActionElectronicWarfareEmploymentCategoryCode(
			"Pill",
			"PILL",
			"A device released by a submarine to create false sonar targets by generating clouds of air or gas bubbles.");
	public static final ActionElectronicWarfareEmploymentCategoryCode PLANNED_MESSAGE_INTRUSION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Planned message intrusion",
			"PLNMSG",
			"A technique similar to nuisance intrusion with the intent to introduce valid enemy traffic into the enemy�s communication network.");
	public static final ActionElectronicWarfareEmploymentCategoryCode RANGE_GATE_PULL_OFF = new ActionElectronicWarfareEmploymentCategoryCode(
			"Range gate pull-off",
			"RANGGT",
			"This technique involves stealing the tracking radars timing gate to disrupt the tracking function.");
	public static final ActionElectronicWarfareEmploymentCategoryCode REFLECTOR_CORNER = new ActionElectronicWarfareEmploymentCategoryCode(
			"Reflector, corner",
			"RFLCCR",
			"Consists of flat reflecting surfaces, of various shapes and sizes, connected to form a three-dimensional reflector.");
	public static final ActionElectronicWarfareEmploymentCategoryCode REFLECTOR_GULL = new ActionElectronicWarfareEmploymentCategoryCode(
			"Reflector, gull",
			"RLLCGL",
			"A floating radar reflector used to simulate surface targets.");
	public static final ActionElectronicWarfareEmploymentCategoryCode ROUTING = new ActionElectronicWarfareEmploymentCategoryCode(
			"Routing",
			"ROUTNG",
			"Deceptive method of concealing the routing of traffic by sending to stations other than the intended recipients.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SCAN_RATE_MODULATION = new ActionElectronicWarfareEmploymentCategoryCode(
			"Scan rate modulation",
			"SCANRT",
			"This technique causes the enemy radar antenna to loose lock on target.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SIMULATION_AMPHIBIOUS_WARFARE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Simulation, amphibious warfare",
			"SIMAMP",
			"Simulate sounds or noises that resemble an amphibious operation such as dropping anchors, starting boat engines, etc.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SIMULATION_FORCE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Simulation, force",
			"SIMFRC",
			"This technique can be achieved by projecting selected audio signals or by emitting sounds from specific areas.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SIMULATION_RIVERINE_WARFARE = new ActionElectronicWarfareEmploymentCategoryCode(
			"Simulation, riverine warfare",
			"SIMRIV",
			"Simulate river patrol operations.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SIMULATION_TACTICAL_MOVEMENTS = new ActionElectronicWarfareEmploymentCategoryCode(
			"Simulation, tactical movements",
			"SIMTAC",
			"A combination of sonic deception and surface craft movements during low visibility.");
	public static final ActionElectronicWarfareEmploymentCategoryCode SIMULATION_UNIT = new ActionElectronicWarfareEmploymentCategoryCode(
			"Simulation, unit",
			"SIMUNT",
			"Establishing a network of communications and non-communications emitters to simulate a unit or organisation. The creation of fictitious friendly units with actual or specially designed equipment.");

	private ActionElectronicWarfareEmploymentCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
