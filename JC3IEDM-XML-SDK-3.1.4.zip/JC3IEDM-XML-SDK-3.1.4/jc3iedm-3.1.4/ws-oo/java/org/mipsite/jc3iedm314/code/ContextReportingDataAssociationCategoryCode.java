/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextReportingDataAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relation of a specific CONTEXT with a specific REPORTING-DATA.";
	}

	private static HashMap<String, ContextReportingDataAssociationCategoryCode> physicalToCode = new HashMap<String, ContextReportingDataAssociationCategoryCode>();

	public static ContextReportingDataAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextReportingDataAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextReportingDataAssociationCategoryCode IS_CONFIRMED_BY = new ContextReportingDataAssociationCategoryCode(
			"Is confirmed by",
			"CONF",
			"A relationship between a REPORTING-DATA and a CONTEXT in which the data referenced by REPORTING-DATA affirms the data referenced by CONTEXT.");
	public static final ContextReportingDataAssociationCategoryCode IS_A_CORRECTION_OF = new ContextReportingDataAssociationCategoryCode(
			"Is a correction of",
			"CORR",
			"A relationship between a REPORTING-DATA and a CONTEXT with the purpose of amending the CONTEXT.");
	public static final ContextReportingDataAssociationCategoryCode IMPLIES = new ContextReportingDataAssociationCategoryCode(
			"Implies",
			"IMPL",
			"A relationship between a REPORTING-DATA and a CONTEXT that is the logical consequence of the CONTEXT.");
	public static final ContextReportingDataAssociationCategoryCode IS_DEFINED_TO_BE = new ContextReportingDataAssociationCategoryCode(
			"Is defined to be",
			"ISDFT",
			"A relationship between a REPORTING-DATA and a CONTEXT in which a CONTEXT is recorded as a REPORTING-DATA.");
	public static final ContextReportingDataAssociationCategoryCode IS_NEGATED_BY = new ContextReportingDataAssociationCategoryCode(
			"Is negated by",
			"NEGA",
			"A relationship between a REPORTING-DATA and a CONTEXT, where the information referred to by the REPORTING-DATA is in any way contradictory to the information referred to by the CONTEXT.");
	public static final ContextReportingDataAssociationCategoryCode IS_SUPERSEDED_BY = new ContextReportingDataAssociationCategoryCode(
			"Is superseded by",
			"SUPR",
			"A relationship between a REPORTING-DATA and a CONTEXT, where the information referred to by the REPORTING-DATA replaces the information referred to by the CONTEXT.");

	private ContextReportingDataAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
