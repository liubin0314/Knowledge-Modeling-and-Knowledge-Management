/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusImoCompliantIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a vessel complies with International Maritime Organisation standards.";
	}

	private static HashMap<String, MaterielStatusImoCompliantIndicatorCode> physicalToCode = new HashMap<String, MaterielStatusImoCompliantIndicatorCode>();

	public static MaterielStatusImoCompliantIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusImoCompliantIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusImoCompliantIndicatorCode NO = new MaterielStatusImoCompliantIndicatorCode(
			"No",
			"NO",
			"The specific vessel does not comply with International Maritime Organisation (IMO) standards.");
	public static final MaterielStatusImoCompliantIndicatorCode YES = new MaterielStatusImoCompliantIndicatorCode(
			"Yes",
			"YES",
			"The specific vessel complies with International Maritime Organisation (IMO) standards.");

	private MaterielStatusImoCompliantIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
