/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CloudCoverAverageCoverageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the average density of a specific CLOUD-COVER as fractional coverage.";
	}

	private static HashMap<String, CloudCoverAverageCoverageCode> physicalToCode = new HashMap<String, CloudCoverAverageCoverageCode>();

	public static CloudCoverAverageCoverageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CloudCoverAverageCoverageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CloudCoverAverageCoverageCode _0_8 = new CloudCoverAverageCoverageCode(
			"0/8",
			"0",
			"Clear sky.");
	public static final CloudCoverAverageCoverageCode _1_8 = new CloudCoverAverageCoverageCode(
			"1/8",
			"1",
			"Sky partially obscured 12 � percent.");
	public static final CloudCoverAverageCoverageCode _2_8 = new CloudCoverAverageCoverageCode(
			"2/8",
			"2",
			"Sky partially obscured 25 percent.");
	public static final CloudCoverAverageCoverageCode _3_8 = new CloudCoverAverageCoverageCode(
			"3/8",
			"3",
			"Scattered sky or sky partially obscured 37 � percent.");
	public static final CloudCoverAverageCoverageCode _4_8 = new CloudCoverAverageCoverageCode(
			"4/8",
			"4",
			"Scattered sky or sky partially obscured 50 percent.");
	public static final CloudCoverAverageCoverageCode _5_8 = new CloudCoverAverageCoverageCode(
			"5/8",
			"5",
			"Broken sky or sky partially obscured 62 � percent.");
	public static final CloudCoverAverageCoverageCode _6_8 = new CloudCoverAverageCoverageCode(
			"6/8",
			"6",
			"Broken sky or sky partially obscured 75 percent.");
	public static final CloudCoverAverageCoverageCode _7_8 = new CloudCoverAverageCoverageCode(
			"7/8",
			"7",
			"Sky partially obscured or overcast with breaks.");
	public static final CloudCoverAverageCoverageCode _7_8_8 = new CloudCoverAverageCoverageCode(
			"7-8/8",
			"78",
			"A condition in which an overcast layer has discernible break(s) totalling less than 1 octal.");
	public static final CloudCoverAverageCoverageCode _8_8 = new CloudCoverAverageCoverageCode(
			"8/8",
			"8",
			"Complete overcast.");

	private CloudCoverAverageCoverageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
