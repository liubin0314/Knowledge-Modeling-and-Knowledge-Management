/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RadioactiveEventRelativeDecayRateCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the rate of decay of fallout relative to the assumed normal value of 1.2 in the Kaufmann equation.";
	}

	private static HashMap<String, RadioactiveEventRelativeDecayRateCode> physicalToCode = new HashMap<String, RadioactiveEventRelativeDecayRateCode>();

	public static RadioactiveEventRelativeDecayRateCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RadioactiveEventRelativeDecayRateCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RadioactiveEventRelativeDecayRateCode DECAY_FASTER_THAN_NORMAL = new RadioactiveEventRelativeDecayRateCode(
			"Decay faster than normal",
			"DF",
			"A faster than natural decrease in the radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventRelativeDecayRateCode DECAY_NORMAL = new RadioactiveEventRelativeDecayRateCode(
			"Decay normal",
			"DN",
			"A natural decrease in the radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventRelativeDecayRateCode DECAY_SLOWER_THAN_NORMAL = new RadioactiveEventRelativeDecayRateCode(
			"Decay slower than normal",
			"DS",
			"A slower than natural decrease in the radiation intensity of any radioactive material with respect to time.");

	private RadioactiveEventRelativeDecayRateCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
