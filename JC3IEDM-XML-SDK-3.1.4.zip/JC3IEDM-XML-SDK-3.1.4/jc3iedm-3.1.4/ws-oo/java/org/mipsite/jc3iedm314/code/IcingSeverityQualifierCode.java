/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IcingSeverityQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the severity of a particular ICING.";
	}

	private static HashMap<String, IcingSeverityQualifierCode> physicalToCode = new HashMap<String, IcingSeverityQualifierCode>();

	public static IcingSeverityQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IcingSeverityQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IcingSeverityQualifierCode LIGHT = new IcingSeverityQualifierCode(
			"Light",
			"LIGHT",
			"No definition provided in APP-6A.");
	public static final IcingSeverityQualifierCode MODERATE = new IcingSeverityQualifierCode(
			"Moderate",
			"MODER",
			"No definition provided in APP-6A.");
	public static final IcingSeverityQualifierCode SEVERE = new IcingSeverityQualifierCode(
			"Severe",
			"SEVERE",
			"No definition provided in APP-6A.");

	private IcingSeverityQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
