/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionAircraftEmploymentCrewCompositionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the composition of the crew.";
	}

	private static HashMap<String, ActionAircraftEmploymentCrewCompositionCode> physicalToCode = new HashMap<String, ActionAircraftEmploymentCrewCompositionCode>();

	public static ActionAircraftEmploymentCrewCompositionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionAircraftEmploymentCrewCompositionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionAircraftEmploymentCrewCompositionCode AUGMENTED = new ActionAircraftEmploymentCrewCompositionCode(
			"Augmented",
			"AUGMNT",
			"A military crew with additional members for an extended crew day.");
	public static final ActionAircraftEmploymentCrewCompositionCode BASIC = new ActionAircraftEmploymentCrewCompositionCode(
			"Basic",
			"BASIC",
			"A normal sized military crew for the aircraft type.");
	public static final ActionAircraftEmploymentCrewCompositionCode COMMERCIAL = new ActionAircraftEmploymentCrewCompositionCode(
			"Commercial",
			"COMRCL",
			"A crew that has been contracted from non-military sources.");

	private ActionAircraftEmploymentCrewCompositionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
