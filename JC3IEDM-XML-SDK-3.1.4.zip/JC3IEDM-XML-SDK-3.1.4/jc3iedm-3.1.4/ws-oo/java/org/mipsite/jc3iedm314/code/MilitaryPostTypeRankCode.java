/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryPostTypeRankCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a designation for a military or naval grade that establishes the relative position or status of a specific MILITARY-POST-TYPE.";
	}

	private static HashMap<String, MilitaryPostTypeRankCode> physicalToCode = new HashMap<String, MilitaryPostTypeRankCode>();

	public static MilitaryPostTypeRankCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryPostTypeRankCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryPostTypeRankCode ENLISTED_PRIVATE = new MilitaryPostTypeRankCode(
			"Enlisted private",
			"EPTE",
			"The specification of a MILITARY-POST-TYPE as being appropriate for an individual in the armed forces without an officer's commission, warrant or other rank conferring leadership over other servicemen.");
	public static final MilitaryPostTypeRankCode NCO_NOT_OTHERWISE_SPECIFIED = new MilitaryPostTypeRankCode(
			"NCO, not otherwise specified",
			"NCO",
			"The specification of a MILITARY-POST-TYPE as being appropriate for an enlisted member of the armed forces appointed to a rank conferring leadership over other servicemen.");
	public static final MilitaryPostTypeRankCode NOT_KNOWN = new MilitaryPostTypeRankCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MilitaryPostTypeRankCode OF_1 = new MilitaryPostTypeRankCode(
			"OF-1",
			"OF1",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Lieutenant/Second Lieutenant/Midshipman/Sub-Lieutenant/Pilot Officer/Flying Officer.");
	public static final MilitaryPostTypeRankCode OF_10 = new MilitaryPostTypeRankCode(
			"OF-10",
			"OF10",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Field Marshal/Fleet Admiral/General of the Air Force.");
	public static final MilitaryPostTypeRankCode OF_2 = new MilitaryPostTypeRankCode(
			"OF-2",
			"OF2",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Captain/Lieutenant/Flight Lieutenant.");
	public static final MilitaryPostTypeRankCode OF_3 = new MilitaryPostTypeRankCode(
			"OF-3",
			"OF3",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Major/Lieutenant-Commander/Squadron Leader.");
	public static final MilitaryPostTypeRankCode OF_4 = new MilitaryPostTypeRankCode(
			"OF-4",
			"OF4",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Lieutenant Colonel/Commander/Wing Commander.");
	public static final MilitaryPostTypeRankCode OF_5 = new MilitaryPostTypeRankCode(
			"OF-5",
			"OF5",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Colonel/Captain (under 6 years of seniority)/Group Captain.");
	public static final MilitaryPostTypeRankCode OF_6 = new MilitaryPostTypeRankCode(
			"OF-6",
			"OF6",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Brigadier Captain (over 6 years seniority)/Air Commodore.");
	public static final MilitaryPostTypeRankCode OF_7 = new MilitaryPostTypeRankCode(
			"OF-7",
			"OF7",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Major General/Rear Admiral/Air Vice Marshal.");
	public static final MilitaryPostTypeRankCode OF_8 = new MilitaryPostTypeRankCode(
			"OF-8",
			"OF8",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of Lieutenant General/Vice Admiral/Air Marshall.");
	public static final MilitaryPostTypeRankCode OF_9 = new MilitaryPostTypeRankCode(
			"OF-9",
			"OF9",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the officer rank of General/Admiral/Air Chief Marshal.");
	public static final MilitaryPostTypeRankCode OFFICER_NOT_OTHERWISE_SPECIFIED = new MilitaryPostTypeRankCode(
			"Officer, not otherwise specified",
			"OFFR",
			"The specification of a MILITARY-POST-TYPE as being appropriate for an individual who is invested with authority by means of a commission in the armed forces.");
	public static final MilitaryPostTypeRankCode OR_1 = new MilitaryPostTypeRankCode(
			"OR-1",
			"OR1",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Private (Class 4)/Seaman Recruit/Basic Airman.");
	public static final MilitaryPostTypeRankCode OR_2 = new MilitaryPostTypeRankCode(
			"OR-2",
			"OR2",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Private (Class 1-3)/Seaman Apprentice/Airman.");
	public static final MilitaryPostTypeRankCode OR_3 = new MilitaryPostTypeRankCode(
			"OR-3",
			"OR3",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Lance Corporal/Seaman/Airman First Class.");
	public static final MilitaryPostTypeRankCode OR_4 = new MilitaryPostTypeRankCode(
			"OR-4",
			"OR4",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Corporal/Petty Officer Third Class/Senior Airman/Sergeant.");
	public static final MilitaryPostTypeRankCode OR_5 = new MilitaryPostTypeRankCode(
			"OR-5",
			"OR5",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Sergeant (Junior)/Petty Officer second Class/Staff Sergeant.");
	public static final MilitaryPostTypeRankCode OR_6 = new MilitaryPostTypeRankCode(
			"OR-6",
			"OR6",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Sergeant (3 Years Seniority)/Petty Officer First Class/Technical Sergeant.");
	public static final MilitaryPostTypeRankCode OR_7 = new MilitaryPostTypeRankCode(
			"OR-7",
			"OR7",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Staff Sergeant/Chief Petty Officer First Class/Master Sergeant.");
	public static final MilitaryPostTypeRankCode OR_8 = new MilitaryPostTypeRankCode(
			"OR-8",
			"OR8",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Warrant Officer Class 2/Senior Chief Petty Officer/Senior Master Sergeant.");
	public static final MilitaryPostTypeRankCode OR_9 = new MilitaryPostTypeRankCode(
			"OR-9",
			"OR9",
			"The specification of a MILITARY-POST-TYPE as being appropriate for the rank of Warrant Officer Class 1/Master Chief Petty Officer/Chief Master Sergeant.");
	public static final MilitaryPostTypeRankCode OTHER_RANKS = new MilitaryPostTypeRankCode(
			"Other ranks",
			"OTHR",
			"The specification of a MILITARY-POST-TYPE as being appropriate for an individual who does not hold an officer's commission in the armed forces.");

	private MilitaryPostTypeRankCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
