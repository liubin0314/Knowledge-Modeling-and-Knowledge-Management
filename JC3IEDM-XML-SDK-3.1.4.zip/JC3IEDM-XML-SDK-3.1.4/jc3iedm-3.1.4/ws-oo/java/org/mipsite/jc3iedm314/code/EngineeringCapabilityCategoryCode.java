/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EngineeringCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ENGINEERING-CAPABILITY.";
	}

	private static HashMap<String, EngineeringCapabilityCategoryCode> physicalToCode = new HashMap<String, EngineeringCapabilityCategoryCode>();

	public static EngineeringCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EngineeringCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EngineeringCapabilityCategoryCode BREACHING = new EngineeringCapabilityCategoryCode(
			"Breaching",
			"BRCH",
			"The action or process of making a gap in a wall or barrier.");
	public static final EngineeringCapabilityCategoryCode CONSTRUCTION = new EngineeringCapabilityCategoryCode(
			"Construction",
			"CNST",
			"The action or process of constructing.");
	public static final EngineeringCapabilityCategoryCode DEMOLITION = new EngineeringCapabilityCategoryCode(
			"Demolition",
			"DEMO",
			"The action or process of demolishing or being demolished.");

	private EngineeringCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
