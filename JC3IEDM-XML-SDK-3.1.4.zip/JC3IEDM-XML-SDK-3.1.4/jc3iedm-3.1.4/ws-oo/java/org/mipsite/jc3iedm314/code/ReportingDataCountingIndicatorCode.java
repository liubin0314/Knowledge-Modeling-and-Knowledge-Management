/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataCountingIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether the data referred to by a specific REPORTING-DATA is based on a count of objects.";
	}

	private static HashMap<String, ReportingDataCountingIndicatorCode> physicalToCode = new HashMap<String, ReportingDataCountingIndicatorCode>();

	public static ReportingDataCountingIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataCountingIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataCountingIndicatorCode NO = new ReportingDataCountingIndicatorCode(
			"No",
			"NO",
			"Reported data is not based on a count.");
	public static final ReportingDataCountingIndicatorCode YES = new ReportingDataCountingIndicatorCode(
			"Yes",
			"YES",
			"Reported data is based on a count.");

	private ReportingDataCountingIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
