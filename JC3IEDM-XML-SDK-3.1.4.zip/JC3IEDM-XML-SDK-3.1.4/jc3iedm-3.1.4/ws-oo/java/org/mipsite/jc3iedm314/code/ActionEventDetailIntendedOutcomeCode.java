/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEventDetailIntendedOutcomeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that describes the immediate and direct goals or objectives of an enemy�s attack.";
	}

	private static HashMap<String, ActionEventDetailIntendedOutcomeCode> physicalToCode = new HashMap<String, ActionEventDetailIntendedOutcomeCode>();

	public static ActionEventDetailIntendedOutcomeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEventDetailIntendedOutcomeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEventDetailIntendedOutcomeCode ANTI_AIR_VEHICLE = new ActionEventDetailIntendedOutcomeCode(
			"Anti-air vehicle",
			"AIRDEF",
			"The intended result is to damage or destroy aircraft and/or their payload as well as to kill or wound individuals inside the aircraft.");
	public static final ActionEventDetailIntendedOutcomeCode ANTI_ARMOUR = new ActionEventDetailIntendedOutcomeCode(
			"Anti-armour",
			"ARMDEF",
			"The intended result is to damage or destroy armoured vehicles and/or to kill or wound individuals inside armoured vehicles.");
	public static final ActionEventDetailIntendedOutcomeCode ANTI_INFRASTRUCTURE = new ActionEventDetailIntendedOutcomeCode(
			"Anti-infrastructure",
			"INFDEF",
			"The intended result is to damage or destroy physical infrastructure.");
	public static final ActionEventDetailIntendedOutcomeCode ANTI_PERSONNEL = new ActionEventDetailIntendedOutcomeCode(
			"Anti-personnel",
			"PERDEF",
			"The intended result is to kill or wound people.");
	public static final ActionEventDetailIntendedOutcomeCode ANTI_VEHICLE = new ActionEventDetailIntendedOutcomeCode(
			"Anti-vehicle",
			"VEHDEF",
			"The intended result is to damage or destroy vehicles, excluding armoured vehicles, and/or their cargo as well as to kill or wound individuals inside such vehicles.");
	public static final ActionEventDetailIntendedOutcomeCode ANTI_VESSEL = new ActionEventDetailIntendedOutcomeCode(
			"Anti-vessel",
			"VESDEF",
			"The intended result is to damage or destroy vessels.");
	public static final ActionEventDetailIntendedOutcomeCode TTP_IDENTIFICATION = new ActionEventDetailIntendedOutcomeCode(
			"TTP identification",
			"TTPID",
			"The intended result is to cause a reaction by forces in an effort to learn and understand employed tactics. This knowledge is then used by the attacker to plan new attacks incorporating the lessons learned to inflict additional casualties or to avoid countermeasures. (TTP - Tactics, Techniques and Procedures).");
	public static final ActionEventDetailIntendedOutcomeCode NOT_OTHERWISE_SPECIFIED = new ActionEventDetailIntendedOutcomeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionEventDetailIntendedOutcomeCode NOT_KNOWN = new ActionEventDetailIntendedOutcomeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private ActionEventDetailIntendedOutcomeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
