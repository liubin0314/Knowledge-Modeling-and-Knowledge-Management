/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MiscellaneousEquipmentTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of MISCELLANEOUS-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, MiscellaneousEquipmentTypeSubcategoryCode> physicalToCode = new HashMap<String, MiscellaneousEquipmentTypeSubcategoryCode>();

	public static MiscellaneousEquipmentTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MiscellaneousEquipmentTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MiscellaneousEquipmentTypeSubcategoryCode BOOM_AND_CENTRELINE_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Boom and centreline drogue",
			"BCD",
			"Two components of a refuelling system by which a boom and a centreline drogue devices can provide fuel on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode BOOM_AND_CENTRELINE_DROGUE_AND_WINGTIP_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Boom and centreline drogue, and wingtip drogue",
			"BCDW",
			"Three components of a refuelling system by which a boom, centreline drogue and wingtip drogue devices can provide fuel on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode BOOM = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Boom",
			"BOOM",
			"A component of a refuelling system by which a boom device on an aerial refuelling tanker is inserted into a receptacle on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode BOOM_AND_WINGTIP_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Boom and wingtip drogue",
			"BWD",
			"Two components of a refuelling system by which a boom and a wingtip drogue devices provide fuel on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode CENTRELINE_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Centreline drogue",
			"CD",
			"A component of a refuelling system by which a centreline drogue device can provide fuel on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode CENTRELINE_DROGUE_AND_WINGTIP_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Centreline drogue and wingtip drogue",
			"CDWD",
			"Two components of a refuelling system by which centreline drogue and wingtip drogue devices can provide fuel on a receiver aircraft.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode HAMMER = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Hammer",
			"HAMMER",
			"Hand tool consisting of a handle with a head of metal or other heavy rigid material, used for striking or pounding.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode PLIERS = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Pliers",
			"PLIERS",
			"Pincers, usually small, having long jaws mostly with parallel surfaces, sometimes toothed, used for bending wire, manipulating small objects, etc.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode SHOVEL = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Shovel",
			"SHOVEL",
			"Hand tool for lifting loose material; consists of a curved container or scoop and a handle.");
	public static final MiscellaneousEquipmentTypeSubcategoryCode WINGTIP_DROGUE = new MiscellaneousEquipmentTypeSubcategoryCode(
			"Wingtip drogue",
			"WD",
			"A component of a refuelling system by which a wingtip drogue device can provide fuel on a receiver aircraft.");

	private MiscellaneousEquipmentTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
