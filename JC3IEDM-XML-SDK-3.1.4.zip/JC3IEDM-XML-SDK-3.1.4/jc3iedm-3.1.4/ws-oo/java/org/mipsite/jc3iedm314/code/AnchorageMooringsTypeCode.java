/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AnchorageMooringsTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of mooring available at the specific ANCHORAGE.";
	}

	private static HashMap<String, AnchorageMooringsTypeCode> physicalToCode = new HashMap<String, AnchorageMooringsTypeCode>();

	public static AnchorageMooringsTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AnchorageMooringsTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AnchorageMooringsTypeCode BUOY = new AnchorageMooringsTypeCode(
			"Buoy",
			"BUOY",
			"An anchored float marking the location of a mooring.");
	public static final AnchorageMooringsTypeCode DOLPHIN = new AnchorageMooringsTypeCode(
			"Dolphin",
			"DOLPIN",
			"An isolated offshore bollard, cluster of piles or columns used for mooring or securing vessels.");
	public static final AnchorageMooringsTypeCode FIXED_POST = new AnchorageMooringsTypeCode(
			"Fixed post",
			"FXDPST",
			"A duc d�albe placed at the location of the anchorage.");
	public static final AnchorageMooringsTypeCode NOT_OTHERWISE_SPECIFIED = new AnchorageMooringsTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private AnchorageMooringsTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
