/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SurveillanceCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of SURVEILLANCE-CAPABILITY.";
	}

	private static HashMap<String, SurveillanceCapabilityCategoryCode> physicalToCode = new HashMap<String, SurveillanceCapabilityCategoryCode>();

	public static SurveillanceCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SurveillanceCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SurveillanceCapabilityCategoryCode COMMUNICATION = new SurveillanceCapabilityCategoryCode(
			"Communication",
			"COM",
			"The ability to gain information by exploiting communications systems.");
	public static final SurveillanceCapabilityCategoryCode ELECTRONIC = new SurveillanceCapabilityCategoryCode(
			"Electronic",
			"ELC",
			"The ability to gain information by exploiting non-communications electronic systems (generally pulsed).");
	public static final SurveillanceCapabilityCategoryCode HUMAN = new SurveillanceCapabilityCategoryCode(
			"Human",
			"HUM",
			"The ability to gain information by exploiting human senses.");
	public static final SurveillanceCapabilityCategoryCode IMAGING = new SurveillanceCapabilityCategoryCode(
			"Imaging",
			"IMG",
			"The ability to gain information by exploiting imaging systems.");
	public static final SurveillanceCapabilityCategoryCode NOT_KNOWN = new SurveillanceCapabilityCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final SurveillanceCapabilityCategoryCode NOT_OTHERWISE_SPECIFIED = new SurveillanceCapabilityCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final SurveillanceCapabilityCategoryCode SIGNAL = new SurveillanceCapabilityCategoryCode(
			"Signal",
			"SIG",
			"The ability to gain information from exploiting EMS (not imagery) systems.");

	private SurveillanceCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
