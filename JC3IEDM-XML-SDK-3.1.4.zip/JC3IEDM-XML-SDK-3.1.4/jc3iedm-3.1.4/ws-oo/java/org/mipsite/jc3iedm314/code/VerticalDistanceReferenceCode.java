/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VerticalDistanceReferenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the reference system for a specific VERTICAL-DISTANCE.";
	}

	private static HashMap<String, VerticalDistanceReferenceCode> physicalToCode = new HashMap<String, VerticalDistanceReferenceCode>();

	public static VerticalDistanceReferenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VerticalDistanceReferenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VerticalDistanceReferenceCode CHART_DATUM = new VerticalDistanceReferenceCode(
			"Chart datum",
			"CHADAT",
			"The vertical reference established as the lowest observed or theoretical sea level possible for the area, such as Mean Lower Low Water (MLLW) or Lowest Astronomical Tide (LAT).");
	public static final VerticalDistanceReferenceCode LOCAL_DATUM = new VerticalDistanceReferenceCode(
			"Local datum",
			"LOCDAT",
			"The vertical reference for a level, a point or an object considered as a point measured from a specific datum.");
	public static final VerticalDistanceReferenceCode MEAN_SEA_LEVEL = new VerticalDistanceReferenceCode(
			"Mean sea level",
			"MNSLVL",
			"The vertical reference established as the average level of the ocean surface measured over a full metonic tidal cycle of 18.6 years.");
	public static final VerticalDistanceReferenceCode PRESSURE_DATUM_QFE = new VerticalDistanceReferenceCode(
			"Pressure datum QFE",
			"PDQFE",
			"The VERTICAL-DISTANCE reference in terms of atmospheric pressure indicated by a pressure altimeter that is calibrated to read 0 at airfield runway ground level.");
	public static final VerticalDistanceReferenceCode PRESSURE_DATUM_QNH = new VerticalDistanceReferenceCode(
			"Pressure datum QNH",
			"PDQNH",
			"The VERTICAL-DISTANCE reference in terms of atmospheric pressure indicated by a pressure altimeter that is calibrated to read 0 at Mean Sea Level (MSL).");
	public static final VerticalDistanceReferenceCode PRESSURE_DATUM_STANDARD_ATMOSPHERE = new VerticalDistanceReferenceCode(
			"Pressure datum standard atmosphere",
			"PDSTDT",
			"The VERTICAL-DISTANCE reference in terms of atmospheric pressure indicated by a pressure altimeter that is calibrated to read 0 at standard atmosphere pressure of 1013.2 millibars.");
	public static final VerticalDistanceReferenceCode TOPOGRAPHIC_SURFACE = new VerticalDistanceReferenceCode(
			"Topographic surface",
			"TOPOSR",
			"The vertical reference is the actual visible surface. This includes both terrain and water surfaces.");
	public static final VerticalDistanceReferenceCode WATER_BOTTOM = new VerticalDistanceReferenceCode(
			"Water bottom",
			"WATBOT",
			"The datum for VERTICAL-DISTANCE provided by the submerged surface at a point or area.");
	public static final VerticalDistanceReferenceCode WGS84_GEOID = new VerticalDistanceReferenceCode(
			"WGS84 geoid",
			"WGS84G",
			"The vertical reference established as the surface of the WGS84 geoid.");
	public static final VerticalDistanceReferenceCode WGS84_REFERENCE_ELLIPSOID = new VerticalDistanceReferenceCode(
			"WGS84 reference ellipsoid",
			"WGS84R",
			"The vertical reference established as the surface of the WGS84 ellipsoid.");

	private VerticalDistanceReferenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
