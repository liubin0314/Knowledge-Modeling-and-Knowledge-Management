/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MeteorologicFeatureCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of METEOROLOGIC-FEATURE.";
	}

	private static HashMap<String, MeteorologicFeatureCategoryCode> physicalToCode = new HashMap<String, MeteorologicFeatureCategoryCode>();

	public static MeteorologicFeatureCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MeteorologicFeatureCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MeteorologicFeatureCategoryCode ATMOSPHERE = new MeteorologicFeatureCategoryCode(
			"ATMOSPHERE",
			"ATMOS",
			"A METEOROLOGIC-FEATURE that specifies humidity, pressure, and temperature characteristics of Earth's atmosphere.");
	public static final MeteorologicFeatureCategoryCode CLOUD_COVER = new MeteorologicFeatureCategoryCode(
			"CLOUD-COVER",
			"COVER",
			"A METEOROLOGIC-FEATURE that specifies the characteristics of clouds above Earth's surface.");
	public static final MeteorologicFeatureCategoryCode CYCLONE = new MeteorologicFeatureCategoryCode(
			"Cyclone",
			"CYCL",
			"The atmospheric pressure distribution in which there is a low central pressure relative to the surroundings. Cyclonic circulation is anticlockwise round the centre in the northern hemisphere and clockwise in the southern hemisphere; in either case the sense of rotation about the vertical is the same as that of the earth's rotation.");
	public static final MeteorologicFeatureCategoryCode FUNNEL_CLOUD = new MeteorologicFeatureCategoryCode(
			"Funnel cloud",
			"FNLCLD",
			"A violent, rotating column of air that does not touch the ground, usually appended to a cumulonimbus cloud. Also called a tuba.");
	public static final MeteorologicFeatureCategoryCode HURRICANE = new MeteorologicFeatureCategoryCode(
			"Hurricane",
			"HURR",
			"A tropical cyclone, especially in the West Indies, in which wind velocity equals or exceeds 64 knots (118.5 km/hr).");
	public static final MeteorologicFeatureCategoryCode ICING = new MeteorologicFeatureCategoryCode(
			"ICING",
			"ICING",
			"A METEOROLOGIC-FEATURE that specifies the accumulation of frozen water on stationary or moving surfaces.");
	public static final MeteorologicFeatureCategoryCode JET_STREAM = new MeteorologicFeatureCategoryCode(
			"Jet stream",
			"JTSTRM",
			"A narrow belt of strong winds, with speeds of 50 to 200 knots (92.6 to 370.4 km/hr), in the upper troposphere.");
	public static final MeteorologicFeatureCategoryCode LIGHTNING = new MeteorologicFeatureCategoryCode(
			"Lightning",
			"LGTNNG",
			"A luminous manifestation accompanying a sudden electrical discharge, which takes place from or inside a cloud or, less often, from high structures on the ground, or from mountains.");
	public static final MeteorologicFeatureCategoryCode LIGHT = new MeteorologicFeatureCategoryCode(
			"LIGHT",
			"LIGHT",
			"A METEOROLOGIC-FEATURE that specifies the availability of natural illumination by type and time.");
	public static final MeteorologicFeatureCategoryCode NOT_OTHERWISE_SPECIFIED = new MeteorologicFeatureCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MeteorologicFeatureCategoryCode PRECIPITATION = new MeteorologicFeatureCategoryCode(
			"PRECIPITATION",
			"PRECIP",
			"A METEOROLOGIC-FEATURE that specifies the type of particulate matter in the Earth's atmosphere and the rate of its accumulation on the Earth's surface.");
	public static final MeteorologicFeatureCategoryCode STORM = new MeteorologicFeatureCategoryCode(
			"Storm",
			"STORM",
			"An atmospheric disturbance manifested in strong winds with precipitation.");
	public static final MeteorologicFeatureCategoryCode THUNDERSTORM = new MeteorologicFeatureCategoryCode(
			"Thunderstorm",
			"THST",
			"A local storm produced by a cumulonimbus cloud accompanied by strong gusty winds, vertical currents at higher levels, and heavy precipitation with lightning and/or thunder. It is usually a few miles in both horizontal and vertical dimensions, extending from the ground up to 6,000, 12,000 or even 18,000 metres in the most vigorous examples.");
	public static final MeteorologicFeatureCategoryCode THUNDERSTORMS_AND_RAIN = new MeteorologicFeatureCategoryCode(
			"Thunderstorms and rain",
			"THSTRN",
			"A local storm produced by a cumulonimbus cloud accompanied by lightning and/or thunder and precipitation, either in the form of drops larger than 0.5 mm, or smaller drops, which in contrast to drizzle, are widely separated.");
	public static final MeteorologicFeatureCategoryCode TORNADO = new MeteorologicFeatureCategoryCode(
			"Tornado",
			"TORN",
			"A violent, rotating column of air touching the ground; funnel cloud touching the ground. A tornado nearly always starts as a funnel cloud and is accompanied by a loud, roaring noise.");
	public static final MeteorologicFeatureCategoryCode TROPICAL_STORM = new MeteorologicFeatureCategoryCode(
			"Tropical storm",
			"TRST",
			"A tropical cyclone having winds ranging from approximately 48 to 121 kilometres per hour.");
	public static final MeteorologicFeatureCategoryCode TYPHOON = new MeteorologicFeatureCategoryCode(
			"Typhoon",
			"TYPH",
			"A severe tropical hurricane.");
	public static final MeteorologicFeatureCategoryCode VISIBILITY = new MeteorologicFeatureCategoryCode(
			"VISIBILITY",
			"VISIB",
			"A METEOROLOGIC-FEATURE that specifies the distance at which an object illuminated by light in the visual spectrum can be detected.");
	public static final MeteorologicFeatureCategoryCode WHIRLWIND = new MeteorologicFeatureCategoryCode(
			"Whirlwind",
			"WHIR",
			"A small revolving storm of wind in which the air whirls around a core of low pressure. Whirlwinds sometimes extend upwards to a height of many hundreds of metres and cause dust whirls formed over a desert.");
	public static final MeteorologicFeatureCategoryCode WIND = new MeteorologicFeatureCategoryCode(
			"WIND",
			"WIND",
			"A METEOROLOGIC-FEATURE that specifies the velocity and directional characteristics of atmospheric movement.");
	public static final MeteorologicFeatureCategoryCode WATERSPOUT = new MeteorologicFeatureCategoryCode(
			"Waterspout",
			"WTRSPT",
			"A violent, rotating column of air that forms over a body of water, such as a bay, gulf, or lake, and touches the water surface; a tornado or funnel cloud that touches a body of water.");

	private MeteorologicFeatureCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
