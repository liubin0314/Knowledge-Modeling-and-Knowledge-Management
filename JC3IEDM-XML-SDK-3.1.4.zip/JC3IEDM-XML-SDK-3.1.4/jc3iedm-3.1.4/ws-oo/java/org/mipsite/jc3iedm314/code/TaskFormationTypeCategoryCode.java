/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class TaskFormationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of TASK-FORMATION-TYPE.";
	}

	private static HashMap<String, TaskFormationTypeCategoryCode> physicalToCode = new HashMap<String, TaskFormationTypeCategoryCode>();

	public static TaskFormationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<TaskFormationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final TaskFormationTypeCategoryCode AIR_FORMATION = new TaskFormationTypeCategoryCode(
			"Air formation",
			"AIRFMN",
			"An ordered arrangement of two or more aircraft proceeding together under a commander.");
	public static final TaskFormationTypeCategoryCode AIR_TASK_FORCE = new TaskFormationTypeCategoryCode(
			"Air task force",
			"AIRTF",
			"A temporary grouping of units, under one commander, formed for the purpose of carrying out a specific air operation or mission.");
	public static final TaskFormationTypeCategoryCode AMPHIBIOUS_TASK_FORCE = new TaskFormationTypeCategoryCode(
			"Amphibious task force",
			"AMPHTF",
			"A temporary grouping of units, under one commander, formed for the purpose of carrying out a specific amphibious operation or mission.");
	public static final TaskFormationTypeCategoryCode COMBAT_CONTROL_TEAM = new TaskFormationTypeCategoryCode(
			"Combat control team",
			"CMBCTM",
			"A TASK-FORMATION-TYPE that consists of parachute and combat diver qualified personnel trained and equipped to rapidly establish and control drop, landing, and extraction zone air traffic in austere or hostile conditions. They survey and establish terminal airheads as well as provide guidance to aircraft for airlift operations. They provide command and control, and conduct reconnaissance, surveillance, and survey assessments of potential objective airfields or assault zones.");
	public static final TaskFormationTypeCategoryCode FLOTILLA = new TaskFormationTypeCategoryCode(
			"Flotilla",
			"FLOTLA",
			"A small fleet; a fleet of boats or small vessels.");
	public static final TaskFormationTypeCategoryCode GROUP_NAVY = new TaskFormationTypeCategoryCode(
			"Group (navy)",
			"GRNAVY",
			"A TASK-FORMATION-TYPE that consists of a number of ships and/or aircraft, normally a subdivision of a force, assigned for a specific purpose.");
	public static final TaskFormationTypeCategoryCode INITIAL_TERMINAL_GUIDANCE_TEAM = new TaskFormationTypeCategoryCode(
			"Initial terminal guidance team",
			"INTGTM",
			"A TASK-FORMATION-TYPE that provides electronic, mechanical, visual, or other assistance given an aircraft pilot to facilitate arrival at, operation within or over, landing upon, or departure from an air landing or airdrop facility.");
	public static final TaskFormationTypeCategoryCode JOINT_TASK_FORCE = new TaskFormationTypeCategoryCode(
			"Joint task force",
			"JNTTF",
			"A temporary grouping of units, under one commander, formed for the purpose of carrying out a specific joint operation or mission.");
	public static final TaskFormationTypeCategoryCode LAND_TASK_FORCE = new TaskFormationTypeCategoryCode(
			"Land task force",
			"LANDTF",
			"A temporary grouping of units, under one commander, formed for the purpose of carrying out a specific land operation or mission.");
	public static final TaskFormationTypeCategoryCode LAND_FORMATION = new TaskFormationTypeCategoryCode(
			"Land formation",
			"LNDFMN",
			"An ordered arrangement of troops and/or vehicles for a specific purpose.");
	public static final TaskFormationTypeCategoryCode MILITARY_CONVOY_TYPE = new TaskFormationTypeCategoryCode(
			"Military-convoy-type",
			"MLCNVY",
			"A TASK-FORMATION-TYPE that is a land or maritime convoy that is controlled and reported as a military unit.");
	public static final TaskFormationTypeCategoryCode MARINE_AIR_TRAFFIC_CONTROL_DETACHMENT = new TaskFormationTypeCategoryCode(
			"Marine air traffic control detachment",
			"MRATCD",
			"A TASK-FORMATION-TYPE, subordinate to the U.S. Marine TACC, that controls local airspace/aircraft in and around a Marine Air Ground Task Force (MAGTF) airfields and provides precision approach control for MAGTF aircraft.");
	public static final TaskFormationTypeCategoryCode MARINE_AIR_TRAFFIC_CONTROL_MOBILE_TEAM = new TaskFormationTypeCategoryCode(
			"Marine air traffic control mobile team",
			"MRATCM",
			"A TASK-FORMATION-TYPE, subordinate to the U. S. Marine TACC, that controls local airspace/aircraft in and around Marine Air Ground Task Force (MAGTF) airfields and provides precision approach control for MAGTF aircraft.");
	public static final TaskFormationTypeCategoryCode NAVAL_FORMATION = new TaskFormationTypeCategoryCode(
			"Naval formation",
			"NAVFMN",
			"An ordered arrangement of two or more ships, units or aircraft proceeding together under a commander.");
	public static final TaskFormationTypeCategoryCode NAVAL_TASK_ELEMENT = new TaskFormationTypeCategoryCode(
			"Naval task element",
			"NAVLTE",
			"A TASK-FORMATION-TYPE that is a component of a task unit organized by the commander of the task unit or higher authority for accomplishing a specific task.");
	public static final TaskFormationTypeCategoryCode NAVAL_TASK_FORCE = new TaskFormationTypeCategoryCode(
			"Naval task force",
			"NAVLTF",
			"A TASK-FORMATION-TYPE that is a component of a fleet organized by the commander of a task fleet or higher authority for the accomplishment of a specific task or tasks.");
	public static final TaskFormationTypeCategoryCode NAVAL_TASK_GROUP = new TaskFormationTypeCategoryCode(
			"Naval task group",
			"NAVLTG",
			"A TASK-FORMATION-TYPE that is a component of a task force organized by the commander of the task force or higher authority for accomplishing specific tasks.");
	public static final TaskFormationTypeCategoryCode NAVAL_TASK_UNIT = new TaskFormationTypeCategoryCode(
			"Naval task unit",
			"NAVLTU",
			"A TASK-FORMATION-TYPE that is a component of a task group organized by the commander of a task group or higher authority for accomplishing specific tasks.");
	public static final TaskFormationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new TaskFormationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final TaskFormationTypeCategoryCode PATROL = new TaskFormationTypeCategoryCode(
			"Patrol",
			"PATROL",
			"A TASK-FORMATION-TYPE that is a detachment of ground, sea, or air forces sent out for the purpose of gathering information or carrying out a destructive, harassing, mopping-up, or security mission.");
	public static final TaskFormationTypeCategoryCode WORK_PARTY = new TaskFormationTypeCategoryCode(
			"Work party",
			"WRKPTY",
			"A group of people who come together to carry out a piece of work.");

	private TaskFormationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
