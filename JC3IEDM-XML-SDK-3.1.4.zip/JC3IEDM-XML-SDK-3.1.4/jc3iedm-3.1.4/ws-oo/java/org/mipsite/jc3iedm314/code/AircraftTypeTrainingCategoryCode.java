/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeTrainingCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether an aircraft can be used for training purposes.";
	}

	private static HashMap<String, AircraftTypeTrainingCategoryCode> physicalToCode = new HashMap<String, AircraftTypeTrainingCategoryCode>();

	public static AircraftTypeTrainingCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeTrainingCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeTrainingCategoryCode NOT_KNOWN = new AircraftTypeTrainingCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeTrainingCategoryCode NO = new AircraftTypeTrainingCategoryCode(
			"No",
			"NO",
			"The AIRCRAFT-TYPE is not designed to be used as a trainer.");
	public static final AircraftTypeTrainingCategoryCode YES = new AircraftTypeTrainingCategoryCode(
			"Yes",
			"YES",
			"The AIRCRAFT-TYPE is designed to be used as a trainer.");

	private AircraftTypeTrainingCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
