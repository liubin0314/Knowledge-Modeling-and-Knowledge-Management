/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusAvailabilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that gives the availability status of an ORGANISATION without regard to readiness.";
	}

	private static HashMap<String, OrganisationStatusAvailabilityCode> physicalToCode = new HashMap<String, OrganisationStatusAvailabilityCode>();

	public static OrganisationStatusAvailabilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusAvailabilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusAvailabilityCode AFTER_30_DAYS = new OrganisationStatusAvailabilityCode(
			"After 30 days",
			"AFT30D",
			"An availability status of an ORGANISATION indicating that the ORGANISATION can be available for use after 30 days.");
	public static final OrganisationStatusAvailabilityCode BETWEEN_16_AND_30_DAYS = new OrganisationStatusAvailabilityCode(
			"Between 16 and 30 days",
			"BTW163",
			"An availability status of an ORGANISATION indicating that the ORGANISATION can be available for use in between 16 and 30 days.");
	public static final OrganisationStatusAvailabilityCode BETWEEN_48_HOURS_AND_4_DAYS = new OrganisationStatusAvailabilityCode(
			"Between 48 hours and 4 days",
			"BTW484",
			"An availability status of an ORGANISATION indicating that the ORGANISATION can be available for use in between 48 hours and 4 days.");
	public static final OrganisationStatusAvailabilityCode BETWEEN_5_AND_15_DAYS = new OrganisationStatusAvailabilityCode(
			"Between 5 and 15 days",
			"BTW515",
			"An availability status of an ORGANISATION indicating that the ORGANISATION can be available for use in between 5 and 15 days.");
	public static final OrganisationStatusAvailabilityCode NOT_AVAILABLE = new OrganisationStatusAvailabilityCode(
			"Not available",
			"NA",
			"An availability status of an ORGANISATION indicating that the ORGANISATION is not available.");
	public static final OrganisationStatusAvailabilityCode WITHIN_48_HOURS = new OrganisationStatusAvailabilityCode(
			"Within 48 hours",
			"WTN48H",
			"An availability status of an ORGANISATION indicating that the ORGANISATION can be available for use within 48 hours.");

	private OrganisationStatusAvailabilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
