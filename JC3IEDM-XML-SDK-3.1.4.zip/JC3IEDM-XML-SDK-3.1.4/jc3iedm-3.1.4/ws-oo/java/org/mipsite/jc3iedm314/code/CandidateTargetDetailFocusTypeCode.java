/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetDetailFocusTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes a general class of actions intended by the nominating authority for a specific CANDIDATE-TARGET-DETAIL.";
	}

	private static HashMap<String, CandidateTargetDetailFocusTypeCode> physicalToCode = new HashMap<String, CandidateTargetDetailFocusTypeCode>();

	public static CandidateTargetDetailFocusTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetDetailFocusTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetDetailFocusTypeCode ATTACK = new CandidateTargetDetailFocusTypeCode(
			"Attack",
			"ATTACK",
			"To conduct a type of offensive action characterised by coordinated employment of firepower and manoeuvre to close with and destroy or capture the enemy.");
	public static final CandidateTargetDetailFocusTypeCode CAPTURE = new CandidateTargetDetailFocusTypeCode(
			"Capture",
			"CAPTUR",
			"To take possession of an object, normally by force; it frequently involves movement as a preliminary phase.");
	public static final CandidateTargetDetailFocusTypeCode DEFEAT = new CandidateTargetDetailFocusTypeCode(
			"Defeat",
			"DEFEAT",
			"To diminish the effectiveness of the enemy to the extent that he is unable to participate further in the battle or at least cannot fulfil his intention.");
	public static final CandidateTargetDetailFocusTypeCode DESTROY = new CandidateTargetDetailFocusTypeCode(
			"Destroy",
			"DESTRY",
			"To physically render a target combat-ineffective or damage it so that it cannot function as intended nor be restored to a usable condition without being entirely rebuilt.");
	public static final CandidateTargetDetailFocusTypeCode DO_NOT_ATTACK = new CandidateTargetDetailFocusTypeCode(
			"Do not attack",
			"DONOTA",
			"The specific object or type in the CANDIDATE-TARGET-DETAIL must not be attacked.");
	public static final CandidateTargetDetailFocusTypeCode ILLUMINATE = new CandidateTargetDetailFocusTypeCode(
			"Illuminate",
			"ILLUMN",
			"Battlespace illumination provided by employing searchlight or pyrotechnic illuminants using diffusion or reflection.");
	public static final CandidateTargetDetailFocusTypeCode INFILTRATE = new CandidateTargetDetailFocusTypeCode(
			"Infiltrate",
			"INFILT",
			"To move a force, broken down as individuals or small groups, over, through or around enemy positions with the aim of avoiding detection.");
	public static final CandidateTargetDetailFocusTypeCode INTERCEPT = new CandidateTargetDetailFocusTypeCode(
			"Intercept",
			"INTCEP",
			"To conduct Electronic Warfare Support operations with a view to searching, locating, recording and analysing radiated electromagnetic energy for the purposes of supporting an operation.");
	public static final CandidateTargetDetailFocusTypeCode JAM = new CandidateTargetDetailFocusTypeCode(
			"Jam",
			"JAM",
			"To deliberately radiate, re-radiate or reflect electromagnetic energy with the object of impairing the use of electronic devices, equipment or systems being used by the enemy.");
	public static final CandidateTargetDetailFocusTypeCode LOCATE = new CandidateTargetDetailFocusTypeCode(
			"Locate",
			"LOCATE",
			"To establish the position of an objective.");
	public static final CandidateTargetDetailFocusTypeCode MARK = new CandidateTargetDetailFocusTypeCode(
			"Mark",
			"MARK",
			"To make visible (by the use of light/IR/laser/arty) an objective in order to allow its identification by another object (usually as a precursor to the use of direct fire weapons against the marked objective).");
	public static final CandidateTargetDetailFocusTypeCode NOT_OTHERWISE_SPECIFIED = new CandidateTargetDetailFocusTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final CandidateTargetDetailFocusTypeCode NEUTRALIZE = new CandidateTargetDetailFocusTypeCode(
			"Neutralize",
			"NUTRLS",
			"To render the enemy�s weapons temporarily ineffective, normally by use of indirect fire (also normally associated with the imposition of 10% casualties in the case of indirect fire).");
	public static final CandidateTargetDetailFocusTypeCode OBSERVE = new CandidateTargetDetailFocusTypeCode(
			"Observe",
			"OBSRV",
			"To provide continuous view, and the potential for reports on the activity of an objective.");
	public static final CandidateTargetDetailFocusTypeCode OCCUPY = new CandidateTargetDetailFocusTypeCode(
			"Occupy",
			"OCCUPY",
			"To move into and properly organise an area to be used as a battle position.");
	public static final CandidateTargetDetailFocusTypeCode RECONNOITRE = new CandidateTargetDetailFocusTypeCode(
			"Reconnoitre",
			"RECCE",
			"To conduct a mission to obtain by visual operations or other detection methods information about the activities and resources of an enemy or potential enemy, or to secure data concerning the meteorological, hydrographic or geographic characteristics of a particular area.");
	public static final CandidateTargetDetailFocusTypeCode SUPPRESS = new CandidateTargetDetailFocusTypeCode(
			"Suppress",
			"SUPPRS",
			"To provide fire which neutralizes or temporarily degrades the capabilities of enemy forces within a specific area. This makes no assumptions as to enemy casualties; it may be a transitory effect.");

	private CandidateTargetDetailFocusTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
