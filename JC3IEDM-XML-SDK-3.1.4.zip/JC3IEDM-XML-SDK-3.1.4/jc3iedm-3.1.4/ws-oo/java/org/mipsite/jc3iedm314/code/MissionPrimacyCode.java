/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MissionPrimacyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the relative priority that a specific capability that is an OPERATIONAL-CAPABILITY has.";
	}

	private static HashMap<String, MissionPrimacyCode> physicalToCode = new HashMap<String, MissionPrimacyCode>();

	public static MissionPrimacyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MissionPrimacyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MissionPrimacyCode PRIMARY = new MissionPrimacyCode(
			"Primary",
			"PRIME",
			"Denotes the primary mission.");
	public static final MissionPrimacyCode SECONDARY = new MissionPrimacyCode(
			"Secondary",
			"SCNDRY",
			"Denotes the secondary mission.");
	public static final MissionPrimacyCode TERTIARY = new MissionPrimacyCode(
			"Tertiary",
			"THIRD",
			"Denotes the tertiary mission.");

	private MissionPrimacyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
