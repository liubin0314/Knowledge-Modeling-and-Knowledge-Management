/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeModelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the specific design of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeModelCode> physicalToCode = new HashMap<String, AircraftTypeModelCode>();

	public static AircraftTypeModelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeModelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeModelCode _1049_SUPER_CONSTELLATION = new AircraftTypeModelCode(
			"1049 Super Constellation",
			"1049",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _1150_ATLANTIQUE = new AircraftTypeModelCode(
			"1150 Atlantique",
			"1150AT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _200_SUPER_KING_AIR_MOD_1900C = new AircraftTypeModelCode(
			"200 Super King Air Mod 1900C",
			"200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _201_ARAVA = new AircraftTypeModelCode(
			"201 Arava",
			"201A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _269A_HUGHES = new AircraftTypeModelCode(
			"269A Hughes",
			"269A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _280L_HAWK_ENSTROM = new AircraftTypeModelCode(
			"280l Hawk Enstrom",
			"280L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _300_C_HUGHES = new AircraftTypeModelCode(
			"300-C Hughes",
			"300C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _333_DF_DRAGON_FLY_333_DF_333_DRAGON_FLY = new AircraftTypeModelCode(
			"333-DF Dragon Fly 333 / DF-333 Dragon Fly",
			"333DF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _35XD_DRAKEN = new AircraftTypeModelCode(
			"35XD Draken",
			"35XD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _369_OHJ_HUGHES = new AircraftTypeModelCode(
			"369 OHJ Hughes",
			"369OHJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_HUGHES = new AircraftTypeModelCode(
			"500 Hughes",
			"H500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_C_HUGHES = new AircraftTypeModelCode(
			"500-C Hughes",
			"H500C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_D_HUGHES = new AircraftTypeModelCode(
			"500-D Hughes",
			"H500D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_E_HUGHES = new AircraftTypeModelCode(
			"500-E Hughes",
			"H500E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_M_HUGHES = new AircraftTypeModelCode(
			"500-M Hughes",
			"H500M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500MD_DEFENDER = new AircraftTypeModelCode(
			"500MD Defender",
			"500MD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_MD_HUGHES_SCOUT = new AircraftTypeModelCode(
			"500-MD Hughes Scout",
			"H500MD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _500_ME_HUGHES = new AircraftTypeModelCode(
			"500-ME Hughes",
			"H500ME",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _698_MK2_VULCAN = new AircraftTypeModelCode(
			"698-MK2 Vulcan",
			"698V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _720_PHA_B_707_720_PHALCON = new AircraftTypeModelCode(
			"720-PHA B 707 / 720 Phalcon",
			"B720PH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode _8600_CRESCO_08_600 = new AircraftTypeModelCode(
			"8600 Cresco 08-600",
			"8600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_1_A_1B_A_1_AMX = new AircraftTypeModelCode(
			"A-1 / A-1B / A-1 AMX",
			"A1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_10_THUNDERBOLT_II = new AircraftTypeModelCode(
			"A-10 Thunderbolt Ii",
			"A10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_100_KING_AIR = new AircraftTypeModelCode(
			"A-100 King Air",
			"A100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_103_ALOUETTE_III = new AircraftTypeModelCode(
			"A-103 Alouette III",
			"A103",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109_AGUSTA_HIRUNDA = new AircraftTypeModelCode(
			"A-109 Agusta / Hirunda",
			"A109A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109C = new AircraftTypeModelCode(
			"A-109C",
			"A109C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109E_AGUSTA_POWER = new AircraftTypeModelCode(
			"A-109E Agusta / Power",
			"A109E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109H0_AGUSTA = new AircraftTypeModelCode(
			"A-109H0 Agusta",
			"A109H0",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109HA_AGUSTA = new AircraftTypeModelCode(
			"A-109HA Agusta",
			"A109HA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109K_AGUSTA = new AircraftTypeModelCode(
			"A-109K Agusta",
			"A109K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109KM_AGUSTA = new AircraftTypeModelCode(
			"A-109KM Agusta",
			"A109KM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109KN_AGUSTA = new AircraftTypeModelCode(
			"A-109KN Agusta",
			"A109KN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_109MAX_AGUSTA = new AircraftTypeModelCode(
			"A-109MAX Agusta",
			"A109MA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_10A_THUNDERBOLT_II = new AircraftTypeModelCode(
			"A-10A Thunderbolt Ii",
			"A10A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_10L_THUNDERBOLT = new AircraftTypeModelCode(
			"A-10l Thunderbolt",
			"A10AL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_10B_THUNDERBOLT = new AircraftTypeModelCode(
			"A-10B Thunderbolt",
			"A10B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_119_KOALA = new AircraftTypeModelCode(
			"A-119 Koala",
			"A119",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_122_UIRAPURU = new AircraftTypeModelCode(
			"A-122 Uirapuru",
			"A122",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_129_MANGUSTA_MANGUSTA_MONGOOSE_A_129 = new AircraftTypeModelCode(
			"A-129 Mangusta / Mangusta Mongoose A-129",
			"A129",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_129_19_MANGUSTA = new AircraftTypeModelCode(
			"A-129-19 Mangusta",
			"A12919",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_132_TANGARA = new AircraftTypeModelCode(
			"A-132 Tangara",
			"A132",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_135_TANGARA_II = new AircraftTypeModelCode(
			"A-135 Tangara II",
			"A135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_139 = new AircraftTypeModelCode(
			"A-139",
			"A139",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_18_AIR_SPACE_18A_A_18_HORNET_A_18 = new AircraftTypeModelCode(
			"A-18 Air & Space 18A / A-18 Hornet A-18",
			"A18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_1D_SKYRAIDER = new AircraftTypeModelCode(
			"A-1D Skyraider",
			"A1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_1M_SKYRAIDER = new AircraftTypeModelCode(
			"A-1M Skyraider",
			"A1M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_20_AIR_SPACE_20A = new AircraftTypeModelCode(
			"A-20 Air & Space 20a",
			"A20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_200 = new AircraftTypeModelCode(
			"A-200",
			"A200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_200_BEECH_SIERRA = new AircraftTypeModelCode(
			"A-200 Beech Sierra",
			"A200BS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_209 = new AircraftTypeModelCode(
			"A-209",
			"A209",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_211 = new AircraftTypeModelCode(
			"A-211",
			"A211",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_21M_SOLO = new AircraftTypeModelCode(
			"A-21M Solo",
			"A21M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_22_LASA_PIRANHA = new AircraftTypeModelCode(
			"A-22 Lasa / Piranha",
			"A22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_22J_FANJET_A_22J_PIRANHA = new AircraftTypeModelCode(
			"A-22J Fanjet / A-22j Piranha",
			"A22J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_23_TRAINER = new AircraftTypeModelCode(
			"A-23 Trainer",
			"A23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_25_BREEZE = new AircraftTypeModelCode(
			"A-25 Breeze",
			"A25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_27_T_27_EMB_312_TUCANO = new AircraftTypeModelCode(
			"A-27 / T-27 / Emb-312 Tucano",
			"A27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_29_SUPER_TUCANO = new AircraftTypeModelCode(
			"A-29 Super Tucano",
			"A29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_3_SKYWARRIOR = new AircraftTypeModelCode(
			"A-3 Skywarrior",
			"A3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_AIRBUS = new AircraftTypeModelCode(
			"A-300 Airbus",
			"A300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_MRTT_AIRBUS = new AircraftTypeModelCode(
			"A-300 MRTT Airbus",
			"A300MR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_B4_AIRBUS = new AircraftTypeModelCode(
			"A-300/B4 Airbus",
			"A300B4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_C4_AIRBUS = new AircraftTypeModelCode(
			"A-300/C4 Airbus",
			"A300C4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_600_AIRBUS = new AircraftTypeModelCode(
			"A-300-600 Airbus",
			"A30060",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_600_MRTT_AIRBUS = new AircraftTypeModelCode(
			"A-300-600 MRTT Airbus",
			"A3006M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_600ST_AIRBUS = new AircraftTypeModelCode(
			"A-300-600ST Airbus",
			"A3006S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_300_608ST_BELUGA = new AircraftTypeModelCode(
			"A-300-608ST Beluga",
			"A300SB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310_AIRBUS = new AircraftTypeModelCode(
			"A-310 Airbus",
			"A310",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310_CRYOPLANE_AIRBUS_TUPOV = new AircraftTypeModelCode(
			"A-310 Cryoplane Airbus-Tupov",
			"A310CY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310_200_AIRBUS = new AircraftTypeModelCode(
			"A-310/200 Airbus",
			"A31020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310_300_AIRBUS = new AircraftTypeModelCode(
			"A-310/300 Airbus",
			"A31030",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310_AE_AIRBUS = new AircraftTypeModelCode(
			"A-310-AE Airbus",
			"A310AE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_310MRTT_AIRBUS = new AircraftTypeModelCode(
			"A-310MRTT Airbus",
			"A310MR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_316_AIRBUS = new AircraftTypeModelCode(
			"A-316 Airbus",
			"A316",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_317_AIRBUS = new AircraftTypeModelCode(
			"A-317 Airbus",
			"A317",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_318_AIRBUS = new AircraftTypeModelCode(
			"A-318 Airbus",
			"A318",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_319_AIRBUS = new AircraftTypeModelCode(
			"A-319 Airbus",
			"A319",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_319_CORPORATE_JET_AIRBUS = new AircraftTypeModelCode(
			"A-319 Corporate Jet Airbus",
			"A319CJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_32_LANSEN = new AircraftTypeModelCode(
			"A-32 Lansen",
			"A32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_320_AIRBUS = new AircraftTypeModelCode(
			"A-320 Airbus",
			"A320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_320_200_AIRBUS = new AircraftTypeModelCode(
			"A-320-200 Airbus",
			"A32020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_321_AIRBUS = new AircraftTypeModelCode(
			"A-321 Airbus",
			"A321",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_321_200_AIRBUS = new AircraftTypeModelCode(
			"A-321-200 Airbus",
			"A32120",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_32A_LANSEN = new AircraftTypeModelCode(
			"A-32A Lansen",
			"A32A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_330_AIRBUS = new AircraftTypeModelCode(
			"A-330 Airbus",
			"A330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_330_200_AIRBUS = new AircraftTypeModelCode(
			"A-330-200 Airbus",
			"A33020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_330_300_AIRBUS = new AircraftTypeModelCode(
			"A-330-300 Airbus",
			"A33030",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_340_AIRBUS = new AircraftTypeModelCode(
			"A-340 Airbus",
			"A340",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_340_400_AIRBUS = new AircraftTypeModelCode(
			"A-340-400 Airbus",
			"A34040",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_340_8000_AIRBUS = new AircraftTypeModelCode(
			"A-340-8000 Airbus",
			"A34080",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_36_HALCON = new AircraftTypeModelCode(
			"A-36 Halcon",
			"A36H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_36_TC = new AircraftTypeModelCode(
			"A-36 TC",
			"A36TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_360_AIRBUS = new AircraftTypeModelCode(
			"A-360 Airbus",
			"A360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_37_DRAGONFLY = new AircraftTypeModelCode(
			"A-37 Dragonfly",
			"A37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_37A_DRAGONFLY = new AircraftTypeModelCode(
			"A-37A Dragonfly",
			"A37A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_37B_DRAGONFLY = new AircraftTypeModelCode(
			"A-37B Dragonfly",
			"A37B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_3A_SKYWARRIOR = new AircraftTypeModelCode(
			"A-3A Skywarrior",
			"A3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_3B_SKYWARRIOR = new AircraftTypeModelCode(
			"A-3B Skywarrior",
			"A3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4_SKYHAWK = new AircraftTypeModelCode(
			"A-4 Skyhawk",
			"A4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_45 = new AircraftTypeModelCode(
			"A-45",
			"BERA45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4A_SKYHAWK = new AircraftTypeModelCode(
			"A-4A Skyhawk",
			"A4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4B_SKYHAWK = new AircraftTypeModelCode(
			"A-4B Skyhawk",
			"A4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4C_SKYHAWK = new AircraftTypeModelCode(
			"A-4C Skyhawk",
			"A4C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4D_SKYHAWK = new AircraftTypeModelCode(
			"A-4D Skyhawk",
			"A4D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4E_SKYHAWK = new AircraftTypeModelCode(
			"A-4E Skyhawk",
			"A4E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4F_SKYHAWK = new AircraftTypeModelCode(
			"A-4F Skyhawk",
			"A4F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4G_SKYHAWK = new AircraftTypeModelCode(
			"A-4G Skyhawk",
			"A4G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4H_SKYHAWK = new AircraftTypeModelCode(
			"A-4H Skyhawk",
			"A4H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4J_SKYHAWK = new AircraftTypeModelCode(
			"A-4J Skyhawk",
			"A4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4K_SKYHAWK = new AircraftTypeModelCode(
			"A-4K Skyhawk",
			"A4K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4KU_SKYHAWK = new AircraftTypeModelCode(
			"A-4KU Skyhawk",
			"A4KU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4L_SKYHAWK = new AircraftTypeModelCode(
			"A-4L Skyhawk",
			"A4L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4M_SKYHAWK = new AircraftTypeModelCode(
			"A-4M Skyhawk",
			"A4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4N_SKYHAWK = new AircraftTypeModelCode(
			"A-4N Skyhawk",
			"A4N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4P_SKYHAWK = new AircraftTypeModelCode(
			"A-4P Skyhawk",
			"A4P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4Q_SKYHAWK = new AircraftTypeModelCode(
			"A-4Q Skyhawk",
			"A4Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4S_SKYHAWK_A_4S_SUPER_SKYHAWK = new AircraftTypeModelCode(
			"A-4S Skyhawk / A-4S Super Skyhawk",
			"A4S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_4SU_SKYHAWK = new AircraftTypeModelCode(
			"A-4SU Skyhawk",
			"A4SU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_5_FANTAN = new AircraftTypeModelCode(
			"A-5 Fantan",
			"A5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_50I_LAI_MAINSTAY = new AircraftTypeModelCode(
			"A-50I LAI Mainstay",
			"A501",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_5M_ALENIA_Q_5_LI_A_5M_VIGILANTE = new AircraftTypeModelCode(
			"A-5M Alenia Q-5 LI / A-5M Vigilante",
			"A5M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6_INTRUDER = new AircraftTypeModelCode(
			"A-6 Intruder",
			"A6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6A_INTRUDER = new AircraftTypeModelCode(
			"A-6A Intruder",
			"A6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6B_INTRUDER = new AircraftTypeModelCode(
			"A-6B Intruder",
			"A6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6C_INTRUDER = new AircraftTypeModelCode(
			"A-6C Intruder",
			"A6C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6E_INTRUDER = new AircraftTypeModelCode(
			"A-6E Intruder",
			"A6E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6F_INTRUDER_II = new AircraftTypeModelCode(
			"A-6F Intruder II",
			"A6F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_6G_INTRUDER = new AircraftTypeModelCode(
			"A-6G Intruder",
			"A6G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7_CORSAIR_II = new AircraftTypeModelCode(
			"A-7 Corsair II",
			"A7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7A_CORSAIR_II = new AircraftTypeModelCode(
			"A-7A Corsair II",
			"A7A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7B_CORSAIR_II = new AircraftTypeModelCode(
			"A-7B Corsair II",
			"A7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7C_CORSAIR_II = new AircraftTypeModelCode(
			"A-7C Corsair II",
			"A7C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7D_CORSAIR_II = new AircraftTypeModelCode(
			"A-7D Corsair II",
			"A7D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7E_CORSAIR_II = new AircraftTypeModelCode(
			"A-7E Corsair II",
			"A7E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7G_CORSAIR_II = new AircraftTypeModelCode(
			"A-7G Corsair II",
			"A7G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7H_CORSAIR_II = new AircraftTypeModelCode(
			"A-7H Corsair II",
			"A7H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7K_CORSAIR_II = new AircraftTypeModelCode(
			"A-7K Corsair II",
			"A7K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode A_7P_CORSAIR_II = new AircraftTypeModelCode(
			"A-7P Corsair II",
			"A7P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AA_1B_TRAINER = new AircraftTypeModelCode(
			"AA-1B Trainer",
			"AA1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AASI_ML_1_ML_2_JETCRUZER_500 = new AircraftTypeModelCode(
			"AASI / Ml-1 / Ml-2 Jetcruzer 500",
			"JCR500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AASI_ML_4_JETCRUZER_650 = new AircraftTypeModelCode(
			"AASI / Ml-4 / Jetcruzer 650",
			"JCR650",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AASI_ML_5_STRATOCRUZER_1250_ER = new AircraftTypeModelCode(
			"AASI / Ml-5 Stratocruzer 1250-ER",
			"SCR125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AASI_JETCRUTER_450 = new AircraftTypeModelCode(
			"AASI Jetcruter 450",
			"JCR450",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AAT_L_235_BALBUZARD = new AircraftTypeModelCode(
			"AAT L-235 Balbuzard",
			"L235BB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_204_AGUSTA_BELL_HELICOPTER = new AircraftTypeModelCode(
			"AB-204 Agusta-Bell Helicopter",
			"AB204",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_204A_AGUSTA_BELL_HELICOPTER = new AircraftTypeModelCode(
			"AB-204A Agusta Bell Helicopter",
			"AB204A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_204B_AGUSTA_BELL_HELICOPTER = new AircraftTypeModelCode(
			"AB-204B Agusta Bell Helicopter",
			"AB204B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_205_AGUSTA_BELL_UH_LHP_HUEY_II = new AircraftTypeModelCode(
			"AB-205 Agusta Bell / UH-LHP Huey II",
			"AB205",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_205A_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-205A Agusta Bell",
			"AB205A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_206_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-206 Agusta Bell",
			"AB206",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_206A_JETRANGER_AGUSTA_BELL_A = new AircraftTypeModelCode(
			"AB-206A Jetranger / Agusta Bell A",
			"AB206A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_206B_JETRANGER_AGUSTA_BELL_B = new AircraftTypeModelCode(
			"AB-206b Jetranger / Agusta Bell B",
			"AB206B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_206L_JETRANGER_AGUSTA_BELL_L = new AircraftTypeModelCode(
			"AB-206l Jetranger / Agusta Bell L",
			"AB206L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_209_HUEY_COBRA = new AircraftTypeModelCode(
			"AB-209 Huey Cobra",
			"AB209",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212 = new AircraftTypeModelCode(
			"AB-212",
			"A212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-212 Agusta Bell",
			"AB212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212_ASW_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-212 Asw Agusta-Bell",
			"A212A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212_MARTE_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-212 Marte Agusta Bell",
			"AB212M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212_OTOMAT_MK_2 = new AircraftTypeModelCode(
			"AB-212 Otomat MK-2",
			"AB212O",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212A_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-212A Agusta Bell",
			"AB212A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_212C_SKUA_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-212C Skua Agusta Bell",
			"AB212C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_214_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-214 Agusta-Bell",
			"AB214",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_214A_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-214A Agusta-Bell",
			"AB214A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_214B_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-214B Agusta-Bell",
			"AB214B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_214C_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-214C Agusta-Bell",
			"AB214C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_214ST_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-214ST Agusta-Bell",
			"AB214S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_222_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-222 Agusta-Bell",
			"AB222",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_406_COMBAT_SCOUT = new AircraftTypeModelCode(
			"AB-406 Combat Scout",
			"AB406",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_412_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-412 Agusta-Bell",
			"AB412",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_47_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-47 Agusta Bell",
			"AB47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_47_SIOUX = new AircraftTypeModelCode(
			"AB-47 Sioux",
			"AB47SX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_47G_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-47G Agusta-Bell",
			"AB47G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AB_47J_AGUSTA_BELL = new AircraftTypeModelCode(
			"AB-47J Agusta Bell",
			"AB47J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ABC_A_120_LIGHTSHIP = new AircraftTypeModelCode(
			"ABC A-120 Lightship",
			"A120LS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ABC_A_60_PLUS_LIGHTSHIP = new AircraftTypeModelCode(
			"ABC A-60 Plus Lightship",
			"A60PLS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_05_PIJAO = new AircraftTypeModelCode(
			"AC-05 Pijao",
			"AC05",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_119_STINGER = new AircraftTypeModelCode(
			"AC-119 Stinger",
			"AC119",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_119K = new AircraftTypeModelCode(
			"AC-119K",
			"AC119K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_130_SPECTRE = new AircraftTypeModelCode(
			"AC-130 Spectre",
			"AC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_130A_SPECTRE = new AircraftTypeModelCode(
			"AC-130A Spectre",
			"AC130A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_130H_SPECTRE = new AircraftTypeModelCode(
			"AC-130H Spectre",
			"AC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_130U_SPECTRE_AC_130U_SPOOKY = new AircraftTypeModelCode(
			"AC-130U Spectre / AC-130U Spooky",
			"AC130U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AC_47_SPOOKY = new AircraftTypeModelCode(
			"AC-47 Spooky",
			"AC47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ACRO_HUSKY_A_1 = new AircraftTypeModelCode(
			"ACRO-Husky A-1",
			"HUS1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ADA_LCA = new AircraftTypeModelCode(
			"ADA LCA",
			"ADA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_100 = new AircraftTypeModelCode(
			"AE-100",
			"AE100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_206_MISTRAL = new AircraftTypeModelCode(
			"AE-206 Mistral",
			"AE206",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_207_MISTRAL_TWIN = new AircraftTypeModelCode(
			"AE-207 Mistral Twin",
			"AE207",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_209_ALBATROS = new AircraftTypeModelCode(
			"AE-209 Albatros",
			"AE209",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_270_IBIS = new AircraftTypeModelCode(
			"AE-270 Ibis",
			"AE270",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_316 = new AircraftTypeModelCode(
			"AE-316",
			"AE316",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AE_317 = new AircraftTypeModelCode(
			"AE-317",
			"AE317",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEDECO_NOGA_VI = new AircraftTypeModelCode(
			"Aedeco Noga VI",
			"NOGA6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERITALIA_ATR_42 = new AircraftTypeModelCode(
			"Aeritalia ATR-42",
			"ATR42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERITALIA_ATR_42_100 = new AircraftTypeModelCode(
			"Aeritalia ATR-42 100",
			"ATR421",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERITALIA_ATR_42_200 = new AircraftTypeModelCode(
			"Aeritalia ATR-42 200",
			"ATR422",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERITALIA_ATR_42_300 = new AircraftTypeModelCode(
			"Aeritalia ATR-42 300",
			"ATR423",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_260AG = new AircraftTypeModelCode(
			"Aero 260AG",
			"AB260",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_COMMANDER = new AircraftTypeModelCode(
			"Aero Commander",
			"ACMD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_COMMANDER_500 = new AircraftTypeModelCode(
			"Aero Commander 500",
			"C0M500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_COMMANDER_600 = new AircraftTypeModelCode(
			"Aero Commander 600",
			"C0M600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_SPACELINES_MINI_GUPPY = new AircraftTypeModelCode(
			"Aero Spacelines Mini Guppy",
			"AP3M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_SPACELINES_PREGNANT_GUPPY = new AircraftTypeModelCode(
			"Aero Spacelines Pregnant Guppy",
			"AP1P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_SPACELINES_SUPER_GUPPY = new AircraftTypeModelCode(
			"Aero Spacelines Super Guppy",
			"AP2S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AERO_SPACELINES_SUPER_TURBINE_GUPPY = new AircraftTypeModelCode(
			"Aero Spacelines Super Turbine Guppy",
			"AP4S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROS_50 = new AircraftTypeModelCode(
			"Aeros 50",
			"AER50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_CORVETTE_SN600 = new AircraftTypeModelCode(
			"Aerospatiale Corvette SN600",
			"S600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_RALLYE_COMMODORE_SERIES_MS892 = new AircraftTypeModelCode(
			"Aerospatiale Rallye Commodore Series MS892",
			"S892",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_RALLYE_MINERVA_SERIES_MS894 = new AircraftTypeModelCode(
			"Aerospatiale Rallye Minerva Series MS894",
			"S894",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_TABAGO_TB_10_TOBAGO = new AircraftTypeModelCode(
			"Aerospatiale Tabago / TB-10 Tobago",
			"TB10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_TAMPICO = new AircraftTypeModelCode(
			"Aerospatiale Tampico",
			"TB9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_TRINIDAD_TB_20_TRINIDAD = new AircraftTypeModelCode(
			"Aerospatiale Trinidad / TB-20 Trinidad",
			"TB20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_TRINIDAD_TC_TB_21_TRINIDAD_TC = new AircraftTypeModelCode(
			"Aerospatiale Trinidad TC / TB-21 Trinidad TC",
			"TB21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEROSPATIALE_TWIN_STAR = new AircraftTypeModelCode(
			"Aerospatiale Twin Star",
			"HR55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEW_MK_3_NIMROD = new AircraftTypeModelCode(
			"AEW MK-3 Nimrod",
			"NIMMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEW_MK7_SEA_KING = new AircraftTypeModelCode(
			"AEW MK7 Sea King",
			"SKMK7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEW_2_SHACKLETON = new AircraftTypeModelCode(
			"AEW-2 Shackleton",
			"AEW2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AEW_MK2A_SEA_KING = new AircraftTypeModelCode(
			"AEW-MK2A Sea King",
			"SKMK2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AG_6_FINIST_SM_92 = new AircraftTypeModelCode(
			"AG-6 Finist / SM-92",
			"AG6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AGUSTA_BELL_205B = new AircraftTypeModelCode(
			"Agusta Bell 205B",
			"AB205B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AGUSTA_BELL_206L_3_LONGRANGER_III = new AircraftTypeModelCode(
			"Agusta Bell 206L-3 / Longranger III",
			"AB2063",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AGUSTA_BELL_206L_4_LONGRANGER_IV = new AircraftTypeModelCode(
			"Agusta Bell 206L-4 / Longranger IV",
			"AB2064",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1 Huey Cobra",
			"AH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1_LYNX = new AircraftTypeModelCode(
			"AH-1 Lynx",
			"AH1LX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_12_WASP = new AircraftTypeModelCode(
			"AH-12 Wasp",
			"AH12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_12A_WASP = new AircraftTypeModelCode(
			"AH-12A Wasp",
			"AH12A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1E_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1E Huey Cobra",
			"AH1E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1F_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1F Huey Cobra",
			"AH1F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1G_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1G Huey Cobra",
			"AH1G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1J_SEA_COBRA = new AircraftTypeModelCode(
			"AH-1J Sea Cobra",
			"AH1J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1P = new AircraftTypeModelCode(
			"AH-1P",
			"AH1P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1Q_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1Q Huey Cobra",
			"AH1Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1R_HUEY_COBRA = new AircraftTypeModelCode(
			"AH-1R Huey Cobra",
			"AH1R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1RO_DRACULA = new AircraftTypeModelCode(
			"AH-1RO Dracula",
			"AH1RO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1S_HUEY_COBRA_AH_1F = new AircraftTypeModelCode(
			"AH-1S Huey Cobra / AH-1F",
			"AH1S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1T_SEA_COBRA = new AircraftTypeModelCode(
			"AH-1T Sea Cobra",
			"AH1TSC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1W_HUEY_COBRA_SUPER_COBRA = new AircraftTypeModelCode(
			"AH-1W Huey Cobra / Super Cobra",
			"AH1W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_1W_SEA_COBRA = new AircraftTypeModelCode(
			"AH-1W Sea Cobra",
			"AH1WSC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_58D_COMBAT_SCOUT_WARRIOR = new AircraftTypeModelCode(
			"AH-58D Combat Scout / Warrior",
			"AH58D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6_MD_500_DEFENDER_MD_530_DEFENDER = new AircraftTypeModelCode(
			"AH-6 / MD-500 Defender / Md-530 Defender",
			"MD500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6_CAYUSE = new AircraftTypeModelCode(
			"AH-6 Cayuse",
			"AH6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_60L_MH_60L = new AircraftTypeModelCode(
			"AH-60L / Mh-60l",
			"MH60L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_64_APACHE = new AircraftTypeModelCode(
			"AH-64 Apache",
			"AH64",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_64A_APACHE = new AircraftTypeModelCode(
			"AH-64A Apache",
			"AH64A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_64C_APACHE = new AircraftTypeModelCode(
			"AH-64C Apache",
			"AH64C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_64D_APACHE_LONGBOW = new AircraftTypeModelCode(
			"AH-64D Apache Longbow",
			"AH64D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6C_DEFENDER = new AircraftTypeModelCode(
			"AH-6C Defender",
			"AH6C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6F = new AircraftTypeModelCode(
			"AH-6F",
			"AH6F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6G = new AircraftTypeModelCode(
			"AH-6G",
			"AH6G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_6J = new AircraftTypeModelCode(
			"AH-6J",
			"AH6J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_7_LYNX = new AircraftTypeModelCode(
			"AH-7 Lynx",
			"AH7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AH_70_BLACKHAWK = new AircraftTypeModelCode(
			"AH-70 Blackhawk",
			"AH70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AHMK_1_LYNX = new AircraftTypeModelCode(
			"AHMK-1 Lynx",
			"AHMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AHMK_5_LYNX = new AircraftTypeModelCode(
			"AHMK-5 Lynx",
			"AHMK5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AHMK_6 = new AircraftTypeModelCode(
			"AHMK-6",
			"AHMK6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AHMK_7_LYNX = new AircraftTypeModelCode(
			"AHMK-7 Lynx",
			"AHMK7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AHMK_9_BATTLEFIELD_LYNX = new AircraftTypeModelCode(
			"AHMK-9 Battlefield Lynx",
			"AHMK9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AIR_BEETLE = new AircraftTypeModelCode(
			"Air Beetle",
			"AIEP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AIRFOX_ALOUETTE_III = new AircraftTypeModelCode(
			"Airfox Alouette III",
			"AFX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AIRSHIP = new AircraftTypeModelCode(
			"Airship",
			"AIRS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AIRTRAINER_CT4 = new AircraftTypeModelCode(
			"Airtrainer CT4",
			"CT4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AJ_37_VIGGEN = new AircraftTypeModelCode(
			"AJ-37 Viggen",
			"AJ37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AJS_37_VIGGEN_SK_60 = new AircraftTypeModelCode(
			"AJS-37 Viggen Sk 60",
			"AJS37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AL_1 = new AircraftTypeModelCode(
			"AL-1",
			"ALI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AL_1_BEAVER = new AircraftTypeModelCode(
			"AL-1 Beaver",
			"AL1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AL_1A = new AircraftTypeModelCode(
			"AL-1A",
			"AL1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AL_60_AERMACCHI = new AircraftTypeModelCode(
			"AL-60 Aermacchi",
			"AL60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AL_60B_AERMACCHI = new AircraftTypeModelCode(
			"AL-60B Aermacchi",
			"AL60B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALA_100 = new AircraftTypeModelCode(
			"ALA-100",
			"ALA100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALA_300 = new AircraftTypeModelCode(
			"ALA-300",
			"ALA300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALA_40 = new AircraftTypeModelCode(
			"ALA-40",
			"ALA40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALA_600 = new AircraftTypeModelCode(
			"ALA-600",
			"ALA600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALIZM_MOD = new AircraftTypeModelCode(
			"ALIZM Mod",
			"ALIZM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALON_AIRCOUPE_A2 = new AircraftTypeModelCode(
			"ALON Aircoupe A2",
			"F02",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALPHA_JET = new AircraftTypeModelCode(
			"Alpha Jet",
			"ALPHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALPHA_JET_MS_1 = new AircraftTypeModelCode(
			"Alpha Jet MS-1",
			"ALPHA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALPHA_JET_MS_2 = new AircraftTypeModelCode(
			"Alpha Jet MS-2",
			"ALPHA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ALPHA_JET_TRAINER = new AircraftTypeModelCode(
			"Alpha Jet Trainer",
			"ALPHAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AM_3C_KUDU = new AircraftTypeModelCode(
			"AM-3C Kudu",
			"AM3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMD_FALCON_10 = new AircraftTypeModelCode(
			"AMD Falcon 10",
			"FAL10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMD_FALCON_20 = new AircraftTypeModelCode(
			"AMD Falcon 20",
			"FAL20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMD_FALCON_50 = new AircraftTypeModelCode(
			"AMD Falcon 50",
			"FAL50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMD_FALCON_900 = new AircraftTypeModelCode(
			"AMD Falcon 900",
			"FAL900",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMH = new AircraftTypeModelCode(
			"AMH",
			"AMH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMT_100_XIMANGO = new AircraftTypeModelCode(
			"AMT-100 Ximango",
			"AMT100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AMT_200_SUPER_XIMANGO = new AircraftTypeModelCode(
			"AMT-200 Super Ximango",
			"AMT200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_10 = new AircraftTypeModelCode(
			"An-10",
			"AN10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_10_CAT = new AircraftTypeModelCode(
			"AN-10 Cat",
			"CAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_114 = new AircraftTypeModelCode(
			"AN-114",
			"AN114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_114_CLOD = new AircraftTypeModelCode(
			"AN-114 Clod",
			"CLD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12 = new AircraftTypeModelCode(
			"AN-12",
			"AN12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12_CUB = new AircraftTypeModelCode(
			"AN-12 Cub",
			"CUB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12_CUB_A = new AircraftTypeModelCode(
			"AN-12 Cub A",
			"CUBA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12_CUB_B = new AircraftTypeModelCode(
			"AN-12 Cub B",
			"CUBB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12_CUB_C = new AircraftTypeModelCode(
			"AN-12 Cub C",
			"CUBC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_12_CUB_D = new AircraftTypeModelCode(
			"AN-12 Cub D",
			"CUBD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124 = new AircraftTypeModelCode(
			"AN-124",
			"AN124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124_CONDOR = new AircraftTypeModelCode(
			"AN-124 Condor",
			"CDR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124_CONDOR_A = new AircraftTypeModelCode(
			"AN-124 Condor A",
			"CDRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124_100 = new AircraftTypeModelCode(
			"AN-124-100",
			"AN1241",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124_100M = new AircraftTypeModelCode(
			"AN-124-100M",
			"AN124M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_124_130 = new AircraftTypeModelCode(
			"AN-124-130",
			"AN1243",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_14_CLOD = new AircraftTypeModelCode(
			"AN-14 Clod",
			"AN14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_140 = new AircraftTypeModelCode(
			"AN-140",
			"AN140",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_180 = new AircraftTypeModelCode(
			"AN-180",
			"AN180",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_2 = new AircraftTypeModelCode(
			"AN-2",
			"AN2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_2_COLT = new AircraftTypeModelCode(
			"AN-2 Colt",
			"CLT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_22_AN_22_ANTHEUS = new AircraftTypeModelCode(
			"AN-22 / AN-22 Antheus",
			"AN22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_22_COCK = new AircraftTypeModelCode(
			"AN-22 Cock",
			"COC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_22_COCK_A = new AircraftTypeModelCode(
			"AN-22 Cock A",
			"AN22A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_22_COCK_B = new AircraftTypeModelCode(
			"AN-22 Cock B",
			"AN22B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_225_AN_225_MRIYA_DREAM = new AircraftTypeModelCode(
			"AN-225 / AN-225 Mriya / Dream",
			"AN225",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_24 = new AircraftTypeModelCode(
			"AN-24",
			"AN24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_24_COKE = new AircraftTypeModelCode(
			"AN-24 Coke",
			"COK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26 = new AircraftTypeModelCode(
			"AN-26",
			"AN26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26_CURL = new AircraftTypeModelCode(
			"AN-26 Curl",
			"CUR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26_CURL_A = new AircraftTypeModelCode(
			"AN-26 Curl A",
			"AN26A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26B = new AircraftTypeModelCode(
			"AN-26B",
			"AN26B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26B_CURL = new AircraftTypeModelCode(
			"AN-26B Curl",
			"CURB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_26RTR = new AircraftTypeModelCode(
			"AN-26RTR",
			"AN26RT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28 = new AircraftTypeModelCode(
			"AN-28",
			"AN28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28_CASH = new AircraftTypeModelCode(
			"AN-28 Cash",
			"CSH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28_CASH_A = new AircraftTypeModelCode(
			"AN-28 Cash A",
			"CSHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28RM1 = new AircraftTypeModelCode(
			"AN-28RM1",
			"AN28R1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28RM2 = new AircraftTypeModelCode(
			"AN-28RM2",
			"AN28R2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_28TD = new AircraftTypeModelCode(
			"AN-28TD",
			"AN28TD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_30 = new AircraftTypeModelCode(
			"AN-30",
			"AN30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_30_CLANK = new AircraftTypeModelCode(
			"AN-30 Clank",
			"CLK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_30A_CLANK = new AircraftTypeModelCode(
			"AN-30A Clank",
			"CLKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_32_CLINE = new AircraftTypeModelCode(
			"AN-32 Cline",
			"CLN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_32_CLINE_A = new AircraftTypeModelCode(
			"AN-32 Cline A",
			"CLNA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_32B_CLINE = new AircraftTypeModelCode(
			"AN-32B Cline",
			"AN32B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_32P_FIREKILLER = new AircraftTypeModelCode(
			"AN-32P Firekiller",
			"AN32P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_38 = new AircraftTypeModelCode(
			"AN-38",
			"AN38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_38_200 = new AircraftTypeModelCode(
			"AN-38-200",
			"AN3820",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_38K = new AircraftTypeModelCode(
			"AN-38K",
			"AN38K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_4 = new AircraftTypeModelCode(
			"AN-4",
			"AN4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_40_VERY_LARGE_TURBOPROP = new AircraftTypeModelCode(
			"AN-40 Very Large Turboprop",
			"AN40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_70_COALER = new AircraftTypeModelCode(
			"AN-70 Coaler",
			"AN70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_70_100 = new AircraftTypeModelCode(
			"AN-70-100",
			"AN7010",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_70T = new AircraftTypeModelCode(
			"AN-70T",
			"AN70T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_70T_100 = new AircraftTypeModelCode(
			"AN-70T-100",
			"AN70T1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_70TK = new AircraftTypeModelCode(
			"AN-70TK",
			"AN70TK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_71_MADCAP = new AircraftTypeModelCode(
			"AN-71 Madcap",
			"AN71",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72 = new AircraftTypeModelCode(
			"AN-72",
			"AN72",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72_COALER = new AircraftTypeModelCode(
			"AN-72 Coaler",
			"CLR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72_COALER_A = new AircraftTypeModelCode(
			"AN-72 Coaler A",
			"CLRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72_COALER_C = new AircraftTypeModelCode(
			"AN-72 Coaler C",
			"CLRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72A = new AircraftTypeModelCode(
			"AN-72A",
			"AN72A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72P = new AircraftTypeModelCode(
			"AN-72P",
			"AN72P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_72S_COALER_C = new AircraftTypeModelCode(
			"AN-72S Coaler C",
			"AN72S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74 = new AircraftTypeModelCode(
			"AN-74",
			"AN74",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74_COALER_B = new AircraftTypeModelCode(
			"AN-74 Coaler B",
			"CLRB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74_COALER_C = new AircraftTypeModelCode(
			"AN-74 Coaler C",
			"AN74C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74_MADCAP = new AircraftTypeModelCode(
			"AN-74 Madcap",
			"AN74MC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74_SALON = new AircraftTypeModelCode(
			"AN-74 Salon",
			"AN74SA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74_200 = new AircraftTypeModelCode(
			"AN-74-200",
			"AN7420",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74A_COALER_B = new AircraftTypeModelCode(
			"AN-74A Coaler B",
			"AN74AB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74A_COALER_C = new AircraftTypeModelCode(
			"AN-74A Coaler C",
			"AN74AC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74AT_COALER_B = new AircraftTypeModelCode(
			"AN-74AT Coaler B",
			"AN74TB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74AT_COALER_C = new AircraftTypeModelCode(
			"AN-74AT Coaler C",
			"AN74TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74S_COALER_B = new AircraftTypeModelCode(
			"AN-74S Coaler B",
			"AN74SB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74T_100 = new AircraftTypeModelCode(
			"AN-74T-100",
			"AN74T1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74T_200 = new AircraftTypeModelCode(
			"AN-74T-200",
			"AN74T2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74TK_100 = new AircraftTypeModelCode(
			"AN-74TK-100",
			"AN74K1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_74TK_200 = new AircraftTypeModelCode(
			"AN-74TK-200",
			"AN74K2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_8 = new AircraftTypeModelCode(
			"AN-8",
			"AN8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AN_8_CAMP = new AircraftTypeModelCode(
			"AN-8 Camp",
			"CMP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANDOVER_C_1 = new AircraftTypeModelCode(
			"Andover C-1",
			"ANC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANDOVER_C_2 = new AircraftTypeModelCode(
			"Andover C-2",
			"ANC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANDOVER_CC_2 = new AircraftTypeModelCode(
			"Andover CC-2",
			"ANCC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANDOVER_E_3 = new AircraftTypeModelCode(
			"Andover E-3",
			"ANE3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANDOVER_E_3A = new AircraftTypeModelCode(
			"Andover E-3A",
			"ANDE3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ANSAT = new AircraftTypeModelCode(
			"ANSAT",
			"ANSAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AP_68TP_600_VIATOR_AP_68TP = new AircraftTypeModelCode(
			"AP-68TP 600 / Viator AP-68TP",
			"AP68TP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode APM_20 = new AircraftTypeModelCode(
			"APM 20",
			"APM20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ARA_3600 = new AircraftTypeModelCode(
			"ARA 3600",
			"ARA360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ARGOSY = new AircraftTypeModelCode(
			"Argosy",
			"ARGOSY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ARGOSY_E_1 = new AircraftTypeModelCode(
			"Argosy E-1",
			"AGSYE1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ARL_24 = new AircraftTypeModelCode(
			"ARL-24",
			"ARL24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ARROW_PA_28R_201 = new AircraftTypeModelCode(
			"Arrow PA-28R-201",
			"PA28R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_2 = new AircraftTypeModelCode(
			"AS 2",
			"AS2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_300 = new AircraftTypeModelCode(
			"AS 300",
			"AS300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_365N2_DAUPHIN_2 = new AircraftTypeModelCode(
			"AS 365N2 Dauphin 2",
			"AS332N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_105_MK_II = new AircraftTypeModelCode(
			"AS-105 MK II",
			"AS1052",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_202_BRAVO = new AircraftTypeModelCode(
			"AS-202 Bravo",
			"AS202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_202_32_TP_SUPER_BRAVO = new AircraftTypeModelCode(
			"AS-202/32 TP Super Bravo",
			"AS2023",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332_SUPER_PUMA = new AircraftTypeModelCode(
			"AS-332 Super Puma",
			"AS332",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332B_SUPER_FRELON = new AircraftTypeModelCode(
			"AS-332B Super Frelon",
			"AS332B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332C_SUPER_FRELON = new AircraftTypeModelCode(
			"AS-332C Super Frelon",
			"AS332C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332F_SUPER_FRELON = new AircraftTypeModelCode(
			"AS-332F Super Frelon",
			"AS332F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332F_SUPER_PUMA = new AircraftTypeModelCode(
			"AS-332F Super Puma",
			"AS332S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332L_SUPER_FRELON = new AircraftTypeModelCode(
			"AS-332L Super Frelon",
			"AS332L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332L1_SUPER_PUMA_MK_I = new AircraftTypeModelCode(
			"AS-332L1 Super Puma MK I",
			"AS32L1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332L2_SUPER_PUMA_MK_II = new AircraftTypeModelCode(
			"AS-332L2 Super Puma MK II",
			"AS32L2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_332M_SUPER_FRELON = new AircraftTypeModelCode(
			"AS-332M Super Frelon",
			"AS332M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350_ECUREUIL = new AircraftTypeModelCode(
			"AS-350 Ecureuil",
			"AS350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350B_ECUREUIL = new AircraftTypeModelCode(
			"AS-350B Ecureuil",
			"AS350B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350B2_SUPER_STAR = new AircraftTypeModelCode(
			"AS-350B2 Super Star",
			"AS3502",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350B3 = new AircraftTypeModelCode(
			"AS-350B3",
			"AS3503",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350BB_HT_MK_1_MK_2_SQUIRREL = new AircraftTypeModelCode(
			"AS-350BB HT.MK 1 / MK 2 Squirrel",
			"AS350M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350C_ASTAR = new AircraftTypeModelCode(
			"AS-350C Astar",
			"AS350C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350D_ASTAR = new AircraftTypeModelCode(
			"AS-350D Astar",
			"AS350D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350E_ECUREUIL = new AircraftTypeModelCode(
			"AS-350E Ecureuil",
			"AS350E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350E = new AircraftTypeModelCode(
			"AS-350E",
			"AS350F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_350L_ECUREUIL = new AircraftTypeModelCode(
			"AS-350L Ecureuil",
			"AS350L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_355_ECUREUIL = new AircraftTypeModelCode(
			"AS-355 Ecureuil",
			"AS355",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_355B_ECUREUIL = new AircraftTypeModelCode(
			"AS-355B Ecureuil",
			"AS355B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_355F_ECUREUIL = new AircraftTypeModelCode(
			"AS-355F Ecureuil",
			"AS355F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_355F1 = new AircraftTypeModelCode(
			"AS-355F1",
			"AS3551",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_355M_ECUREUIL = new AircraftTypeModelCode(
			"AS-355M Ecureuil",
			"AS355M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_366G_DOLPHIN_II = new AircraftTypeModelCode(
			"AS-366G Dolphin II",
			"AS366G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_532_COUGAR = new AircraftTypeModelCode(
			"AS-532 Cougar",
			"AS532",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_532_COUGAR_MK_I = new AircraftTypeModelCode(
			"AS-532 Cougar MK I",
			"AS5321",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_532_COUGAR_MK1_HORIZON = new AircraftTypeModelCode(
			"AS-532 Cougar MK1 Horizon",
			"AS532H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_532_CS_SUPER_PUMA = new AircraftTypeModelCode(
			"AS-532 CS Super Puma",
			"AS532C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_532_MK_II_SUPER_PUMA = new AircraftTypeModelCode(
			"AS-532 MK II Super Puma",
			"AS5322",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_550_FENNEC_AS_350B2 = new AircraftTypeModelCode(
			"AS-550 Fennec / AS-350B2",
			"AS550",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_555_FENNEC = new AircraftTypeModelCode(
			"AS-555 Fennec",
			"AS555",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_555AN_FENNEC = new AircraftTypeModelCode(
			"AS-555AN Fennec",
			"AS555A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_555UN_FENNEC = new AircraftTypeModelCode(
			"AS-555UN Fennec",
			"AS555U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565_MA_PANTHER = new AircraftTypeModelCode(
			"AS-565 MA Panther",
			"AS565M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565_PANTHER = new AircraftTypeModelCode(
			"AS-565 Panther",
			"AS565",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565AA_PANTHER = new AircraftTypeModelCode(
			"AS-565AA Panther",
			"AS565A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565AB = new AircraftTypeModelCode(
			"AS-565AB",
			"AS565B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565CA_PANTHER = new AircraftTypeModelCode(
			"AS-565CA Panther",
			"AS565C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565SB = new AircraftTypeModelCode(
			"AS-565SB",
			"AS565S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_565UA_PANTHER = new AircraftTypeModelCode(
			"AS-565UA Panther",
			"AS565U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61_SH_3_SEA_KING = new AircraftTypeModelCode(
			"AS-61 / SH-3 Sea King",
			"AS6ISK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61_SEA_KING = new AircraftTypeModelCode(
			"AS-61 Sea King",
			"AS61SK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61_SIKORSKY = new AircraftTypeModelCode(
			"AS-61 Sikorsky",
			"AS61",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61A_SEA_KING = new AircraftTypeModelCode(
			"AS-61A Sea King",
			"AS61A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61N1_SIKORSKY = new AircraftTypeModelCode(
			"AS-61N1 Sikorsky",
			"AS61N1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61R_HH_3F = new AircraftTypeModelCode(
			"AS-61R / HH-3F",
			"AS61R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61TS = new AircraftTypeModelCode(
			"AS-61TS",
			"AS6ITS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_61TS_SEA_KING = new AircraftTypeModelCode(
			"AS-61TS Sea King",
			"AS61TS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_80_MK_II = new AircraftTypeModelCode(
			"AS-80 MK II",
			"AS80M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AS_90_MK_II = new AircraftTypeModelCode(
			"AS-90 MK II",
			"AS90M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ASTRA_SP_GALAXY = new AircraftTypeModelCode(
			"Astra SP Galaxy",
			"ASTRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_2000 = new AircraftTypeModelCode(
			"AT-2000",
			"AT2000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_26_XAVANTA_EMB_326_MB_326GC = new AircraftTypeModelCode(
			"AT-26 Xavanta / Emb-326 / MB-326GC",
			"AT26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_28_TROJAN = new AircraftTypeModelCode(
			"AT-28 Trojan",
			"AT28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_33_SHOOTING_STAR = new AircraftTypeModelCode(
			"AT-33 Shooting Star",
			"AT33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_37D = new AircraftTypeModelCode(
			"AT-37D",
			"AT37D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_38B_TALON = new AircraftTypeModelCode(
			"AT-38B Talon",
			"AT38B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_401_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-401 Air Tractor",
			"AT401",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_402_TURBO_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-402 Turbo Air Tractor",
			"AT402",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_502_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-502 Air Tractor",
			"AT502",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_502A_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-502A Air Tractor",
			"AT50A2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_503_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-503 Air Tractor",
			"AT503",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_6G_TEXAN = new AircraftTypeModelCode(
			"AT-6G Texan",
			"AT6G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_802_AIR_TRACTOR = new AircraftTypeModelCode(
			"AT-802 Air Tractor",
			"AT802",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATLANTIQUE_1150 = new AircraftTypeModelCode(
			"Atlantique 1150",
			"AT1150",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATLANTIQUE_2 = new AircraftTypeModelCode(
			"Atlantique 2",
			"ATL2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_42_MP = new AircraftTypeModelCode(
			"Atr 42 MP",
			"ATR42M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_42_SAR = new AircraftTypeModelCode(
			"Atr 42 SAR",
			"ATR42S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_42_400 = new AircraftTypeModelCode(
			"ATR 42-400",
			"ATR424",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_42_500 = new AircraftTypeModelCode(
			"ATR 42-500",
			"ATR425",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_42_F = new AircraftTypeModelCode(
			"ATR 42-F",
			"ATR42F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_52C_72_100 = new AircraftTypeModelCode(
			"ATR 52C / 72 -100",
			"ATR52C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_72_72_210 = new AircraftTypeModelCode(
			"ATR 72 / 72-210",
			"ATR72",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATR_72_72_200 = new AircraftTypeModelCode(
			"ATR 72 72-200",
			"ATR722",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ATTA_3000 = new AircraftTypeModelCode(
			"ATTA 3000",
			"ATTA30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_TC_3_TROJAN = new AircraftTypeModelCode(
			"AT-TC-3 Trojan",
			"ATTC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AT_TC_3_TSE_CHANG = new AircraftTypeModelCode(
			"AT-TC-3 Tse Chang",
			"ATTC3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AU_23_PEACEMAKER = new AircraftTypeModelCode(
			"AU-23 Peacemaker",
			"AU23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AU_23A_PEACEMAKER = new AircraftTypeModelCode(
			"AU-23A Peacemaker",
			"AU23A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AU_24_STALLION = new AircraftTypeModelCode(
			"AU-24 Stallion",
			"AU24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AU_24A_STALLION = new AircraftTypeModelCode(
			"AU-24A Stallion",
			"AU24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AUH_76_AGUSTA_BELL = new AircraftTypeModelCode(
			"AUH-76 Agusta-Bell",
			"AUH76",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AURORA_ARCTURUS_CP_140 = new AircraftTypeModelCode(
			"Aurora Arcturus / CP-140",
			"AUR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8_T_4_HARRIER_MK_4_HARRIER = new AircraftTypeModelCode(
			"AV-8 T-4 Harrier / MK 4 Harrier",
			"AV8T4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8A_HARRIER_GR_MK_3 = new AircraftTypeModelCode(
			"AV-8A Harrier / GR. MK 3",
			"AV8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8A_SEA_HARRIER = new AircraftTypeModelCode(
			"AV-8A Sea Harrier",
			"AV8AA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8B_GR_MK_5_ADVAN_HARRIER = new AircraftTypeModelCode(
			"AV-8B / GR. MK 5 Advan Harrier",
			"AV8BAH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8B_HARRIER_II = new AircraftTypeModelCode(
			"AV-8B Harrier II",
			"AV8B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8B_II_GR_MK_7_HARRIER_II = new AircraftTypeModelCode(
			"AV-8B II / Gr. MK 7 Harrier II",
			"AV8B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8B_II_PLUS = new AircraftTypeModelCode(
			"AV-8B II Plus",
			"AV8B2P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8C_HARRIER = new AircraftTypeModelCode(
			"AV-8C Harrier",
			"AV8C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AV_8S_MATADOR = new AircraftTypeModelCode(
			"AV-8S Matador",
			"AV8S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVIAT_A_1_HUSKY = new AircraftTypeModelCode(
			"Aviat A-1 Husky",
			"AVIAA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVIATIKA_890 = new AircraftTypeModelCode(
			"Aviatika 890",
			"AVIA89",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVIATIKA_900_ACROBAT = new AircraftTypeModelCode(
			"Aviatika 900 Acrobat",
			"AVIA90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVIATIKA_960 = new AircraftTypeModelCode(
			"Aviatika 960",
			"AVIA96",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVRO_ANSON_FEDERAL = new AircraftTypeModelCode(
			"Avro Anson / Federal",
			"AV52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVRO_CF_100 = new AircraftTypeModelCode(
			"Avro CF-100",
			"CF00",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVROLANCASTER = new AircraftTypeModelCode(
			"Avrolancaster",
			"LANC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AVTEK_400A = new AircraftTypeModelCode(
			"Avtek 400A",
			"AV400A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AW_1_FAN_TRAINER = new AircraftTypeModelCode(
			"AW-1 Fan Trainer",
			"AW1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AW_2_FAN_TRAINER = new AircraftTypeModelCode(
			"AW-2 Fan Trainer",
			"AW2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AYRES_600_THRUSH = new AircraftTypeModelCode(
			"Ayres 600 Thrush",
			"AY600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AYRES_700_TURBO_THRUSH = new AircraftTypeModelCode(
			"Ayres 700 Turbo Thrush",
			"AY700",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode AZTEC_APACHE_PIPER = new AircraftTypeModelCode(
			"Aztec Apache Piper",
			"AZTEC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_1_LANCER = new AircraftTypeModelCode(
			"B-1 Lancer",
			"B1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_100_KING_AIR_A100 = new AircraftTypeModelCode(
			"B-100 King Air A100",
			"B100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_BAC111 = new AircraftTypeModelCode(
			"B-111 BAC111",
			"BAC111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_200 = new AircraftTypeModelCode(
			"B-111-200",
			"B1112",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_300 = new AircraftTypeModelCode(
			"B-111-300",
			"B1113",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_400 = new AircraftTypeModelCode(
			"B-111-400",
			"B1114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_475 = new AircraftTypeModelCode(
			"B-111-475",
			"B11147",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_111_500 = new AircraftTypeModelCode(
			"B-111-500",
			"B1115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_1B_LANCER = new AircraftTypeModelCode(
			"B-1B Lancer",
			"B1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_2_SPIRIT = new AircraftTypeModelCode(
			"B-2 Spirit",
			"B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_2_SUPER_MYSTERE = new AircraftTypeModelCode(
			"B-2 Super Mystere",
			"B2SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_214ST_BELL_SUPER_TRANSPORT_AIRCRAFT_TYPE = new AircraftTypeModelCode(
			"B-214ST Bell Super Transport Aircraft Type",
			"B214ST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_2A_SPIRIT = new AircraftTypeModelCode(
			"B-2A Spirit",
			"B2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_350 = new AircraftTypeModelCode(
			"B-350",
			"B350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B36TC_TURBO_BONANZA = new AircraftTypeModelCode(
			"B36TC Turbo Bonanza",
			"B36TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_3LA_SAAB = new AircraftTypeModelCode(
			"B-3LA Saab",
			"B3LA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_47 = new AircraftTypeModelCode(
			"B-47",
			"B47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_5 = new AircraftTypeModelCode(
			"B-5",
			"B5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_52_STRATOFORTRESS = new AircraftTypeModelCode(
			"B-52 Stratofortress",
			"B52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_52G_STRATOFORTRESS = new AircraftTypeModelCode(
			"B-52G Stratofortress",
			"B52G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_52H_STRATOFORTRESS = new AircraftTypeModelCode(
			"B-52H Stratofortress",
			"B52H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_57_CANBERRA = new AircraftTypeModelCode(
			"B-57 Canberra",
			"B57",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_60 = new AircraftTypeModelCode(
			"B-60",
			"DUB60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_720_BOEING_B_7_XAC_JH_7 = new AircraftTypeModelCode(
			"B-720 Boeing / B-7 XAC JH-7",
			"B720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode B_720M_STRATOLINER_720 = new AircraftTypeModelCode(
			"B-720M Stratoliner 720",
			"B720M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_ONE_ELEVEN_SERIES = new AircraftTypeModelCode(
			"BAC One-Eleven Series",
			"B111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_VC10_C_MK_2_MK_3 = new AircraftTypeModelCode(
			"BAC VC10 C- MK 2 / MK 3",
			"VC10M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_111_2400 = new AircraftTypeModelCode(
			"BAC-111-2400",
			"BA2400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_111_2500 = new AircraftTypeModelCode(
			"BAC-111-2500",
			"BA2500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_145_JETPROVOST = new AircraftTypeModelCode(
			"BAC-145 Jetprovost",
			"BAC145",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAC_167_STRIKEMASTER = new AircraftTypeModelCode(
			"BAC-167 Strikemaster",
			"BAC167",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BADGER_C_MOD_TU_16 = new AircraftTypeModelCode(
			"Badger C Mod / TU-16",
			"BGRCMO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_748_COASTGUARDER = new AircraftTypeModelCode(
			"BAE 748 Coastguarder",
			"BA748",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_ADVANCED_TURBOPROP_ATP = new AircraftTypeModelCode(
			"BAE Advanced Turboprop Atp",
			"BATP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_HS_TRIDENT = new AircraftTypeModelCode(
			"BAE HS Trident",
			"BAETRI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_JETSTREAM_31 = new AircraftTypeModelCode(
			"BAE Jetstream 31",
			"BA14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_SUPER_VC10 = new AircraftTypeModelCode(
			"BAE Super Vc10",
			"BA15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_VICTOR = new AircraftTypeModelCode(
			"BAE Victor",
			"BAEVIC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_125_HARRIER = new AircraftTypeModelCode(
			"BAE-125 Harrier",
			"BAE125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_125_SEA_HARRIER = new AircraftTypeModelCode(
			"BAE-125 Sea Harrier",
			"BA125S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_125_700 = new AircraftTypeModelCode(
			"BAE-125-700",
			"BA1257",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_125_800 = new AircraftTypeModelCode(
			"BAE-125-800",
			"BA1258",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_146_QUIET_TRADER = new AircraftTypeModelCode(
			"BAE-146 Quiet Trader",
			"BAE146",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_146_SERIES_200 = new AircraftTypeModelCode(
			"BAE-146 Series 200",
			"BA1462",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_146M = new AircraftTypeModelCode(
			"BAE-146M",
			"BA146",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_146_QT = new AircraftTypeModelCode(
			"BAE-146-QT",
			"BA146Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_146STA = new AircraftTypeModelCode(
			"BAE-146STA",
			"BA146S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAE_748_ANDOVER = new AircraftTypeModelCode(
			"BAE-748 Andover",
			"BAE748",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BAHADUR_MIG_27M = new AircraftTypeModelCode(
			"Bahadur / Mig-27m",
			"MIG27M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BANDEIRANTE_MARITIM_EMB_111 = new AircraftTypeModelCode(
			"Bandeirante Maritim / Emb-111",
			"EMB111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BATTLEFIELD_LYNX = new AircraftTypeModelCode(
			"Battlefield Lynx",
			"LBAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BD_10_FALCON = new AircraftTypeModelCode(
			"BD-10 Falcon",
			"BD10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BD_12 = new AircraftTypeModelCode(
			"BD-12",
			"BD12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BD_700_GLOBAL_EXPRESS = new AircraftTypeModelCode(
			"BD-700 Global Express",
			"BD700",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_103 = new AircraftTypeModelCode(
			"BE-103",
			"BER103",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_12 = new AircraftTypeModelCode(
			"BE-12",
			"BE12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_12_MAIL = new AircraftTypeModelCode(
			"BE-12 Mail",
			"MAI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_200 = new AircraftTypeModelCode(
			"BE-200",
			"BER200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_30_CUFF = new AircraftTypeModelCode(
			"BE-30 Cuff",
			"BE30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_32_CUFF = new AircraftTypeModelCode(
			"BE-32 Cuff",
			"BER32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_32K = new AircraftTypeModelCode(
			"BE-32K",
			"BER32K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_42_BERIEV_ALBATROSS = new AircraftTypeModelCode(
			"BE-42 Beriev Albatross",
			"BE42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_42_MERMAID = new AircraftTypeModelCode(
			"BE-42 Mermaid",
			"BER42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_45_MENTOR = new AircraftTypeModelCode(
			"BE-45 Mentor",
			"BE45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_6 = new AircraftTypeModelCode(
			"BE-6",
			"BE6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_6_MADGE = new AircraftTypeModelCode(
			"BE-6 Madge",
			"MDG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_65_BEECH_SEMINOLE = new AircraftTypeModelCode(
			"BE-65 Beech Seminole",
			"BC65",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_80_BEECH_SEMINOLE = new AircraftTypeModelCode(
			"BE-80 Beech Seminole",
			"BC80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BE_99_AIRLINER = new AircraftTypeModelCode(
			"BE-99 Airliner",
			"BE99",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEAGLE_B_121_PUP_SERIES_AIRDALE = new AircraftTypeModelCode(
			"Beagle B-121 Pup Series Airdale",
			"BT10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEAGLE_B_206_BEAGLE_SERIES_MODEL_206S = new AircraftTypeModelCode(
			"Beagle B-206 Beagle Series Model 206s",
			"BT6S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEE_T_203 = new AircraftTypeModelCode(
			"Bee / T-203",
			"T203",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_114B_COMMANDER = new AircraftTypeModelCode(
			"Beech 114B Commander",
			"BC114B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_1900 = new AircraftTypeModelCode(
			"Beech 1900",
			"BC02",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_1900C_AIRLINER_1900C_1900_EXEC_LINER = new AircraftTypeModelCode(
			"Beech 1900C Airliner / 1900c / 1900 Exec-Liner",
			"BC19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_1900D = new AircraftTypeModelCode(
			"Beech 1900D",
			"BC190D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_200_SIERRA = new AircraftTypeModelCode(
			"Beech 200 Sierra",
			"BC200S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_2000_STARSHIP_1 = new AircraftTypeModelCode(
			"Beech 2000 Starship 1",
			"BC2000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_2000A_STARSHIP_1 = new AircraftTypeModelCode(
			"Beech 2000A Starship 1",
			"BC200A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_390_PD_PREMIER_I = new AircraftTypeModelCode(
			"Beech 390-PD / Premier I",
			"RAY390",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BARON_BE_58 = new AircraftTypeModelCode(
			"Beech Baron BE-58",
			"BE58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_DEBONAIR = new AircraftTypeModelCode(
			"Beech Bonanza / Debonair",
			"BC33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_35_V_TAIL = new AircraftTypeModelCode(
			"Beech Bonanza 35 V-Tail",
			"BC35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_36 = new AircraftTypeModelCode(
			"Beech Bonanza 36",
			"BC36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_A_36_A_36_BONANZA = new AircraftTypeModelCode(
			"Beech Bonanza A-36 / A-36 Bonanza",
			"BC36A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_A36AT = new AircraftTypeModelCode(
			"Beech Bonanza A36AT",
			"BC36AT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_F33A = new AircraftTypeModelCode(
			"Beech Bonanza F33A",
			"BC33FA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_F_33A_581 = new AircraftTypeModelCode(
			"Beech Bonanza F-33A-581",
			"F33A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_F33C = new AircraftTypeModelCode(
			"Beech Bonanza F33C",
			"BC33FC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_L33 = new AircraftTypeModelCode(
			"Beech Bonanza L33",
			"BC33L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_L35 = new AircraftTypeModelCode(
			"Beech Bonanza L35",
			"BC35L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_L36 = new AircraftTypeModelCode(
			"Beech Bonanza L36",
			"BC36L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_BONANZA_V35B = new AircraftTypeModelCode(
			"Beech Bonanza V35B",
			"BC35V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_DUCHESS_76 = new AircraftTypeModelCode(
			"Beech Duchess 76",
			"BC76",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_DUKE_60 = new AircraftTypeModelCode(
			"Beech Duke 60",
			"BC60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_F90 = new AircraftTypeModelCode(
			"Beech F90",
			"BC90F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_200_C_12_GUARDRAIL_KING_AIR_200 = new AircraftTypeModelCode(
			"Beech King Air 200 / C-12 / Guardrail King Air 200",
			"BC200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_90 = new AircraftTypeModelCode(
			"Beech King Air 90",
			"BC90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_B200T = new AircraftTypeModelCode(
			"Beech King Air B200T",
			"BC200T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_C90_A90_B90_C90_1_C90A = new AircraftTypeModelCode(
			"Beech King Air C90 / A90 / B90 / C90-1 / C90A",
			"BC90C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_C90B = new AircraftTypeModelCode(
			"Beech King Air C90B",
			"BC90B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_KING_AIR_C90SE = new AircraftTypeModelCode(
			"Beech King Air C90SE",
			"BC90SE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_QUEEN_AIR_88 = new AircraftTypeModelCode(
			"Beech Queen Air 88",
			"BC88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SIERRA_24 = new AircraftTypeModelCode(
			"Beech Sierra 24",
			"BC24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SKIPPER_77 = new AircraftTypeModelCode(
			"Beech Skipper 77",
			"BC77",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_STAGGER_WING_17 = new AircraftTypeModelCode(
			"Beech Stagger Wing 17",
			"BC17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUNDOWNER_23_MUSKETEER_23 = new AircraftTypeModelCode(
			"Beech Sundowner 23 / Musketeer 23",
			"BC23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_H18 = new AircraftTypeModelCode(
			"Beech Super H18",
			"BC8S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200_C_12L_HURON = new AircraftTypeModelCode(
			"Beech Super King Air 200 / C-12l / Huron",
			"BC200L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200B = new AircraftTypeModelCode(
			"Beech Super King Air 200B",
			"BC200B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200BC = new AircraftTypeModelCode(
			"Beech Super King Air 200BC",
			"BC20BC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200C = new AircraftTypeModelCode(
			"Beech Super King Air 200C",
			"BC200C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200D = new AircraftTypeModelCode(
			"Beech Super King Air 200D",
			"BC200D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200E = new AircraftTypeModelCode(
			"Beech Super King Air 200E",
			"BC200E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200F = new AircraftTypeModelCode(
			"Beech Super King Air 200F",
			"BC200F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200G_RC_12G = new AircraftTypeModelCode(
			"Beech Super King Air 200G / RC-12G",
			"BC200G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200H = new AircraftTypeModelCode(
			"Beech Super King Air 200H",
			"BC200H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200K = new AircraftTypeModelCode(
			"Beech Super King Air 200K",
			"BC200K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200M = new AircraftTypeModelCode(
			"Beech Super King Air 200M",
			"BC200M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200N_RC_12N = new AircraftTypeModelCode(
			"Beech Super King Air 200N / RC-12N",
			"BC200N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200P_RC_12P = new AircraftTypeModelCode(
			"Beech Super King Air 200P / RC-12P",
			"BC200P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200Q_RC_12Q = new AircraftTypeModelCode(
			"Beech Super King Air 200Q / RC-12Q",
			"BC200Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_200R_C_12R = new AircraftTypeModelCode(
			"Beech Super King Air 200R / C-12R",
			"BC200R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_300 = new AircraftTypeModelCode(
			"Beech Super King Air 300",
			"BC30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_300LW = new AircraftTypeModelCode(
			"Beech Super King Air 300LW",
			"BC30LW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_SUPER_KING_AIR_350_LR_2 = new AircraftTypeModelCode(
			"Beech Super King Air 350 / LR-2",
			"BC350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_TRAVELAIR_95 = new AircraftTypeModelCode(
			"Beech Travelair 95",
			"BC95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_TURBO_BONANZA_B36TC = new AircraftTypeModelCode(
			"Beech Turbo Bonanza B36TC",
			"BC36TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_TWIN_BEECH = new AircraftTypeModelCode(
			"Beech Twin Beech",
			"BCTWBE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECH_TWIN_BONANZA_50 = new AircraftTypeModelCode(
			"Beech Twin Bonanza 50",
			"BC50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECHJET_400 = new AircraftTypeModelCode(
			"Beechjet 400",
			"BC400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BEECHJET_400A = new AircraftTypeModelCode(
			"Beechjet 400A",
			"BC400A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_205_UH_1_IROQUOIS_SUPERHUEY = new AircraftTypeModelCode(
			"Bell 205 / UH-1 Iroquois / Superhuey",
			"BE205",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_205B = new AircraftTypeModelCode(
			"Bell 205B",
			"BE205B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206A_JETRANGER = new AircraftTypeModelCode(
			"Bell 206A Jetranger",
			"BE206A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206B_3_JETRANGER_III_CH_67 = new AircraftTypeModelCode(
			"Bell 206B-3 Jetranger III / CH-67",
			"BE206B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206L_3_LONGRANGER_III = new AircraftTypeModelCode(
			"Bell 206L-3 Longranger III",
			"BE2063",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206L_3ST_TRIDAIR = new AircraftTypeModelCode(
			"Bell 206L-3ST Tridair",
			"BE206L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206L_4_LONGRANGER_IV = new AircraftTypeModelCode(
			"Bell 206L-4 Longranger IV",
			"BE2064",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206L_4ST_GEMINI_ST = new AircraftTypeModelCode(
			"Bell 206L-4ST Gemini St",
			"BE206G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_206LT_TWINRANGER = new AircraftTypeModelCode(
			"Bell 206LT Twinranger",
			"BE206T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_209_HUEY_COBRA_AH_1E_AH_1F_TAH_1F_AH = new AircraftTypeModelCode(
			"Bell 209 Huey Cobra / AH-1E / AH-1F / TAH-1F / AH-",
			"BE209",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_209_SUPERCOBRA_AH_1W = new AircraftTypeModelCode(
			"Bell 209 Supercobra / AH-1W",
			"BE209S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_212_ASW = new AircraftTypeModelCode(
			"Bell 212 ASW",
			"ABE212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_212_TWIN_212_UH_1N = new AircraftTypeModelCode(
			"Bell 212 Twin 212 / UH-1N",
			"BE212T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_230 = new AircraftTypeModelCode(
			"Bell 230",
			"BE230",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_407 = new AircraftTypeModelCode(
			"Bell 407",
			"BE407",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_412_412_EP_412_SP = new AircraftTypeModelCode(
			"Bell 412 / 412 EP / 412 SP",
			"BE412",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_412_CF_GRIFFON = new AircraftTypeModelCode(
			"Bell 412 CF Griffon",
			"BE412C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_427 = new AircraftTypeModelCode(
			"Bell 427",
			"BE427",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_430 = new AircraftTypeModelCode(
			"Bell 430",
			"BE430",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_442 = new AircraftTypeModelCode(
			"Bell 442",
			"BE442",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_609 = new AircraftTypeModelCode(
			"Bell 609",
			"BE609",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_620 = new AircraftTypeModelCode(
			"Bell 620",
			"BE620",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_901_CV_22_OSPREY = new AircraftTypeModelCode(
			"Bell 901 / CV-22 Osprey",
			"CV22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_901_OSPREY = new AircraftTypeModelCode(
			"Bell 901 Osprey",
			"BE901",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_BIGLIFTER = new AircraftTypeModelCode(
			"Bell Biglifter",
			"BH14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_MODEL_222 = new AircraftTypeModelCode(
			"Bell Model 222",
			"BH22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_SUPER_TRANSPORT_214ST = new AircraftTypeModelCode(
			"Bell Super Transport 214ST",
			"BHST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELL_SUPER_TRANSPORT_AIRCRAFT_TYPE = new AircraftTypeModelCode(
			"Bell Super Transport Aircraft Type",
			"BELL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_AERONCA_CHAMPION = new AircraftTypeModelCode(
			"Bellanca Aeronca Champion",
			"AR58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_AERONCA_CHIEF_SUPER_CHIEF = new AircraftTypeModelCode(
			"Bellanca Aeronca Chief/ Super Chief",
			"AR11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_AERONCA_SEDAN = new AircraftTypeModelCode(
			"Bellanca Aeronca Sedan",
			"AR15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION = new AircraftTypeModelCode(
			"Bellanca Champion",
			"CH5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION_CHALLENGER = new AircraftTypeModelCode(
			"Bellanca Champion Challenger",
			"CH8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION_CITABRIA = new AircraftTypeModelCode(
			"Bellanca Champion Citabria",
			"CH10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION_CITABRIA_7ECA = new AircraftTypeModelCode(
			"Bellanca Champion Citabria 7ECA",
			"CH9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION_LANCER_402 = new AircraftTypeModelCode(
			"Bellanca Champion Lancer 402",
			"CH40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CHAMPION_TRAVELER_7EC = new AircraftTypeModelCode(
			"Bellanca Champion Traveler 7EC",
			"CH7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_CRUISAIR_SR_CRUISEMASTER_14_19 = new AircraftTypeModelCode(
			"Bellanca Cruisair Sr., Cruisemaster 14-19",
			"BL14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_DECATHLON = new AircraftTypeModelCode(
			"Bellanca Decathlon",
			"BL30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_MODEL_17_30A_SUPER_VIKING_300A = new AircraftTypeModelCode(
			"Bellanca Model 17-30A, Super Viking 300A",
			"BL26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_MODEL_8GCBC_SCOUT = new AircraftTypeModelCode(
			"Bellanca Model 8GCBC Scout",
			"BL28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BELLANCA_TURBO_VIKING = new AircraftTypeModelCode(
			"Bellanca Turbo Viking",
			"BL31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BERIEV_976_A_50_MAINSTAY = new AircraftTypeModelCode(
			"Beriev 976 / A-50 / Mainstay",
			"BERA50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BETA_R_22 = new AircraftTypeModelCode(
			"Beta R-22",
			"BETA22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BK_117_B_2 = new AircraftTypeModelCode(
			"Bk-117 B-2",
			"BK117B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BK_117_C_1 = new AircraftTypeModelCode(
			"Bk-117 C-1",
			"BK117C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BK_117_MBB = new AircraftTypeModelCode(
			"Bk-117 MBB",
			"BK117",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BK_117_P5 = new AircraftTypeModelCode(
			"Bk-117 P5",
			"BK117P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BK_117M = new AircraftTypeModelCode(
			"Bk-117M",
			"BK117M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BLUE_BIRD_D_139 = new AircraftTypeModelCode(
			"Blue Bird D-139",
			"D139",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2_DEFENDER_B2_320 = new AircraftTypeModelCode(
			"BN-2 Defender B2-320",
			"BN2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN2A_ISLANDER = new AircraftTypeModelCode(
			"BN2A Islander",
			"BN2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2A_3 = new AircraftTypeModelCode(
			"BN-2A-3",
			"BN2A3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2B_DEFENDER = new AircraftTypeModelCode(
			"BN-2B Defender",
			"BN2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2B_ISLANDER = new AircraftTypeModelCode(
			"BN-2B Islander",
			"BN2BI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2B_MAR_DEFENDER = new AircraftTypeModelCode(
			"BN-2B Mar Defender",
			"BN2BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T = new AircraftTypeModelCode(
			"BN-2T",
			"BN2T1S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_AEW_DEFENDER = new AircraftTypeModelCode(
			"BN-2T Aew Defender",
			"BN2AEW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_ASTOR_DEFEND = new AircraftTypeModelCode(
			"BN-2T Astor Defend",
			"BN2T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_ASW_MAR_DEFENDER = new AircraftTypeModelCode(
			"BN-2T ASW Mar Defender",
			"BN2ASW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_DEFENDER_4000 = new AircraftTypeModelCode(
			"BN-2T Defender 4000",
			"BN4000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_ELINT_DEFENDER = new AircraftTypeModelCode(
			"BN-2T Elint Defender",
			"BN2TED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_INT_SEC_DEFENDER = new AircraftTypeModelCode(
			"BN-2T Int Sec Defender",
			"BN2TIS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_ISLANDER_AL_MK1 = new AircraftTypeModelCode(
			"BN-2T Islander AL.MK1",
			"BN2TAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_TURB_ISLANDER = new AircraftTypeModelCode(
			"BN-2T Turb Islander",
			"BN2TI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_4R_DEFENDER = new AircraftTypeModelCode(
			"BN-2T-4R Defender",
			"BN2T4R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_2T_4S_DEFENDER_4000 = new AircraftTypeModelCode(
			"BN-2T-4S Defender 4000",
			"BN2T4S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BN_3_TRISLANDER = new AircraftTypeModelCode(
			"BN-3 Trislander",
			"BN3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105_LS = new AircraftTypeModelCode(
			"BO-105 LS",
			"BO105L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105_MBB_NURTANIO = new AircraftTypeModelCode(
			"BO-105 MBB / Nurtanio",
			"BO105",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105C = new AircraftTypeModelCode(
			"BO-105C",
			"BO105C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105CBS_TWIN_JET_II = new AircraftTypeModelCode(
			"BO-105CBS Twin Jet II",
			"BO105T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105D = new AircraftTypeModelCode(
			"BO-105D",
			"BO105D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105M = new AircraftTypeModelCode(
			"BO-105M",
			"BO105M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105P = new AircraftTypeModelCode(
			"BO-105P",
			"BOP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105PAH = new AircraftTypeModelCode(
			"BO-105PAH",
			"BOPAH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_105PAH1 = new AircraftTypeModelCode(
			"BO-105PAH1",
			"BO105P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_106 = new AircraftTypeModelCode(
			"BO-106",
			"BO106",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_108 = new AircraftTypeModelCode(
			"BO-108",
			"BO108",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_108_ALH = new AircraftTypeModelCode(
			"BO-108 / ALH",
			"B0108",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BO_115 = new AircraftTypeModelCode(
			"BO-115",
			"BO115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_707 = new AircraftTypeModelCode(
			"Boeing 707",
			"B707",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_707_AMTU = new AircraftTypeModelCode(
			"Boeing 707 AMTU",
			"B707AM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_707_131B = new AircraftTypeModelCode(
			"Boeing 707-131B",
			"B70713",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_707_320C = new AircraftTypeModelCode(
			"Boeing 707-320C",
			"B70732",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_707TT = new AircraftTypeModelCode(
			"Boeing 707TT",
			"B707TT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_720B = new AircraftTypeModelCode(
			"Boeing 720B",
			"B720B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_727 = new AircraftTypeModelCode(
			"Boeing 727",
			"B727",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_727_100 = new AircraftTypeModelCode(
			"Boeing 727-100",
			"B72710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_727_200 = new AircraftTypeModelCode(
			"Boeing 727-200",
			"B72720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737 = new AircraftTypeModelCode(
			"Boeing 737",
			"B737",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_AEW = new AircraftTypeModelCode(
			"Boeing 737 AEW",
			"B737AE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_SURVEILLER = new AircraftTypeModelCode(
			"Boeing 737 Surveiller",
			"B737S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_100 = new AircraftTypeModelCode(
			"Boeing 737-100",
			"B73710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_123 = new AircraftTypeModelCode(
			"Boeing 737-123",
			"B73712",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_200 = new AircraftTypeModelCode(
			"Boeing 737-200",
			"B73720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_300 = new AircraftTypeModelCode(
			"Boeing 737-300",
			"B73730",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_400 = new AircraftTypeModelCode(
			"Boeing 737-400",
			"B73740",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_500 = new AircraftTypeModelCode(
			"Boeing 737-500",
			"B73750",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_600 = new AircraftTypeModelCode(
			"Boeing 737-600",
			"B73760",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_700 = new AircraftTypeModelCode(
			"Boeing 737-700",
			"B73770",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_737_800 = new AircraftTypeModelCode(
			"Boeing 737-800",
			"B73780",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747 = new AircraftTypeModelCode(
			"Boeing 747",
			"B747",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_100 = new AircraftTypeModelCode(
			"Boeing 747-100",
			"B74710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_200 = new AircraftTypeModelCode(
			"Boeing 747-200",
			"B74720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_300 = new AircraftTypeModelCode(
			"Boeing 747-300",
			"B74730",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_400_C_19A = new AircraftTypeModelCode(
			"Boeing 747-400 / C-19A",
			"B74740",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_400F_AL_1A = new AircraftTypeModelCode(
			"Boeing 747-400F / AL-1A",
			"B7474F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_747_SP = new AircraftTypeModelCode(
			"Boeing 747-SP",
			"B747SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_757 = new AircraftTypeModelCode(
			"Boeing 757",
			"B757",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_757_200_C_32A = new AircraftTypeModelCode(
			"Boeing 757-200 / C-32A",
			"B75720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767 = new AircraftTypeModelCode(
			"Boeing 767",
			"B767",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_AWACS = new AircraftTypeModelCode(
			"Boeing 767 AWACS",
			"B767AE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_100 = new AircraftTypeModelCode(
			"Boeing 767-100",
			"B76710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_200 = new AircraftTypeModelCode(
			"Boeing 767-200",
			"B76720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_200TC = new AircraftTypeModelCode(
			"Boeing 767-200TC",
			"B767TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_300 = new AircraftTypeModelCode(
			"Boeing 767-300",
			"B76730",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_300T_T = new AircraftTypeModelCode(
			"Boeing 767-300T/T",
			"B7673T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_767_400 = new AircraftTypeModelCode(
			"Boeing 767-400",
			"B76740",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_777 = new AircraftTypeModelCode(
			"Boeing 777",
			"B777",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_777_200 = new AircraftTypeModelCode(
			"Boeing 777-200",
			"B77720",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_777_300 = new AircraftTypeModelCode(
			"Boeing 777-300",
			"B77730",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_RC_707 = new AircraftTypeModelCode(
			"Boeing RC-707",
			"BRC707",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_STEARMAN = new AircraftTypeModelCode(
			"Boeing Stearman",
			"B75",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOEING_VERTOL_MODEL_105 = new AircraftTypeModelCode(
			"Boeing Vertol Model 105",
			"B105",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOERO_115 = new AircraftTypeModelCode(
			"Boero 115",
			"BOE115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOERO_180_PSA = new AircraftTypeModelCode(
			"Boero 180 PSA",
			"BOE18P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BOERO_180_RVR = new AircraftTypeModelCode(
			"Boero 180 RVR",
			"BOE18R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BR_1050_ALIZE = new AircraftTypeModelCode(
			"BR-1050 Alize",
			"BR1050",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BR_1150_ATLANTIC_NG = new AircraftTypeModelCode(
			"BR-1150 Atlantic NG",
			"BRNG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BR_1150_ATLANTIQUE = new AircraftTypeModelCode(
			"BR-1150 Atlantique",
			"BR1150",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BR_1150_BREGUET_ATLANTIQUE = new AircraftTypeModelCode(
			"BR-1150 Breguet Atlantique",
			"ATLA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRANTLEY_MODEL_305 = new AircraftTypeModelCode(
			"Brantley Model 305",
			"HB43",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRANTLEY_MODEL_B_2A_B_2B = new AircraftTypeModelCode(
			"Brantley Model B-2A/B-2B",
			"HB42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRIGANTINE_T_274 = new AircraftTypeModelCode(
			"Brigantine / T-274",
			"T274",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRISTOL_BRITANNIA_310 = new AircraftTypeModelCode(
			"Bristol Britannia 310",
			"BR31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRISTOL_FREIGHTER = new AircraftTypeModelCode(
			"Bristol Freighter",
			"BRFT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BRITTEN_NORMAN_BN2_A_B_ISLANDER = new AircraftTypeModelCode(
			"Britten Norman Bn2-A/B Islander",
			"BN2AB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BUCCANEER_S_HAWKER_SIDLEY = new AircraftTypeModelCode(
			"Buccaneer S Hawker Sidley",
			"BUC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BUCCANEER_S_MK2 = new AircraftTypeModelCode(
			"Buccaneer S MK2",
			"BUCMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BULLDOG_AC = new AircraftTypeModelCode(
			"Bulldog AC",
			"BULLAC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BULLDOG_T_MK1 = new AircraftTypeModelCode(
			"Bulldog T MK1",
			"BULMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BULLDOG_T_MK2 = new AircraftTypeModelCode(
			"Bulldog T MK2",
			"BULMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BUSHMASTER_2000 = new AircraftTypeModelCode(
			"Bushmaster 2000",
			"BU20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode BV_234_CHINOOK = new AircraftTypeModelCode(
			"BV-234 Chinook",
			"BV234",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1_KAWASAKI = new AircraftTypeModelCode(
			"C-1 Kawasaki",
			"C1KAW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1_SEAHURON = new AircraftTypeModelCode(
			"C-1 Seahuron",
			"C1S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1_TRADER = new AircraftTypeModelCode(
			"C-1 Trader",
			"C1T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101_AVIOJET = new AircraftTypeModelCode(
			"C-101 Aviojet",
			"C101",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101BB_AVIOJET = new AircraftTypeModelCode(
			"C-101BB Aviojet",
			"C101BB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101BB_HALCON = new AircraftTypeModelCode(
			"C-101BB Halcon",
			"CHALC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101CC_AVIOJET = new AircraftTypeModelCode(
			"C-101CC Aviojet",
			"C101CC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101DD = new AircraftTypeModelCode(
			"C-101DD",
			"C101DD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_101EB = new AircraftTypeModelCode(
			"C-101EB",
			"C101EB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_118_LIFTMASTER = new AircraftTypeModelCode(
			"C-118 Liftmaster",
			"C118",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_118A_LIFTMASTER = new AircraftTypeModelCode(
			"C-118A Liftmaster",
			"C118A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_118B_LIFTMASTER = new AircraftTypeModelCode(
			"C-118B Liftmaster",
			"C118B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119_FLYING_BOXCAR = new AircraftTypeModelCode(
			"C-119 Flying Boxcar",
			"C119",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119A_FLYING_BOXCAR = new AircraftTypeModelCode(
			"C-119A Flying Boxcar",
			"C119A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119G_FLYING_BOXCAR = new AircraftTypeModelCode(
			"C-119G Flying Boxcar",
			"C119G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119J_FLYING_BOXCAR = new AircraftTypeModelCode(
			"C-119J Flying Boxcar",
			"C119J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119J_PACKET = new AircraftTypeModelCode(
			"C-119J Packet",
			"C119JP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_119RQ4 = new AircraftTypeModelCode(
			"C-119RQ4",
			"C119RQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_12_HURON_BEECH_SUPER_KING_AIR_200_200B = new AircraftTypeModelCode(
			"C-12 Huron / Beech Super King Air 200 / 200B",
			"C12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_121 = new AircraftTypeModelCode(
			"C-121",
			"C121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_121G_SUPER_CONNIE_C_121G_SUPER_CONSTELLATION = new AircraftTypeModelCode(
			"C-121G Super Connie / C-121G Super Constellation",
			"C121G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123_PROVIDER = new AircraftTypeModelCode(
			"C-123 Provider",
			"C123",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123B_PROVIDER = new AircraftTypeModelCode(
			"C-123B Provider",
			"C123B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123H_PROVIDER = new AircraftTypeModelCode(
			"C-123H Provider",
			"C123H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123J_PROVIDER = new AircraftTypeModelCode(
			"C-123J Provider",
			"C123J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123K_PROVIDER = new AircraftTypeModelCode(
			"C-123K Provider",
			"C123K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123L_PROVIDER = new AircraftTypeModelCode(
			"C-123L Provider",
			"C123L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_123T_PROVIDER = new AircraftTypeModelCode(
			"C-123T Provider",
			"C123T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_124 = new AircraftTypeModelCode(
			"C-124",
			"C124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_12A_HURON = new AircraftTypeModelCode(
			"C-12A Huron",
			"C12A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_12F = new AircraftTypeModelCode(
			"C-12F",
			"C12F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_12F_BEECH_SUPER_KING_AIR = new AircraftTypeModelCode(
			"C-12F Beech Super King Air",
			"C12FT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_12J_MODEL_1900C = new AircraftTypeModelCode(
			"C-12J Model 1900C",
			"C12J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130_H_30_HERCULES = new AircraftTypeModelCode(
			"C-130 H-30 Hercules",
			"C130H3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130_HERCULES = new AircraftTypeModelCode(
			"C-130 Hercules",
			"C130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130A_HERCULES = new AircraftTypeModelCode(
			"C-130A Hercules",
			"C130A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130B_HERCULES = new AircraftTypeModelCode(
			"C-130B Hercules",
			"C130B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130C_HERCULES = new AircraftTypeModelCode(
			"C-130C Hercules",
			"C130C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130D_HERCULES = new AircraftTypeModelCode(
			"C-130D Hercules",
			"C130D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130E_HERCULES = new AircraftTypeModelCode(
			"C-130E Hercules",
			"C130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130F = new AircraftTypeModelCode(
			"C-130F",
			"C13OF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130F_HERCULES = new AircraftTypeModelCode(
			"C-130F Hercules",
			"C130F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130G_HERCULES = new AircraftTypeModelCode(
			"C-130G Hercules",
			"C130G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130H_HERCULES = new AircraftTypeModelCode(
			"C-130H Hercules",
			"C130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130H_MP = new AircraftTypeModelCode(
			"C-130H-MP",
			"C130MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130J_HERCULES = new AircraftTypeModelCode(
			"C-130J Hercules",
			"C130J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130J_30 = new AircraftTypeModelCode(
			"C-130J-30",
			"C130J3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130K_HERCULES = new AircraftTypeModelCode(
			"C-130K Hercules",
			"C130K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130M_HERCULES = new AircraftTypeModelCode(
			"C-130M Hercules",
			"C130M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130N_HERCULES = new AircraftTypeModelCode(
			"C-130N Hercules",
			"C130N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130P_HERCULES = new AircraftTypeModelCode(
			"C-130P Hercules",
			"C130P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_130T = new AircraftTypeModelCode(
			"C-130T",
			"C130T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_131_COSMOPOLITAN = new AircraftTypeModelCode(
			"C-131 Cosmopolitan",
			"C131CO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_131_SAMARITAN = new AircraftTypeModelCode(
			"C-131 Samaritan",
			"C131",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_131F_SAMARITAN = new AircraftTypeModelCode(
			"C-131F Samaritan",
			"C131F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_131G_SAMARITAN = new AircraftTypeModelCode(
			"C-131G Samaritan",
			"C131G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_131H_SAMARITAN = new AircraftTypeModelCode(
			"C-131H Samaritan",
			"C131H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_133 = new AircraftTypeModelCode(
			"C-133",
			"C133",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_133A = new AircraftTypeModelCode(
			"C-133A",
			"C133A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135 Stratolifter",
			"C135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135A_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135A Stratolifter",
			"C135A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135B_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135B Stratolifter",
			"C135B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135C_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135C Stratolifter",
			"C135C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135E_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135E Stratolifter",
			"C135E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135F_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135F Stratolifter",
			"C135F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_135_FR_STRATOLIFTER = new AircraftTypeModelCode(
			"C-135-FR Stratolifter",
			"C135FR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_137B_STRATOLINER = new AircraftTypeModelCode(
			"C-137B Stratoliner",
			"C137B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_137C_STRATOLINER = new AircraftTypeModelCode(
			"C-137C Stratoliner",
			"C137C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_139A = new AircraftTypeModelCode(
			"C-139A",
			"C139A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_14_MIRAGE_F1 = new AircraftTypeModelCode(
			"C-14 Mirage F1",
			"C14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_140_JETSTAR = new AircraftTypeModelCode(
			"C-140 Jetstar",
			"C140",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_140A_JETSTAR = new AircraftTypeModelCode(
			"C-140A Jetstar",
			"C140A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_141_STARLIFTER = new AircraftTypeModelCode(
			"C-141 Starlifter",
			"C141",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_141B_STARLIFTER = new AircraftTypeModelCode(
			"C-141B Starlifter",
			"C141B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_141C_STARLIFTER = new AircraftTypeModelCode(
			"C-141C Starlifter",
			"C141C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_16_EFA_EUROFIGHTER = new AircraftTypeModelCode(
			"C-16 EFA / Eurofighter",
			"EFA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160_ALIZE = new AircraftTypeModelCode(
			"C-160 Alize",
			"C160AL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160_ASTARTE = new AircraftTypeModelCode(
			"C-160 Astarte",
			"C160AS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160_TRANSALL_BASIC = new AircraftTypeModelCode(
			"C-160 Transall Basic",
			"C160",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160F_TRANSALL = new AircraftTypeModelCode(
			"C-160F Transall",
			"C160F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160G_TRANSALL_GABRIEL = new AircraftTypeModelCode(
			"C-160G Transall Gabriel",
			"C160G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160H_TRANSALL_ASTARTE = new AircraftTypeModelCode(
			"C-160H Transall Astarte",
			"C160H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_160NG_TRANSALL = new AircraftTypeModelCode(
			"C-160NG Transall",
			"C160NG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_17_GLOBEMASTER_III = new AircraftTypeModelCode(
			"C-17 Globemaster III",
			"C17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_17A_GLOBEMASTER_3_C_17A_GLOBEMASTER_III = new AircraftTypeModelCode(
			"C-17A Globemaster 3 / C-17A Globemaster III",
			"C17A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_18_BOEING_707 = new AircraftTypeModelCode(
			"C-18 Boeing 707",
			"C18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_180_SKYWAGON = new AircraftTypeModelCode(
			"C-180 Skywagon",
			"C180",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_19 = new AircraftTypeModelCode(
			"C-19",
			"C19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_19A_BOEING_747 = new AircraftTypeModelCode(
			"C-19A / Boeing 747",
			"C19A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1A_TRADER = new AircraftTypeModelCode(
			"C-1A Trader",
			"C1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1K_HERCULES = new AircraftTypeModelCode(
			"C-1K Hercules",
			"C1K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_1PR_PEMBROKE = new AircraftTypeModelCode(
			"C-1PR Pembroke",
			"C1PR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_2_GREYHOUND = new AircraftTypeModelCode(
			"C-2 Greyhound",
			"C2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20 Gulfstream III",
			"C20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20_SEADEVON = new AircraftTypeModelCode(
			"C-20 Seadevon",
			"C20S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_207_AZOR = new AircraftTypeModelCode(
			"C-207 Azor",
			"C207",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_207A_AZOR = new AircraftTypeModelCode(
			"C-207A Azor",
			"C207A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_208_CARAVAN = new AircraftTypeModelCode(
			"C-208 Caravan",
			"C208",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20A_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20A Gulfstream III",
			"C20A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20B_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20B Gulfstream III",
			"C20B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20C_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20C Gulfstream III",
			"C20C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20D_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20D Gulfstream III",
			"C20D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20F_GULFSTREAM_IV = new AircraftTypeModelCode(
			"C-20F Gulfstream IV",
			"C20F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20G_GULFSTREAM_IV = new AircraftTypeModelCode(
			"C-20G Gulfstream IV",
			"C20G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20H_GULFSTREAM_III = new AircraftTypeModelCode(
			"C-20H Gulfstream III",
			"C020H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_20H_GULFSTREAM_IV = new AircraftTypeModelCode(
			"C-20H Gulfstream IV",
			"C20H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_21 = new AircraftTypeModelCode(
			"C-21",
			"C21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_AVIOCAR_B = new AircraftTypeModelCode(
			"C-212 Aviocar B",
			"C212A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_CASA = new AircraftTypeModelCode(
			"C-212 Casa",
			"C212C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_CASA_AVIOCAR_PATRULLERO_TP_89 = new AircraftTypeModelCode(
			"C-212 Casa Aviocar / Patrullero / TP-89",
			"C212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_100M_AVIOCAR = new AircraftTypeModelCode(
			"C-212-100M Aviocar",
			"C2121M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_200M = new AircraftTypeModelCode(
			"C-212-200M",
			"C2122M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_300ASW = new AircraftTypeModelCode(
			"C-212-300ASW",
			"C2123D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_300DE = new AircraftTypeModelCode(
			"C-212-300DE",
			"C2123E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_300M_CASA = new AircraftTypeModelCode(
			"C-212-300M Casa",
			"C212M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_300MP = new AircraftTypeModelCode(
			"C-212-300MP",
			"C2123M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_300P = new AircraftTypeModelCode(
			"C-212-300P",
			"C2123P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212_400 = new AircraftTypeModelCode(
			"C-212-400",
			"C21240",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_212P_CASA = new AircraftTypeModelCode(
			"C-212P Casa",
			"C212P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_21A_LEARJET_35A = new AircraftTypeModelCode(
			"C-21A / Learjet 35A",
			"C21A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_22_BOEING_727_100 = new AircraftTypeModelCode(
			"C-22 Boeing 727-100",
			"C22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_223_FLAMINGO = new AircraftTypeModelCode(
			"C-223 Flamingo",
			"C223",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_22B = new AircraftTypeModelCode(
			"C-22B",
			"C022B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_22J_VENTURA = new AircraftTypeModelCode(
			"C-22J Ventura",
			"C22J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_23_SHERPA = new AircraftTypeModelCode(
			"C-23 Sherpa",
			"C23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_23_SUNDOWNER = new AircraftTypeModelCode(
			"C-23 Sundowner",
			"C23SUN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_233_CASA = new AircraftTypeModelCode(
			"C-233 Casa",
			"C233",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_233_CASA_FLAMINGO = new AircraftTypeModelCode(
			"C-233 Casa Flamingo",
			"C233FL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_235_CASA = new AircraftTypeModelCode(
			"C-235 Casa",
			"C235",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_23A_SHERPA = new AircraftTypeModelCode(
			"C-23A Sherpa",
			"C23A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_23A_SUNDOWNER = new AircraftTypeModelCode(
			"C-23A Sundowner",
			"C23ASU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_26_METROLINER = new AircraftTypeModelCode(
			"C-26 Metroliner",
			"C26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_26A_METRO_23_C_26A_METRO_III = new AircraftTypeModelCode(
			"C-26A Metro 23 / C-26A Metro III",
			"C26A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_26B_METRO_23 = new AircraftTypeModelCode(
			"C-26B Metro 23",
			"C26B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_27A_SPARTAN_G_222_ALENIA = new AircraftTypeModelCode(
			"C-27A Spartan / G-222 Alenia",
			"C27A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_27J_SPARTAN = new AircraftTypeModelCode(
			"C-27J Spartan",
			"C27J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_295 = new AircraftTypeModelCode(
			"C-295",
			"C295",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_29A_BAE_125_800 = new AircraftTypeModelCode(
			"C-29A BAE-125-800",
			"C29A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_2A_GREYHOUND = new AircraftTypeModelCode(
			"C-2A Greyhound",
			"C2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_3_HERCULES = new AircraftTypeModelCode(
			"C-3 Hercules",
			"C3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_32A_BOEING_757_200 = new AircraftTypeModelCode(
			"C-32A / Boeing 757-200",
			"C32A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_337_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"C-337 Super Skymaster",
			"C337",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_337G_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"C-337G Super Skymaster",
			"C337G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_3605_SWISS_FEDERATE = new AircraftTypeModelCode(
			"C-3605 Swiss Federate",
			"C3605",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_37A_GULFSTREAM_V = new AircraftTypeModelCode(
			"C-37A Gulfstream V",
			"C37A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_38_GALAXY_AEROSPACE_ASTRA_SPX = new AircraftTypeModelCode(
			"C-38 / Galaxy Aerospace Astra SPX",
			"C38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_38A = new AircraftTypeModelCode(
			"C-38A",
			"C38A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_404_TITAN = new AircraftTypeModelCode(
			"C-404 Titan",
			"C404",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_42_AVIOCAR = new AircraftTypeModelCode(
			"C-42 Aviocar",
			"C42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_42_REGENTE = new AircraftTypeModelCode(
			"C-42 Regente",
			"C42R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_45_EXPEDITOR = new AircraftTypeModelCode(
			"C-45 Expeditor",
			"C45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_46_COMMANDO = new AircraftTypeModelCode(
			"C-46 Commando",
			"C46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_46_COMMANDO_1 = new AircraftTypeModelCode(
			"C-46 Commando 1",
			"C461",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_46_COMMANDO_F_W = new AircraftTypeModelCode(
			"C-46 Commando F/W",
			"C46FW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_46A_COMMANDO = new AircraftTypeModelCode(
			"C-46A Commando",
			"C46A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_47_DAKOTA_SKYTRAIN = new AircraftTypeModelCode(
			"C-47 Dakota / Skytrain",
			"C47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_47_DAKOTA_DC_3 = new AircraftTypeModelCode(
			"C-47 Dakota DC-3",
			"C47DC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_47A_SKYTRAIN_R4D = new AircraftTypeModelCode(
			"C-47A Skytrain R4D",
			"C47A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_4M_KUDU = new AircraftTypeModelCode(
			"C-4M Kudu",
			"C4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_5_GALAXY = new AircraftTypeModelCode(
			"C-5 Galaxy",
			"C5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_501_CITATION = new AircraftTypeModelCode(
			"C-501 Citation",
			"C501",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_54_SKYMASTER = new AircraftTypeModelCode(
			"C-54 Skymaster",
			"C54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_54B_SKYMASTER = new AircraftTypeModelCode(
			"C-54B Skymaster",
			"C54B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_54D_SKYMASTER = new AircraftTypeModelCode(
			"C-54D Skymaster",
			"C54D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_550_CITATION = new AircraftTypeModelCode(
			"C-550 Citation",
			"C550",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_5A_GALAXY = new AircraftTypeModelCode(
			"C-5A Galaxy",
			"C5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_5B_GALAXY = new AircraftTypeModelCode(
			"C-5B Galaxy",
			"C5B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_5C_GALAXY = new AircraftTypeModelCode(
			"C-5C Galaxy",
			"C5C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_7_CARIBOU = new AircraftTypeModelCode(
			"C-7 Caribou",
			"C7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_7_DASH_7 = new AircraftTypeModelCode(
			"C-7 Dash-7",
			"C7DASH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_7_KFIR_C7 = new AircraftTypeModelCode(
			"C-7 KFIR C7",
			"C7KFIR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_7A_CARIBOU = new AircraftTypeModelCode(
			"C-7A Caribou",
			"C7A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_8_BUFFALO = new AircraftTypeModelCode(
			"C-8 Buffalo",
			"C8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_8A_BUFFALO = new AircraftTypeModelCode(
			"C-8A Buffalo",
			"C8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_9_NIGHTINGALE_SKYTRAIN = new AircraftTypeModelCode(
			"C-9 Nightingale / Skytrain",
			"C9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_91_ANDOVER = new AircraftTypeModelCode(
			"C-91 Andover",
			"C91",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_95_BANDEIRANTE = new AircraftTypeModelCode(
			"C-95 Bandeirante",
			"C95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_95_BANDEIRANTE_MAR = new AircraftTypeModelCode(
			"C-95 Bandeirante Mar",
			"C95MAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_95A = new AircraftTypeModelCode(
			"C-95A",
			"C95A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_97_STRATOCRUISER = new AircraftTypeModelCode(
			"C-97 Stratocruiser",
			"C97",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_99_AIRLINER = new AircraftTypeModelCode(
			"C-99 Airliner",
			"C99",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_9A_NIGHTINGALE = new AircraftTypeModelCode(
			"C-9A Nightingale",
			"C9A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_9B_SKYTRAIN_II = new AircraftTypeModelCode(
			"C-9B Skytrain II",
			"C9B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_9C_NIGHTINGALE = new AircraftTypeModelCode(
			"C-9C Nightingale",
			"C9C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_22_ELAND = new AircraftTypeModelCode(
			"CA-22 Eland",
			"CA25E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_25_IMPALA = new AircraftTypeModelCode(
			"CA-25 Impala",
			"CA25I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_25_WINJEEL = new AircraftTypeModelCode(
			"CA-25 Winjeel",
			"CA25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_25N_GAZELLE = new AircraftTypeModelCode(
			"CA-25N Gazelle",
			"CA25G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_61_MINI_ACE = new AircraftTypeModelCode(
			"CA-61 Mini Ace",
			"CA61MA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_65 = new AircraftTypeModelCode(
			"CA-65",
			"CA65",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CA_65A = new AircraftTypeModelCode(
			"CA-65A",
			"CA65A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAMAIR_MODEL_480_TWIN_NAVION_CTN_A_THRU_D = new AircraftTypeModelCode(
			"Camair Model 480 Twin Navion / CTN-A Thru D",
			"CM48",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAMBER = new AircraftTypeModelCode(
			"Camber",
			"CAM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAMERON_DG_14 = new AircraftTypeModelCode(
			"Cameron DG-14",
			"DG14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAMERON_DP_60_DP_90 = new AircraftTypeModelCode(
			"Cameron DP-60 - DP-90",
			"DP60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANADAIR_215_AMPHIBIAN = new AircraftTypeModelCode(
			"Canadair 215 Amphibian",
			"CAN215",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANADAIR_COSMOPOLITAN = new AircraftTypeModelCode(
			"Canadair Cosmopolitan",
			"CL66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANADAIR_NORTH_STAR = new AircraftTypeModelCode(
			"Canadair North Star",
			"NSTR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA = new AircraftTypeModelCode(
			"Canberra",
			"CANBER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_B2 = new AircraftTypeModelCode(
			"Canberra B2",
			"CANB2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_E13 = new AircraftTypeModelCode(
			"Canberra E13",
			"CANE13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_PR7 = new AircraftTypeModelCode(
			"Canberra PR7",
			"CANPR7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_PR9 = new AircraftTypeModelCode(
			"Canberra PR9",
			"CANPR9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_T17 = new AircraftTypeModelCode(
			"Canberra T17",
			"CANT17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_T4 = new AircraftTypeModelCode(
			"Canberra T4",
			"CANT4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CANBERRA_TT1B = new AircraftTypeModelCode(
			"Canberra TT1B",
			"CANT1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAP_10_MUDRY = new AircraftTypeModelCode(
			"CAP-10 Mudry",
			"CAP10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAP_10B_MUDRY = new AircraftTypeModelCode(
			"CAP-10B Mudry",
			"CAP10B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAP_231_EX = new AircraftTypeModelCode(
			"CAP-231 EX",
			"CAP231",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAP_232 = new AircraftTypeModelCode(
			"CAP-232",
			"CAP232",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CARTHORSE_GM_01 = new AircraftTypeModelCode(
			"Carthorse / GM-01",
			"GM01",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CASA_223_A1_FLAMINGO = new AircraftTypeModelCode(
			"Casa 223 A1 Flamingo",
			"CA223A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CASA_223_K1_FLAMINGO = new AircraftTypeModelCode(
			"Casa 223 K1 Flamingo",
			"CA223K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CASH_A = new AircraftTypeModelCode(
			"Cash A",
			"CASHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAYUSE_BLACK_TIGER = new AircraftTypeModelCode(
			"Cayuse Black Tiger",
			"CAYU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CAYUSE_DEFENDER = new AircraftTypeModelCode(
			"Cayuse Defender",
			"CAYDEF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_108_CARIBOU = new AircraftTypeModelCode(
			"CC-108 Caribou",
			"CC108C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_109_COSMOPOLITAN = new AircraftTypeModelCode(
			"CC-109 Cosmopolitan",
			"CC109",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_115_BUFFALO = new AircraftTypeModelCode(
			"CC-115 Buffalo",
			"CC115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_117_FALCON_20 = new AircraftTypeModelCode(
			"CC-117 Falcon 20",
			"CC117",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_132_DASH_7 = new AircraftTypeModelCode(
			"CC-132 Dash 7",
			"CC132D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_138_TWIN_OTTER = new AircraftTypeModelCode(
			"CC-138 Twin Otter",
			"CC138",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_142_DASH_8 = new AircraftTypeModelCode(
			"CC-142 Dash 8",
			"CC142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_144_CHALLENGER = new AircraftTypeModelCode(
			"CC-144 Challenger",
			"CC144",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_2 = new AircraftTypeModelCode(
			"CC-2",
			"ANDCC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CC_3_SEAHERON = new AircraftTypeModelCode(
			"CC-3 Seaheron",
			"CC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CE_144A_CHALLENGER = new AircraftTypeModelCode(
			"CE-144A Challenger",
			"CE144A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_120 = new AircraftTypeModelCode(
			"Cessna 120",
			"C120",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_150 = new AircraftTypeModelCode(
			"Cessna 150",
			"C150",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_152 = new AircraftTypeModelCode(
			"Cessna 152",
			"C152",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_170 = new AircraftTypeModelCode(
			"Cessna 170",
			"C170",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_190 = new AircraftTypeModelCode(
			"Cessna 190",
			"C190",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_195 = new AircraftTypeModelCode(
			"Cessna 195",
			"C195",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_206_STATIONAIR = new AircraftTypeModelCode(
			"Cessna 206 Stationair",
			"CE206",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_208_CARAVAN_I = new AircraftTypeModelCode(
			"Cessna 208 Caravan I",
			"CE208",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_310 = new AircraftTypeModelCode(
			"Cessna 310",
			"CE310",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_335 = new AircraftTypeModelCode(
			"Cessna 335",
			"C335",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_337 = new AircraftTypeModelCode(
			"Cessna 337",
			"CE337",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_340 = new AircraftTypeModelCode(
			"Cessna 340",
			"C340",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_401 = new AircraftTypeModelCode(
			"Cessna 401",
			"C401",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_402 = new AircraftTypeModelCode(
			"Cessna 402",
			"C402",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_411 = new AircraftTypeModelCode(
			"Cessna 411",
			"C411",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_414A = new AircraftTypeModelCode(
			"Cessna 414A",
			"414A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_414A_CHANCELOR = new AircraftTypeModelCode(
			"Cessna 414A Chancelor",
			"CE414A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_425_CONQUEST_I = new AircraftTypeModelCode(
			"Cessna 425 Conquest I",
			"CE425",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_441_CONQUEST_II = new AircraftTypeModelCode(
			"Cessna 441 Conquest II",
			"CE441",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_501_CITATION_I = new AircraftTypeModelCode(
			"Cessna 501 Citation I",
			"CE501",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_525_CITATIONJET = new AircraftTypeModelCode(
			"Cessna 525 Citationjet",
			"CE525",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_526_CITATIONJET = new AircraftTypeModelCode(
			"Cessna 526 Citationjet",
			"CE526",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_550_CITATION_BRAVO = new AircraftTypeModelCode(
			"Cessna 550 Citation Bravo",
			"CE550",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_560_CITATION_V_OT_47B = new AircraftTypeModelCode(
			"Cessna 560 Citation V / OT-47B",
			"CE560",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_560_XL_CITATION_EXCEL = new AircraftTypeModelCode(
			"Cessna 560 Xl Citation Excel",
			"CE560E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_650_CITATION_VII = new AircraftTypeModelCode(
			"Cessna 650 Citation VII",
			"CE650",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_660_CITATION_VII = new AircraftTypeModelCode(
			"Cessna 660 Citation VII",
			"CE660",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_670_CITATION_IV = new AircraftTypeModelCode(
			"Cessna 670 Citation IV",
			"CE670",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_750_CITATION_X = new AircraftTypeModelCode(
			"Cessna 750 Citation X",
			"CE750",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_AG_HUSKY = new AircraftTypeModelCode(
			"Cessna AG Husky",
			"CEAGH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_AG_TRUCK = new AircraftTypeModelCode(
			"Cessna AG Truck",
			"CEAGT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_AGWAGON_AGTRUCK_AGHUSKY_188 = new AircraftTypeModelCode(
			"Cessna Agwagon / Agtruck / Aghusky 188",
			"C188",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CARAVAN_I_208A = new AircraftTypeModelCode(
			"Cessna Caravan I 208A",
			"C208CA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CARDINAL_177 = new AircraftTypeModelCode(
			"Cessna Cardinal 177",
			"C177",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CENTURION_II_210 = new AircraftTypeModelCode(
			"Cessna Centurion/II 210",
			"C210",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CHANCELLOR_414 = new AircraftTypeModelCode(
			"Cessna Chancellor 414",
			"C414",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CITATION_I = new AircraftTypeModelCode(
			"Cessna Citation I",
			"C500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CITATION_I_SP = new AircraftTypeModelCode(
			"Cessna Citation I/SP",
			"C501SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CITATION_III = new AircraftTypeModelCode(
			"Cessna Citation III",
			"C553",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CONQUEST_CONQUEST_II_441 = new AircraftTypeModelCode(
			"Cessna Conquest / Conquest II 441",
			"C441",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CORSAIR_CONQUEST_I_425 = new AircraftTypeModelCode(
			"Cessna Corsair / Conquest I 425",
			"C425",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CRANE_BOBCAT = new AircraftTypeModelCode(
			"Cessna Crane / Bobcat",
			"CT50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_CRUSADER_303 = new AircraftTypeModelCode(
			"Cessna Crusader 303",
			"C303",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_GOLDEN_EAGLE_421 = new AircraftTypeModelCode(
			"Cessna Golden Eagle 421",
			"C421",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_III = new AircraftTypeModelCode(
			"Cessna III",
			"C650",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_SKYLANE_182_RG_TURBO_SKYLANE_RG = new AircraftTypeModelCode(
			"Cessna Skylane 182/RG, Turbo Skylane/RG",
			"C182",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_SKYLARK_175 = new AircraftTypeModelCode(
			"Cessna Skylark 175",
			"C175",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_SKYMASTER_336 = new AircraftTypeModelCode(
			"Cessna Skymaster 336",
			"C336",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_SKYNIGHT_320 = new AircraftTypeModelCode(
			"Cessna Skynight 320",
			"C320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_STATIONAIR_6_TURBO_STATIONAIR_6 = new AircraftTypeModelCode(
			"Cessna Stationair 6 / Turbo Stationair 6",
			"C206",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_SUPER_SKYWAGON_SUPER_SKYLANE = new AircraftTypeModelCode(
			"Cessna Super Skywagon / Super Skylane",
			"C205",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CESSNA_V = new AircraftTypeModelCode(
			"Cessna V",
			"C560",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_101_VOODOO = new AircraftTypeModelCode(
			"CF-101 Voodoo",
			"CF101",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_104_STARFIGHTER = new AircraftTypeModelCode(
			"CF-104 Starfighter",
			"CF104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_18_HORNET = new AircraftTypeModelCode(
			"CF-18 Hornet",
			"CF18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_188B_CE_15_EF_18B_F_A_18B = new AircraftTypeModelCode(
			"CF-188B / CE-15 / EF-18B / F/A-18B",
			"F18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_18A_HORNET = new AircraftTypeModelCode(
			"CF-18A Hornet",
			"CF18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_18B_HORNET = new AircraftTypeModelCode(
			"CF-18B Hornet",
			"CF18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_5_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"CF-5 Freedom Fighter",
			"CF5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_5A_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"CF-5A Freedom Fighter",
			"CF5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_5D_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"CF-5D Freedom Fighter",
			"CF5D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CF_5F_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"CF-5F Freedom Fighter",
			"CF5F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_113_LABRADOR = new AircraftTypeModelCode(
			"CH-113 Labrador",
			"CH113",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_113A_VOYAGEUR = new AircraftTypeModelCode(
			"CH-113A Voyageur",
			"CH113A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_118_IROQUOIS = new AircraftTypeModelCode(
			"CH-118 Iroquois",
			"CH118",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_124_SEA_KING = new AircraftTypeModelCode(
			"CH-124 Sea King",
			"CH124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_124B_SEA_KING = new AircraftTypeModelCode(
			"CH-124B Sea King",
			"CH124B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_135_AGUSTA_BELL_212 = new AircraftTypeModelCode(
			"CH-135 Agusta Bell 212",
			"CH135A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_135_IROQUOIS = new AircraftTypeModelCode(
			"CH-135 Iroquois",
			"CH135I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_135_IROQUOIS_III = new AircraftTypeModelCode(
			"CH-135 Iroquois III",
			"CHIII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_135_TWIN_HUEY = new AircraftTypeModelCode(
			"CH-135 Twin Huey",
			"CH135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_136_JETRANGER = new AircraftTypeModelCode(
			"CH-136 Jetranger",
			"CH136J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_136_KIOWA = new AircraftTypeModelCode(
			"CH-136 Kiowa",
			"CH136",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_146_412F_GRIFFON = new AircraftTypeModelCode(
			"CH-146 / 412F Griffon",
			"CH146",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_147_CHINOOK = new AircraftTypeModelCode(
			"CH-147 Chinook",
			"CH147",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH2000_ZENITH = new AircraftTypeModelCode(
			"CH2000 Zenith",
			"CH2000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_3 = new AircraftTypeModelCode(
			"CH-3",
			"CH3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_34_CHOCTAW = new AircraftTypeModelCode(
			"CH-34 Choctaw",
			"CH34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_34_SUPER_PUMA = new AircraftTypeModelCode(
			"CH-34 Super Puma",
			"CH34SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_34A_CHOCTAW = new AircraftTypeModelCode(
			"CH-34A Choctaw",
			"CH34A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_34D_CHOCTAW = new AircraftTypeModelCode(
			"CH-34D Choctaw",
			"CH34D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_37_MOHAVE = new AircraftTypeModelCode(
			"CH-37 Mohave",
			"CH37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_3E_SEA_KING = new AircraftTypeModelCode(
			"CH-3E Sea King",
			"CH3E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_46_SEA_KNIGHT = new AircraftTypeModelCode(
			"CH-46 Sea Knight",
			"CH46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_46A_SEA_KNIGHT = new AircraftTypeModelCode(
			"CH-46A Sea Knight",
			"CH46A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_46D_SEA_KNIGHT = new AircraftTypeModelCode(
			"CH-46D Sea Knight",
			"CH46D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_46E_SEA_KNIGHT = new AircraftTypeModelCode(
			"CH-46E Sea Knight",
			"CH46E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_46F_SEA_KNIGHT = new AircraftTypeModelCode(
			"CH-46F Sea Knight",
			"CH46F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47_CHINOOK_CH_147 = new AircraftTypeModelCode(
			"CH-47 Chinook / CH-147",
			"CH47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47A_CHINOOK = new AircraftTypeModelCode(
			"CH-47A Chinook",
			"CH47A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47B_CHINOOK = new AircraftTypeModelCode(
			"CH-47B Chinook",
			"CH47B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47C_CHINOOK = new AircraftTypeModelCode(
			"CH-47C Chinook",
			"CH47C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47D_CHINOOK = new AircraftTypeModelCode(
			"CH-47D Chinook",
			"CH47D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47J_CHINOOK_JAPAN = new AircraftTypeModelCode(
			"CH-47J Chinook Japan",
			"CH47J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_47JA = new AircraftTypeModelCode(
			"CH-47JA",
			"CH47JA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_50_ESQUILO_CH_50_ECUREUIL = new AircraftTypeModelCode(
			"CH-50 Esquilo / CH-50 Ecureuil",
			"CH50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53 Sea Stallion",
			"CH53",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53A_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53A Sea Stallion",
			"CH53A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_5BB_SEA_STALLION = new AircraftTypeModelCode(
			"CH-5Bb Sea Stallion",
			"CH53B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53C_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53C Sea Stallion",
			"CH53C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53D_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53D Sea Stallion",
			"CH53D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53DG_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53DG Sea Stallion",
			"CH53DG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53E_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53E Sea Stallion",
			"CH53E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53E_SUPER_STALLION = new AircraftTypeModelCode(
			"CH-53E Super Stallion",
			"CH53ES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_53G_SEA_STALLION = new AircraftTypeModelCode(
			"CH-53G Sea Stallion",
			"CH53G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_54_LARKE_SKYTRAIN = new AircraftTypeModelCode(
			"CH-54 Larke / Skytrain",
			"CH54LS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_54_SKYCRANE = new AircraftTypeModelCode(
			"CH-54 Skycrane",
			"CH54SC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_54_TARHE = new AircraftTypeModelCode(
			"CH-54 Tarhe",
			"CH54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_54A_TARHE = new AircraftTypeModelCode(
			"CH-54A Tarhe",
			"CH54A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_54B_TARHE = new AircraftTypeModelCode(
			"CH-54B Tarhe",
			"CH54B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_55_ECUREUIL_1 = new AircraftTypeModelCode(
			"CH-55 Ecureuil 1",
			"CH55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_601HD_ZODIAK = new AircraftTypeModelCode(
			"CH-601HD Zodiak",
			"CH601H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_601HDS_SUPER_ZODIAK = new AircraftTypeModelCode(
			"CH-601HDS Super Zodiak",
			"CH601S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CH_701_STOL = new AircraftTypeModelCode(
			"CH-701 STOL",
			"CH701",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHALLENGER_604 = new AircraftTypeModelCode(
			"Challenger 604",
			"CL604",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHANGHE_Z_11 = new AircraftTypeModelCode(
			"Changhe Z-11",
			"CHGZ11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHANGHE_Z_8_SUPER_FRELON = new AircraftTypeModelCode(
			"Changhe Z-8 Super Frelon",
			"CHGZ8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHE_22_CORVETTE = new AircraftTypeModelCode(
			"CHE-22 Corvette",
			"CHE22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHE_25 = new AircraftTypeModelCode(
			"CHE-25",
			"CHE25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHEETAH_LAMA = new AircraftTypeModelCode(
			"Cheetah Lama",
			"CHETA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHEROKEE_PILLAN = new AircraftTypeModelCode(
			"Cherokee Pillan",
			"CHEROK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHETAK_ALOUETTE_II = new AircraftTypeModelCode(
			"Chetak Alouette II",
			"CHKII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHETAK_ALOUETTE_III = new AircraftTypeModelCode(
			"Chetak Alouette III",
			"CHKIII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHEVRON_2_32_C = new AircraftTypeModelCode(
			"Chevron 2-32 C",
			"232C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHEYENNE_NAVAJO = new AircraftTypeModelCode(
			"Cheyenne Navajo",
			"CHEY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHIEFTAIN_NAVAJO = new AircraftTypeModelCode(
			"Chieftain Navajo",
			"CHIEF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHIPMUNK = new AircraftTypeModelCode(
			"Chipmunk",
			"CHIP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHK_91_BLUE_SKY_91_KAL_CHK_91 = new AircraftTypeModelCode(
			"CHK-91 Blue Sky 91 / KAL CHK-91",
			"CHK91",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CHRISTEN_MODEL_A_1_HUSKEY = new AircraftTypeModelCode(
			"Christen Model A-1 Huskey",
			"CA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CJ_5_MAX = new AircraftTypeModelCode(
			"CJ-5 Max",
			"CJ5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CJ_6A_PT_6A = new AircraftTypeModelCode(
			"CJ-6A / PT-6A",
			"CJ6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_214_CANADAIR = new AircraftTypeModelCode(
			"CL-214 Canadair",
			"CL214",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_215_AMPHIBIAN_CL_215_6B = new AircraftTypeModelCode(
			"CL-215 Amphibian / CL-215-6B",
			"CL2156",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_215_CANADAIR = new AircraftTypeModelCode(
			"CL-215 Canadair",
			"CL215",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_215T = new AircraftTypeModelCode(
			"CL-215T",
			"CL215T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_41_TUTOR = new AircraftTypeModelCode(
			"CL-41 Tutor",
			"CL41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_415 = new AircraftTypeModelCode(
			"CL-415",
			"CL415",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_415M = new AircraftTypeModelCode(
			"CL-415M",
			"CL415M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_41G_TUTOR = new AircraftTypeModelCode(
			"CL-41G Tutor",
			"CL41G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_44_CANADAIR_400 = new AircraftTypeModelCode(
			"CL-44 Canadair 400",
			"CL44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_600_CANADAIR_600 = new AircraftTypeModelCode(
			"CL-600 Canadair 600",
			"CL600C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_600_CHALLENGER = new AircraftTypeModelCode(
			"CL-600 Challenger",
			"CL600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_601_CANADAIR_601 = new AircraftTypeModelCode(
			"CL-601 Canadair 601",
			"CL601C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CL_601_CHALLENGER = new AircraftTypeModelCode(
			"CL-601 Challenger",
			"CL601",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CLASSIC_IL_62 = new AircraftTypeModelCode(
			"Classic / Il-62",
			"IL62",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CM_170_FOUGA_MAGISTER = new AircraftTypeModelCode(
			"CM-170 Fouga Magister",
			"CM170",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CM_175_ZEPHYR = new AircraftTypeModelCode(
			"CM-175 Zephyr",
			"CM175",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CM_AU_MAGLITR = new AircraftTypeModelCode(
			"CM-AU Maglitr",
			"CMAU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_MK1K = new AircraftTypeModelCode(
			"C-MK1K",
			"HCMK1K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_MK3 = new AircraftTypeModelCode(
			"C-MK3",
			"HCMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_MK3_HERCULES = new AircraftTypeModelCode(
			"C-MK3 Hercules",
			"HCM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode C_MK5 = new AircraftTypeModelCode(
			"C-MK5",
			"HCMK5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_CASA = new AircraftTypeModelCode(
			"CN-235 Casa",
			"CN235",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_MP_PERSUADER = new AircraftTypeModelCode(
			"CN-235 MP Persuader",
			"CN235M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_MPA = new AircraftTypeModelCode(
			"CN-235 MPA",
			"CN235A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_100 = new AircraftTypeModelCode(
			"CN-235-100",
			"CN2351",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_200 = new AircraftTypeModelCode(
			"CN-235-200",
			"CN2352",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_235_330_PHOENIX = new AircraftTypeModelCode(
			"CN-235-330 Phoenix",
			"CN2353",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CN_245 = new AircraftTypeModelCode(
			"CN-245",
			"CN245",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COASTGUARDIAN_ANDOVER = new AircraftTypeModelCode(
			"Coastguardian Andover",
			"CG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COCHISE_BARON_55 = new AircraftTypeModelCode(
			"Cochise Baron 55",
			"COCH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COCK_A_ANTHEUS = new AircraftTypeModelCode(
			"Cock A Antheus",
			"ACOCKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COCK_ANTHEUS = new AircraftTypeModelCode(
			"Cock Antheus",
			"ACOCK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COCK_B_ANTHEUS = new AircraftTypeModelCode(
			"Cock B Antheus",
			"ACOCKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMANCHE_TWIN = new AircraftTypeModelCode(
			"Comanche Twin",
			"COMAN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMM1_COMMANDO = new AircraftTypeModelCode(
			"Comm1 Commando",
			"COMM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMM2A_COMMANDO = new AircraftTypeModelCode(
			"Comm2A Commando",
			"COMM2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMM3_COMMANDO = new AircraftTypeModelCode(
			"Comm3 Commando",
			"COMM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_114B = new AircraftTypeModelCode(
			"Commander 114B",
			"CO114B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_500_AERO_COMMANDER = new AircraftTypeModelCode(
			"Commander 500 Aero Commander",
			"COM500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_560_XINGU = new AircraftTypeModelCode(
			"Commander 560 Xingu",
			"COM560",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_600_AERO_COMMANDER = new AircraftTypeModelCode(
			"Commander 600 Aero Commander",
			"COM600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_681B = new AircraftTypeModelCode(
			"Commander 681B",
			"CO681B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_685 = new AircraftTypeModelCode(
			"Commander 685",
			"CO685",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDER_690A = new AircraftTypeModelCode(
			"Commander 690A",
			"CO690",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDO_MK_1 = new AircraftTypeModelCode(
			"Commando MK-1",
			"CMMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDO_MK_2 = new AircraftTypeModelCode(
			"Commando MK-2",
			"CMMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDO_MK_2E = new AircraftTypeModelCode(
			"Commando MK-2E",
			"CMMK2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDO_MK_3 = new AircraftTypeModelCode(
			"Commando MK-3",
			"CMMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COMMANDO_MK_4 = new AircraftTypeModelCode(
			"Commando MK-4",
			"CMMK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONAIR_TURBO_FIRECAT = new AircraftTypeModelCode(
			"Conair Turbo Firecat",
			"CONTUR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONCORDE_SST = new AircraftTypeModelCode(
			"Concorde SST",
			"SST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONDOR_526_AFM = new AircraftTypeModelCode(
			"Condor / 526 AFM",
			"AFM526",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONQUEST_I = new AircraftTypeModelCode(
			"Conquest I",
			"CECON1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONQUEST_II = new AircraftTypeModelCode(
			"Conquest II",
			"CECON2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONTENDER_202 = new AircraftTypeModelCode(
			"Contender 202",
			"CON202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONTENDER_303 = new AircraftTypeModelCode(
			"Contender 303",
			"CON303",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CONTENDER_606 = new AircraftTypeModelCode(
			"Contender 606",
			"CON606",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CORA_ALLEGRO = new AircraftTypeModelCode(
			"Cora Allegro",
			"CORA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CORRIEDALE_SD_27 = new AircraftTypeModelCode(
			"Corriedale SD 27",
			"SD27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COUGAR_MK_I = new AircraftTypeModelCode(
			"Cougar MK I",
			"COUMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COUGAR_MK_II = new AircraftTypeModelCode(
			"Cougar MK II",
			"COUMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode COURIER_S_7 = new AircraftTypeModelCode(
			"Courier S-7",
			"COURS7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CP_121_TRACKER = new AircraftTypeModelCode(
			"CP-121 Tracker",
			"CP121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CP_140_AURORA = new AircraftTypeModelCode(
			"CP-140 Aurora",
			"CP140",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CP_140A_P_3_ORION_ARCTURUS = new AircraftTypeModelCode(
			"CP-140A P-3 / Orion Arcturus",
			"CP140A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CR_100 = new AircraftTypeModelCode(
			"CR-100",
			"CR100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CR_110 = new AircraftTypeModelCode(
			"CR-110",
			"CR110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CROSSPOINTER_TW_18 = new AircraftTypeModelCode(
			"Crosspointer TW-18",
			"TW18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CS_2F_TRACKER_MK_2_CS_2F_TRACKER_MK_A = new AircraftTypeModelCode(
			"CS-2F Tracker MK-2 / CS-2F Tracker MK-A",
			"CS2FA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CSH_2_ROOIVAALK_RED_KESTREL_ROOIVALK = new AircraftTypeModelCode(
			"CSH-2 Rooivaalk / Red Kestrel / Rooivalk",
			"CSH2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_114 = new AircraftTypeModelCode(
			"CT-114",
			"CT114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_133_SHOOTING_STAR = new AircraftTypeModelCode(
			"CT-133 Shooting Star",
			"CT133",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_134_MUSKETEER = new AircraftTypeModelCode(
			"CT-134 Musketeer",
			"CT134",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_134A_MUSKETEER = new AircraftTypeModelCode(
			"CT-134A Musketeer",
			"CT134A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_142_DHC_8 = new AircraftTypeModelCode(
			"CT-142 / DHC-8",
			"CT142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_33_SHOOTING_STAR = new AircraftTypeModelCode(
			"CT-33 Shooting Star",
			"CT33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_39 = new AircraftTypeModelCode(
			"CT-39",
			"CT39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_39A = new AircraftTypeModelCode(
			"CT-39A",
			"CT39A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_39E = new AircraftTypeModelCode(
			"CT-39E",
			"CT39E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_39F = new AircraftTypeModelCode(
			"CT-39F",
			"CT39F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_39G = new AircraftTypeModelCode(
			"CT-39G",
			"CT39G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_43A = new AircraftTypeModelCode(
			"CT-43A",
			"CT43A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CT_4A_AIRTRAINER = new AircraftTypeModelCode(
			"CT-4A Airtrainer",
			"CT4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CUFF = new AircraftTypeModelCode(
			"Cuff",
			"CUF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CURL_A = new AircraftTypeModelCode(
			"Curl A",
			"CURLA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CV_22A_OSPREY = new AircraftTypeModelCode(
			"CV-22A Osprey",
			"CV22A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CV_34_COSMOPOLITAN = new AircraftTypeModelCode(
			"CV-34 Cosmopolitan",
			"CV34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CVAIR_440_CONVAIR_MTPLTN = new AircraftTypeModelCode(
			"CVAIR-440 Convair-MTPLTN",
			"CV440",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CVAIR_580 = new AircraftTypeModelCode(
			"CVAIR-580",
			"CV580",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CVAIR_880_CONVAIR_MTPLTN = new AircraftTypeModelCode(
			"CVAIR-880 Convair-MTPLTN",
			"CV880",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode CYGNET_SF_25A = new AircraftTypeModelCode(
			"Cygnet SF-25A",
			"SF25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode D139_PT1 = new AircraftTypeModelCode(
			"D139-PT1",
			"D139P1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode D_4 = new AircraftTypeModelCode(
			"D-4",
			"DALD4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_10_FALCON_10 = new AircraftTypeModelCode(
			"DA-10 Falcon 10",
			"DA10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_20_A1_KATANA = new AircraftTypeModelCode(
			"DA-20 A1 Katana",
			"DA20A1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_20_C1_SPEED_KATANA = new AircraftTypeModelCode(
			"DA-20 C1 Speed Katana",
			"DA20C1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_20_FALCON_20 = new AircraftTypeModelCode(
			"DA-20 Falcon 20",
			"DA20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_21_MYSTERE_FALCON = new AircraftTypeModelCode(
			"DA-21 Mystere Falcon",
			"FAL21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_21M_FALCON_20G_20GF_MYSTERE_FALCON_200 = new AircraftTypeModelCode(
			"DA-21M Falcon 20G / 20GF Mystere Falcon 200",
			"FAL21M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_2A = new AircraftTypeModelCode(
			"DA-2A",
			"DA2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_40_KATANA = new AircraftTypeModelCode(
			"DA-40 Katana",
			"DA40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DA_50_FALCON_50 = new AircraftTypeModelCode(
			"DA-50 Falcon 50",
			"DA50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DASA_2000_RANGER_2000 = new AircraftTypeModelCode(
			"Dasa 2000 / Ranger 2000",
			"DA2000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DASA_X_31A_EFM = new AircraftTypeModelCode(
			"Dasa X-31A EFM",
			"X31A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DASH_7 = new AircraftTypeModelCode(
			"Dash-7",
			"DSH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DASSAULT_MERCURE = new AircraftTypeModelCode(
			"Dassault Mercure",
			"DA01",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DASSAULT_SUPER_ETENDARD = new AircraftTypeModelCode(
			"Dassault Super Etendard",
			"SETE4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DAUPHIN = new AircraftTypeModelCode(
			"Dauphin",
			"DPN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DAUPHIN_2_AS_365N = new AircraftTypeModelCode(
			"Dauphin 2 / AS-365N",
			"AS365N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DAUPHIN_DR_400 = new AircraftTypeModelCode(
			"Dauphin Dr 400",
			"RDR400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DAUPHIN_FRENCH_TWIN = new AircraftTypeModelCode(
			"Dauphin French Twin",
			"DAUPH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DAUPHIN_Z_9 = new AircraftTypeModelCode(
			"Dauphin Z-9",
			"Z9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_10_DOUGLAS = new AircraftTypeModelCode(
			"DC-10/10 Douglas",
			"DC10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_10CF = new AircraftTypeModelCode(
			"DC-10/10CF",
			"DC101C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_15_DOUGLAS = new AircraftTypeModelCode(
			"DC-10/15 Douglas",
			"DC1015",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_30_DOUGLAS = new AircraftTypeModelCode(
			"DC-10/30 Douglas",
			"DC1030",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_40_DOUGLAS = new AircraftTypeModelCode(
			"DC-10/40 Douglas",
			"DC1040",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_30CF = new AircraftTypeModelCode(
			"DC-10-30CF",
			"DC103C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10_30F = new AircraftTypeModelCode(
			"DC-10-30F",
			"DC103F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_10CF_DOUGLAS = new AircraftTypeModelCode(
			"DC-10CF Douglas",
			"DC10CF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_130_HERCULES = new AircraftTypeModelCode(
			"DC-130 Hercules",
			"DC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_130A_HERCULES = new AircraftTypeModelCode(
			"DC-130A Hercules",
			"DC130A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_130H_HERCULES = new AircraftTypeModelCode(
			"DC-130h Hercules",
			"DC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_3_DOUGLAS = new AircraftTypeModelCode(
			"DC-3 Douglas",
			"DC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_4_DOUGLAS = new AircraftTypeModelCode(
			"DC-4 Douglas",
			"DC4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_6_DOUGLAS = new AircraftTypeModelCode(
			"DC-6 Douglas",
			"DC6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_6B_DOUGLAS = new AircraftTypeModelCode(
			"DC-6B Douglas",
			"DC6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_6C_DOUGLAS = new AircraftTypeModelCode(
			"DC-6C Douglas",
			"DC6C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_7_DOUGLAS = new AircraftTypeModelCode(
			"DC-7 Douglas",
			"DC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_7B_SPEEDFREIGHTER = new AircraftTypeModelCode(
			"DC-7B Speedfreighter",
			"DC7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_DOUGLAS = new AircraftTypeModelCode(
			"DC-8 Douglas",
			"DC8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_SARIGUE = new AircraftTypeModelCode(
			"DC-8 Sarigue",
			"DC8SAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_10_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/10 Douglas",
			"DC810",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_20_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/20 Douglas",
			"DC820",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_30_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/30 Douglas",
			"DC830",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_43 = new AircraftTypeModelCode(
			"DC-8/43",
			"DC843",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_50_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/50 Douglas",
			"DC850",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_54_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/54 Douglas",
			"DC854",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_55_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/55 Douglas",
			"DC855",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_60_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/60 Douglas",
			"DC860",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_61_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/61 Douglas",
			"DC861",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_62_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/62 Douglas",
			"DC862",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_63_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/63 Douglas",
			"DC863",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_70_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/70 Douglas",
			"DC870",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_71_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/71 Douglas",
			"DC871",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8_73_DOUGLAS = new AircraftTypeModelCode(
			"DC-8/73 Douglas",
			"DC873",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_8F_DOUGLAS = new AircraftTypeModelCode(
			"DC-8F Douglas",
			"DC8F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_DOUGLAS = new AircraftTypeModelCode(
			"DC-9 Douglas",
			"DC9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_10_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/10 Douglas",
			"DC910",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_10_M15_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/10 M15 Douglas",
			"DC910M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_20_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/20 Douglas",
			"DC920",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_30_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/30 Douglas",
			"DC930",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_32_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/32 Douglas",
			"DC932",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_40_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/40 Douglas",
			"DC940",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_50_MCDONNELL_DC_9 = new AircraftTypeModelCode(
			"DC-9/50 Mcdonnell DC-9",
			"DC9M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_50_MCDONNELL_DC_9_50 = new AircraftTypeModelCode(
			"DC-9/50 Mcdonnell DC-9/50",
			"DC950",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9_51_DOUGLAS = new AircraftTypeModelCode(
			"DC-9/51 Douglas",
			"DC951",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DC_9F_30_DOUGLAS = new AircraftTypeModelCode(
			"DC-9F/30 Douglas",
			"DC9F30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_COMET_2 = new AircraftTypeModelCode(
			"Dehavilland Comet 2",
			"DH62",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_COMET_4 = new AircraftTypeModelCode(
			"Dehavilland Comet 4",
			"DH64",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_DOVE_DEVON_DH_104 = new AircraftTypeModelCode(
			"Dehavilland Dove Devon Dh-104",
			"DH10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_DRAGON_RAPIDE = new AircraftTypeModelCode(
			"Dehavilland Dragon Rapide",
			"DH89",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_FOX_MOTH = new AircraftTypeModelCode(
			"Dehavilland Fox Moth",
			"DH83",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_GYPSY_MOTH = new AircraftTypeModelCode(
			"Dehavilland Gypsy Moth",
			"DH60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_HORNET_MOTH = new AircraftTypeModelCode(
			"Dehavilland Hornet Moth",
			"DH87",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_MOSQUITO = new AircraftTypeModelCode(
			"Dehavilland Mosquito",
			"DH98",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_PUSS_MOTH = new AircraftTypeModelCode(
			"Dehavilland Puss Moth",
			"DH80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_TIGER_MOTH = new AircraftTypeModelCode(
			"Dehavilland Tiger Moth",
			"DH82",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DEHAVILLAND_TURBO_BEAVER_DHC_2T = new AircraftTypeModelCode(
			"Dehavilland Turbo Beaver DHC-2T",
			"DH2T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DELFIN_MAYA = new AircraftTypeModelCode(
			"Delfin Maya",
			"DELFIN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DELTA_DART_II = new AircraftTypeModelCode(
			"Delta-Dart II",
			"DEDE2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DH_114_HERON_C_2 = new AircraftTypeModelCode(
			"DH-114 Heron C-2",
			"DH114A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DH_114_HERON_HS = new AircraftTypeModelCode(
			"DH-114 Heron HS",
			"DC114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DH_114B_HERON_HS = new AircraftTypeModelCode(
			"DH-114B Heron HS",
			"DH114B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_1_T_10 = new AircraftTypeModelCode(
			"DHC-1 / T-10",
			"DHC1T1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_1_T_30 = new AircraftTypeModelCode(
			"DHC-1 / T-30",
			"DHC1T3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_1_CHIPMUNK = new AircraftTypeModelCode(
			"DHC-1 Chipmunk",
			"DHC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_1_CHIPMUNK_T_10 = new AircraftTypeModelCode(
			"DHC-1 Chipmunk T-10",
			"DHCT10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_1_CHIPMUNK_T_30 = new AircraftTypeModelCode(
			"DHC-1 Chipmunk T-30",
			"DHCT30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_2_AL_2 = new AircraftTypeModelCode(
			"DHC-2 / AL-2",
			"DHC2A2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_2_BEAVER = new AircraftTypeModelCode(
			"DHC-2 Beaver",
			"DHC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_2_BEAVER_AL_2 = new AircraftTypeModelCode(
			"DHC-2 Beaver AL-2",
			"DHCAL2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_2_MK_III_TURBO_BEAVER = new AircraftTypeModelCode(
			"DHC-2 MK III Turbo Beaver",
			"DHC2M3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_3_OTTER = new AircraftTypeModelCode(
			"DHC-3 Otter",
			"DHC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_3_U_1A_OTTER = new AircraftTypeModelCode(
			"DHC-3 U-1A Otter",
			"DHC3U1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_4_CARIBOU = new AircraftTypeModelCode(
			"DHC-4 Caribou",
			"DHC4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_4A_CARIBOU = new AircraftTypeModelCode(
			"DHC-4A Caribou",
			"DHC4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_5_BUFFALO = new AircraftTypeModelCode(
			"DHC-5 Buffalo",
			"DHC5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_5D_BUFFALO = new AircraftTypeModelCode(
			"DHC-5D Buffalo",
			"DHC5D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_5E = new AircraftTypeModelCode(
			"DHC-5E",
			"DHC5E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_100_TWIN_OTTER = new AircraftTypeModelCode(
			"DHC-6 100 Twin Otter",
			"DHC6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_100 = new AircraftTypeModelCode(
			"DHC-6-100",
			"DHC610",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_200 = new AircraftTypeModelCode(
			"DHC-6-200",
			"DHC620",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_300 = new AircraftTypeModelCode(
			"DHC-6-300",
			"DHC630",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_300M = new AircraftTypeModelCode(
			"DHC-6-300M",
			"DHC63M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_300MR = new AircraftTypeModelCode(
			"DHC-6-300MR",
			"DHC63R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_6_300S = new AircraftTypeModelCode(
			"DHC-6-300S",
			"DHC63S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_7_DASH_7 = new AircraftTypeModelCode(
			"DHC-7 Dash 7",
			"DHC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_7R = new AircraftTypeModelCode(
			"DHC-7R",
			"DHC7R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_DASH_8_DHC_8_COMMUTER = new AircraftTypeModelCode(
			"DHC-8 Dash 8 / DHC-8 Commuter",
			"DHC8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_TRITON = new AircraftTypeModelCode(
			"DHC-8 Triton",
			"DHC8TR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_100 = new AircraftTypeModelCode(
			"DHC-8-100",
			"DHC810",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_200 = new AircraftTypeModelCode(
			"DHC-8-200",
			"DHC820",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_300 = new AircraftTypeModelCode(
			"DHC-8-300",
			"DHC830",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8_400 = new AircraftTypeModelCode(
			"DHC-8-400",
			"DHC840",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_8M = new AircraftTypeModelCode(
			"DHC-8M",
			"DHC8M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DHC_E_OTTER_CSR_1_2_3 = new AircraftTypeModelCode(
			"DHC-E Otter CSR 1-2-3",
			"DHCCSR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DINGO = new AircraftTypeModelCode(
			"Dingo",
			"DINGO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DK_10_DRACULA = new AircraftTypeModelCode(
			"DK-10 Dracula",
			"DK10D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_JET = new AircraftTypeModelCode(
			"DO 328 Jet",
			"DO328J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_528_JET_328_700 = new AircraftTypeModelCode(
			"DO 528 Jet / 328-700",
			"DO528J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_128_DORNIER = new AircraftTypeModelCode(
			"DO-128 Dornier",
			"DO128",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_128_2_DORNIER_DO_128_2_SKYSERVANT = new AircraftTypeModelCode(
			"DO-128-2 Dornier / DO-128-2 Skyservant",
			"DO1282",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_128_6_TURBO_SKY_DO_128_6_TURBO_SKYSERVANT = new AircraftTypeModelCode(
			"DO-128-6 Turbo-Sky / DO-128-6 Turbo-Skyservant",
			"DO1286",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_DORNIER = new AircraftTypeModelCode(
			"DO-228 Dornier",
			"DO228",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_DORNIER_100 = new AircraftTypeModelCode(
			"DO-228 Dornier 100",
			"DO228D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_DORNIER_100A = new AircraftTypeModelCode(
			"DO-228 Dornier 100A",
			"DO228C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_MARITIME_POLLUTION_SURVEILLANCE = new AircraftTypeModelCode(
			"DO-228 Maritime Pollution Surveillance",
			"DO228M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_PHOTO_SURVEY = new AircraftTypeModelCode(
			"DO-228 Photo Survey",
			"DO228P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_100_DO_228_101 = new AircraftTypeModelCode(
			"DO-228-100 / DO 228-101",
			"DO2281",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_101 = new AircraftTypeModelCode(
			"DO-228-101",
			"D22811",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228_201 = new AircraftTypeModelCode(
			"DO-228-201",
			"D22821",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228A_DORNIER = new AircraftTypeModelCode(
			"DO-228A Dornier",
			"DO228A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_228B_DORNIER = new AircraftTypeModelCode(
			"DO-228B Dornier",
			"DO228B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_27_DORNIER = new AircraftTypeModelCode(
			"DO-27 Dornier",
			"DO27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_28_D_1_SKYSERVANT = new AircraftTypeModelCode(
			"DO-28 D-1 Skyservant",
			"DO28D1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_28_D_2T_DORNIER = new AircraftTypeModelCode(
			"DO-28 D-2T Dornier",
			"DO28DT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_28_DORNIER = new AircraftTypeModelCode(
			"DO-28 Dornier",
			"DO28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_28D = new AircraftTypeModelCode(
			"DO-28D",
			"DO28D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328 = new AircraftTypeModelCode(
			"DO-328",
			"D328",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_DORNIER = new AircraftTypeModelCode(
			"DO-328 Dornier",
			"DO328",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_100 = new AircraftTypeModelCode(
			"DO-328-100",
			"D32810",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_110 = new AircraftTypeModelCode(
			"DO-328-110",
			"D32811",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_120 = new AircraftTypeModelCode(
			"DO-328-120",
			"D32812",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_130 = new AircraftTypeModelCode(
			"DO-328-130",
			"D32813",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_210 = new AircraftTypeModelCode(
			"DO-328-210",
			"D32821",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_300 = new AircraftTypeModelCode(
			"DO-328-300",
			"D32830",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_500 = new AircraftTypeModelCode(
			"DO-328-500",
			"D32850",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DO_328_700 = new AircraftTypeModelCode(
			"DO-328-700",
			"D32870",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DOMINIE_MERCURIUS = new AircraftTypeModelCode(
			"Dominie Mercurius",
			"DOMIN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DOMINIE_T_MK_1 = new AircraftTypeModelCode(
			"Dominie T.MK 1",
			"DOM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DORNIER_ALPHA_JET = new AircraftTypeModelCode(
			"Dornier Alpha Jet",
			"DOAJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DP_6000 = new AircraftTypeModelCode(
			"DP-6000",
			"DP6000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DP_800 = new AircraftTypeModelCode(
			"DP-800",
			"DP800",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_DAUPHIN = new AircraftTypeModelCode(
			"DR 400 Dauphin",
			"DR400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_V6 = new AircraftTypeModelCode(
			"DR 400 V6",
			"DR4006",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_100_CADET = new AircraftTypeModelCode(
			"DR 400-100 Cadet",
			"DR4001",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_120_2_2_DAUPHIN = new AircraftTypeModelCode(
			"DR 400-120 2+2 Dauphin",
			"DR4012",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_160_MAJOR = new AircraftTypeModelCode(
			"DR 400-160 Major",
			"DR4016",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_180_REGENT = new AircraftTypeModelCode(
			"DR 400-180 Regent",
			"DR4018",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_180R_REMO_180 = new AircraftTypeModelCode(
			"DR 400-180r Remo 180",
			"DR401R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_200I_PRESIDENT = new AircraftTypeModelCode(
			"DR 400-200i President",
			"DR4020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DR_400_200R_REMO_200 = new AircraftTypeModelCode(
			"DR 400-200r Remo 200",
			"DR402R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DROMADER = new AircraftTypeModelCode(
			"Dromader",
			"PZLDRO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DUBNA_2_OSA_DUBNA_2_WASP = new AircraftTypeModelCode(
			"Dubna-2 / Osa Dubna-2 / Wasp",
			"DUBNA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DUET_SARAS_M_102 = new AircraftTypeModelCode(
			"Duet / Saras / M-102",
			"M102",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DV_20_KATANA = new AircraftTypeModelCode(
			"DV-20 Katana",
			"DV20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode DV_40_FLA = new AircraftTypeModelCode(
			"DV-40 Fla",
			"DV40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_1_TRACER = new AircraftTypeModelCode(
			"E-1 Tracer",
			"E1S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_2_HAWKEYE = new AircraftTypeModelCode(
			"E-2 Hawkeye",
			"E2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_25_AVIOJET_MIRLO = new AircraftTypeModelCode(
			"E-25 Aviojet / Mirlo",
			"E25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_26_TAMIZ = new AircraftTypeModelCode(
			"E-26 / Tamiz",
			"E26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_2A_HAWKEYE = new AircraftTypeModelCode(
			"E-2A Hawkeye",
			"E2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_2B_HAWKEYE = new AircraftTypeModelCode(
			"E-2B Hawkeye",
			"E2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_2C_HAWKEYE = new AircraftTypeModelCode(
			"E-2C Hawkeye",
			"E2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E2E_SPEEDTWIN = new AircraftTypeModelCode(
			"E2E Speedtwin",
			"E2EST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3_SENTRY_AWACS = new AircraftTypeModelCode(
			"E-3 Sentry Awacs",
			"E3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3A_SENTRY = new AircraftTypeModelCode(
			"E-3A Sentry",
			"E3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3B_SENTRY = new AircraftTypeModelCode(
			"E-3B Sentry",
			"E3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3C_SENTRY = new AircraftTypeModelCode(
			"E-3C Sentry",
			"E3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3D_AEW_MK1 = new AircraftTypeModelCode(
			"E-3D AEW MK1",
			"E3DMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3D_SENTRY = new AircraftTypeModelCode(
			"E-3D Sentry",
			"E3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3F_SENTRY = new AircraftTypeModelCode(
			"E-3F Sentry",
			"E3F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3INT = new AircraftTypeModelCode(
			"E-3INT",
			"E3INT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_3NTC = new AircraftTypeModelCode(
			"E-3NTC",
			"E3NTC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4_AABNCP = new AircraftTypeModelCode(
			"E-4 AABNCP",
			"E4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4_TACAMO_NEACP = new AircraftTypeModelCode(
			"E-4 Tacamo / Neacp",
			"E4TN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4A_AABNCP = new AircraftTypeModelCode(
			"E-4A AABNCP",
			"E4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4A_NEACP = new AircraftTypeModelCode(
			"E-4A Neacp",
			"E4AN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4B_AABNCP = new AircraftTypeModelCode(
			"E-4B AABNCP",
			"E4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_4B_NEACP = new AircraftTypeModelCode(
			"E-4B Neacp",
			"E4BN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_6_TACAMO = new AircraftTypeModelCode(
			"E-6 Tacamo",
			"E6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_6A_MERCURY_TACAMO = new AircraftTypeModelCode(
			"E-6A Mercury Tacamo",
			"E6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_6B_TACAMO_ABNCP = new AircraftTypeModelCode(
			"E-6B Tacamo / Abncp",
			"E6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_767_AWACS = new AircraftTypeModelCode(
			"E-767 Awacs",
			"E767",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_8_JOINT_STARS = new AircraftTypeModelCode(
			"E-8 Joint Stars",
			"E8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_8A_JOINT_STARS = new AircraftTypeModelCode(
			"E-8A Joint Stars",
			"E8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_8B = new AircraftTypeModelCode(
			"E-8B",
			"E8B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_8C_JOINT_STARS = new AircraftTypeModelCode(
			"E-8C Joint Stars",
			"E8C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_8D_JOINT_STARS = new AircraftTypeModelCode(
			"E-8D Joint Stars",
			"E8D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode E_9A_DASH_8 = new AircraftTypeModelCode(
			"E-9A Dash 8",
			"E9A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_1_KINGFISHER = new AircraftTypeModelCode(
			"EA-1 Kingfisher",
			"EA1KF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_3B_SKYWARRIOR = new AircraftTypeModelCode(
			"EA-3B Skywarrior",
			"EA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_4F = new AircraftTypeModelCode(
			"EA-4F",
			"EA4F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_4J = new AircraftTypeModelCode(
			"EA-4J",
			"EA4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_6_INTRUDER = new AircraftTypeModelCode(
			"EA-6 Intruder",
			"EA6I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_6_PROWLER = new AircraftTypeModelCode(
			"EA-6 Prowler",
			"EA6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_6A_PROWLER = new AircraftTypeModelCode(
			"EA-6A Prowler",
			"EA6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_6B_PROWLER = new AircraftTypeModelCode(
			"EA-6B Prowler",
			"EA6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA7_OPTICA = new AircraftTypeModelCode(
			"EA7 Optica",
			"EA7OPT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EA_7L = new AircraftTypeModelCode(
			"EA-7L",
			"EA7L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EAGLE_X_TS = new AircraftTypeModelCode(
			"Eagle X-Ts",
			"XTS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EB_57_CANBERRA = new AircraftTypeModelCode(
			"EB-57 Canberra",
			"EB57B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EB_66_DESTROYER = new AircraftTypeModelCode(
			"EB-66 Destroyer",
			"EB66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_SUPER_FIVE = new AircraftTypeModelCode(
			"EC Super Five",
			"ECSUP5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_1 = new AircraftTypeModelCode(
			"EC-1",
			"EC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_120B_COLIBRI = new AircraftTypeModelCode(
			"EC-120B Colibri",
			"EC120B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_121_CONSTELLATION = new AircraftTypeModelCode(
			"EC-121 Constellation",
			"EC121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_121K_WARNING_STAR = new AircraftTypeModelCode(
			"EC-121K Warning Star",
			"EC121K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130_HERCULES = new AircraftTypeModelCode(
			"EC-130 Hercules",
			"EC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130_HERCULES_COMPASS_CALL = new AircraftTypeModelCode(
			"EC-130 Hercules Compass Call",
			"EC130C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130B_HERCULES = new AircraftTypeModelCode(
			"EC-130B Hercules",
			"EC130B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130E_HERCULES_ABCCC = new AircraftTypeModelCode(
			"EC-130E Hercules Abccc",
			"EC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130G_HERCULES_TACAMO = new AircraftTypeModelCode(
			"EC-130G Hercules Tacamo",
			"EC130G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130H_HERCULES_COMPASS_CALL = new AircraftTypeModelCode(
			"EC-130H Hercules Compass Call",
			"EC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130J_COMMAND_SOLO = new AircraftTypeModelCode(
			"EC-130J Command Solo",
			"EC130J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130L_HERCULES = new AircraftTypeModelCode(
			"EC-130L Hercules",
			"EC130L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130Q_HERCULES_TACAMO = new AircraftTypeModelCode(
			"EC-130Q Hercules Tacamo",
			"EC130Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_130V_HERCULES = new AircraftTypeModelCode(
			"EC-130V Hercules",
			"EC130V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135 Stratolifter",
			"EC135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135A_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135A Stratolifter",
			"EC135A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135C_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135C Stratolifter",
			"EC135C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135E_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135E Stratolifter",
			"EC135E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135G_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135G Stratolifter",
			"EC135G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135H_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135H Stratolifter",
			"EC135H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135J_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135J Stratolifter",
			"EC135J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135K_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135K Stratolifter",
			"EC135K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135L_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135L Stratolifter",
			"EC135L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135P_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135P Stratolifter",
			"EC135P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_135Y_STRATOLIFTER = new AircraftTypeModelCode(
			"EC-135Y Stratolifter",
			"EC135Y",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_137D = new AircraftTypeModelCode(
			"EC-137D",
			"EC137D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_145 = new AircraftTypeModelCode(
			"EC-145",
			"EC145",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_165 = new AircraftTypeModelCode(
			"EC-165",
			"EC165",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_18_ARIA = new AircraftTypeModelCode(
			"EC-18 Aria",
			"EC18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_18B_ARIA = new AircraftTypeModelCode(
			"EC-18B Aria",
			"EC18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_18C_JOINT_STARS = new AircraftTypeModelCode(
			"EC-18C Joint Stars",
			"EC18C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_18D = new AircraftTypeModelCode(
			"EC-18D",
			"EC18D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_18D_ARIA = new AircraftTypeModelCode(
			"EC-18D Aria",
			"EC018D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_24A = new AircraftTypeModelCode(
			"EC-24A",
			"EC24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_35A = new AircraftTypeModelCode(
			"EC-35A",
			"EC35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_6_CRIQUET = new AircraftTypeModelCode(
			"EC-6 Criquet",
			"EC6CRI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_635 = new AircraftTypeModelCode(
			"EC-635",
			"EC635",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EC_95 = new AircraftTypeModelCode(
			"EC-95",
			"EC95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ECUREUIL = new AircraftTypeModelCode(
			"Ecureuil",
			"ECURE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_111_RAVEN = new AircraftTypeModelCode(
			"EF-111 Raven",
			"EF111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_111A_GD_RAVEN = new AircraftTypeModelCode(
			"EF-111A GD Raven",
			"EF111G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_111A_RAVEN = new AircraftTypeModelCode(
			"EF-111A Raven",
			"EF111A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_18A_HORNET = new AircraftTypeModelCode(
			"EF-18A Hornet",
			"EF18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_18B_HORNET = new AircraftTypeModelCode(
			"EF-18B Hornet",
			"EF18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_4_WILD_WEASEL = new AircraftTypeModelCode(
			"EF-4 Wild Weasel",
			"EF4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_4B = new AircraftTypeModelCode(
			"EF-4B",
			"EF4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_4G = new AircraftTypeModelCode(
			"EF-4G",
			"EF4G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EF_4J = new AircraftTypeModelCode(
			"EF-4J",
			"EF4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EGRETT_I = new AircraftTypeModelCode(
			"Egrett I",
			"G500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_1_IROQUOIS = new AircraftTypeModelCode(
			"EH-1 Iroquois",
			"EH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_MERLIN = new AircraftTypeModelCode(
			"EH-101 Merlin",
			"EH101",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_100 = new AircraftTypeModelCode(
			"EH-101-100",
			"EH1011",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_200 = new AircraftTypeModelCode(
			"EH-101-200",
			"EH1012",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_300 = new AircraftTypeModelCode(
			"EH-101-300",
			"EH1013",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_400 = new AircraftTypeModelCode(
			"EH-101-400",
			"EH1014",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_101_500 = new AircraftTypeModelCode(
			"EH-101-500",
			"EH1015",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_1H_IROQUOIS = new AircraftTypeModelCode(
			"EH-1H Iroquois",
			"EH1H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_1X_IROQUOIS = new AircraftTypeModelCode(
			"EH-1X Iroquois",
			"EH1X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_6_DEFENDER = new AircraftTypeModelCode(
			"EH-6 Defender",
			"EH6DEF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_60_BLACKHAWK = new AircraftTypeModelCode(
			"EH-60 Blackhawk",
			"EH60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_60_QUICK_FOX = new AircraftTypeModelCode(
			"EH-60 Quick Fox",
			"EH60QF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_60A_BLACKHAWK = new AircraftTypeModelCode(
			"EH-60A Blackhawk",
			"EH60A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_60B_SOTAS = new AircraftTypeModelCode(
			"EH-60B Sotas",
			"EH60B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EH_60C_BLACKHAWK = new AircraftTypeModelCode(
			"EH-60C Blackhawk",
			"EH60C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EKA_3B = new AircraftTypeModelCode(
			"EKA-3B",
			"EKA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ELITE = new AircraftTypeModelCode(
			"Elite",
			"ELITE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_100_BANDEIRANTE = new AircraftTypeModelCode(
			"EMB-100 Bandeirante",
			"EMB100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_110_BANDEIRANTE = new AircraftTypeModelCode(
			"EMB-110 Bandeirante",
			"EMB110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_110_P1 = new AircraftTypeModelCode(
			"EMB-110 P1",
			"EM11P1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_110_P2 = new AircraftTypeModelCode(
			"EMB-110 P2",
			"EM11P2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_110C_BANDEIRANTE = new AircraftTypeModelCode(
			"EMB-110C Bandeirante",
			"EM110C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_111A_BANDEIRANTE_MARITIME = new AircraftTypeModelCode(
			"EMB-111A Bandeirante Maritime",
			"EM111A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_120_BRASILA = new AircraftTypeModelCode(
			"EMB-120 Brasila",
			"EMB120",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_120_BRASILIA = new AircraftTypeModelCode(
			"EMB-120 Brasilia",
			"EM120",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_121_XINGU = new AircraftTypeModelCode(
			"EMB-121 Xingu",
			"EMB121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_121A_XINGU_I = new AircraftTypeModelCode(
			"EMB-121A Xingu I",
			"EM121A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_121A1_XINGU_II = new AircraftTypeModelCode(
			"EMB-121A1 Xingu II",
			"EM1211",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_135 = new AircraftTypeModelCode(
			"EMB-135",
			"EM135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_145 = new AircraftTypeModelCode(
			"EMB-145",
			"EM145",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_145RS = new AircraftTypeModelCode(
			"EMB-145RS",
			"EM145R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_145SA = new AircraftTypeModelCode(
			"EMB-145SA",
			"EM145S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_170 = new AircraftTypeModelCode(
			"EMB-170",
			"EM170",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_201_202_IPANEMA = new AircraftTypeModelCode(
			"EMB-201/202 Ipanema",
			"EM201",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_212_TUCANO = new AircraftTypeModelCode(
			"EMB-212 Tucano",
			"EMB212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_312_TUCANO = new AircraftTypeModelCode(
			"EMB-312 Tucano",
			"EMB312",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_312_TUCANO_T_27_TUCANO = new AircraftTypeModelCode(
			"EMB-312 Tucano / T-27 Tucano",
			"EM312",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_312F = new AircraftTypeModelCode(
			"EMB-312F",
			"EM312F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_312H_SUPER_TUCANO = new AircraftTypeModelCode(
			"EMB-312H Super Tucano",
			"EM312H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_326_XAVANTE = new AircraftTypeModelCode(
			"EMB-326 Xavante",
			"EMB326",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_326GB_XAVANTE = new AircraftTypeModelCode(
			"EMB-326GB Xavante",
			"EM326G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_710_CARIOCA = new AircraftTypeModelCode(
			"EMB-710 Carioca",
			"EM710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_711T_CORISCO = new AircraftTypeModelCode(
			"EMB-711T Corisco",
			"EM711",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_810_SENECA_III = new AircraftTypeModelCode(
			"EMB-810 Seneca III",
			"EM810",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_810C_NAVAJO = new AircraftTypeModelCode(
			"EMB-810C Navajo",
			"EM810C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_810D_SENECA = new AircraftTypeModelCode(
			"EMB-810D Seneca",
			"EM810D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMBRACER_BANDEIRANTE = new AircraftTypeModelCode(
			"Embracer Bandeirante",
			"EMBRAC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMB_S312 = new AircraftTypeModelCode(
			"EMB-S312",
			"EMS312",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EMD_720D_MINUANO = new AircraftTypeModelCode(
			"EMD-720D Minuano",
			"EM720D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ENSTROM_280F_FX_SHARK = new AircraftTypeModelCode(
			"Enstrom 280f / FX Shark",
			"ENS28F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ENSTROM_280L_HAWK = new AircraftTypeModelCode(
			"Enstrom 280l Hawk",
			"ENS28L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ENSTROM_480_TH_28 = new AircraftTypeModelCode(
			"Enstrom 480 / TH-28",
			"ENS480",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP_2J_NEPTUNE = new AircraftTypeModelCode(
			"EP-2J Neptune",
			"EP2J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP_3_ORION = new AircraftTypeModelCode(
			"EP-3 Orion",
			"EP3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP_3A_ORION = new AircraftTypeModelCode(
			"EP-3A Orion",
			"EP3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP_3B_ORION = new AircraftTypeModelCode(
			"EP-3B Orion",
			"EP3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP_3E_ORION = new AircraftTypeModelCode(
			"EP-3E Orion",
			"EP3E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EP3J = new AircraftTypeModelCode(
			"EP3J",
			"EP3J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ERA_3B_SKYWARRIOR = new AircraftTypeModelCode(
			"ERA-3B Skywarrior",
			"ERA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ES_2D_TRACKER = new AircraftTypeModelCode(
			"ES-2D Tracker",
			"ES2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ES_3A_VIKING_SIGINT = new AircraftTypeModelCode(
			"ES-3A Viking Sigint",
			"ES3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ESQUILO_ECUREUIL = new AircraftTypeModelCode(
			"Esquilo Ecureuil",
			"ESQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ETENDARD_HUNTER = new AircraftTypeModelCode(
			"Etendard Hunter",
			"ETENDH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ETENDARD_IV = new AircraftTypeModelCode(
			"Etendard IV",
			"ETEN4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ETENDARD_IV_M = new AircraftTypeModelCode(
			"Etendard IV M",
			"ETEN4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ETENDARD_IV_P_ETENDARD_4_P = new AircraftTypeModelCode(
			"Etendard IV P / Etendard 4 P",
			"ETEN4P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ETENDARD_IV_MP = new AircraftTypeModelCode(
			"Etendard IV-MP",
			"ETE4MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EUROCOPTER_TIGER = new AircraftTypeModelCode(
			"Eurocopter Tiger",
			"TIGER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EUROFAR = new AircraftTypeModelCode(
			"Eurofar",
			"EUROFA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EXCALIBUR_F_15F = new AircraftTypeModelCode(
			"Excalibur / F-15F",
			"EXC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EXTRA_200 = new AircraftTypeModelCode(
			"Extra 200",
			"EX200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EXTRA_300_300L_300S = new AircraftTypeModelCode(
			"Extra 300 / 300l / 300s",
			"EX300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode EXTRA_400 = new AircraftTypeModelCode(
			"Extra 400",
			"EX400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18_HORNET = new AircraftTypeModelCode(
			"F/A-18 Hornet",
			"F18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18C_NIGHT_ATTACK_HORNET = new AircraftTypeModelCode(
			"F/A-18C Night Attack Hornet",
			"F18C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18D_RC = new AircraftTypeModelCode(
			"F/A-18D / RC",
			"F18DRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18D_HORNET = new AircraftTypeModelCode(
			"F/A-18D Hornet",
			"F18D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18E_SUPER_HORNET = new AircraftTypeModelCode(
			"F/A-18E Super Hornet",
			"F18E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_A_18F_SUPER_HORNET = new AircraftTypeModelCode(
			"F/A-18F Super Hornet",
			"F18F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_1_HUNTER = new AircraftTypeModelCode(
			"F-1 Hunter",
			"F1HNTR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_1_MITSUBISHI = new AircraftTypeModelCode(
			"F-1 Mitsubishi",
			"F1MSI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_10_J_10 = new AircraftTypeModelCode(
			"F-10 / J-10",
			"F10J10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_100_SUPERSABRE = new AircraftTypeModelCode(
			"F-100 Supersabre",
			"F100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_100A_SUPERSABRE = new AircraftTypeModelCode(
			"F-100A Supersabre",
			"F100A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_100D_SUPERSABRE = new AircraftTypeModelCode(
			"F-100D Supersabre",
			"F100D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_100F_SUPERSABRE = new AircraftTypeModelCode(
			"F-100F Supersabre",
			"F100F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_101F_VOODOO = new AircraftTypeModelCode(
			"F-101F Voodoo",
			"F101G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_102_DELTA_DAGGER = new AircraftTypeModelCode(
			"F-102 Delta Dagger",
			"F102",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104_STARFIGHTER = new AircraftTypeModelCode(
			"F-104 Starfighter",
			"F104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104A_STARFIGHTER = new AircraftTypeModelCode(
			"F-104A Starfighter",
			"F104A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104B_STARFIGHTER = new AircraftTypeModelCode(
			"F-104B Starfighter",
			"F104B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104C_STARFIGHTER = new AircraftTypeModelCode(
			"F-104C Starfighter",
			"F104C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104CF_STARFIGHTER = new AircraftTypeModelCode(
			"F-104CF Starfighter",
			"F104CF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104D_STARFIGHTER = new AircraftTypeModelCode(
			"F-104D Starfighter",
			"F104D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104DJ_STARFIGHTER = new AircraftTypeModelCode(
			"F-104DJ Starfighter",
			"F104DJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104F_STARFIGHTER = new AircraftTypeModelCode(
			"F-104F Starfighter",
			"F104F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104G_STARFIGHTER = new AircraftTypeModelCode(
			"F-104G Starfighter",
			"F104G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104J_STARFIGHTER = new AircraftTypeModelCode(
			"F-104J Starfighter",
			"F104J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104S_ASA = new AircraftTypeModelCode(
			"F-104S Asa",
			"F104SA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_104S_STARFIGHTER = new AircraftTypeModelCode(
			"F-104S Starfighter",
			"F104S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_105G_FAIRCHILD_THUNDERCHIEF = new AircraftTypeModelCode(
			"F-105G Fairchild Thunderchief",
			"F105G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_106_DELTA_DART = new AircraftTypeModelCode(
			"F-106 Delta Dart",
			"F106",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_106A_DELTA_DART = new AircraftTypeModelCode(
			"F-106A Delta Dart",
			"F106A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111 = new AircraftTypeModelCode(
			"F-111",
			"F111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111A = new AircraftTypeModelCode(
			"F-111A",
			"F111A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111B_GD = new AircraftTypeModelCode(
			"F-111B GD",
			"F111B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111C = new AircraftTypeModelCode(
			"F-111C",
			"F111C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111D = new AircraftTypeModelCode(
			"F-111D",
			"F111D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111E = new AircraftTypeModelCode(
			"F-111E",
			"F111E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111F = new AircraftTypeModelCode(
			"F-111F",
			"F111F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111G = new AircraftTypeModelCode(
			"F-111G",
			"F111G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_111K_GD = new AircraftTypeModelCode(
			"F-111K GD",
			"F111K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_117 = new AircraftTypeModelCode(
			"F-117",
			"F117",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_117A_NIGHTHAWK = new AircraftTypeModelCode(
			"F-117A Nighthawk",
			"F117A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_12 = new AircraftTypeModelCode(
			"F-12",
			"F12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14_TOMCAT = new AircraftTypeModelCode(
			"F-14 Tomcat",
			"F14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14A_MOD_TOMCAT = new AircraftTypeModelCode(
			"F-14A Mod Tomcat",
			"F14MOD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14A_PLUS_TOMCAT = new AircraftTypeModelCode(
			"F-14A Plus Tomcat",
			"F14AP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14A_TOMCAT = new AircraftTypeModelCode(
			"F-14A Tomcat",
			"F14A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14B_TOMCAT = new AircraftTypeModelCode(
			"F-14B Tomcat",
			"F14B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_14D_TOMCAT = new AircraftTypeModelCode(
			"F-14D Tomcat",
			"F14D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15_EAGLE = new AircraftTypeModelCode(
			"F-15 Eagle",
			"F15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15A_EAGLE = new AircraftTypeModelCode(
			"F-15A Eagle",
			"F15A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15B_EAGLE = new AircraftTypeModelCode(
			"F-15B Eagle",
			"F15B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15C_EAGLE = new AircraftTypeModelCode(
			"F-15C Eagle",
			"F15C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15D_EAGLE = new AircraftTypeModelCode(
			"F-15D Eagle",
			"F15D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15DJ_EAGLE = new AircraftTypeModelCode(
			"F-15DJ Eagle",
			"F15DJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15E_STRIKE_EAGLE = new AircraftTypeModelCode(
			"F-15E Strike Eagle",
			"F15E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15F_EAGLE = new AircraftTypeModelCode(
			"F-15F Eagle",
			"F15F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15I_THUNDER = new AircraftTypeModelCode(
			"F-15I Thunder",
			"F15I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15J_EAGLE = new AircraftTypeModelCode(
			"F-15J Eagle",
			"F15J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_15S_STRIKE_EAGLE = new AircraftTypeModelCode(
			"F-15S Strike Eagle",
			"F15S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16 Fighting Falcon",
			"F16",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16A_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16A Fighting Falcon",
			"F16A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16B_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16B Fighting Falcon",
			"F16B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16C_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16C Fighting Falcon",
			"F16C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16CG_FALCON = new AircraftTypeModelCode(
			"F-16CG Falcon",
			"F16CG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16CJ_FALCON = new AircraftTypeModelCode(
			"F-16CJ Falcon",
			"F16CJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16D_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16D Fighting Falcon",
			"F16D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16ES = new AircraftTypeModelCode(
			"F-16ES",
			"F16ES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_16N_FIGHTING_FALCON = new AircraftTypeModelCode(
			"F-16N Fighting Falcon",
			"F16N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_18A_CF_18A_EF_18A_HORNET = new AircraftTypeModelCode(
			"F-18A / CF-18A / EF-18A Hornet",
			"F18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_1CR_200 = new AircraftTypeModelCode(
			"F-1CR-200",
			"MF1CR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_1EQ = new AircraftTypeModelCode(
			"F-1EQ",
			"MF1EQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_2_FAGOT = new AircraftTypeModelCode(
			"F-2 Fagot",
			"F2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_21_KFIR_AGGRESSOR = new AircraftTypeModelCode(
			"F-21 Kfir Aggressor",
			"F21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22_PHOENIX = new AircraftTypeModelCode(
			"F-22 Phoenix",
			"F22PHO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22_PINGUINO = new AircraftTypeModelCode(
			"F-22 Pinguino",
			"F22PIN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22_RAPTOR = new AircraftTypeModelCode(
			"F-22 Raptor",
			"F22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_220_AIRONE = new AircraftTypeModelCode(
			"F-220 Airone",
			"F220",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_222_SAMA = new AircraftTypeModelCode(
			"F-222 Sama",
			"F222",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22A = new AircraftTypeModelCode(
			"F-22A",
			"F22A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22B = new AircraftTypeModelCode(
			"F-22B",
			"F22B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_22R = new AircraftTypeModelCode(
			"F-22R",
			"F22R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_FIREFIGHTER = new AircraftTypeModelCode(
			"F-27 Firefighter",
			"CONF27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27 Friendship",
			"F27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_FRIENDSHIP_100 = new AircraftTypeModelCode(
			"F-27 Friendship 100",
			"F27100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_FRIENDSHIP_200 = new AircraftTypeModelCode(
			"F-27 Friendship 200",
			"F27200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_FRIENDSHIP_MARITIME = new AircraftTypeModelCode(
			"F-27 Friendship Maritime",
			"F27M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_KINGBIRD = new AircraftTypeModelCode(
			"F-27 Kingbird",
			"F27KB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_MARITIME_ENFORCER = new AircraftTypeModelCode(
			"F-27 Maritime Enforcer",
			"F27ME",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_MK400M_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27 MK400M Friendship",
			"F27M4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_SENTINEL = new AircraftTypeModelCode(
			"F-27 Sentinel",
			"F27SEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_300_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27/300 Friendship",
			"F27300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_400_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27/400 Friendship",
			"F27400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_500_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27/500 Friendship",
			"F27500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27_600_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27/600 Friendship",
			"F27600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_27A_FRIENDSHIP = new AircraftTypeModelCode(
			"F-27A Friendship",
			"F27A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_FELLOWSHIP = new AircraftTypeModelCode(
			"F-28 Fellowship",
			"F28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_280_FX_SHARK = new AircraftTypeModelCode(
			"F-280 FX Shark",
			"F28FX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_1000_FELLOWSHIP = new AircraftTypeModelCode(
			"F-28-1000 Fellowship",
			"F28100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_1000C = new AircraftTypeModelCode(
			"F-28-1000C",
			"F2810C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_2000_FELLOWSHIP = new AircraftTypeModelCode(
			"F-28-2000 Fellowship",
			"F28200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_3000_FELLOWSHIP = new AircraftTypeModelCode(
			"F-28-3000 Fellowship",
			"F28300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28_4000_FELLOWSHIP = new AircraftTypeModelCode(
			"F-28-4000 Fellowship",
			"F28400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28F_FALCON = new AircraftTypeModelCode(
			"F-28F Falcon",
			"F28F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_28F_P_SENTINEL = new AircraftTypeModelCode(
			"F-28F-P Sentinel",
			"F28FP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_3_TORNADO = new AircraftTypeModelCode(
			"F-3 Tornado",
			"TORAF3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_33_BONANZA = new AircraftTypeModelCode(
			"F-33 Bonanza",
			"F33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_337_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"F-337 Super Skymaster",
			"F337",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_337F_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"F-337F Super Skymaster",
			"F337F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_35_DRAKEN = new AircraftTypeModelCode(
			"F-35 Draken",
			"F35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4_PHANTOM_II = new AircraftTypeModelCode(
			"F-4 Phantom II",
			"F4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F406_CARAVAN_II = new AircraftTypeModelCode(
			"F406 Caravan II",
			"F406CA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_45A = new AircraftTypeModelCode(
			"F-45A",
			"F45A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_45B = new AircraftTypeModelCode(
			"F-45B",
			"F45B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4A_PHANTOM_II = new AircraftTypeModelCode(
			"F-4A Phantom II",
			"F4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4B_PHANTOM_II = new AircraftTypeModelCode(
			"F-4B Phantom II",
			"F4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4C_PHANTOM_II = new AircraftTypeModelCode(
			"F-4C Phantom II",
			"F4C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4D_PHANTOM_II = new AircraftTypeModelCode(
			"F-4D Phantom II",
			"F4D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4E_PHANTOM_II = new AircraftTypeModelCode(
			"F-4E Phantom II",
			"F4E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4EJ_KAI = new AircraftTypeModelCode(
			"F-4EJ Kai",
			"F4EJK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4EJ_PHANTOM_II = new AircraftTypeModelCode(
			"F-4EJ Phantom II",
			"F4EJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4F_PHANTOM_II = new AircraftTypeModelCode(
			"F-4F Phantom II",
			"F4F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4G_PHANTOM_II_F_4G_WILD_WEASEL = new AircraftTypeModelCode(
			"F-4G Phantom II / F-4G Wild Weasel",
			"F4G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4J_PHANTOM_II = new AircraftTypeModelCode(
			"F-4J Phantom II",
			"F4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4K_PHANTOM_II = new AircraftTypeModelCode(
			"F-4K Phantom II",
			"F4K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4M_PHANTOM_II = new AircraftTypeModelCode(
			"F-4M Phantom II",
			"F4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4N_PHANTOM_II = new AircraftTypeModelCode(
			"F-4N Phantom II",
			"F4N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_4S_PHANTOM_II = new AircraftTypeModelCode(
			"F-4S Phantom II",
			"F4S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F4X20_PHANTOM_2000 = new AircraftTypeModelCode(
			"F4X20 Phantom 2000",
			"F4X20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5_FREEDOM_FIGHTER_TIGER = new AircraftTypeModelCode(
			"F-5 Freedom Fighter / Tiger",
			"F5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_50_FOKKER = new AircraftTypeModelCode(
			"F-50 Fokker",
			"F50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5A_FREEDOM_FIGHTER_TIGER = new AircraftTypeModelCode(
			"F-5A Freedom Fighter / Tiger",
			"F5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5B_FREEDOM_FIGHTER_TIGER = new AircraftTypeModelCode(
			"F-5B Freedom Fighter / Tiger",
			"F5B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5C_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"F-5C Freedom Fighter",
			"F5C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5D_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"F-5D Freedom Fighter",
			"F5D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5E_TIGER_II = new AircraftTypeModelCode(
			"F-5E Tiger II",
			"F5E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_5F_TIGER_II = new AircraftTypeModelCode(
			"F-5F Tiger II",
			"F5F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_6_FARMER_D_PRC = new AircraftTypeModelCode(
			"F-6 Farmer D PRC",
			"F6FARM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_6_SEA_HARRIER = new AircraftTypeModelCode(
			"F-6 Sea Harrier",
			"SHF6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7_FISHBED = new AircraftTypeModelCode(
			"F-7 Fishbed",
			"F7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7_FISHBED_A = new AircraftTypeModelCode(
			"F-7 Fishbed A",
			"F7A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7_FISHBED_C = new AircraftTypeModelCode(
			"F-7 Fishbed C",
			"F7C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7B_FISHBED = new AircraftTypeModelCode(
			"F-7B Fishbed",
			"F7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7BS = new AircraftTypeModelCode(
			"F-7BS",
			"F7BS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7M_AIRGUARD = new AircraftTypeModelCode(
			"F-7M Airguard",
			"F7M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7MG = new AircraftTypeModelCode(
			"F-7MG",
			"F7MG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_7P_SKYBOLT = new AircraftTypeModelCode(
			"F-7P Skybolt",
			"F7P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8_CRUSADER = new AircraftTypeModelCode(
			"F-8 Crusader",
			"F8CRUS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8_FINBACK = new AircraftTypeModelCode(
			"F-8 Finback",
			"F8FB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8_FISHBED = new AircraftTypeModelCode(
			"F-8 Fishbed",
			"F8FISH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8_II_FINBACK_B = new AircraftTypeModelCode(
			"F-8 II Finback B",
			"F8FB2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8_METEOR = new AircraftTypeModelCode(
			"F-8 Meteor",
			"F8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_86_SABRE_AVON_MK_32 = new AircraftTypeModelCode(
			"F-86 Sabre Avon MK-32",
			"F86M32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_86F_SUPER_SABRE = new AircraftTypeModelCode(
			"F-86F Super Sabre",
			"F86F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8A_FINBACK = new AircraftTypeModelCode(
			"F-8A Finback",
			"F8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8E_CRUSADER = new AircraftTypeModelCode(
			"F-8E Crusader",
			"F8E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8F_CRUSADER = new AircraftTypeModelCode(
			"F-8F Crusader",
			"F8F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_8H_CRUSADER = new AircraftTypeModelCode(
			"F-8H Crusader",
			"F8H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_9_COUGAR = new AircraftTypeModelCode(
			"F-9 Cougar",
			"F9A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_9_FANTAN = new AircraftTypeModelCode(
			"F-9 Fantan",
			"F9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_MK_1_SEA_HARRIER = new AircraftTypeModelCode(
			"FA MK-1 Sea Harrier",
			"SHFMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18_HORNET = new AircraftTypeModelCode(
			"FA-18 Hornet",
			"FA18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18A_HORNET = new AircraftTypeModelCode(
			"FA-18A Hornet",
			"FA18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18B_HORNET = new AircraftTypeModelCode(
			"FA-18B Hornet",
			"FA18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18C_HORNET = new AircraftTypeModelCode(
			"FA-18C Hornet",
			"FA18C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18D_HORNET = new AircraftTypeModelCode(
			"FA-18D Hornet",
			"FA18D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_18EF_HORNET = new AircraftTypeModelCode(
			"FA-18EF Hornet",
			"FA18L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_2_SEA_HARRIER = new AircraftTypeModelCode(
			"FA-2 Sea Harrier",
			"FA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_20 = new AircraftTypeModelCode(
			"FA-20",
			"FA20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FA_50 = new AircraftTypeModelCode(
			"FA-50",
			"FA50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_CORNELL = new AircraftTypeModelCode(
			"Fairchild Cornell",
			"FA62",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_HELIPORTER = new AircraftTypeModelCode(
			"Fairchild Heliporter",
			"FA25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_L4_SL4 = new AircraftTypeModelCode(
			"Fairchild L4/Sl4",
			"HH4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_METRO = new AircraftTypeModelCode(
			"Fairchild Metro",
			"FA3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_MODEL_71 = new AircraftTypeModelCode(
			"Fairchild Model 71",
			"FA71",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_THUNDERCHIEF = new AircraftTypeModelCode(
			"Fairchild Thunderchief",
			"F105",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FAIRCHILD_THUNDERSTREAK = new AircraftTypeModelCode(
			"Fairchild Thunderstreak",
			"F84",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCO_F_8L = new AircraftTypeModelCode(
			"Falco F.8l",
			"F8LFAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON = new AircraftTypeModelCode(
			"Falcon",
			"FALCN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_10 = new AircraftTypeModelCode(
			"Falcon 10",
			"FALCN1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_100 = new AircraftTypeModelCode(
			"Falcon 100",
			"FAL100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_10MER = new AircraftTypeModelCode(
			"Falcon 10MER",
			"FAL10M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_20 = new AircraftTypeModelCode(
			"Falcon 20",
			"FALCN2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_200 = new AircraftTypeModelCode(
			"Falcon 200",
			"FAL200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_2000 = new AircraftTypeModelCode(
			"Falcon 2000",
			"FAL2T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_20_5 = new AircraftTypeModelCode(
			"Falcon 20-5",
			"FAL205",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_20_50 = new AircraftTypeModelCode(
			"Falcon 20-50",
			"FA2050",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_50 = new AircraftTypeModelCode(
			"Falcon 50",
			"FALCN5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_900B = new AircraftTypeModelCode(
			"Falcon 900B",
			"FAL90B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_900EX = new AircraftTypeModelCode(
			"Falcon 900EX",
			"FAL90E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_GUARDIAN = new AircraftTypeModelCode(
			"Falcon Guardian",
			"FG1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FALCON_MYSTERE_200 = new AircraftTypeModelCode(
			"Falcon Mystere 200",
			"FALMYS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FB_111 = new AircraftTypeModelCode(
			"FB-111",
			"FB111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FB_111A = new AircraftTypeModelCode(
			"FB-111A",
			"FB111A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FB_111A_GD_AARDVARKEN = new AircraftTypeModelCode(
			"FB-111A GD Aardvarken",
			"FB111G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FBA_2E_BUSH_HAWK = new AircraftTypeModelCode(
			"FBA-2E Bush Hawk",
			"FBA2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FELLOWSHIP_1000 = new AircraftTypeModelCode(
			"Fellowship 1000",
			"FS1000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FELLOWSHIP_3000 = new AircraftTypeModelCode(
			"Fellowship 3000",
			"FS3000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FELLOWSHIP_4000 = new AircraftTypeModelCode(
			"Fellowship 4000",
			"FS4000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FENCER_F = new AircraftTypeModelCode(
			"Fencer F",
			"FENCEF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FFA_AS_202_18A = new AircraftTypeModelCode(
			"FFA AS-202/18A",
			"AS2021",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FGA_5_SEA_HAWK = new AircraftTypeModelCode(
			"FGA-5 Sea Hawk",
			"FGA5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FGA_6_SEA_HAWK = new AircraftTypeModelCode(
			"FGA-6 Sea Hawk",
			"FGA6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FGA_7A_HUNTER = new AircraftTypeModelCode(
			"FGA-7A Hunter",
			"FGA7A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FGR_1_PHANTOM_II = new AircraftTypeModelCode(
			"FGR-1 Phantom II",
			"PHFGR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FGR_2_PHANTOM_II = new AircraftTypeModelCode(
			"FGR-2 Phantom II",
			"PHFGR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FH_1100_FAIRCHILD = new AircraftTypeModelCode(
			"FH-1100 Fairchild",
			"FH1100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FH_227_FRIENDSHIP = new AircraftTypeModelCode(
			"FH-227 Friendship",
			"FH227",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FICR = new AircraftTypeModelCode(
			"FICR",
			"FICR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FINBACK = new AircraftTypeModelCode(
			"Finback",
			"FNB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FINBACK_F_8_II = new AircraftTypeModelCode(
			"Finback / F-8 II",
			"F82",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FIREBAR_B = new AircraftTypeModelCode(
			"Firebar B",
			"FIREB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FISHBED_JX = new AircraftTypeModelCode(
			"Fishbed JX",
			"FISHJX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FISHPOT = new AircraftTypeModelCode(
			"Fishpot",
			"FPT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FK_27 = new AircraftTypeModelCode(
			"FK-27",
			"FK27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLANKER_K = new AircraftTypeModelCode(
			"Flanker K",
			"FLANKK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLASHLIGHT = new AircraftTypeModelCode(
			"Flashlight",
			"FLT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLOATMASTER_MISSION_MASTER = new AircraftTypeModelCode(
			"Floatmaster Mission-Master",
			"FLTMAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLOGGER_A = new AircraftTypeModelCode(
			"Flogger A",
			"FLOGA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLOGGER_D_BAHADUR = new AircraftTypeModelCode(
			"Flogger D Bahadur",
			"FLOGD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLOGGER_J_BAHADUR = new AircraftTypeModelCode(
			"Flogger J Bahadur",
			"FLOGJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FLOGGER_J2 = new AircraftTypeModelCode(
			"Flogger J2",
			"FLOGJ2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_MK2_TORNADO_ADV = new AircraftTypeModelCode(
			"F-MK2 Tornado ADV",
			"TORF2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_MK2A_TORNADO_ADV = new AircraftTypeModelCode(
			"F-MK2A Tornado ADV",
			"TORF2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode F_MK3_TORNADO_ADV = new AircraftTypeModelCode(
			"F-MK3 Tornado ADV",
			"TORF3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKER_NPA_ENFORCER_MK_2 = new AircraftTypeModelCode(
			"Foker NPA Enforcer MK-2",
			"FOKER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKKER_130 = new AircraftTypeModelCode(
			"Fokker 130",
			"FOK13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKKER_50 = new AircraftTypeModelCode(
			"Fokker 50",
			"FOK50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKKER_50_SPECIAL_MISSION = new AircraftTypeModelCode(
			"Fokker 50 Special Mission",
			"FOK50M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKKER_60 = new AircraftTypeModelCode(
			"Fokker 60",
			"FOK60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOKKER_70 = new AircraftTypeModelCode(
			"Fokker 70",
			"FOK70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOXHOUND = new AircraftTypeModelCode(
			"Foxhound",
			"FHD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FOXHOUND_B = new AircraftTypeModelCode(
			"Foxhound B",
			"FXHB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FR_74S_HUNTER = new AircraftTypeModelCode(
			"FR-74S Hunter",
			"FR74S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FREEBIRD_MK_5 = new AircraftTypeModelCode(
			"Freebird MK 5",
			"FRBI5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"Freedom Fighter",
			"FREEFI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FREESTYLE = new AircraftTypeModelCode(
			"Freestyle",
			"FREEST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FRS_MK1_SEA_HARRIER = new AircraftTypeModelCode(
			"FRS-MK1 Sea Harrier",
			"SHM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FRS_MK51_SEA_HARRIER = new AircraftTypeModelCode(
			"FRS-MK51 Sea Harrier",
			"SHM51",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FT_337_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"FT-337 Super Skymaster",
			"FT337",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FT_7_JJ_7 = new AircraftTypeModelCode(
			"FT-7 / JJ-7",
			"FT7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FTB_337_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"FTB-337 Super Skymaster",
			"FTB337",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FU24_954_FLETCHER = new AircraftTypeModelCode(
			"FU24-954 Fletcher",
			"FU2495",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FUJI_KM_2 = new AircraftTypeModelCode(
			"Fuji KM 2",
			"FUJI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FULCRUM = new AircraftTypeModelCode(
			"Fulcrum",
			"FUL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FULCRUM_BAAZ = new AircraftTypeModelCode(
			"Fulcrum Baaz",
			"FCMBAZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode FULCRUM_D = new AircraftTypeModelCode(
			"Fulcrum D",
			"FCMD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_115_HERON = new AircraftTypeModelCode(
			"G-115 Heron",
			"HERON",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_115TA_ACRO = new AircraftTypeModelCode(
			"G-115TA Acro",
			"G115TA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222_ALENIA = new AircraftTypeModelCode(
			"G-222 Alenia",
			"G222AL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_22228_AERITALIA = new AircraftTypeModelCode(
			"G-22228 Aeritalia",
			"G22228",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222EC_AERITALIA = new AircraftTypeModelCode(
			"G-222EC Aeritalia",
			"G222EC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222GE_ALENIA = new AircraftTypeModelCode(
			"G-222GE Alenia",
			"G222GE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222RM_AERITALIA = new AircraftTypeModelCode(
			"G-222RM Aeritalia",
			"G222R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222RM_ALENIA = new AircraftTypeModelCode(
			"G-222RM Alenia",
			"G222RM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222SAA_ALENIA = new AircraftTypeModelCode(
			"G-222SAA Alenia",
			"G222SA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222T_ALENIA = new AircraftTypeModelCode(
			"G-222T Alenia",
			"G222T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222VS = new AircraftTypeModelCode(
			"G-222VS",
			"G222VS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_222VS_ALENIA = new AircraftTypeModelCode(
			"G-222VS Alenia",
			"G222VA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_2A_GALEB = new AircraftTypeModelCode(
			"G-2A Galeb",
			"G2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_4_SUPER_GALEB = new AircraftTypeModelCode(
			"G-4 Super Galeb",
			"G4SG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_520_EGRETT_II = new AircraftTypeModelCode(
			"G-520 Egrett II",
			"G520",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91 = new AircraftTypeModelCode(
			"G-91",
			"G91",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91_SUPER_MYSTERE = new AircraftTypeModelCode(
			"G-91 Super Mystere",
			"G91SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91R_1 = new AircraftTypeModelCode(
			"G-91R/1",
			"G91R1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91R_3 = new AircraftTypeModelCode(
			"G-91R/3",
			"G91R3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91R_4 = new AircraftTypeModelCode(
			"G-91R/4",
			"G91R4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91T_1 = new AircraftTypeModelCode(
			"G-91T/1",
			"G91T1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91T_3 = new AircraftTypeModelCode(
			"G-91T/3",
			"G91T3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91Y = new AircraftTypeModelCode(
			"G-91Y",
			"G91Y",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode G_91Y_ENTENDARD_HUNTER = new AircraftTypeModelCode(
			"G-91Y Entendard Hunter",
			"G91YEH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GABRIEL_TRANSALL = new AircraftTypeModelCode(
			"Gabriel Transall",
			"GABR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAFHAWK_125 = new AircraftTypeModelCode(
			"Gafhawk 125",
			"GH125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAJARAJ_CANDID = new AircraftTypeModelCode(
			"Gajaraj Candid",
			"GAJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAK_22_DINO = new AircraftTypeModelCode(
			"Gak-22 Dino",
			"GAK22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GALEB = new AircraftTypeModelCode(
			"Galeb",
			"GLB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GALEB_G_4_SEAGULL = new AircraftTypeModelCode(
			"Galeb G-4 Seagull",
			"G4SEAG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GARDIAN_2 = new AircraftTypeModelCode(
			"Gardian 2",
			"GARD2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GARDIAN_50 = new AircraftTypeModelCode(
			"Gardian 50",
			"GARD50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET = new AircraftTypeModelCode(
			"Gates Lear Jet",
			"GAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET_24A = new AircraftTypeModelCode(
			"Gates Lear Jet 24A",
			"GAT24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET_25 = new AircraftTypeModelCode(
			"Gates Lear Jet 25",
			"GAT25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET_35 = new AircraftTypeModelCode(
			"Gates Lear Jet 35",
			"GAT35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET_35A = new AircraftTypeModelCode(
			"Gates Lear Jet 35A",
			"GAT35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEAR_JET_55 = new AircraftTypeModelCode(
			"Gates Lear Jet 55",
			"GAT55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEARJET_23 = new AircraftTypeModelCode(
			"Gates Learjet 23",
			"GAT23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEARJET_28 = new AircraftTypeModelCode(
			"Gates Learjet 28",
			"GAT28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEARJET_29 = new AircraftTypeModelCode(
			"Gates Learjet 29",
			"GAT29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEARJET_36 = new AircraftTypeModelCode(
			"Gates Learjet 36",
			"GAT36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GATES_LEARJET_54 = new AircraftTypeModelCode(
			"Gates Learjet 54",
			"GAT54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAVILAN_358 = new AircraftTypeModelCode(
			"Gavilan 358",
			"358GAV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAVIO_LAMA = new AircraftTypeModelCode(
			"Gavio Lama",
			"GAV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAZELLE_CA_25N = new AircraftTypeModelCode(
			"Gazelle / CA-25N",
			"CA25N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GAZELLE_SA_341_HT_MK_2 = new AircraftTypeModelCode(
			"Gazelle / SA-341 HT-MK-2",
			"GHTMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_CANSO_CATALINA = new AircraftTypeModelCode(
			"General Dynamics Canso / Catalina",
			"CV14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_CONVAIR_240 = new AircraftTypeModelCode(
			"General Dynamics Convair 240",
			"CV24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_CONVAIR_600 = new AircraftTypeModelCode(
			"General Dynamics Convair 600",
			"CV60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_CONVAIR_640 = new AircraftTypeModelCode(
			"General Dynamics Convair 640",
			"CV64",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_CORONADO_990 = new AircraftTypeModelCode(
			"General Dynamics Coronado 990",
			"CV99",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_FLYING_CLASSROOM = new AircraftTypeModelCode(
			"General Dynamics Flying Classroom",
			"T29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_PRIVATEER = new AircraftTypeModelCode(
			"General Dynamics Privateer",
			"P4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENERAL_DYNAMICS_VALIANT_34 = new AircraftTypeModelCode(
			"General Dynamics Valiant 34",
			"CV13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENESIS_6_650 = new AircraftTypeModelCode(
			"Genesis 6-650",
			"GE6650",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GENET_WARRIOR = new AircraftTypeModelCode(
			"Genet Warrior",
			"GEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GF_200 = new AircraftTypeModelCode(
			"GF-200",
			"GF200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GF_250 = new AircraftTypeModelCode(
			"GF-250",
			"GF250",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GF_300 = new AircraftTypeModelCode(
			"GF-300",
			"GF300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GF_350 = new AircraftTypeModelCode(
			"GF-350",
			"GF350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GLASAIR_III = new AircraftTypeModelCode(
			"Glasair III",
			"GLAS3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GLASAIR_II_SUPER = new AircraftTypeModelCode(
			"Glasair II-Super",
			"GLAS2S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GLASTAR = new AircraftTypeModelCode(
			"Glastar",
			"GLASTA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GLOBAL_EXPRESS = new AircraftTypeModelCode(
			"Global Express",
			"GLOEX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GNAT_MK_1 = new AircraftTypeModelCode(
			"GNAT MK-1",
			"GNAT1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GNAT_MK_2 = new AircraftTypeModelCode(
			"GNAT MK-2",
			"GNAT2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GNAT_T_1 = new AircraftTypeModelCode(
			"GNAT T-1",
			"GATT1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GNAT_T_1DB = new AircraftTypeModelCode(
			"GNAT T-1DB",
			"GATT1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GOAIR_TRAINER = new AircraftTypeModelCode(
			"Goair Trainer",
			"GOAIRT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GOMOURIA = new AircraftTypeModelCode(
			"Gomouria",
			"GOM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GOVERNMENT_AIRCRAFT_N_24A_NOMAD = new AircraftTypeModelCode(
			"Government Aircraft N-24A Nomad",
			"N24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK3_HARRIER = new AircraftTypeModelCode(
			"GR MK3 Harrier",
			"HARGM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK4_HARRIER = new AircraftTypeModelCode(
			"GR MK4 Harrier",
			"HARGM4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_1_HARRIER = new AircraftTypeModelCode(
			"GR-1 Harrier",
			"GR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_1_SPE_CAT_JAGUAR = new AircraftTypeModelCode(
			"GR-1 SPE Cat Jaguar",
			"GR1J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_1A_HARRIER = new AircraftTypeModelCode(
			"GR-1A Harrier",
			"GR1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_3_HARRIER = new AircraftTypeModelCode(
			"GR-3 Harrier",
			"GR3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_4_TORNADO = new AircraftTypeModelCode(
			"GR-4 Tornado",
			"GR4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_4A_TORNADO = new AircraftTypeModelCode(
			"GR-4A Tornado",
			"GR4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_5_HARRIER = new AircraftTypeModelCode(
			"GR-5 Harrier",
			"GR5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_7_HARRIER_HARRIER_GR_7 = new AircraftTypeModelCode(
			"GR-7 Harrier / Harrier GR-7",
			"GR7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK1_TORNADO_IDS = new AircraftTypeModelCode(
			"GR-MK1 Tornado IDS",
			"TORM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK1A_TORNADO_IDS = new AircraftTypeModelCode(
			"GR-MK1A Tornado IDS",
			"TORM1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK1B_TORNADO_IDS = new AircraftTypeModelCode(
			"GR-MK1B Tornado IDS",
			"TORM1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GR_MK4_TORNADO_IDS = new AircraftTypeModelCode(
			"GR-MK4 Tornado IDS",
			"TORM4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_CHEETAH = new AircraftTypeModelCode(
			"Grumman Cheetah",
			"G28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_COUGAR_AA7 = new AircraftTypeModelCode(
			"Grumman Cougar AA7",
			"GA7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_COUGAR_G_93 = new AircraftTypeModelCode(
			"Grumman Cougar G-93",
			"F9CG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_GOOSE_SUPER_GOOSE = new AircraftTypeModelCode(
			"Grumman Goose / Super Goose",
			"G21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_MALLARD = new AircraftTypeModelCode(
			"Grumman Mallard",
			"G73",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_MODEL_G_164_TURBO_AG_CAT = new AircraftTypeModelCode(
			"Grumman Model G-164 / Turbo AG-Cat",
			"G164",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_TRAVELER = new AircraftTypeModelCode(
			"Grumman Traveler",
			"AA5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_WIDGEON_SUPER_WIDGEON = new AircraftTypeModelCode(
			"Grumman Widgeon / Super Widgeon",
			"G44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GRUMMAN_YANKEE_AA1B_C = new AircraftTypeModelCode(
			"Grumman Yankee AA1B/C",
			"AA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_COMMANDER_JETPROP_840_900_980 = new AircraftTypeModelCode(
			"Gulfstream Commander Jetprop 840/900/980",
			"GA84",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_I = new AircraftTypeModelCode(
			"Gulfstream I",
			"GULI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_II = new AircraftTypeModelCode(
			"Gulfstream II",
			"GULII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_IIB = new AircraftTypeModelCode(
			"Gulfstream IIB",
			"GUL2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_III = new AircraftTypeModelCode(
			"Gulfstream III",
			"GULIII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_IV = new AircraftTypeModelCode(
			"Gulfstream IV",
			"GULIV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_IV_B = new AircraftTypeModelCode(
			"Gulfstream IV-B",
			"GUL4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_IV_MPA = new AircraftTypeModelCode(
			"Gulfstream IV-MPA",
			"GUL4MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_IV_SP = new AircraftTypeModelCode(
			"Gulfstream IV-SP",
			"GUL4SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULFSTREAM_V_C_37 = new AircraftTypeModelCode(
			"Gulfstream V / C-37",
			"GUL5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode GULL_M_20 = new AircraftTypeModelCode(
			"Gull M-20",
			"PZLM20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_13_SIOUX = new AircraftTypeModelCode(
			"H-13 Sioux",
			"H13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_19_CHIKASAW = new AircraftTypeModelCode(
			"H-19 Chikasaw",
			"H19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_23_RAVEN = new AircraftTypeModelCode(
			"H-23 Raven",
			"H23A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_2X_HAWK_III = new AircraftTypeModelCode(
			"H-2X Hawk III",
			"H2X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_3_SEA_KING = new AircraftTypeModelCode(
			"H-3 Sea King",
			"H3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_34_CHOCTAW = new AircraftTypeModelCode(
			"H-34 Choctaw",
			"H34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_36_DIMONA = new AircraftTypeModelCode(
			"H-36 Dimona",
			"H36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_37_MOJAVE = new AircraftTypeModelCode(
			"H-37 Mojave",
			"H37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_40 = new AircraftTypeModelCode(
			"H-40",
			"HOFH40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_5 = new AircraftTypeModelCode(
			"H-5",
			"H5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_5_MI_8_HARBEN = new AircraftTypeModelCode(
			"H-5 / MI-8 Harben",
			"H5HAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_5_BEAGLE = new AircraftTypeModelCode(
			"H-5 Beagle",
			"H5BGL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_53_PAVELOW_III = new AircraftTypeModelCode(
			"H-53 Pavelow III",
			"MH53",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_53E_SUPER_STALLION = new AircraftTypeModelCode(
			"H-53E Super Stallion",
			"H53E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_6_HONG_6 = new AircraftTypeModelCode(
			"H-6 Hong-6",
			"H6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_7_HONG_7 = new AircraftTypeModelCode(
			"H-7 Hong-7",
			"H7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_76_EAGLE = new AircraftTypeModelCode(
			"H-76 Eagle",
			"H76",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_76N_AGUSTA_BELL = new AircraftTypeModelCode(
			"H-76N Agusta Bell",
			"H76SIK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode H_76N_EAGLE = new AircraftTypeModelCode(
			"H-76N Eagle",
			"H76N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HA_1_ESQUILO = new AircraftTypeModelCode(
			"HA-1 Esquilo",
			"HA1ESQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAMILTON_A_II_AVENGER = new AircraftTypeModelCode(
			"Hamilton A-II Avenger",
			"A2AVEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HANDLEY_PAGE_JETSTREAM_HP_137 = new AircraftTypeModelCode(
			"Handley Page Jetstream Hp-137",
			"HP13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HANSA_JET_HFP_320 = new AircraftTypeModelCode(
			"Hansa Jet HFP-320",
			"HANSA3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HANSA_2 = new AircraftTypeModelCode(
			"Hansa-2",
			"HANSA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAR_MK3_SEA_KING = new AircraftTypeModelCode(
			"HAR MK3 Sea King",
			"SKHRM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAR_MK3A_SEA_KING = new AircraftTypeModelCode(
			"HAR MK3A Sea King",
			"SKHA3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAR_MK5_SEA_KING = new AircraftTypeModelCode(
			"HAR MK5 Sea King",
			"SKHAM5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAR_10_WHIRLWIND = new AircraftTypeModelCode(
			"HAR-10 Whirlwind",
			"HAR10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARBIN_H_5_BEAGLE = new AircraftTypeModelCode(
			"Harbin H-5 Beagle",
			"HARBH5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARBIN_Z_5_HOUND = new AircraftTypeModelCode(
			"Harbin Z-5 Hound",
			"HARBZ5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARKE_B = new AircraftTypeModelCode(
			"Harke B",
			"HARKEB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_GR_MK_1 = new AircraftTypeModelCode(
			"Harrier GR. MK 1",
			"HGRM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_GR_MK_1A = new AircraftTypeModelCode(
			"Harrier GR. MK 1A",
			"HGRM1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_GR_MK_3 = new AircraftTypeModelCode(
			"Harrier GR. MK 3",
			"HGRM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_GR_MK_5 = new AircraftTypeModelCode(
			"Harrier GR. MK 5",
			"HGRM5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_GR_MK_7 = new AircraftTypeModelCode(
			"Harrier GR. MK 7",
			"HGRM7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_II = new AircraftTypeModelCode(
			"Harrier II",
			"HARII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_II_PLUS = new AircraftTypeModelCode(
			"Harrier II Plus",
			"HARIIP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_T_MK_10 = new AircraftTypeModelCode(
			"Harrier T. MK 10",
			"HTMK10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_T_MK_2A = new AircraftTypeModelCode(
			"Harrier T-MK-2A",
			"HTMK2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_T_MK_4 = new AircraftTypeModelCode(
			"Harrier T-MK-4",
			"HTMK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_T_MK_4A = new AircraftTypeModelCode(
			"Harrier T-MK-4A",
			"HTMK4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARRIER_T_MK_4N = new AircraftTypeModelCode(
			"Harrier T-MK-4N",
			"HTMK4N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HARVARD_TEXAN = new AircraftTypeModelCode(
			"Harvard Texan",
			"HARV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK1_SEA_KING = new AircraftTypeModelCode(
			"HAS MK1 Sea King",
			"SKHSM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_1_WASP = new AircraftTypeModelCode(
			"HAS-1 Wasp",
			"HAS1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_2_LYNX = new AircraftTypeModelCode(
			"HAS-2 Lynx",
			"HAS2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_3_LYNX = new AircraftTypeModelCode(
			"HAS-3 Lynx",
			"HAS3L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_3_WESSEX = new AircraftTypeModelCode(
			"HAS-3 Wessex",
			"HAS3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_31B_WESSEX = new AircraftTypeModelCode(
			"HAS-31B Wessex",
			"HAS31B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_4_LYNX = new AircraftTypeModelCode(
			"HAS-4 Lynx",
			"HAS4L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK_2_LYNX = new AircraftTypeModelCode(
			"HAS-MK-2 Lynx",
			"LHASM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK2_SEA_KING = new AircraftTypeModelCode(
			"HAS-MK2 Sea King",
			"HASMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK_3_LYNX = new AircraftTypeModelCode(
			"HAS-MK-3 Lynx",
			"LHASM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK_4_LYNX = new AircraftTypeModelCode(
			"HAS-MK-4 Lynx",
			"LHASM4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK5_SEA_KING = new AircraftTypeModelCode(
			"HAS-MK5 Sea King",
			"HASMK5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK6_SEA_KING = new AircraftTypeModelCode(
			"HAS-MK6 Sea King",
			"HASMK6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAS_MK8_SUPER_LYNX = new AircraftTypeModelCode(
			"HAS-MK8 Super Lynx",
			"HASMK8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAT_21_AS_532_COUGAR = new AircraftTypeModelCode(
			"HAT-21 / AS 532 Cougar",
			"HAT21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_100 = new AircraftTypeModelCode(
			"Hawk 100",
			"HAK100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_200 = new AircraftTypeModelCode(
			"Hawk 200",
			"HAK200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_50 = new AircraftTypeModelCode(
			"Hawk 50",
			"HAK50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_60 = new AircraftTypeModelCode(
			"Hawk 60",
			"HAK60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_T_MK1 = new AircraftTypeModelCode(
			"Hawk T. MK1",
			"HAKTM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_T_MK1A = new AircraftTypeModelCode(
			"Hawk T. MK1A",
			"HAKT1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWK_T_MK1W = new AircraftTypeModelCode(
			"Hawk T. MK1W",
			"HAKT1W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_1000 = new AircraftTypeModelCode(
			"Hawker 1000",
			"HAW100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_4000 = new AircraftTypeModelCode(
			"Hawker 4000",
			"HAW400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800 = new AircraftTypeModelCode(
			"Hawker 800",
			"HAW80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800FI = new AircraftTypeModelCode(
			"Hawker 800FI",
			"HAW80F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800MP = new AircraftTypeModelCode(
			"Hawker 800MP",
			"HAW80M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800RA = new AircraftTypeModelCode(
			"Hawker 800RA",
			"HAW80R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800SSIG_U_125A = new AircraftTypeModelCode(
			"Hawker 800SSIG / U-125A",
			"HAW80S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800SM = new AircraftTypeModelCode(
			"Hawker 800SM",
			"HAW8SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_800XP = new AircraftTypeModelCode(
			"Hawker 800XP",
			"HAW80X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_SIDDELEY_AVRO_VULCAN_698 = new AircraftTypeModelCode(
			"Hawker Siddeley Avro Vulcan 698",
			"VLCN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HAWKER_SIDDELEY_MODEL_HS_KDH_BH125_BAE = new AircraftTypeModelCode(
			"Hawker Siddeley Model HS / KDH / BH125 BAE",
			"HS25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_207_ALFA = new AircraftTypeModelCode(
			"HB-207 Alfa",
			"HB207",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_315_GAVIO = new AircraftTypeModelCode(
			"HB-315 Gavio",
			"HB315G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_315_LAMA = new AircraftTypeModelCode(
			"HB-315 Lama",
			"HB315L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_315B_GAVIAO = new AircraftTypeModelCode(
			"HB-315b Gaviao",
			"HB315B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_350_ESQUILLO = new AircraftTypeModelCode(
			"HB-350 Esquillo",
			"HB350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_350B_ESQUILO = new AircraftTypeModelCode(
			"HB-350B Esquilo",
			"HB350B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_350B1 = new AircraftTypeModelCode(
			"HB-350B1",
			"HB35B1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HB_355F2 = new AircraftTypeModelCode(
			"HB-355f2",
			"HB355F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_MK1_CHINOOK = new AircraftTypeModelCode(
			"HC MK1 Chinook",
			"CHM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_MK1_PUMA = new AircraftTypeModelCode(
			"HC MK1 Puma",
			"PS1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_1_PUMA = new AircraftTypeModelCode(
			"HC-1 Puma",
			"HC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130_HERCULES = new AircraftTypeModelCode(
			"HC-130 Hercules",
			"HC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130B_HERCULES = new AircraftTypeModelCode(
			"HC-130B Hercules",
			"HC130B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130E_HERCULES = new AircraftTypeModelCode(
			"HC-130E Hercules",
			"HC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130H_HERCULES = new AircraftTypeModelCode(
			"HC-130H Hercules",
			"HC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130N_HERCULES = new AircraftTypeModelCode(
			"HC-130N Hercules",
			"HC130N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_130P_HERCULES = new AircraftTypeModelCode(
			"HC-130P Hercules",
			"HC130P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_131A_SAMARITAN = new AircraftTypeModelCode(
			"HC-131A Samaritan",
			"HC131A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_2_WESSEX = new AircraftTypeModelCode(
			"HC-2 Wessex",
			"HC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_7 = new AircraftTypeModelCode(
			"HC-7",
			"HC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HCC_MK4_GAZELLE = new AircraftTypeModelCode(
			"HCC MK4 Gazelle",
			"GHMC4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HCC_2_CHOCTAW = new AircraftTypeModelCode(
			"HCC-2 Choctaw",
			"HCC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HCC_412_WHIRLWIND = new AircraftTypeModelCode(
			"HCC-412 Whirlwind",
			"HCC412",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_MK1_CHINOOK_C_MK1_HERCULES = new AircraftTypeModelCode(
			"HC-MK1 Chinook / C-MK1 Hercules",
			"HCMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HC_MK4_SEA_KING = new AircraftTypeModelCode(
			"HC-MK4 Sea King",
			"HCMK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HD_21_SUPER_PUMA = new AircraftTypeModelCode(
			"HD-21 Super Puma",
			"HD21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HEBB_320_ECM_TRAINER = new AircraftTypeModelCode(
			"HEBB 320 ECM-Trainer",
			"HEB320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HELIO_COURIER = new AircraftTypeModelCode(
			"Helio Courier",
			"HE1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HELIO_MODEL_500 = new AircraftTypeModelCode(
			"Helio Model 500",
			"HE4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HELIPORTER_PEACEMAKER = new AircraftTypeModelCode(
			"Heliporter Peacemaker",
			"HP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HELIX = new AircraftTypeModelCode(
			"Helix",
			"HEL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HERCULES_CMK_1 = new AircraftTypeModelCode(
			"Hercules CMK-1",
			"CMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HERCULES_CMK_3 = new AircraftTypeModelCode(
			"Hercules CMK-3",
			"CMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HERON_F_220_AIRONE = new AircraftTypeModelCode(
			"Heron / F-220 Airone",
			"F220AI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HERON_G_115 = new AircraftTypeModelCode(
			"Heron / G-115",
			"G115HE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HF_24_MK1_MARUT = new AircraftTypeModelCode(
			"HF-24 MK1 Marut",
			"HF24M1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HF_24_MK_1_WIND_SPIRIT = new AircraftTypeModelCode(
			"HF-24 MK-1 Wind Spirit",
			"MARUT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HF_24_MK1T_MARUT = new AircraftTypeModelCode(
			"HF-24 MK1T Marut",
			"HF24MT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HF_24_WINDSPIRIT = new AircraftTypeModelCode(
			"HF-24 Windspirit",
			"HF24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HFB_320_HANSAJET = new AircraftTypeModelCode(
			"HFB-320 Hansajet",
			"HFB320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_1 = new AircraftTypeModelCode(
			"HH-1",
			"HH1SAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_1_IROQUOIS = new AircraftTypeModelCode(
			"HH-1 Iroquois",
			"HH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_1H_IROQUOIS = new AircraftTypeModelCode(
			"HH-1H Iroquois",
			"HH1H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_1K_IROQUOIS = new AircraftTypeModelCode(
			"HH-1K Iroquois",
			"HH1K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_2_SEA_SPRITE = new AircraftTypeModelCode(
			"HH-2 Sea Sprite",
			"HH2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_25A_GUARDIAN = new AircraftTypeModelCode(
			"HH-25A Guardian",
			"HH25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_2D_SEASPRITE = new AircraftTypeModelCode(
			"HH-2D Seasprite",
			"HH2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_3 = new AircraftTypeModelCode(
			"HH-3",
			"HH3SAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_3A = new AircraftTypeModelCode(
			"HH-3A",
			"HH3ASR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_3E_JOLLY_GREEN_GIANT = new AircraftTypeModelCode(
			"HH-3E Jolly Green Giant",
			"HH3E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_3FFPELICAN = new AircraftTypeModelCode(
			"HH-3fFPelican",
			"HH3APL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_42_HUSKIE = new AircraftTypeModelCode(
			"HH-42 Huskie",
			"HH42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_42B_HUSKIE = new AircraftTypeModelCode(
			"HH-42B Huskie",
			"HH42B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_43F_HUSKIE = new AircraftTypeModelCode(
			"HH-43F Huskie",
			"HH43F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_46_SEA_KNIGHT = new AircraftTypeModelCode(
			"HH-46 Sea Knight",
			"HH46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_46A_SEA_KNIGHT = new AircraftTypeModelCode(
			"HH-46A Sea Knight",
			"HH46A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_52_SEA_GUARD = new AircraftTypeModelCode(
			"HH-52 Sea Guard",
			"HH52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_52_SIKORSKY = new AircraftTypeModelCode(
			"HH-52 Sikorsky",
			"HH52S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_52A_SEA_GUARD = new AircraftTypeModelCode(
			"HH-52A Sea Guard",
			"HH52A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_52A_SIKORSKY = new AircraftTypeModelCode(
			"HH-52A Sikorsky",
			"HH52AS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53_SUPER_JOLLY_GREEN_GIANT = new AircraftTypeModelCode(
			"HH-53 Super Jolly Green Giant",
			"HH53",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53A_NAVY_SEA_STALLION = new AircraftTypeModelCode(
			"HH-53A Navy Sea Stallion",
			"HH53A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53B_SUPER_JOLLY_GREEN_GIANT = new AircraftTypeModelCode(
			"HH-53B Super Jolly Green Giant",
			"HH53B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53C_SUPER_JOLLY_GREEN_GIANT = new AircraftTypeModelCode(
			"HH-53C Super Jolly Green Giant",
			"HH53C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53E_SEA_STALLION = new AircraftTypeModelCode(
			"HH-53E Sea Stallion",
			"HH53E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_53H = new AircraftTypeModelCode(
			"HH-53H",
			"HH53H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60A_NIGHTHAWK = new AircraftTypeModelCode(
			"HH-60A Nighthawk",
			"HH60A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60D_NIGHTHAWK = new AircraftTypeModelCode(
			"HH-60D Nighthawk",
			"HH60D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60G_PAVE_HAWK = new AircraftTypeModelCode(
			"HH-60G Pave Hawk",
			"HH60G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60H_SEA_HAWK = new AircraftTypeModelCode(
			"HH-60H Sea Hawk",
			"HH60H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60J_JAYHAWK = new AircraftTypeModelCode(
			"HH-60J Jayhawk",
			"HH60J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_60JA_JAYHAWK = new AircraftTypeModelCode(
			"HH-60JA Jayhawk",
			"HH60JA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_65_DOLPHIN = new AircraftTypeModelCode(
			"HH-65 Dolphin",
			"HH65",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HH_65A_DOLPHIN_II = new AircraftTypeModelCode(
			"HH-65A Dolphin II",
			"HH65II",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HIND_F = new AircraftTypeModelCode(
			"Hind F",
			"HIINF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HIP_J_1 = new AircraftTypeModelCode(
			"HIP J-1",
			"HIPJ1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HIP_K_1 = new AircraftTypeModelCode(
			"HIP K-1",
			"HIPK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HIP_Z_6 = new AircraftTypeModelCode(
			"HIP Z-6",
			"Z6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HIP_K_MI_17P = new AircraftTypeModelCode(
			"HIP-K / MI-17P",
			"MI17P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_KIRAN_1 = new AircraftTypeModelCode(
			"HJT-16 Kiran 1",
			"HJT161",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_KIRAN_2 = new AircraftTypeModelCode(
			"HJT-16 Kiran 2",
			"HJT162",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_MK_I_KIRAN = new AircraftTypeModelCode(
			"HJT-16 MK I Kiran",
			"KIRM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_MK_IA_KIRAN_MK_IA = new AircraftTypeModelCode(
			"HJT-16 MK IA / Kiran MK IA",
			"KIRM1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_MK_II = new AircraftTypeModelCode(
			"HJT-16 MK II",
			"KIRM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HJT_16_MK1 = new AircraftTypeModelCode(
			"HJT-16 MK1",
			"H16M1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_10_SUPER_PUMA = new AircraftTypeModelCode(
			"HKP-10 Super Puma",
			"HKP10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_2_ALOUETTE = new AircraftTypeModelCode(
			"HKP-2 Alouette",
			"HKP2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_2_ALOUETTE_II = new AircraftTypeModelCode(
			"HKP-2 Alouette II",
			"HKP2II",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_3_IROQUOIS = new AircraftTypeModelCode(
			"HKP-3 Iroquois",
			"HKP3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_4_VERTOL = new AircraftTypeModelCode(
			"HKP-4 Vertol",
			"HKP4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_5_OSAGE = new AircraftTypeModelCode(
			"HKP-5 Osage",
			"HKP5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_6 = new AircraftTypeModelCode(
			"HKP-6",
			"HKP6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HKP_7 = new AircraftTypeModelCode(
			"HKP-7",
			"HKP7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HM_1_AS_565_PANTHER = new AircraftTypeModelCode(
			"HM-1 / AS-565 Panther",
			"HM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HN_32_ALOUETTE_III = new AircraftTypeModelCode(
			"HN-32 Alouette III",
			"HN32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HN_433_MENESTREL = new AircraftTypeModelCode(
			"HN-433 Menestrel",
			"HN433",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HN_600 = new AircraftTypeModelCode(
			"HN-600",
			"HN600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HOMER = new AircraftTypeModelCode(
			"Homer",
			"HOM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HORNET_LV = new AircraftTypeModelCode(
			"Hornet-Lv",
			"AHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HOWARD_MODEL_500_WARO = new AircraftTypeModelCode(
			"Howard Model 500 Waro",
			"HW5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HPT_32_DEEPAK_H = new AircraftTypeModelCode(
			"HPT-32 Deepak H",
			"HPT32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_TRIDENT_2E = new AircraftTypeModelCode(
			"HS Trident 2E",
			"TRDT2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_TRIDENT_3B = new AircraftTypeModelCode(
			"HS Trident 3B",
			"TRDT3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_1182_HAWK = new AircraftTypeModelCode(
			"HS-1182 Hawk",
			"HS1182",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_125_DOMINIE = new AircraftTypeModelCode(
			"HS-125 Dominie",
			"HS125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_125_400B_DOMINIE = new AircraftTypeModelCode(
			"HS-125-400B Dominie",
			"HS1254",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_125_600B = new AircraftTypeModelCode(
			"HS-125-600B",
			"HS1256",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_125_700B_DOMINIE = new AircraftTypeModelCode(
			"HS-125-700B Dominie",
			"HS1257",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_125_800B = new AircraftTypeModelCode(
			"HS-125-800B",
			"HS1258",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_146 = new AircraftTypeModelCode(
			"HS-146",
			"HS146",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_146_200 = new AircraftTypeModelCode(
			"HS-146-200",
			"HS1462",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_650_ARGOSY = new AircraftTypeModelCode(
			"HS-650 Argosy",
			"HS650",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_2B = new AircraftTypeModelCode(
			"HS-748 2B",
			"H74B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_ASP = new AircraftTypeModelCode(
			"HS-748 ASP",
			"HS748A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_AVRO = new AircraftTypeModelCode(
			"HS-748 Avro",
			"HS748",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_COAST_GUARDIAN = new AircraftTypeModelCode(
			"HS-748 Coast Guardian",
			"HS748C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_S2B = new AircraftTypeModelCode(
			"HS-748 S2B",
			"H7482B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_SERIES_1 = new AircraftTypeModelCode(
			"HS-748 Series 1",
			"HS7481",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_SERIES_2A = new AircraftTypeModelCode(
			"HS-748 Series 2A",
			"HS7482",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_748_SERIES_2B = new AircraftTypeModelCode(
			"HS-748 Series 2B",
			"HS7483",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_801_MK_1_NIMROD = new AircraftTypeModelCode(
			"HS-801 MK-1 Nimrod",
			"NIM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_801_MK_2_NIMROD = new AircraftTypeModelCode(
			"HS-801 MK-2 Nimrod",
			"NIM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HS_801_NIMROD_MK_3_AEW = new AircraftTypeModelCode(
			"HS-801 Nimrod MK-3 AEW",
			"HS801M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HSPNO_HA_200_SAETA = new AircraftTypeModelCode(
			"HSPNO HA-200 Saeta",
			"HA200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HT_MK3_GAZELLE = new AircraftTypeModelCode(
			"HT MK3 Gazelle",
			"GHTMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HT_17_CH_47_CHINOOK = new AircraftTypeModelCode(
			"HT-17 / CH-47 Chinook",
			"HT17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HT_MK_2_GAZELLE = new AircraftTypeModelCode(
			"HT-MK-2 Gazelle",
			"HTMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HTT_34 = new AircraftTypeModelCode(
			"HTT-34",
			"HTT34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_16_ALBATROSS = new AircraftTypeModelCode(
			"HU-16 Albatross",
			"HU16",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_16B_ALBATROSS = new AircraftTypeModelCode(
			"HU-16B Albatross",
			"HU16B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_16C_ALBATROSS = new AircraftTypeModelCode(
			"HU-16C Albatross",
			"HU16C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_16E = new AircraftTypeModelCode(
			"HU-16E",
			"H16E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_16E_ALBATROSS = new AircraftTypeModelCode(
			"HU-16E Albatross",
			"HU16E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_2_PETREL_650D = new AircraftTypeModelCode(
			"HU-2 Petrel 650d",
			"HU2PET",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_25_GUARDIAN = new AircraftTypeModelCode(
			"HU-25 Guardian",
			"HU25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_25A_GUARDIAN = new AircraftTypeModelCode(
			"HU-25A Guardian",
			"HU25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_25B_GUARDIAN = new AircraftTypeModelCode(
			"HU-25B Guardian",
			"HU25B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_25C_NIGHT_STALKER = new AircraftTypeModelCode(
			"HU-25C Night Stalker",
			"HU25C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HU_5_WESSEX = new AircraftTypeModelCode(
			"HU-5 Wessex",
			"HU5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUGHES_269_OSAGE = new AircraftTypeModelCode(
			"Hughes 269 Osage",
			"HUG269",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUGHES_300_OSAGE = new AircraftTypeModelCode(
			"Hughes 300 Osage",
			"HUG300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUGHES_300C = new AircraftTypeModelCode(
			"Hughes 300C",
			"HU300C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUGHES_369_CAYUSE = new AircraftTypeModelCode(
			"Hughes 369 Cayuse",
			"HUG369",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUGHES_500_CAYUSE = new AircraftTypeModelCode(
			"Hughes 500 Cayuse",
			"HUG500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HUNTER = new AircraftTypeModelCode(
			"Hunter",
			"HUNTER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode HYDRO_2000 = new AircraftTypeModelCode(
			"Hydro 2000",
			"HYDRO2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode I_1123_WESTWIND = new AircraftTypeModelCode(
			"I-1123 Westwind",
			"I1123",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode I_1124_SEASCAN = new AircraftTypeModelCode(
			"I-1124 Seascan",
			"I1124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode I_1L = new AircraftTypeModelCode(
			"I-1l",
			"I1L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode I_22_IRYDA_IRIDIUM = new AircraftTypeModelCode(
			"I-22 Iryda / Iridium",
			"I22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode I_23 = new AircraftTypeModelCode(
			"I-23",
			"I23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_35_HUANQUERO = new AircraftTypeModelCode(
			"IA-35 Huanquero",
			"IA35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_50_GUARANI = new AircraftTypeModelCode(
			"IA-50 Guarani",
			"IA50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_58_PUCARA = new AircraftTypeModelCode(
			"IA-58 Pucara",
			"IA58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_58A_PUCARA = new AircraftTypeModelCode(
			"IA-58A Pucara",
			"IA58A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_58B_PUCARA_BRAVO = new AircraftTypeModelCode(
			"IA-58b Pucara Bravo",
			"IA58B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_63 = new AircraftTypeModelCode(
			"IA-63",
			"IA63",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IA_66_PUCARA = new AircraftTypeModelCode(
			"IA-66 Pucara",
			"IA66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_GALAXY = new AircraftTypeModelCode(
			"IAI Galaxy",
			"IAIGAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_KFIR = new AircraftTypeModelCode(
			"IAI Kfir",
			"IAI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_101_ARAVA = new AircraftTypeModelCode(
			"IAI-101 Arava",
			"IA101",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_1123_WESTWIND = new AircraftTypeModelCode(
			"IAI-1123 Westwind",
			"IA1123",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_1124_SEASCAN = new AircraftTypeModelCode(
			"IAI-1124 Seascan",
			"IA1124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_1124N_SEA_SCAN_1124_SEA_SCAN = new AircraftTypeModelCode(
			"IAI-1124N Sea Scan / 1124 Sea Scan",
			"1124SS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_1125_ASTRA = new AircraftTypeModelCode(
			"IAI-1125 Astra",
			"IA1125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_1125_ASTRA_SP = new AircraftTypeModelCode(
			"IAI-1125 Astra SP",
			"1125SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_201_ARAVA = new AircraftTypeModelCode(
			"IAI-201 Arava",
			"IAI201",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAI_202_ARAVA = new AircraftTypeModelCode(
			"IAI-202 Arava",
			"IA202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAK_52 = new AircraftTypeModelCode(
			"IAK-52",
			"IAK52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_28MA = new AircraftTypeModelCode(
			"IAR 28MA",
			"IAR28M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_109_SWIFT = new AircraftTypeModelCode(
			"IAR-109 Swift",
			"IAR109",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_316B = new AircraftTypeModelCode(
			"IAR-316B",
			"IAR316",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_316B_ALOUETTE_III = new AircraftTypeModelCode(
			"IAR-316B Alouette III",
			"IA316B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_317_ALOUETTE_III = new AircraftTypeModelCode(
			"IAR-317 Alouette III",
			"IAR317",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_330_PUMA = new AircraftTypeModelCode(
			"IAR-330 Puma",
			"IA330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_330L_PUMA_2000 = new AircraftTypeModelCode(
			"IAR-330L Puma 2000",
			"IAR330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_46 = new AircraftTypeModelCode(
			"IAR-46",
			"IAR46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_705 = new AircraftTypeModelCode(
			"IAR-705",
			"IAR705",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_823 = new AircraftTypeModelCode(
			"IAR-823",
			"IAR823",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_825TP = new AircraftTypeModelCode(
			"IAR-825TP",
			"IAR825",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_831_PELICAN = new AircraftTypeModelCode(
			"IAR-831 Pelican",
			"IAR831",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_93_EAGLE = new AircraftTypeModelCode(
			"IAR-93 Eagle",
			"IAR93",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_93_ORAO = new AircraftTypeModelCode(
			"IAR-93 Orao",
			"IAR93O",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IAR_99_SOIM = new AircraftTypeModelCode(
			"IAR-99 Soim",
			"IAR99",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_103 = new AircraftTypeModelCode(
			"IL-103",
			"IL103",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_106 = new AircraftTypeModelCode(
			"IL-106",
			"IL106",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_112 = new AircraftTypeModelCode(
			"IL-112",
			"IL112",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114 = new AircraftTypeModelCode(
			"IL-114",
			"IL114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114FK = new AircraftTypeModelCode(
			"IL-114FK",
			"IL114F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114M = new AircraftTypeModelCode(
			"IL-114M",
			"IL114M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114P = new AircraftTypeModelCode(
			"IL-114P",
			"IL114P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114PC = new AircraftTypeModelCode(
			"IL-114PC",
			"IL114C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_114T = new AircraftTypeModelCode(
			"IL-114T",
			"IL114T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_12 = new AircraftTypeModelCode(
			"IL-12",
			"IL12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_12_COACH = new AircraftTypeModelCode(
			"IL-12 Coach",
			"CCH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_14 = new AircraftTypeModelCode(
			"IL-14",
			"IL14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_14_CRATE = new AircraftTypeModelCode(
			"IL-14 Crate",
			"CRT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_14P_CRATE = new AircraftTypeModelCode(
			"IL-14P Crate",
			"IL14P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_18 = new AircraftTypeModelCode(
			"IL-18",
			"IL18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_18_COOT = new AircraftTypeModelCode(
			"IL-18 Coot",
			"COT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_18_COOT_A = new AircraftTypeModelCode(
			"IL-18 Coot-A",
			"IL18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_18D_MOSKVA = new AircraftTypeModelCode(
			"IL-18d Moskva",
			"IL18D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_20 = new AircraftTypeModelCode(
			"IL-20",
			"IL20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_20_COOT_A = new AircraftTypeModelCode(
			"IL-20 Coot A",
			"COTA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_22 = new AircraftTypeModelCode(
			"IL-22",
			"IL22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_22_COOT_B = new AircraftTypeModelCode(
			"IL-22 Coot B",
			"COTB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_24N = new AircraftTypeModelCode(
			"IL-24N",
			"IL24N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28 = new AircraftTypeModelCode(
			"IL-28",
			"IL28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28_B_5_BEAGLE_PRC = new AircraftTypeModelCode(
			"IL-28 B-5 Beagle Prc",
			"B5BGL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28_MASCOT = new AircraftTypeModelCode(
			"IL-28 Mascot",
			"MAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28B_BEAGLE = new AircraftTypeModelCode(
			"IL-28B Beagle",
			"IL28BB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28R_BEAGLE = new AircraftTypeModelCode(
			"IL-28R Beagle",
			"IL28RB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28T_BEAGLE = new AircraftTypeModelCode(
			"IL-28T Beagle",
			"BGL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_28U_MASCOT = new AircraftTypeModelCode(
			"IL-28U Mascot",
			"IL28U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_38 = new AircraftTypeModelCode(
			"IL-38",
			"IL38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_38_MAY = new AircraftTypeModelCode(
			"IL-38 May",
			"MAY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_38P = new AircraftTypeModelCode(
			"IL-38P",
			"IL38P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_62_CLASSIC = new AircraftTypeModelCode(
			"IL-62 Classic",
			"CXX1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_62M_CLASSIC = new AircraftTypeModelCode(
			"IL-62M Classic",
			"IL62M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_62MK_CLASSIC = new AircraftTypeModelCode(
			"IL-62MK Classic",
			"IL62MK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76 = new AircraftTypeModelCode(
			"IL-76",
			"IL76",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_976 = new AircraftTypeModelCode(
			"IL-76 976",
			"IL7697",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_A_50 = new AircraftTypeModelCode(
			"IL-76 A-50",
			"IL76A5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_CANDID = new AircraftTypeModelCode(
			"IL-76 Candid",
			"CND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_CANDID_A = new AircraftTypeModelCode(
			"IL-76 Candid A",
			"CNDA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_CANDID_B = new AircraftTypeModelCode(
			"IL-76 Candid B",
			"CNDB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_MAINSTAY = new AircraftTypeModelCode(
			"IL-76 Mainstay",
			"MX2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76_MIDAS = new AircraftTypeModelCode(
			"IL-76 Midas",
			"MX1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76AEW_A_50_A_50_I_A_50U_MAINSTAY = new AircraftTypeModelCode(
			"IL-76AEW / A-50 / A-50 I A-50U / Mainstay",
			"IL76AE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76K = new AircraftTypeModelCode(
			"IL-76K",
			"IL76K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76LL = new AircraftTypeModelCode(
			"IL-76LL",
			"IL76LL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76M = new AircraftTypeModelCode(
			"IL-76M",
			"IL76M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76MD = new AircraftTypeModelCode(
			"IL-76MD",
			"IL76MD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76MDK = new AircraftTypeModelCode(
			"IL-76MDK",
			"IL76MK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76MDP = new AircraftTypeModelCode(
			"IL-76MDP",
			"IL76MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76MP = new AircraftTypeModelCode(
			"IL-76MP",
			"IL76MF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76SK = new AircraftTypeModelCode(
			"IL-76SK",
			"IL76SK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76T_CANDID = new AircraftTypeModelCode(
			"IL-76t Candid",
			"IL76T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76TD = new AircraftTypeModelCode(
			"IL-76TD",
			"IL76TD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_76TF = new AircraftTypeModelCode(
			"IL-76TF",
			"IL76TF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_78_ADNAN_1 = new AircraftTypeModelCode(
			"IL-78 Adnan 1",
			"IL781",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_78_MIDAS = new AircraftTypeModelCode(
			"IL-78 Midas",
			"IL78",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_78M = new AircraftTypeModelCode(
			"IL-78M",
			"IL78M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_82 = new AircraftTypeModelCode(
			"IL-82",
			"IL82",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_86 = new AircraftTypeModelCode(
			"IL-86",
			"CXX2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_86_CAMBER = new AircraftTypeModelCode(
			"IL-86 Camber",
			"IL86",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_87_MAXDOME = new AircraftTypeModelCode(
			"IL-87 Maxdome",
			"IL87",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_96_300 = new AircraftTypeModelCode(
			"IL-96-300",
			"IL9630",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_96M = new AircraftTypeModelCode(
			"IL-96M",
			"IL96M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_96MK = new AircraftTypeModelCode(
			"IL-96MK",
			"IL96MK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IL_96T = new AircraftTypeModelCode(
			"IL-96T",
			"IL96T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IMPALA_MK_2 = new AircraftTypeModelCode(
			"Impala MK 2",
			"IMPMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IMPALA_MK2_ATLAS = new AircraftTypeModelCode(
			"Impala MK2 Atlas",
			"IMPM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IMPALA_XAVANTE = new AircraftTypeModelCode(
			"Impala Xavante",
			"IMPX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode INTERNATIONAL_EXEC_90 = new AircraftTypeModelCode(
			"International Exec 90",
			"EXEC90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IPD_6201 = new AircraftTypeModelCode(
			"IPD-6201",
			"IP6201",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IPE_04 = new AircraftTypeModelCode(
			"IPE-04",
			"IPE04",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IPTN_N_250 = new AircraftTypeModelCode(
			"IPTN N-250",
			"N250",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IPTN_N_270 = new AircraftTypeModelCode(
			"IPTN N-270",
			"N270",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IR_02 = new AircraftTypeModelCode(
			"IR-02",
			"IR02",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IR_12 = new AircraftTypeModelCode(
			"IR-12",
			"IR12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IR_H5 = new AircraftTypeModelCode(
			"IR-H5",
			"IRH5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IS_2 = new AircraftTypeModelCode(
			"IS-2",
			"IS2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ISKRA = new AircraftTypeModelCode(
			"ISKRA",
			"ISK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ISLANDER = new AircraftTypeModelCode(
			"Islander",
			"ROMISL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ISRAEL_AIRCRAFT_1124_WESTWIND = new AircraftTypeModelCode(
			"Israel Aircraft 1124 Westwind",
			"WW24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode IV_M5_SUPER_ETENARD = new AircraftTypeModelCode(
			"IV-M5 Super Etenard",
			"ETEND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_1_HAWK = new AircraftTypeModelCode(
			"J-1 Hawk",
			"J1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_1_JASTREB = new AircraftTypeModelCode(
			"J-1 Jastreb",
			"J1J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_10 = new AircraftTypeModelCode(
			"J-10",
			"J10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_1E_JASTREB = new AircraftTypeModelCode(
			"J-1e Jastreb",
			"J1EJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_2_SHENYANG_FAGOT = new AircraftTypeModelCode(
			"J-2 Shenyang Fagot",
			"J2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_22_ORAO = new AircraftTypeModelCode(
			"J-22 Orao",
			"J22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_32_LANSEN = new AircraftTypeModelCode(
			"J-32 Lansen",
			"J32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_32B = new AircraftTypeModelCode(
			"J-32B",
			"J32B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_32D_LANSEN = new AircraftTypeModelCode(
			"J-32d Lansen",
			"J32D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_32E = new AircraftTypeModelCode(
			"J-32e",
			"J32E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35_DRAKEN = new AircraftTypeModelCode(
			"J-35 Draken",
			"J35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35A_DRAKEN = new AircraftTypeModelCode(
			"J-35A Draken",
			"J35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35B_DRAKEN = new AircraftTypeModelCode(
			"J-35B Draken",
			"J35B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35D_DRAKEN = new AircraftTypeModelCode(
			"J-35D Draken",
			"J35D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35F_DRAKEN = new AircraftTypeModelCode(
			"J-35F Draken",
			"J35F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35F1_DRAKEN = new AircraftTypeModelCode(
			"J-35F1 Draken",
			"J35F1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35F2_DRAKEN = new AircraftTypeModelCode(
			"J-35F2 Draken",
			"J35F2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35J = new AircraftTypeModelCode(
			"J-35J",
			"J35J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35S_DRAKEN = new AircraftTypeModelCode(
			"J-35S Draken",
			"J35S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35X_DRAKEN = new AircraftTypeModelCode(
			"J-35X Draken",
			"J35X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_35XD = new AircraftTypeModelCode(
			"J-35XD",
			"J35XD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_37_VIGGEN = new AircraftTypeModelCode(
			"J-37 Viggen",
			"J37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_39_GRIPEN = new AircraftTypeModelCode(
			"J-39 Gripen",
			"J39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_4_SHENYANG_FRESCO = new AircraftTypeModelCode(
			"J-4 Shenyang Fresco",
			"J4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_5_SHENYANG_FRESCO = new AircraftTypeModelCode(
			"J-5 Shenyang Fresco",
			"J5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_6_FARMER_A = new AircraftTypeModelCode(
			"J-6 Farmer A",
			"J6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_7_FISHBED = new AircraftTypeModelCode(
			"J-7 Fishbed",
			"J7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode J_8 = new AircraftTypeModelCode(
			"J-8",
			"J8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JA_37_VIGGEN = new AircraftTypeModelCode(
			"JA-37 Viggen",
			"J37A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JABIRU_ST = new AircraftTypeModelCode(
			"Jabiru St",
			"JABIRU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR = new AircraftTypeModelCode(
			"Jaguar",
			"JAG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_A = new AircraftTypeModelCode(
			"Jaguar A",
			"JAGA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_B = new AircraftTypeModelCode(
			"Jaguar B",
			"JAGB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_E = new AircraftTypeModelCode(
			"Jaguar E",
			"JAGE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_GR1_1A = new AircraftTypeModelCode(
			"Jaguar GR1/1A",
			"JAGGR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_GR_MK1 = new AircraftTypeModelCode(
			"Jaguar GR-MK1",
			"JGRMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_GR_MK1A = new AircraftTypeModelCode(
			"Jaguar GR-MK1A",
			"JGRM1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_GR_MK3 = new AircraftTypeModelCode(
			"Jaguar GR-MK3",
			"JGRMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_INTERNATIONAL = new AircraftTypeModelCode(
			"Jaguar International",
			"JAGINT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_M = new AircraftTypeModelCode(
			"Jaguar M",
			"JAGM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_S = new AircraftTypeModelCode(
			"Jaguar S",
			"JAGS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_SPE_CAT = new AircraftTypeModelCode(
			"Jaguar Spe Cat",
			"JAGSC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_T_2 = new AircraftTypeModelCode(
			"Jaguar T-2",
			"JAGT2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_T_MK_2 = new AircraftTypeModelCode(
			"Jaguar T-MK-2",
			"JTMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_T_MK_2B = new AircraftTypeModelCode(
			"Jaguar T-MK-2B",
			"JTM2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAGUAR_T_MK_4 = new AircraftTypeModelCode(
			"Jaguar T-MK-4",
			"JTMK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAH_1T = new AircraftTypeModelCode(
			"JAH-1T",
			"JAH1T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAS_39_GRIPEN = new AircraftTypeModelCode(
			"JAS 39 Gripen",
			"JAS39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAS_39A = new AircraftTypeModelCode(
			"JAS-39A",
			"JAS39A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAS_39B = new AircraftTypeModelCode(
			"JAS-39B",
			"JAS39B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAS_39C = new AircraftTypeModelCode(
			"JAS-39C",
			"JAS39C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JAS_39D = new AircraftTypeModelCode(
			"JAS-39D",
			"JAS39D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JASTREB = new AircraftTypeModelCode(
			"Jastreb",
			"JSB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JC_130_HERCULES = new AircraftTypeModelCode(
			"Jc-130 Hercules",
			"JC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JC_130H_HERCULES = new AircraftTypeModelCode(
			"Jc-130H Hercules",
			"JC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JET_SQUALUS_F1300NGT = new AircraftTypeModelCode(
			"Jet Squalus F1300NGT",
			"F1300N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETPROP_1000 = new AircraftTypeModelCode(
			"Jetprop 1000",
			"JP1000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETPROP_840 = new AircraftTypeModelCode(
			"Jetprop 840",
			"JP840",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETPROP_900 = new AircraftTypeModelCode(
			"Jetprop 900",
			"JP900",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETPROP_980 = new AircraftTypeModelCode(
			"Jetprop 980",
			"JP980",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_31 = new AircraftTypeModelCode(
			"Jetstream 31",
			"JS31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_41 = new AircraftTypeModelCode(
			"Jetstream 41",
			"JS41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_51 = new AircraftTypeModelCode(
			"Jetstream 51",
			"JS51",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_61 = new AircraftTypeModelCode(
			"Jetstream 61",
			"JS61",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_SUPER_31 = new AircraftTypeModelCode(
			"Jetstream Super 31",
			"JSS31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JETSTREAM_T_MK1 = new AircraftTypeModelCode(
			"Jetstream T-MK1",
			"JSTMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JH_46E = new AircraftTypeModelCode(
			"JH-46E",
			"JH46E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JH_7 = new AircraftTypeModelCode(
			"JH-7",
			"JH7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode JUROM_200_ORAO = new AircraftTypeModelCode(
			"Jurom 200 Orao",
			"JU200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode K_1200_K_MAX = new AircraftTypeModelCode(
			"K-1200 K-Max",
			"K1200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode K_2_VICTOR = new AircraftTypeModelCode(
			"K-2 Victor",
			"K2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode K_250 = new AircraftTypeModelCode(
			"K-250",
			"K250",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode K_8_KARAKORUM_8 = new AircraftTypeModelCode(
			"K-8 Karakorum 8",
			"K8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_115 = new AircraftTypeModelCode(
			"KA-115",
			"KA115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_126_HOODLUM_B = new AircraftTypeModelCode(
			"KA-126 Hoodlum B",
			"KA126B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_136_HOODLUM_B = new AircraftTypeModelCode(
			"KA-136 Hoodlum B",
			"HODB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_15_HEN = new AircraftTypeModelCode(
			"KA-15 Hen",
			"KA15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_18_HOG = new AircraftTypeModelCode(
			"KA-18 Hog",
			"K18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_226 = new AircraftTypeModelCode(
			"KA-226",
			"KA226",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25 = new AircraftTypeModelCode(
			"KA-25",
			"KA25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25_HORMONE = new AircraftTypeModelCode(
			"KA-25 Hormone",
			"HOR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25_HORMONE_A = new AircraftTypeModelCode(
			"KA-25 Hormone A",
			"HORA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25_HORMONE_B = new AircraftTypeModelCode(
			"KA-25 Hormone B",
			"HORB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25_HORMONE_C = new AircraftTypeModelCode(
			"KA-25 Hormone C",
			"HORC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25A = new AircraftTypeModelCode(
			"KA-25A",
			"KA25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25B = new AircraftTypeModelCode(
			"KA-25B",
			"KA25B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_25C = new AircraftTypeModelCode(
			"KA-25C",
			"KA25C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_26_HOODLUM = new AircraftTypeModelCode(
			"KA-26 Hoodlum",
			"HOD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_26_HOODLUM_A = new AircraftTypeModelCode(
			"KA-26 Hoodlum A",
			"HODA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27_HELIX = new AircraftTypeModelCode(
			"KA-27 Helix",
			"HLX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27_HELIX_A = new AircraftTypeModelCode(
			"KA-27 Helix A",
			"HLXA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27_HELIX_B = new AircraftTypeModelCode(
			"KA-27 Helix B",
			"HLXB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27_HELIX_D = new AircraftTypeModelCode(
			"KA-27 Helix D",
			"HLXD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27_PS_HELIX_A = new AircraftTypeModelCode(
			"KA-27 PS Helix A",
			"KA27PS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_27PL = new AircraftTypeModelCode(
			"KA-27PL",
			"KA27PL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_28_HELIX = new AircraftTypeModelCode(
			"KA-28 Helix",
			"KA28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_29_HELIX_A = new AircraftTypeModelCode(
			"KA-29 Helix A",
			"KA29A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_29_HELIX_B = new AircraftTypeModelCode(
			"KA-29 Helix B",
			"KA29B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_31_KA_29RLD = new AircraftTypeModelCode(
			"KA-31 / KA-29RLD",
			"KA31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32_HELIX = new AircraftTypeModelCode(
			"KA-32 Helix",
			"KA32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32_HELIX_C = new AircraftTypeModelCode(
			"KA-32 Helix C",
			"HLXC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A_HELIX_C = new AircraftTypeModelCode(
			"KA-32A Helix C",
			"KA32A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A1 = new AircraftTypeModelCode(
			"KA-32A1",
			"KA32A1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A11 = new AircraftTypeModelCode(
			"KA-32A11",
			"KA3211",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A12 = new AircraftTypeModelCode(
			"KA-32A12",
			"KA3212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A2 = new AircraftTypeModelCode(
			"KA-32A2",
			"KA32A2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A3 = new AircraftTypeModelCode(
			"KA-32A3",
			"KA32A3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_32A7_KA_327 = new AircraftTypeModelCode(
			"KA-32A7 / KA-327",
			"KA32A7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_3B = new AircraftTypeModelCode(
			"KA-3B",
			"KA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_40 = new AircraftTypeModelCode(
			"KA-40",
			"KA40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_50_BLACK_SHARK_HOKUM_HOKUM_A = new AircraftTypeModelCode(
			"KA-50 Black Shark Hokum / Hokum A",
			"KA50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_50N = new AircraftTypeModelCode(
			"KA-50N",
			"KA50N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_52_ALLIGATOR = new AircraftTypeModelCode(
			"KA-52 Alligator",
			"KA52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_6_INTRUDER = new AircraftTypeModelCode(
			"KA-6 Intruder",
			"KA6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_62 = new AircraftTypeModelCode(
			"KA-62",
			"KA62",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_62M = new AircraftTypeModelCode(
			"KA-62M",
			"KA62M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_6A_INTRUDER = new AircraftTypeModelCode(
			"KA-6A Intruder",
			"KA6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_6D_INTRUDER = new AircraftTypeModelCode(
			"KA-6D Intruder",
			"KA6D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_6H_INTRUDER = new AircraftTypeModelCode(
			"KA-6H Intruder",
			"KA6H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_7 = new AircraftTypeModelCode(
			"KA-7",
			"KA7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_840 = new AircraftTypeModelCode(
			"KA-840",
			"KA840",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KANIA = new AircraftTypeModelCode(
			"Kania",
			"KANIA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KANIA_MI_2 = new AircraftTypeModelCode(
			"Kania Mi-2",
			"KANMI2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KATRAN = new AircraftTypeModelCode(
			"Katran",
			"KATRAN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_XX = new AircraftTypeModelCode(
			"KA-XX",
			"KAXX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_XX_HOKUM = new AircraftTypeModelCode(
			"KA-XX Hokum",
			"HKM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KA_XX_HOKUM_A = new AircraftTypeModelCode(
			"KA-XX Hokum A",
			"HKMA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_10_EXTENDER = new AircraftTypeModelCode(
			"KC-10 Extender",
			"KC10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_10A_EXTENDER = new AircraftTypeModelCode(
			"KC-10A Extender",
			"KC10A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130_HERCULES = new AircraftTypeModelCode(
			"KC-130 Hercules",
			"KC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130F_HERCULES = new AircraftTypeModelCode(
			"KC-130F Hercules",
			"KC130F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130H_HERCULES = new AircraftTypeModelCode(
			"KC-130H Hercules",
			"KC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130Q = new AircraftTypeModelCode(
			"KC-130Q",
			"KC130Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130R_HERCULES = new AircraftTypeModelCode(
			"KC-130R Hercules",
			"KC130R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130T_HERCULES = new AircraftTypeModelCode(
			"KC-130T Hercules",
			"KC130T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_130T_30 = new AircraftTypeModelCode(
			"KC-130T-30",
			"KC13T3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135 Stratotanker",
			"KC135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135A_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135A Stratotanker",
			"KC135A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135E_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135E Stratotanker",
			"KC135E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135F = new AircraftTypeModelCode(
			"KC-135F",
			"KC135F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135Q_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135Q Stratotanker",
			"KC135Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135R_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135R Stratotanker",
			"KC135R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_135T_STRATOTANKER = new AircraftTypeModelCode(
			"KC-135T Stratotanker",
			"KC135T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_137_STRATOLINER = new AircraftTypeModelCode(
			"KC-137 Stratoliner",
			"KC137",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_707 = new AircraftTypeModelCode(
			"KC-707",
			"KC707",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_747 = new AircraftTypeModelCode(
			"KC-747",
			"KC747",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_8_SARIGUE = new AircraftTypeModelCode(
			"KC-8 Sarigue",
			"KC8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KC_97_STRATOFREIGHTER = new AircraftTypeModelCode(
			"KC-97 Stratofreighter",
			"KC97",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KDC_10 = new AircraftTypeModelCode(
			"KDC-10",
			"KDC10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KE_3A = new AircraftTypeModelCode(
			"KE-3A",
			"KE3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_F_21A = new AircraftTypeModelCode(
			"KFIR / F-21A",
			"KFIR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_C_2 = new AircraftTypeModelCode(
			"KFIR C-2",
			"KFIRC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_C7 = new AircraftTypeModelCode(
			"KFIR C7",
			"KFIRC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_RC_2 = new AircraftTypeModelCode(
			"KFIR RC-2",
			"KFIRR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_TC_2 = new AircraftTypeModelCode(
			"KFIR TC-2",
			"KFIRT2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_TC_7 = new AircraftTypeModelCode(
			"KFIR TC-7",
			"KFIRT7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KFIR_C2_LION_CUB = new AircraftTypeModelCode(
			"KFIR-C2 Lion Cub",
			"KFIRLC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KH_4_KAWASAKI = new AircraftTypeModelCode(
			"KH-4 Kawasaki",
			"KH4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KING_BIRD_MK_2_FOKKER_50 = new AircraftTypeModelCode(
			"King Bird MK-2 Fokker 50",
			"KBMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KINGS_44_ANGEL = new AircraftTypeModelCode(
			"Kings 44 Angel",
			"KIN44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KIOWA = new AircraftTypeModelCode(
			"Kiowa",
			"BEKIO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KIOWA_JETRANGER = new AircraftTypeModelCode(
			"Kiowa Jetranger",
			"KIOWA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KIOWA_WARRIOR = new AircraftTypeModelCode(
			"Kiowa Warrior",
			"BEKIOW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KIRAN_MK_II = new AircraftTypeModelCode(
			"Kiran MK II",
			"KIRMII",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KMH = new AircraftTypeModelCode(
			"KMH",
			"KMH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KORSHUN = new AircraftTypeModelCode(
			"Korshun",
			"KORSHU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KS_3A_VIKING = new AircraftTypeModelCode(
			"KS-3A Viking",
			"KS3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KTX_2 = new AircraftTypeModelCode(
			"KTX-2",
			"KTX2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KTX_I_WOONG_BEE = new AircraftTypeModelCode(
			"KTX-I Woong-Bee",
			"KTX1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KUDU_BOSBOK = new AircraftTypeModelCode(
			"Kudu Bosbok",
			"KUDU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A = new AircraftTypeModelCode(
			"KV-107 II A",
			"K107A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A_SERIES = new AircraftTypeModelCode(
			"KV-107 II A Series",
			"KV107T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A_2 = new AircraftTypeModelCode(
			"KV-107 II A-2",
			"K107A2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A_3 = new AircraftTypeModelCode(
			"KV-107 II A-3",
			"K107A3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A_5 = new AircraftTypeModelCode(
			"KV-107 II A-5",
			"KV07A5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_II_A_SM = new AircraftTypeModelCode(
			"KV-107 II A-SM",
			"K107AS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_IL_A_4 = new AircraftTypeModelCode(
			"KV-107 Il A-4",
			"K107A4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_KAWASAKI_II_ASMI = new AircraftTypeModelCode(
			"KV-107 Kawasaki II ASMI",
			"KV107A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode KV_107_KAWASAKI_SM_2_I = new AircraftTypeModelCode(
			"KV-107 Kawasaki SM-2 I",
			"KV107S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_LOCKHEED_ELECTRA = new AircraftTypeModelCode(
			"L- Lockheed Electra",
			"L188A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_100_HERCULES = new AircraftTypeModelCode(
			"L-100 Hercules",
			"L100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_100_20_HERCULES = new AircraftTypeModelCode(
			"L-100-20 Hercules",
			"L10020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_100_30_HERCULES = new AircraftTypeModelCode(
			"L-100-30 Hercules",
			"L10030",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_100_30HS = new AircraftTypeModelCode(
			"L-100-30HS",
			"L1003H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_100J = new AircraftTypeModelCode(
			"L-100J",
			"L100J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_TRISTAR = new AircraftTypeModelCode(
			"L-1011 Tristar",
			"L1011",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_TRISTAR_250 = new AircraftTypeModelCode(
			"L-1011 Tristar 250",
			"L10112",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_TRISTAR_A = new AircraftTypeModelCode(
			"L-1011 Tristar A",
			"L1011A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_TRISTAR_E = new AircraftTypeModelCode(
			"L-1011 Tristar E",
			"L1011E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_TRISTAR_K_MK_1 = new AircraftTypeModelCode(
			"L-1011 Tristar K MK-1",
			"L1011K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_100_TRISTAR_100 = new AircraftTypeModelCode(
			"L-1011/100 Tristar 100",
			"L10111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_50_TRISTAR_50 = new AircraftTypeModelCode(
			"L-1011/50 Tristar 50",
			"L10110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_150 = new AircraftTypeModelCode(
			"L-1011-150",
			"L11115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011_500_TRISTAR_500 = new AircraftTypeModelCode(
			"L-1011-500 Tristar 500",
			"L10115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1011F = new AircraftTypeModelCode(
			"L-1011F",
			"L1011F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_1049_SUPER_CONNIE_L_1049_SUPER_CONSTELLATION = new AircraftTypeModelCode(
			"L-1049 Super Connie / L-1049 Super Constellation",
			"L1049",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_159 = new AircraftTypeModelCode(
			"L-159",
			"L159",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_159T = new AircraftTypeModelCode(
			"L-159T",
			"L159T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_188_LOCKHEED_ELECTRA = new AircraftTypeModelCode(
			"L-188 Lockheed Electra",
			"L188",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_188C_LOCKHEED_ELECTRA = new AircraftTypeModelCode(
			"L-188C Lockheed Electra",
			"L188C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_19_BIRD_DOG = new AircraftTypeModelCode(
			"L-19 Bird Dog",
			"L19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_20_MORAVA = new AircraftTypeModelCode(
			"L-20 Morava",
			"L20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_21_SUPER_CUB = new AircraftTypeModelCode(
			"L-21 Super Cub",
			"L21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29 = new AircraftTypeModelCode(
			"L-29",
			"L29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29_DELFIN = new AircraftTypeModelCode(
			"L-29 Delfin",
			"L29DEL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29_MAYA = new AircraftTypeModelCode(
			"L-29 Maya",
			"MAA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29A = new AircraftTypeModelCode(
			"L-29A",
			"L29A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29CZ_MAYA = new AircraftTypeModelCode(
			"L-29CZ Maya",
			"L29CZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_29R = new AircraftTypeModelCode(
			"L-29R",
			"L29R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_382G_LOCKHEED_ELECTRA = new AircraftTypeModelCode(
			"L-382G Lockheed Electra",
			"L382G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39_ALBATROSS = new AircraftTypeModelCode(
			"L-39 Albatross",
			"L39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39C = new AircraftTypeModelCode(
			"L-39C",
			"L39C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39D_ALBATROSS = new AircraftTypeModelCode(
			"L-39D Albatross",
			"L39D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39MS = new AircraftTypeModelCode(
			"L-39MS",
			"L39MS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39V = new AircraftTypeModelCode(
			"L-39V",
			"L39V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39Z_ALBATROSS = new AircraftTypeModelCode(
			"L-39Z Albatross",
			"L39Z",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39Z0 = new AircraftTypeModelCode(
			"L-39Z0",
			"L39Z0",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_39ZA = new AircraftTypeModelCode(
			"L-39ZA",
			"L39ZA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_410_TURBOJET = new AircraftTypeModelCode(
			"L-410 Turbojet",
			"L410",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_410_UVP = new AircraftTypeModelCode(
			"L-410 UVP",
			"L410U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_410_UVP_E = new AircraftTypeModelCode(
			"L-410 UVP-E",
			"L410UE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_410A_TURBOLET = new AircraftTypeModelCode(
			"L-410A Turbolet",
			"L410A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_420 = new AircraftTypeModelCode(
			"L-420",
			"L420",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_430 = new AircraftTypeModelCode(
			"L-430",
			"L430",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_450 = new AircraftTypeModelCode(
			"L-450",
			"L450",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_59E = new AircraftTypeModelCode(
			"L-59E",
			"L59E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_59T = new AircraftTypeModelCode(
			"L-59T",
			"L59T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_610G = new AircraftTypeModelCode(
			"L-610G",
			"L610G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_70_MILTRAINER = new AircraftTypeModelCode(
			"L-70 Miltrainer",
			"L70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_70_VINKA = new AircraftTypeModelCode(
			"L-70 Vinka",
			"L70VIN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode L_90_TP_REDIGO = new AircraftTypeModelCode(
			"L-90 TP Redigo",
			"L90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LA_250 = new AircraftTypeModelCode(
			"LA-250",
			"LA250",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LA_270 = new AircraftTypeModelCode(
			"LA-270",
			"LA270",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LA4_200 = new AircraftTypeModelCode(
			"LA4-200",
			"LA4200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LADOGA_6 = new AircraftTypeModelCode(
			"Ladoga-6",
			"LADO6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LADOGA_9 = new AircraftTypeModelCode(
			"Ladoga-9",
			"LADO0",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LAKE_LA_250_RENEGADE_SEAFURY = new AircraftTypeModelCode(
			"Lake La-250 Renegade / Seafury",
			"LA25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LAK_X = new AircraftTypeModelCode(
			"LAK-X",
			"LAKX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_320 = new AircraftTypeModelCode(
			"Lancair 320",
			"LAN320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_360 = new AircraftTypeModelCode(
			"Lancair 360",
			"LAN360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_ES = new AircraftTypeModelCode(
			"Lancair ES",
			"LANES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_IV = new AircraftTypeModelCode(
			"Lancair IV",
			"LAN4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_IV_P = new AircraftTypeModelCode(
			"Lancair IV-P",
			"LAN4P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LANCAIR_SUPER_ES = new AircraftTypeModelCode(
			"Lancair Super ES",
			"LANSES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LARKE_SKYCRANE = new AircraftTypeModelCode(
			"Larke Skycrane",
			"SKYCR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LASTA_1_SWALLOW = new AircraftTypeModelCode(
			"Lasta-1 / Swallow",
			"LASTA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LASTA_2_SWALLOW = new AircraftTypeModelCode(
			"Lasta-2 / Swallow",
			"LASTA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LCC130_HERCULES = new AircraftTypeModelCode(
			"LCC130 Hercules",
			"LC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LC_130F_HERCULES = new AircraftTypeModelCode(
			"LC-130F Hercules",
			"LC130F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LC_130H_HERCULES = new AircraftTypeModelCode(
			"LC-130H Hercules",
			"LC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LC_130R_HERCULES = new AircraftTypeModelCode(
			"LC-130R Hercules",
			"LC130R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LC_40 = new AircraftTypeModelCode(
			"LC-40",
			"LANLC4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET = new AircraftTypeModelCode(
			"Learjet",
			"LAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_24 = new AircraftTypeModelCode(
			"Learjet 24",
			"LJ24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_24A = new AircraftTypeModelCode(
			"Learjet 24A",
			"LJ24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_25 = new AircraftTypeModelCode(
			"Learjet 25",
			"LJ25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_25D = new AircraftTypeModelCode(
			"Learjet 25D",
			"LJ25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_31 = new AircraftTypeModelCode(
			"Learjet 31",
			"LJ31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_31A = new AircraftTypeModelCode(
			"Learjet 31A",
			"LJ31A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_35 = new AircraftTypeModelCode(
			"Learjet 35",
			"LJ35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_35A = new AircraftTypeModelCode(
			"Learjet 35A",
			"LJ35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_36A = new AircraftTypeModelCode(
			"Learjet 36A",
			"LJ36A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_45 = new AircraftTypeModelCode(
			"Learjet 45",
			"LJ45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_55 = new AircraftTypeModelCode(
			"Learjet 55",
			"LJ55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_55B = new AircraftTypeModelCode(
			"Learjet 55B",
			"LJ55B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_55C = new AircraftTypeModelCode(
			"Learjet 55C",
			"LJ55C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEARJET_60 = new AircraftTypeModelCode(
			"Learjet 60",
			"LJ60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LEOPARD = new AircraftTypeModelCode(
			"Leopard",
			"CMCLEO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LFI = new AircraftTypeModelCode(
			"LFI",
			"MIGLFI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LI_2_CAB = new AircraftTypeModelCode(
			"LI-2 Cab",
			"LI2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIGHTNING_F_2 = new AircraftTypeModelCode(
			"Lightning F-2",
			"F2LTNG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIGHTNING_F_2A = new AircraftTypeModelCode(
			"Lightning F-2A",
			"F2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIGHTNING_F_3 = new AircraftTypeModelCode(
			"Lightning F-3",
			"F3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIGHTNING_F_6 = new AircraftTypeModelCode(
			"Lightning F-6",
			"F6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIGHTNING_T_5 = new AircraftTypeModelCode(
			"Lightning T-5",
			"LGTT5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIM_1_FAGOT = new AircraftTypeModelCode(
			"LIM-1 Fagot",
			"LIM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LIM_6BIS_FRESCO_E = new AircraftTypeModelCode(
			"LIM-6BIS Fresco E",
			"LIM6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LM200_LOADMASTER = new AircraftTypeModelCode(
			"LM200 Loadmaster",
			"AYLM20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LM250_LOADMASTER = new AircraftTypeModelCode(
			"LM250 Loadmaster",
			"AYLLM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LOCKHEED_CONSTELLATION_649 = new AircraftTypeModelCode(
			"Lockheed Constellation 649",
			"L649",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LOCKHEED_CONSTELLATION_749 = new AircraftTypeModelCode(
			"Lockheed Constellation 749",
			"L749",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LOCKHEED_LODESTAR = new AircraftTypeModelCode(
			"Lockheed Lodestar",
			"L18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LOCKHEED_STARLINER = new AircraftTypeModelCode(
			"Lockheed Starliner",
			"L164",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LR_1_MITSUBISHI_MU_2 = new AircraftTypeModelCode(
			"LR-1 Mitsubishi MU-2",
			"LR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LR_2 = new AircraftTypeModelCode(
			"LR-2",
			"LR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_AH_MK_1GT = new AircraftTypeModelCode(
			"Lynx AH-MK-1GT",
			"LYAH1G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_AH_MK_5 = new AircraftTypeModelCode(
			"Lynx AH-MK-5",
			"LYAHM5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_AH_MK_7 = new AircraftTypeModelCode(
			"Lynx AH-MK-7",
			"LYAHM7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_AH_MK_9 = new AircraftTypeModelCode(
			"Lynx AH-MK-9",
			"LYAHM9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_AN_MK_53_COMMANDO = new AircraftTypeModelCode(
			"Lynx AN MK-53 Commando",
			"LHM53",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HAS_MK_2_COMMANDO = new AircraftTypeModelCode(
			"Lynx Has MK-2 Commando",
			"LHM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HAS_MK_2 = new AircraftTypeModelCode(
			"Lynx Has-MK-2",
			"LYHSM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HAS_MK_2FN = new AircraftTypeModelCode(
			"Lynx Has-MK-2FN",
			"LYHS2F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HAS_MK_3 = new AircraftTypeModelCode(
			"Lynx Has-MK-3",
			"LYHAM3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HAS_MK_4FN = new AircraftTypeModelCode(
			"Lynx Has-MK-4FN",
			"LYHS4F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_HMA_MK_8 = new AircraftTypeModelCode(
			"Lynx HMA-MK-8",
			"LYHMM8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_21 = new AircraftTypeModelCode(
			"Lynx MK-21",
			"LYMK21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_21A = new AircraftTypeModelCode(
			"Lynx MK-21A",
			"LYM21A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_23 = new AircraftTypeModelCode(
			"Lynx MK-23",
			"LYMK23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_25 = new AircraftTypeModelCode(
			"Lynx MK-25",
			"LYMK25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_27 = new AircraftTypeModelCode(
			"Lynx MK-27",
			"LYMK27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_28 = new AircraftTypeModelCode(
			"Lynx MK-28",
			"LYMK28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_80 = new AircraftTypeModelCode(
			"Lynx MK-80",
			"LYMK80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_81 = new AircraftTypeModelCode(
			"Lynx MK-81",
			"LYMK81",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_86 = new AircraftTypeModelCode(
			"Lynx MK-86",
			"LYMK86",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_88 = new AircraftTypeModelCode(
			"Lynx MK-88",
			"LYMK88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_88A = new AircraftTypeModelCode(
			"Lynx MK-88A",
			"LYM88A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_89 = new AircraftTypeModelCode(
			"Lynx MK-89",
			"LYMK89",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_90 = new AircraftTypeModelCode(
			"Lynx MK-90",
			"LYMK90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_95 = new AircraftTypeModelCode(
			"Lynx MK-95",
			"LYMK95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_MK_99 = new AircraftTypeModelCode(
			"Lynx MK-99",
			"LYMK99",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_SUPER_100 = new AircraftTypeModelCode(
			"Lynx Super 100",
			"LYS100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_SUPER_200 = new AircraftTypeModelCode(
			"Lynx Super 200",
			"LYS200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode LYNX_SUPER_300 = new AircraftTypeModelCode(
			"Lynx Super 300",
			"LYS300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_101T_GZHEL = new AircraftTypeModelCode(
			"M-101t Gzhel",
			"M101TG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_102_DUET_SARAS = new AircraftTypeModelCode(
			"M-102 Duet / Saras",
			"M102DS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_112 = new AircraftTypeModelCode(
			"M-112",
			"M112",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_17_MYSTIC = new AircraftTypeModelCode(
			"M-17 Mystic",
			"M17MYS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_18_DROMADER = new AircraftTypeModelCode(
			"M-18 Dromader",
			"M18DRO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_20_R_OVATION = new AircraftTypeModelCode(
			"M-20 R Ovation",
			"MO20RO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_201_SOKOL = new AircraftTypeModelCode(
			"M-201 Sokol",
			"M201SO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_20J_MSE = new AircraftTypeModelCode(
			"M-20J MSE",
			"MO20JM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_20K_ENCORE = new AircraftTypeModelCode(
			"M-20K Encore",
			"MO20KE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_20M_TLS = new AircraftTypeModelCode(
			"M-20M-TLS",
			"MO20MT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_26_00_AIR_WOLF = new AircraftTypeModelCode(
			"M-26 00 Air Wolf",
			"M2600A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_26_01_LITTLE_SPARK = new AircraftTypeModelCode(
			"M-26 01 Little Spark",
			"M2601L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_26_ISKIERKA = new AircraftTypeModelCode(
			"M-26 Iskierka",
			"M26ISK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_262 = new AircraftTypeModelCode(
			"M-262",
			"M262",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_28_SKYTRUCK = new AircraftTypeModelCode(
			"M-28 Skytruck",
			"M28ST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_290TP = new AircraftTypeModelCode(
			"M-290TP",
			"M290TP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_300 = new AircraftTypeModelCode(
			"M-300",
			"NMM300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_4 = new AircraftTypeModelCode(
			"M-4",
			"M4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_4_BISON = new AircraftTypeModelCode(
			"M-4 Bison",
			"BSN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_4_BISON_A = new AircraftTypeModelCode(
			"M-4 Bison A",
			"BSNA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_4_BISON_B = new AircraftTypeModelCode(
			"M-4 Bison B",
			"BSNB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_4_BISON_C = new AircraftTypeModelCode(
			"M-4 Bison C",
			"BSNC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode M_58_MASQUITO = new AircraftTypeModelCode(
			"M-58 Masquito",
			"M58MAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MADCAP = new AircraftTypeModelCode(
			"Madcap",
			"MCP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MADCAP_COALER = new AircraftTypeModelCode(
			"Madcap Coaler",
			"MADCAP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MAIDEN = new AircraftTypeModelCode(
			"Maiden",
			"MDN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MANGROVE = new AircraftTypeModelCode(
			"Mangrove",
			"MNG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARITIME_ENFORCE_MK_FOKKER_50 = new AircraftTypeModelCode(
			"Maritime Enforce MK Fokker 50",
			"MARMK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARITIME_ENFORCER_FRIENDSHIP = new AircraftTypeModelCode(
			"Maritime Enforcer Friendship",
			"MAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARITIME_FOKKER_50 = new AircraftTypeModelCode(
			"Maritime Fokker 50",
			"MARMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARITIME_PATROL_B200T = new AircraftTypeModelCode(
			"Maritime Patrol B200T",
			"B200TM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARTIN_MODEL_202 = new AircraftTypeModelCode(
			"Martin Model 202",
			"M202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARTIN_MODEL_404 = new AircraftTypeModelCode(
			"Martin Model 404",
			"M404",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARTU_HAL_HF_241T = new AircraftTypeModelCode(
			"Martu HAL HF-241T",
			"HF241T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MARUT_WINDSPIRIT = new AircraftTypeModelCode(
			"Marut Windspirit",
			"MARWND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MASCOT_HJ_5 = new AircraftTypeModelCode(
			"Mascot / HJ-5",
			"HJ5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MASCOT_BEAGLE = new AircraftTypeModelCode(
			"Mascot Beagle",
			"MASCOT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MASHSHAQ_SUPPORTER = new AircraftTypeModelCode(
			"Mashshaq Supporter",
			"MASH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MATADOR_HARRIER = new AircraftTypeModelCode(
			"Matador Harrier",
			"MATAD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MATADOR_II_VA_2 = new AircraftTypeModelCode(
			"Matador II VA-2",
			"EAV8B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MAX = new AircraftTypeModelCode(
			"Max",
			"MAX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_312_TUCANO = new AircraftTypeModelCode(
			"MB-312 Tucano",
			"MB312",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326_AERMACCHI = new AircraftTypeModelCode(
			"MB-326 Aermacchi",
			"MB326",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326_XAVANTE = new AircraftTypeModelCode(
			"MB-326 Xavante",
			"MB326X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326B = new AircraftTypeModelCode(
			"MB-326B",
			"MB326B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326F = new AircraftTypeModelCode(
			"MB-326F",
			"MB326F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326GB = new AircraftTypeModelCode(
			"MB-326GB",
			"MB326G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326H_XAVANTE = new AircraftTypeModelCode(
			"MB-326h Xavante",
			"MB326H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326K = new AircraftTypeModelCode(
			"MB-326K",
			"MB326K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326K_AERMACCHI = new AircraftTypeModelCode(
			"MB-326K Aermacchi",
			"MB326A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326KD = new AircraftTypeModelCode(
			"MB-326KD",
			"MB326D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326L = new AircraftTypeModelCode(
			"MB-326L",
			"MB326L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_326M_IMPALA = new AircraftTypeModelCode(
			"MB-326M Impala",
			"MB326M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339_AERMACCHI = new AircraftTypeModelCode(
			"MB-339 Aermacchi",
			"MB339",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339A_AERMACCHI = new AircraftTypeModelCode(
			"MB-339A Aermacchi",
			"MB339A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339A_VELTRO_II = new AircraftTypeModelCode(
			"MB-339A Veltro II",
			"MB339V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339AM = new AircraftTypeModelCode(
			"MB-339AM",
			"MB339M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339B = new AircraftTypeModelCode(
			"MB-339B",
			"MB339B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339C = new AircraftTypeModelCode(
			"MB-339C",
			"MB339C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339CB = new AircraftTypeModelCode(
			"MB-339CB",
			"MB39CB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339CD = new AircraftTypeModelCode(
			"MB-339CD",
			"MB339D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339CE = new AircraftTypeModelCode(
			"MB-339CE",
			"MB339E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MB_339K = new AircraftTypeModelCode(
			"MB-339K",
			"MB339K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MBB_223_FLAMINGO = new AircraftTypeModelCode(
			"MBB-223 Flamingo",
			"MBB223",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MC_130_HERCULES = new AircraftTypeModelCode(
			"MC-130 Hercules",
			"MC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MC_130E_HERCULES = new AircraftTypeModelCode(
			"MC-130E Hercules",
			"MC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MC_130H_HERCULES = new AircraftTypeModelCode(
			"MC-130H Hercules",
			"MC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MC_130P_HERCULES = new AircraftTypeModelCode(
			"MC-130P Hercules",
			"MC130P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MCDONNELL_DOUGLAS_DESTROYER = new AircraftTypeModelCode(
			"Mcdonnell-Douglas Destroyer",
			"B66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MCDONNELL_DOUGLAS_MD_90 = new AircraftTypeModelCode(
			"Mcdonnell-Douglas Md-90",
			"MD90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MCDONNELL_DOUGLAS_SKYNIGHT = new AircraftTypeModelCode(
			"Mcdonnell-Douglas Skynight",
			"F10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_11_COMBI = new AircraftTypeModelCode(
			"MD-11 Combi",
			"MD11C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_11_DOUGLAS = new AircraftTypeModelCode(
			"MD-11 Douglas",
			"MD11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_11CF = new AircraftTypeModelCode(
			"MD-11CF",
			"MD11CF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_11ER = new AircraftTypeModelCode(
			"MD-11ER",
			"MD11ER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_11F_DOUGLAS = new AircraftTypeModelCode(
			"MD-11F Douglas",
			"MD11F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_17 = new AircraftTypeModelCode(
			"MD-17",
			"MD17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500B_COMMANDER = new AircraftTypeModelCode(
			"MD-500B Commander",
			"MD500B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500C = new AircraftTypeModelCode(
			"MD-500C",
			"MD500C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500D_DEFENDER_CAYUSE = new AircraftTypeModelCode(
			"MD-500D Defender Cayuse",
			"MD500D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500E = new AircraftTypeModelCode(
			"MD-500E",
			"MD500E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500F_LIFTER = new AircraftTypeModelCode(
			"MD-500F Lifter",
			"H500F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500M = new AircraftTypeModelCode(
			"MD-500M",
			"MD50M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500MD_SCOUT_DEFENDER_TOW_DEFENDER = new AircraftTypeModelCode(
			"MD-500MD Scout Defender / Tow Defender",
			"MD50MD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500ME_MD_500E_DEFENDER_II = new AircraftTypeModelCode(
			"MD-500ME / MD-500E / Defender II",
			"MD50ME",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_500MG_DEFENDER_II = new AircraftTypeModelCode(
			"MD-500MG Defender II",
			"MD50MG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_520N_BLACK_TIGER = new AircraftTypeModelCode(
			"MD-520N Black Tiger",
			"MD520N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_530_DEFENDER_AH_6_EH_6 = new AircraftTypeModelCode(
			"MD-530 Defender / AH-6 / EH-6",
			"MD530",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_530F_CAYUSE_SUPER_CAYUSE_LIFTER = new AircraftTypeModelCode(
			"MD-530f Cayuse / Super Cayuse / Lifter",
			"MD530F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_600N = new AircraftTypeModelCode(
			"MD-600N",
			"MD600N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_80_DOUGLAS = new AircraftTypeModelCode(
			"MD-80 Douglas",
			"MD80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_81_DOUGLAS = new AircraftTypeModelCode(
			"MD-81 Douglas",
			"MD81",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_82_DOUGLAS = new AircraftTypeModelCode(
			"MD-82 Douglas",
			"MD82",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_82T = new AircraftTypeModelCode(
			"MD-82T",
			"MD82T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_83_DOUGLAS = new AircraftTypeModelCode(
			"MD-83 Douglas",
			"MD83",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_87_DOUGLAS = new AircraftTypeModelCode(
			"MD-87 Douglas",
			"MD87",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_88_DOUGLAS = new AircraftTypeModelCode(
			"MD-88 Douglas",
			"MD88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_900_EXPLORER = new AircraftTypeModelCode(
			"MD-900 Explorer",
			"MD900",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_90_30 = new AircraftTypeModelCode(
			"MD-90-30",
			"MD903",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_90_30ER = new AircraftTypeModelCode(
			"MD-90-30ER",
			"MD903E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_90_30T = new AircraftTypeModelCode(
			"MD-90-30T",
			"MD903T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_920_EXPLORER = new AircraftTypeModelCode(
			"MD-920 Explorer",
			"MD920",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_95 = new AircraftTypeModelCode(
			"MD-95",
			"MD95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_95_30 = new AircraftTypeModelCode(
			"MD-95-30",
			"MD953",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MD_95_50 = new AircraftTypeModelCode(
			"MD-95-50",
			"MD955",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_23 = new AircraftTypeModelCode(
			"Merlin 23",
			"MER23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_23E = new AircraftTypeModelCode(
			"Merlin 23E",
			"MER23E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_HC_MK_3 = new AircraftTypeModelCode(
			"Merlin HC-MK-3",
			"MERHC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_HM_MK_2 = new AircraftTypeModelCode(
			"Merlin HM-MK-2",
			"MERHM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_II_SWEARINGEN = new AircraftTypeModelCode(
			"Merlin II Swearingen",
			"MER2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_IIA = new AircraftTypeModelCode(
			"Merlin IIA",
			"MER2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_IIB = new AircraftTypeModelCode(
			"Merlin IIB",
			"MER2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_III = new AircraftTypeModelCode(
			"Merlin III",
			"MER3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_IIIB_SWEARINGEN = new AircraftTypeModelCode(
			"Merlin IIIB Swearingen",
			"MER3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERLIN_IV = new AircraftTypeModelCode(
			"Merlin IV",
			"MER4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MERMAID = new AircraftTypeModelCode(
			"Mermaid",
			"MMD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MESSENGER_T_910 = new AircraftTypeModelCode(
			"Messenger / T-910",
			"T910",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MESSERSCHMITT_BO_209_MONSUN = new AircraftTypeModelCode(
			"Messerschmitt BO 209 Monsun",
			"ME29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode METRO_23_DC_METRO_23 = new AircraftTypeModelCode(
			"Metro 23 / DC Metro 23",
			"MET23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode METRO_II_SWEARINGEN = new AircraftTypeModelCode(
			"Metro II Swearingen",
			"MET2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode METRO_IIA_SWEARINGEN = new AircraftTypeModelCode(
			"Metro IIA Swearingen",
			"MET2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode METRO_III_SWEARINGEN = new AircraftTypeModelCode(
			"Metro III Swearingen",
			"MET3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MEWA_M_20 = new AircraftTypeModelCode(
			"Mewa M-20",
			"MEM20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MEYERS_200 = new AircraftTypeModelCode(
			"Meyers 200",
			"MY20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MFI_15_SAAB_SAFARI = new AircraftTypeModelCode(
			"MFI-15 Saab Safari",
			"MFI15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MFI_17_SUPPORTER = new AircraftTypeModelCode(
			"MFI-17 Supporter",
			"MFI17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MFI_18 = new AircraftTypeModelCode(
			"MFI-18",
			"MFI18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MGS_6 = new AircraftTypeModelCode(
			"MGS-6",
			"MGS6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MGS_8 = new AircraftTypeModelCode(
			"MGS-8",
			"MGS8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_1521_BROUSSARD = new AircraftTypeModelCode(
			"MH-1521 Broussard",
			"MH1521",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_47_CHINOOK = new AircraftTypeModelCode(
			"MH-47 Chinook",
			"MH47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_47_D = new AircraftTypeModelCode(
			"MH-47 D",
			"MH47D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_47E = new AircraftTypeModelCode(
			"MH-47E",
			"MH47E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_53E_PAVELOW_III = new AircraftTypeModelCode(
			"MH-53E Pavelow III",
			"MH53E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_53E_SEA_DRAGON = new AircraftTypeModelCode(
			"MH-53E Sea Dragon",
			"MH53ED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_53E_SUPER_SEASPRITE = new AircraftTypeModelCode(
			"MH-53E Super Seasprite",
			"MH53EP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH53E_SUPER_STALLION = new AircraftTypeModelCode(
			"MH53E Super Stallion",
			"MH53ES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_53H_PAVELOW_III = new AircraftTypeModelCode(
			"MH-53H Pavelow III",
			"MH53H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_53J_PAVELOW_III = new AircraftTypeModelCode(
			"MH-53J Pavelow III",
			"MH53J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_6_CAYUSE = new AircraftTypeModelCode(
			"MH-6 Cayuse",
			"MH6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_60_PAVE_HAWK = new AircraftTypeModelCode(
			"MH-60 Pave Hawk",
			"MH60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_60A = new AircraftTypeModelCode(
			"MH-60A",
			"MH60A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_60G_PAVE_HAWK = new AircraftTypeModelCode(
			"MH-60G Pave Hawk",
			"MH60G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_60K_PAVE_HAWK = new AircraftTypeModelCode(
			"MH-60K Pave Hawk",
			"MH60K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MH_6B_CAYUSE = new AircraftTypeModelCode(
			"MH-6B Cayuse",
			"MH6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_1 = new AircraftTypeModelCode(
			"MI-1",
			"MI1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_1_HARE = new AircraftTypeModelCode(
			"MI-1 Hare",
			"HAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10 = new AircraftTypeModelCode(
			"MI-10",
			"MI10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10_HARKE = new AircraftTypeModelCode(
			"MI-10 Harke",
			"HRK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10_HARKE_A = new AircraftTypeModelCode(
			"MI-10 Harke A",
			"HRKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10_HARKE_B = new AircraftTypeModelCode(
			"MI-10 Harke B",
			"HRKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10K_HARKE = new AircraftTypeModelCode(
			"MI-10K Harke",
			"MI10K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_10K_HARKE_B = new AircraftTypeModelCode(
			"MI-10K Harke B",
			"HRKKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_12_HOMER = new AircraftTypeModelCode(
			"MI-12 Homer",
			"MI12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14 = new AircraftTypeModelCode(
			"MI-14",
			"MI14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_BT_HAZE_B = new AircraftTypeModelCode(
			"MI-14 BT Haze B",
			"HAZBT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_HAZE = new AircraftTypeModelCode(
			"MI-14 Haze",
			"HAZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_HAZE_A = new AircraftTypeModelCode(
			"MI-14 Haze A",
			"HAZA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_HAZE_B = new AircraftTypeModelCode(
			"MI-14 Haze B",
			"HAZB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_PL_HAZE_A = new AircraftTypeModelCode(
			"MI-14 PL Haze A",
			"HAZAPL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14_PS_HAZE_C = new AircraftTypeModelCode(
			"MI-14 PS Haze C",
			"HAZCPS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14BT = new AircraftTypeModelCode(
			"MI-14BT",
			"MI14BT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14GP = new AircraftTypeModelCode(
			"MI-14GP",
			"MI14GP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14P = new AircraftTypeModelCode(
			"MI-14P",
			"MI14P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14PL = new AircraftTypeModelCode(
			"MI-14PL",
			"MI14PL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14PLM = new AircraftTypeModelCode(
			"MI-14PLM",
			"MI14PM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14PS = new AircraftTypeModelCode(
			"MI-14PS",
			"MI14PS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_14PW = new AircraftTypeModelCode(
			"MI-14PW",
			"MI14PW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_17 = new AircraftTypeModelCode(
			"MI-17",
			"MI17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_17_HIP_H = new AircraftTypeModelCode(
			"MI-17 Hip H",
			"HIPH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_17_HIP_K = new AircraftTypeModelCode(
			"MI-17 Hip K",
			"HIPK17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_171_HIP = new AircraftTypeModelCode(
			"MI-171 Hip",
			"MI171",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_17_1V = new AircraftTypeModelCode(
			"MI-17-1V",
			"MI171V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_172_HIP = new AircraftTypeModelCode(
			"MI-172 Hip",
			"MI172",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_17Z_II = new AircraftTypeModelCode(
			"MI-17Z-II",
			"MI17Z",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_2 = new AircraftTypeModelCode(
			"MI-2",
			"MI2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_2_HOPLITE = new AircraftTypeModelCode(
			"MI-2 Hoplite",
			"HOP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_22_HOOK_C = new AircraftTypeModelCode(
			"MI-22 Hook C",
			"MI22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24 = new AircraftTypeModelCode(
			"MI-24",
			"MI24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND = new AircraftTypeModelCode(
			"MI-24 Hind",
			"HIN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND_A = new AircraftTypeModelCode(
			"MI-24 Hind A",
			"HINA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND_B = new AircraftTypeModelCode(
			"MI-24 Hind B",
			"HINB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND_C = new AircraftTypeModelCode(
			"MI-24 Hind C",
			"HINC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND_D = new AircraftTypeModelCode(
			"MI-24 Hind D",
			"HIND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_HIND_E = new AircraftTypeModelCode(
			"MI-24 Hind E",
			"HINE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_K_HIND_G_2 = new AircraftTypeModelCode(
			"MI-24 K Hind G-2",
			"HING2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_P_HIND_F = new AircraftTypeModelCode(
			"MI-24 P Hind F",
			"HINF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_R_HIND_G_1 = new AircraftTypeModelCode(
			"MI-24 R Hind G-1",
			"HINR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24_W_HIND_G_1 = new AircraftTypeModelCode(
			"MI-24 W Hind G-1",
			"HINW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24A = new AircraftTypeModelCode(
			"MI-24A",
			"MI24A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24BMT = new AircraftTypeModelCode(
			"MI-24BMT",
			"MI24BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24DU = new AircraftTypeModelCode(
			"MI-24DU",
			"MI24DU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24ESV = new AircraftTypeModelCode(
			"MI-24ESV",
			"MI24ES",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24K = new AircraftTypeModelCode(
			"MI-24K",
			"MI24K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24P = new AircraftTypeModelCode(
			"MI-24P",
			"MI24P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24RKR = new AircraftTypeModelCode(
			"MI-24RKR",
			"MI24RK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24V = new AircraftTypeModelCode(
			"MI-24V",
			"MI24V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24VM = new AircraftTypeModelCode(
			"MI-24VM",
			"MI24VM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_24VP = new AircraftTypeModelCode(
			"MI-24VP",
			"MI24VP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26_HALO = new AircraftTypeModelCode(
			"MI-26 Halo",
			"MI26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26A = new AircraftTypeModelCode(
			"MI-26A",
			"MI26A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26M = new AircraftTypeModelCode(
			"MI-26M",
			"MI26M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26MS = new AircraftTypeModelCode(
			"MI-26MS",
			"MI26MS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26T = new AircraftTypeModelCode(
			"MI-26T",
			"MI26T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26TM = new AircraftTypeModelCode(
			"MI-26TM",
			"MI26TM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26TS = new AircraftTypeModelCode(
			"MI-26TS",
			"MI26TS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_26TZ = new AircraftTypeModelCode(
			"MI-26TZ",
			"MI26TZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_27 = new AircraftTypeModelCode(
			"MI-27",
			"MI27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_28 = new AircraftTypeModelCode(
			"MI-28",
			"MI28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_28_HAVOC = new AircraftTypeModelCode(
			"MI-28 Havoc",
			"HVC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_28_HAVOC_A = new AircraftTypeModelCode(
			"MI-28 Havoc A",
			"HVCA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_28N = new AircraftTypeModelCode(
			"MI-28N",
			"MI28N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_2PS = new AircraftTypeModelCode(
			"MI-2PS",
			"MI24PS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_34_HERMET = new AircraftTypeModelCode(
			"MI-34 Hermet",
			"MI34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_34A = new AircraftTypeModelCode(
			"MI-34A",
			"MI34A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_34S = new AircraftTypeModelCode(
			"MI-34S",
			"MI34S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_34VAZ = new AircraftTypeModelCode(
			"MI-34VAZ",
			"MI34VA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_35_HIND = new AircraftTypeModelCode(
			"MI-35 Hind",
			"MI35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_35D = new AircraftTypeModelCode(
			"MI-35D",
			"MI35D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_35M = new AircraftTypeModelCode(
			"MI-35M",
			"MI35M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_35P = new AircraftTypeModelCode(
			"MI-35P",
			"MI35P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_38 = new AircraftTypeModelCode(
			"MI-38",
			"MI38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_HOUND = new AircraftTypeModelCode(
			"MI-4 Hound",
			"HND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_HOUND_A = new AircraftTypeModelCode(
			"MI-4 Hound A",
			"HNDA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_HOUND_B = new AircraftTypeModelCode(
			"MI-4 Hound B",
			"HNDB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_HOUND_C = new AircraftTypeModelCode(
			"MI-4 Hound C",
			"HNDC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_HOUND_PRC = new AircraftTypeModelCode(
			"MI-4 Hound Prc",
			"HNDP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_4_Z5_HOUND = new AircraftTypeModelCode(
			"MI-4/Z5 Hound",
			"Z5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_40 = new AircraftTypeModelCode(
			"MI-40",
			"MI40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_52 = new AircraftTypeModelCode(
			"MI-52",
			"MI52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_54 = new AircraftTypeModelCode(
			"MI-54",
			"MI54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_58 = new AircraftTypeModelCode(
			"MI-58",
			"MI58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6_AYASH = new AircraftTypeModelCode(
			"MI-6 Ayash",
			"MI6AY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6_HOOK = new AircraftTypeModelCode(
			"MI-6 Hook",
			"HOK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6_HOOK_A = new AircraftTypeModelCode(
			"MI-6 Hook A",
			"HOKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6_HOOK_B = new AircraftTypeModelCode(
			"MI-6 Hook B",
			"HOKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6_HOOK_C_CMD_VARIANT = new AircraftTypeModelCode(
			"MI-6 Hook C Cmd Variant",
			"HOKC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6A_HOOK = new AircraftTypeModelCode(
			"MI-6A Hook",
			"MI6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6T = new AircraftTypeModelCode(
			"MI-6T",
			"MI6T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_6VKP = new AircraftTypeModelCode(
			"MI-6VKP",
			"MI6VKP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8 = new AircraftTypeModelCode(
			"MI-8",
			"MI8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP = new AircraftTypeModelCode(
			"MI-8 Hip",
			"HIP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_A = new AircraftTypeModelCode(
			"MI-8 Hip A",
			"HIPA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_B = new AircraftTypeModelCode(
			"MI-8 Hip B",
			"HIPB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_C = new AircraftTypeModelCode(
			"MI-8 Hip C",
			"HIPC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_D = new AircraftTypeModelCode(
			"MI-8 Hip D",
			"HIPD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_E = new AircraftTypeModelCode(
			"MI-8 Hip E",
			"HIPE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_F = new AircraftTypeModelCode(
			"MI-8 Hip F",
			"HIPF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_G = new AircraftTypeModelCode(
			"MI-8 Hip G",
			"HIPG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_J = new AircraftTypeModelCode(
			"MI-8 Hip J",
			"HIPJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8_HIP_K = new AircraftTypeModelCode(
			"MI-8 Hip K",
			"HIPK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8AT = new AircraftTypeModelCode(
			"MI-8AT",
			"MI8AT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8BT = new AircraftTypeModelCode(
			"MI-8BT",
			"MI8BT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8K = new AircraftTypeModelCode(
			"MI-8K",
			"MI8K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8MT = new AircraftTypeModelCode(
			"MI-8MT",
			"MI8MT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8MTV = new AircraftTypeModelCode(
			"MI-8MTV",
			"MI8MTV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8P = new AircraftTypeModelCode(
			"MI-8P",
			"MI8P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8PPA = new AircraftTypeModelCode(
			"MI-8PPA",
			"MI8PPA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8PS = new AircraftTypeModelCode(
			"MI-8PS",
			"MI8PS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8R = new AircraftTypeModelCode(
			"MI-8R",
			"MI8R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8S = new AircraftTypeModelCode(
			"MI-8S",
			"MI8S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8SMV = new AircraftTypeModelCode(
			"MI-8SMV",
			"MI8SMV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8T_HIP = new AircraftTypeModelCode(
			"MI-8t Hip",
			"MI8T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TB = new AircraftTypeModelCode(
			"MI-8TB",
			"MI8TB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TBK = new AircraftTypeModelCode(
			"MI-8TBK",
			"MI8TBK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TG = new AircraftTypeModelCode(
			"MI-8TG",
			"MI8TG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TM = new AircraftTypeModelCode(
			"MI-8TM",
			"MI8TM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TP = new AircraftTypeModelCode(
			"MI-8TP",
			"MI8TP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TV = new AircraftTypeModelCode(
			"MI-8TV",
			"MI8TV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8TZ = new AircraftTypeModelCode(
			"MI-8TZ",
			"MI8TZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8VIP = new AircraftTypeModelCode(
			"MI-8VIP",
			"MI8VIP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_8VZPU = new AircraftTypeModelCode(
			"MI-8VZPU",
			"MI8VZP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MI_9_HIP_G = new AircraftTypeModelCode(
			"MI-9 Hip G",
			"MI9HPG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIDAS = new AircraftTypeModelCode(
			"Midas",
			"MDS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIDAS_IL_78 = new AircraftTypeModelCode(
			"Midas / Il-78",
			"IL78MI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIDGET_FAGOT = new AircraftTypeModelCode(
			"Midget Fagot",
			"MIDFAG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_1_42_MFI = new AircraftTypeModelCode(
			"Mig 1-42 MFI",
			"MIG142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_110 = new AircraftTypeModelCode(
			"Mig-110",
			"MIG110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_15 = new AircraftTypeModelCode(
			"Mig-15",
			"MIG15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_15_FAGOT = new AircraftTypeModelCode(
			"Mig-15 Fagot",
			"FAG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_15U = new AircraftTypeModelCode(
			"Mig-15U",
			"MIG15U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_15U_MIDGET = new AircraftTypeModelCode(
			"Mig-15U Midget",
			"MID",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_15UTI_FAGOT = new AircraftTypeModelCode(
			"Mig-15UTI Fagot",
			"M15UTI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO = new AircraftTypeModelCode(
			"Mig-17 Fresco",
			"FRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO_A = new AircraftTypeModelCode(
			"Mig-17 Fresco A",
			"FREA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO_B = new AircraftTypeModelCode(
			"Mig-17 Fresco B",
			"FREB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO_C = new AircraftTypeModelCode(
			"Mig-17 Fresco C",
			"FREC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO_D = new AircraftTypeModelCode(
			"Mig-17 Fresco D",
			"FRED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_17_FRESCO_E = new AircraftTypeModelCode(
			"Mig-17 Fresco E",
			"FREE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER = new AircraftTypeModelCode(
			"Mig-19 Farmer",
			"FMR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_A = new AircraftTypeModelCode(
			"Mig-19 Farmer A",
			"FMRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_B = new AircraftTypeModelCode(
			"Mig-19 Farmer B",
			"FMRB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_C = new AircraftTypeModelCode(
			"Mig-19 Farmer C",
			"FMRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_D = new AircraftTypeModelCode(
			"Mig-19 Farmer D",
			"FMRD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_E = new AircraftTypeModelCode(
			"Mig-19 Farmer E",
			"FMRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_19_FARMER_F = new AircraftTypeModelCode(
			"Mig-19 Farmer F",
			"FMRF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_BIS_FISHBED_L = new AircraftTypeModelCode(
			"Mig-21 Bis Fishbed L",
			"M21B1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_BIS_FISHBED_N = new AircraftTypeModelCode(
			"Mig-21 Bis Fishbed N",
			"M21BIS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED = new AircraftTypeModelCode(
			"Mig-21 Fishbed",
			"FBD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_A = new AircraftTypeModelCode(
			"Mig-21 Fishbed A",
			"FBDA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_B = new AircraftTypeModelCode(
			"Mig-21 Fishbed B",
			"FBDB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_C = new AircraftTypeModelCode(
			"Mig-21 Fishbed C",
			"FBDC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_D = new AircraftTypeModelCode(
			"Mig-21 Fishbed D",
			"FBDD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_E = new AircraftTypeModelCode(
			"Mig-21 Fishbed E",
			"FBDE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_F = new AircraftTypeModelCode(
			"Mig-21 Fishbed F",
			"FBDF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_H = new AircraftTypeModelCode(
			"Mig-21 Fishbed H",
			"FBDH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_J = new AircraftTypeModelCode(
			"Mig-21 Fishbed J",
			"FBDJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_K = new AircraftTypeModelCode(
			"Mig-21 Fishbed K",
			"FBDK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_L = new AircraftTypeModelCode(
			"Mig-21 Fishbed L",
			"FBDL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_FISHBED_N = new AircraftTypeModelCode(
			"Mig-21 Fishbed N",
			"FBDN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_MONGOL = new AircraftTypeModelCode(
			"Mig-21 Mongol",
			"MOG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_MONGOL_A = new AircraftTypeModelCode(
			"Mig-21 Mongol A",
			"MOGA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_MONGOL_B = new AircraftTypeModelCode(
			"Mig-21 Mongol B",
			"MOGB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21_MONGOL_C = new AircraftTypeModelCode(
			"Mig-21 Mongol C",
			"MOGC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21BIS = new AircraftTypeModelCode(
			"Mig-21BIS",
			"MIG21B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21F_FISHBED_C = new AircraftTypeModelCode(
			"Mig-21F Fishbed C",
			"MIG21F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21FI = new AircraftTypeModelCode(
			"Mig-21FI",
			"MIG21L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21M = new AircraftTypeModelCode(
			"Mig-21M",
			"MIG21M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21MB_FISHBED_J = new AircraftTypeModelCode(
			"Mig-21MB Fishbed J",
			"MG21MF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21PFM_FISHBED_F = new AircraftTypeModelCode(
			"Mig-21PFM Fishbed F",
			"MG21PF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21PFMA_FISHBED_J = new AircraftTypeModelCode(
			"Mig-21PFMA Fishbed J",
			"MG21PA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21PFS = new AircraftTypeModelCode(
			"Mig-21PFS",
			"MG21PS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21R_FISHBED_H = new AircraftTypeModelCode(
			"Mig-21R Fishbed H",
			"MG21R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21RF_FISHBED_H = new AircraftTypeModelCode(
			"Mig-21RF Fishbed H",
			"MG21RF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21SMT_FISHBED_K = new AircraftTypeModelCode(
			"Mig-21SMT Fishbed K",
			"MG21SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21U_MONGOL_A = new AircraftTypeModelCode(
			"Mig-21U Mongol A",
			"MG21U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21UM = new AircraftTypeModelCode(
			"Mig-21UM",
			"MG21UM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21UM_MONGOL_B = new AircraftTypeModelCode(
			"Mig-21UM Mongol B",
			"M21UM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21US = new AircraftTypeModelCode(
			"Mig-21US",
			"MG21US",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_21US_MONGOL_B = new AircraftTypeModelCode(
			"Mig-21US Mongol B",
			"M21US",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER = new AircraftTypeModelCode(
			"Mig-23 Flogger",
			"FLO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_A = new AircraftTypeModelCode(
			"Mig-23 Flogger A",
			"FLOA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_B = new AircraftTypeModelCode(
			"Mig-23 Flogger B",
			"FLOB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_C = new AircraftTypeModelCode(
			"Mig-23 Flogger C",
			"FLOC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_E = new AircraftTypeModelCode(
			"Mig-23 Flogger E",
			"FLOE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_F = new AircraftTypeModelCode(
			"Mig-23 Flogger F",
			"FLOF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_G = new AircraftTypeModelCode(
			"Mig-23 Flogger G",
			"FLOG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_H = new AircraftTypeModelCode(
			"Mig-23 Flogger H",
			"FLOH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23_FLOGGER_K = new AircraftTypeModelCode(
			"Mig-23 Flogger K",
			"FLOK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23BN = new AircraftTypeModelCode(
			"Mig-23BN",
			"MIG23B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23M = new AircraftTypeModelCode(
			"Mig-23M",
			"MIG23M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23MF = new AircraftTypeModelCode(
			"Mig-23MF",
			"MG23MF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23ML = new AircraftTypeModelCode(
			"Mig-23ML",
			"MG23ML",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23MS = new AircraftTypeModelCode(
			"Mig-23MS",
			"MG23MS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23S_FLOGGER_A = new AircraftTypeModelCode(
			"Mig-23S Flogger A",
			"MIG23S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23SM = new AircraftTypeModelCode(
			"Mig-23SM",
			"MG23SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23UB = new AircraftTypeModelCode(
			"Mig-23UB",
			"MG23UB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_23UM = new AircraftTypeModelCode(
			"Mig-23UM",
			"MG23UM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT = new AircraftTypeModelCode(
			"Mig-25 Foxbat",
			"FOX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_A = new AircraftTypeModelCode(
			"Mig-25 Foxbat A",
			"FOXA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_B = new AircraftTypeModelCode(
			"Mig-25 Foxbat B",
			"FOXB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_C = new AircraftTypeModelCode(
			"Mig-25 Foxbat C",
			"FOXC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_D = new AircraftTypeModelCode(
			"Mig-25 Foxbat D",
			"FOXD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_E = new AircraftTypeModelCode(
			"Mig-25 Foxbat E",
			"FOXE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25_FOXBAT_F = new AircraftTypeModelCode(
			"Mig-25 Foxbat F",
			"FOXF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25BM = new AircraftTypeModelCode(
			"Mig-25BM",
			"MG25BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25M = new AircraftTypeModelCode(
			"Mig-25M",
			"MIG25M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25R = new AircraftTypeModelCode(
			"Mig-25R",
			"MIG25R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25RB = new AircraftTypeModelCode(
			"Mig-25RB",
			"MG25RB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25RBK = new AircraftTypeModelCode(
			"Mig-25RBK",
			"MG25RK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25RU = new AircraftTypeModelCode(
			"Mig-25RU",
			"MG25RU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_25U = new AircraftTypeModelCode(
			"Mig-25U",
			"MIG25U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_27 = new AircraftTypeModelCode(
			"Mig-27",
			"MIG27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_27_FLOGGER_D = new AircraftTypeModelCode(
			"Mig-27 Flogger D",
			"FLOD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_27_FLOGGER_J = new AircraftTypeModelCode(
			"Mig-27 Flogger J",
			"FLOJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29_FULCRUM = new AircraftTypeModelCode(
			"Mig-29 Fulcrum",
			"FCM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29_FULCRUM_A = new AircraftTypeModelCode(
			"Mig-29 Fulcrum A",
			"FCMA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29_FULCRUM_B = new AircraftTypeModelCode(
			"Mig-29 Fulcrum B",
			"FCMB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29_FULCRUM_C = new AircraftTypeModelCode(
			"Mig-29 Fulcrum C",
			"FCMC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29K = new AircraftTypeModelCode(
			"Mig-29K",
			"MIG29K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29M = new AircraftTypeModelCode(
			"Mig-29M",
			"MIG29M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29ME = new AircraftTypeModelCode(
			"Mig-29ME",
			"MG29ME",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29N = new AircraftTypeModelCode(
			"Mig-29N",
			"MIG29N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29NUB = new AircraftTypeModelCode(
			"Mig-29NUB",
			"MG29NU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29S = new AircraftTypeModelCode(
			"Mig-29S",
			"MIG29S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29SD = new AircraftTypeModelCode(
			"Mig-29SD",
			"MG29SD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29SE = new AircraftTypeModelCode(
			"Mig-29SE",
			"MG29SE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29SM = new AircraftTypeModelCode(
			"Mig-29SM",
			"MG29SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_29UB = new AircraftTypeModelCode(
			"Mig-29UB",
			"MG29UB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31_FOXHOUND = new AircraftTypeModelCode(
			"Mig-31 Foxhound",
			"FXH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31_FOXHOUND_A = new AircraftTypeModelCode(
			"Mig-31 Foxhound A",
			"FXHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31B = new AircraftTypeModelCode(
			"Mig-31B",
			"MIG31B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31BS = new AircraftTypeModelCode(
			"Mig-31BS",
			"MG31BS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31D = new AircraftTypeModelCode(
			"Mig-31D",
			"MIG31D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_31M = new AircraftTypeModelCode(
			"Mig-31M",
			"MIG31M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_33 = new AircraftTypeModelCode(
			"Mig-33",
			"MIG33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_35 = new AircraftTypeModelCode(
			"Mig-35",
			"MIG35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_AS = new AircraftTypeModelCode(
			"Mig-AS",
			"MIGAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_AT = new AircraftTypeModelCode(
			"Mig-AT",
			"MIGAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIG_ATS = new AircraftTypeModelCode(
			"Mig-ATS",
			"MIGATS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MILLIROLE_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"Millirole Super Skymaster",
			"MILL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MILTRAINER_VINKA = new AircraftTypeModelCode(
			"Miltrainer Vinka",
			"MILTR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MINI_500 = new AircraftTypeModelCode(
			"Mini-500",
			"MINI50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000 = new AircraftTypeModelCode(
			"Mirage 2000",
			"M2000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000_5 = new AircraftTypeModelCode(
			"Mirage 2000-5",
			"M20005",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000_9 = new AircraftTypeModelCode(
			"Mirage 2000-9",
			"M2009",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000B = new AircraftTypeModelCode(
			"Mirage 2000B",
			"M2000B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000C = new AircraftTypeModelCode(
			"Mirage 2000C",
			"M2000C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000D = new AircraftTypeModelCode(
			"Mirage 2000D",
			"M2000D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000E = new AircraftTypeModelCode(
			"Mirage 2000E",
			"M2000E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000N = new AircraftTypeModelCode(
			"Mirage 2000N",
			"M2000N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000RDI = new AircraftTypeModelCode(
			"Mirage 2000RDI",
			"M2000I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000RDM = new AircraftTypeModelCode(
			"Mirage 2000RDM",
			"M2000M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_2000RDY = new AircraftTypeModelCode(
			"Mirage 2000RDY",
			"M2000Y",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_4000 = new AircraftTypeModelCode(
			"Mirage 4000",
			"M4000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5 = new AircraftTypeModelCode(
			"Mirage 5",
			"MIR5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_50 = new AircraftTypeModelCode(
			"Mirage 50",
			"M50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5000 = new AircraftTypeModelCode(
			"Mirage 5000",
			"M5000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_BA = new AircraftTypeModelCode(
			"Mirage 5-BA",
			"MIR5BA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_BD = new AircraftTypeModelCode(
			"Mirage 5-BD",
			"MIR5BD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_BR = new AircraftTypeModelCode(
			"Mirage 5-BR",
			"MIR5BR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_COA = new AircraftTypeModelCode(
			"Mirage 5-COA",
			"MIR5CA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_COD = new AircraftTypeModelCode(
			"Mirage 5-COD",
			"MIR5CD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_COR = new AircraftTypeModelCode(
			"Mirage 5-COR",
			"MIR5CR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_D = new AircraftTypeModelCode(
			"Mirage 5-D",
			"MIR5D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DAD = new AircraftTypeModelCode(
			"Mirage 5-DAD",
			"MIR5DA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DD = new AircraftTypeModelCode(
			"Mirage 5-DD",
			"MIR5DD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DE = new AircraftTypeModelCode(
			"Mirage 5-DE",
			"MIR5DE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DG = new AircraftTypeModelCode(
			"Mirage 5-DG",
			"MIR5DG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DM = new AircraftTypeModelCode(
			"Mirage 5-DM",
			"MIR5DM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DR = new AircraftTypeModelCode(
			"Mirage 5-DR",
			"MIR5DR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_DV = new AircraftTypeModelCode(
			"Mirage 5-DV",
			"MIR5DV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_E = new AircraftTypeModelCode(
			"Mirage 5-E",
			"MIR5E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_EAD = new AircraftTypeModelCode(
			"Mirage 5-EAD",
			"MIREAD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_F = new AircraftTypeModelCode(
			"Mirage 5-F",
			"MIR5F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_M = new AircraftTypeModelCode(
			"Mirage 5-M",
			"MIR5M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_P = new AircraftTypeModelCode(
			"Mirage 5-P",
			"MIR5P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_PA = new AircraftTypeModelCode(
			"Mirage 5-PA",
			"MIR5PA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_R = new AircraftTypeModelCode(
			"Mirage 5-R",
			"MIR5R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_RAD = new AircraftTypeModelCode(
			"Mirage 5-RAD",
			"MIR5RA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_SDE = new AircraftTypeModelCode(
			"Mirage 5-SDE",
			"MIR5SD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_5_V = new AircraftTypeModelCode(
			"Mirage 5-V",
			"MIR5V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1 = new AircraftTypeModelCode(
			"Mirage F-1",
			"MIRF1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1A = new AircraftTypeModelCode(
			"Mirage F-1A",
			"MIRF1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1B = new AircraftTypeModelCode(
			"Mirage F-1B",
			"MIRF1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1C = new AircraftTypeModelCode(
			"Mirage F-1C",
			"MIRF1C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F1CR = new AircraftTypeModelCode(
			"Mirage F1CR",
			"MF1CR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F1CT = new AircraftTypeModelCode(
			"Mirage F1CT",
			"MF1CT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1D = new AircraftTypeModelCode(
			"Mirage F-1D",
			"MIRF1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1E = new AircraftTypeModelCode(
			"Mirage F-1E",
			"MIRF1E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F1R = new AircraftTypeModelCode(
			"Mirage F1R",
			"MF1R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_F_1R = new AircraftTypeModelCode(
			"Mirage F-1R",
			"MIRF1R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III = new AircraftTypeModelCode(
			"Mirage III",
			"MIR3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_A = new AircraftTypeModelCode(
			"Mirage III-A",
			"MIR3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_AD = new AircraftTypeModelCode(
			"Mirage III-AD",
			"MIR3AD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_BS = new AircraftTypeModelCode(
			"Mirage III-BS",
			"MIR3BS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_BZ = new AircraftTypeModelCode(
			"Mirage III-BZ",
			"MIR3BZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_C = new AircraftTypeModelCode(
			"Mirage III-C",
			"MIR3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_CJR = new AircraftTypeModelCode(
			"Mirage III-CJR",
			"MIR3CJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_CZ = new AircraftTypeModelCode(
			"Mirage III-CZ",
			"MIR3CZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_D = new AircraftTypeModelCode(
			"Mirage III-D",
			"MIR3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_D2Z = new AircraftTypeModelCode(
			"Mirage III-D2Z",
			"MIR3D2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_DO = new AircraftTypeModelCode(
			"Mirage III-DO",
			"MIR3DO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_DZ = new AircraftTypeModelCode(
			"Mirage III-DZ",
			"MIR3DZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_E = new AircraftTypeModelCode(
			"Mirage III-E",
			"MIR3E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EA = new AircraftTypeModelCode(
			"Mirage III-EA",
			"MIR3EA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EBR = new AircraftTypeModelCode(
			"Mirage III-EBR",
			"MIR3EB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EE = new AircraftTypeModelCode(
			"Mirage III-EE",
			"MIR3EE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EL = new AircraftTypeModelCode(
			"Mirage III-EL",
			"MIR3EL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EP = new AircraftTypeModelCode(
			"Mirage III-EP",
			"MIR3EP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EV = new AircraftTypeModelCode(
			"Mirage III-EV",
			"MIR3EV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_EZ = new AircraftTypeModelCode(
			"Mirage III-EZ",
			"MIR3EZ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_O = new AircraftTypeModelCode(
			"Mirage III-O",
			"MIR3O",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_R2Z = new AircraftTypeModelCode(
			"Mirage III-R2Z",
			"MIR3R2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_RP = new AircraftTypeModelCode(
			"Mirage III-RP",
			"MIR3RP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_RS = new AircraftTypeModelCode(
			"Mirage III-RS",
			"MIR3RS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_III_S = new AircraftTypeModelCode(
			"Mirage III-S",
			"MIR3S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_IV = new AircraftTypeModelCode(
			"Mirage IV",
			"MIV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_IV_P = new AircraftTypeModelCode(
			"Mirage IV-P",
			"MIR4P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MIRAGE_V_F = new AircraftTypeModelCode(
			"Mirage V F",
			"M5F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MITSUBISHI_DIAMOND_I_MU_300 = new AircraftTypeModelCode(
			"Mitsubishi Diamond I / MU-300",
			"MU3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MJ_5_SIROCCO = new AircraftTypeModelCode(
			"MJ-5 Sirocco",
			"MJ5SCI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MJ_53_AUTAN = new AircraftTypeModelCode(
			"MJ-53 Autan",
			"MJ53AU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_II_GNAT = new AircraftTypeModelCode(
			"MK II Gnat",
			"GNAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_1_NIMROD = new AircraftTypeModelCode(
			"MK-1 Nimrod",
			"MK1NIM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_1_WSTLD_COMMANDO = new AircraftTypeModelCode(
			"MK-1 Wstld Commando",
			"MK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_2_COMMAND = new AircraftTypeModelCode(
			"MK-2 Command",
			"MK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_2_GNAT = new AircraftTypeModelCode(
			"MK-2 Gnat",
			"MK2GNT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_21_LYNX = new AircraftTypeModelCode(
			"MK-21 Lynx",
			"MK21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_23_LYNX = new AircraftTypeModelCode(
			"MK-23 Lynx",
			"MK23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_25_LYNX_A = new AircraftTypeModelCode(
			"MK-25 Lynx A",
			"MK25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_27_LYNX_B = new AircraftTypeModelCode(
			"MK-27 Lynx B",
			"MK27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_2A_COMMANDO = new AircraftTypeModelCode(
			"MK-2A Commando",
			"MK2ACM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_2A_SEA_KING_AEW = new AircraftTypeModelCode(
			"MK-2A Sea King Aew",
			"MK2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_2C_COMMANDO = new AircraftTypeModelCode(
			"MK-2C Commando",
			"MK2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_3_COMMANDO = new AircraftTypeModelCode(
			"MK-3 Commando",
			"MK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_4_LYNX = new AircraftTypeModelCode(
			"MK-4 Lynx",
			"MK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_41_SEA_KING = new AircraftTypeModelCode(
			"MK-41 Sea King",
			"MK41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_42_SEA_KING = new AircraftTypeModelCode(
			"MK-42 Sea King",
			"MK42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_42A_SEA_KING = new AircraftTypeModelCode(
			"MK-42A Sea King",
			"MK42A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_42B_SEA_KING = new AircraftTypeModelCode(
			"MK-42B Sea King",
			"MK42B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_43_SEA_KING = new AircraftTypeModelCode(
			"MK-43 Sea King",
			"SKM43",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_43B_SEA_KING = new AircraftTypeModelCode(
			"MK-43B Sea King",
			"SKM43B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_45_SEA_KING = new AircraftTypeModelCode(
			"MK-45 Sea King",
			"MK45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_47_SEA_KING = new AircraftTypeModelCode(
			"MK-47 Sea King",
			"MK47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_48_SEA_KING = new AircraftTypeModelCode(
			"MK-48 Sea King",
			"MK48",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_50_SEA_KING = new AircraftTypeModelCode(
			"MK-50 Sea King",
			"MK50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_53_LIGHTNING = new AircraftTypeModelCode(
			"MK-53 Lightning",
			"LIGHT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_8_HUNTER = new AircraftTypeModelCode(
			"MK-8 Hunter",
			"MK8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_8_LYNX = new AircraftTypeModelCode(
			"MK-8 Lynx",
			"LX8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_80_LYNX = new AircraftTypeModelCode(
			"MK-80 Lynx",
			"MK80LX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_80_SEA_KING = new AircraftTypeModelCode(
			"MK-80 Sea King",
			"MK80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_81_LYNX_C = new AircraftTypeModelCode(
			"MK-81 Lynx C",
			"MK81",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_86_LYNX = new AircraftTypeModelCode(
			"MK-86 Lynx",
			"MK86LX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_86_SEA_KING = new AircraftTypeModelCode(
			"MK-86 Sea King",
			"MK86",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_88_LYNX = new AircraftTypeModelCode(
			"MK-88 Lynx",
			"MK88LX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_88_SEA_KING = new AircraftTypeModelCode(
			"MK-88 Sea King",
			"MK88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_89_LYNX = new AircraftTypeModelCode(
			"MK-89 Lynx",
			"MK89",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_8M_HUNTER_SIDDELEY = new AircraftTypeModelCode(
			"MK-8M Hunter Siddeley",
			"HUNT8M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MK_ADV_SEA_KING = new AircraftTypeModelCode(
			"MK-Adv Sea King",
			"MKADV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLLER_M_400_SKYCAR = new AircraftTypeModelCode(
			"Moller M-400 Skycar",
			"MOM400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLNIYA_1 = new AircraftTypeModelCode(
			"Molniya-1",
			"MOL1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLNIYA_100 = new AircraftTypeModelCode(
			"Molniya-100",
			"MOL100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLNIYA_1000 = new AircraftTypeModelCode(
			"Molniya-1000",
			"ML1000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLNIYA_300 = new AircraftTypeModelCode(
			"Molniya-300",
			"MOL300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOLNIYA_400 = new AircraftTypeModelCode(
			"Molniya-400",
			"MOL400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MONGOL_FISHBED = new AircraftTypeModelCode(
			"Mongol Fishbed",
			"MONGOL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MONGOOSE_MANGUSTA = new AircraftTypeModelCode(
			"Mongoose Mangusta",
			"MONGOS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_201_M20J = new AircraftTypeModelCode(
			"Mooney 201/M20J",
			"MO2J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_MARK_10_CADET = new AircraftTypeModelCode(
			"Mooney Mark 10 Cadet",
			"MO10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_MARK_20 = new AircraftTypeModelCode(
			"Mooney Mark 20",
			"MO20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_MARK_21_MOONEY_RANGER = new AircraftTypeModelCode(
			"Mooney Mark 21 / Mooney Ranger",
			"MO21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_MARK_22 = new AircraftTypeModelCode(
			"Mooney Mark 22",
			"MO22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOONEY_TURBO_MOONEY_231_M20K = new AircraftTypeModelCode(
			"Mooney Turbo Mooney 231 / M20K",
			"MO2K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOSS = new AircraftTypeModelCode(
			"Moss",
			"MOSS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MOUJIK_FITTER_A = new AircraftTypeModelCode(
			"Moujik Fitter A",
			"MOUJIK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MR_1_NIMROD = new AircraftTypeModelCode(
			"MR-1 Nimrod",
			"MR1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MR_1_SHACKLETON = new AircraftTypeModelCode(
			"MR-1 Shackleton",
			"MR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MR_2_SHACKLETON = new AircraftTypeModelCode(
			"MR-2 Shackleton",
			"MR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MR_3_SHACKLETON = new AircraftTypeModelCode(
			"MR-3 Shackleton",
			"MR3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MRCA_TORNADO = new AircraftTypeModelCode(
			"MRCA Tornado",
			"TORNAD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MRCA_TORNADO_F_MK_2 = new AircraftTypeModelCode(
			"MRCA Tornado F MK-2",
			"FMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MRCA_TORNADO_F_MK_3 = new AircraftTypeModelCode(
			"MRCA Tornado F MK-3",
			"FMK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MRCA_TORNADO_GR_MK_1 = new AircraftTypeModelCode(
			"MRCA Tornado Gr MK-1",
			"GRMK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MRCA_TORNADO_NAVAL = new AircraftTypeModelCode(
			"MRCA Tornado Naval",
			"MRCAN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MS_760_PARIS = new AircraftTypeModelCode(
			"MS-760 Paris",
			"MS760",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2_MITSUBISHI = new AircraftTypeModelCode(
			"MU-2 Mitsubishi",
			"MU2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2A = new AircraftTypeModelCode(
			"MU-2A",
			"MU2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2B = new AircraftTypeModelCode(
			"MU-2B",
			"MU2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2C = new AircraftTypeModelCode(
			"MU-2C",
			"MU2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2D = new AircraftTypeModelCode(
			"MU-2D",
			"MU2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2E = new AircraftTypeModelCode(
			"MU-2E",
			"MU2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2F = new AircraftTypeModelCode(
			"MU-2F",
			"MU2F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2G = new AircraftTypeModelCode(
			"MU-2G",
			"MU2G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2J_MARQUISE = new AircraftTypeModelCode(
			"MU-2J Marquise",
			"MU2JMQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2J_MITSUBISHI = new AircraftTypeModelCode(
			"MU-2J Mitsubishi",
			"MU2J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2K = new AircraftTypeModelCode(
			"MU-2K",
			"MU2K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MU_2S_MITSUBISHI = new AircraftTypeModelCode(
			"MU-2S Mitsubishi",
			"MU2S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MUSHAK_SUPER = new AircraftTypeModelCode(
			"Mushak Super",
			"MUSH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MUSHSHAK_PROFICIENT = new AircraftTypeModelCode(
			"Mushshak / Proficient",
			"PACMUS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MV_22_OSPREY = new AircraftTypeModelCode(
			"MV-22 Osprey",
			"MV22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MY_104 = new AircraftTypeModelCode(
			"MY-104",
			"MY104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MYSTERE_10 = new AircraftTypeModelCode(
			"Mystere 10",
			"MIST10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MYSTERE_20 = new AircraftTypeModelCode(
			"Mystere 20",
			"MIST20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MYSTERE_50 = new AircraftTypeModelCode(
			"Mystere 50",
			"MIST50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MYSTERE_F_FALCON = new AircraftTypeModelCode(
			"Mystere F Falcon",
			"MYSTF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode MYSTERE_S_SUPER_MYSTERE = new AircraftTypeModelCode(
			"Mystere S Super Mystere",
			"MYSTS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_05 = new AircraftTypeModelCode(
			"N-05",
			"ZEPN05",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_07 = new AircraftTypeModelCode(
			"N-07",
			"ZEPN07",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_2130_LPTN = new AircraftTypeModelCode(
			"N-2130 LPTN",
			"N2130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_22_MISSIONMASTER = new AircraftTypeModelCode(
			"N-22 Missionmaster",
			"N22MIS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_22_NOMAD = new AircraftTypeModelCode(
			"N-22 Nomad",
			"N22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_22A_NOMAD = new AircraftTypeModelCode(
			"N-22A Nomad",
			"N22A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_22B_MISSIONMASTER = new AircraftTypeModelCode(
			"N-22B Missionmaster",
			"N22BMI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_22B_NOMAD = new AircraftTypeModelCode(
			"N-22B Nomad",
			"N22B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_24_SEARCHMASTER = new AircraftTypeModelCode(
			"N-24 Searchmaster",
			"N24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_250_100 = new AircraftTypeModelCode(
			"N-250-100",
			"N25010",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_2501F_NORATLAS = new AircraftTypeModelCode(
			"N-2501F Noratlas",
			"N2501F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_262_FREGATE = new AircraftTypeModelCode(
			"N-262 Fregate",
			"N262",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_262A = new AircraftTypeModelCode(
			"N-262A",
			"N262A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_262B = new AircraftTypeModelCode(
			"N-262B",
			"N262B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_262C_FREGATE = new AircraftTypeModelCode(
			"N-262C Fregate",
			"N262C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_262D_FREGATE = new AircraftTypeModelCode(
			"N-262D Fregate",
			"N262D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_5A = new AircraftTypeModelCode(
			"N-5A",
			"N5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_621_UNIVERSAL = new AircraftTypeModelCode(
			"N-621 Universal",
			"N621",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_821_CARAJA = new AircraftTypeModelCode(
			"N-821 Caraja",
			"N821",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NAC_100 = new AircraftTypeModelCode(
			"NAC-100",
			"NAC100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NAS_332_SUPER_PUMA = new AircraftTypeModelCode(
			"NAS-332 Super Puma",
			"NAS332",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NAVAJO_C_R = new AircraftTypeModelCode(
			"Navajo C/R",
			"PINAVC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NAVION_RANGEMASTER = new AircraftTypeModelCode(
			"Navion Rangemaster",
			"NA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NAVION_TWIN_NAVION = new AircraftTypeModelCode(
			"Navion Twin Navion",
			"NA16",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NBELL_407 = new AircraftTypeModelCode(
			"Nbell-407",
			"NBE407",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NBELL_412 = new AircraftTypeModelCode(
			"Nbell-412",
			"NBE412",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NBELL_430 = new AircraftTypeModelCode(
			"Nbell-430",
			"NBE430",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NBO_105 = new AircraftTypeModelCode(
			"Nbo-105",
			"NBO105",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_130_HERCULES = new AircraftTypeModelCode(
			"NC-130 Hercules",
			"NC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_130A_TEST = new AircraftTypeModelCode(
			"NC-130A Test",
			"NC130A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_130E_TEST = new AircraftTypeModelCode(
			"NC-130e Test",
			"NC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_130H_HERCULES = new AircraftTypeModelCode(
			"NC-130h Hercules",
			"NC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_141A_TEST = new AircraftTypeModelCode(
			"NC-141A Test",
			"NC141A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_212_AVIOCAR = new AircraftTypeModelCode(
			"NC-212 Aviocar",
			"NC212",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_212_100 = new AircraftTypeModelCode(
			"NC-212-100",
			"NC2121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NC_212_200 = new AircraftTypeModelCode(
			"NC-212-200",
			"NC2122",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NCH_46_SEA_KNIGHT = new AircraftTypeModelCode(
			"NCH-46 Sea Knight",
			"NCH46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NEACP_TACOMA_NEACP = new AircraftTypeModelCode(
			"Neacp Tacoma / Neacp",
			"NEACP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NEIVA_REGENTE = new AircraftTypeModelCode(
			"Neiva Regente",
			"NEIVAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NEIVA_UNIVERSAL = new AircraftTypeModelCode(
			"Neiva Universal",
			"NEIVAU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NESHER_DAGGER = new AircraftTypeModelCode(
			"Nesher Dagger",
			"NESHD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NF_4J_PHANTOM_II = new AircraftTypeModelCode(
			"NF-4J Phantom II",
			"NF4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NF_5_FREEDOM_FIGHTER_NORWAY = new AircraftTypeModelCode(
			"NF-5 Freedom Fighter Norway",
			"NF5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NF_5A_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"NF-5A Freedom Fighter",
			"NF5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NF_5B_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"NF-5B Freedom Fighter",
			"NF5B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NH_90_EUROC0PTER = new AircraftTypeModelCode(
			"NH-90 Euroc0pter",
			"NH90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NH_90_NFH = new AircraftTypeModelCode(
			"NH-90 NFH",
			"NH90NF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode N_90_TTH = new AircraftTypeModelCode(
			"N-90 TTH",
			"NH90TT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NHH_2D_SEA_SPRITE = new AircraftTypeModelCode(
			"NHH-2D Sea Sprite",
			"NHH2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NIMROD_2000 = new AircraftTypeModelCode(
			"Nimrod 2000",
			"NIM200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NIMROD_AEW_MK_3 = new AircraftTypeModelCode(
			"Nimrod AEW MK-3",
			"NIMA3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NIMROD_MK_1 = new AircraftTypeModelCode(
			"Nimrod MK-1",
			"NIMR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NIMROD_MR_MK_1 = new AircraftTypeModelCode(
			"Nimrod MR MK-1",
			"NIMMR1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NIMROD_MR_MK_2 = new AircraftTypeModelCode(
			"Nimrod MR MK-2",
			"NIMMR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NKC_135_STRATOTANKER = new AircraftTypeModelCode(
			"NKC-135 Stratotanker",
			"NKC135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NOORDYUN_NORSEMAN_MK_IV = new AircraftTypeModelCode(
			"Noordyun Norseman MK-IV",
			"NY4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NOORDYUN_NORSEMAN_M_V = new AircraftTypeModelCode(
			"Noordyun Norseman M-V",
			"NY5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_626_FREGATE = new AircraftTypeModelCode(
			"Nord 626 Fregate",
			"NRD626",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_MARTINET_NC701_02 = new AircraftTypeModelCode(
			"Nord Martinet Nc701/02",
			"MART",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_2501 = new AircraftTypeModelCode(
			"Nord-2501",
			"ND2501",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_2504 = new AircraftTypeModelCode(
			"Nord-2504",
			"ND2504",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_262 = new AircraftTypeModelCode(
			"Nord-262",
			"NORD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_262C = new AircraftTypeModelCode(
			"Nord-262C",
			"ND262C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_3202 = new AircraftTypeModelCode(
			"Nord-3202",
			"ND3202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NORD_3400 = new AircraftTypeModelCode(
			"Nord-3400",
			"ND3400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NP_3A_ORION = new AircraftTypeModelCode(
			"NP-3A Orion",
			"NP3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NU_1B_OTTER = new AircraftTypeModelCode(
			"NU-1B Otter",
			"NU1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NUH_1E_IROQUOIS = new AircraftTypeModelCode(
			"NUH-1E Iroquois",
			"NUH1E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1_BIRD_DOG = new AircraftTypeModelCode(
			"O-1 Bird Dog",
			"O1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_14_AVIA = new AircraftTypeModelCode(
			"O-14 Avia",
			"O14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1A_BIRD_DOG = new AircraftTypeModelCode(
			"O-1A Bird Dog",
			"O1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1B_BIRD_DOG = new AircraftTypeModelCode(
			"O-1B Bird Dog",
			"O1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1C_BIRD_DOG = new AircraftTypeModelCode(
			"O-1C Bird Dog",
			"O1C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1E_BIRD_DOG = new AircraftTypeModelCode(
			"O-1E Bird Dog",
			"O1E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_1G_BIRD_DOG = new AircraftTypeModelCode(
			"O-1G Bird Dog",
			"O1G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_2_SKYMASTER = new AircraftTypeModelCode(
			"O-2 Skymaster",
			"O2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O2_337_SENTRY = new AircraftTypeModelCode(
			"O2-337 Sentry",
			"O2337S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_29_MAYA = new AircraftTypeModelCode(
			"O-29 Maya",
			"O29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_2A_SKYMASTER = new AircraftTypeModelCode(
			"O-2A Skymaster",
			"O2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode O_2B = new AircraftTypeModelCode(
			"O-2B",
			"O2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OA_10_THUNDERBOLT_II = new AircraftTypeModelCode(
			"OA-10 Thunderbolt II",
			"OA10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OA_10A = new AircraftTypeModelCode(
			"OA-10A",
			"OA010A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OA_37_DRAGONFLY = new AircraftTypeModelCode(
			"OA-37 Dragonfly",
			"OA37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OA_4 = new AircraftTypeModelCode(
			"OA-4",
			"OA4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OA_4M = new AircraftTypeModelCode(
			"OA-4M",
			"OA4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OBSERVER_2 = new AircraftTypeModelCode(
			"Observer 2",
			"OBS2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OC_135B = new AircraftTypeModelCode(
			"OC-135B",
			"OC135B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_1 = new AircraftTypeModelCode(
			"OH-1",
			"OH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13_SIOUX = new AircraftTypeModelCode(
			"OH-13 Sioux",
			"OH13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13G_SIOUX = new AircraftTypeModelCode(
			"OH-13G Sioux",
			"OH13G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13H_SIOUX = new AircraftTypeModelCode(
			"OH-13H Sioux",
			"OH13H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13J_SIOUX = new AircraftTypeModelCode(
			"OH-13J Sioux",
			"OH13J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13K_SIOUX = new AircraftTypeModelCode(
			"OH-13K Sioux",
			"OH13K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_13S_SIOUX = new AircraftTypeModelCode(
			"OH-13S Sioux",
			"OH13S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23_HILLER = new AircraftTypeModelCode(
			"OH-23 Hiller",
			"OH23HL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23_RAVEN = new AircraftTypeModelCode(
			"OH-23 Raven",
			"OH23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23A_RAVEN = new AircraftTypeModelCode(
			"OH-23A Raven",
			"OH23A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23B_RAVEN = new AircraftTypeModelCode(
			"OH-23B Raven",
			"OH23B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23C_RAVEN = new AircraftTypeModelCode(
			"OH-23C Raven",
			"OH23C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23D_RAVEN = new AircraftTypeModelCode(
			"OH-23D Raven",
			"OH23D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23F_RAVEN = new AircraftTypeModelCode(
			"OH-23F Raven",
			"OH23F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_23G_RAVEN = new AircraftTypeModelCode(
			"OH-23G Raven",
			"OH23G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_5_HILLER = new AircraftTypeModelCode(
			"OH-5 Hiller",
			"OH5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58_JETRANGER = new AircraftTypeModelCode(
			"OH-58 Jetranger",
			"OH58JT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58_KIOWA = new AircraftTypeModelCode(
			"OH-58 Kiowa",
			"OH58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58A_COMBAT_SCOUT_OH_58A_KIOWA = new AircraftTypeModelCode(
			"OH-58A Combat Scout / OH-58A Kiowa",
			"OH58A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58B_KIOWA = new AircraftTypeModelCode(
			"OH-58B Kiowa",
			"OH58B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58C_KIOWA = new AircraftTypeModelCode(
			"OH-58C Kiowa",
			"OH58C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58D_COMBAT_SCOUT = new AircraftTypeModelCode(
			"OH-58D Combat Scout",
			"OH58DC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_58D_KIOWA_WARRIOR = new AircraftTypeModelCode(
			"OH-58D Kiowa Warrior",
			"OH58D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_5A_HILLER = new AircraftTypeModelCode(
			"OH-5A Hiller",
			"OH5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6_CAYUSE = new AircraftTypeModelCode(
			"OH-6 Cayuse",
			"OH6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6A_CAYUSE = new AircraftTypeModelCode(
			"OH-6A Cayuse",
			"OH6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6B_CAYUSE = new AircraftTypeModelCode(
			"OH-6B Cayuse",
			"OH6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6C = new AircraftTypeModelCode(
			"OH-6C",
			"OH6C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6D_CAYUSE = new AircraftTypeModelCode(
			"OH-6D Cayuse",
			"OH6D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6DA = new AircraftTypeModelCode(
			"OH-6DA",
			"OH6DA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OH_6J_CAYUSE = new AircraftTypeModelCode(
			"Oh-6J Cayuse",
			"OH6J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OMEGA_2 = new AircraftTypeModelCode(
			"Omega 2",
			"OMEGA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ON_MARK_MARKSMAN_A = new AircraftTypeModelCode(
			"ON Mark Marksman A",
			"A26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ON_MARK_MARKSMAN_B = new AircraftTypeModelCode(
			"ON Mark Marksman B",
			"B26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ONE_ELEVEN_560 = new AircraftTypeModelCode(
			"One-Eleven-560",
			"101156",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ORAO_1 = new AircraftTypeModelCode(
			"Orao 1",
			"ORAO1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ORAO_2 = new AircraftTypeModelCode(
			"Orao 2",
			"ORAO2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ORAO_2_D = new AircraftTypeModelCode(
			"Orao 2-D",
			"ORAO2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OT_47B_CITATION_V = new AircraftTypeModelCode(
			"OT-47B Citation V",
			"OT47B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OURAGAN = new AircraftTypeModelCode(
			"Ouragan",
			"OUR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_1_MOHAWK = new AircraftTypeModelCode(
			"OV-1 Mohawk",
			"OV1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10_BRONCO = new AircraftTypeModelCode(
			"OV-10 Bronco",
			"OV10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10A_BRONCO = new AircraftTypeModelCode(
			"OV-10A Bronco",
			"OV10A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10B_BRONCO = new AircraftTypeModelCode(
			"OV-10B Bronco",
			"OV10B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10C_BRONCO = new AircraftTypeModelCode(
			"OV-10c Bronco",
			"OV10C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10D_BRONCO = new AircraftTypeModelCode(
			"OV-10D Bronco",
			"OV10D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10E_BRONCO = new AircraftTypeModelCode(
			"OV-10E Bronco",
			"OV10E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_10F_BRONCO = new AircraftTypeModelCode(
			"OV-10F Bronco",
			"OV10F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_1A_MOHAWK = new AircraftTypeModelCode(
			"OV-1A Mohawk",
			"OV1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_1B_MOHAWK = new AircraftTypeModelCode(
			"OV-1B Mohawk",
			"OV1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_1C_MOHAWK = new AircraftTypeModelCode(
			"OV-1C Mohawk",
			"OV1C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode OV_1D_D_MOHAWK = new AircraftTypeModelCode(
			"OV-1d\\D Mohawk",
			"OV1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_148_PIAGGIO = new AircraftTypeModelCode(
			"P-148 Piaggio",
			"P148",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_149_PIAGGIO = new AircraftTypeModelCode(
			"P-149 Piaggio",
			"P149",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_149D_PIAGGIO = new AircraftTypeModelCode(
			"P-149D Piaggio",
			"P149D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166_PIAGGIO = new AircraftTypeModelCode(
			"P-166 Piaggio",
			"P166",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166B = new AircraftTypeModelCode(
			"P-166B",
			"P166B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166C = new AircraftTypeModelCode(
			"P-166C",
			"P166C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166_DL2 = new AircraftTypeModelCode(
			"P-166-Dl2",
			"P16DL2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166_DL3 = new AircraftTypeModelCode(
			"P-166-Dl3",
			"P16DL3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166_DL3_MA = new AircraftTypeModelCode(
			"P-166-Dl3-MA",
			"P166D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166_M = new AircraftTypeModelCode(
			"P-166-M",
			"P166M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_166S = new AircraftTypeModelCode(
			"P-166S",
			"P166S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_180_AVANTI = new AircraftTypeModelCode(
			"P-180 Avanti",
			"P180",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2_NEPTUNE = new AircraftTypeModelCode(
			"P-2 Neptune",
			"P2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2E_NEPTUNE = new AircraftTypeModelCode(
			"P-2E Neptune",
			"P2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2F_NEPTUNE = new AircraftTypeModelCode(
			"P-2F Neptune",
			"P2F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2H_NEPTUNE = new AircraftTypeModelCode(
			"P-2H Neptune",
			"P2H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2J_NEPTUNE = new AircraftTypeModelCode(
			"P-2J Neptune",
			"P2J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_2V = new AircraftTypeModelCode(
			"P-2V",
			"P2V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3_SENTINEL = new AircraftTypeModelCode(
			"P-3 Sentinel",
			"P3SEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3A_ORION = new AircraftTypeModelCode(
			"P-3A Orion",
			"P3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3B_ORION = new AircraftTypeModelCode(
			"P-3B Orion",
			"P3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3C_AIP = new AircraftTypeModelCode(
			"P-3C Aip",
			"P3CAIP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3C_ORION = new AircraftTypeModelCode(
			"P-3C Orion",
			"P3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3C1_ORION = new AircraftTypeModelCode(
			"P-3C1 Orion",
			"P3C1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3C2_ORION = new AircraftTypeModelCode(
			"P-3C2 Orion",
			"P3C2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3C3_ORION = new AircraftTypeModelCode(
			"P-3C3 Orion",
			"P3C3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_3CJ = new AircraftTypeModelCode(
			"P-3CJ",
			"P3CJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_51_MUSTANG = new AircraftTypeModelCode(
			"P-51 Mustang",
			"P51",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_55_PARTEAVIA = new AircraftTypeModelCode(
			"P-55 Parteavia",
			"P55A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_68_OBSERVER_2 = new AircraftTypeModelCode(
			"P-68 Observer 2",
			"P68OBS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_68A = new AircraftTypeModelCode(
			"P-68A",
			"P68A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_68B = new AircraftTypeModelCode(
			"P-68B",
			"P68B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_68C = new AircraftTypeModelCode(
			"P-68C",
			"P68C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_68C_TC = new AircraftTypeModelCode(
			"P-68C-TC",
			"P68CTC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_95_EMB_111 = new AircraftTypeModelCode(
			"P-95 / Emb-111",
			"EM111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_95_BANDEIRANTE_MAR = new AircraftTypeModelCode(
			"P-95 Bandeirante Mar",
			"P95MAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode P_95_EMBRACER = new AircraftTypeModelCode(
			"P-95 Embracer",
			"P95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_18_SUPER_CUB = new AircraftTypeModelCode(
			"PA-18 Super Cub",
			"PA18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_200_TORNADO_ADV = new AircraftTypeModelCode(
			"PA-200 Tornado Adv",
			"PA200A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_200_TORNADO_ECR = new AircraftTypeModelCode(
			"PA-200 Tornado Ecr",
			"PA200E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_200_TORNADO_IDS = new AircraftTypeModelCode(
			"PA-200 Tornado Ids",
			"PA200I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_22_PIPER_CUB = new AircraftTypeModelCode(
			"PA-22 Piper Cub",
			"PA22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_23_AZTEC = new AircraftTypeModelCode(
			"PA-23 Aztec",
			"PA23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_24_COMANCHE = new AircraftTypeModelCode(
			"PA-24 Comanche",
			"PA24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_CHEROKEE_WARRIOR_III_PA_28 = new AircraftTypeModelCode(
			"PA-28 Cherokee / Warrior III / PA-28",
			"PA28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_151_WARRIOR = new AircraftTypeModelCode(
			"PA-28-151 Warrior",
			"PA2815",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_161_WARRIOR_III = new AircraftTypeModelCode(
			"PA-28-161 Warrior III",
			"PA2816",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_181_ARCHER_III = new AircraftTypeModelCode(
			"PA-28-181 Archer III",
			"PA2818",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_200_ARCHER_II = new AircraftTypeModelCode(
			"PA-28-200 Archer II",
			"PA2820",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_201_ARROW = new AircraftTypeModelCode(
			"PA-28-201 Arrow",
			"PA2821",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_235_PATHFINDER = new AircraftTypeModelCode(
			"PA-28-235 PAthfinder",
			"PA2823",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_28_236_DAKOTA = new AircraftTypeModelCode(
			"PA-28-236 Dakota",
			"PA2826",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_30_TWIN_COMANCHE = new AircraftTypeModelCode(
			"PA-30 Twin Comanche",
			"PA30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_31_NAVAJO = new AircraftTypeModelCode(
			"PA-31 Navajo",
			"PA31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_31_310_NAVAJO = new AircraftTypeModelCode(
			"PA-31-310 Navajo",
			"PA3131",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_31_350_CHIEFTAIN = new AircraftTypeModelCode(
			"PA-31-350 Chieftain",
			"PA3135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_31T_CHEYENNE = new AircraftTypeModelCode(
			"PA-31T Cheyenne",
			"PA31T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_32 = new AircraftTypeModelCode(
			"PA-32",
			"PA32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_32_301_SARATOGA = new AircraftTypeModelCode(
			"PA-32-301 Saratoga",
			"PA3230",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_34_SENECA = new AircraftTypeModelCode(
			"PA-34 Seneca",
			"PA34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_34_SENECA_II = new AircraftTypeModelCode(
			"PA-34 Seneca II",
			"PA34II",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_34_220T_SENECA_II = new AircraftTypeModelCode(
			"PA-34-220T Seneca II",
			"PA3422",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_38_TOMAHAWK = new AircraftTypeModelCode(
			"PA-38 Tomahawk",
			"PA38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_38_112_TOMAHAWK_II = new AircraftTypeModelCode(
			"PA-38-112 Tomahawk II",
			"PA3811",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_42_1000_CHEYENNE_400 = new AircraftTypeModelCode(
			"PA-42-1000 Cheyenne 400",
			"PA4210",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_42_720_CHEYENNE_IIIA = new AircraftTypeModelCode(
			"PA-42-720 Cheyenne IIIa",
			"PA4272",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_44_180_SEMINOLE = new AircraftTypeModelCode(
			"PA-44-180 Seminole",
			"PA4418",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PA_46_350P_MALIBU_MIRAGE = new AircraftTypeModelCode(
			"PA-46-350P Malibu Mirage",
			"PA4635",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PACKET_FLYING_BOXCAR = new AircraftTypeModelCode(
			"Packet Flying Boxcar",
			"PACK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PAH_2_TIGER = new AircraftTypeModelCode(
			"PAH-2 Tiger",
			"PAH2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PAN_ATLANTIC_CAS = new AircraftTypeModelCode(
			"Pan Atlantic CAS",
			"PANATL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PAN_200_TORNADO_ADV = new AircraftTypeModelCode(
			"Pan-200 Tornado ADV",
			"PN200A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PAN_200_TORNADO_ECR = new AircraftTypeModelCode(
			"Pan-200 Tornado ECR",
			"PN200E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PAN_200_TORNADO_IDS = new AircraftTypeModelCode(
			"Pan-200 Tornado IDS",
			"PN200I",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PASHOSH_TB_20 = new AircraftTypeModelCode(
			"Pashosh / TB-20",
			"TB20PA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_12 = new AircraftTypeModelCode(
			"PC-12",
			"PC12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_12_EAGLE = new AircraftTypeModelCode(
			"PC-12 Eagle",
			"PC12E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_12_45 = new AircraftTypeModelCode(
			"PC-12-45",
			"PC1245",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_6_CHIRICAHUA = new AircraftTypeModelCode(
			"PC-6 Chiricahua",
			"PC6CHR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_6_PORTER = new AircraftTypeModelCode(
			"PC-6 Porter",
			"PC6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_6A_TURBO_PORTER = new AircraftTypeModelCode(
			"PC-6A Turbo Porter",
			"PC6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_6B_PEACEMAKER = new AircraftTypeModelCode(
			"PC-6b Peacemaker",
			"PC6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_6C = new AircraftTypeModelCode(
			"PC-6C",
			"PC6C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_7_MK_II = new AircraftTypeModelCode(
			"PC-7 MK II",
			"PC7MK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_7_PILATUS_TURBO_TRAINER = new AircraftTypeModelCode(
			"PC-7 Pilatus Turbo Trainer",
			"PC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_8_TWIN_PORTER = new AircraftTypeModelCode(
			"PC-8 Twin Porter",
			"PC8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_9_MK_II = new AircraftTypeModelCode(
			"PC-9 MK II",
			"PC9MK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_9_PILATUS = new AircraftTypeModelCode(
			"PC-9 Pilatus",
			"PC9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_9A = new AircraftTypeModelCode(
			"PC-9A",
			"PC9A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PC_9B = new AircraftTypeModelCode(
			"PC-9B",
			"PC9B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PCHELKA_CLOD = new AircraftTypeModelCode(
			"Pchelka Clod",
			"PCHEL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_PIAGGIO = new AircraftTypeModelCode(
			"PD-808 Piaggio",
			"PD808P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_TA = new AircraftTypeModelCode(
			"PD-808 Ta",
			"PD808T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VESPA = new AircraftTypeModelCode(
			"PD-808 Vespa",
			"PD808",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VESPA_EA = new AircraftTypeModelCode(
			"PD-808 Vespa EA",
			"PD808E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VESPA_RADIO = new AircraftTypeModelCode(
			"PD-808 Vespa Radio",
			"PD808R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VESPA_TA = new AircraftTypeModelCode(
			"PD-808 Vespa Ta",
			"PD808A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VESPA_TF = new AircraftTypeModelCode(
			"PD-808 Vespa TF",
			"PD808F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PD_808_VIP = new AircraftTypeModelCode(
			"PD-808 Vip",
			"PD808V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PHANTOM_2000 = new AircraftTypeModelCode(
			"Phantom 2000",
			"F42000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PHANTOM_GF_1 = new AircraftTypeModelCode(
			"Phantom GF-1",
			"GF1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PHANTOM_II_FG_1 = new AircraftTypeModelCode(
			"Phantom II FG-1",
			"FG1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PHANTOM_II_FGR_2 = new AircraftTypeModelCode(
			"Phantom II FGR-2",
			"FGR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIAGGIO_P_136_ROYAL_GULL = new AircraftTypeModelCode(
			"Piaggio P.136 Royal Gull",
			"P136",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PILLAN_AUCAN = new AircraftTypeModelCode(
			"Pillan Aucan",
			"PILL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_AERO_STAR_600_700 = new AircraftTypeModelCode(
			"Piper Aero Star 600/700",
			"PA60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_ARCHER = new AircraftTypeModelCode(
			"Piper Archer",
			"PA29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CHEROKEE_ARROW_IV = new AircraftTypeModelCode(
			"Piper Cherokee Arrow IV",
			"PARO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CHEYENNE_400 = new AircraftTypeModelCode(
			"Piper Cheyenne 400",
			"PA41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CHEYENNE_I_II = new AircraftTypeModelCode(
			"Piper Cheyenne I/II",
			"PAYE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CHEYENNE_III_IV = new AircraftTypeModelCode(
			"Piper Cheyenne III/IV",
			"PA42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CLIPPER = new AircraftTypeModelCode(
			"Piper Clipper",
			"PA16",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CRUISER = new AircraftTypeModelCode(
			"Piper Cruiser",
			"PA5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CUB_SPECIAL = new AircraftTypeModelCode(
			"Piper Cub Special",
			"PA11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_CUB_TRAINER = new AircraftTypeModelCode(
			"Piper Cub Trainer",
			"PA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_FAMILY_CRUISER = new AircraftTypeModelCode(
			"Piper Family Cruiser",
			"PA14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_MALIBU = new AircraftTypeModelCode(
			"Piper Malibu",
			"PA46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_PACER = new AircraftTypeModelCode(
			"Piper Pacer",
			"PA20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_PAWNEE_PA_25_PAWNEE = new AircraftTypeModelCode(
			"Piper Pawnee / PA-25 Pawnee",
			"PA25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_PAWNEE_BRAVE = new AircraftTypeModelCode(
			"Piper Pawnee Brave",
			"PA36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_SEMINOLE = new AircraftTypeModelCode(
			"Piper Seminole",
			"PA44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_SENECA = new AircraftTypeModelCode(
			"Piper Seneca",
			"PIPER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_SUPER_CRUISER = new AircraftTypeModelCode(
			"Piper Super Cruiser",
			"PA12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_T_1040 = new AircraftTypeModelCode(
			"Piper T-1040",
			"PAT1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_VAGABOND = new AircraftTypeModelCode(
			"Piper Vagabond",
			"PA17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIPER_VAGABOND_TRAINER = new AircraftTypeModelCode(
			"Piper Vagabond Trainer",
			"PA15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIRANHA_2C = new AircraftTypeModelCode(
			"Piranha-2C",
			"PIR2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIRANHA_2D = new AircraftTypeModelCode(
			"Piranha-2D",
			"PIR2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIRANHA_4 = new AircraftTypeModelCode(
			"Piranha-4",
			"PIR4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PIRANHA_5 = new AircraftTypeModelCode(
			"Piranha-5",
			"PIR5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PO_2_MULE = new AircraftTypeModelCode(
			"PO-2 Mule",
			"PO2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PS_1_SHIN_MEIWA = new AircraftTypeModelCode(
			"PS-1 Shin Meiwa",
			"PS1SHM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PS_5 = new AircraftTypeModelCode(
			"PS-5",
			"PS5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PT_6_CHUJIAO = new AircraftTypeModelCode(
			"PT-6 Chujiao",
			"PT6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PT_6A_CJ_6A = new AircraftTypeModelCode(
			"PT-6A / CJ-6A",
			"PT6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PUMA_IAR_330L = new AircraftTypeModelCode(
			"Puma / IAR-330L",
			"IAR33L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_106BT_TURBO_KRUK = new AircraftTypeModelCode(
			"PZL 106BT Turbo-Kruk",
			"PZ106T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_130T_TURBO_ORLIK = new AircraftTypeModelCode(
			"PZL 130T Turbo-Orlik",
			"PZ130T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_104_WILGA = new AircraftTypeModelCode(
			"PZL-104 Wilga",
			"PZL104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_105L_FLAMINGO = new AircraftTypeModelCode(
			"PZL-105l Flamingo",
			"PZ105L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_106B_KRUK = new AircraftTypeModelCode(
			"PZL-106B Kruk",
			"PZ106B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_110_KOLIBER_HUMMINGBIRD = new AircraftTypeModelCode(
			"PZL-110 Koliber / Hummingbird",
			"PZL110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_111_KOLIBER_SENIOR_HUMMINGBIRD = new AircraftTypeModelCode(
			"PZL-111 Koliber Senior / Hummingbird",
			"PZL111",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_126_MROWKA = new AircraftTypeModelCode(
			"PZL-126 Mrowka",
			"PZL126",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_130_ORLIK = new AircraftTypeModelCode(
			"PZL-130 Orlik",
			"PZL130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode PZL_230F_SKORPION = new AircraftTypeModelCode(
			"PZL-230f Skorpion",
			"PZL230",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Q_5_FANTAN = new AircraftTypeModelCode(
			"Q-5 Fantan",
			"Q5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QF_4E = new AircraftTypeModelCode(
			"QF-4E",
			"QF004E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QF_4G = new AircraftTypeModelCode(
			"QF-4G",
			"QF004G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QU_22_BONANZA = new AircraftTypeModelCode(
			"QU-22 Bonanza",
			"QU22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QUEEN_AIR_80_BEECH_SEMINOLE = new AircraftTypeModelCode(
			"Queen Air 80 Beech Seminole",
			"BCQU80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QUEEN_AIR_B80 = new AircraftTypeModelCode(
			"Queen Air B80",
			"BEQU80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QUEENAIRE_800 = new AircraftTypeModelCode(
			"Queenaire 800",
			"QU800",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QUEENAIRE_8800 = new AircraftTypeModelCode(
			"Queenaire 8800",
			"QU8800",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode QUIET_TRADER_RJ_115 = new AircraftTypeModelCode(
			"Quiet Trader / RJ-115",
			"RJ115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_1_NIMROD = new AircraftTypeModelCode(
			"R-1 Nimrod",
			"R1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_1180_AIGLON = new AircraftTypeModelCode(
			"R-1180 Aiglon",
			"R1180",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_2160 = new AircraftTypeModelCode(
			"R-2160",
			"R2160",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_22_BETA = new AircraftTypeModelCode(
			"R-22 Beta",
			"ROR22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_235_GUERRIER = new AircraftTypeModelCode(
			"R-235 Guerrier",
			"R235G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_3000_120 = new AircraftTypeModelCode(
			"R-3000-120",
			"R30012",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_3000_140 = new AircraftTypeModelCode(
			"R-3000-140",
			"R30014",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_3000_160 = new AircraftTypeModelCode(
			"R-3000-160",
			"R30016",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_44_ASTRO = new AircraftTypeModelCode(
			"R-44 Astro",
			"ROR44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_50_ROBERT = new AircraftTypeModelCode(
			"R-50 Robert",
			"SAR50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_90_230_RG = new AircraftTypeModelCode(
			"R-90-230 RG",
			"R90230",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_90_420_AT = new AircraftTypeModelCode(
			"R-90-420 AT",
			"R90420",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode R_95 = new AircraftTypeModelCode(
			"R-95",
			"R95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RA_5_VIGILANTE = new AircraftTypeModelCode(
			"RA-5 Vigilante",
			"RA5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RA_7E_INTRUDER = new AircraftTypeModelCode(
			"RA-7E Intruder",
			"RA7E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RAFALE = new AircraftTypeModelCode(
			"Rafale",
			"RAFAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RAFALE_B = new AircraftTypeModelCode(
			"Rafale-B",
			"RAFALB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RAFALE_C = new AircraftTypeModelCode(
			"Rafale-C",
			"RAFALC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RAFALE_M = new AircraftTypeModelCode(
			"Rafale-M",
			"RAFALM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RAH_66_COMANCHE = new AircraftTypeModelCode(
			"RAH-66 Comanche",
			"RAH66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RALLYE_235_GUERRIER = new AircraftTypeModelCode(
			"Rallye-235 Guerrier",
			"RAL235",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RANGER_DASH_7 = new AircraftTypeModelCode(
			"Ranger Dash 7",
			"RANGER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RB_57_CANBERRA = new AircraftTypeModelCode(
			"RB-57 Canberra",
			"RB57",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12_HURON = new AircraftTypeModelCode(
			"RC-12 Huron",
			"RC12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_121_CONSTELLATION = new AircraftTypeModelCode(
			"RC-121 Constellation",
			"RC121",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12D_IMPROVED_GUARDRAIL_V = new AircraftTypeModelCode(
			"RC-12D Improved Guardrail V",
			"RC12DG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12D_SUPER_KING_AIR_200D = new AircraftTypeModelCode(
			"RC-12D Super King Air 200D",
			"RC12DS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12F = new AircraftTypeModelCode(
			"RC-12F",
			"RCI2F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12F_SUPER_KING_AIR_200F = new AircraftTypeModelCode(
			"RC-12F Super King Air 200F",
			"RC12F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12H = new AircraftTypeModelCode(
			"RC-12H",
			"RCI2HS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12H_GUARDRAIL = new AircraftTypeModelCode(
			"RC-12H Guardrail",
			"RC12HG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12H_SUPER_KING_AIR_200H = new AircraftTypeModelCode(
			"RC-12H Super King Air 200H",
			"RC12HS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12K_GUARDRAIL = new AircraftTypeModelCode(
			"RC-12K Guardrail",
			"RC12KG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12K_SUPER_KING_AIR_200K = new AircraftTypeModelCode(
			"RC-12K Super King Air 200K",
			"RC12KS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12M = new AircraftTypeModelCode(
			"RC-12M",
			"RCI2M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_12M_SUPER_KING_AIR_200M = new AircraftTypeModelCode(
			"RC-12M Super King Air 200M",
			"RC12M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_130_HERCULES = new AircraftTypeModelCode(
			"RC-130 Hercules",
			"RC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_130A_HERCULES = new AircraftTypeModelCode(
			"RC-130A Hercules",
			"RC130A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_130E_HERCULES = new AircraftTypeModelCode(
			"RC-130E Hercules",
			"RC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_130H_HERCULES = new AircraftTypeModelCode(
			"RC-130H Hercules",
			"RC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_130S_HERCULES = new AircraftTypeModelCode(
			"RC-130S Hercules",
			"RC130S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135 Stratolifter",
			"RC135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135A_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135A Stratolifter",
			"RC135A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135C_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135C Stratolifter",
			"RC135C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135D_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135D Stratolifter",
			"RC135D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135M_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135M Stratolifter",
			"RC135M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135S_COBRA_BALL = new AircraftTypeModelCode(
			"RC-135S Cobra Ball",
			"RCOBRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135S_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135S Stratolifter",
			"RC135S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135T_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135T Stratolifter",
			"RC135T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135U_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135U Stratolifter",
			"RC135U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135V_RIVET_JOINT = new AircraftTypeModelCode(
			"RC-135V Rivet Joint",
			"RC135V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135W_RIVET_JOINT = new AircraftTypeModelCode(
			"RC-135W Rivet Joint",
			"RC135W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RC_135X_STRATOLIFTER = new AircraftTypeModelCode(
			"RC-135X Stratolifter",
			"RC135X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REBEL = new AircraftTypeModelCode(
			"Rebel",
			"REBEL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REGIONAL_JET_100 = new AircraftTypeModelCode(
			"Regional Jet 100",
			"RJ100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REGIONAL_JET_200 = new AircraftTypeModelCode(
			"Regional Jet 200",
			"RJ200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REGIONAL_JET_700A = new AircraftTypeModelCode(
			"Regional Jet 700A",
			"RJ700A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REGIONAL_JET_700B = new AircraftTypeModelCode(
			"Regional Jet 700B",
			"RJ700B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode REIMS_F406_CARAVAN_II = new AircraftTypeModelCode(
			"Reims F406 Caravan II",
			"F4062",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RENEGADE_II = new AircraftTypeModelCode(
			"Renegade II",
			"MUREN2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RENEGADE_SPIRIT = new AircraftTypeModelCode(
			"Renegade Spirit",
			"MURENS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_104G_STARFIGHTER = new AircraftTypeModelCode(
			"RF-104G Starfighter",
			"RF104G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_111A = new AircraftTypeModelCode(
			"RF-111A",
			"RF111A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_111C = new AircraftTypeModelCode(
			"RF-111C",
			"RF111C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_18_HORNET = new AircraftTypeModelCode(
			"RF-18 Hornet",
			"RF18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_18D_HORNET = new AircraftTypeModelCode(
			"RF-18D Hornet",
			"RF18D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_35_DRAKEN = new AircraftTypeModelCode(
			"RF-35 Draken",
			"RF35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_35XD_DRAKEN = new AircraftTypeModelCode(
			"RF-35XD Draken",
			"RF35XD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4_PHANTOM_II = new AircraftTypeModelCode(
			"RF-4 Phantom II",
			"RF4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_47 = new AircraftTypeModelCode(
			"RF-47",
			"RF47FO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4B_PHANTOM_II = new AircraftTypeModelCode(
			"RF-4B Phantom II",
			"RF4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4C_PHANTOM_II = new AircraftTypeModelCode(
			"RF-4C Phantom II",
			"RF4C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4E_PHANTOM_II = new AircraftTypeModelCode(
			"RF-4E Phantom II",
			"RF4E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4EJ = new AircraftTypeModelCode(
			"RF-4EJ",
			"RF4EJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_4K_PHANTOM_II = new AircraftTypeModelCode(
			"RF-4K Phantom II",
			"RF4K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_5_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"RF-5 Freedom Fighter",
			"RF5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_5_TIGER = new AircraftTypeModelCode(
			"RF-5 Tiger",
			"RF5T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_5A_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"RF-5A Freedom Fighter",
			"RF5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_5E_TIGER_EYE = new AircraftTypeModelCode(
			"RF-5E Tiger Eye",
			"RF5E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_5G = new AircraftTypeModelCode(
			"RF-5G",
			"RF5G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_8_CRUSADER = new AircraftTypeModelCode(
			"RF-8 Crusader",
			"RF8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_84F_THUNDERFLASH = new AircraftTypeModelCode(
			"RF-84F Thunderflash",
			"RF84F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_8A_CRUSADER = new AircraftTypeModelCode(
			"RF-8A Crusader",
			"RF8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_8G_CRUSADER = new AircraftTypeModelCode(
			"RF-8G Crusader",
			"RF8G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RF_9 = new AircraftTypeModelCode(
			"RF-9",
			"RF9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RFB_1000_FANTRAINER = new AircraftTypeModelCode(
			"RFB-1000 Fantrainer",
			"RFB100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RFB_400 = new AircraftTypeModelCode(
			"RFB-400",
			"RFB400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RFB_400_FANTRAINER = new AircraftTypeModelCode(
			"RFB-400 Fantrainer",
			"RF400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RFB_600 = new AircraftTypeModelCode(
			"RFB-600",
			"RFB600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RFB_600_FANTRAINER = new AircraftTypeModelCode(
			"RFB-600 Fantrainer",
			"RF600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RH_1100 = new AircraftTypeModelCode(
			"RH-1100",
			"RH1100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RH_53 = new AircraftTypeModelCode(
			"RH-53",
			"RH53",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RH_53A = new AircraftTypeModelCode(
			"RH-53A",
			"RH53A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RH_53D_SEA_STALLION = new AircraftTypeModelCode(
			"RH-53D Sea Stallion",
			"RH53D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RILEY_EAGLE_21 = new AircraftTypeModelCode(
			"Riley Eagle 21",
			"RY21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RILEY_M65_ROCKET = new AircraftTypeModelCode(
			"Riley M65 / Rocket",
			"RY65",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RILEY_TURBO_EXECUTIVE = new AircraftTypeModelCode(
			"Riley Turbo-Executive",
			"RY40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_1_HAWK = new AircraftTypeModelCode(
			"RJ-1 Hawk",
			"RJ1HK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_1_JASTREB = new AircraftTypeModelCode(
			"RJ-1 Jastreb",
			"RJ1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_110 = new AircraftTypeModelCode(
			"RJ-110",
			"BRJ110",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_115 = new AircraftTypeModelCode(
			"RJ-115",
			"BRJ115",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_70_AVROLINER = new AircraftTypeModelCode(
			"RJ-70 Avroliner",
			"BRJ70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RJ_85 = new AircraftTypeModelCode(
			"RJ-85",
			"BRJ85",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROBIN_100 = new AircraftTypeModelCode(
			"Robin 100",
			"ROB100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROBIN_200 = new AircraftTypeModelCode(
			"Robin 200",
			"ROB200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROBINSON_R22 = new AircraftTypeModelCode(
			"Robinson R22",
			"RH22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_AERO_COMMANDER_112 = new AircraftTypeModelCode(
			"Rockwell Aero Commander 112",
			"AC12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_AIR_CRUISER = new AircraftTypeModelCode(
			"Rockwell Air-Cruiser",
			"AC72",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_112A = new AircraftTypeModelCode(
			"Rockwell Commander 112A",
			"AC2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_112TC = new AircraftTypeModelCode(
			"Rockwell Commander 112TC",
			"AC2T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_114 = new AircraftTypeModelCode(
			"Rockwell Commander 114",
			"AC14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_200 = new AircraftTypeModelCode(
			"Rockwell Commander 200",
			"AC20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_500 = new AircraftTypeModelCode(
			"Rockwell Commander 500",
			"AC50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_520 = new AircraftTypeModelCode(
			"Rockwell Commander 520",
			"AC52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_COMMANDER_JET_PROP_800_900_1000 = new AircraftTypeModelCode(
			"Rockwell Commander Jet Prop 800/900/1000",
			"AC90",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_DARTER_100_150 = new AircraftTypeModelCode(
			"Rockwell Darter 100/150",
			"AC10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_GRAND_COMMANDER_680 = new AircraftTypeModelCode(
			"Rockwell Grand Commander 680",
			"AC60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_JET_COMMANDER = new AircraftTypeModelCode(
			"Rockwell Jet Commander",
			"AC21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_JET_PROP_COMMANDER = new AircraftTypeModelCode(
			"Rockwell Jet Prop Commander",
			"AC69",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_LARK = new AircraftTypeModelCode(
			"Rockwell Lark",
			"LARK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_MITCHELL = new AircraftTypeModelCode(
			"Rockwell Mitchell",
			"B25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_NAVION = new AircraftTypeModelCode(
			"Rockwell Navion",
			"N145",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ROCKWELL_TURBO_COMMANDER = new AircraftTypeModelCode(
			"Rockwell Turbo Commander",
			"AC6T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RORO_162F = new AircraftTypeModelCode(
			"Roro 162F",
			"RO162F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RP_3A_ORION = new AircraftTypeModelCode(
			"RP-3A Orion",
			"RP3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RP_3D_ORION = new AircraftTypeModelCode(
			"RP-3D Orion",
			"RP3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RQ_1A_PREDATOR_UAV = new AircraftTypeModelCode(
			"RQ-1A Predator UAV",
			"RQ1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RQ4_1_FLYING_BOXCAR = new AircraftTypeModelCode(
			"RQ4-1 Flying Boxcar",
			"RQ41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RQ4_2_FLYING_BOXCAR = new AircraftTypeModelCode(
			"RQ4-2 Flying Boxcar",
			"RQ42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RQ_4A_GLOBAL_HAWK_UAV = new AircraftTypeModelCode(
			"RQ-4A Global Hawk UAV",
			"RQ4A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RT_26_XAVANTE = new AircraftTypeModelCode(
			"RT-26 Xavante",
			"RT26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RT_33A_SHOOTING_STAR = new AircraftTypeModelCode(
			"RT-33A Shooting Star",
			"RT33A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RU_21_UTE = new AircraftTypeModelCode(
			"RU-21 UTE",
			"RU21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RU_21J = new AircraftTypeModelCode(
			"RU-21J",
			"RU21J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RU_38A_TWIN_CONDOR = new AircraftTypeModelCode(
			"Ru-38A Twin Condor",
			"RU38A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RUTAN_151_ARES = new AircraftTypeModelCode(
			"Rutan 151 Ares",
			"RUT151",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RUTAN_202_11_BOOMERANG = new AircraftTypeModelCode(
			"Rutan 202-11 Boomerang",
			"RUT202",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RV_1 = new AircraftTypeModelCode(
			"RV-1",
			"RV1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode RV_1D_MOHAWK = new AircraftTypeModelCode(
			"RV-1D Mohawk",
			"RV1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_100B_ARGUS_SAAB_340B = new AircraftTypeModelCode(
			"S-100B Argus / Saab 340B",
			"S100B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_12_E = new AircraftTypeModelCode(
			"S-12-E",
			"S12E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_16_SHEKARI = new AircraftTypeModelCode(
			"S-16 Shekari",
			"S16SHE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S1B2 = new AircraftTypeModelCode(
			"S1B2",
			"S1B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2_BUCCANEER = new AircraftTypeModelCode(
			"S-2 Buccaneer",
			"S2BUC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2_TRACKER = new AircraftTypeModelCode(
			"S-2 Tracker",
			"S2TRK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_208_MARCHETTI = new AircraftTypeModelCode(
			"S-208 Marchetti",
			"S208",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_21 = new AircraftTypeModelCode(
			"S-21",
			"SUS21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_210_CARAVELLE = new AircraftTypeModelCode(
			"S-210 Caravelle",
			"S210",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_210M = new AircraftTypeModelCode(
			"S-210M",
			"S210M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_211_MARCHETTI = new AircraftTypeModelCode(
			"S-211 Marchetti",
			"S211",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_211A_AGUSTA = new AircraftTypeModelCode(
			"S-211A Agusta",
			"S211A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_235_GUERRIER = new AircraftTypeModelCode(
			"S-235 Guerrier",
			"S235",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_235E_GUERRIER = new AircraftTypeModelCode(
			"S-235E Guerrier",
			"S235E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2A_TRACKER = new AircraftTypeModelCode(
			"S-2A Tracker",
			"S2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2C_TRACKER = new AircraftTypeModelCode(
			"S-2C Tracker",
			"S2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2E_TRACKER = new AircraftTypeModelCode(
			"S-2E Tracker",
			"S2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2G_TRACKER = new AircraftTypeModelCode(
			"S-2G Tracker",
			"S2G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2N_TRACKER = new AircraftTypeModelCode(
			"S-2N Tracker",
			"S2N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S2R_G10_VIGILANTE = new AircraftTypeModelCode(
			"S2R-G10 Vigilante",
			"AYS2RG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S2R_T_TURBO_TRUSH = new AircraftTypeModelCode(
			"S2R-T Turbo Trush",
			"S2RT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_2T_TRACKER = new AircraftTypeModelCode(
			"S-2T Tracker",
			"S2T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_312_TUCANO = new AircraftTypeModelCode(
			"S-312 Tucano",
			"S312",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_32 = new AircraftTypeModelCode(
			"S-32",
			"SUS32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_32C_LANSEN = new AircraftTypeModelCode(
			"S-32C Lansen",
			"S32C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_35_DRAKEN = new AircraftTypeModelCode(
			"S-35 Draken",
			"S35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_35E_DRAKEN = new AircraftTypeModelCode(
			"S-35E Draken",
			"S35E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_3A_VIKING = new AircraftTypeModelCode(
			"S-3A Viking",
			"S3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_3B_VIKING = new AircraftTypeModelCode(
			"S-3B Viking",
			"S3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_51_SIKORSKY = new AircraftTypeModelCode(
			"S-51 Sikorsky",
			"SK51",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_52_SIKORSKY = new AircraftTypeModelCode(
			"S-52 Sikorsky",
			"SK52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_54 = new AircraftTypeModelCode(
			"S-54",
			"SUS54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_55_CHIKASAW = new AircraftTypeModelCode(
			"S-55 Chikasaw",
			"S55CHK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_55T_CHIKASAW = new AircraftTypeModelCode(
			"S-55T Chikasaw",
			"S55T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_56_SIKORSKY_MOJAVE = new AircraftTypeModelCode(
			"S-56 Sikorsky Mojave",
			"SK56M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_58_SIKORSKY = new AircraftTypeModelCode(
			"S-58 Sikorsky",
			"S58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_58T_SIKORSKY = new AircraftTypeModelCode(
			"S-58T Sikorsky",
			"S58T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_59_SIKORSKY = new AircraftTypeModelCode(
			"S-59 Sikorsky",
			"SK59",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61_SIKORSKY = new AircraftTypeModelCode(
			"S-61 Sikorsky",
			"S61",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61A_NURI = new AircraftTypeModelCode(
			"S-61A Nuri",
			"S61AN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61A_SIKORSKY = new AircraftTypeModelCode(
			"S-61A Sikorsky",
			"S61A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61L = new AircraftTypeModelCode(
			"S-61L",
			"S61L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61N_SIKORSKY = new AircraftTypeModelCode(
			"S-61N Sikorsky",
			"S61N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_61N1_SILVER = new AircraftTypeModelCode(
			"S-61N1 Silver",
			"S61N1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_62_SIKORSKY = new AircraftTypeModelCode(
			"S-62 Sikorsky",
			"S62",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_62B_SIKORSKY = new AircraftTypeModelCode(
			"S-62B Sikorsky",
			"S62B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_64E_SKY_CRANE = new AircraftTypeModelCode(
			"S-64E Sky Crane",
			"S64E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_65_SEA_STALLION = new AircraftTypeModelCode(
			"S-65 Sea Stallion",
			"S65SEA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_65A_CH_53A_SEA_STALLION = new AircraftTypeModelCode(
			"S-65A / CH-53A Sea Stallion",
			"S65A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_65E_CH_53E_SUPER_STALLION = new AircraftTypeModelCode(
			"S-65E / CH-53E Super Stallion",
			"S65E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70 = new AircraftTypeModelCode(
			"S-70",
			"S70LOG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70_A_1L_DESERT_HAWK = new AircraftTypeModelCode(
			"S-70 A-1l Desert Hawk",
			"S70A1L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70_SIKORSKY = new AircraftTypeModelCode(
			"S-70 Sikorsky",
			"S70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70A_BLACKHAWK = new AircraftTypeModelCode(
			"S-70A Blackhawk",
			"S70A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70B_SEAHAWK = new AircraftTypeModelCode(
			"S-70B Seahawk",
			"S70BS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70B_2_SEAHAWK_RAWS = new AircraftTypeModelCode(
			"S-70B-2 Seahawk Raws",
			"S70B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_70C_M_SEAHAWK = new AircraftTypeModelCode(
			"S-70C M Seahawk",
			"S70C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76_EAGLE = new AircraftTypeModelCode(
			"S-76 Eagle",
			"S76E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76_MARK_II = new AircraftTypeModelCode(
			"S-76 Mark II",
			"S76M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76_SHADOW = new AircraftTypeModelCode(
			"S-76 Shadow",
			"S76S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76_SIKORSKY_SPIRIT = new AircraftTypeModelCode(
			"S-76 Sikorsky Spirit",
			"S76",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76A = new AircraftTypeModelCode(
			"S-76A",
			"S76A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76B = new AircraftTypeModelCode(
			"S-76B",
			"S76B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76C = new AircraftTypeModelCode(
			"S-76C",
			"S76C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_76N = new AircraftTypeModelCode(
			"S-76N",
			"S76N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_80 = new AircraftTypeModelCode(
			"S-80",
			"SUS80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_80E_SEA_DRAGON = new AircraftTypeModelCode(
			"S-80E Sea Dragon",
			"S80E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_80M_SEA_DRAGON = new AircraftTypeModelCode(
			"S-80M Sea Dragon",
			"S80M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_84 = new AircraftTypeModelCode(
			"S-84",
			"SUS84",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_880_RALLYE = new AircraftTypeModelCode(
			"S-880 Rallye",
			"S880",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_890_RALLYE = new AircraftTypeModelCode(
			"S-890 Rallye",
			"S890",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_92_HELIBUS = new AircraftTypeModelCode(
			"S-92 Helibus",
			"S92HB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_92C = new AircraftTypeModelCode(
			"S-92C",
			"S92C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_92U = new AircraftTypeModelCode(
			"S-92U",
			"S92U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode S_986 = new AircraftTypeModelCode(
			"S-986",
			"SUS986",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_227_CC_METRO_23 = new AircraftTypeModelCode(
			"SA 227-CC Metro 23",
			"MET23C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_227_DC_METRO_23 = new AircraftTypeModelCode(
			"SA 227-DC Metro 23",
			"MET23D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_2_37A_SCHWEIZER = new AircraftTypeModelCode(
			"SA 2-37A Schweizer",
			"SA237A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_2_38A = new AircraftTypeModelCode(
			"SA 2-38A",
			"SA238A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_3_BULLDOG = new AircraftTypeModelCode(
			"SA-3 Bulldog",
			"SA3BUL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_3_BULLDOG_T_MK_1 = new AircraftTypeModelCode(
			"SA-3 Bulldog T-MK 1",
			"SA3TMK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_30_GULFJET = new AircraftTypeModelCode(
			"SA-30 Gulfjet",
			"GJSA30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_315_LAMB = new AircraftTypeModelCode(
			"SA-315 Lamb",
			"SA315",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_315B_LAMA_CHEETAH_GAVIAO = new AircraftTypeModelCode(
			"SA-315B Lama / Cheetah / Gaviao",
			"SA315B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_316_ALOUETTE_III = new AircraftTypeModelCode(
			"SA-316 Alouette III",
			"SA316",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_316A_ALOUETTE_III = new AircraftTypeModelCode(
			"SA-316A Alouette III",
			"SA316A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_316B_CHEETAH_III = new AircraftTypeModelCode(
			"SA-316B Cheetah III",
			"SA316B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_318_ALOUETTE_II = new AircraftTypeModelCode(
			"SA-318 Alouette II",
			"SA318",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_318C_ALOUETTE_II = new AircraftTypeModelCode(
			"SA-318C Alouette II",
			"SA318C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_319_ALOUETTE_III = new AircraftTypeModelCode(
			"SA-319 Alouette III",
			"SA319W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_319A_ALOUETTE_III = new AircraftTypeModelCode(
			"SA-319A Alouette III",
			"SA319A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_319B_ALOUETTE_III = new AircraftTypeModelCode(
			"SA-319B Alouette III",
			"SA319B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321 Super Frelon",
			"SA321",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321F_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321F Super Frelon",
			"SA321F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321G_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321G Super Frelon",
			"SA321G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321H_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321H Super Frelon",
			"SA321H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321JA = new AircraftTypeModelCode(
			"SA-321JA",
			"SA321J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321K_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321K Super Frelon",
			"SA321K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321L_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321L Super Frelon",
			"SA321L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_321M_SUPER_FRELON = new AircraftTypeModelCode(
			"SA-321M Super Frelon",
			"SA321M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330_BA_PUMA = new AircraftTypeModelCode(
			"SA-330 BA Puma",
			"SA330B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330_PUMA = new AircraftTypeModelCode(
			"SA-330 Puma",
			"SA330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330E_PUMA = new AircraftTypeModelCode(
			"SA-330E Puma",
			"SA330E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330H_PUMA = new AircraftTypeModelCode(
			"SA-330H Puma",
			"SA330H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330J_PUMA = new AircraftTypeModelCode(
			"SA-330J Puma",
			"SA330J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_330L_PUMA = new AircraftTypeModelCode(
			"SA-330L Puma",
			"SA330L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_332_SUPER_PUMA = new AircraftTypeModelCode(
			"SA-332 Super Puma",
			"SA332",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341_GAZELLE = new AircraftTypeModelCode(
			"SA-341 Gazelle",
			"SA341",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341B_GAZELLE = new AircraftTypeModelCode(
			"SA-341B Gazelle",
			"SA341B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341C_GAZELLE = new AircraftTypeModelCode(
			"SA-341C Gazelle",
			"SA341C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341D_GAZELLE = new AircraftTypeModelCode(
			"SA-341D Gazelle",
			"SA341D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341E = new AircraftTypeModelCode(
			"SA-341E",
			"SA341E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341F_GAZELLE = new AircraftTypeModelCode(
			"SA-341F Gazelle",
			"SA341F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341G_GAZELLE = new AircraftTypeModelCode(
			"SA-341G Gazelle",
			"SA341G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341H_GAZELLE = new AircraftTypeModelCode(
			"SA-341H Gazelle",
			"SA341H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_341M_GAZELLE = new AircraftTypeModelCode(
			"SA-341M Gazelle",
			"SA341M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342_GAZELLE = new AircraftTypeModelCode(
			"SA-342 Gazelle",
			"SA342",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342F_GAZELLE_AATCP = new AircraftTypeModelCode(
			"SA-342F Gazelle Aatcp",
			"SA342A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342G = new AircraftTypeModelCode(
			"SA-342G",
			"SA342G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342J_GAZELLE = new AircraftTypeModelCode(
			"SA-342J Gazelle",
			"SA342J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342K_GAZELLE = new AircraftTypeModelCode(
			"SA-342K Gazelle",
			"SA342K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342L_GAZELLE = new AircraftTypeModelCode(
			"SA-342L Gazelle",
			"SA342L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342M_GAZELLE_HOT = new AircraftTypeModelCode(
			"SA-342M Gazelle Hot",
			"SA342M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_342M_GAZELLE_HOT_VIVIANE = new AircraftTypeModelCode(
			"SA-342M Gazelle Hot / Viviane",
			"SA342V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350_ASTAR = new AircraftTypeModelCode(
			"SA-350 Astar",
			"SA350",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350B_ECUREUIL = new AircraftTypeModelCode(
			"SA-350B Ecureuil",
			"SA350B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350B2 = new AircraftTypeModelCode(
			"SA-350B2",
			"SA35B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350B3 = new AircraftTypeModelCode(
			"SA-350B3",
			"SA35B3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350BA = new AircraftTypeModelCode(
			"SA-350BA",
			"SA35BA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350BB = new AircraftTypeModelCode(
			"SA-350BB",
			"SA36BB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_350E_ECUREUIL = new AircraftTypeModelCode(
			"SA-350E Ecureuil",
			"SA350E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_360_DAUPHIN = new AircraftTypeModelCode(
			"SA-360 Dauphin",
			"SA360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_360C_DAUPHIN = new AircraftTypeModelCode(
			"SA-360C Dauphin",
			"SA360C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_361_DAUPHIN = new AircraftTypeModelCode(
			"SA-361 Dauphin",
			"SA361",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365_DAUPHIN_II = new AircraftTypeModelCode(
			"SA-365 Dauphin II",
			"SA365",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365C_DAUPHIN_II = new AircraftTypeModelCode(
			"SA-365C Dauphin II",
			"SA365C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365F_DAUPHIN_II = new AircraftTypeModelCode(
			"SA-365F Dauphin II",
			"SA365F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365K_PANTHER = new AircraftTypeModelCode(
			"SA-365K Panther",
			"SA365K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365M_PANTHER = new AircraftTypeModelCode(
			"SA-365M Panther",
			"SA365M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365N_DAUPHIN_II = new AircraftTypeModelCode(
			"SA-365N Dauphin II",
			"SA365N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365N2 = new AircraftTypeModelCode(
			"SA-365N2",
			"S365N2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365N3 = new AircraftTypeModelCode(
			"SA-365N3",
			"S365N3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_365S = new AircraftTypeModelCode(
			"SA-365S",
			"SA365S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_366G_DAUPHIN_II = new AircraftTypeModelCode(
			"SA-366G Dauphin II",
			"SA366G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_366G1 = new AircraftTypeModelCode(
			"SA-366G1",
			"S366G1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SA_37_VIGGEN_JA = new AircraftTypeModelCode(
			"SA-37 Viggen Ja",
			"SA37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_32_LANSEN = new AircraftTypeModelCode(
			"Saab 32 Lansen",
			"SB32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_340A = new AircraftTypeModelCode(
			"Saab 340A",
			"SB34A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_340B = new AircraftTypeModelCode(
			"Saab 340B",
			"SB34B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_35_DRAKEN = new AircraftTypeModelCode(
			"Saab 35 Draken",
			"SB35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_35M_DRAKEN = new AircraftTypeModelCode(
			"Saab 35M Draken",
			"SB35M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_35XD = new AircraftTypeModelCode(
			"Saab 35XD",
			"SB35X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_37_VIGGEN = new AircraftTypeModelCode(
			"Saab 37 Viggen",
			"SB37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_37M_VIGGEN = new AircraftTypeModelCode(
			"Saab 37M Viggen",
			"SB37M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_39M_GRIPEN = new AircraftTypeModelCode(
			"Saab 39M Gripen",
			"SB39M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_91_SSAFIR = new AircraftTypeModelCode(
			"Saab 91 Ssafir",
			"SAAB91",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SAAB_35E_DRAKEN = new AircraftTypeModelCode(
			"Saab-35E Draken",
			"SB35E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SABRE_40 = new AircraftTypeModelCode(
			"Sabre 40",
			"RSA40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SABRE_40A = new AircraftTypeModelCode(
			"Sabre 40A",
			"RSA40A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SABRE_60 = new AircraftTypeModelCode(
			"Sabre 60",
			"RSA60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SABRE_75 = new AircraftTypeModelCode(
			"Sabre 75",
			"RSA75",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SABRE_75A = new AircraftTypeModelCode(
			"Sabre 75A",
			"RSA75A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SASS = new AircraftTypeModelCode(
			"Sass",
			"SASS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SB7L_360A_SEEKER = new AircraftTypeModelCode(
			"SB7l-360A Seeker",
			"SB7L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SC_3_BULLDOG = new AircraftTypeModelCode(
			"SC-3 Bulldog",
			"SC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SC_7_SHORTSKYVAN = new AircraftTypeModelCode(
			"SC-7 Shortskyvan",
			"SC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SC_95B_EMB_110P1K = new AircraftTypeModelCode(
			"SC-95b / Emb-110P1K",
			"SC95B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCHWEIZER_269A_300C = new AircraftTypeModelCode(
			"Schweizer 269A / 300C",
			"SC269A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCHWEIZER_300C = new AircraftTypeModelCode(
			"Schweizer 300C",
			"SC300C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCHWEIZER_330_296C = new AircraftTypeModelCode(
			"Schweizer 330 / 296C",
			"SC330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCOTTISH_AVIATION_PIONEER = new AircraftTypeModelCode(
			"Scottish Aviation Pioneer",
			"SCP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCOTTISH_AVIATION_TWIN_PIONEER = new AircraftTypeModelCode(
			"Scottish Aviation Twin Pioneer",
			"SCTP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SCOUT_HUEY_COBRA = new AircraftTypeModelCode(
			"Scout Huey Cobra",
			"SCOUT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SD_27 = new AircraftTypeModelCode(
			"SD-27",
			"SISD27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SE_210_CARAVELLE_12 = new AircraftTypeModelCode(
			"SE-210 Caravelle 12",
			"SE210",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SE_3130_ALOUETTE_II = new AircraftTypeModelCode(
			"SE-3130 Alouette II",
			"SE3130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SE_313B_ALOUETTE_II = new AircraftTypeModelCode(
			"SE-313B Alouette II",
			"SE313B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_COBRA_HUEY_COBRA = new AircraftTypeModelCode(
			"Sea Cobra Huey Cobra",
			"SEACOB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_HARRIER_FA_MK2 = new AircraftTypeModelCode(
			"Sea Harrier FA MK2",
			"SHFMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_HARRIER_FRS_MK_1 = new AircraftTypeModelCode(
			"Sea Harrier FRS MK-1",
			"SHFRM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_HARRIER_FRS_MK_2 = new AircraftTypeModelCode(
			"Sea Harrier FRS MK-2",
			"SHFRM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_HARRIER_FRS_MK_51 = new AircraftTypeModelCode(
			"Sea Harrier FRS MK-51",
			"SHFRM5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_AEW = new AircraftTypeModelCode(
			"Sea King AEW",
			"SKW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_AEW_MK7 = new AircraftTypeModelCode(
			"Sea King AEW MK7",
			"SKAEM7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_ASSAULT = new AircraftTypeModelCode(
			"Sea King Assault",
			"SKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_ASW_SEA_KING_JEZEBEL = new AircraftTypeModelCode(
			"Sea King ASW / Sea King Jezebel",
			"SKJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_HC_MK4 = new AircraftTypeModelCode(
			"Sea King HC MK4",
			"SKHCM4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_MK_48 = new AircraftTypeModelCode(
			"Sea King MK-48",
			"SKMK48",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_KING_MK_50 = new AircraftTypeModelCode(
			"Sea King MK-50",
			"SKMK50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEA_LYNX_MK_88 = new AircraftTypeModelCode(
			"Sea Lynx MK-88",
			"SEALYX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEABAT_CHOCTAW = new AircraftTypeModelCode(
			"Seabat Choctaw",
			"SEABAT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEAGULL_GALEB_G4 = new AircraftTypeModelCode(
			"Seagull Galeb G4",
			"SEAGUL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEARANGER_JETRANGER = new AircraftTypeModelCode(
			"Searanger Jetranger",
			"SEARNG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEASPRITE_S = new AircraftTypeModelCode(
			"Seasprite S",
			"SEASPT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEASTAR_CD2 = new AircraftTypeModelCode(
			"Seastar CD2",
			"SEACD2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEAWOLF = new AircraftTypeModelCode(
			"Seawolf",
			"LASEWO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SENTINEL_F_28F_P = new AircraftTypeModelCode(
			"Sentinel / F-28F-P",
			"ENS28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SENTINEL_1240 = new AircraftTypeModelCode(
			"Sentinel 1240",
			"1240",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SENTINEL_MK_2_FOKKER_50 = new AircraftTypeModelCode(
			"Sentinel MK-2 Fokker 50",
			"SENMK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SENTINEL_ORION = new AircraftTypeModelCode(
			"Sentinel Orion",
			"SEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SEQUOIA_300 = new AircraftTypeModelCode(
			"Sequoia 300",
			"BE300S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260_MARCHETTI = new AircraftTypeModelCode(
			"SF-260 Marchetti",
			"SF260",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260_WARRIOR = new AircraftTypeModelCode(
			"SF-260 Warrior",
			"SF260W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260A_WARRIOR = new AircraftTypeModelCode(
			"SF-260A Warrior",
			"SF260A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260B = new AircraftTypeModelCode(
			"SF-260B",
			"SF260B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260C_WARRIOR = new AircraftTypeModelCode(
			"SF-260C Warrior",
			"SF260C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260D = new AircraftTypeModelCode(
			"SF-260D",
			"SF269D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260F = new AircraftTypeModelCode(
			"SF-260F",
			"SF260F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260M_WARRIOR = new AircraftTypeModelCode(
			"SF-260M Warrior",
			"SF260M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260MZ_WARRIOR = new AircraftTypeModelCode(
			"SF-260MZ Warrior",
			"SF260Z",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260TP = new AircraftTypeModelCode(
			"SF-260TP",
			"SF260T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_260WE = new AircraftTypeModelCode(
			"SF-260WE",
			"SF260E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_340_SAAB_FAIRCHILD = new AircraftTypeModelCode(
			"SF-340 Saab Fairchild",
			"SF340",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_37_VIGGEN = new AircraftTypeModelCode(
			"SF-37 Viggen",
			"SF37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_5_FREEDOM_FIGHTER_SWISS = new AircraftTypeModelCode(
			"SF-5 Freedom Fighter Swiss",
			"SF5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_5A_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"SF-5A Freedom Fighter",
			"SF5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_5B_FREEDOM_FIGHTER = new AircraftTypeModelCode(
			"SF-5B Freedom Fighter",
			"SF5B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_600A_CANGURO = new AircraftTypeModelCode(
			"SF-600A Canguro",
			"SF600A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_600TP = new AircraftTypeModelCode(
			"SF-600TP",
			"SF600T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SF_600TP_CANGURO = new AircraftTypeModelCode(
			"SF-600TP Canguro",
			"SF600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SFA_HARRIER_FRS_MK_1 = new AircraftTypeModelCode(
			"SFA Harrier FRS MK-1",
			"SHARF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_14_LYNX = new AircraftTypeModelCode(
			"SH-14 Lynx",
			"SH14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_14B_LYNX = new AircraftTypeModelCode(
			"SH-14B Lynx",
			"SH14B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_14C_LYNX = new AircraftTypeModelCode(
			"SH-14C Lynx",
			"SH14C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_14D_LYNX = new AircraftTypeModelCode(
			"SH-14D Lynx",
			"SH14D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_2_SEASPRITE = new AircraftTypeModelCode(
			"SH-2 Seasprite",
			"SH2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_2D_SEASPRITE = new AircraftTypeModelCode(
			"SH-2D Seasprite",
			"SH2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_2F_SEASPRITE = new AircraftTypeModelCode(
			"SH-2F Seasprite",
			"SH2F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3_SEA_KING = new AircraftTypeModelCode(
			"SH-3 Sea King",
			"SH3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_34_SEABAT = new AircraftTypeModelCode(
			"SH-34 Seabat",
			"SH34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_34G_SEABAT = new AircraftTypeModelCode(
			"SH-34G Seabat",
			"SH34G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_34J_SEABAT = new AircraftTypeModelCode(
			"SH-34J Seabat",
			"SH34J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_37_VIGGEN = new AircraftTypeModelCode(
			"SH-37 Viggen",
			"SH37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3A_SEA_KING = new AircraftTypeModelCode(
			"SH-3A Sea King",
			"SH3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3D_SEA_KING = new AircraftTypeModelCode(
			"SH-3D Sea King",
			"SH3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3DTS_SEA_KING = new AircraftTypeModelCode(
			"SH-3DTS Sea King",
			"SH3DTS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3G_SEA_KING = new AircraftTypeModelCode(
			"SH-3G Sea King",
			"SH3G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_3H_SEA_KING = new AircraftTypeModelCode(
			"SH-3H Sea King",
			"SH3H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_5 = new AircraftTypeModelCode(
			"SH-5",
			"SH5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_5_HARB_A = new AircraftTypeModelCode(
			"SH-5 Harb A",
			"SH5A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60_SEA_HAWK = new AircraftTypeModelCode(
			"SH-60 Sea Hawk",
			"SH60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60B_SEA_HAWK = new AircraftTypeModelCode(
			"SH-60B Sea Hawk",
			"SH60B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60D_SEA_HAWK = new AircraftTypeModelCode(
			"SH-60D Sea Hawk",
			"SH60D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60F_SEA_HAWK = new AircraftTypeModelCode(
			"SH-60F Sea Hawk",
			"SH60F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60J = new AircraftTypeModelCode(
			"SH-60J",
			"SH60J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SH_60R = new AircraftTypeModelCode(
			"SH-60R",
			"SH60R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHAEW2 = new AircraftTypeModelCode(
			"Shaew2",
			"SHAEW2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHAHBAZ_FALCON = new AircraftTypeModelCode(
			"Shahbaz / Falcon",
			"PACSHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHAMSHER_JAGUAR = new AircraftTypeModelCode(
			"Shamsher Jaguar",
			"HALSHA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHERPA_SUNDOWNER = new AircraftTypeModelCode(
			"Sherpa Sundowner",
			"SHERPA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHOOTING_STAR = new AircraftTypeModelCode(
			"Shooting Star",
			"SHTSTR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHOOTING_STAR_SILVER_STAR = new AircraftTypeModelCode(
			"Shooting Star Silver Star",
			"SLVSTR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORT = new AircraftTypeModelCode(
			"Short",
			"SHD3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORT_MODEL_360 = new AircraftTypeModelCode(
			"Short Model 360",
			"SHD6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_330_SHERPA = new AircraftTypeModelCode(
			"Shorts 330 Sherpa",
			"SHT330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_330_UTT = new AircraftTypeModelCode(
			"Shorts 330 Utt",
			"ST33UT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_330_200 = new AircraftTypeModelCode(
			"Shorts 330-200",
			"ST3320",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_360 = new AircraftTypeModelCode(
			"Shorts 360",
			"ST360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_360_300F = new AircraftTypeModelCode(
			"Shorts 360-300f",
			"ST3630",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SHORTS_SHERPA = new AircraftTypeModelCode(
			"Shorts Sherpa",
			"SHTSHE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SILVAIRE_OBSERVER_LUSCOMBE = new AircraftTypeModelCode(
			"Silvaire Observer / Luscombe",
			"SL8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SJ_30_2 = new AircraftTypeModelCode(
			"SJ 30-2",
			"SJ302",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_1100 = new AircraftTypeModelCode(
			"SK-1100",
			"SK1100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_35C_DRAKEN = new AircraftTypeModelCode(
			"SK-35C Draken",
			"SK35C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_37_VIGGEN = new AircraftTypeModelCode(
			"SK-37 Viggen",
			"SK37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_50_SAFIR = new AircraftTypeModelCode(
			"SK-50 Safir",
			"SK50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_500 = new AircraftTypeModelCode(
			"SK-500",
			"SK500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_55_CHIKASAW = new AircraftTypeModelCode(
			"SK-55 Chikasaw",
			"SK55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_56_MOJAVE = new AircraftTypeModelCode(
			"SK-56 Mojave",
			"SK56",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_58_CHOCTAW = new AircraftTypeModelCode(
			"SK-58 Choctaw",
			"SK58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_60_SAAB_105 = new AircraftTypeModelCode(
			"SK-60 Saab-105",
			"SK60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_61_SEA_KING = new AircraftTypeModelCode(
			"SK-61 Sea King",
			"SK61",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_70_SEA_HAWK = new AircraftTypeModelCode(
			"SK-70 Sea Hawk",
			"SK70",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_700 = new AircraftTypeModelCode(
			"SK-700",
			"SK700",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_700SE = new AircraftTypeModelCode(
			"SK-700SE",
			"SK700S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SK_76_SIKORSKY = new AircraftTypeModelCode(
			"SK-76 Sikorsky",
			"SK71",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKY_SERVANT_DORNIER_28 = new AircraftTypeModelCode(
			"Sky Servant Dornier 28",
			"SKY28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKYFOX = new AircraftTypeModelCode(
			"Skyfox",
			"SKYFOX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKYMASTER_S = new AircraftTypeModelCode(
			"Skymaster S",
			"SKYS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKYROCKET = new AircraftTypeModelCode(
			"Skyrocket",
			"SKYROK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKYSHIP_5000_YEZ_2A = new AircraftTypeModelCode(
			"Skyship 5000 / YEZ-2A",
			"WAI500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SKYSHIP_500HL = new AircraftTypeModelCode(
			"Skyship 500HL",
			"WAI50H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SL_90_LESHII_I_1 = new AircraftTypeModelCode(
			"SL-90 Leshii / I-1",
			"SL90L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SM_92 = new AircraftTypeModelCode(
			"SM-92",
			"SM92",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SM_92P = new AircraftTypeModelCode(
			"SM-92P",
			"SM92P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SM_94 = new AircraftTypeModelCode(
			"SM-94",
			"SM94",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SN_601_CORVETTE = new AircraftTypeModelCode(
			"SN-601 Corvette",
			"SN601",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SOKO_GALEB = new AircraftTypeModelCode(
			"Soko Galeb",
			"SOKOG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SOKO_JASTREB = new AircraftTypeModelCode(
			"Soko Jastreb",
			"SOKOJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SOKO_KRAGUJ = new AircraftTypeModelCode(
			"Soko Kraguj",
			"SOKOK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SOLITAIRE_MARQUISE = new AircraftTypeModelCode(
			"Solitaire Marquise",
			"SOLMRQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SOLOY_BELL_47_SIOUX = new AircraftTypeModelCode(
			"Soloy Bell 47 Sioux",
			"SOL47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SP_2_NEPTUNE = new AircraftTypeModelCode(
			"SP-2 Neptune",
			"SP2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SP_20 = new AircraftTypeModelCode(
			"SP-20",
			"NMSP20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SP_2H_NEPTUNE = new AircraftTypeModelCode(
			"SP-2H Neptune",
			"SP2H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SP_95 = new AircraftTypeModelCode(
			"SP-95",
			"SP95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SPARK_ISKRA = new AircraftTypeModelCode(
			"Spark Iskra",
			"SPK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SPARKA_MAYA = new AircraftTypeModelCode(
			"Sparka Maya",
			"SPKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SPEEDFREIGHTER = new AircraftTypeModelCode(
			"Speedfreighter",
			"SPDFRT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SPEEDTWIN_E2E = new AircraftTypeModelCode(
			"Speedtwin E2E",
			"SPTE2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SPRINT_F_22_R = new AircraftTypeModelCode(
			"Sprint / F-22-R",
			"SPF22R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SR_2500_SUPER_REBEL = new AircraftTypeModelCode(
			"SR-2500 Super Rebel",
			"MUSR25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SR_71_BLACKBIRD = new AircraftTypeModelCode(
			"SR-71 Blackbird",
			"SR71",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SR_71A_BLACKBIRD = new AircraftTypeModelCode(
			"SR-71A Blackbird",
			"SR71A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SR_71B_BLACKBIRD = new AircraftTypeModelCode(
			"SR-71B Blackbird",
			"SR71B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SR_71C = new AircraftTypeModelCode(
			"SR-71C",
			"SR71C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SRA_1_GULFSTREAM_III = new AircraftTypeModelCode(
			"SRA-1 Gulfstream III",
			"SRA1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SRA_4_GULFSTREAM_IV = new AircraftTypeModelCode(
			"SRA-4 Gulfstream IV",
			"SRA4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SRS_3M_SKYVAN = new AircraftTypeModelCode(
			"SRS-3M Skyvan",
			"SKY3M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SS_2A = new AircraftTypeModelCode(
			"SS-2A",
			"SS22A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SSC_CONCORDE = new AircraftTypeModelCode(
			"SSC Concorde",
			"SSCA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SSIC_650_B_650D_PETREL = new AircraftTypeModelCode(
			"SSIC 650 B / 650D Petrel",
			"SSLC65",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ST_1700_CONESTOGA = new AircraftTypeModelCode(
			"ST-1700 Conestoga",
			"ST170",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ST_1700_EVADER = new AircraftTypeModelCode(
			"ST-1700 Evader",
			"ST1700",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ST_1700MD_EVADER = new AircraftTypeModelCode(
			"ST-1700MD Evader",
			"ST17MD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ST_50 = new AircraftTypeModelCode(
			"ST-50",
			"ISST50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STINSON_RELIANT_VULTEE = new AircraftTypeModelCode(
			"Stinson Reliant / Vultee",
			"ST77",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STINSON_VOYAGER_STATION_WAGON_105_108 = new AircraftTypeModelCode(
			"Stinson Voyager / Station Wagon / 105/108",
			"ST75",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STORM_280SI = new AircraftTypeModelCode(
			"Storm 280si",
			"SG28SI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STORM_300 = new AircraftTypeModelCode(
			"Storm 300",
			"SG300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STRATO_1 = new AircraftTypeModelCode(
			"Strato 1",
			"STRAT1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STRATO_2C = new AircraftTypeModelCode(
			"Strato 2C",
			"STRAT2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode STRIZH_T_420A = new AircraftTypeModelCode(
			"Strizh T-420A",
			"T420A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_11_FISHPOT_C = new AircraftTypeModelCode(
			"SU-11 Fishpot-C",
			"SU11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_11U_MAIDEN = new AircraftTypeModelCode(
			"SU-11U Maiden",
			"SU11U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15 = new AircraftTypeModelCode(
			"SU-15",
			"SU15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON = new AircraftTypeModelCode(
			"SU-15 Flagon",
			"FLG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_A = new AircraftTypeModelCode(
			"SU-15 Flagon A",
			"FLGA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_C = new AircraftTypeModelCode(
			"SU-15 Flagon C",
			"FLGC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_D = new AircraftTypeModelCode(
			"SU-15 Flagon D",
			"FLGD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_E = new AircraftTypeModelCode(
			"SU-15 Flagon E",
			"FLGE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_F = new AircraftTypeModelCode(
			"SU-15 Flagon F",
			"FLGF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15_FLAGON_G = new AircraftTypeModelCode(
			"SU-15 Flagon G",
			"FLGG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_15U_FLAGON_G = new AircraftTypeModelCode(
			"SU-15U Flagon G",
			"SU15U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17 = new AircraftTypeModelCode(
			"SU-17",
			"SU17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_SU_20_FITTER_C = new AircraftTypeModelCode(
			"SU-17 / SU-20 Fitter C",
			"FITC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_SU_22_FITTER_H = new AircraftTypeModelCode(
			"SU-17 / SU-22 Fitter H",
			"FITH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_SU_22_FITTER_K = new AircraftTypeModelCode(
			"SU-17 / SU-22 Fitter K",
			"FITK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_SU_22M_FITTER_J = new AircraftTypeModelCode(
			"SU-17 / SU-22M Fitter J",
			"FITJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_SU_22U_FITTER_E = new AircraftTypeModelCode(
			"SU-17 / SU-22U Fitter E",
			"FITE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_FITTER_B = new AircraftTypeModelCode(
			"SU-17 Fitter B",
			"FITB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_FITTER_D = new AircraftTypeModelCode(
			"SU-17 Fitter D",
			"FITD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17_FITTER_G = new AircraftTypeModelCode(
			"SU-17 Fitter G",
			"FITG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17M_FITTER_D = new AircraftTypeModelCode(
			"SU-17M Fitter D",
			"SU17M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17M1_FITTER_H = new AircraftTypeModelCode(
			"SU-17M1 Fitter H",
			"SU17M1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17M2_FITTER_H = new AircraftTypeModelCode(
			"SU-17M2 Fitter H",
			"SU17M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17M3_FITTER_H = new AircraftTypeModelCode(
			"SU-17M3 Fitter H",
			"SU17M3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17M4_FITTER_K = new AircraftTypeModelCode(
			"SU-17M4 Fitter K",
			"SU17M4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17U_FITTER_E = new AircraftTypeModelCode(
			"SU-17U Fitter E",
			"SU17U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_17UM_FITTER_G = new AircraftTypeModelCode(
			"SU-17UM Fitter G",
			"SU17UM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_19 = new AircraftTypeModelCode(
			"SU-19",
			"S19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_20 = new AircraftTypeModelCode(
			"SU-20",
			"SU20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_20M = new AircraftTypeModelCode(
			"SU-20M",
			"SU20M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_20U = new AircraftTypeModelCode(
			"SU-20U",
			"SU20U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22_FITTER = new AircraftTypeModelCode(
			"SU-22 Fitter",
			"SU22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22_FITTER_C = new AircraftTypeModelCode(
			"SU-22 Fitter C",
			"S22C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22_FITTER_F = new AircraftTypeModelCode(
			"SU-22 Fitter F",
			"FITF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22_FITTER_G = new AircraftTypeModelCode(
			"SU-22 Fitter G",
			"SU22G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22BKL = new AircraftTypeModelCode(
			"SU-22BKL",
			"SU22BK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22BM = new AircraftTypeModelCode(
			"SU-22BM",
			"SU22BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22M = new AircraftTypeModelCode(
			"SU-22M",
			"SU22M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22M2_FITTER_H = new AircraftTypeModelCode(
			"SU-22M2 Fitter H",
			"SU22H2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22M2_FITTER_J = new AircraftTypeModelCode(
			"SU-22M2 Fitter J",
			"SU22J2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22M4_FITTER_K = new AircraftTypeModelCode(
			"SU-22M4 Fitter K",
			"SU22M4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_22U = new AircraftTypeModelCode(
			"SU-22U",
			"SU22U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24 = new AircraftTypeModelCode(
			"SU-24",
			"SU24",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER = new AircraftTypeModelCode(
			"SU-24 Fencer",
			"FEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER_A = new AircraftTypeModelCode(
			"SU-24 Fencer A",
			"FENA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER_B = new AircraftTypeModelCode(
			"SU-24 Fencer B",
			"FENB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER_C = new AircraftTypeModelCode(
			"SU-24 Fencer C",
			"FENC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER_D = new AircraftTypeModelCode(
			"SU-24 Fencer D",
			"FEND",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24_FENCER_E = new AircraftTypeModelCode(
			"SU-24 Fencer E",
			"FENE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24M = new AircraftTypeModelCode(
			"SU-24M",
			"SU24M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24MK_FENCER_D = new AircraftTypeModelCode(
			"SU-24MK Fencer D",
			"SU24MK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24MP_FENCER_F = new AircraftTypeModelCode(
			"SU-24MP Fencer F",
			"SU24MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_24MR_FENCER_E = new AircraftTypeModelCode(
			"SU-24MR Fencer E",
			"SU24MR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25 = new AircraftTypeModelCode(
			"SU-25",
			"SU25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25_FROGFOOT = new AircraftTypeModelCode(
			"SU-25 Frogfoot",
			"FRF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25_FROGFOOT_A = new AircraftTypeModelCode(
			"SU-25 Frogfoot A",
			"FRFA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25 Frogfoot B",
			"FRFB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25BM_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25BM Frogfoot B",
			"SU25BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25K_FROGFOOT_A = new AircraftTypeModelCode(
			"SU-25K Frogfoot A",
			"SU25K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25T_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25T Frogfoot B",
			"SU25T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25TK = new AircraftTypeModelCode(
			"SU-25TK",
			"SU25TK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25TM = new AircraftTypeModelCode(
			"SU-25TM",
			"SU25TM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU25UB_FROGFOOT_B = new AircraftTypeModelCode(
			"SU25UB Frogfoot B",
			"SU25UB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25UBK_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25UBK Frogfoot B",
			"SU25UK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25UUT_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25UUT Frogfoot B",
			"SU25UT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_25UTG_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-25UTG Frogfoot B",
			"SU25UG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_26M = new AircraftTypeModelCode(
			"SU-26M",
			"SU26M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27 = new AircraftTypeModelCode(
			"SU-27",
			"SU27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27_FLANKER = new AircraftTypeModelCode(
			"SU-27 Flanker",
			"FLK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27_FLANKER_A = new AircraftTypeModelCode(
			"SU-27 Flanker A",
			"FLKA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27_FLANKER_B = new AircraftTypeModelCode(
			"SU-27 Flanker B",
			"FLKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27_FLANKER_C = new AircraftTypeModelCode(
			"SU-27 Flanker C",
			"FLKC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27IB_SU_34 = new AircraftTypeModelCode(
			"SU-27IB / SU-34",
			"SU27IB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27K_FLANKER_K = new AircraftTypeModelCode(
			"SU-27K Flanker K",
			"SU27K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27LL_PS = new AircraftTypeModelCode(
			"SU-27LL-PS",
			"SU27LL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27M_SU_35 = new AircraftTypeModelCode(
			"SU-27M / SU-35",
			"SU27M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27P = new AircraftTypeModelCode(
			"SU-27P",
			"SU27P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27PD = new AircraftTypeModelCode(
			"SU-27PD",
			"SU27PD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27S = new AircraftTypeModelCode(
			"SU-27S",
			"SU27S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27SMK = new AircraftTypeModelCode(
			"SU-27SMK",
			"SU27SM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_27UB_FLANKER_C = new AircraftTypeModelCode(
			"SU-27UB Flanker C",
			"SU27UB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_28_FROGFOOT_B = new AircraftTypeModelCode(
			"SU-28 Frogfoot B",
			"SU28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_29 = new AircraftTypeModelCode(
			"SU-29",
			"SU29",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_30 = new AircraftTypeModelCode(
			"SU-30",
			"SU30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_30K = new AircraftTypeModelCode(
			"SU-30K",
			"SU30K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_30M = new AircraftTypeModelCode(
			"SU-30M",
			"SU30M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_30MK = new AircraftTypeModelCode(
			"SU-30MK",
			"SU30MK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_30MKI = new AircraftTypeModelCode(
			"SU-30MKI",
			"SU3MKI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_32FN = new AircraftTypeModelCode(
			"SU-32FN",
			"SU32FN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_33_FLANKER_D = new AircraftTypeModelCode(
			"SU-33 Flanker-D",
			"SU33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_34 = new AircraftTypeModelCode(
			"SU-34",
			"SU34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_35 = new AircraftTypeModelCode(
			"SU-35",
			"SU35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_37 = new AircraftTypeModelCode(
			"SU-37",
			"SU37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_38 = new AircraftTypeModelCode(
			"SU-38",
			"SU38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_39 = new AircraftTypeModelCode(
			"SU-39",
			"SU39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_49 = new AircraftTypeModelCode(
			"SU-49",
			"SU49",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7 = new AircraftTypeModelCode(
			"SU-7",
			"SU7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7_SU_17_SU_20_SU_22_FITTER = new AircraftTypeModelCode(
			"SU-7 / SU-17 / SU-20 / SU-22 Fitter",
			"FIT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7_FITTER_A = new AircraftTypeModelCode(
			"SU-7 Fitter A",
			"FITA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7B_FITTER_A = new AircraftTypeModelCode(
			"SU-7B Fitter A",
			"S7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7B_MOUJIK = new AircraftTypeModelCode(
			"SU-7B Moujik",
			"SU7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7BKL = new AircraftTypeModelCode(
			"SU-7BKL",
			"SU7BKL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7BM_FITTER_A = new AircraftTypeModelCode(
			"SU-7BM Fitter A",
			"S7BM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7BMK_FITTER_A = new AircraftTypeModelCode(
			"SU-7BMK Fitter A",
			"SU7BMK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7U = new AircraftTypeModelCode(
			"SU-7U",
			"SU7U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7U_MOUJIK = new AircraftTypeModelCode(
			"SU-7U Moujik",
			"MOU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7UM_FITTER_A = new AircraftTypeModelCode(
			"SU-7UM Fitter A",
			"SU7UM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_7UMK_FITTER_A = new AircraftTypeModelCode(
			"SU-7UMK Fitter A",
			"SU7UMK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_9_FISHPOT = new AircraftTypeModelCode(
			"SU-9 Fishpot",
			"SU9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_9_FISHPOT_B = new AircraftTypeModelCode(
			"SU-9 Fishpot B",
			"S9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SU_9U_MAIDEN = new AircraftTypeModelCode(
			"SU-9U Maiden",
			"SU9U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUMMIT_SENTRY_SUPER_SKYMASTER = new AircraftTypeModelCode(
			"Summit Sentry Super Skymaster",
			"SUMSEN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_ENTENDARD = new AircraftTypeModelCode(
			"Super Entendard",
			"ETENSU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_FRELON = new AircraftTypeModelCode(
			"Super Frelon",
			"FRELON",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_FRELON_Z_8 = new AircraftTypeModelCode(
			"Super Frelon Z-8",
			"Z8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_GALEB_G4 = new AircraftTypeModelCode(
			"Super Galeb G4",
			"SGAL4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_HORNET = new AircraftTypeModelCode(
			"Super Hornet",
			"SUPHOR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_LYNX = new AircraftTypeModelCode(
			"Super Lynx",
			"SULYNX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_MYSTERE_B_2 = new AircraftTypeModelCode(
			"Super Mystere B-2",
			"MYSTB2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_ROCKET = new AircraftTypeModelCode(
			"Super Rocket",
			"SUROK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_SEATA = new AircraftTypeModelCode(
			"Super Seata",
			"SEATA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SUPER_TRANSPORTER = new AircraftTypeModelCode(
			"Super Transporter",
			"SAA300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SW_3_MERLIN_III = new AircraftTypeModelCode(
			"SW-3 Merlin III",
			"SW3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SW_3_MERLIN_IV = new AircraftTypeModelCode(
			"SW-3 Merlin IV",
			"SW3IV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SW_4 = new AircraftTypeModelCode(
			"SW-4",
			"PZLSW4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SW_5 = new AircraftTypeModelCode(
			"SW-5",
			"PZLSW5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SWATI_LT_IIM = new AircraftTypeModelCode(
			"Swati LT-IIM",
			"SWATI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode SWISS_FEDERATE = new AircraftTypeModelCode(
			"Swiss Federate",
			"SWSFED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_MK1_HAWK = new AircraftTypeModelCode(
			"T MK1 Hawk",
			"HTM1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_MK_6_HARRIER = new AircraftTypeModelCode(
			"T MK-6 Harrier",
			"HARTM6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1_BULLDOG = new AircraftTypeModelCode(
			"T-1 Bulldog",
			"T1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1_HAWK = new AircraftTypeModelCode(
			"T-1 Hawk",
			"T1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T1_HAWK_T1_A_HAWK = new AircraftTypeModelCode(
			"T1 Hawk / T1-A Hawk",
			"T11A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1_MITSUBISHI = new AircraftTypeModelCode(
			"T-1 Mitsubishi",
			"TIMIT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_10_HERCULES = new AircraftTypeModelCode(
			"T-10 Hercules",
			"T10HER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_101_GRACH = new AircraftTypeModelCode(
			"T-101 Grach",
			"T101GR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_101E = new AircraftTypeModelCode(
			"T-101E",
			"T101E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_101S = new AircraftTypeModelCode(
			"T-101S",
			"T101S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1020 = new AircraftTypeModelCode(
			"T-1020",
			"PT1020",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1040 = new AircraftTypeModelCode(
			"T-1040",
			"PT1040",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_106 = new AircraftTypeModelCode(
			"T-106",
			"T106",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_11_CACIQUE = new AircraftTypeModelCode(
			"T-11 Cacique",
			"T11CAC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_11_VAMPIRE = new AircraftTypeModelCode(
			"T-11 Vampire",
			"T11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_12_AVIOCAR = new AircraftTypeModelCode(
			"T-12 Aviocar",
			"T12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_130_FREGAT = new AircraftTypeModelCode(
			"T-130 Fregat",
			"T130FR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_134_MUSKETEER = new AircraftTypeModelCode(
			"T-134 Musketeer",
			"T134",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_16_FALCON_50 = new AircraftTypeModelCode(
			"T-16 Falcon 50",
			"T16FAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_17_SUPPORTER = new AircraftTypeModelCode(
			"T-17 Supporter",
			"T17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_18_FALCON_900 = new AircraftTypeModelCode(
			"T-18 Falcon 900",
			"T18FAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_19A_CN_235 = new AircraftTypeModelCode(
			"T-19A / CN-235",
			"T19A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_19B = new AircraftTypeModelCode(
			"T-19B",
			"T19B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1A_JAYHAWK = new AircraftTypeModelCode(
			"T-1A Jayhawk",
			"T1AJAY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_1A_SEASTAR = new AircraftTypeModelCode(
			"T-1A Seastar",
			"T1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2_BUCKEYE = new AircraftTypeModelCode(
			"T-2 Buckeye",
			"T2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2_KAI = new AircraftTypeModelCode(
			"T-2 Kai",
			"T2KAI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2_MITSUBISHI = new AircraftTypeModelCode(
			"T-2 Mitsubishi",
			"T2MIT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_201 = new AircraftTypeModelCode(
			"T-201",
			"T201",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_201_AIST = new AircraftTypeModelCode(
			"T-201 Aist",
			"T201AI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_203_PCHELA = new AircraftTypeModelCode(
			"T-203 Pchela",
			"T203PC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_204_GRIFFON = new AircraftTypeModelCode(
			"T-204 Griffon",
			"T204GR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_205_KARAVAN = new AircraftTypeModelCode(
			"T-205 Karavan",
			"T205KA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_23_UIRAPURU = new AircraftTypeModelCode(
			"T-23 Uirapuru",
			"T23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_25_UNIVERSAL = new AircraftTypeModelCode(
			"T-25 Universal",
			"T25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_25A_NIEVA_UNIVERSAL = new AircraftTypeModelCode(
			"T-25A Nieva Universal",
			"T25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_25B = new AircraftTypeModelCode(
			"T-25B",
			"T25B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_27 = new AircraftTypeModelCode(
			"T-27",
			"T27T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_27_EMB_TUCANO = new AircraftTypeModelCode(
			"T-27 Emb/Tucano",
			"T27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_274_BRIGANTINE = new AircraftTypeModelCode(
			"T-274 Brigantine",
			"T274BR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_274_TITAN = new AircraftTypeModelCode(
			"T-274 Titan",
			"T274TI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_28_TROJAN = new AircraftTypeModelCode(
			"T-28 Trojan",
			"T28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_28A_TROJAN = new AircraftTypeModelCode(
			"T-28A Trojan",
			"T28A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_28B_TROJAN = new AircraftTypeModelCode(
			"T-28B Trojan",
			"T28B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_28C_TROJAN = new AircraftTypeModelCode(
			"T-28C Trojan",
			"T28C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_28D_TROJAN = new AircraftTypeModelCode(
			"T-28D Trojan",
			"T28D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_29_FLYING_CLASSROOM = new AircraftTypeModelCode(
			"T-29 Flying Classroom",
			"T29A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2A_BUCKEYE = new AircraftTypeModelCode(
			"T-2A Buckeye",
			"T2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2B_BUCKEYE = new AircraftTypeModelCode(
			"T-2B Buckeye",
			"T2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2C_BUCKEYE = new AircraftTypeModelCode(
			"T-2C Buckeye",
			"T2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2D_BUCKEYE = new AircraftTypeModelCode(
			"T-2D Buckeye",
			"T2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_2E_BUCKEYE = new AircraftTypeModelCode(
			"T-2E Buckeye",
			"T2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_3_FUJI = new AircraftTypeModelCode(
			"T-3 Fuji",
			"T3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_33_SHOOTING_STAR = new AircraftTypeModelCode(
			"T-33 Shooting Star",
			"T33",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_33A_SHOOTING_STAR_SIVERSTAR = new AircraftTypeModelCode(
			"T-33A Shooting Star / Siverstar",
			"T33A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_33B_SHOOTING_STAR_SIVERSTAR = new AircraftTypeModelCode(
			"T-33B Shooting Star / Siverstar",
			"T33B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_33N_SHOOTING_STAR = new AircraftTypeModelCode(
			"T-33N Shooting Star",
			"T33N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_34_MENTOR = new AircraftTypeModelCode(
			"T-34 Mentor",
			"T34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_34A_MENTOR = new AircraftTypeModelCode(
			"T-34A Mentor",
			"T34A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_34B_MENTOR = new AircraftTypeModelCode(
			"T-34B Mentor",
			"T34B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_34C_MENTOR = new AircraftTypeModelCode(
			"T-34C Mentor",
			"T34C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35_PILLAN = new AircraftTypeModelCode(
			"T-35 Pillan",
			"T35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35A_PILLAN_DEVIL = new AircraftTypeModelCode(
			"T-35A Pillan / Devil",
			"T35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35B = new AircraftTypeModelCode(
			"T-35B",
			"T35B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35C_PILLAN_T_35C_TAMIZ = new AircraftTypeModelCode(
			"T-35C Pillan / T-35C Tamiz",
			"T35C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35D_TURBO_PILLAN = new AircraftTypeModelCode(
			"T-35D Turbo Pillan",
			"T35D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35S = new AircraftTypeModelCode(
			"T-35S",
			"T35S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_35T_AUCAN = new AircraftTypeModelCode(
			"T-35T Aucan",
			"T35T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_36_HALCON_C_101BB = new AircraftTypeModelCode(
			"T-36 Halcon C-101BB",
			"T36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_37 = new AircraftTypeModelCode(
			"T-37",
			"T37",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_37_TWEET = new AircraftTypeModelCode(
			"T-37 Tweet",
			"T37T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_37A_TWEET = new AircraftTypeModelCode(
			"T-37A Tweet",
			"T37A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_37B = new AircraftTypeModelCode(
			"T-37B",
			"T37B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_37C = new AircraftTypeModelCode(
			"T-37C",
			"T37C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_38_TALON = new AircraftTypeModelCode(
			"T-38 Talon",
			"T38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_38A_TALON = new AircraftTypeModelCode(
			"T-38A Talon",
			"T38A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_38B_TALON = new AircraftTypeModelCode(
			"T-38B Talon",
			"T38B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_38D_TALON = new AircraftTypeModelCode(
			"T-38D Talon",
			"T38D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_39_SABERLINER = new AircraftTypeModelCode(
			"T-39 Saberliner",
			"T39",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_39A_SABERLINER = new AircraftTypeModelCode(
			"T-39A Saberliner",
			"T39A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_39B_SABERLINER = new AircraftTypeModelCode(
			"T-39B Saberliner",
			"T39B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_39D_SABERLINER = new AircraftTypeModelCode(
			"T-39D Saberliner",
			"T39D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_39F_SABERLINER = new AircraftTypeModelCode(
			"T-39F Saberliner",
			"T39F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_3A_FIREFLY = new AircraftTypeModelCode(
			"T-3A Firefly",
			"T67M26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_4_KAWASAKI = new AircraftTypeModelCode(
			"T-4 Kawasaki",
			"T4KAWA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_4_SHACKLETON = new AircraftTypeModelCode(
			"T-4 Shackleton",
			"T4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_400_BEECHJET = new AircraftTypeModelCode(
			"T-400 Beechjet",
			"BJT400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_401_SOKOL = new AircraftTypeModelCode(
			"T-401 Sokol",
			"T401SO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_407_SKVORETS = new AircraftTypeModelCode(
			"T-407 Skvorets",
			"T407SK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41_MESCALERO = new AircraftTypeModelCode(
			"T-41 Mescalero",
			"T41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_411_AIST_2 = new AircraftTypeModelCode(
			"T-411 Aist-2",
			"T411AI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_411_WOLVERINE = new AircraftTypeModelCode(
			"T-411 Wolverine",
			"T411WO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_417_PEGASUS = new AircraftTypeModelCode(
			"T-417 Pegasus",
			"T417PE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41A = new AircraftTypeModelCode(
			"T-41A",
			"CET41A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41A_MESCALERO = new AircraftTypeModelCode(
			"T-41A Mescalero",
			"T41A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41B = new AircraftTypeModelCode(
			"T-41B",
			"CET41B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41B_MESCALERO = new AircraftTypeModelCode(
			"T-41B Mescalero",
			"T41B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41D = new AircraftTypeModelCode(
			"T-41D",
			"CET41D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_41D_MESCALERO = new AircraftTypeModelCode(
			"T-41D Mescalero",
			"T41D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_42_COCHISE = new AircraftTypeModelCode(
			"T-42 Cochise",
			"T42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_420_STRIZH = new AircraftTypeModelCode(
			"T-420 Strizh",
			"T420ST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_420CL_STRIZH = new AircraftTypeModelCode(
			"T-420CL Strizh",
			"T420CL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_422_YASREB_HAWK_T_422 = new AircraftTypeModelCode(
			"T-422 Yasreb / Hawk / T-422",
			"T422YA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_42A = new AircraftTypeModelCode(
			"T-42A",
			"BCT42A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_42A_COCHISE = new AircraftTypeModelCode(
			"T-42A Cochise",
			"T42A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_42B = new AircraftTypeModelCode(
			"T-42B",
			"BCT42B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_42B_COCHISE = new AircraftTypeModelCode(
			"T-42B Cochise",
			"T42B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_43 = new AircraftTypeModelCode(
			"T-43",
			"T43",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_430_SPRINTER = new AircraftTypeModelCode(
			"T-430 Sprinter",
			"T430SP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_433_FLAMINGO = new AircraftTypeModelCode(
			"T-433 Flamingo",
			"T433FL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_43A = new AircraftTypeModelCode(
			"T-43A",
			"T43A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_44_BEECH_KING = new AircraftTypeModelCode(
			"T-44 Beech King",
			"T44",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_44_KINGAIR = new AircraftTypeModelCode(
			"T-44 Kingair",
			"T44K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_45_GOSHAWK = new AircraftTypeModelCode(
			"T-45 Goshawk",
			"T45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_45_TURBO_DROMADER = new AircraftTypeModelCode(
			"T-45 Turbo Dromader",
			"PZLT45",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_45A_GOSHAWK = new AircraftTypeModelCode(
			"T-45A Goshawk",
			"T45A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_45B_GOSHAWK = new AircraftTypeModelCode(
			"T-45B Goshawk",
			"T45B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_45TS_GOSHAWK = new AircraftTypeModelCode(
			"T-45TS Goshawk",
			"T45TS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_47_CITATION = new AircraftTypeModelCode(
			"T-47 Citation",
			"T47",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_471_CORVETTE = new AircraftTypeModelCode(
			"T-471 Corvette",
			"T471",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_47A_CITATION_II = new AircraftTypeModelCode(
			"T-47A Citation II",
			"T47A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_47A_CITATION_S_II = new AircraftTypeModelCode(
			"T-47A Citation S/II",
			"CET47A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_5_FUJI_KM_2 = new AircraftTypeModelCode(
			"T-5 Fuji KM 2",
			"T5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_501_STRIZH = new AircraftTypeModelCode(
			"T-501 Strizh",
			"T501",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_6_TEXAN_HARVARDSON = new AircraftTypeModelCode(
			"T-6 Texan / Harvardson",
			"T6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_610_CALL = new AircraftTypeModelCode(
			"T-610 Call",
			"T610",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_610_VOYAGE = new AircraftTypeModelCode(
			"T-610 Voyage",
			"T610VO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_66_HUNTER = new AircraftTypeModelCode(
			"T-66 Hunter",
			"T66",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_67_FIREFLY = new AircraftTypeModelCode(
			"T-67 Firefly",
			"T67",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_67B = new AircraftTypeModelCode(
			"T-67B",
			"T67B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_67C = new AircraftTypeModelCode(
			"T-67C",
			"T67C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_67M_FIREFLY = new AircraftTypeModelCode(
			"T-67M Firefly",
			"T67M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_67M_MK_II_FIREFLY = new AircraftTypeModelCode(
			"T-67M MK II Firefly",
			"T67MM2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T67M200 = new AircraftTypeModelCode(
			"T67M200",
			"T67M20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_6G_TEXAN = new AircraftTypeModelCode(
			"T-6G Texan",
			"T6G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_9_CARIBOU = new AircraftTypeModelCode(
			"T-9 Caribou",
			"T9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_9_STALKER = new AircraftTypeModelCode(
			"T-9 Stalker",
			"T9STO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_910_KURYER = new AircraftTypeModelCode(
			"T-910 Kuryer",
			"T910KU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_16_SEAFIRE = new AircraftTypeModelCode(
			"TA-16 Seafire",
			"TA16SF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_3B = new AircraftTypeModelCode(
			"TA-3B",
			"TA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4_SKYHAWK = new AircraftTypeModelCode(
			"TA-4 Skyhawk",
			"TA4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4B_SKYHAWK = new AircraftTypeModelCode(
			"TA-4B Skyhawk",
			"TA4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4F_SKYHAWK = new AircraftTypeModelCode(
			"TA-4F Skyhawk",
			"TA4F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4G_SKYHAWK = new AircraftTypeModelCode(
			"TA-4G Skyhawk",
			"TA4G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4H_SKYHAWK = new AircraftTypeModelCode(
			"TA-4H Skyhawk",
			"TA4H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4J_SKYHAWK = new AircraftTypeModelCode(
			"TA-4J Skyhawk",
			"TA4J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4K_SKYHAWK = new AircraftTypeModelCode(
			"TA-4K Skyhawk",
			"TA4K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4KU_SKYHAWK = new AircraftTypeModelCode(
			"Ta-4KU Skyhawk",
			"TA4KU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4M_SKYHAWK = new AircraftTypeModelCode(
			"TA-4M Skyhawk",
			"TA4M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_4S = new AircraftTypeModelCode(
			"TA-4S",
			"TA4S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_7_CORSAIR_II = new AircraftTypeModelCode(
			"TA-7 Corsair II",
			"TA7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_7C_CORSAIR_II = new AircraftTypeModelCode(
			"TA-7C Corsair II",
			"TA7C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_7H_CORSAIR_II = new AircraftTypeModelCode(
			"TA-7H Corsair II",
			"TA7H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TA_7P_CORSAIR_II = new AircraftTypeModelCode(
			"TA-7P Corsair II",
			"TA7P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_AGM_23 = new AircraftTypeModelCode(
			"T-AGM-23",
			"TAGM23",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAV_8_HARRIER = new AircraftTypeModelCode(
			"TAV-8 Harrier",
			"TAV8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAV_8A_HARRIER = new AircraftTypeModelCode(
			"TAV-8A Harrier",
			"TAV8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAV_8B_HARRIER = new AircraftTypeModelCode(
			"TAV-8B Harrier",
			"TAV8B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAV_8S_HARRIER = new AircraftTypeModelCode(
			"TAV-8S Harrier",
			"TAV8S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAYLORCRAFT_F_15A_TOURIST = new AircraftTypeModelCode(
			"Taylorcraft F-15A Tourist",
			"TC15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAYLORCRAFT_F_19_SPORTS_MAN_100 = new AircraftTypeModelCode(
			"Taylorcraft F-19 Sports-Man 100",
			"TC19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TAYLORCRAFT_F_20A_TOPPER = new AircraftTypeModelCode(
			"Taylorcraft F-20A Topper",
			"TC20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_200_TOBAGO_XL = new AircraftTypeModelCode(
			"TB-200 Tobago Xl",
			"TB200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_30_EPSILON = new AircraftTypeModelCode(
			"TB-30 Epsilon",
			"TB30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_31_OMEGA = new AircraftTypeModelCode(
			"TB-31 Omega",
			"TB31",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_360_TANGARA = new AircraftTypeModelCode(
			"TB-360 Tangara",
			"TB360",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_60000_SAROHALE = new AircraftTypeModelCode(
			"TB-60000 Sarohale",
			"TB6000",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TB_9_TAMPICO_CLUB = new AircraftTypeModelCode(
			"TB-9 Tampico Club",
			"TB9TC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TBM_700 = new AircraftTypeModelCode(
			"TBM-700",
			"TBM700",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_130_HERCULES = new AircraftTypeModelCode(
			"TC-130 Hercules",
			"TC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_130G_HERCULES = new AircraftTypeModelCode(
			"TC-130G Hercules",
			"TC130G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_130Q_HERCULES = new AircraftTypeModelCode(
			"TC-130Q Hercules",
			"TC130Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_135S = new AircraftTypeModelCode(
			"TC-135S",
			"TC135S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_135W = new AircraftTypeModelCode(
			"TC-135W",
			"TC135W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_18E = new AircraftTypeModelCode(
			"TC-18E",
			"TC018E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_18F = new AircraftTypeModelCode(
			"TC-18F",
			"TC18F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_3_TSE_CHANG = new AircraftTypeModelCode(
			"TC-3 TSE Chang",
			"TC3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_4B_GULFSTREAM = new AircraftTypeModelCode(
			"TC-4B Gulfstream",
			"TC4B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_4C_ACADEME = new AircraftTypeModelCode(
			"TC-4C Academe",
			"TC4CA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TC_4C_GULFSTREAM = new AircraftTypeModelCode(
			"TC-4C Gulfstream",
			"TC4C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode T_CH_1_CHUNG_CHENG = new AircraftTypeModelCode(
			"T-CH-1 Chung Cheng",
			"TCH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TCHAIKA_MAIL = new AircraftTypeModelCode(
			"Tchaika Mail",
			"TCHAI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TE_2_HAWKEYE = new AircraftTypeModelCode(
			"TE-2 Hawkeye",
			"TE2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TE_2A_HAWKEYE = new AircraftTypeModelCode(
			"TE-2A Hawkeye",
			"TE2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TE_2C_HAWKEYE = new AircraftTypeModelCode(
			"TE-2C Hawkeye",
			"TE2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TED_SMITH_AERO_STAR = new AircraftTypeModelCode(
			"Ted Smith Aero Star",
			"TS60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_102A = new AircraftTypeModelCode(
			"TF-102A",
			"TF1O2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_102A_DELTA_DAGGER = new AircraftTypeModelCode(
			"TF-102A Delta Dagger",
			"TF102A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_104_STARFIGHTER = new AircraftTypeModelCode(
			"TF-104 Starfighter",
			"TF104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_104G_STARFIGHTER = new AircraftTypeModelCode(
			"TF-104G Starfighter",
			"TF104G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_15_EAGLE = new AircraftTypeModelCode(
			"TF-15 Eagle",
			"TF15",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_16N_FIGHTING_FALCON = new AircraftTypeModelCode(
			"TF-16N Fighting Falcon",
			"TF16N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_18_HORNET = new AircraftTypeModelCode(
			"TF-18 Hornet",
			"TF18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_18A_HORNET = new AircraftTypeModelCode(
			"TF-18A Hornet",
			"TF18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_35_DRAKEN = new AircraftTypeModelCode(
			"TF-35 Draken",
			"TF35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TF_35XD_DRAKEN = new AircraftTypeModelCode(
			"TF-35XD Draken",
			"TF35XD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TG_10 = new AircraftTypeModelCode(
			"TG-10",
			"TG10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TG_1X = new AircraftTypeModelCode(
			"TG-1X",
			"TG1X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_1_IROQUOIS = new AircraftTypeModelCode(
			"TH-1 Iroquois",
			"TH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_13_SIOUX = new AircraftTypeModelCode(
			"TH-13 Sioux",
			"TH13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_13M_SIOUX = new AircraftTypeModelCode(
			"TH-13M Sioux",
			"TH13M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_13S_SIOUX = new AircraftTypeModelCode(
			"TH-13S Sioux",
			"TH13S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_13T_SIOUX = new AircraftTypeModelCode(
			"TH-13T Sioux",
			"TH13T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_1F_IROQUOIS = new AircraftTypeModelCode(
			"TH-1F Iroquois",
			"TH1F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_1G_HUEY_COBRA = new AircraftTypeModelCode(
			"TH-1G Huey Cobra",
			"TH1G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_1L_IROQUOIS = new AircraftTypeModelCode(
			"TH-1L Iroquois",
			"TH1L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_1S_NIGHT_STALKER = new AircraftTypeModelCode(
			"TH-1S Night Stalker",
			"TH1S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_206 = new AircraftTypeModelCode(
			"TH-206",
			"TH206",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_28 = new AircraftTypeModelCode(
			"TH-28",
			"ENTH28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_50_ESQUILO = new AircraftTypeModelCode(
			"TH-50 Esquilo",
			"TH50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_53A = new AircraftTypeModelCode(
			"TH-53A",
			"TH053A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_55_OSAGE = new AircraftTypeModelCode(
			"TH-55 Osage",
			"TH55",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_55A_OSAGE = new AircraftTypeModelCode(
			"TH-55A Osage",
			"TH55A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_55J_OSAGE = new AircraftTypeModelCode(
			"TH-55J Osage",
			"TH55J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_57_JETRANGER = new AircraftTypeModelCode(
			"TH-57 Jetranger",
			"H57",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_57_SEA_RANGER = new AircraftTypeModelCode(
			"TH-57 Sea Ranger",
			"TH57",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_57A_SEA_RANGER = new AircraftTypeModelCode(
			"TH-57A Sea Ranger",
			"TH57A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_57B_SEA_RANGER = new AircraftTypeModelCode(
			"TH-57B Sea Ranger",
			"TH57B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_57C_SEA_RANGER = new AircraftTypeModelCode(
			"TH-57C Sea Ranger",
			"TH57C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TH_67_CREEK = new AircraftTypeModelCode(
			"TH-67 Creek",
			"TH67",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TK_10_HERCULES = new AircraftTypeModelCode(
			"TK-10 Hercules",
			"TK10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TL_10_HERCULES = new AircraftTypeModelCode(
			"TL-10 Hercules",
			"TL10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TLS_M_20M = new AircraftTypeModelCode(
			"TLS M-20M",
			"MOM2M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TMK_4_SEA_HARRIER = new AircraftTypeModelCode(
			"TMK-4 Sea Harrier",
			"SHTM4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_ADV = new AircraftTypeModelCode(
			"Tornado ADV",
			"TORA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_ECR = new AircraftTypeModelCode(
			"Tornado ECR",
			"TORE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_GR_MK1 = new AircraftTypeModelCode(
			"Tornado GR MK1",
			"TORGMK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_IDS = new AircraftTypeModelCode(
			"Tornado IDS",
			"TORI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_PA_200 = new AircraftTypeModelCode(
			"Tornado PA-200",
			"MRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TORNADO_RECCE = new AircraftTypeModelCode(
			"Tornado Recce",
			"TORR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TOUCAN_TUCANO = new AircraftTypeModelCode(
			"Toucan Tucano",
			"TOUCAN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_100_SAAB_340B = new AircraftTypeModelCode(
			"TP-100 Saab / 340B",
			"TP100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_101_KING_AIR_B200 = new AircraftTypeModelCode(
			"TP-101 / King Air B200",
			"TP101",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_102_SRA_4 = new AircraftTypeModelCode(
			"TP-102 / SRA-4",
			"TP102",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_400_MALIBU = new AircraftTypeModelCode(
			"TP-400 Malibu",
			"TP400",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_600 = new AircraftTypeModelCode(
			"TP-600",
			"TP600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_84_HERCULES = new AircraftTypeModelCode(
			"TP-84 Hercules",
			"TP84",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_88_METRO = new AircraftTypeModelCode(
			"TP-88 Metro",
			"TP88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_88_METRO_III = new AircraftTypeModelCode(
			"TP-88 Metro III",
			"TP883",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TP_89_CASA = new AircraftTypeModelCode(
			"TP-89 Casa",
			"TP89",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TR_1 = new AircraftTypeModelCode(
			"TR-1",
			"TR1REC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TR_1_DRAGONLADY = new AircraftTypeModelCode(
			"TR-1 Dragonlady",
			"TR1DRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TR_1_TRIGULL = new AircraftTypeModelCode(
			"TR-1 TRigull",
			"TR1TRI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TR_1A_TRIGULL = new AircraftTypeModelCode(
			"TR-1A TRigull",
			"TR1ATR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TR_1B_LOCKHEED = new AircraftTypeModelCode(
			"TR-1B Lockheed",
			"TR1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRANSALL_ALIZE = new AircraftTypeModelCode(
			"Transall Alize",
			"TRAN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRIDENT_2E = new AircraftTypeModelCode(
			"Trident 2E",
			"TRID2E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRIDENT_3B = new AircraftTypeModelCode(
			"Trident 3B",
			"TRI3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRISTAR_500 = new AircraftTypeModelCode(
			"Tristar 500",
			"TRI500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRISTAR_C2 = new AircraftTypeModelCode(
			"Tristar C2",
			"TRIC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRISTAR_K1 = new AircraftTypeModelCode(
			"Tristar K1",
			"TRIK1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRISTAR_KC1 = new AircraftTypeModelCode(
			"Tristar KC1",
			"TRIKC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRISTARC2A = new AircraftTypeModelCode(
			"Tristarc2A",
			"TRIC2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRITON_300 = new AircraftTypeModelCode(
			"Triton 300",
			"TRI300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TROOPER_SIOUX = new AircraftTypeModelCode(
			"Trooper Sioux",
			"TROOP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TRU_145M_LK_2 = new AircraftTypeModelCode(
			"TRU-145M-LK-2",
			"TU154L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TS_11_ISKRA = new AircraftTypeModelCode(
			"TS-11 Iskra",
			"PZTS11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TS_2A_TRACKER = new AircraftTypeModelCode(
			"TS-2A Tracker",
			"TS2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TS_8_BIES = new AircraftTypeModelCode(
			"TS-8 Bies",
			"TS8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TSC_1A3_TEAL_III = new AircraftTypeModelCode(
			"TSC-1A3 Teal III",
			"TSC1A3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TT_300_WESTLAND = new AircraftTypeModelCode(
			"TT-300 Westland",
			"TT300",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_104 = new AircraftTypeModelCode(
			"TU-104",
			"TU104",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_104_CAMEL = new AircraftTypeModelCode(
			"TU-104 Camel",
			"TU104A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_114_CLEAT = new AircraftTypeModelCode(
			"TU-114 Cleat",
			"TU114",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_116 = new AircraftTypeModelCode(
			"TU-116",
			"TU116",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_124 = new AircraftTypeModelCode(
			"TU-124",
			"TU124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_124_COOKPOT = new AircraftTypeModelCode(
			"TU-124 Cookpot",
			"CKP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_126_MOSS = new AircraftTypeModelCode(
			"TU-126 Moss",
			"TU126",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_128 = new AircraftTypeModelCode(
			"TU-128",
			"TU128",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_128_FIDDLER = new AircraftTypeModelCode(
			"TU-128 Fiddler",
			"FDL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_128_FIDDLER_B = new AircraftTypeModelCode(
			"TU-128 Fiddler B",
			"FDLB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_128_FIDDLER_C = new AircraftTypeModelCode(
			"TU-128 Fiddler C",
			"FDLC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_130 = new AircraftTypeModelCode(
			"TU-130",
			"TU130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_130LNG = new AircraftTypeModelCode(
			"TU-130LNG",
			"TU130L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134 = new AircraftTypeModelCode(
			"TU-134",
			"TU134",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134_CRUSTY = new AircraftTypeModelCode(
			"TU-134 Crusty",
			"CRU",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134A_CRUSTY = new AircraftTypeModelCode(
			"TU-134A Crusty",
			"TU134A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134B = new AircraftTypeModelCode(
			"TU-134B",
			"TU134B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134B1 = new AircraftTypeModelCode(
			"TU-134B1",
			"TU1341",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_134B3 = new AircraftTypeModelCode(
			"TU-134B3",
			"TU1343",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR = new AircraftTypeModelCode(
			"TU-142 Bear",
			"TU142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR_C = new AircraftTypeModelCode(
			"TU-142 Bear C",
			"TU142C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR_D = new AircraftTypeModelCode(
			"TU-142 Bear D",
			"TU142D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR_E = new AircraftTypeModelCode(
			"TU-142 Bear E",
			"TU142E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR_F = new AircraftTypeModelCode(
			"TU-142 Bear F",
			"BERF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142_BEAR_J = new AircraftTypeModelCode(
			"TU-142 Bear J",
			"BERJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142K_BEAR_H = new AircraftTypeModelCode(
			"TU-142K Bear H",
			"TU142H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142M = new AircraftTypeModelCode(
			"TU-142M",
			"TU142M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142MR = new AircraftTypeModelCode(
			"TU-142MR",
			"TU142R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142MS = new AircraftTypeModelCode(
			"TU-142MS",
			"TU142S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_142MZ = new AircraftTypeModelCode(
			"TU-142MZ",
			"TU142Z",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144 = new AircraftTypeModelCode(
			"TU-144",
			"TU144",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144_CHARGER = new AircraftTypeModelCode(
			"TU-144 Charger",
			"CX3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144_CHARGER_B = new AircraftTypeModelCode(
			"TU-144 Charger B",
			"CX3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144D = new AircraftTypeModelCode(
			"TU-144D",
			"TU144D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144D_CHARGER_C = new AircraftTypeModelCode(
			"TU-144D Charger C",
			"CX3C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_144LL = new AircraftTypeModelCode(
			"TU-144LL",
			"TU144L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154 = new AircraftTypeModelCode(
			"TU-154",
			"TU154",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154_CARELESS = new AircraftTypeModelCode(
			"TU-154 Careless",
			"CAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154_CRUSTY = new AircraftTypeModelCode(
			"TU-154 Crusty",
			"TU154T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154A = new AircraftTypeModelCode(
			"TU-154A",
			"TU154A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154A_CARELESS = new AircraftTypeModelCode(
			"TU-154A Careless",
			"CALA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154B_CARELESS = new AircraftTypeModelCode(
			"TU-154B Careless",
			"TU154B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154B2 = new AircraftTypeModelCode(
			"TU-154B2",
			"TU1542",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154M_CARELESS = new AircraftTypeModelCode(
			"TU-154M Careless",
			"TU154M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154M_OS = new AircraftTypeModelCode(
			"TU-154M/OS",
			"TU154O",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154M_100 = new AircraftTypeModelCode(
			"TU-154M-100",
			"TU1541",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154M2 = new AircraftTypeModelCode(
			"TU-154M2",
			"T154M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_154S_CARELESS = new AircraftTypeModelCode(
			"TU-154S Careless",
			"TU154S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_156 = new AircraftTypeModelCode(
			"TU-156",
			"TU156",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_156S = new AircraftTypeModelCode(
			"TU-156S",
			"TU156S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16 = new AircraftTypeModelCode(
			"TU-16",
			"TU16",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER = new AircraftTypeModelCode(
			"TU-16 Badger",
			"BGR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_A = new AircraftTypeModelCode(
			"TU-16 Badger A",
			"BGRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_B = new AircraftTypeModelCode(
			"TU-16 Badger B",
			"BGRB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_C = new AircraftTypeModelCode(
			"TU-16 Badger C",
			"BGRC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_D = new AircraftTypeModelCode(
			"TU-16 Badger D",
			"BGRD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_E = new AircraftTypeModelCode(
			"TU-16 Badger E",
			"BGRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_F = new AircraftTypeModelCode(
			"TU-16 Badger F",
			"BGRF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_G = new AircraftTypeModelCode(
			"TU-16 Badger G",
			"BGRG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_H = new AircraftTypeModelCode(
			"TU-16 Badger H",
			"BGRH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_J = new AircraftTypeModelCode(
			"TU-16 Badger J",
			"BGRJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_K = new AircraftTypeModelCode(
			"TU-16 Badger K",
			"BGRK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_BADGER_L = new AircraftTypeModelCode(
			"TU-16 Badger L",
			"BGRL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16_KORVET_BADGER_A = new AircraftTypeModelCode(
			"TU-16 Korvet Badger A",
			"KORVET",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_160_BLACKJACK = new AircraftTypeModelCode(
			"TU-160 Blackjack",
			"TU160",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_160SK = new AircraftTypeModelCode(
			"TU-160SK",
			"TU160S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16K_10_BADGER_C = new AircraftTypeModelCode(
			"TU-16K-10 Badger C",
			"TU1610",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16K_10_BADGER_C_MOD = new AircraftTypeModelCode(
			"TU-16K-10 Badger C Mod",
			"BGCMOD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16KS_1 = new AircraftTypeModelCode(
			"TU-16KS-1",
			"TU16KS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16N_BADGER_A = new AircraftTypeModelCode(
			"TU-16N Badger A",
			"TU16N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16PPH = new AircraftTypeModelCode(
			"TU-16PPH",
			"TU16PP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16PPH_BADGER_H = new AircraftTypeModelCode(
			"TU-16PPH Badger H",
			"TU16PH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16PPJ_BADGER_J = new AircraftTypeModelCode(
			"TU-16PPJ Badger J",
			"TU16PJ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16RD_BADGER_D = new AircraftTypeModelCode(
			"TU-16RD Badger D",
			"TU16RD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16RF_BADGER_F = new AircraftTypeModelCode(
			"TU-16RF Badger F",
			"TU16RF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16RK_BADGER_K = new AircraftTypeModelCode(
			"TU-16RK Badger K",
			"TU16RK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_16T_BADGER_A = new AircraftTypeModelCode(
			"TU-16T Badger A",
			"TU16T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_20_BEAR = new AircraftTypeModelCode(
			"TU-20 Bear",
			"TU20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_MARITIME = new AircraftTypeModelCode(
			"TU-204 Maritime",
			"TU204M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_TUPOLEV = new AircraftTypeModelCode(
			"TU-204 Tupolev",
			"TU204",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_100_TUPOLEV = new AircraftTypeModelCode(
			"TU-204/100 Tupolev",
			"TU2041",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_200_TUPOLEV = new AircraftTypeModelCode(
			"TU-204/200 Tupolev",
			"TU2042",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_120 = new AircraftTypeModelCode(
			"TU-204-120",
			"TU2412",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_220 = new AircraftTypeModelCode(
			"TU-204-220",
			"TU2422",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204_230 = new AircraftTypeModelCode(
			"TU-204-230",
			"TU2423",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_204C = new AircraftTypeModelCode(
			"TU-204C",
			"TU204C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_214 = new AircraftTypeModelCode(
			"TU-214",
			"TU214",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22 = new AircraftTypeModelCode(
			"TU-22",
			"TU22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22_BLINDER = new AircraftTypeModelCode(
			"TU-22 Blinder",
			"BLN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22_BLINDER_A = new AircraftTypeModelCode(
			"TU-22 Blinder A",
			"BLNA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22_BLINDER_B = new AircraftTypeModelCode(
			"TU-22 Blinder B",
			"BLNB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22_BLINDER_C = new AircraftTypeModelCode(
			"TU-22 Blinder C",
			"BLNC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22_BLINDER_D = new AircraftTypeModelCode(
			"TU-22 Blinder D",
			"TU22D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22E_BLINDER_E = new AircraftTypeModelCode(
			"TU-22E Blinder E",
			"BLNE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22M1 = new AircraftTypeModelCode(
			"TU-22M1",
			"TU22M1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22M2 = new AircraftTypeModelCode(
			"TU-22M2",
			"TU22M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22M3 = new AircraftTypeModelCode(
			"TU-22M3",
			"TU22M3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22MR = new AircraftTypeModelCode(
			"TU-22MR",
			"TU22MR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_22U_BLINDER_D = new AircraftTypeModelCode(
			"TU-22U Blinder D",
			"TU22U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_244 = new AircraftTypeModelCode(
			"TU-244",
			"TU244",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_24S = new AircraftTypeModelCode(
			"TU-24S",
			"TU24S",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_24T = new AircraftTypeModelCode(
			"TU-24T",
			"TU24T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_24U = new AircraftTypeModelCode(
			"TU-24U",
			"TU24U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_26_BACKFIRE = new AircraftTypeModelCode(
			"TU-26 Backfire",
			"BKF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_26_BACKFIRE_A = new AircraftTypeModelCode(
			"TU-26 Backfire A",
			"BKFA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_26_BACKFIRE_B = new AircraftTypeModelCode(
			"TU-26 Backfire B",
			"BKFB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_26_BACKFIRE_C = new AircraftTypeModelCode(
			"TU-26 Backfire C",
			"BKFC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_26_BACKFIRE_RECCE = new AircraftTypeModelCode(
			"TU-26 Backfire Recce",
			"TU26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_28P_FIDDLER = new AircraftTypeModelCode(
			"TU-28P Fiddler",
			"TU28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_330 = new AircraftTypeModelCode(
			"TU-330",
			"TU330",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_334 = new AircraftTypeModelCode(
			"TU-334",
			"TU334",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_334_100 = new AircraftTypeModelCode(
			"TU-334-100",
			"TU3341",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_334_100D = new AircraftTypeModelCode(
			"TU-334-100D",
			"TU334D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_334C = new AircraftTypeModelCode(
			"TU-334C",
			"TU334C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_34 = new AircraftTypeModelCode(
			"TU-34",
			"TU34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_354 = new AircraftTypeModelCode(
			"TU-354",
			"TU354",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_414 = new AircraftTypeModelCode(
			"TU-414",
			"TU414",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95 = new AircraftTypeModelCode(
			"TU-95",
			"TU95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR = new AircraftTypeModelCode(
			"TU-95 Bear",
			"BER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_A = new AircraftTypeModelCode(
			"TU-95 Bear A",
			"BERA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_B = new AircraftTypeModelCode(
			"TU-95 Bear B",
			"BERB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_C = new AircraftTypeModelCode(
			"TU-95 Bear C",
			"BERC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_D = new AircraftTypeModelCode(
			"TU-95 Bear D",
			"BERD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_E = new AircraftTypeModelCode(
			"TU-95 Bear E",
			"BERE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_G = new AircraftTypeModelCode(
			"TU-95 Bear G",
			"BERG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95_BEAR_H = new AircraftTypeModelCode(
			"TU-95 Bear H",
			"BERH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95K = new AircraftTypeModelCode(
			"TU-95K",
			"TU95K",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95K_20 = new AircraftTypeModelCode(
			"TU-95K-20",
			"TU95K2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95K_22 = new AircraftTypeModelCode(
			"TU-95K-22",
			"TU9522",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95M = new AircraftTypeModelCode(
			"TU-95M",
			"TU95M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95MR = new AircraftTypeModelCode(
			"TU-95MR",
			"TU95MR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TU_95RT = new AircraftTypeModelCode(
			"TU-95RT",
			"TU95RT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TUPOLEV_C_PROP = new AircraftTypeModelCode(
			"Tupolev C-Prop",
			"TUCP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TURBOBEAVER = new AircraftTypeModelCode(
			"Turbobeaver",
			"TURBVR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TURBOPORTER_PEACEMAKER = new AircraftTypeModelCode(
			"Turboporter Peacemaker",
			"TURPOR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TWIN_BEECH_18 = new AircraftTypeModelCode(
			"Twin Beech 18",
			"BC18L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TWIN_HUEY_AGUSTA_BELL_205 = new AircraftTypeModelCode(
			"Twin Huey Agusta Bell 205",
			"HAB205",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TWIN_OTTER_CANADIAN = new AircraftTypeModelCode(
			"Twin Otter Canadian",
			"TWINOT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TWIN_SQUIRREL_ECUREUIL_2 = new AircraftTypeModelCode(
			"Twin Squirrel Ecureuil 2",
			"TWINSQ",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TWIN_STAR = new AircraftTypeModelCode(
			"Twin Star",
			"TWINST",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode TZUGIT_MAGISTER = new AircraftTypeModelCode(
			"Tzugit Magister",
			"TZUG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_1_OTTER = new AircraftTypeModelCode(
			"U-1 Otter",
			"U1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_10_COURIER = new AircraftTypeModelCode(
			"U-10 Courier",
			"U10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_11_AZTEC = new AircraftTypeModelCode(
			"U-11 Aztec",
			"U11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_11A_AZTEC = new AircraftTypeModelCode(
			"U-11A Aztec",
			"U11A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_125 = new AircraftTypeModelCode(
			"U-125",
			"U125",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_125A = new AircraftTypeModelCode(
			"U-125A",
			"U125A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_17_SKYWAGON = new AircraftTypeModelCode(
			"U-17 Skywagon",
			"U17",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_17A_SKYWAGON = new AircraftTypeModelCode(
			"U-17A Skywagon",
			"U17A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_17B_SKYWAGON = new AircraftTypeModelCode(
			"U-17B Skywagon",
			"U17B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_1A_OTTER = new AircraftTypeModelCode(
			"U-1A Otter",
			"U1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_2 = new AircraftTypeModelCode(
			"U-2",
			"U2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_21_UTE = new AircraftTypeModelCode(
			"U-21 Ute",
			"U21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_21F_UTE_U_21F_KING_AIR_100 = new AircraftTypeModelCode(
			"U-21F Ute / U-21F King Air 100",
			"U21F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_25_HURON = new AircraftTypeModelCode(
			"U-25 Huron",
			"U25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_27A_CARAVAN = new AircraftTypeModelCode(
			"U-27A Caravan",
			"U27A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_2R = new AircraftTypeModelCode(
			"U-2R",
			"U2R",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_3_CESSNA = new AircraftTypeModelCode(
			"U-3 Cessna",
			"U3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_36_LEARJET = new AircraftTypeModelCode(
			"U-36 Learjet",
			"U36",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_3A = new AircraftTypeModelCode(
			"U-3A",
			"U3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_3B = new AircraftTypeModelCode(
			"U-3B",
			"U3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_4_AERO_COMMANDER = new AircraftTypeModelCode(
			"U-4 Aero Commander",
			"U4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_42_REGENTE = new AircraftTypeModelCode(
			"U-42 Regente",
			"U42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_5_AERO_COMMANDER = new AircraftTypeModelCode(
			"U-5 Aero Commander",
			"U5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_6_BEAVER = new AircraftTypeModelCode(
			"U-6 Beaver",
			"U6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_6A_BEAVER = new AircraftTypeModelCode(
			"U-6A Beaver",
			"U6A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_7_SENECA_II = new AircraftTypeModelCode(
			"U-7 Seneca II",
			"U7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_7_SUPER_CUB = new AircraftTypeModelCode(
			"U-7 Super Cub",
			"U7SC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_7A_SENECA = new AircraftTypeModelCode(
			"U-7A Seneca",
			"U7A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_7B_SENECA = new AircraftTypeModelCode(
			"U-7B Seneca",
			"U7B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_8 = new AircraftTypeModelCode(
			"U-8",
			"U8TE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_8_SEMINOLE_U_8_TWIN_BONANZA = new AircraftTypeModelCode(
			"U-8 Seminole / U-8 Twin Bonanza",
			"U8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_8_TWIN_BONANZA = new AircraftTypeModelCode(
			"U-8 Twin Bonanza",
			"U8TB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_8D_TWIN_BONANZA = new AircraftTypeModelCode(
			"U-8D Twin Bonanza",
			"U8D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_8F_SEMINOLE = new AircraftTypeModelCode(
			"U-8F Seminole",
			"U8F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_9_AERO = new AircraftTypeModelCode(
			"U-9 Aero",
			"U9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_9_XINGU = new AircraftTypeModelCode(
			"U-9 Xingu",
			"U9X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_9_XINGU_I = new AircraftTypeModelCode(
			"U-9 Xingu I",
			"U9XI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_93_DOMINIE = new AircraftTypeModelCode(
			"U-93 Dominie",
			"U93",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode U_9D_AERO = new AircraftTypeModelCode(
			"U-9D Aero",
			"U9D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12B = new AircraftTypeModelCode(
			"UC-12B",
			"UC12B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12B_HURON = new AircraftTypeModelCode(
			"UC-12B Huron",
			"UC12BH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12B_SUPER_KING_AIR_200B = new AircraftTypeModelCode(
			"UC-12B Super King Air 200B",
			"UC12B2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12D_SUPER_KING_AIR_200D = new AircraftTypeModelCode(
			"UC-12D Super King Air 200d",
			"UC12D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12F_SUPER_KING_AIR_200F = new AircraftTypeModelCode(
			"UC-12F Super King Air 200f",
			"UC12F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12M = new AircraftTypeModelCode(
			"UC-12M",
			"UC12M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_12M_SUPER_KING_AIR_200M = new AircraftTypeModelCode(
			"UC-12M Super King Air 200M",
			"UC12M2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_26C = new AircraftTypeModelCode(
			"UC-26C",
			"UC26C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_26C_MERLIN_IV_C = new AircraftTypeModelCode(
			"UC-26C Merlin IV-C",
			"UC026C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_35A_CITATION_V_CESSNA_CITATION_560_ULTRA_V = new AircraftTypeModelCode(
			"UC-35A Citation V / Cessna Citation 560 Ultra V",
			"UC35A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UC_45J_NAVIGATOR = new AircraftTypeModelCode(
			"UC-45J Navigator",
			"UC45J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_MK_88_LYNX = new AircraftTypeModelCode(
			"UH MK-88 Lynx",
			"UHMK88",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1_AGUSTA_BELL_205 = new AircraftTypeModelCode(
			"UH-1 Agusta Bell 205",
			"UH1AB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1_IROQUOIS = new AircraftTypeModelCode(
			"UH-1 Iroquois",
			"UH1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_12_HILLER = new AircraftTypeModelCode(
			"UH-12 Hiller",
			"UH12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_12E_HILLER = new AircraftTypeModelCode(
			"UH-12E Hiller",
			"UH12E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_14_LYNX = new AircraftTypeModelCode(
			"UH-14 Lynx",
			"UH14",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_14A_LYNX = new AircraftTypeModelCode(
			"UH-14A Lynx",
			"UH14A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19_CHICKASAW = new AircraftTypeModelCode(
			"UH-19 Chickasaw",
			"UH19",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19A_CHICKASAW = new AircraftTypeModelCode(
			"UH-19A Chickasaw",
			"UH19A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19B_CHIKASAW = new AircraftTypeModelCode(
			"UH-19B Chikasaw",
			"UH19B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19C_CHICKASAW = new AircraftTypeModelCode(
			"UH-19C Chickasaw",
			"UH19C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19D_CHICKASAW = new AircraftTypeModelCode(
			"UH-19D Chickasaw",
			"UH19D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_19F_CHICKASAW = new AircraftTypeModelCode(
			"UH-19F Chickasaw",
			"UH19F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1B_IROQUOIS = new AircraftTypeModelCode(
			"UH-1B Iroquois",
			"UH1B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1C_IROQUOIS = new AircraftTypeModelCode(
			"UH-1C Iroquois",
			"UH1C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1D_IROQUOIS = new AircraftTypeModelCode(
			"UH-1D Iroquois",
			"UH1D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1E_IROQUOIS = new AircraftTypeModelCode(
			"UH-1E Iroquois",
			"UH1E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1F_IROQUOIS = new AircraftTypeModelCode(
			"UH-1F Iroquois",
			"UH1F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1H_IROQUOIS = new AircraftTypeModelCode(
			"UH-1H Iroquois",
			"UH1H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1J = new AircraftTypeModelCode(
			"UH-1J",
			"UH1J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1L_IROQUOIS = new AircraftTypeModelCode(
			"UH-1L Iroquois",
			"UH1L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1M_IROQUOIS = new AircraftTypeModelCode(
			"UH-1M Iroquois",
			"UH1M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1N_TWIN_HUEY = new AircraftTypeModelCode(
			"UH-1N Twin Huey",
			"UH1NTH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1P_IROQUOIS = new AircraftTypeModelCode(
			"UH-1P Iroquois",
			"UH1P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1T_IROQUOIS = new AircraftTypeModelCode(
			"UH-1T Iroquois",
			"UH1T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_1V_IROQUOIS = new AircraftTypeModelCode(
			"UH-1V Iroquois",
			"UH1V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_2_SEASPRITE = new AircraftTypeModelCode(
			"UH-2 Seasprite",
			"UH2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_2A_SEASPRITE = new AircraftTypeModelCode(
			"UH-2A Seasprite",
			"UH2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_2B_SEASPRITE = new AircraftTypeModelCode(
			"UH-2B Seasprite",
			"UH2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_3_SEA_KING = new AircraftTypeModelCode(
			"UH-3 Sea King",
			"UH3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_34D_CHOCTAW = new AircraftTypeModelCode(
			"UH-34D Choctaw",
			"UH34D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_3A_SEA_KING = new AircraftTypeModelCode(
			"UH-3A Sea King",
			"UH3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_3D = new AircraftTypeModelCode(
			"UH-3D",
			"UH3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_46_CHINOOK = new AircraftTypeModelCode(
			"UH-46 Chinook",
			"UH46C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_46_SEA_KNIGHT = new AircraftTypeModelCode(
			"UH-46 Sea Knight",
			"UH46",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_46A_SEA_KNIGHT = new AircraftTypeModelCode(
			"UH-46A Sea Knight",
			"UH46A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_46D_SEA_KNIGHT = new AircraftTypeModelCode(
			"UH-46D Sea Knight",
			"UH46D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60 Blackhawk",
			"UH60",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60A_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60A Blackhawk",
			"UH60A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60A_PAVEHAWK = new AircraftTypeModelCode(
			"UH-60A Pavehawk",
			"UH60AP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60B_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60B Blackhawk",
			"UH60B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60C_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60C Blackhawk",
			"UH60C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60J = new AircraftTypeModelCode(
			"UH-60J",
			"UH60J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60JA = new AircraftTypeModelCode(
			"UH-60JA",
			"UH60JA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60L_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60L Blackhawk",
			"UH60L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60P_BLACKHAWK = new AircraftTypeModelCode(
			"UH-60P Blackhawk",
			"UH60P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UH_60Q_DUSTOFF = new AircraftTypeModelCode(
			"UH-60Q Dustoff",
			"UH60Q",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ULTRASPORT_496 = new AircraftTypeModelCode(
			"Ultrasport 496",
			"US496",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UM10_23_CLOUD_CRUISER = new AircraftTypeModelCode(
			"UM10-23 Cloud Cruiser",
			"UM1023",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UM30_71 = new AircraftTypeModelCode(
			"UM30-71",
			"UM3071",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UP_2J_NEPTUNE = new AircraftTypeModelCode(
			"UP-2J Neptune",
			"UP2J",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_1 = new AircraftTypeModelCode(
			"US-1",
			"US1SAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_1_SHIN_MEIWA = new AircraftTypeModelCode(
			"US-1 Shin Meiwa",
			"US1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_1A = new AircraftTypeModelCode(
			"US-1A",
			"US1A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_2_TRACKER = new AircraftTypeModelCode(
			"US-2 Tracker",
			"US2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_2A_TRACKER = new AircraftTypeModelCode(
			"US-2A Tracker",
			"US2A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_2B_TRACKER = new AircraftTypeModelCode(
			"US-2B Tracker",
			"US2B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_2C_TRACKER = new AircraftTypeModelCode(
			"US-2C Tracker",
			"US2C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_2D_TRACKER = new AircraftTypeModelCode(
			"US-2D Tracker",
			"US2D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode US_3A_VIKING = new AircraftTypeModelCode(
			"US-3A Viking",
			"US3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UTVA = new AircraftTypeModelCode(
			"Utva",
			"UTV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UTVA_75_75_AG_11 = new AircraftTypeModelCode(
			"Utva-75 / 75 AG 11",
			"UTVA75",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UTVA_95 = new AircraftTypeModelCode(
			"Utva-95",
			"UTVA95",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_18_TWIN_OTTER = new AircraftTypeModelCode(
			"UV-18 Twin Otter",
			"UV18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_18A_CANADIAN = new AircraftTypeModelCode(
			"UV-18A Canadian",
			"UV18AC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_18A_TWIN_OTTER = new AircraftTypeModelCode(
			"UV-18A Twin Otter",
			"UV18A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_18B_TWIN_OTTER = new AircraftTypeModelCode(
			"UV-18B Twin Otter",
			"UV18B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_20 = new AircraftTypeModelCode(
			"UV-20",
			"UV20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode UV_20A_CHIRICAHUA = new AircraftTypeModelCode(
			"UV-20A Chiricahua",
			"UV20A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode V_22_OSPREY = new AircraftTypeModelCode(
			"V-22 Osprey",
			"V22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode V_35B_BONANZA = new AircraftTypeModelCode(
			"V-35B Bonanza",
			"BCV35B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VA_10_VANTAGE = new AircraftTypeModelCode(
			"VA-10 Vantage",
			"VA10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VA_2_MATADOR_II = new AircraftTypeModelCode(
			"VA-2 Matador II",
			"VA2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VA_3B = new AircraftTypeModelCode(
			"VA-3B",
			"VA3B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VARGA_KACHINA_2150A = new AircraftTypeModelCode(
			"Varga Kachina 2150A",
			"VG21",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VARJA_MIRAGE_2000 = new AircraftTypeModelCode(
			"Varja Mirage 2000",
			"VAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_CMK1K = new AircraftTypeModelCode(
			"VC-10 CMK1K",
			"VC10CM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_K_MK23 = new AircraftTypeModelCode(
			"VC-10 K-MK23",
			"VC10M3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_MK_K2 = new AircraftTypeModelCode(
			"VC-10 MK K2",
			"VC1KK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_MK_K3 = new AircraftTypeModelCode(
			"VC-10 MK K3",
			"VC1KK3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_MK_K4 = new AircraftTypeModelCode(
			"VC-10 MK K4",
			"VC1KK4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10_VISCOUNT = new AircraftTypeModelCode(
			"VC-10 Viscount",
			"VC10",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10C1_BAC = new AircraftTypeModelCode(
			"VC-10C1 BAC",
			"VC10C1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10K2_BAC = new AircraftTypeModelCode(
			"VC-10K2 BAC",
			"VC10K2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_10K3_BAC = new AircraftTypeModelCode(
			"VC-10K3 BAC",
			"VC10K3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_11 = new AircraftTypeModelCode(
			"VC-11",
			"VC11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_11_SKYTRAIN_II = new AircraftTypeModelCode(
			"VC-11 Skytrain II",
			"VC11II",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_118_LIFTMASTER = new AircraftTypeModelCode(
			"VC-118 Liftmaster",
			"VC118",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_118A_LIFTMASTER = new AircraftTypeModelCode(
			"VC-118A Liftmaster",
			"VC118A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_118B_LIFTMASTER = new AircraftTypeModelCode(
			"VC-118B Liftmaster",
			"VC118B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_11A = new AircraftTypeModelCode(
			"VC-11A",
			"VC11A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_11A_GULFSTREAM_II = new AircraftTypeModelCode(
			"VC-11A Gulfstream II",
			"VC11AG",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_130_HERCULES = new AircraftTypeModelCode(
			"VC-130 Hercules",
			"VC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_130H_HERCULES = new AircraftTypeModelCode(
			"VC-130H Hercules",
			"VC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_131_SAMARITAN = new AircraftTypeModelCode(
			"VC-131 Samaritan",
			"VC131",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_131A_SAMARITAN = new AircraftTypeModelCode(
			"VC-131A Samaritan",
			"VC131A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_131H_SAMARITAN = new AircraftTypeModelCode(
			"VC-131H Samaritan",
			"VC131H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_135B_STRATOLIFTER = new AircraftTypeModelCode(
			"VC-135B Stratolifter",
			"VC135B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_137 = new AircraftTypeModelCode(
			"VC-137",
			"VC137",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_137_GULFSTREAM = new AircraftTypeModelCode(
			"VC-137 Gulfstream",
			"VC137G",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_137C_GULFSTREAM = new AircraftTypeModelCode(
			"VC-137C Gulfstream",
			"VC137C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_140_JETSTAR = new AircraftTypeModelCode(
			"VC-140 Jetstar",
			"VC140",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_140B_JETSTAR = new AircraftTypeModelCode(
			"VC-140B Jetstar",
			"VC140B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_25_BOEING_747 = new AircraftTypeModelCode(
			"VC-25 Boeing 747",
			"VC25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_25A_B_747_200 = new AircraftTypeModelCode(
			"VC-25A / B-747-200",
			"VC25A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_25A_BOEING_747 = new AircraftTypeModelCode(
			"VC-25A Boeing 747",
			"VC025A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_26 = new AircraftTypeModelCode(
			"VC-26",
			"VC26",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_6_KING_AIR = new AircraftTypeModelCode(
			"VC-6 King Air",
			"VC6",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_6B_KING_AIR_C90 = new AircraftTypeModelCode(
			"VC-6B King Air C90",
			"VC6B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_7_VISCOUNT = new AircraftTypeModelCode(
			"VC-7 Viscount",
			"VC7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_9_NIGHTINGALE = new AircraftTypeModelCode(
			"VC-9 Nightingale",
			"VC9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC_97_BRASILIA = new AircraftTypeModelCode(
			"VC-97 Brasilia",
			"VC97",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VC9C_MCDONNELL_DC_9 = new AircraftTypeModelCode(
			"VC9C Mcdonnell DC-9",
			"VC9C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VERTOL_MODEL_44A = new AircraftTypeModelCode(
			"Vertol Model 44A",
			"VRT44A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VERTOL_MODEL_44B = new AircraftTypeModelCode(
			"Vertol Model 44B",
			"VRT44B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VERTOL_V_234 = new AircraftTypeModelCode(
			"Vertol V-234",
			"V234",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VFW_F_27_FRIENDSHIP = new AircraftTypeModelCode(
			"VFW F-27 Friendship",
			"F27AV",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VFW_614 = new AircraftTypeModelCode(
			"VFW-614",
			"VFW614",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_3_SEA_KING = new AircraftTypeModelCode(
			"VH-3 Sea King",
			"VH3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_34D_SEAHORSE = new AircraftTypeModelCode(
			"VH-34D Seahorse",
			"VH34D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_3A_SEA_KING = new AircraftTypeModelCode(
			"VH-3A Sea King",
			"VH3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_3D_SEA_KING = new AircraftTypeModelCode(
			"VH-3D Sea King",
			"VH3D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_4_JETRANGER = new AircraftTypeModelCode(
			"VH-4 Jetranger",
			"VH4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VH_60N_BLACKHAWK = new AircraftTypeModelCode(
			"VH-60n Blackhawk",
			"VH60N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VICKERS_VANGUARD = new AircraftTypeModelCode(
			"Vickers Vanguard",
			"VKVNGD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VICKERS_VISCOUNT = new AircraftTypeModelCode(
			"Vickers Viscount",
			"VCONT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VICTOR = new AircraftTypeModelCode(
			"Victor",
			"VICTOR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VICTOR_K2 = new AircraftTypeModelCode(
			"Victor K2",
			"VICTK2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VICTOR_P_68 = new AircraftTypeModelCode(
			"Victor P-68",
			"P68",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VJ_22_SPORTSMAN = new AircraftTypeModelCode(
			"VJ-22 Sportsman",
			"VJ22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VOUGHT_SWIFT = new AircraftTypeModelCode(
			"Vought Swift",
			"GC1",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VOYAGEUR_LABRADOR = new AircraftTypeModelCode(
			"Voyageur Labrador",
			"VOY",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VP_3A_ORION = new AircraftTypeModelCode(
			"VP-3A Orion",
			"VP3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VTOUR_2N_VATOUR_IIN = new AircraftTypeModelCode(
			"VTOUR 2N / Vatour IIN",
			"VTOUR2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode VU_9_EMBRACER = new AircraftTypeModelCode(
			"VU-9 Embracer",
			"VU9",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode W_3_SOKOL = new AircraftTypeModelCode(
			"W-3 Sokol",
			"PZLW3",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode W_3A = new AircraftTypeModelCode(
			"W-3A",
			"PZLW3A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode W_3RM = new AircraftTypeModelCode(
			"W-3RM",
			"PZW3RM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode W_3W = new AircraftTypeModelCode(
			"W-3W",
			"PZLW3W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode W_3WA = new AircraftTypeModelCode(
			"W-3WA",
			"PZW3WA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WAG_2_2_SPORTSMAN = new AircraftTypeModelCode(
			"WAG 2+2 Sportsman",
			"WAG22",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WAG_A_BOND = new AircraftTypeModelCode(
			"WAG-A-Bond",
			"WAGABO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WAI_100 = new AircraftTypeModelCode(
			"WAI 100",
			"WAI100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WAI_600 = new AircraftTypeModelCode(
			"WAI 600",
			"WAI600",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_130_HERCULES = new AircraftTypeModelCode(
			"WC-130 Hercules",
			"WC130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_130B_HERCULES = new AircraftTypeModelCode(
			"WC-130B Hercules",
			"WC130B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_130E_HERCULES = new AircraftTypeModelCode(
			"WC-130E Hercules",
			"WC130E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_130H_HERCULES = new AircraftTypeModelCode(
			"WC-130H Hercules",
			"WC130H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_135 = new AircraftTypeModelCode(
			"WC-135",
			"WC135",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_135B_STRATOLIFTER = new AircraftTypeModelCode(
			"WC-135B Stratolifter",
			"WC135B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_135N_STRATOLIFTER = new AircraftTypeModelCode(
			"WC-135N Stratolifter",
			"WC135N",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WC_135W_STRATOLIFTER = new AircraftTypeModelCode(
			"WC-135W Stratolifter",
			"WC135W",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WESSEX_CHOCTAW = new AircraftTypeModelCode(
			"Wessex Choctaw",
			"WSX",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WG_13_LYNX_MK_4_FR = new AircraftTypeModelCode(
			"WG-13 Lynx MK-4 FR",
			"WG13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WG_30_WESTLAND_CIVIL = new AircraftTypeModelCode(
			"WG-30 Westland Civil",
			"WG30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WG_34_WESTLAND_LYNX = new AircraftTypeModelCode(
			"WG-34 Westland Lynx",
			"WG34",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WHIRLWIND_CHIKASAW = new AircraftTypeModelCode(
			"Whirlwind Chikasaw",
			"WW",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WILGA_2000 = new AircraftTypeModelCode(
			"Wilga 2000",
			"PZWI20",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WILGA_35 = new AircraftTypeModelCode(
			"Wilga 35",
			"PZWI35",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WILGA_80 = new AircraftTypeModelCode(
			"Wilga 80",
			"PZWI80",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode WIND_SPIRIT = new AircraftTypeModelCode(
			"Wind Spirit",
			"WSPRT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode X_4 = new AircraftTypeModelCode(
			"X-4",
			"ROBX4",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode XC_2_AIDC = new AircraftTypeModelCode(
			"XC-2 AIDC",
			"XC2",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode XIAN_F7_FISHBED_C = new AircraftTypeModelCode(
			"Xian F7 Fishbed C",
			"XIANF7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode XIHU_5 = new AircraftTypeModelCode(
			"Xihu 5",
			"XIHU5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode XINGU_I_EMB_121A = new AircraftTypeModelCode(
			"Xingu I / Emb-121A",
			"EMB21A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode XINGU_II_EMB_121A1 = new AircraftTypeModelCode(
			"Xingu II / Emb-121A1",
			"EMB211",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_11_CHAN_YUN_11 = new AircraftTypeModelCode(
			"Y-11 Chan / Yun-11",
			"Y11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_11_MOOSE = new AircraftTypeModelCode(
			"Y-11 Moose",
			"Y11M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_11B_I = new AircraftTypeModelCode(
			"Y-11B / I",
			"Y11B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_11T_CHAN_YUN_11T = new AircraftTypeModelCode(
			"Y-11T Chan / Yun-11T",
			"Y11T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_12_II_TURBO_PANDA = new AircraftTypeModelCode(
			"Y-12 / II Turbo-Panda",
			"Y122",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_12_IV = new AircraftTypeModelCode(
			"Y-12 / IV",
			"Y124",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_12_TURBO_PANDA_YUN_12 = new AircraftTypeModelCode(
			"Y-12 Turbo-Panda / Yun-12",
			"Y12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_5_COLT = new AircraftTypeModelCode(
			"Y-5 Colt",
			"Y5",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_5B = new AircraftTypeModelCode(
			"Y-5B",
			"Y5B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_5C = new AircraftTypeModelCode(
			"Y-5C",
			"Y5C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7 = new AircraftTypeModelCode(
			"Y-7",
			"Y7",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7_100 = new AircraftTypeModelCode(
			"Y-7-100",
			"Y710",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y7_100_COKE = new AircraftTypeModelCode(
			"Y7-100 Coke",
			"Y7100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7_100C = new AircraftTypeModelCode(
			"Y-7-100C",
			"Y710C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7_200A = new AircraftTypeModelCode(
			"Y-7-200A",
			"Y720A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7_200B = new AircraftTypeModelCode(
			"Y-7-200B",
			"Y720B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7E = new AircraftTypeModelCode(
			"Y-7E",
			"Y7E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7H = new AircraftTypeModelCode(
			"Y-7H",
			"Y7H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_7H_500 = new AircraftTypeModelCode(
			"Y-7H-500",
			"Y7H50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y7H_500_CURL = new AircraftTypeModelCode(
			"Y7H-500 Curl",
			"Y7H500",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8_YUN_8 = new AircraftTypeModelCode(
			"Y-8 / Yun-8",
			"Y8",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8A = new AircraftTypeModelCode(
			"Y-8A",
			"Y8A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8B = new AircraftTypeModelCode(
			"Y-8B",
			"Y8B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8C = new AircraftTypeModelCode(
			"Y-8C",
			"Y8C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8D = new AircraftTypeModelCode(
			"Y-8D",
			"Y8D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8E = new AircraftTypeModelCode(
			"Y-8E",
			"Y8E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8ECM = new AircraftTypeModelCode(
			"Y-8ECM",
			"Y8ECM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8F = new AircraftTypeModelCode(
			"Y-8F",
			"Y8F",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8H = new AircraftTypeModelCode(
			"Y-8H",
			"Y8H",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Y_8X = new AircraftTypeModelCode(
			"Y-8X",
			"Y8X",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_130_AEM_YAK_130 = new AircraftTypeModelCode(
			"YAK 130 / AEM/YAK 130",
			"YAK13",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_11 = new AircraftTypeModelCode(
			"YAK-11",
			"YAK11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_11_MOOSE = new AircraftTypeModelCode(
			"YAK-11 Moose",
			"MOO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_112 = new AircraftTypeModelCode(
			"YAK-112",
			"YAK112",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_12_CREEK = new AircraftTypeModelCode(
			"YAK-12 Creek",
			"YAK12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_130 = new AircraftTypeModelCode(
			"YAK-130",
			"YAK130",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_142 = new AircraftTypeModelCode(
			"YAK-142",
			"YAK142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_142VIP = new AircraftTypeModelCode(
			"YAK-142vip",
			"YAK14V",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_18_MAX = new AircraftTypeModelCode(
			"YAK-18 Max",
			"YAK18",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_18_MOOSE = new AircraftTypeModelCode(
			"YAK-18 Moose",
			"Y18MOO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_18T = new AircraftTypeModelCode(
			"YAK-18T",
			"YAK18T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_242 = new AircraftTypeModelCode(
			"YAK-242",
			"YAK242",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_25_FLASHLIGHT = new AircraftTypeModelCode(
			"YAK-25 Flashlight",
			"YAK25",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_27 = new AircraftTypeModelCode(
			"YAK-27",
			"Y27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_27_MANGROVE = new AircraftTypeModelCode(
			"YAK-27 Mangrove",
			"YAK27",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_27U_MAESTRO = new AircraftTypeModelCode(
			"YAK-27U Maestro",
			"YA27U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28 = new AircraftTypeModelCode(
			"YAK-28",
			"YAK28",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER = new AircraftTypeModelCode(
			"YAK-28 Brewer",
			"BRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER_A = new AircraftTypeModelCode(
			"YAK-28 Brewer A",
			"BREA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER_B = new AircraftTypeModelCode(
			"YAK-28 Brewer B",
			"BREB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER_C = new AircraftTypeModelCode(
			"YAK-28 Brewer C",
			"BREC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER_D = new AircraftTypeModelCode(
			"YAK-28 Brewer D",
			"BRED",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_BREWER_E = new AircraftTypeModelCode(
			"YAK-28 Brewer E",
			"BREE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28_FIREBAR_A = new AircraftTypeModelCode(
			"YAK-28 Firebar A",
			"YAKFBA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28P = new AircraftTypeModelCode(
			"YAK-28P",
			"YAK28P",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28P_BREWER_E = new AircraftTypeModelCode(
			"YAK-28P Brewer E",
			"28PBRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28P_FIREBAR = new AircraftTypeModelCode(
			"YAK-28P Firebar",
			"FBR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28P_FIREBAR_A = new AircraftTypeModelCode(
			"YAK-28P Firebar A",
			"FBRA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28P_FIREBAR_B = new AircraftTypeModelCode(
			"YAK-28P Firebar B",
			"FBRB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28R_BREWER_D = new AircraftTypeModelCode(
			"YAK-28R Brewer D",
			"28RBRD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28U_BREWER_D = new AircraftTypeModelCode(
			"YAK-28U Brewer D",
			"28UBRD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28U_BREWER_E = new AircraftTypeModelCode(
			"YAK-28U Brewer E",
			"28UBRE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_28U_MAESTRO = new AircraftTypeModelCode(
			"YAK-28U Maestro",
			"YAK28U",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_30_MAGNUM = new AircraftTypeModelCode(
			"YAK-30 Magnum",
			"YAK30",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_32_MANTIS = new AircraftTypeModelCode(
			"YAK-32 Mantis",
			"YAK32",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_3RMP = new AircraftTypeModelCode(
			"YAK-3RMP",
			"YAK36M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_36MP_FORGER = new AircraftTypeModelCode(
			"YAK-36MP Forger",
			"Y36MP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_36MP_FORGER_A = new AircraftTypeModelCode(
			"YAK-36MP Forger-A",
			"Y36MPA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_36MP_FORGER_B = new AircraftTypeModelCode(
			"YAK-36MP Forger-B",
			"Y36MPB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38 = new AircraftTypeModelCode(
			"YAK-38",
			"YAK38",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38_FORGER = new AircraftTypeModelCode(
			"YAK-38 Forger",
			"FOR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38_FORGER_A = new AircraftTypeModelCode(
			"YAK-38 Forger A",
			"FORA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38_FORGER_B = new AircraftTypeModelCode(
			"YAK-38 Forger B",
			"FORB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38A = new AircraftTypeModelCode(
			"YAK-38A",
			"YAK38A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_38D = new AircraftTypeModelCode(
			"YAK-38D",
			"YAK38B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_40 = new AircraftTypeModelCode(
			"YAK-40",
			"YAK40",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_40_CODLING = new AircraftTypeModelCode(
			"YAK-40 Codling",
			"COD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_41_FREESTYLE = new AircraftTypeModelCode(
			"YAK-41 Freestyle",
			"YAK41",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42 = new AircraftTypeModelCode(
			"YAK-42",
			"YAK42",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42_CLOBBER = new AircraftTypeModelCode(
			"YAK-42 Clobber",
			"CLO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42A = new AircraftTypeModelCode(
			"YAK-42A",
			"YAK42A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42D_CLOBBER = new AircraftTypeModelCode(
			"YAK-42D Clobber",
			"YAK42D",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42E_LL_CLOBBER = new AircraftTypeModelCode(
			"YAK-42E-LL Clobber",
			"YAK42E",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42M_CLOBBER = new AircraftTypeModelCode(
			"YAK-42M Clobber",
			"YAK42M",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_42T = new AircraftTypeModelCode(
			"YAK-42T",
			"YAK42T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_46_1 = new AircraftTypeModelCode(
			"YAK-46-1",
			"YAK461",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_46_2 = new AircraftTypeModelCode(
			"YAK-46-2",
			"YAK462",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_52 = new AircraftTypeModelCode(
			"YAK-52",
			"YAK52",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_54 = new AircraftTypeModelCode(
			"YAK-54",
			"YAK54",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_56 = new AircraftTypeModelCode(
			"YAK-56",
			"YAK56",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAK_58 = new AircraftTypeModelCode(
			"YAK-58",
			"YAK58",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YAMAL = new AircraftTypeModelCode(
			"Yamal",
			"YAMAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YANSHUF_S_70A = new AircraftTypeModelCode(
			"Yanshuf / S-70A",
			"YAS70A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YF_11 = new AircraftTypeModelCode(
			"YF-11",
			"YF11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YS_11_NAMC = new AircraftTypeModelCode(
			"YS-11 Namc",
			"YS11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YT_25B = new AircraftTypeModelCode(
			"YT-25B",
			"YT25B",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode YUN_12_YUNSHUJI_12 = new AircraftTypeModelCode(
			"Yun-12 Yunshuji-12",
			"YUN12",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_11 = new AircraftTypeModelCode(
			"Z-11",
			"Z11",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_137T_AGRO_TURBO = new AircraftTypeModelCode(
			"Z-137T Agro Turbo",
			"137T",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_142 = new AircraftTypeModelCode(
			"Z-142",
			"Z142",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_142C = new AircraftTypeModelCode(
			"Z-142C",
			"Z142C",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_142CAF = new AircraftTypeModelCode(
			"Z-142CAF",
			"Z142CA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_142L = new AircraftTypeModelCode(
			"Z-142L",
			"Z142L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_143 = new AircraftTypeModelCode(
			"Z-143",
			"Z143",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_242L = new AircraftTypeModelCode(
			"Z-242L",
			"Z242L",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_326_ZLIN = new AircraftTypeModelCode(
			"Z-326 Zlin",
			"Z326",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_50_Z_50_LS = new AircraftTypeModelCode(
			"Z-50 / Z 50 Ls",
			"Z50",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_9_100 = new AircraftTypeModelCode(
			"Z-9-100",
			"Z9100",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode Z_9A_HAITUN_DOLPHIN = new AircraftTypeModelCode(
			"Z-9A Haitun / Dolphin",
			"Z9A",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZENITH_CH_200 = new AircraftTypeModelCode(
			"Zenith-Ch 200",
			"CH200",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZENITH_CH_250 = new AircraftTypeModelCode(
			"Zenith-Ch 250",
			"CH250",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_AEROSTAT = new AircraftTypeModelCode(
			"ZLN Aerostat",
			"ZLNAER",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_AIRTOURER = new AircraftTypeModelCode(
			"ZLN Airtourer",
			"ZLNAIR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_ATLANTIC_I = new AircraftTypeModelCode(
			"ZLN Atlantic I",
			"ZLNATL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_BALLON_LASS = new AircraftTypeModelCode(
			"ZLN Ballon Lass",
			"ZLNBAL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_BARON = new AircraftTypeModelCode(
			"ZLN Baron",
			"ZLNBAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_CHIEFTAIN = new AircraftTypeModelCode(
			"ZLN Chieftain",
			"ZLNCHI",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_CONCORDE = new AircraftTypeModelCode(
			"ZLN Concorde",
			"ZLNCON",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_COOKPOT = new AircraftTypeModelCode(
			"ZLN Cookpot",
			"ZLNCOO",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_DASH_5 = new AircraftTypeModelCode(
			"ZLN Dash 5",
			"ZLNDAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_DOLPHIN_SH = new AircraftTypeModelCode(
			"ZLN Dolphin SH",
			"ZLNDOL",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HARKE_A = new AircraftTypeModelCode(
			"ZLN Harke A",
			"ZLNHAR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HIP_D = new AircraftTypeModelCode(
			"ZLN Hip D",
			"ZLNHPD",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HIP_F = new AircraftTypeModelCode(
			"ZLN Hip F",
			"ZLNHPF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HIP_H_EW = new AircraftTypeModelCode(
			"ZLN Hip H EW",
			"ZLNHPH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HOOK_B = new AircraftTypeModelCode(
			"ZLN Hook B",
			"ZLNHKB",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HOOK_C = new AircraftTypeModelCode(
			"ZLN Hook C",
			"ZLNHKC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_HOUND_C = new AircraftTypeModelCode(
			"ZLN Hound C",
			"ZLNHDC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_LDF = new AircraftTypeModelCode(
			"ZLN LDF",
			"ZLNIDF",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_QUEEN_AIR_65 = new AircraftTypeModelCode(
			"ZLN Queen Air 65",
			"ZLNQUE",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_SEA_COBRA = new AircraftTypeModelCode(
			"ZLN Sea Cobra",
			"ZLNSEA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode ZLN_SOKOL = new AircraftTypeModelCode(
			"ZLN Sokol",
			"ZLNSOK",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1015/20.");
	public static final AircraftTypeModelCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeModelCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private AircraftTypeModelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
