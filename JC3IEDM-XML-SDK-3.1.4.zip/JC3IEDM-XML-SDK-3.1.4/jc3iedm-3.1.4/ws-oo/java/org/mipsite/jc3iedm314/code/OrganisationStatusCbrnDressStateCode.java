/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusCbrnDressStateCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the Mission Oriented Protective Posture (MOPP) status defining the NBC (CBRN) dress code of a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusCbrnDressStateCode> physicalToCode = new HashMap<String, OrganisationStatusCbrnDressStateCode>();

	public static OrganisationStatusCbrnDressStateCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusCbrnDressStateCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusCbrnDressStateCode MOPP_0 = new OrganisationStatusCbrnDressStateCode(
			"MOPP 0",
			"MOPP0",
			"Mask is carried. Individual protection equipment is immediately available.");
	public static final OrganisationStatusCbrnDressStateCode MOPP_1 = new OrganisationStatusCbrnDressStateCode(
			"MOPP 1",
			"MOPP1",
			"Mask is carried. Suit worn, boots and gloves are carried.");
	public static final OrganisationStatusCbrnDressStateCode MOPP_2 = new OrganisationStatusCbrnDressStateCode(
			"MOPP 2",
			"MOPP2",
			"Mask is carried. Suit and boots worn, gloves are carried.");
	public static final OrganisationStatusCbrnDressStateCode MOPP_3 = new OrganisationStatusCbrnDressStateCode(
			"MOPP 3",
			"MOPP3",
			"Mask is carried. Suit, boots and gloves are worn.");
	public static final OrganisationStatusCbrnDressStateCode MOPP_READY = new OrganisationStatusCbrnDressStateCode(
			"MOPP Ready",
			"MOPPRY",
			"Mask is carried. First set individual protection equipment is available within 2 hours, second set individual protection equipment is available within 6 hours.");

	private OrganisationStatusCbrnDressStateCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
