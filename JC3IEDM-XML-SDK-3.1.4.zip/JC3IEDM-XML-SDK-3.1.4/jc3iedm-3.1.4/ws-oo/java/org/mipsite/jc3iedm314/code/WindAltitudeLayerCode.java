/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class WindAltitudeLayerCode extends CodeDomain {

	public static String getComment() {
		return "The specific value used to indicate the class of the altitude for a specific set of reported wind data.";
	}

	private static HashMap<String, WindAltitudeLayerCode> physicalToCode = new HashMap<String, WindAltitudeLayerCode>();

	public static WindAltitudeLayerCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<WindAltitudeLayerCode> getCodes() {
		return physicalToCode.values();
	}

	public static final WindAltitudeLayerCode _10_000_METRES = new WindAltitudeLayerCode(
			"10,000 metres",
			"10",
			"Reported wind data are valid for altitudes greater than or equal to 8000 and less than 10000 metres above ground.");
	public static final WindAltitudeLayerCode _12_000_METRES = new WindAltitudeLayerCode(
			"12,000 metres",
			"12",
			"Reported wind data are valid for altitudes greater than or equal to 10000 and less than 12000 metres above ground.");
	public static final WindAltitudeLayerCode _14_000_METRES = new WindAltitudeLayerCode(
			"14,000 metres",
			"14",
			"Reported wind data are valid for altitudes between 12000 and less than 14000 metres above ground.");
	public static final WindAltitudeLayerCode _16_000_METRES = new WindAltitudeLayerCode(
			"16,000 metres",
			"16",
			"Reported wind data are valid for altitudes greater than or equal to 14000 and less than 16000 metres above ground.");
	public static final WindAltitudeLayerCode _18_000_METRES = new WindAltitudeLayerCode(
			"18,000 metres",
			"18",
			"Reported wind data are valid for altitudes greater than or equal to 16000 and less than 18000 metres above ground.");
	public static final WindAltitudeLayerCode _2000_METRES = new WindAltitudeLayerCode(
			"2000 metres",
			"2",
			"Reported wind data are valid for altitudes less than 2000 metres above ground.");
	public static final WindAltitudeLayerCode _20_000_METRES = new WindAltitudeLayerCode(
			"20,000 metres",
			"20",
			"Reported wind data are valid for altitudes greater than or equal to 18000 and less than 20000 metres above ground.");
	public static final WindAltitudeLayerCode _22_000_METRES = new WindAltitudeLayerCode(
			"22,000 metres",
			"22",
			"Reported wind data are valid for altitudes greater than or equal to 20000 and less than 22000 metres above ground.");
	public static final WindAltitudeLayerCode _24_000_METRES = new WindAltitudeLayerCode(
			"24,000 metres",
			"24",
			"Reported wind data are valid for altitudes greater than or equal to 22000 and less than 24000 metres above ground.");
	public static final WindAltitudeLayerCode _26_000_METRES = new WindAltitudeLayerCode(
			"26,000 metres",
			"26",
			"Reported wind data are valid for altitudes greater than or equal to 24000 and less than 26000 metres above ground.");
	public static final WindAltitudeLayerCode _28_000_METRES = new WindAltitudeLayerCode(
			"28,000 metres",
			"28",
			"Reported wind data are valid for altitudes greater than or equal to 26000 and less than 28000 metres above ground.");
	public static final WindAltitudeLayerCode _30_000_METRES = new WindAltitudeLayerCode(
			"30,000 metres",
			"30",
			"Reported wind data are valid for altitudes greater than or equal to 28000 and less than 30000 metres above ground.");
	public static final WindAltitudeLayerCode _4000_METRES = new WindAltitudeLayerCode(
			"4000 metres",
			"4",
			"Reported wind data are valid for altitudes greater than or equal to 2000 and less than 4000 metres above ground.");
	public static final WindAltitudeLayerCode _6000_METRES = new WindAltitudeLayerCode(
			"6000 metres",
			"6",
			"Reported wind data are valid for altitudes greater than or equal to 4000 and less than 6000 metres above ground.");
	public static final WindAltitudeLayerCode _8000_METRES = new WindAltitudeLayerCode(
			"8000 metres",
			"8",
			"Reported wind data are valid for altitudes greater than or equal to 6000 and less than 8000 metres above ground.");

	private WindAltitudeLayerCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
