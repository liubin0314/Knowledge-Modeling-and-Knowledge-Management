/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EvacuationDestinationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the disposition of casualties according to the destination of evacuation.";
	}

	private static HashMap<String, EvacuationDestinationCode> physicalToCode = new HashMap<String, EvacuationDestinationCode>();

	public static EvacuationDestinationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EvacuationDestinationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EvacuationDestinationCode HOME_OR_HOLDING_COUNTRY = new EvacuationDestinationCode(
			"Home or holding country",
			"HOMHOL",
			"Individual was evacuated to home or holding country.");
	public static final EvacuationDestinationCode MEDICAL_FACILITY_IN_THEATRE = new EvacuationDestinationCode(
			"Medical facility in theatre",
			"MEDTHT",
			"Individual was evacuated to a medical facility in theatre.");
	public static final EvacuationDestinationCode RETURNED_TO_DUTY = new EvacuationDestinationCode(
			"Returned to duty",
			"RETDTY",
			"Individual was returned to duty.");

	private EvacuationDestinationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
