/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationPlanOrderAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the responsibility of the specific ORGANISATION with respect to the specific PLAN-ORDER.";
	}

	private static HashMap<String, OrganisationPlanOrderAssociationCategoryCode> physicalToCode = new HashMap<String, OrganisationPlanOrderAssociationCategoryCode>();

	public static OrganisationPlanOrderAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationPlanOrderAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationPlanOrderAssociationCategoryCode IS_APPROVING_AUTHORITY_FOR = new OrganisationPlanOrderAssociationCategoryCode(
			"Is approving authority for",
			"APPR",
			"The specific ORGANISATION is empowered to approve the PLAN-ORDER.");
	public static final OrganisationPlanOrderAssociationCategoryCode IS_RESPONSIBLE_FOR_DISTRIBUTION_OF = new OrganisationPlanOrderAssociationCategoryCode(
			"Is responsible for distribution of",
			"DISTR",
			"The specific ORGANISATION is responsible for delivery of the PLAN-ORDER to the intended recipients.");
	public static final OrganisationPlanOrderAssociationCategoryCode IS_RESPONSIBLE_FOR_PREPARATION_OF = new OrganisationPlanOrderAssociationCategoryCode(
			"Is responsible for preparation of",
			"PREP",
			"The specific ORGANISATION is responsible creating the contents of the PLAN-ORDER.");
	public static final OrganisationPlanOrderAssociationCategoryCode HAS_EXECUTION_OVERSIGHT_OF = new OrganisationPlanOrderAssociationCategoryCode(
			"Has execution oversight of",
			"EXEC",
			"The specific ORGANISATION is responsible for controlling the execution of the PLAN-ORDER.");
	public static final OrganisationPlanOrderAssociationCategoryCode IS_THE_ISSUING_HEADQUARTERS_FOR = new OrganisationPlanOrderAssociationCategoryCode(
			"Is the issuing headquarters for",
			"ISSHQ",
			"The specific ORGANISATION is the issuing headquarters for the PLAN-ORDER.");

	private OrganisationPlanOrderAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
