/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldLandStoppingPowerCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the stopping power of a particular MINEFIELD-LAND.";
	}

	private static HashMap<String, MinefieldLandStoppingPowerCode> physicalToCode = new HashMap<String, MinefieldLandStoppingPowerCode>();

	public static MinefieldLandStoppingPowerCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldLandStoppingPowerCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldLandStoppingPowerCode HIGH = new MinefieldLandStoppingPowerCode(
			"High",
			"HIGH",
			"Minefield to be covered by light direct fire. Mines per square meter: 0.004.");
	public static final MinefieldLandStoppingPowerCode LOW = new MinefieldLandStoppingPowerCode(
			"Low",
			"LOW",
			"Harassment used with other munitions. Mines per square meter: 0.001.");
	public static final MinefieldLandStoppingPowerCode MEDIUM = new MinefieldLandStoppingPowerCode(
			"Medium",
			"MEDIUM",
			"Minefield to be covered by light direct fire. Mines per square meter: 0.002.");

	private MinefieldLandStoppingPowerCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
