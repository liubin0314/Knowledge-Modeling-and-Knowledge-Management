/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeDesignRangeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the designed range of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeDesignRangeCode> physicalToCode = new HashMap<String, AircraftTypeDesignRangeCode>();

	public static AircraftTypeDesignRangeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeDesignRangeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeDesignRangeCode LONG = new AircraftTypeDesignRangeCode(
			"Long",
			"LONG",
			"Distances above 4,630 kilometres.");
	public static final AircraftTypeDesignRangeCode MEDIUM = new AircraftTypeDesignRangeCode(
			"Medium",
			"MEDIUM",
			"Distances between 1,852 to 4,630 kilometres.");
	public static final AircraftTypeDesignRangeCode NOT_KNOWN = new AircraftTypeDesignRangeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeDesignRangeCode SHORT = new AircraftTypeDesignRangeCode(
			"Short",
			"SHORT",
			"Distances less than 1,852 kilometres.");

	private AircraftTypeDesignRangeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
