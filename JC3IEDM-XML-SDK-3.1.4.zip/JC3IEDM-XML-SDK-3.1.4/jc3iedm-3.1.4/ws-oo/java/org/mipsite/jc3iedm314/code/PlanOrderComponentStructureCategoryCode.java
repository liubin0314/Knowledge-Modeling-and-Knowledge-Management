/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderComponentStructureCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between a subject PLAN-ORDER-COMPONENT and an object PLAN-ORDER-COMPONENT in a specific PLAN-ORDER-COMPONENT-STRUCTURE.";
	}

	private static HashMap<String, PlanOrderComponentStructureCategoryCode> physicalToCode = new HashMap<String, PlanOrderComponentStructureCategoryCode>();

	public static PlanOrderComponentStructureCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderComponentStructureCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderComponentStructureCategoryCode IS_DISSOCIATED_FROM = new PlanOrderComponentStructureCategoryCode(
			"Is dissociated from",
			"ISDISS",
			"The relationship of the subject PLAN-ORDER-COMPONENT to the object PLAN-ORDER-COMPONENT is deleted.");
	public static final PlanOrderComponentStructureCategoryCode IS_PARENT_OF = new PlanOrderComponentStructureCategoryCode(
			"Is parent of",
			"ISPRNT",
			"The subject PLAN-ORDER-COMPONENT is the general topic for which the object PLAN-ORDER-COMPONENT is a sub-topic.");
	public static final PlanOrderComponentStructureCategoryCode IS_REPLACED_BY = new PlanOrderComponentStructureCategoryCode(
			"Is replaced by",
			"ISREPL",
			"The subject PLAN-ORDER-COMPONENT is replaced in its entirety by the object PLAN-ORDER-COMPONENT. The replacement removes all subordinate components of the subject PLAN-ORDER-COMPONENT.");

	private PlanOrderComponentStructureCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
