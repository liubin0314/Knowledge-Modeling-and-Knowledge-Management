/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a restriction or other qualification applicable to a specific ACTION-OBJECTIVE for a specific ACTION.";
	}

	private static HashMap<String, ActionObjectiveQualifierCode> physicalToCode = new HashMap<String, ActionObjectiveQualifierCode>();

	public static ActionObjectiveQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveQualifierCode AUTHORISED = new ActionObjectiveQualifierCode(
			"Authorised",
			"AUTH",
			"The ACTION-OBJECTIVE is authorised without restriction.");
	public static final ActionObjectiveQualifierCode DO_NOT_ATTACK = new ActionObjectiveQualifierCode(
			"Do not attack",
			"DONTAT",
			"The specific ACTION-OBJECTIVE (e.g. hospitals or friendly forces) must not be attacked.");
	public static final ActionObjectiveQualifierCode NO_EXPLOITATION_EAST_OF_LINE = new ActionObjectiveQualifierCode(
			"No exploitation east of line",
			"NEEL",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no exploitation east of it.");
	public static final ActionObjectiveQualifierCode NO_EXPLOITATION_NORTH_OF_LINE = new ActionObjectiveQualifierCode(
			"No exploitation north of line",
			"NENL",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no exploitation north of it.");
	public static final ActionObjectiveQualifierCode NO_EXPLOITATION_SOUTH_OF_LINE = new ActionObjectiveQualifierCode(
			"No exploitation south of line",
			"NESL",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no exploitation south of it.");
	public static final ActionObjectiveQualifierCode NO_EXPLOITATION_WEST_OF_LINE = new ActionObjectiveQualifierCode(
			"No exploitation west of line",
			"NEWL",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no exploitation west of it.");
	public static final ActionObjectiveQualifierCode NOT_AUTHORISED = new ActionObjectiveQualifierCode(
			"Not authorised",
			"NOTA",
			"The specific ACTION-OBJECTIVE is not authorised.");
	public static final ActionObjectiveQualifierCode STAY_ABOVE = new ActionObjectiveQualifierCode(
			"Stay above",
			"STAYAB",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no movement below or within it.");
	public static final ActionObjectiveQualifierCode STAY_BELOW = new ActionObjectiveQualifierCode(
			"Stay below",
			"STAYBL",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no movement above or within it.");
	public static final ActionObjectiveQualifierCode STAY_INSIDE = new ActionObjectiveQualifierCode(
			"Stay inside",
			"STAYIN",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no movement outside it.");
	public static final ActionObjectiveQualifierCode STAY_OUTSIDE = new ActionObjectiveQualifierCode(
			"Stay outside",
			"STAYOT",
			"The specific ACTION-OBJECTIVE is authorised with the restriction that there is to be no movement inside it.");

	private ActionObjectiveQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
