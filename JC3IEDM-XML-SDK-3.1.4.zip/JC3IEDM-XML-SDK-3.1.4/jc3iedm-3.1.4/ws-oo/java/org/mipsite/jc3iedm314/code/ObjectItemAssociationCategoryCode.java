/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between the subject OBJECT-ITEM and the object OBJECT-ITEM in a specific OBJECT-ITEM-ASSOCIATION.";
	}

	private static HashMap<String, ObjectItemAssociationCategoryCode> physicalToCode = new HashMap<String, ObjectItemAssociationCategoryCode>();

	public static ObjectItemAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAssociationCategoryCode ADMINISTERS = new ObjectItemAssociationCategoryCode(
			"Administers",
			"ADMINS",
			"The subject ORGANISATION is responsible for the administration of the object FACILITY.");
	public static final ObjectItemAssociationCategoryCode AUGMENTS = new ObjectItemAssociationCategoryCode(
			"Augments",
			"AUGMNT",
			"The subject PERSON extends the capacity of the object PERSON in his tasks.");
	public static final ObjectItemAssociationCategoryCode COMMAND_AND_CONTROL = new ObjectItemAssociationCategoryCode(
			"Command and control",
			"CMDCTL",
			"The subject ORGANISATION has a command and control association with the object ORGANISATION.");
	public static final ObjectItemAssociationCategoryCode CONSUMES = new ObjectItemAssociationCategoryCode(
			"Consumes",
			"CONSUM",
			"The subject ORGANISATION expends the object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode CONTAINS = new ObjectItemAssociationCategoryCode(
			"Contains",
			"CONTNS",
			"A subject MATERIEL holds an object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode CONTROLS = new ObjectItemAssociationCategoryCode(
			"Controls",
			"CONTRL",
			"The subject OBJECT-ITEM has authority over the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode COORDINATES_USE_OF = new ObjectItemAssociationCategoryCode(
			"Coordinates use of",
			"COORDN",
			"The subject ORGANISATION arranges the scheduling for the object FACILITY.");
	public static final ObjectItemAssociationCategoryCode DETECTS = new ObjectItemAssociationCategoryCode(
			"Detects",
			"DETECT",
			"The subject OBJECT-ITEM perceives the object OBJECT-ITEM as being of possible military interest but without being able to recognise it.");
	public static final ObjectItemAssociationCategoryCode DISESTABLISHES = new ObjectItemAssociationCategoryCode(
			"Disestablishes",
			"DISE",
			"The subject ORGANISATION terminates the function or physical presence of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode EMPLOYS = new ObjectItemAssociationCategoryCode(
			"Employs",
			"EMPLOY",
			"The subject OBJECT-ITEM is the permanent or temporary user of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode ENCLOSES = new ObjectItemAssociationCategoryCode(
			"Encloses",
			"ENCLOS",
			"The subject OBJECT-ITEM encompasses the whole of object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode ESTABLISHES = new ObjectItemAssociationCategoryCode(
			"Establishes",
			"ESTA",
			"The subject ORGANISATION sets up the function or physical presence of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode EXPLOITS = new ObjectItemAssociationCategoryCode(
			"Exploits",
			"EXPLOT",
			"The subject PERSON takes advantage of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode FIRE_UNIT_AND_COMBAT_SUPPORT = new ObjectItemAssociationCategoryCode(
			"Fire unit and combat support",
			"FUCS",
			"The subject ORGANISATION has a fire unit and combat support association with the object ORGANISATION.");
	public static final ObjectItemAssociationCategoryCode HAS_UNDER_COMMAND_FOR_ADMIN = new ObjectItemAssociationCategoryCode(
			"Has under command for admin",
			"HSADMI",
			"The subject ORGANISATION has command responsibility for all administrative and logistic services provided to the object ORGANISATION.");
	public static final ObjectItemAssociationCategoryCode HAS_ON_ASSIGNMENT = new ObjectItemAssociationCategoryCode(
			"Has on assignment",
			"HSASGN",
			"The subject ORGANISATION has the object PERSON assigned on a long-term basis.");
	public static final ObjectItemAssociationCategoryCode HAS_ON_ATTACHMENT = new ObjectItemAssociationCategoryCode(
			"Has on attachment",
			"HSATCH",
			"The subject ORGANISATION has the object PERSON assigned on a temporary basis.");
	public static final ObjectItemAssociationCategoryCode HAS_AS_A_CONSULTANT = new ObjectItemAssociationCategoryCode(
			"Has as a consultant",
			"HSCNSL",
			"The subject ORGANISATION uses the object PERSON to provide expert of professional advice.");
	public static final ObjectItemAssociationCategoryCode HAS_ITS_FUNCTION_PHYSICALLY_EMBODIED_BY = new ObjectItemAssociationCategoryCode(
			"Has its function physically embodied by",
			"HSFPEM",
			"The subject CONTROL-FEATURE has its function embodied by the object FACILITY or MATERIEL.");
	public static final ObjectItemAssociationCategoryCode HAS_AS_A_LIAISON_OFFICER = new ObjectItemAssociationCategoryCode(
			"Has as a liaison officer",
			"HSLOFF",
			"The subject ORGANISATION has in place the object PERSON on a temporary basis with the objective of coordinating actions.");
	public static final ObjectItemAssociationCategoryCode HAS_UNDER_COMMAND_FOR_MAINT = new ObjectItemAssociationCategoryCode(
			"Has under command for maint",
			"HSMAIN",
			"The subject ORGANISATION has command responsibility for daily maintenance services provided to the object ORGANISATION. The object ORGANISATION retains full responsibility for all other administrative functions.");
	public static final ObjectItemAssociationCategoryCode HAS_AS_A_MEMBER = new ObjectItemAssociationCategoryCode(
			"Has as a member",
			"HSMMBR",
			"The subject ORGANISATION has as a member the object PERSON.");
	public static final ObjectItemAssociationCategoryCode HAS_AS_AN_OPERATIVE = new ObjectItemAssociationCategoryCode(
			"Has as an operative",
			"HSOPER",
			"The subject ORGANISATION uses the object PERSON as a secret or trusted agent.");
	public static final ObjectItemAssociationCategoryCode HAS_AS_POINT_OF_CONTACT = new ObjectItemAssociationCategoryCode(
			"Has as point of contact",
			"HSPOC",
			"The subject ORGANISATION has on call the object PERSON with the objective of coordinating details for each element of support required.");
	public static final ObjectItemAssociationCategoryCode INSTALLS = new ObjectItemAssociationCategoryCode(
			"Installs",
			"INSTAL",
			"The subject ORGANISATION or PERSON places the object MATERIEL in position and connects or adjusts it for use.");
	public static final ObjectItemAssociationCategoryCode INTERSECTS = new ObjectItemAssociationCategoryCode(
			"Intersects",
			"INTRST",
			"The subject CONTROL-FEATURE cuts across or overlaps the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_ACCOUNTING_AUTHORITY_FOR = new ObjectItemAssociationCategoryCode(
			"Is accounting authority for",
			"ISACAU",
			"The subject OBJECT-ITEM has the object OBJECT-ITEM on its account.");
	public static final ObjectItemAssociationCategoryCode IS_AFFECTED_BY = new ObjectItemAssociationCategoryCode(
			"Is affected by",
			"ISAFBY",
			"The subject FACILITY is affected by the object FEATURE (applies to METEOROLOGICAL-FEATURE).");
	public static final ObjectItemAssociationCategoryCode IS_ASSIGNED_TO = new ObjectItemAssociationCategoryCode(
			"Is assigned to",
			"ISASTO",
			"The subject ORGANISATION is designated for duty at the object FACILITY.");
	public static final ObjectItemAssociationCategoryCode IS_AUNT_OF = new ObjectItemAssociationCategoryCode(
			"Is aunt of",
			"ISAUNT",
			"The subject PERSON is the aunt of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_AUTHORISED_TO = new ObjectItemAssociationCategoryCode(
			"Is authorised to",
			"ISAUTO",
			"The subject FACILITY, ORGANISATION or PERSON is granted formal entitlement to the object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode IS_BOUNDED_IN_THE_FRONT_BY = new ObjectItemAssociationCategoryCode(
			"Is bounded in the front by",
			"ISBDFR",
			"The subject ORGANISATION has part or all of its frontal boundary specified by the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_BOUNDED_ON_THE_LEFT_BY = new ObjectItemAssociationCategoryCode(
			"Is bounded on the left by",
			"ISBDLE",
			"The subject ORGANISATION has part or all of its left-flank boundary specified by the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_BOUNDED_IN_THE_REAR_BY = new ObjectItemAssociationCategoryCode(
			"Is bounded in the rear by",
			"ISBDRR",
			"The subject ORGANISATION has part or all of its rear boundary specified by the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_BOUNDED_ON_THE_RIGHT_BY = new ObjectItemAssociationCategoryCode(
			"Is bounded on the right by",
			"ISBDRT",
			"The subject ORGANISATION has part or all of its right-flank boundary specified by the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_BOUNDED_BY = new ObjectItemAssociationCategoryCode(
			"Is bounded by",
			"ISBOND",
			"The subject OBJECT-ITEM has its boundaries defined by the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_BROTHER_OF = new ObjectItemAssociationCategoryCode(
			"Is brother of",
			"ISBRTH",
			"The subject PERSON is the brother of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_CONNECTED_TO = new ObjectItemAssociationCategoryCode(
			"Is connected to",
			"ISCNNC",
			"The subject FACILITY is connected to the object FACILITY (e.g. a barracks connected to a command post).");
	public static final ObjectItemAssociationCategoryCode IS_CONVEYANCE_FOR = new ObjectItemAssociationCategoryCode(
			"Is conveyance for",
			"ISCNVY",
			"The subject MATERIEL is the conveyance for the specified object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode IS_CONSTRAINED_OR_ENABLED_BY = new ObjectItemAssociationCategoryCode(
			"Is constrained or enabled by",
			"ISCONS",
			"The subject OBJECT-ITEM operates in accordance with procedures implied by the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_COUSIN_OF = new ObjectItemAssociationCategoryCode(
			"Is cousin of",
			"ISCOUS",
			"The subject PERSON is the cousin of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_CAPTOR_OF = new ObjectItemAssociationCategoryCode(
			"Is captor of",
			"ISCPTR",
			"The subject ORGANISATION or PERSON has taken possession, as a result of forceful means, of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_CAPTOR_OF_SPACE_DEFINED_BY = new ObjectItemAssociationCategoryCode(
			"Is captor of space defined by",
			"ISCPTS",
			"The subject ORGANISATION has taken possession, as a result of forceful means, of the space associated with the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_DAUGHTER_OF = new ObjectItemAssociationCategoryCode(
			"Is daughter of",
			"ISDAUG",
			"The subject PERSON is the daughter of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_END_OF = new ObjectItemAssociationCategoryCode(
			"Is end of",
			"ISEND",
			"A relationship between CONTROL-FEATUREs that denotes that the subject CONTROL-FEATURE defines an end point or objective line for the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_FATHER_OF = new ObjectItemAssociationCategoryCode(
			"Is father of",
			"ISFATH",
			"The subject PERSON is the father of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_FASTENED_TO = new ObjectItemAssociationCategoryCode(
			"Is fastened to",
			"ISFSTN",
			"A subject MATERIEL is temporarily attached to an object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode IS_FATHER_IN_LAW_OF = new ObjectItemAssociationCategoryCode(
			"Is father-in-law of",
			"ISFTLW",
			"The subject PERSON is the father-in-law of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_GRANDDAUGHTER_OF = new ObjectItemAssociationCategoryCode(
			"Is granddaughter of",
			"ISGRDD",
			"The subject PERSON is the granddaughter of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_GRANDFATHER_OF = new ObjectItemAssociationCategoryCode(
			"Is grandfather of",
			"ISGRDF",
			"The subject PERSON is the grandfather of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_GRANDMOTHER_OF = new ObjectItemAssociationCategoryCode(
			"Is grandmother of",
			"ISGRDM",
			"The subject PERSON is the grandmother of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_GRANDSON_OF = new ObjectItemAssociationCategoryCode(
			"Is grandson of",
			"ISGRDS",
			"The subject PERSON is the grandson of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_HUSBAND_OF = new ObjectItemAssociationCategoryCode(
			"Is husband of",
			"ISHUSB",
			"The subject PERSON is the husband of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_LEGAL_FATHER_OF = new ObjectItemAssociationCategoryCode(
			"Is legal father of",
			"ISLGLF",
			"The subject PERSON is the legal father of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_LEGAL_MOTHER_OF = new ObjectItemAssociationCategoryCode(
			"Is legal mother of",
			"ISLGLM",
			"The subject PERSON is the legal mother of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_LOADED_ON = new ObjectItemAssociationCategoryCode(
			"Is loaded on",
			"ISLOAD",
			"A subject MATERIEL is loaded on the object MATERIEL.");
	public static final ObjectItemAssociationCategoryCode IS_TO_THE_LEFT_OF = new ObjectItemAssociationCategoryCode(
			"Is to the left of",
			"ISLOF",
			"The subject ORGANISATION is located on the left side of the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_MOTHER_OF = new ObjectItemAssociationCategoryCode(
			"Is mother of",
			"ISMOTH",
			"The subject PERSON is the mother of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_MOTHER_IN_LAW_OF = new ObjectItemAssociationCategoryCode(
			"Is mother-in-law of",
			"ISMTLW",
			"The subject PERSON is the mother-in-law of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_NEPHEW_OF = new ObjectItemAssociationCategoryCode(
			"Is nephew of",
			"ISNEPH",
			"The subject PERSON is the nephew of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_NIECE_OF = new ObjectItemAssociationCategoryCode(
			"Is niece of",
			"ISNIEC",
			"The subject PERSON is the niece of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_OWNER_OF = new ObjectItemAssociationCategoryCode(
			"Is owner of",
			"ISOWNR",
			"The subject OBJECT-ITEM is the owner of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_PARTIALLY_BOUNDED_BY = new ObjectItemAssociationCategoryCode(
			"Is partially bounded by",
			"ISPABD",
			"The subject OBJECT-ITEM is partially bounded by the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_PART_OF = new ObjectItemAssociationCategoryCode(
			"Is part of",
			"ISPART",
			"The subject OBJECT-ITEM is a constituent of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_A_PEER_OF = new ObjectItemAssociationCategoryCode(
			"Is a peer of",
			"ISPEER",
			"The subject PERSON has equal standing with the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_PHYSICALLY_PARTIALLY_REPRESENTED_BY_ALL_OF = new ObjectItemAssociationCategoryCode(
			"Is physically partially represented by all of",
			"ISPPRA",
			"Part of the subject CONTROL-FEATURE is described or delineated by the whole of the object GEOGRAPHIC-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_PHYSICALLY_PARTIALLY_REPRESENTED_BY_PART_OF = new ObjectItemAssociationCategoryCode(
			"Is physically partially represented by part of",
			"ISPPRP",
			"Part of the subject CONTROL-FEATURE is described or delineated by part of the object GEOGRAPHIC-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_PHYSICALLY_REPRESENTED_IN_ITS_ENTIRETY_BY_ALL_OF = new ObjectItemAssociationCategoryCode(
			"Is physically represented in its entirety by all of",
			"ISPREA",
			"The whole of the subject CONTROL-FEATURE is described by the whole of the object GEOGRAPHIC-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_PHYSICALLY_REPRESENTED_IN_ITS_ENTIRETY_BY_PART_OF = new ObjectItemAssociationCategoryCode(
			"Is physically represented in its entirety by part of",
			"ISPREP",
			"The whole of the subject CONTROL-FEATURE is described by part of the object GEOGRAPHIC-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_PROTECTED_BY = new ObjectItemAssociationCategoryCode(
			"Is protected by",
			"ISPRTC",
			"The subject OBJECT-ITEM is kept from harm or attack by the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_TO_THE_RIGHT_OF = new ObjectItemAssociationCategoryCode(
			"Is to the right of",
			"ISROF",
			"The subject ORGANISATION is located on the right side of the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_SUCCESSOR_OF = new ObjectItemAssociationCategoryCode(
			"Is successor of",
			"ISSCSR",
			"A relationship between CONTROL-FEATUREs that denotes an ordering in which the subject CONTROL-FEATURE is the successor of the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_SECONDARY_TO = new ObjectItemAssociationCategoryCode(
			"Is secondary to",
			"ISSECN",
			"A subject OBJECT-ITEM is designated as secondary to an object OBJECT-ITEM in the order that it is expected to be used.");
	public static final ObjectItemAssociationCategoryCode IS_SISTER_OF = new ObjectItemAssociationCategoryCode(
			"Is sister of",
			"ISSIST",
			"The subject PERSON is the sister of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_SITUATED_IN = new ObjectItemAssociationCategoryCode(
			"Is situated in",
			"ISSITU",
			"The subject OBJECT-ITEM is located within the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_SON_OF = new ObjectItemAssociationCategoryCode(
			"Is son of",
			"ISSON",
			"The subject PERSON is the son of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_SPONSOR_FOR = new ObjectItemAssociationCategoryCode(
			"Is sponsor for",
			"ISSPNR",
			"The subject ORGANISATION provides resources in support of the object FACILITY without being responsible for its administration.");
	public static final ObjectItemAssociationCategoryCode IS_SUPPLIED_BY = new ObjectItemAssociationCategoryCode(
			"Is supplied by",
			"ISSPPL",
			"The subject OBJECT-ITEM draws its provisions from the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode IS_SUPPORTED_BY = new ObjectItemAssociationCategoryCode(
			"Is supported by",
			"ISSPRT",
			"The subject OBJECT-ITEM depends on the object OBJECT-ITEM for its logistics or other assistance in the course of its functioning.");
	public static final ObjectItemAssociationCategoryCode IS_START_OF = new ObjectItemAssociationCategoryCode(
			"Is start of",
			"ISSTRT",
			"A relationship between CONTROL-FEATUREs that denotes that the subject CONTROL-FEATURE defines a starting point or departure line for the object CONTROL-FEATURE.");
	public static final ObjectItemAssociationCategoryCode IS_SUPERIOR_OF = new ObjectItemAssociationCategoryCode(
			"Is superior of",
			"ISSUPR",
			"The subject PERSON is higher in rank, station or authority than the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_UNDER_COMMAND_OF = new ObjectItemAssociationCategoryCode(
			"Is under command of",
			"ISUCOM",
			"The subject ORGANISATION or PERSON is under control or authority of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_UNCLE_OF = new ObjectItemAssociationCategoryCode(
			"Is uncle of",
			"ISUNCL",
			"The subject PERSON is the uncle of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode IS_WIFE_OF = new ObjectItemAssociationCategoryCode(
			"Is wife of",
			"ISWIFE",
			"The subject PERSON is the wife of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode MAINTAINS = new ObjectItemAssociationCategoryCode(
			"Maintains",
			"MAINTN",
			"The subject OBJECT-ITEM keeps the object MATERIEL in good repair or efficiency on a routine basis.");
	public static final ObjectItemAssociationCategoryCode NOT_KNOWN = new ObjectItemAssociationCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ObjectItemAssociationCategoryCode NOT_OTHERWISE_SPECIFIED = new ObjectItemAssociationCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ObjectItemAssociationCategoryCode OBSERVES = new ObjectItemAssociationCategoryCode(
			"Observes",
			"OBSRVS",
			"The subject OBJECT-ITEM perceives the object OBJECT-ITEM by visual or electro-optical imaging means.");
	public static final ObjectItemAssociationCategoryCode OPERATES = new ObjectItemAssociationCategoryCode(
			"Operates",
			"OPERAT",
			"The subject ORGANISATION is responsible for the operation of the object FACILITY.");
	public static final ObjectItemAssociationCategoryCode POSSESSES = new ObjectItemAssociationCategoryCode(
			"Possesses",
			"POSESS",
			"The subject ORGANISATION has physical control of the object MATERIEL with or without authorisation.");
	public static final ObjectItemAssociationCategoryCode PARTIALLY_ENCLOSES = new ObjectItemAssociationCategoryCode(
			"Partially encloses",
			"PRTENC",
			"The subject OBJECT-ITEM encompasses part the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode PROVIDES_LOGISTIC_SERVICES_TO = new ObjectItemAssociationCategoryCode(
			"Provides logistic services to",
			"PRVLOG",
			"The subject ORGANISATION provides materiel and transportation for the sustainment and movement of the object ORGANISATION.");
	public static final ObjectItemAssociationCategoryCode RATES_OR_ASSESSES = new ObjectItemAssociationCategoryCode(
			"Rates or assesses",
			"RATES",
			"The subject PERSON provides performance evaluations of the object PERSON.");
	public static final ObjectItemAssociationCategoryCode REPAIRS = new ObjectItemAssociationCategoryCode(
			"Repairs",
			"REPAIR",
			"The subject OBJECT-ITEM restores the object MATERIEL to sound condition after damage or failure.");
	public static final ObjectItemAssociationCategoryCode REPORTS_TO = new ObjectItemAssociationCategoryCode(
			"Reports to",
			"REPORT",
			"The subject PERSON is under the direction of the object PERSON for tasking.");
	public static final ObjectItemAssociationCategoryCode SERVES_AS = new ObjectItemAssociationCategoryCode(
			"Serves as",
			"SERVES",
			"The subject OBJECT-ITEM is used for a role that is characterised by the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode SUPPLEMENTARY = new ObjectItemAssociationCategoryCode(
			"Supplementary",
			"SUPPL",
			"The subject ORGANISATION and the object ORGANISATION have additional relationships other than command and control or fire unit and combat support or administrative and combat service support relationships.");
	public static final ObjectItemAssociationCategoryCode SUPPORTS = new ObjectItemAssociationCategoryCode(
			"Supports",
			"SUPPRT",
			"The subject ORGANISATION aids, protects, complements, or sustains the object ORGANISATION.");
	public static final ObjectItemAssociationCategoryCode TRANSPORTS = new ObjectItemAssociationCategoryCode(
			"Transports",
			"TRNSPT",
			"The subject OBJECT-ITEM is responsible for the movement of the object OBJECT-ITEM.");
	public static final ObjectItemAssociationCategoryCode USES = new ObjectItemAssociationCategoryCode(
			"Uses",
			"USES",
			"The subject OBJECT-ITEM uses the object OBJECT-ITEM for its intended function while it is controlled by another organisation.");

	private ObjectItemAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
