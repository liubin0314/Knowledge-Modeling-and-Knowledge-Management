/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusReadinessCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that gives the readiness level of an ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusReadinessCode> physicalToCode = new HashMap<String, OrganisationStatusReadinessCode>();

	public static OrganisationStatusReadinessCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusReadinessCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusReadinessCode AIRBORNE_ALERT = new OrganisationStatusReadinessCode(
			"Airborne alert",
			"AIRALR",
			"A readiness level of an ORGANISATION wherein combat-equipped aircraft are airborne and ready for immediate action.");
	public static final OrganisationStatusReadinessCode BATTLE_STATIONS = new OrganisationStatusReadinessCode(
			"Battle stations",
			"BTLSTN",
			"A readiness level of an ORGANISATION where the aircrews will be in cockpits of their fighters and be capable of starting their engines and becoming airborne in the minimum practicable time.");
	public static final OrganisationStatusReadinessCode GROUND_ALERT = new OrganisationStatusReadinessCode(
			"Ground alert",
			"GRDALR",
			"A readiness level of an ORGANISATION wherein aircraft on the ground/deck are fully serviced and armed, with combat crews in readiness to take off within a specified short period of time (usually 15 minutes) after receipt of a mission order.");
	public static final OrganisationStatusReadinessCode NOT_KNOWN = new OrganisationStatusReadinessCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusReadinessCode NOT_OTHERWISE_SPECIFIED = new OrganisationStatusReadinessCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final OrganisationStatusReadinessCode NOT_READY_WITHIN_12_HOURS = new OrganisationStatusReadinessCode(
			"Not ready within 12 hours",
			"NRD12H",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION cannot be ready within 12 hours.");
	public static final OrganisationStatusReadinessCode READINESS_STATE_1 = new OrganisationStatusReadinessCode(
			"Readiness state 1",
			"RDNS1",
			"Readiness state 1, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_2 = new OrganisationStatusReadinessCode(
			"Readiness state 2",
			"RDNS2",
			"Readiness state 2, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_3 = new OrganisationStatusReadinessCode(
			"Readiness state 3",
			"RDNS3",
			"Readiness state 3, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_4 = new OrganisationStatusReadinessCode(
			"Readiness state 4",
			"RDNS4",
			"Readiness state 4, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_5 = new OrganisationStatusReadinessCode(
			"Readiness state 5",
			"RDNS5",
			"Readiness state 5, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_6 = new OrganisationStatusReadinessCode(
			"Readiness state 6",
			"RDNS6",
			"Readiness state 6, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_7 = new OrganisationStatusReadinessCode(
			"Readiness state 7",
			"RDNS7",
			"Readiness state 7, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_8 = new OrganisationStatusReadinessCode(
			"Readiness state 8",
			"RDNS8",
			"Readiness state 8, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READINESS_STATE_9 = new OrganisationStatusReadinessCode(
			"Readiness state 9",
			"RDNS9",
			"Readiness state 9, in line with definitions provided by \"Shape Standing Defence Plan (SDP) 10901D - ANGRY HASP\" [NC] and by the \"Comairnorth Supplan 24600D Constant Effort\" for the Northern Region Integrated Air Defence System (NRIADS), Annex h dated 15 FEB 2000 [NC].");
	public static final OrganisationStatusReadinessCode READY_WITHIN_10_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within 10 minutes",
			"RDY10M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 10 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_12_HOURS = new OrganisationStatusReadinessCode(
			"Ready within 12 hours",
			"RDY12H",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 12 hours.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_15_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within 15 minutes",
			"RDY15M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 15 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_20_MINUTES_US = new OrganisationStatusReadinessCode(
			"Ready within 20 minutes (US)",
			"RDY20M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 20 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_2_HOURS = new OrganisationStatusReadinessCode(
			"Ready within 2 hours",
			"RDY2H",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 2 hours.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_30_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within 30 minutes",
			"RDY30M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 30 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_3_HOURS = new OrganisationStatusReadinessCode(
			"Ready within 3 hours",
			"RDY3H",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 3 hours.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_5_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within 5 minutes",
			"RDY5M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 5 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_60_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within 60 minutes",
			"RDY60M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 60 minutes.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_6_HOURS = new OrganisationStatusReadinessCode(
			"Ready within 6 hours",
			"RDY6H",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within 6 hours.");
	public static final OrganisationStatusReadinessCode READY_WITHIN_LESS_THAN_5_MINUTES = new OrganisationStatusReadinessCode(
			"Ready within less than 5 minutes",
			"RDYL5M",
			"A readiness state of an ORGANISATION indicating that the ORGANISATION can be ready within less than 5 minutes.");
	public static final OrganisationStatusReadinessCode RED = new OrganisationStatusReadinessCode(
			"Red",
			"RED",
			"A readiness level of a \"Marine Unit\" type ORGANISATION where the troops must be able to open fire in 2 to 5 minutes.");
	public static final OrganisationStatusReadinessCode RUNWAY_ALERT = new OrganisationStatusReadinessCode(
			"Runway alert",
			"RNYALR",
			"A readiness level of an ORGANISATION where the aircrews will be in the cockpits with the applicable checks completed and the aircraft will be located on or near the runway with engines running ready for take off.");
	public static final OrganisationStatusReadinessCode WHITE = new OrganisationStatusReadinessCode(
			"White",
			"WHITE",
			"A readiness level of a \"Marine Unit\" type ORGANISATION where the troops must be able to open fire in 30 to 60 minutes.");
	public static final OrganisationStatusReadinessCode WITHIN_10_DAYS = new OrganisationStatusReadinessCode(
			"Within 10 days",
			"WT10D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 10 days.");
	public static final OrganisationStatusReadinessCode WITHIN_180_DAYS = new OrganisationStatusReadinessCode(
			"Within 180 days",
			"WT180D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 180 days.");
	public static final OrganisationStatusReadinessCode WITHIN_20_DAYS = new OrganisationStatusReadinessCode(
			"Within 20 days",
			"WT20D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 20 days.");
	public static final OrganisationStatusReadinessCode WITHIN_2_DAYS = new OrganisationStatusReadinessCode(
			"Within 2 days",
			"WT2D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 2 days.");
	public static final OrganisationStatusReadinessCode WITHIN_30_DAYS = new OrganisationStatusReadinessCode(
			"Within 30 days",
			"WT30D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 30 days.");
	public static final OrganisationStatusReadinessCode WITHIN_365_DAYS = new OrganisationStatusReadinessCode(
			"Within 365 days",
			"WT365D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 365 days.");
	public static final OrganisationStatusReadinessCode WITHIN_5_DAYS = new OrganisationStatusReadinessCode(
			"Within 5 days",
			"WT5D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 5 days.");
	public static final OrganisationStatusReadinessCode WITHIN_60_DAYS = new OrganisationStatusReadinessCode(
			"Within 60 days",
			"WT60D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 60 days.");
	public static final OrganisationStatusReadinessCode WITHIN_90_DAYS = new OrganisationStatusReadinessCode(
			"Within 90 days",
			"WT90D",
			"A readiness level of an ORGANISATION where the troops will be able to be engaged in action, defence or protection within 90 days.");
	public static final OrganisationStatusReadinessCode YELLOW = new OrganisationStatusReadinessCode(
			"Yellow",
			"YELLOW",
			"A readiness level of a \"Marine Unit\" type ORGANISATION where the troops must be able to open fire in 15 minutes.");

	private OrganisationStatusReadinessCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
