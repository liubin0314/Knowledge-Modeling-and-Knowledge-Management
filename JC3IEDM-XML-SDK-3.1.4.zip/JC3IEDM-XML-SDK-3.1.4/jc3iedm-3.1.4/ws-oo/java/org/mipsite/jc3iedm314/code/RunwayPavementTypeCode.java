/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RunwayPavementTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of pavement classification, which is part of the standard ICAO (International Civil Aviation Organization) method of reporting pavement strength for pavements with bearing strength greater than 5,700 kilograms (12,500 pounds).";
	}

	private static HashMap<String, RunwayPavementTypeCode> physicalToCode = new HashMap<String, RunwayPavementTypeCode>();

	public static RunwayPavementTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RunwayPavementTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RunwayPavementTypeCode FLEXIBLE = new RunwayPavementTypeCode(
			"Flexible",
			"F",
			"The pavement type has a flexible classification.");
	public static final RunwayPavementTypeCode RIGID = new RunwayPavementTypeCode(
			"Rigid",
			"R",
			"The pavement type has a rigid classification.");

	private RunwayPavementTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
