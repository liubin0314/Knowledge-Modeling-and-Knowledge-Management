/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkArchitectureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the architecture of a specific NETWORK.";
	}

	private static HashMap<String, NetworkArchitectureCode> physicalToCode = new HashMap<String, NetworkArchitectureCode>();

	public static NetworkArchitectureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkArchitectureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkArchitectureCode ARCNET = new NetworkArchitectureCode(
			"ARCnet",
			"ARCNET",
			"The IEEE 802.4 network architecture.");
	public static final NetworkArchitectureCode ETHERNET = new NetworkArchitectureCode(
			"Ethernet",
			"ETHRNT",
			"The IEEE 802.3 (and derivatives) network architecture.");
	public static final NetworkArchitectureCode MIXED = new NetworkArchitectureCode(
			"Mixed",
			"MIXED",
			"A network where more than one architecture is used.");
	public static final NetworkArchitectureCode NOT_OTHERWISE_SPECIFIED = new NetworkArchitectureCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkArchitectureCode TOKEN_RING = new NetworkArchitectureCode(
			"Token ring",
			"TKNRNG",
			"The IEEE 802.5 network architecture.");
	public static final NetworkArchitectureCode WIRELESS = new NetworkArchitectureCode(
			"Wireless",
			"WRLESS",
			"The IEEE 802.11 network architecture.");

	private NetworkArchitectureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
