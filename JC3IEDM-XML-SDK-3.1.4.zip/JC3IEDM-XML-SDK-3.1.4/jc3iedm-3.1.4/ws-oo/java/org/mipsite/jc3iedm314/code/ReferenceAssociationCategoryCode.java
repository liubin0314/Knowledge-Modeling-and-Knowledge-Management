/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of relationship between a subject REFERENCE and an object REFERENCE for a specific REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, ReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, ReferenceAssociationCategoryCode>();

	public static ReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceAssociationCategoryCode CANCELS = new ReferenceAssociationCategoryCode(
			"Cancels",
			"CANCEL",
			"The artefact in the subject REFERENCE cancels the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode GRAPHICALLY_DEPICTS_INFORMATION_CONTAINED_IN = new ReferenceAssociationCategoryCode(
			"Graphically depicts information contained in",
			"GRPHDP",
			"The artefact in the subject REFERENCE graphically depicts the information in the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode INCLUDES = new ReferenceAssociationCategoryCode(
			"Includes",
			"INCLDE",
			"The artefact in the subject REFERENCE includes the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode IS_AN_AMENDMENT_TO = new ReferenceAssociationCategoryCode(
			"Is an amendment to",
			"ISAMND",
			"The artefact in the subject REFERENCE is an amendment to the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode IS_ATTACHMENT_TO = new ReferenceAssociationCategoryCode(
			"Is attachment to",
			"ISATTC",
			"The artefact in the subject REFERENCE is an attachment to the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode IS_DERIVED_FROM = new ReferenceAssociationCategoryCode(
			"Is derived from",
			"ISDRVD",
			"The artefact in the subject REFERENCE is derived from the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode IS_MODIFICATION_OF = new ReferenceAssociationCategoryCode(
			"Is modification of",
			"ISMODF",
			"The artefact in the subject REFERENCE is a modification of the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode PROVIDES_AUTHORITY_FOR = new ReferenceAssociationCategoryCode(
			"Provides authority for",
			"PRVATH",
			"The stipulations of the artefact in the subject REFERENCE provide authority for the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode REFERENCES = new ReferenceAssociationCategoryCode(
			"References",
			"REFRNC",
			"The artefact in the subject REFERENCE references the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode SUPPLEMENTS = new ReferenceAssociationCategoryCode(
			"Supplements",
			"SUPLMN",
			"The artefact in the subject REFERENCE supplements the artefact in the object REFERENCE.");
	public static final ReferenceAssociationCategoryCode SUPERSEDES = new ReferenceAssociationCategoryCode(
			"Supersedes",
			"SUPRCD",
			"The artefact in the subject REFERENCE supersedes the artefact in the object REFERENCE.");

	private ReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
