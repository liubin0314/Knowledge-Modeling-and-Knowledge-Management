/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldLandPersistenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the option for terminating the effectiveness of a specific MINEFIELD-LAND.";
	}

	private static HashMap<String, MinefieldLandPersistenceCode> physicalToCode = new HashMap<String, MinefieldLandPersistenceCode>();

	public static MinefieldLandPersistenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldLandPersistenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldLandPersistenceCode NOT_KNOWN = new MinefieldLandPersistenceCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MinefieldLandPersistenceCode PERMANENT = new MinefieldLandPersistenceCode(
			"Permanent",
			"PERMAN",
			"A minefield, already existing and effective, until somebody clears it.");
	public static final MinefieldLandPersistenceCode REMOTE_ACTIVATED_DESTRUCTION = new MinefieldLandPersistenceCode(
			"Remote activated destruction",
			"REMOTE",
			"A minefield that can be destroyed by remote control.");
	public static final MinefieldLandPersistenceCode TIMED_AUTOMATIC_DESTRUCTION = new MinefieldLandPersistenceCode(
			"Timed automatic destruction",
			"SLFDST",
			"A minefield that is in place for a certain period of time after which it destroys itself.");

	private MinefieldLandPersistenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
