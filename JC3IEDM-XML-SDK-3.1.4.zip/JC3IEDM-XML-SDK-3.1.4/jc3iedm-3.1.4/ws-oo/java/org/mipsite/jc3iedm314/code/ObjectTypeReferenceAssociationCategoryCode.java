/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectTypeReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a specific OBJECT-TYPE-REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, ObjectTypeReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, ObjectTypeReferenceAssociationCategoryCode>();

	public static ObjectTypeReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectTypeReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectTypeReferenceAssociationCategoryCode HAS_CAPABILITIES_DEFINED_IN = new ObjectTypeReferenceAssociationCategoryCode(
			"Has capabilities defined in",
			"HASCAP",
			"The specific OBJECT-TYPE is competent to perform according to provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode HAS_TRAINING_SUPPORTED_BY = new ObjectTypeReferenceAssociationCategoryCode(
			"Has training supported by",
			"HASTNG",
			"The training for a specific OBJECT-TYPE is aided by the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode IS_DESCRIBED_BY = new ObjectTypeReferenceAssociationCategoryCode(
			"Is described by",
			"ISDSCR",
			"The specific OBJECT-TYPE is depicted in the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode IS_MAINTAINED_USING = new ObjectTypeReferenceAssociationCategoryCode(
			"Is maintained using",
			"ISMNTN",
			"The maintenance of the specific OBJECT-TYPE is performed according to the provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode IS_PROCURED_USING = new ObjectTypeReferenceAssociationCategoryCode(
			"Is procured using",
			"ISPRCR",
			"The specific OBJECT-TYPE is acquired according to provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode IS_REFERENCED_IN = new ObjectTypeReferenceAssociationCategoryCode(
			"Is referenced in",
			"ISRFNC",
			"The specific OBJECT-TYPE is alluded to in the artefact cited in the specific REFERENCE.");
	public static final ObjectTypeReferenceAssociationCategoryCode IS_SPECIFIED_BY = new ObjectTypeReferenceAssociationCategoryCode(
			"Is specified by",
			"ISSPCF",
			"The specific OBJECT-TYPE is specified by the provisions in the artefact cited in the specific REFERENCE.");

	private ObjectTypeReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
