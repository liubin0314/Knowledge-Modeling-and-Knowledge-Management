/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaintenanceCapabilityLevelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the extent of repairs or servicing that can be accomplished.";
	}

	private static HashMap<String, MaintenanceCapabilityLevelCode> physicalToCode = new HashMap<String, MaintenanceCapabilityLevelCode>();

	public static MaintenanceCapabilityLevelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaintenanceCapabilityLevelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaintenanceCapabilityLevelCode MAJOR = new MaintenanceCapabilityLevelCode(
			"Major",
			"A",
			"The level of repair provided by the specific MAINTENANCE-CAPABILITY is major.");
	public static final MaintenanceCapabilityLevelCode MODERATE = new MaintenanceCapabilityLevelCode(
			"Moderate",
			"B",
			"The level of repair provided by the specific MAINTENANCE-CAPABILITY is moderate.");
	public static final MaintenanceCapabilityLevelCode LIMITED = new MaintenanceCapabilityLevelCode(
			"Limited",
			"C",
			"The level of repair provided by the specific MAINTENANCE-CAPABILITY is limited.");
	public static final MaintenanceCapabilityLevelCode EMERGENCY_ONLY = new MaintenanceCapabilityLevelCode(
			"Emergency only",
			"D",
			"The level of repair provided by the specific MAINTENANCE-CAPABILITY is only for emergencies.");

	private MaintenanceCapabilityLevelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
