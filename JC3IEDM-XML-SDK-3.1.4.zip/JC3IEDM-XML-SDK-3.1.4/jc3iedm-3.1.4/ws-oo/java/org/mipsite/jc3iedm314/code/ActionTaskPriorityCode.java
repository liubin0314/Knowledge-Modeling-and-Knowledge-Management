/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskPriorityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the rank of importance of a specific ACTION-TASK in view of the planning organisation.";
	}

	private static HashMap<String, ActionTaskPriorityCode> physicalToCode = new HashMap<String, ActionTaskPriorityCode>();

	public static ActionTaskPriorityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskPriorityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskPriorityCode PRIORITY_1 = new ActionTaskPriorityCode(
			"Priority 1",
			"1",
			"The classification that denotes those ACTION-TASKs which meet the criteria for being placed in the highest categorisation.");
	public static final ActionTaskPriorityCode PRIORITY_1A1 = new ActionTaskPriorityCode(
			"Priority 1A1",
			"1A1",
			"The highest classification that denotes those ACTION-TASKs that are directed by a head of state or the highest NATO authority.");
	public static final ActionTaskPriorityCode PRIORITY_1A2 = new ActionTaskPriorityCode(
			"Priority 1A2",
			"1A2",
			"The highest classification that denotes those ACTION-TASKs that involve forces or activities in combat.");
	public static final ActionTaskPriorityCode PRIORITY_1A3 = new ActionTaskPriorityCode(
			"Priority 1A3",
			"1A3",
			"The highest classification that denotes those ACTION-TASKs that are top national priority programs which have been approved by the highest national authority.");
	public static final ActionTaskPriorityCode PRIORITY_1A4 = new ActionTaskPriorityCode(
			"Priority 1A4",
			"1A4",
			"The highest classification that denotes those ACTION-TASKs that involve special weapons.");
	public static final ActionTaskPriorityCode PRIORITY_1B1 = new ActionTaskPriorityCode(
			"Priority 1B1",
			"1B1",
			"The highest classification that denotes those ACTION-TASKs that are directed by a major NATO command or a nations highest military staff or civilian-military agency.");
	public static final ActionTaskPriorityCode PRIORITY_1B2 = new ActionTaskPriorityCode(
			"Priority 1B2",
			"1B2",
			"The highest classification that denotes those ACTION-TASKs that involve UNITs, projects, or plans approved by a major NATO command or a nations highest military staff.");
	public static final ActionTaskPriorityCode PRIORITY_1B3 = new ActionTaskPriorityCode(
			"Priority 1B3",
			"1B3",
			"The highest classification that denotes those ACTION-TASKs that are scheduled resupply missions.");
	public static final ActionTaskPriorityCode PRIORITY_2 = new ActionTaskPriorityCode(
			"Priority 2",
			"2",
			"The classification that denotes those ACTION-TASKs which meet the criteria for being placed in the 2nd highest category.");
	public static final ActionTaskPriorityCode PRIORITY_2A1 = new ActionTaskPriorityCode(
			"Priority 2A1",
			"2A1",
			"The second highest classification that denotes those ACTION-TASKs that involve forces which are being deployed or are positioned and maintained in a state of readiness for immediate combat or direct combat support.");
	public static final ActionTaskPriorityCode PRIORITY_2A2 = new ActionTaskPriorityCode(
			"Priority 2A2",
			"2A2",
			"The second highest classification that denotes those ACTION-TASKs that involve industrial production activities; to prevent work stoppage; or to reinstitute production");
	public static final ActionTaskPriorityCode PRIORITY_2B1 = new ActionTaskPriorityCode(
			"Priority 2B1",
			"2B1",
			"The second highest classification that denotes those ACTION-TASKs that are NATO or national directed exercises.");
	public static final ActionTaskPriorityCode PRIORITY_2B2 = new ActionTaskPriorityCode(
			"Priority 2B2",
			"2B2",
			"The second highest classification that denotes those ACTION-TASKs that are NATO or national coordinated exercises.");
	public static final ActionTaskPriorityCode PRIORITY_3 = new ActionTaskPriorityCode(
			"Priority 3",
			"3",
			"The classification that denotes those ACTION-TASKs which meet the criteria for being placed in the 3rd highest category.");
	public static final ActionTaskPriorityCode PRIORITY_3A1 = new ActionTaskPriorityCode(
			"Priority 3A1",
			"3A1",
			"The third highest classification that denotes those ACTION-TASKs that involve unit inspection or evaluation tests; Emergency Deployment Readiness Exercise (EDRE), Operational Readiness Inspection (ORI), etc.");
	public static final ActionTaskPriorityCode PRIORITY_3A2 = new ActionTaskPriorityCode(
			"Priority 3A2",
			"3A2",
			"The third highest classification that denotes those ACTION-TASKs that involve forces maintained in a state of readiness to deploy for combat.");
	public static final ActionTaskPriorityCode PRIORITY_3A3 = new ActionTaskPriorityCode(
			"Priority 3A3",
			"3A3",
			"The third highest classification that denotes those ACTION-TASKs that are non-scheduled resupply missions.");
	public static final ActionTaskPriorityCode PRIORITY_3B1 = new ActionTaskPriorityCode(
			"Priority 3B1",
			"3B1",
			"The third highest classification that denotes those ACTION-TASKs that require service training when it is integral to combat readiness (e.g., field training exercises, proficiency airdrop, and air assault).");
	public static final ActionTaskPriorityCode PRIORITY_3B2 = new ActionTaskPriorityCode(
			"Priority 3B2",
			"3B2",
			"The third highest classification that denotes those ACTION-TASKs that require combat support training (e.g., flare drops, unconventional warfare activities, and Joint Airborne Communications Centre/Command Post (JACC/CP)).");
	public static final ActionTaskPriorityCode PRIORITY_3B3 = new ActionTaskPriorityCode(
			"Priority 3B3",
			"3B3",
			"The third highest classification that denotes those ACTION-TASKs that are service schools requiring airborne, airdrop, and air transportability training as a part of the training program.");
	public static final ActionTaskPriorityCode PRIORITY_3B4 = new ActionTaskPriorityCode(
			"Priority 3B4",
			"3B4",
			"The third highest classification that denotes those ACTION-TASKs that require airdrop/air transportability or aircraft certification of new or modified equipment.");
	public static final ActionTaskPriorityCode PRIORITY_4 = new ActionTaskPriorityCode(
			"Priority 4",
			"4",
			"The classification that denotes those ACTION-TASKs which meet the criteria for being placed in the 4th highest category.");
	public static final ActionTaskPriorityCode PRIORITY_4A1 = new ActionTaskPriorityCode(
			"Priority 4A1",
			"4A1",
			"The fourth highest classification that denotes those ACTION-TASKs that require forces which are planned for employment in support of approved war plans and support activities essential to such forces.");
	public static final ActionTaskPriorityCode PRIORITY_4A2 = new ActionTaskPriorityCode(
			"Priority 4A2",
			"4A2",
			"The fourth highest classification that denotes those ACTION-TASKs that are static loading exercises.");
	public static final ActionTaskPriorityCode PRIORITY_4B2 = new ActionTaskPriorityCode(
			"Priority 4B2",
			"4B2",
			"The fourth highest classification that denotes those ACTION-TASKs that are other non-military activities which cannot be accommodated by commercial airlift.");
	public static final ActionTaskPriorityCode PRIORITY_4B3 = new ActionTaskPriorityCode(
			"Priority 4B3",
			"4B3",
			"The fourth highest classification that denotes those ACTION-TASKs that require a static display for public and military events.");
	public static final ActionTaskPriorityCode PRIORITY_5 = new ActionTaskPriorityCode(
			"Priority 5",
			"5",
			"The classification that denotes those ACTION-TASKs which meet the criteria for being placed in the 5th highest category.");

	private ActionTaskPriorityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
