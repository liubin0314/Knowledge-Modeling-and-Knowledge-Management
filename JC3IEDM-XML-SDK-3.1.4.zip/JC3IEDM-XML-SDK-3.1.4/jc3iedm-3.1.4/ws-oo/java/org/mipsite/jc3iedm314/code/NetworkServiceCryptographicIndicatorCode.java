/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkServiceCryptographicIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific NETWORK-SERVICE is encrypted.";
	}

	private static HashMap<String, NetworkServiceCryptographicIndicatorCode> physicalToCode = new HashMap<String, NetworkServiceCryptographicIndicatorCode>();

	public static NetworkServiceCryptographicIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkServiceCryptographicIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkServiceCryptographicIndicatorCode NO = new NetworkServiceCryptographicIndicatorCode(
			"No",
			"NO",
			"The NETWORK-SERVICE is not encrypted.");
	public static final NetworkServiceCryptographicIndicatorCode YES = new NetworkServiceCryptographicIndicatorCode(
			"Yes",
			"YES",
			"The NETWORK-SERVICE is encrypted.");

	private NetworkServiceCryptographicIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
