/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CapabilityReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a specific CAPABILITY-REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, CapabilityReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, CapabilityReferenceAssociationCategoryCode>();

	public static CapabilityReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CapabilityReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CapabilityReferenceAssociationCategoryCode IS_AMPLIFIED_BY = new CapabilityReferenceAssociationCategoryCode(
			"Is amplified by",
			"ISAMPL",
			"The specific CAPABILITY has additional detail provided in the artefact cited in the specific REFERENCE.");
	public static final CapabilityReferenceAssociationCategoryCode IS_DEFINED_IN = new CapabilityReferenceAssociationCategoryCode(
			"Is defined in",
			"ISDFND",
			"The specific CAPABILITY is prescribed in the artefact cited in the specific REFERENCE.");
	public static final CapabilityReferenceAssociationCategoryCode IS_DESCRIBED_BY = new CapabilityReferenceAssociationCategoryCode(
			"Is described by",
			"ISDSCR",
			"The specific CAPABILITY is explained in the artefact cited in the specific REFERENCE.");

	private CapabilityReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
