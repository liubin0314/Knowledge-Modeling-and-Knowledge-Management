/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AnchorageBottomTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the description of the ground under the water of a lake, river, ocean, or other body of water at a specific ANCHORAGE.";
	}

	private static HashMap<String, AnchorageBottomTypeCode> physicalToCode = new HashMap<String, AnchorageBottomTypeCode>();

	public static AnchorageBottomTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AnchorageBottomTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AnchorageBottomTypeCode BOULDER = new AnchorageBottomTypeCode(
			"Boulder",
			"BOULDR",
			"The surface consists of boulders larger than human head size.");
	public static final AnchorageBottomTypeCode CLAY = new AnchorageBottomTypeCode(
			"Clay",
			"CLAY",
			"The surface consists of clay.");
	public static final AnchorageBottomTypeCode COBBLES = new AnchorageBottomTypeCode(
			"Cobbles",
			"COBBLS",
			"The surface consists of cobbles up to human head size.");
	public static final AnchorageBottomTypeCode CORAL = new AnchorageBottomTypeCode(
			"Coral",
			"CORAL",
			"The surface consists of coral.");
	public static final AnchorageBottomTypeCode GRAVEL = new AnchorageBottomTypeCode(
			"Gravel",
			"GRAVEL",
			"The surface consists of gravel.");
	public static final AnchorageBottomTypeCode LIMESTONE = new AnchorageBottomTypeCode(
			"Limestone",
			"LMNSTN",
			"The surface consists of limestone.");
	public static final AnchorageBottomTypeCode MUD = new AnchorageBottomTypeCode(
			"Mud",
			"MUD",
			"The surface consists of mud.");
	public static final AnchorageBottomTypeCode MUD_SMOOTH_SAND = new AnchorageBottomTypeCode(
			"Mud/smooth sand",
			"MUDSND",
			"The surface consists of mud and smooth sand.");
	public static final AnchorageBottomTypeCode NOT_OTHERWISE_SPECIFIED = new AnchorageBottomTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AnchorageBottomTypeCode PEBBLES = new AnchorageBottomTypeCode(
			"Pebbles",
			"PEBBLS",
			"The surface consists of pebbles up to clenched fist size.");
	public static final AnchorageBottomTypeCode ROUGH_CORAL_ROCK = new AnchorageBottomTypeCode(
			"Rough, coral/rock",
			"RGHCRL",
			"The surface of the bottom is uneven and contains outcrops of rock and or coral.");
	public static final AnchorageBottomTypeCode ROCK = new AnchorageBottomTypeCode(
			"Rock",
			"ROCK",
			"The surface is made of rock, not specified.");
	public static final AnchorageBottomTypeCode ROUGH = new AnchorageBottomTypeCode(
			"Rough",
			"ROUGH",
			"The surface of the bottom is uneven, with holes, bumps and folds up to 30cm and/or a lot of seaweed.");
	public static final AnchorageBottomTypeCode SAND = new AnchorageBottomTypeCode(
			"Sand",
			"SAND",
			"The surface consists of fine sand up to pinhead size.");
	public static final AnchorageBottomTypeCode SAND_COARSE = new AnchorageBottomTypeCode(
			"Sand, coarse",
			"SANDCR",
			"The surface consists of sand between 0.5 and 2.0 mm in size.");
	public static final AnchorageBottomTypeCode SAND_FINE = new AnchorageBottomTypeCode(
			"Sand, fine",
			"SANDFN",
			"The surface consists of sand between 0.125 and 0.25mm in size.");
	public static final AnchorageBottomTypeCode SAND_MEDIUM = new AnchorageBottomTypeCode(
			"Sand, medium",
			"SANDMD",
			"The surface consists of sand between 0.25 and 0.5mm in size.");
	public static final AnchorageBottomTypeCode SAND_VERY_COARSE = new AnchorageBottomTypeCode(
			"Sand, very coarse",
			"SANDVC",
			"The surface consists of sand up to 72mm in size.");
	public static final AnchorageBottomTypeCode SAND_VERY_FINE = new AnchorageBottomTypeCode(
			"Sand, very fine",
			"SANDVF",
			"The surface consists of sand between 0.063 and 0.125mm in size.");
	public static final AnchorageBottomTypeCode SMOOTH_AND_FLAT = new AnchorageBottomTypeCode(
			"Smooth and flat",
			"SMTHFL",
			"The surface is stable and smooth and contains ripples of less than 15cm.");
	public static final AnchorageBottomTypeCode STABLE_AND_SMOOTH = new AnchorageBottomTypeCode(
			"Stable and smooth",
			"STBLSM",
			"The surface is stable and smooth and contains holes, bumps and folds up to 30cm.");

	private AnchorageBottomTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
