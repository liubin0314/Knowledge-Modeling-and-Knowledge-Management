/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class JettyRailServedIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the JETTY has railway facilities.";
	}

	private static HashMap<String, JettyRailServedIndicatorCode> physicalToCode = new HashMap<String, JettyRailServedIndicatorCode>();

	public static JettyRailServedIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<JettyRailServedIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final JettyRailServedIndicatorCode NO = new JettyRailServedIndicatorCode(
			"No",
			"NO",
			"Railway services are not available at the jetty.");
	public static final JettyRailServedIndicatorCode YES = new JettyRailServedIndicatorCode(
			"Yes",
			"YES",
			"Railway services are available at the jetty.");

	private JettyRailServedIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
