/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GroupCharacteristicTriageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies the triage classification in a specific GROUP-CHARACTERISTIC.";
	}

	private static HashMap<String, GroupCharacteristicTriageCode> physicalToCode = new HashMap<String, GroupCharacteristicTriageCode>();

	public static GroupCharacteristicTriageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GroupCharacteristicTriageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GroupCharacteristicTriageCode IMMEDIATE_TREATMENT_GROUP_T1 = new GroupCharacteristicTriageCode(
			"Immediate treatment (Group T1)",
			"T1",
			"A group that consists of those requiring emergency care and life-saving surgery. These procedures should not be time-consuming and be applied only to those with high chances of survival.");
	public static final GroupCharacteristicTriageCode DELAYED_TREATMENT_GROUP_T2 = new GroupCharacteristicTriageCode(
			"Delayed treatment (Group T2)",
			"T2",
			"A group that consists of those in need of surgery, but whose general condition permits delay in surgical treatment without unduly endangering life. To mitigate the effect of delay in surgery, sustaining treatment will be required.");
	public static final GroupCharacteristicTriageCode MINIMAL_TREATMENT_GROUP_T3 = new GroupCharacteristicTriageCode(
			"Minimal treatment (Group T3)",
			"T3",
			"A group that consists of those with relatively minor injuries who can effectively care for themselves or who can be helped by untrained personnel.");
	public static final GroupCharacteristicTriageCode EXPECTANT_TREATMENT_GROUP_T4 = new GroupCharacteristicTriageCode(
			"Expectant treatment (Group T4)",
			"T4",
			"A group that comprises those who have received serious and often multiple injuries, and whose treatment would be time-consuming and complicated, with a low chance of survival.");

	private GroupCharacteristicTriageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
