/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourEntranceRestrictionsIceIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether ice is a natural factor restricting the entrance of vessels into the port.";
	}

	private static HashMap<String, HarbourEntranceRestrictionsIceIndicatorCode> physicalToCode = new HashMap<String, HarbourEntranceRestrictionsIceIndicatorCode>();

	public static HarbourEntranceRestrictionsIceIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourEntranceRestrictionsIceIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourEntranceRestrictionsIceIndicatorCode NO = new HarbourEntranceRestrictionsIceIndicatorCode(
			"No",
			"NO",
			"Ice is not a natural factor restricting the entrance of vessels into the harbour.");
	public static final HarbourEntranceRestrictionsIceIndicatorCode YES = new HarbourEntranceRestrictionsIceIndicatorCode(
			"Yes",
			"YES",
			"Ice is a natural factor restricting the entrance of vessels into the harbour.");

	private HarbourEntranceRestrictionsIceIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
