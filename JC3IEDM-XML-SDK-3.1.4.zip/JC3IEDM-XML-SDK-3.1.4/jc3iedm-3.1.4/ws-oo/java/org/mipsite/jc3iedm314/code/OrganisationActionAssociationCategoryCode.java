/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationActionAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between a specific ORGANISATION and a specific ACTION for a specific ORGANISATION-ACTION-ASSOCIATION.";
	}

	private static HashMap<String, OrganisationActionAssociationCategoryCode> physicalToCode = new HashMap<String, OrganisationActionAssociationCategoryCode>();

	public static OrganisationActionAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationActionAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationActionAssociationCategoryCode APPROVES = new OrganisationActionAssociationCategoryCode(
			"Approves",
			"APPR",
			"Authorises a specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode CONTROLS = new OrganisationActionAssociationCategoryCode(
			"Controls",
			"CONTRL",
			"The specific ORGANISATION that is in charge of the direction, coordination and execution of a specific ACTION-TASK.");
	public static final OrganisationActionAssociationCategoryCode IS_COORDINATING_AGENT_FOR = new OrganisationActionAssociationCategoryCode(
			"Is coordinating agent for",
			"COOR",
			"Responsible for coordinating the ACTION when two, or more, resources are involved.");
	public static final OrganisationActionAssociationCategoryCode INITIATES = new OrganisationActionAssociationCategoryCode(
			"Initiates",
			"INIT",
			"Starts the planning or execution of a specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode IS_INTERESTED_IN = new OrganisationActionAssociationCategoryCode(
			"Is interested in",
			"INTRST",
			"The specific ORGANISATION takes an interest in the specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode IS_SCRAMBLE_AGENCY_FOR = new OrganisationActionAssociationCategoryCode(
			"Is scramble agency for",
			"ISSCRM",
			"An agency that has the authority to issue an order directing take-off of aircraft as quickly as possible usually followed by mission instructions.");
	public static final OrganisationActionAssociationCategoryCode IS_LIAISON_FOR = new OrganisationActionAssociationCategoryCode(
			"Is liaison for",
			"LIAISN",
			"Denotes the ORGANISATION that acts as the liaison in connection with an ACTION.");
	public static final OrganisationActionAssociationCategoryCode OBSERVED = new OrganisationActionAssociationCategoryCode(
			"Observed",
			"OBSRVD",
			"The specific ORGANISATION has witnessed the specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode PLANS = new OrganisationActionAssociationCategoryCode(
			"Plans",
			"PLAN",
			"Performs the detailing of a specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode IS_POINT_OF_CONTACT_FOR = new OrganisationActionAssociationCategoryCode(
			"Is point of contact for",
			"POC",
			"Denotes the organisation to be contacted in connection with an ACTION.");
	public static final OrganisationActionAssociationCategoryCode PROVIDES_DIRECTION_FOR = new OrganisationActionAssociationCategoryCode(
			"Provides direction for",
			"PROVDR",
			"States the commander's guidance or intent for.");
	public static final OrganisationActionAssociationCategoryCode REPORTED = new OrganisationActionAssociationCategoryCode(
			"Reported",
			"REP",
			"The specific ORGANISATION accounts for its specific ACTION.");
	public static final OrganisationActionAssociationCategoryCode REQUESTS = new OrganisationActionAssociationCategoryCode(
			"Requests",
			"REQUST",
			"Indicates a need for.");
	public static final OrganisationActionAssociationCategoryCode SUSPECTED = new OrganisationActionAssociationCategoryCode(
			"Suspected",
			"SSPCTD",
			"The specific ORGANISATION inclines to think that the specific ACTION has occurred, is occurring or will occur.");

	private OrganisationActionAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
