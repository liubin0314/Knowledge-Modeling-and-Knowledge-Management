/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class QuayStorageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of storage facilities available at a specific QUAY.";
	}

	private static HashMap<String, QuayStorageCode> physicalToCode = new HashMap<String, QuayStorageCode>();

	public static QuayStorageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<QuayStorageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final QuayStorageCode CBRN = new QuayStorageCode(
			"CBRN",
			"CBRN",
			"The equipment and resources to load/unload, keep temporarily and to manage in a correct way military chemical, biological, radiological, or nuclear materiel and associated equipment.");
	public static final QuayStorageCode GRAIN_SILO = new QuayStorageCode(
			"Grain silo",
			"GRNSIL",
			"A tower or towers for the storage of grain, typically accompanied by loading/offloading facilities for grain.");
	public static final QuayStorageCode HAZARDOUS_CARGO = new QuayStorageCode(
			"Hazardous cargo",
			"HAZCAR",
			"The equipment and resources to securely store, in transit, any cargo that contains a substance that is harmful to humans or living organisms and poses a physical hazard, health hazard or environmental hazard. This includes substances that are toxic, explosive, corrosive, nuclear, ignitable or chemically reactive.");
	public static final QuayStorageCode LIQUID_STORAGE = new QuayStorageCode(
			"Liquid storage",
			"LQDSTR",
			"The equipment and resources to hold and store a liquid in transit, and normally has inloading and discharging facilities.");
	public static final QuayStorageCode MUNITIONS_AND_EXPLOSIVES = new QuayStorageCode(
			"Munitions and explosives",
			"MNTEXP",
			"The equipment and resources to load/unload, keep temporarily and to manage in a correct way military weapons, ammunition, explosives and associated equipment.");
	public static final QuayStorageCode NOT_OTHERWISE_SPECIFIED = new QuayStorageCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final QuayStorageCode OPEN_AREA = new QuayStorageCode(
			"Open area",
			"OPENAR",
			"A flat open area, prepared (tarmac, concrete) or natural, on which cargo can be loaded/offloaded from vessels and stored whilst in transit.");
	public static final QuayStorageCode REFRIGERATED = new QuayStorageCode(
			"Refrigerated",
			"RFRGTD",
			"A building, usually insulated, with a cooled or chilled inside environment, normally used for keeping in transit anything that is perishable, such as, foodstuffs.");
	public static final QuayStorageCode VEHICLE = new QuayStorageCode(
			"Vehicle",
			"VEHCLE",
			"The equipment and resources for storing road vehicles in transit. This may be an open area or a multi storey building having several storeys or floors or both, accessible to vehicles by means of ramps.");
	public static final QuayStorageCode WAREHOUSE = new QuayStorageCode(
			"Warehouse",
			"WARHSE",
			"A large structure used for the storage of goods or material in transit.");

	private QuayStorageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
