/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LiquidSurfaceStatusSurfaceConditionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the physical status of a liquid surface area.";
	}

	private static HashMap<String, LiquidSurfaceStatusSurfaceConditionCode> physicalToCode = new HashMap<String, LiquidSurfaceStatusSurfaceConditionCode>();

	public static LiquidSurfaceStatusSurfaceConditionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LiquidSurfaceStatusSurfaceConditionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LiquidSurfaceStatusSurfaceConditionCode DRAINED = new LiquidSurfaceStatusSurfaceConditionCode(
			"Drained",
			"DRAIND",
			"A characterisation of an area temporarily without any liquid present.");
	public static final LiquidSurfaceStatusSurfaceConditionCode ICE = new LiquidSurfaceStatusSurfaceConditionCode(
			"Ice",
			"ICE",
			"A characterisation of an area covered with a layer or mass of frozen water.");
	public static final LiquidSurfaceStatusSurfaceConditionCode LIQUID = new LiquidSurfaceStatusSurfaceConditionCode(
			"Liquid",
			"LIQUID",
			"A characterisation of an area covered with liquid that is not frozen.");
	public static final LiquidSurfaceStatusSurfaceConditionCode MIXED = new LiquidSurfaceStatusSurfaceConditionCode(
			"Mixed",
			"MIXED",
			"A characterisation of an area covered with a mix of ice and water.");
	public static final LiquidSurfaceStatusSurfaceConditionCode NOT_KNOWN = new LiquidSurfaceStatusSurfaceConditionCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private LiquidSurfaceStatusSurfaceConditionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
