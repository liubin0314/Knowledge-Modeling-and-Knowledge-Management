/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAliasCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OBJECT-ITEM-ALIAS.";
	}

	private static HashMap<String, ObjectItemAliasCategoryCode> physicalToCode = new HashMap<String, ObjectItemAliasCategoryCode>();

	public static ObjectItemAliasCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAliasCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAliasCategoryCode ALTERNATE_NAME = new ObjectItemAliasCategoryCode(
			"Alternate name",
			"ALTNAM",
			"A designation of the common additional reference given to an OBJECT-ITEM.");
	public static final ObjectItemAliasCategoryCode ELINT_NOTATION = new ObjectItemAliasCategoryCode(
			"Elint notation",
			"ELINT",
			"A 5-character ELINT notation for non-communications electronics emissions related to such equipments.");
	public static final ObjectItemAliasCategoryCode EMISSIONS_SORTING_CODE = new ObjectItemAliasCategoryCode(
			"Emissions sorting code",
			"EMSSNS",
			"A 4-character code which facilitates reporting equipment type that has no associated ELINT notation.");
	public static final ObjectItemAliasCategoryCode GEOLOCATION = new ObjectItemAliasCategoryCode(
			"Geolocation",
			"GEOLOC",
			"A standard coded representation of a geolocation of a military organisation or a place with military significance.");
	public static final ObjectItemAliasCategoryCode TRACK_IDENTIFIER = new ObjectItemAliasCategoryCode(
			"Track identifier",
			"TRACK",
			"An identifier that is used in track reporting.");
	public static final ObjectItemAliasCategoryCode UNIT_DESIGNATOR = new ObjectItemAliasCategoryCode(
			"Unit designator",
			"UNITDS",
			"The designator of the unit that is tasked to perform the mission, for example: \"UNIT:ARS BROCKZETEL\".");

	private ObjectItemAliasCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
