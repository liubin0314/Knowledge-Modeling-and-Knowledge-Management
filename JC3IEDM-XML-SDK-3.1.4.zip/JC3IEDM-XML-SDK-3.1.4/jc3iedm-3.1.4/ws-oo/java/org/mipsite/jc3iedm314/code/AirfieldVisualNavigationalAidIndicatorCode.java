/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldVisualNavigationalAidIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value indicating whether or not the airport has a visual navigational aid displaying flashes of white or colored light to indicate the location of an airport.";
	}

	private static HashMap<String, AirfieldVisualNavigationalAidIndicatorCode> physicalToCode = new HashMap<String, AirfieldVisualNavigationalAidIndicatorCode>();

	public static AirfieldVisualNavigationalAidIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldVisualNavigationalAidIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldVisualNavigationalAidIndicatorCode NO = new AirfieldVisualNavigationalAidIndicatorCode(
			"No",
			"NO",
			"Visual navigational aid is not available at the airfield.");
	public static final AirfieldVisualNavigationalAidIndicatorCode YES = new AirfieldVisualNavigationalAidIndicatorCode(
			"Yes",
			"YES",
			"Visual navigational aid is available at the airfield.");

	private AirfieldVisualNavigationalAidIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
