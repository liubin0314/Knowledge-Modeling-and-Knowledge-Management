/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BiologicalMaterielTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of BIOLOGICAL-MATERIEL-TYPE.";
	}

	private static HashMap<String, BiologicalMaterielTypeCategoryCode> physicalToCode = new HashMap<String, BiologicalMaterielTypeCategoryCode>();

	public static BiologicalMaterielTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BiologicalMaterielTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BiologicalMaterielTypeCategoryCode BACTERIAL = new BiologicalMaterielTypeCategoryCode(
			"Bacterial",
			"BACTRL",
			"A generic term for a BIOLOGICAL-MATERIEL-TYPE, member of a large group of unicellular micro-organisms (prokaryotes) that have cell walls but lack an organised nucleus and other structures, and include numerous disease causing forms.");
	public static final BiologicalMaterielTypeCategoryCode NOT_KNOWN = new BiologicalMaterielTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final BiologicalMaterielTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new BiologicalMaterielTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final BiologicalMaterielTypeCategoryCode TOXIN = new BiologicalMaterielTypeCategoryCode(
			"Toxin",
			"TOXIN",
			"A generic term for a BIOLOGICAL-MATERIEL-TYPE that is a micro-organism product that causes disease in man, plants or animals or causes the deterioration of materiel.");
	public static final BiologicalMaterielTypeCategoryCode TOXIC_INDUSTRIAL_MATERIAL = new BiologicalMaterielTypeCategoryCode(
			"Toxic industrial material",
			"TOXMAT",
			"A generic term for a BIOLOGICAL-MATERIEL-TYPE compound in solid, liquid, aerosolised or gaseous form. It may be used, or stored for use, for industrial, commercial, medical, military or domestic purposes.");
	public static final BiologicalMaterielTypeCategoryCode VIRAL = new BiologicalMaterielTypeCategoryCode(
			"Viral",
			"VIRAL",
			"A generic term for a BIOLOGICAL-MATERIEL-TYPE of the nature of a virus; submicroscopic infective particle, typically consisting of nucleic acid coated in protein, which is able to multiply within the cells of a host organism.");

	private BiologicalMaterielTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
