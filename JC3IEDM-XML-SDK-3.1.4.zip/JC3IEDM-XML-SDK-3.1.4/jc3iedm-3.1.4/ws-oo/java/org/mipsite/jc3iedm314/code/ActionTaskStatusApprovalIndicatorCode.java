/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStatusApprovalIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes at the reporting time whether an ACTION-TASK is approved for execution.";
	}

	private static HashMap<String, ActionTaskStatusApprovalIndicatorCode> physicalToCode = new HashMap<String, ActionTaskStatusApprovalIndicatorCode>();

	public static ActionTaskStatusApprovalIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStatusApprovalIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStatusApprovalIndicatorCode NO = new ActionTaskStatusApprovalIndicatorCode(
			"No",
			"NO",
			"The associated ACTION-TASK is disapproved.");
	public static final ActionTaskStatusApprovalIndicatorCode YES = new ActionTaskStatusApprovalIndicatorCode(
			"Yes",
			"YES",
			"The associated ACTION-TASK is approved for execution.");

	private ActionTaskStatusApprovalIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
