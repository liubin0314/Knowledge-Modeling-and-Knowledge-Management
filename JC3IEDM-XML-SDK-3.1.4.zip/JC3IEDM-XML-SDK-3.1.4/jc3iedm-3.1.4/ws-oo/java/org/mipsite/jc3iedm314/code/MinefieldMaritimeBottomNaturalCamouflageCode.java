/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeBottomNaturalCamouflageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the description of the ground of a lake, river, or ocean, or other body of water with respect to the ability to hide mines on the bottom at a specific MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeBottomNaturalCamouflageCode> physicalToCode = new HashMap<String, MinefieldMaritimeBottomNaturalCamouflageCode>();

	public static MinefieldMaritimeBottomNaturalCamouflageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeBottomNaturalCamouflageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeBottomNaturalCamouflageCode BOTTOM_COVERED_IN_SEAWEED = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Bottom covered in seaweed",
			"BTMCVR",
			"Mines are likely to be hidden by seaweed, mine hunting possible with difficulty.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode BOTTOM_HAS_DEEP_HOLLOWS_OR_CREVICES_OR_CLIFFS = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Bottom has deep hollows or crevices or cliffs",
			"BTMDEP",
			"Mines are likely to be hidden completely in deep hollows or crevices or by cliffs, mine hunting difficult.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode IRREGULAR_BOTTOM = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Irregular bottom",
			"IRREGL",
			"Mines are likely to be hidden by irregularity of the bottom, mine hunting difficult.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode NOT_OTHERWISE_SPECIFIED = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode ROUGH_BOTTOM = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Rough bottom",
			"RGHBTM",
			"Rough bottom, mine hunting more difficult.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode RATHER_STABLE_AND_SMOOTH_BUT_UNEVEN_BOTTOM = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Rather stable and smooth but uneven bottom",
			"RTHRST",
			"Rather stable and smooth but uneven bottom, mine hunting possible.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode SOFT_BOTTOM = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Soft bottom",
			"SFTBTM",
			"Mines are likely to be hidden completely owing to complete burial, mine hunting difficult.");
	public static final MinefieldMaritimeBottomNaturalCamouflageCode STABLE_AND_SMOOTH_FLAT_BOTTOM = new MinefieldMaritimeBottomNaturalCamouflageCode(
			"Stable and smooth flat bottom",
			"STBSMT",
			"Stable and smooth flat bottom, mine hunting possible, little camouflage for mines.");

	private MinefieldMaritimeBottomNaturalCamouflageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
