/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataTimingCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the absolute, uncertain or relative timing for a specific REPORTING-DATA.";
	}

	private static HashMap<String, ReportingDataTimingCategoryCode> physicalToCode = new HashMap<String, ReportingDataTimingCategoryCode>();

	public static ReportingDataTimingCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataTimingCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataTimingCategoryCode REPORTING_DATA_ABSOLUTE_TIMING = new ReportingDataTimingCategoryCode(
			"REPORTING-DATA-ABSOLUTE-TIMING",
			"RDABST",
			"A REPORTING-DATA that specifies effective date and time that are referenced to Universal Time.");
	public static final ReportingDataTimingCategoryCode REPORTING_DATA_RELATIVE_TIMING = new ReportingDataTimingCategoryCode(
			"REPORTING-DATA-RELATIVE-TIMING",
			"RDRELT",
			"A REPORTING-DATA that specifies effective timing that is referenced to a specific ACTION-TASK.");
	public static final ReportingDataTimingCategoryCode TIMING_NOT_AVAILABLE = new ReportingDataTimingCategoryCode(
			"Timing not available",
			"TIMNA",
			"A REPORTING-DATA that indicates that the start or end timing with respect to past, current, or future periods is not available.");

	private ReportingDataTimingCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
