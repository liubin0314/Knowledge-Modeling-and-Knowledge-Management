/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MobilityCapabilityTerrainTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of terrain to which a particular MOBILITY-CAPABILITY pertains.";
	}

	private static HashMap<String, MobilityCapabilityTerrainTypeCode> physicalToCode = new HashMap<String, MobilityCapabilityTerrainTypeCode>();

	public static MobilityCapabilityTerrainTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MobilityCapabilityTerrainTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MobilityCapabilityTerrainTypeCode CROSS_COUNTRY = new MobilityCapabilityTerrainTypeCode(
			"Cross-country",
			"CRSCTY",
			"The capability is valid for movement in open country.");
	public static final MobilityCapabilityTerrainTypeCode NOT_KNOWN = new MobilityCapabilityTerrainTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MobilityCapabilityTerrainTypeCode NOT_OTHERWISE_SPECIFIED = new MobilityCapabilityTerrainTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MobilityCapabilityTerrainTypeCode ROAD = new MobilityCapabilityTerrainTypeCode(
			"Road",
			"ROAD",
			"The capability is valid for terrain specifically prepared for vehicle movement.");
	public static final MobilityCapabilityTerrainTypeCode SNOW = new MobilityCapabilityTerrainTypeCode(
			"Snow",
			"SNOW",
			"The capability is valid for terrain covered by snow.");
	public static final MobilityCapabilityTerrainTypeCode TERRAIN_INDEPENDENT = new MobilityCapabilityTerrainTypeCode(
			"Terrain independent",
			"TERIND",
			"The capability is independent of the class of terrain.");

	private MobilityCapabilityTerrainTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
