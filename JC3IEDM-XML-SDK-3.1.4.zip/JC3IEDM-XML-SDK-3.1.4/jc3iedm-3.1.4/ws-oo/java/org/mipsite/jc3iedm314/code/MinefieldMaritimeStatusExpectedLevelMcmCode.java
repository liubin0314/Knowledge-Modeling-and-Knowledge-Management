/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusExpectedLevelMcmCode extends CodeDomain {

	public static String getComment() {
		return "The specific values of expected mine countermeasures (MCM) to be employed against a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusExpectedLevelMcmCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusExpectedLevelMcmCode>();

	public static MinefieldMaritimeStatusExpectedLevelMcmCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusExpectedLevelMcmCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusExpectedLevelMcmCode HEAVY_MCM = new MinefieldMaritimeStatusExpectedLevelMcmCode(
			"Heavy MCM",
			"HVYMCM",
			"Heavy mine counter measures are expected to be employed against the MINEFIELD-MARITIME.");
	public static final MinefieldMaritimeStatusExpectedLevelMcmCode LIGHT_MCM = new MinefieldMaritimeStatusExpectedLevelMcmCode(
			"Light MCM",
			"LGTMCM",
			"Light mine counter measures are expected to be employed against the MINEFIELD-MARITIME.");
	public static final MinefieldMaritimeStatusExpectedLevelMcmCode MODERATE_MCM = new MinefieldMaritimeStatusExpectedLevelMcmCode(
			"Moderate MCM",
			"MODMCM",
			"Moderate mine counter measures are expected to be employed against the MINEFIELD-MARITIME.");
	public static final MinefieldMaritimeStatusExpectedLevelMcmCode NO_MCM = new MinefieldMaritimeStatusExpectedLevelMcmCode(
			"No MCM",
			"NOMCM",
			"No mine counter measures are expected to be employed against the MINEFIELD-MARITIME.");

	private MinefieldMaritimeStatusExpectedLevelMcmCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
