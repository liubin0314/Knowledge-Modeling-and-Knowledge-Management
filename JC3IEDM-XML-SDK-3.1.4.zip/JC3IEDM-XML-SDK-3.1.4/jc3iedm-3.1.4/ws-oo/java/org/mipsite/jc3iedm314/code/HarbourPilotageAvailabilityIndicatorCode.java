/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourPilotageAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a pilot is available at the port.";
	}

	private static HashMap<String, HarbourPilotageAvailabilityIndicatorCode> physicalToCode = new HashMap<String, HarbourPilotageAvailabilityIndicatorCode>();

	public static HarbourPilotageAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourPilotageAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourPilotageAvailabilityIndicatorCode NO = new HarbourPilotageAvailabilityIndicatorCode(
			"No",
			"NO",
			"Pilotage is not available at the port.");
	public static final HarbourPilotageAvailabilityIndicatorCode YES = new HarbourPilotageAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Pilotage is available at the port.");

	private HarbourPilotageAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
