/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OperationalInformationGroupOrganisationAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between a specific OPERATIONAL-INFORMATION-GROUP and a specific ORGANISATION in a specific OPERATIONAL-INFORMATION-GROUP-ORGANISATION-ASSOCIATION.";
	}

	private static HashMap<String, OperationalInformationGroupOrganisationAssociationCategoryCode> physicalToCode = new HashMap<String, OperationalInformationGroupOrganisationAssociationCategoryCode>();

	public static OperationalInformationGroupOrganisationAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OperationalInformationGroupOrganisationAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OperationalInformationGroupOrganisationAssociationCategoryCode IS_UNDER_OPERATIONAL_RESPONSIBILITY_OF = new OperationalInformationGroupOrganisationAssociationCategoryCode(
			"Is under operational responsibility of",
			"RESP",
			"The specific OPERATIONAL-INFORMATION-GROUP has the specific ORGANISATION as the operationally responsible party for creating and populating it.");
	public static final OperationalInformationGroupOrganisationAssociationCategoryCode IS_UNDER_PROXY_RESPONSIBILITY_FOR = new OperationalInformationGroupOrganisationAssociationCategoryCode(
			"Is under proxy responsibility for",
			"PROXY",
			"The specific OPERATIONAL-INFORMATION-GROUP is currently maintained by the specified ORGANISATION on behalf of the operationally responsible organisation.");

	private OperationalInformationGroupOrganisationAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
