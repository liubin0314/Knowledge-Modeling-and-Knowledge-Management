/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NuclearYieldGroupCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the explosive yield of a nuclear weapon that is the amount of energy discharged when the weapon is detonated, expressed in the equivalent mass of trinitrotoluene (TNT), either in kilotons (thousands of tons of TNT) or megatons (millions of tons of TNT).";
	}

	private static HashMap<String, NuclearYieldGroupCode> physicalToCode = new HashMap<String, NuclearYieldGroupCode>();

	public static NuclearYieldGroupCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NuclearYieldGroupCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NuclearYieldGroupCode ALFA = new NuclearYieldGroupCode(
			"ALFA",
			"ALFA",
			"Yield Group ALFA is less than 2 KT.");
	public static final NuclearYieldGroupCode BRAVO = new NuclearYieldGroupCode(
			"BRAVO",
			"BRAVO",
			"Yield Group BRAVO is 2 KT to less than 5 KT.");
	public static final NuclearYieldGroupCode CHARLIE = new NuclearYieldGroupCode(
			"CHARLIE",
			"CHARLI",
			"Yield Group CHARLIE is 5 KT to less than 30 KT.");
	public static final NuclearYieldGroupCode DELTA = new NuclearYieldGroupCode(
			"DELTA",
			"DELTA",
			"Yield Group DELTA is 30 KT to less than 100 KT.");
	public static final NuclearYieldGroupCode ECHO = new NuclearYieldGroupCode(
			"ECHO",
			"ECHO",
			"Yield Group ECHO is 100 KT to less than 300 KT.");
	public static final NuclearYieldGroupCode FOXTROT = new NuclearYieldGroupCode(
			"FOXTROT",
			"FOXTRT",
			"Yield Group FOXTROT is 300 KT to less than 1000 KT.");
	public static final NuclearYieldGroupCode GOLF = new NuclearYieldGroupCode(
			"GOLF",
			"GOLF",
			"Yield Group GOLF is 1000 KT to less than 3000 KT.");
	public static final NuclearYieldGroupCode NOT_KNOWN = new NuclearYieldGroupCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NuclearYieldGroupCode NOT_OTHERWISE_SPECIFIED = new NuclearYieldGroupCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private NuclearYieldGroupCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
