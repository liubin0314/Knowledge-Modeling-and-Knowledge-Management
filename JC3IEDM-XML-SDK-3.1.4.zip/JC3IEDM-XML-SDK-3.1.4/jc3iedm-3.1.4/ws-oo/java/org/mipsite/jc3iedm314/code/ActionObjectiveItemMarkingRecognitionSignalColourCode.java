/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveItemMarkingRecognitionSignalColourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the coloration of the marking signal.";
	}

	private static HashMap<String, ActionObjectiveItemMarkingRecognitionSignalColourCode> physicalToCode = new HashMap<String, ActionObjectiveItemMarkingRecognitionSignalColourCode>();

	public static ActionObjectiveItemMarkingRecognitionSignalColourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveItemMarkingRecognitionSignalColourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode BLUE = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Blue",
			"BLUE",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode GREEN = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Green",
			"GREEN",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode NOT_KNOWN = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode NOT_OTHERWISE_SPECIFIED = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode ORANGE = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Orange",
			"ORANGE",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode PURPLE = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Purple",
			"PURPLE",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode RED = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Red",
			"RED",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode WHITE = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"White",
			"WHITE",
			"Self defined.");
	public static final ActionObjectiveItemMarkingRecognitionSignalColourCode YELLOW = new ActionObjectiveItemMarkingRecognitionSignalColourCode(
			"Yellow",
			"YELLOW",
			"Self defined.");

	private ActionObjectiveItemMarkingRecognitionSignalColourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
