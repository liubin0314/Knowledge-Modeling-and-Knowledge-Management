/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionAircraftEmploymentApproachOffsetCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the side of the initial point-to-target line that the attack aircraft is cleared to manoeuvre in during the target run.";
	}

	private static HashMap<String, ActionAircraftEmploymentApproachOffsetCode> physicalToCode = new HashMap<String, ActionAircraftEmploymentApproachOffsetCode>();

	public static ActionAircraftEmploymentApproachOffsetCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionAircraftEmploymentApproachOffsetCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionAircraftEmploymentApproachOffsetCode LEFT = new ActionAircraftEmploymentApproachOffsetCode(
			"Left",
			"LEFT",
			"A turn 90 degrees counter clockwise.");
	public static final ActionAircraftEmploymentApproachOffsetCode RIGHT = new ActionAircraftEmploymentApproachOffsetCode(
			"Right",
			"RIGHT",
			"A turn 90 degrees clockwise.");
	public static final ActionAircraftEmploymentApproachOffsetCode RIGHT_OR_LEFT = new ActionAircraftEmploymentApproachOffsetCode(
			"Right or left",
			"RL",
			"A turn 90 degrees either clockwise or counter clockwise.");

	private ActionAircraftEmploymentApproachOffsetCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
