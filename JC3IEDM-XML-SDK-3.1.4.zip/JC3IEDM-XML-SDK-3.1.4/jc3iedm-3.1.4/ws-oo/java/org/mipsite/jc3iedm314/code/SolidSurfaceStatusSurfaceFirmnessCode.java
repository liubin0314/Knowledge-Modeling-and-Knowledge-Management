/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SolidSurfaceStatusSurfaceFirmnessCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the firmness of a surface area, in terms of its ability to support land vehicles or helicopters.";
	}

	private static HashMap<String, SolidSurfaceStatusSurfaceFirmnessCode> physicalToCode = new HashMap<String, SolidSurfaceStatusSurfaceFirmnessCode>();

	public static SolidSurfaceStatusSurfaceFirmnessCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SolidSurfaceStatusSurfaceFirmnessCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SolidSurfaceStatusSurfaceFirmnessCode HARD = new SolidSurfaceStatusSurfaceFirmnessCode(
			"Hard",
			"HARD",
			"The surface area is able to support the helicopter and can be used by two-wheel drive vehicles or four-wheel drive vehicles and trailers.");
	public static final SolidSurfaceStatusSurfaceFirmnessCode MODERATE = new SolidSurfaceStatusSurfaceFirmnessCode(
			"Moderate",
			"MODER",
			"The surface area can be used by three or four ton vehicles which should be able to start from rest using four-wheel drive.");
	public static final SolidSurfaceStatusSurfaceFirmnessCode SOFT = new SolidSurfaceStatusSurfaceFirmnessCode(
			"Soft",
			"SOFT",
			"On the surface area, four-wheel drive vehicles cannot start from rest but might be able to cross if already on the move.");
	public static final SolidSurfaceStatusSurfaceFirmnessCode VERY_SOFT = new SolidSurfaceStatusSurfaceFirmnessCode(
			"Very soft",
			"VSOFT",
			"Wheeled vehicles cannot progress across the surface.");

	private SolidSurfaceStatusSurfaceFirmnessCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
