/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkFrequencyBandCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the frequency band of a specific NETWORK.";
	}

	private static HashMap<String, NetworkFrequencyBandCode> physicalToCode = new HashMap<String, NetworkFrequencyBandCode>();

	public static NetworkFrequencyBandCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkFrequencyBandCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkFrequencyBandCode EXTRA_HIGH_FREQUENCY = new NetworkFrequencyBandCode(
			"Extra high frequency",
			"EHF",
			"A frequency of 30 - 300 gigahertz. (EHF)");
	public static final NetworkFrequencyBandCode HIGH_FREQUENCY = new NetworkFrequencyBandCode(
			"High frequency",
			"HF",
			"A frequency of 3 - 30 megahertz. (HF)");
	public static final NetworkFrequencyBandCode LOW_FREQUENCY = new NetworkFrequencyBandCode(
			"Low frequency",
			"LF",
			"A frequency of 30 - 300 kilohertz. (LF)");
	public static final NetworkFrequencyBandCode MEDIUM_FREQUENCY = new NetworkFrequencyBandCode(
			"Medium frequency",
			"MF",
			"A frequency of 300 - 3000 kilohertz. (MF)");
	public static final NetworkFrequencyBandCode SUPER_HIGH_FREQUENCY = new NetworkFrequencyBandCode(
			"Super high frequency",
			"SHF",
			"A frequency of 3 - 30 gigahertz. (SHF)");
	public static final NetworkFrequencyBandCode ULTRA_HIGH_FREQUENCY = new NetworkFrequencyBandCode(
			"Ultra high frequency",
			"UHF",
			"A frequency of 300 - 3000 megahertz. (UHF)");
	public static final NetworkFrequencyBandCode VERY_HIGH_FREQUENCY = new NetworkFrequencyBandCode(
			"Very high frequency",
			"VHF",
			"A frequency of 30 - 300 megahertz. (VHF)");
	public static final NetworkFrequencyBandCode VERY_LOW_FREQUENCY = new NetworkFrequencyBandCode(
			"Very low frequency",
			"VLF",
			"A frequency of 3 - 30 kilohertz. (VLF)");

	private NetworkFrequencyBandCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
