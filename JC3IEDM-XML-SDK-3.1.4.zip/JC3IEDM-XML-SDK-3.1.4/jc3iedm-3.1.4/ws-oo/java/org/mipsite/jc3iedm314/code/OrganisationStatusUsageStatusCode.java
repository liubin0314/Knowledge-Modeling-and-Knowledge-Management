/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusUsageStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the usage of a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusUsageStatusCode> physicalToCode = new HashMap<String, OrganisationStatusUsageStatusCode>();

	public static OrganisationStatusUsageStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusUsageStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusUsageStatusCode IN_ACTION = new OrganisationStatusUsageStatusCode(
			"In action",
			"INACT",
			"A status indicating that an ORGANISATION is performing its operational mission.");
	public static final OrganisationStatusUsageStatusCode NOT_KNOWN = new OrganisationStatusUsageStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusUsageStatusCode OUT_OF_ACTION = new OrganisationStatusUsageStatusCode(
			"Out of action",
			"OUTACT",
			"A status indicating that an ORGANISATION is not performing its operational mission.");

	private OrganisationStatusUsageStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
