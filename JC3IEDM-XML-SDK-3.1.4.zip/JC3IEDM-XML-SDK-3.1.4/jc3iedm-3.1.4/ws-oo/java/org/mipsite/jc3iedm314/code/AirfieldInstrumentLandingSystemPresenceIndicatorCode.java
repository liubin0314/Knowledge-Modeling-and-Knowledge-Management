/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldInstrumentLandingSystemPresenceIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific AIRFIELD has an instrument landing system.";
	}

	private static HashMap<String, AirfieldInstrumentLandingSystemPresenceIndicatorCode> physicalToCode = new HashMap<String, AirfieldInstrumentLandingSystemPresenceIndicatorCode>();

	public static AirfieldInstrumentLandingSystemPresenceIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldInstrumentLandingSystemPresenceIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldInstrumentLandingSystemPresenceIndicatorCode NO = new AirfieldInstrumentLandingSystemPresenceIndicatorCode(
			"No",
			"NO",
			"At the specific AIRFIELD there is no instrument landing system.");
	public static final AirfieldInstrumentLandingSystemPresenceIndicatorCode YES = new AirfieldInstrumentLandingSystemPresenceIndicatorCode(
			"Yes",
			"YES",
			"At the specific AIRFIELD there is an instrument landing system.");

	private AirfieldInstrumentLandingSystemPresenceIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
