/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NuclearWeaponEventCraterPresenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the presence of a crater.";
	}

	private static HashMap<String, NuclearWeaponEventCraterPresenceCode> physicalToCode = new HashMap<String, NuclearWeaponEventCraterPresenceCode>();

	public static NuclearWeaponEventCraterPresenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NuclearWeaponEventCraterPresenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NuclearWeaponEventCraterPresenceCode CRATER_PRESENT = new NuclearWeaponEventCraterPresenceCode(
			"Crater present",
			"CRATER",
			"There is a crater present.");
	public static final NuclearWeaponEventCraterPresenceCode NOT_KNOWN = new NuclearWeaponEventCraterPresenceCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NuclearWeaponEventCraterPresenceCode NO_CRATER_PRESENT = new NuclearWeaponEventCraterPresenceCode(
			"No crater present",
			"NONE",
			"There is a no crater present.");

	private NuclearWeaponEventCraterPresenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
