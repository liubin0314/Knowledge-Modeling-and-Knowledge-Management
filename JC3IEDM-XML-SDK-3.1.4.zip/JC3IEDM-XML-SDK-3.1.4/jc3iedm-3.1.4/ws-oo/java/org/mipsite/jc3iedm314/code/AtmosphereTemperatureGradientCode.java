/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AtmosphereTemperatureGradientCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents heat change with respect to the ground and 100 m in elevation in a certain area. Acts as an indication of vertical air movement between the ground and higher elevations.";
	}

	private static HashMap<String, AtmosphereTemperatureGradientCode> physicalToCode = new HashMap<String, AtmosphereTemperatureGradientCode>();

	public static AtmosphereTemperatureGradientCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AtmosphereTemperatureGradientCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AtmosphereTemperatureGradientCode NEUTRAL = new AtmosphereTemperatureGradientCode(
			"Neutral",
			"NEUTRL",
			"A one degree Kelvin, or less, temperature gradient between the ground and 100 metres above ground level.");
	public static final AtmosphereTemperatureGradientCode NOT_KNOWN = new AtmosphereTemperatureGradientCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AtmosphereTemperatureGradientCode STABLE = new AtmosphereTemperatureGradientCode(
			"Stable",
			"STABLE",
			"More than one degree Kelvin positive temperature gradient between the ground and 100 metres above ground level. (colder lower layers)");
	public static final AtmosphereTemperatureGradientCode UNSTABLE = new AtmosphereTemperatureGradientCode(
			"Unstable",
			"UNSTAB",
			"More than one degree Kelvin negative temperature gradient between the ground and 100 metres above ground level. (hotter lower layers)");

	private AtmosphereTemperatureGradientCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
