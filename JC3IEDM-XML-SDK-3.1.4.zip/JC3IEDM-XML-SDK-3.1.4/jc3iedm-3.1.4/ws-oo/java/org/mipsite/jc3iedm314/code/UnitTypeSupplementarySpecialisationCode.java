/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UnitTypeSupplementarySpecialisationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that supplements the designation of a particular UNIT-TYPE.";
	}

	private static HashMap<String, UnitTypeSupplementarySpecialisationCode> physicalToCode = new HashMap<String, UnitTypeSupplementarySpecialisationCode>();

	public static UnitTypeSupplementarySpecialisationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UnitTypeSupplementarySpecialisationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UnitTypeSupplementarySpecialisationCode AIR = new UnitTypeSupplementarySpecialisationCode(
			"Air",
			"AIR",
			"A UNIT-TYPE that, whatever its primary function is, employs principally air assets.");
	public static final UnitTypeSupplementarySpecialisationCode AIRBORNE = new UnitTypeSupplementarySpecialisationCode(
			"Airborne",
			"AIRBRN",
			"A UNIT-TYPE that, whatever its primary function is, is specially trained to carry out operations, either by paradrop or air landing, following an air movement.");
	public static final UnitTypeSupplementarySpecialisationCode AMPHIBIOUS = new UnitTypeSupplementarySpecialisationCode(
			"Amphibious",
			"AMPH",
			"A UNIT-TYPE that, whatever its primary function is, is able to conduct an operation launched from the sea by military forces against a hostile or potentially hostile shore.");
	public static final UnitTypeSupplementarySpecialisationCode AIR_ASSAULT = new UnitTypeSupplementarySpecialisationCode(
			"Air assault",
			"ARASLT",
			"A UNIT-TYPE that, whatever its primary function is, employs helicopter assets as an integral element of its assault operations.");
	public static final UnitTypeSupplementarySpecialisationCode ARCTIC = new UnitTypeSupplementarySpecialisationCode(
			"Arctic",
			"ARCTIC",
			"A UNIT-TYPE that, whatever its primary function is, is able to perform a mission in arctic environment.");
	public static final UnitTypeSupplementarySpecialisationCode ARMOURED = new UnitTypeSupplementarySpecialisationCode(
			"Armoured",
			"ARMORD",
			"A UNIT-TYPE that, whatever its primary function is, employs principally armoured assets.");
	public static final UnitTypeSupplementarySpecialisationCode GROUND = new UnitTypeSupplementarySpecialisationCode(
			"Ground",
			"GROUND",
			"A UNIT-TYPE that, whatever its primary function is, employs principally ground assets.");
	public static final UnitTypeSupplementarySpecialisationCode LIGHT_UNIT = new UnitTypeSupplementarySpecialisationCode(
			"Light unit",
			"LIGHT",
			"A UNIT-TYPE that, whatever its primary function is, is equipped with materiel of small weight.");
	public static final UnitTypeSupplementarySpecialisationCode MARINE = new UnitTypeSupplementarySpecialisationCode(
			"Marine",
			"MARINE",
			"A UNIT-TYPE that is capable of performing marine operations in addition to its primary function.");
	public static final UnitTypeSupplementarySpecialisationCode MECHANISED = new UnitTypeSupplementarySpecialisationCode(
			"Mechanised",
			"MECH",
			"A UNIT-TYPE that, whatever its primary function is, employs principally mechanised assets.");
	public static final UnitTypeSupplementarySpecialisationCode MOUNTAIN = new UnitTypeSupplementarySpecialisationCode(
			"Mountain",
			"MOUNTN",
			"A UNIT-TYPE that, whatever its primary function is, is dedicated to conduct military operations in mountainous areas.");
	public static final UnitTypeSupplementarySpecialisationCode MOTORISED = new UnitTypeSupplementarySpecialisationCode(
			"Motorised",
			"MTRSD",
			"A UNIT-TYPE that, whatever its primary function is, employs principally motorised assets.");
	public static final UnitTypeSupplementarySpecialisationCode NAVAL = new UnitTypeSupplementarySpecialisationCode(
			"Naval",
			"NAVAL",
			"A UNIT-TYPE that, whatever its primary function is, is dedicated to conduct operations in a maritime environment.");

	private UnitTypeSupplementarySpecialisationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
