/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeSubfunctionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the intended purpose of the MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeSubfunctionCode> physicalToCode = new HashMap<String, MinefieldMaritimeSubfunctionCode>();

	public static MinefieldMaritimeSubfunctionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeSubfunctionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeSubfunctionCode ANTI_INVASION = new MinefieldMaritimeSubfunctionCode(
			"Anti-invasion",
			"ANTINV",
			"A maritime minefield that is primarily intended to cause damage to enemy vessels engaging in an attack on a friendly shore line.");
	public static final MinefieldMaritimeSubfunctionCode ANTI_PASSAGE = new MinefieldMaritimeSubfunctionCode(
			"Anti-passage",
			"ANTPSG",
			"A maritime minefield that is primarily intended to cause damage to enemy vessels in a specific channel.");
	public static final MinefieldMaritimeSubfunctionCode ANTI_SHIPPING = new MinefieldMaritimeSubfunctionCode(
			"Anti-shipping",
			"ANTSHP",
			"A maritime minefield that is primarily intended to cause damage to enemy ships.");
	public static final MinefieldMaritimeSubfunctionCode ATTRITION = new MinefieldMaritimeSubfunctionCode(
			"Attrition",
			"ATTRIT",
			"A maritime minefield that is primarily intended to cause damage to enemy vessels over time.");
	public static final MinefieldMaritimeSubfunctionCode BLOCKADE = new MinefieldMaritimeSubfunctionCode(
			"Blockade",
			"BLCKDE",
			"A maritime minefield that is primarily intended to prevent the passage of enemy vessels into or out of a specific area with respect to a fixed location on land.");
	public static final MinefieldMaritimeSubfunctionCode DELAY = new MinefieldMaritimeSubfunctionCode(
			"Delay",
			"DELAY",
			"A maritime minefield that is primarily intended to impede the movement of enemy vessels.");
	public static final MinefieldMaritimeSubfunctionCode HARASSMENT = new MinefieldMaritimeSubfunctionCode(
			"Harassment",
			"HARASS",
			"A maritime minefield that is primarily intended to cause damage to enemy vessels over a period of time in a random manner.");
	public static final MinefieldMaritimeSubfunctionCode NOT_OTHERWISE_SPECIFIED = new MinefieldMaritimeSubfunctionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MinefieldMaritimeSubfunctionCode PORT_CLOSURE = new MinefieldMaritimeSubfunctionCode(
			"Port closure",
			"PRTCLS",
			"A maritime minefield that is primarily intended to deny the usage of a harbour/port to an enemy.");
	public static final MinefieldMaritimeSubfunctionCode STRAIT_CLOSURE = new MinefieldMaritimeSubfunctionCode(
			"Strait closure",
			"STRCLS",
			"A maritime minefield that is primarily intended to deny the usage of a particular strait to enemy vessels.");

	private MinefieldMaritimeSubfunctionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
