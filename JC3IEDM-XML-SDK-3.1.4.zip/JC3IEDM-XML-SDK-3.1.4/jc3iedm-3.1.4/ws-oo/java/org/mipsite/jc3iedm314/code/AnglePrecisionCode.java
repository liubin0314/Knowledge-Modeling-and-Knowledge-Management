/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AnglePrecisionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the maximum resolution used for the expression of a value of an angle.";
	}

	private static HashMap<String, AnglePrecisionCode> physicalToCode = new HashMap<String, AnglePrecisionCode>();

	public static AnglePrecisionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AnglePrecisionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AnglePrecisionCode _1_1000_MINUTE = new AnglePrecisionCode(
			"1/1000 minute",
			"1000MN",
			"Angular precision is expressed to the precision of 1/1000 of a minute.");
	public static final AnglePrecisionCode _1_100_MINUTE = new AnglePrecisionCode(
			"1/100 minute",
			"100MN",
			"Angular precision is expressed to the precision of 1/100 of a minute (centiminute).");
	public static final AnglePrecisionCode _1_100_SECOND = new AnglePrecisionCode(
			"1/100 second",
			"100SEC",
			"Angular precision is expressed to the precision of 1/100 of a second.");
	public static final AnglePrecisionCode _1_10_DEGREE = new AnglePrecisionCode(
			"1/10 degree",
			"10DEG",
			"Angular precision is expressed to the precision of 1/10 of a degree.");
	public static final AnglePrecisionCode _1_10_MINUTE = new AnglePrecisionCode(
			"1/10 minute",
			"10MN",
			"Angular precision is expressed to the precision of 1/10 of a minute.");
	public static final AnglePrecisionCode _1_10_SECOND = new AnglePrecisionCode(
			"1/10 second",
			"10SEC",
			"Angular precision is expressed to the precision of 1/10 of a second.");
	public static final AnglePrecisionCode DEGREE = new AnglePrecisionCode(
			"Degree",
			"DEGREE",
			"Angular precision is expressed to the precision of a degree (60 minutes).");
	public static final AnglePrecisionCode MIL = new AnglePrecisionCode(
			"Mil",
			"MIL",
			"Angular precision is expressed to the precision of 1 mil (1/6400 of a full circle).");
	public static final AnglePrecisionCode MINUTE = new AnglePrecisionCode(
			"Minute",
			"MINUTE",
			"Angular precision is expressed to the precision of a minute (60 seconds).");
	public static final AnglePrecisionCode SECOND = new AnglePrecisionCode(
			"Second",
			"SECOND",
			"Angular precision is expressed to the precision of a second.");

	private AnglePrecisionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
