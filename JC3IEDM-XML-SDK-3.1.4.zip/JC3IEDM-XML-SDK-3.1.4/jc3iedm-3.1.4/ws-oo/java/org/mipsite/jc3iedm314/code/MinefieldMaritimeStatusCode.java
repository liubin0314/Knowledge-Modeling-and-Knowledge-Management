/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the known status of a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusCode>();

	public static MinefieldMaritimeStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusCode CLOSED = new MinefieldMaritimeStatusCode(
			"Closed",
			"CLOSED",
			"A maritime minefield area that presents such a threat that waterborne shipping is prevented from moving.");
	public static final MinefieldMaritimeStatusCode OPEN = new MinefieldMaritimeStatusCode(
			"Open",
			"OPEN",
			"No known threat to shipping from maritime mines exists.");

	private MinefieldMaritimeStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
