/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RunwayPavementEvaluationMethodCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the pavement evaluation method classification, which is part of the standard ICAO (International Civil Aviation Organization) method of reporting pavement strength for pavements with bearing strength greater than 5,700 kilograms (12,500 pounds).";
	}

	private static HashMap<String, RunwayPavementEvaluationMethodCode> physicalToCode = new HashMap<String, RunwayPavementEvaluationMethodCode>();

	public static RunwayPavementEvaluationMethodCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RunwayPavementEvaluationMethodCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RunwayPavementEvaluationMethodCode TECHNICAL_EVALUATION = new RunwayPavementEvaluationMethodCode(
			"Technical evaluation",
			"T",
			"The specific value, which indicates that the pavement evaluation method is based on a technical study.");
	public static final RunwayPavementEvaluationMethodCode BY_EXPERIENCE = new RunwayPavementEvaluationMethodCode(
			"By experience",
			"U",
			"The specific value, which indicates that the pavement evaluation method is determined by experience of aircraft using the pavement.");

	private RunwayPavementEvaluationMethodCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
