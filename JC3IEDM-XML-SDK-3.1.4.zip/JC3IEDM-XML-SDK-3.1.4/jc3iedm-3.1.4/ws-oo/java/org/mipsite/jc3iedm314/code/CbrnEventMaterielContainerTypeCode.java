/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CbrnEventMaterielContainerTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of container that stores the materiel (agent) involved in a specific CBRN-EVENT and characterised in ATP-45.";
	}

	private static HashMap<String, CbrnEventMaterielContainerTypeCode> physicalToCode = new HashMap<String, CbrnEventMaterielContainerTypeCode>();

	public static CbrnEventMaterielContainerTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CbrnEventMaterielContainerTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CbrnEventMaterielContainerTypeCode BOMBLETS = new CbrnEventMaterielContainerTypeCode(
			"Bomblets",
			"BML",
			"A small munition capable of containing a biological warfare agent; a submunition. Numerous bomblets could be packed inside a larger munition (e.g., a bomb or warhead) that would explode in the air scattering the bomblets over a relatively wide area.");
	public static final CbrnEventMaterielContainerTypeCode BOMB = new CbrnEventMaterielContainerTypeCode(
			"Bomb",
			"BOM",
			"A case filled with explosive, inflammable material, poison gas, or smoke, etc., dropped from aircraft, or thrown or deposited by hand.");
	public static final CbrnEventMaterielContainerTypeCode PRESSURIZED_GAS_BOTTLE = new CbrnEventMaterielContainerTypeCode(
			"Pressurized gas bottle",
			"BTL",
			"A large metal cylinder holding liquefied gas under pressure.");
	public static final CbrnEventMaterielContainerTypeCode BUNKER = new CbrnEventMaterielContainerTypeCode(
			"Bunker",
			"BUK",
			"No definition provided in ATP-45(B).");
	public static final CbrnEventMaterielContainerTypeCode GENERIC_STORAGE_CONTAINER = new CbrnEventMaterielContainerTypeCode(
			"Generic storage container",
			"CON",
			"A receptacle in which material is held or carried.");
	public static final CbrnEventMaterielContainerTypeCode NOMINAL_200_LITRE_STORAGE_DRUM = new CbrnEventMaterielContainerTypeCode(
			"Nominal 200 litre storage drum",
			"DRM",
			"A cylindrical container that holds 200 litres.");
	public static final CbrnEventMaterielContainerTypeCode GENERATOR_AEROSOL = new CbrnEventMaterielContainerTypeCode(
			"Generator (aerosol)",
			"GEN",
			"An instrument or machine capable of releasing a substance as a fine spray by subjecting it to pressure.");
	public static final CbrnEventMaterielContainerTypeCode MINE_NBC_FILLED_ONLY = new CbrnEventMaterielContainerTypeCode(
			"Mine (NBC filled only)",
			"MNE",
			"A mine containing a chemical or radiological agent designed to kill, injure, or incapacitate personnel or to contaminate materiel or terrain.");
	public static final CbrnEventMaterielContainerTypeCode MISSILE = new CbrnEventMaterielContainerTypeCode(
			"Missile",
			"MSL",
			"A weapon that is self-propelled or directed by remote control, carrying conventional or nuclear explosive.");
	public static final CbrnEventMaterielContainerTypeCode NOT_KNOWN = new CbrnEventMaterielContainerTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final CbrnEventMaterielContainerTypeCode REACTOR = new CbrnEventMaterielContainerTypeCode(
			"Reactor",
			"RCT",
			"A facility that contains a controlled nuclear fission chain reaction. It can be used to generate electricity, conduct research, and produce isotopes and manmade elements such as plutonium.");
	public static final CbrnEventMaterielContainerTypeCode ROCKET = new CbrnEventMaterielContainerTypeCode(
			"Rocket",
			"RKT",
			"A cylindrical projectile that can be propelled to a great height or distance by the combustion of its contents.");
	public static final CbrnEventMaterielContainerTypeCode SHELL = new CbrnEventMaterielContainerTypeCode(
			"Shell",
			"SHL",
			"An explosive artillery projectile or bomb.");
	public static final CbrnEventMaterielContainerTypeCode SPRAY_TANK = new CbrnEventMaterielContainerTypeCode(
			"Spray (tank)",
			"SPR",
			"A container used to dispense chemical or biological agents.");
	public static final CbrnEventMaterielContainerTypeCode STOCKPILE = new CbrnEventMaterielContainerTypeCode(
			"Stockpile",
			"STK",
			"No definition provided in ATP-45(B).");
	public static final CbrnEventMaterielContainerTypeCode TANK = new CbrnEventMaterielContainerTypeCode(
			"Tank",
			"TNK",
			"A large receptacle or storage chamber, especially for liquid or gas.");
	public static final CbrnEventMaterielContainerTypeCode TORPEDO = new CbrnEventMaterielContainerTypeCode(
			"Torpedo",
			"TOR",
			"A cigar-shaped self-propelled underwater missile designed to be fired from a ship, submarine, or an aircraft.");
	public static final CbrnEventMaterielContainerTypeCode WASTE = new CbrnEventMaterielContainerTypeCode(
			"Waste",
			"WST",
			"A container of wastes that includes materials such as laboratory wastes and protective clothing.");

	private CbrnEventMaterielContainerTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
