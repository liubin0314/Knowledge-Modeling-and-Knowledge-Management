/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VegetationSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed type of vegetation.";
	}

	private static HashMap<String, VegetationSubcategoryCode> physicalToCode = new HashMap<String, VegetationSubcategoryCode>();

	public static VegetationSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VegetationSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VegetationSubcategoryCode BAMBOO_CANE = new VegetationSubcategoryCode(
			"Bamboo/cane",
			"BAMBOO",
			"Woody, treelike grass.");
	public static final VegetationSubcategoryCode BOTANICAL_GARDEN = new VegetationSubcategoryCode(
			"Botanical garden",
			"BTNCLG",
			"A cultural area where plants and/or trees are displayed.");
	public static final VegetationSubcategoryCode CROPLAND = new VegetationSubcategoryCode(
			"Cropland",
			"CRPLND",
			"An area that has been tilled for the planting of crops.");
	public static final VegetationSubcategoryCode DESERT = new VegetationSubcategoryCode(
			"Desert",
			"DESERT",
			"A waterless, desolate area of land with little or no vegetation typically covered with sand.");
	public static final VegetationSubcategoryCode FOREST = new VegetationSubcategoryCode(
			"Forest",
			"FOREST",
			"A dense growth of trees, plants and underbrush covering a large area.");
	public static final VegetationSubcategoryCode GRASS_SCRUB_BRUSH = new VegetationSubcategoryCode(
			"Grass/scrub/brush",
			"GRASS",
			"Area composed of uncultured plants which may have some woody tissue.");
	public static final VegetationSubcategoryCode GRASSLAND = new VegetationSubcategoryCode(
			"Grassland",
			"GRSLND",
			"An area composed of uncultured plants which have little or no woody tissue.");
	public static final VegetationSubcategoryCode HEDGEROW = new VegetationSubcategoryCode(
			"Hedgerow",
			"HDGERW",
			"A continuous growth of shrubbery planted as a fence, a boundary, or a wind break.");
	public static final VegetationSubcategoryCode HOPS = new VegetationSubcategoryCode(
			"Hops",
			"HOPS",
			"An area covered by the systematic planting of hop vines.");
	public static final VegetationSubcategoryCode JUNGLE_CULTIVATION = new VegetationSubcategoryCode(
			"Jungle, cultivation",
			"JUNGC",
			"Areas which include areas such as rice paddies which will tend to be open, flat, dirty and swampy to areas such as rubber plantations which offer similar characteristics to primary jungle except for the fact that the trees will be in straight lines.");
	public static final VegetationSubcategoryCode JUNGLE_COASTAL_ESTUARY = new VegetationSubcategoryCode(
			"Jungle, coastal/estuary",
			"JUNGCE",
			"An area of jungle on generally swampy ground where movement is slow and difficult.");
	public static final VegetationSubcategoryCode JUNGLE_PRIMARY = new VegetationSubcategoryCode(
			"Jungle, primary",
			"JUNGP",
			"An area in lowland tropics, which has heavy rainfall. It has a thick 3 tier canopy up to 60m high and a reasonably clear floor that may permit some vehicular movement. Visibility may not exceed 50m.");
	public static final VegetationSubcategoryCode JUNGLE_SECONDARY = new VegetationSubcategoryCode(
			"Jungle, secondary",
			"JUNGS",
			"An area that has thick undergrowth created through rapid growth after an area of primary jungle has been cleared, movement will be slow and noisy, heat increased due to a lack of canopy and visibility will be reduced to around 20m.");
	public static final VegetationSubcategoryCode MARSH = new VegetationSubcategoryCode(
			"Marsh",
			"MARSH",
			"An area of wet, often spongy ground that is subject to frequent or tidal inundations, but not considered to be continually under water. It is characterized by the growth of non woody plants and by the lack of trees.");
	public static final VegetationSubcategoryCode NURSERY = new VegetationSubcategoryCode(
			"Nursery",
			"NURSRY",
			"A place where shrubs, flowers, plants and trees are grown for transplanting, seed or grafting.");
	public static final VegetationSubcategoryCode OASIS = new VegetationSubcategoryCode(
			"Oasis",
			"OASIS",
			"A small, isolated, fertile or green area in a desert region usually having a spring or well.");
	public static final VegetationSubcategoryCode ORCHARD_PLANTATION = new VegetationSubcategoryCode(
			"Orchard/plantation",
			"ORCHRD",
			"An area covered by systematic plantings of trees which yield fruits, nuts or other products.");
	public static final VegetationSubcategoryCode SAVANNAH = new VegetationSubcategoryCode(
			"Savannah",
			"SAVNNH",
			"A grassy plain in tropical and subtropical regions, with few trees.");
	public static final VegetationSubcategoryCode SCRUB_BRUSH_BUSH = new VegetationSubcategoryCode(
			"Scrub/brush/bush",
			"SCRUB",
			"A characterisation of an area with low-growing woody plants.");
	public static final VegetationSubcategoryCode SWAMP = new VegetationSubcategoryCode(
			"Swamp",
			"SWAMP",
			"A low lying saturated area covered with water all or most of the year, where accumulating dead vegetation does not rapidly decay. It can exist on flat-lying areas created by certain geomorphic environments. The vegetation mainly consists of hydrophytic trees and/or scrubs whose roots are adapted to wet conditions, with an open to very dense canopy closure.");
	public static final VegetationSubcategoryCode TREES = new VegetationSubcategoryCode(
			"Trees",
			"TREES",
			"Woody-perennial plants, having a self-supporting main stem or trunk.");
	public static final VegetationSubcategoryCode TUNDRA = new VegetationSubcategoryCode(
			"Tundra",
			"TUNDRA",
			"A prairie-like region in the Arctic and Subarctic zones which sustains a growth of low vegetation.");
	public static final VegetationSubcategoryCode VINEYARD = new VegetationSubcategoryCode(
			"Vineyard",
			"VNEYRD",
			"An area covered by the systematic planting of grape vines.");

	private VegetationSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
