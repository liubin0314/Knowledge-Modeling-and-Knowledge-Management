/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonBloodTypeCode extends CodeDomain {

	public static String getComment() {
		return "A code which represents the specific blood type of a PERSON.";
	}

	private static HashMap<String, PersonBloodTypeCode> physicalToCode = new HashMap<String, PersonBloodTypeCode>();

	public static PersonBloodTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonBloodTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonBloodTypeCode A_RH_POSITIVE = new PersonBloodTypeCode(
			"A Rh Positive",
			"APLUS",
			"The circulating red blood cells with 'A' antigen and the presence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode A_RH_NEGATIVE = new PersonBloodTypeCode(
			"A Rh Negative",
			"AMNUS",
			"The circulating red blood cells with 'A' antigen and the absence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode AB_RH_POSITIVE = new PersonBloodTypeCode(
			"AB Rh Positive",
			"ABPLUS",
			"The circulating red blood cells with 'A' and 'B' antigen and the presence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode AB_RH_NEGATIVE = new PersonBloodTypeCode(
			"AB Rh Negative",
			"ABMNUS",
			"The circulating red blood cells with 'A' and 'B' antigen and the absence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode B_RH_POSITIVE = new PersonBloodTypeCode(
			"B Rh Positive",
			"BPLUS",
			"The circulating red blood cells with 'B' antigen and the presence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode B_RH_NEGATIVE = new PersonBloodTypeCode(
			"B Rh Negative",
			"BMNUS",
			"The circulating red blood cells with 'B' antigen and the absence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode NOT_KNOWN = new PersonBloodTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonBloodTypeCode O_RH_POSITIVE = new PersonBloodTypeCode(
			"O Rh Positive",
			"OPLUS",
			"The circulating red blood cells that lack 'A' and 'B' antigen and the presence of the 'Rh' antigen.");
	public static final PersonBloodTypeCode O_RH_NEGATIVE = new PersonBloodTypeCode(
			"O Rh Negative",
			"OMNUS",
			"The circulating red blood cells that lack 'A' and 'B' antigen and the absence of the 'Rh' antigen.");

	private PersonBloodTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
