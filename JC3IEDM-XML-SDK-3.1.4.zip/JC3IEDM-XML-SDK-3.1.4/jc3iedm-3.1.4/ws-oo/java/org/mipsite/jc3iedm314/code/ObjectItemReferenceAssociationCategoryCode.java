/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemReferenceAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of a specific OBJECT-ITEM-REFERENCE-ASSOCIATION.";
	}

	private static HashMap<String, ObjectItemReferenceAssociationCategoryCode> physicalToCode = new HashMap<String, ObjectItemReferenceAssociationCategoryCode>();

	public static ObjectItemReferenceAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemReferenceAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemReferenceAssociationCategoryCode HAS_INSTRUCTIONS_PROVIDED_IN = new ObjectItemReferenceAssociationCategoryCode(
			"Has instructions provided in",
			"HASINS",
			"The specific OBJECT-ITEM is provided guidance in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_ACTIVATED_BY = new ObjectItemReferenceAssociationCategoryCode(
			"Is activated by",
			"ISACTV",
			"The operational status of the specific OBJECT-ITEM is made active by provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_AUTHORISED_BY = new ObjectItemReferenceAssociationCategoryCode(
			"Is authorised by",
			"ISAUTH",
			"The specific OBJECT-ITEM is sanctioned by the provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_DEACTIVATED_BY = new ObjectItemReferenceAssociationCategoryCode(
			"Is deactivated by",
			"ISDEAC",
			"The operational status of the specific OBJECT-ITEM is made inactive by provisions in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_DESCRIBED_IN = new ObjectItemReferenceAssociationCategoryCode(
			"Is described in",
			"ISDSCR",
			"The specific OBJECT-ITEM is depicted in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_GRAPHICALLY_DEPICTED_BY = new ObjectItemReferenceAssociationCategoryCode(
			"Is graphically depicted by",
			"ISGRPH",
			"The specific OBJECT-ITEM is pictorially described in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_REFERENCED_BY = new ObjectItemReferenceAssociationCategoryCode(
			"Is referenced by",
			"ISRFNC",
			"The specific OBJECT-ITEM is alluded to in the artefact cited in the specific REFERENCE.");
	public static final ObjectItemReferenceAssociationCategoryCode IS_REPORTED_IN = new ObjectItemReferenceAssociationCategoryCode(
			"Is reported in",
			"ISRPTD",
			"The specific OBJECT-ITEM is given a formal account in the artefact cited in the specific REFERENCE.");

	private ObjectItemReferenceAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
