/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourBiologicallySecureAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of supplying biologically secure facilities, to include quarantine facilities.";
	}

	private static HashMap<String, HarbourBiologicallySecureAvailabilityIndicatorCode> physicalToCode = new HashMap<String, HarbourBiologicallySecureAvailabilityIndicatorCode>();

	public static HarbourBiologicallySecureAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourBiologicallySecureAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourBiologicallySecureAvailabilityIndicatorCode NO = new HarbourBiologicallySecureAvailabilityIndicatorCode(
			"No",
			"NO",
			"Biologically secure facilities are not available at the harbour.");
	public static final HarbourBiologicallySecureAvailabilityIndicatorCode YES = new HarbourBiologicallySecureAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Biologically secure facilities are available at the harbour.");

	private HarbourBiologicallySecureAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
