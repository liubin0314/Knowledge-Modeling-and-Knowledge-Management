/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of restriction or other qualification applicable to a specific ACTION-RESOURCE for a specific ACTION.";
	}

	private static HashMap<String, ActionResourceQualifierCode> physicalToCode = new HashMap<String, ActionResourceQualifierCode>();

	public static ActionResourceQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceQualifierCode AUTHORISED_FOR_USE = new ActionResourceQualifierCode(
			"Authorised for use",
			"AUTH",
			"The specified ACTION-RESOURCE is authorised for use without restriction.");
	public static final ActionResourceQualifierCode MAXIMISE_USE_OF = new ActionResourceQualifierCode(
			"Maximise use of",
			"MAXU",
			"The specified ACTION-RESOURCE is authorised and its use is to be maximised.");
	public static final ActionResourceQualifierCode MINIMISE_USE_OF = new ActionResourceQualifierCode(
			"Minimise use of",
			"MINU",
			"The specified ACTION-RESOURCE is authorised, but use of it is to be minimised to only that which is operationally necessary in the opinion of the authorised commander.");
	public static final ActionResourceQualifierCode NO_EXPLOITATION_EAST_OF_LINE = new ActionResourceQualifierCode(
			"No exploitation east of line",
			"NEEL",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no exploitation east of it.");
	public static final ActionResourceQualifierCode NO_EXPLOITATION_NORTH_OF_LINE = new ActionResourceQualifierCode(
			"No exploitation north of line",
			"NENL",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no exploitation north of it.");
	public static final ActionResourceQualifierCode NO_EXPLOITATION_SOUTH_OF_LINE = new ActionResourceQualifierCode(
			"No exploitation south of line",
			"NESL",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no exploitation south of it.");
	public static final ActionResourceQualifierCode NO_EXPLOITATION_WEST_OF_LINE = new ActionResourceQualifierCode(
			"No exploitation west of line",
			"NEWL",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no exploitation west of it.");
	public static final ActionResourceQualifierCode NOT_AUTHORISED = new ActionResourceQualifierCode(
			"Not authorised",
			"NOTA",
			"The specified ACTION-RESOURCE is not authorised for use.");
	public static final ActionResourceQualifierCode STAY_ABOVE = new ActionResourceQualifierCode(
			"Stay above",
			"STAYAB",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no movement below or within it.");
	public static final ActionResourceQualifierCode STAY_BELOW = new ActionResourceQualifierCode(
			"Stay below",
			"STAYBL",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no movement above or within it.");
	public static final ActionResourceQualifierCode STAY_INSIDE = new ActionResourceQualifierCode(
			"Stay inside",
			"STAYIN",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no movement outside it.");
	public static final ActionResourceQualifierCode STAY_OUTSIDE = new ActionResourceQualifierCode(
			"Stay outside",
			"STAYOT",
			"The specific ACTION-RESOURCE is authorised with the restriction that there is to be no movement within it.");

	private ActionResourceQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
