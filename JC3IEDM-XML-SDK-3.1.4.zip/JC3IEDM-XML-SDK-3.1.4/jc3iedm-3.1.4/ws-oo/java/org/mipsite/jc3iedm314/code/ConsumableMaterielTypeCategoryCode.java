/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CONSUMABLE-MATERIEL-TYPE.";
	}

	private static HashMap<String, ConsumableMaterielTypeCategoryCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeCategoryCode>();

	public static ConsumableMaterielTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeCategoryCode AMMUNITION_TYPE = new ConsumableMaterielTypeCategoryCode(
			"AMMUNITION-TYPE",
			"AMMO",
			"A CONSUMABLE-MATERIEL-TYPE that is a complete device charged with explosives, propellants, pyrotechnics, initiating composition, or nuclear, biological, or chemical material for use in military operations.");
	public static final ConsumableMaterielTypeCategoryCode BIOLOGICAL_MATERIEL_TYPE = new ConsumableMaterielTypeCategoryCode(
			"BIOLOGICAL-MATERIEL-TYPE",
			"BIOMAT",
			"A CONSUMABLE-MATERIEL-TYPE that is either a microorganism that causes disease in man, plants, or animals or causes the deterioration of materiel; or a toxin, produced by an animal, plant, or microorganism, which may kill, seriously injure, or incapacitate personnel through its physiological effects.");
	public static final ConsumableMaterielTypeCategoryCode CHEMICAL_MATERIEL_TYPE = new ConsumableMaterielTypeCategoryCode(
			"CHEMICAL-MATERIEL-TYPE",
			"CHMMAT",
			"A CONSUMABLE-MATERIEL-TYPE that is a substance that is not produced by a living organism, and does not emit radiation but may kill, seriously injure, or incapacitate personnel through its physiological effects or cause the deterioration of materiel.");
	public static final ConsumableMaterielTypeCategoryCode CONSTRUCTION_MATERIALS = new ConsumableMaterielTypeCategoryCode(
			"Construction materials",
			"CON",
			"Any material that may be used in construction.");
	public static final ConsumableMaterielTypeCategoryCode CROPS = new ConsumableMaterielTypeCategoryCode(
			"Crops",
			"CROPS",
			"Cultivated agricultural plants, as grain, vegetables or fruit.");
	public static final ConsumableMaterielTypeCategoryCode DRUG = new ConsumableMaterielTypeCategoryCode(
			"Drug",
			"DRUG",
			"A narcotic, hallucinogen, or stimulant, esp. one causing addiction.");
	public static final ConsumableMaterielTypeCategoryCode FLARE = new ConsumableMaterielTypeCategoryCode(
			"Flare",
			"FLARE",
			"A pyrotechnic munition producing a bright light for illumination or identification.");
	public static final ConsumableMaterielTypeCategoryCode FOOD = new ConsumableMaterielTypeCategoryCode(
			"Food",
			"FOO",
			"Materiel to be used as nourishment in solid or liquid form.");
	public static final ConsumableMaterielTypeCategoryCode FUEL = new ConsumableMaterielTypeCategoryCode(
			"Fuel",
			"FUEL",
			"A substance burned to create energy.");
	public static final ConsumableMaterielTypeCategoryCode FUSE = new ConsumableMaterielTypeCategoryCode(
			"Fuse",
			"FUSE",
			"A device that initiates an explosive train.");
	public static final ConsumableMaterielTypeCategoryCode GENERAL_SUPPLIES = new ConsumableMaterielTypeCategoryCode(
			"General supplies",
			"GENSPL",
			"All disposable materiel and items used in the equipment, support and maintenance of military forces or civilians.");
	public static final ConsumableMaterielTypeCategoryCode IMPROVISED_EXPLOSIVE_DEVICE = new ConsumableMaterielTypeCategoryCode(
			"Improvised explosive device",
			"IMEXDE",
			"A device placed or fabricated in an improvised manner incorporating destructive, lethal, noxious, pyrotechnic or incendiary chemicals and designed to destroy, incapacitate, harass or distract.");
	public static final ConsumableMaterielTypeCategoryCode EXERCISE_MINE = new ConsumableMaterielTypeCategoryCode(
			"Exercise mine",
			"MAMNEX",
			"In naval mine warfare, a mine suitable for use in mine warfare exercises, fitted with visible or audible indicating devices to show where and when it would normally fire.");
	public static final ConsumableMaterielTypeCategoryCode MAP = new ConsumableMaterielTypeCategoryCode(
			"Map",
			"MAP",
			"A piece of paper that is a graphic representation of a part or the whole of the earth.");
	public static final ConsumableMaterielTypeCategoryCode MEDICAL_SUPPLY = new ConsumableMaterielTypeCategoryCode(
			"Medical supply",
			"MEDSPL",
			"Supplies for the treatment of injuries, illness and disease, including drugs.");
	public static final ConsumableMaterielTypeCategoryCode MONEY = new ConsumableMaterielTypeCategoryCode(
			"Money",
			"MONEY",
			"The official currency, coins and negotiable paper notes issued by a government.");
	public static final ConsumableMaterielTypeCategoryCode NOT_KNOWN = new ConsumableMaterielTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ConsumableMaterielTypeCategoryCode PERSONAL_EQUIPMENT = new ConsumableMaterielTypeCategoryCode(
			"Personal equipment",
			"PEREQU",
			"Equipment issued to or carried by an individual.");
	public static final ConsumableMaterielTypeCategoryCode POL = new ConsumableMaterielTypeCategoryCode(
			"POL",
			"POL",
			"Petroleum, Oil, and Lubricant - A broad term that includes all petroleum and associated products used by the armed forces.");
	public static final ConsumableMaterielTypeCategoryCode RADIOACTIVE_MATERIEL_TYPE = new ConsumableMaterielTypeCategoryCode(
			"RADIOACTIVE-MATERIEL-TYPE",
			"RADMAT",
			"A CONSUMABLE-MATERIEL-TYPE that is a substance which spontaneously emits radiation, and which may kill, seriously injure, or incapacitate personnel through its physiological effects or causes the deterioration of materiel.");
	public static final ConsumableMaterielTypeCategoryCode SPARE_PARTS = new ConsumableMaterielTypeCategoryCode(
			"Spare parts",
			"SPRPRT",
			"A generic term covering materiel used as replacement parts.");
	public static final ConsumableMaterielTypeCategoryCode WATER = new ConsumableMaterielTypeCategoryCode(
			"Water",
			"WAT",
			"A clear, colourless, nearly odourless and tasteless liquid.");
	public static final ConsumableMaterielTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ConsumableMaterielTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private ConsumableMaterielTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
