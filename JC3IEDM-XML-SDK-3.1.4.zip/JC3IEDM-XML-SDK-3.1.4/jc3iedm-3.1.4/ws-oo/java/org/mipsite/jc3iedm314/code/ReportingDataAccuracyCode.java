/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReportingDataAccuracyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents, for intelligence purpose, the general appraisal of the subject matter in graded terms to indicate the extent or degree to which it has been judged to be free from mistake or error or to conform to truth or some recognised standard value.";
	}

	private static HashMap<String, ReportingDataAccuracyCode> physicalToCode = new HashMap<String, ReportingDataAccuracyCode>();

	public static ReportingDataAccuracyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReportingDataAccuracyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReportingDataAccuracyCode CONFIRMED = new ReportingDataAccuracyCode(
			"Confirmed",
			"1",
			"Reported data is confirmed by at least 3 independent sources.");
	public static final ReportingDataAccuracyCode PROBABLE = new ReportingDataAccuracyCode(
			"Probable",
			"2",
			"Reported data is confirmed by 2 independent sources.");
	public static final ReportingDataAccuracyCode POSSIBLE = new ReportingDataAccuracyCode(
			"Possible",
			"3",
			"Reported data is given by only one source.");
	public static final ReportingDataAccuracyCode DOUBTFUL = new ReportingDataAccuracyCode(
			"Doubtful",
			"4",
			"Reported data can be viewed with suspicion.");
	public static final ReportingDataAccuracyCode IMPROBABLE = new ReportingDataAccuracyCode(
			"Improbable",
			"5",
			"Reported data shall be considered as probably erroneous.");
	public static final ReportingDataAccuracyCode TRUTH_CANNOT_BE_JUDGED = new ReportingDataAccuracyCode(
			"Truth cannot be judged",
			"6",
			"Basis for the estimate of Reported data cannot be estimated.");

	private ReportingDataAccuracyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
