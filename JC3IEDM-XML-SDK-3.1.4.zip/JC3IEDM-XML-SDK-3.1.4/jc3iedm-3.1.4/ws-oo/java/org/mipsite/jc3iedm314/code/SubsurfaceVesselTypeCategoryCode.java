/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SubsurfaceVesselTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of subsurface vessel.";
	}

	private static HashMap<String, SubsurfaceVesselTypeCategoryCode> physicalToCode = new HashMap<String, SubsurfaceVesselTypeCategoryCode>();

	public static SubsurfaceVesselTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SubsurfaceVesselTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SubsurfaceVesselTypeCategoryCode DEEP_SUBMERGENCE_VEHICLE = new SubsurfaceVesselTypeCategoryCode(
			"Deep submergence vehicle",
			"DSV",
			"Submersible designed to operate at great depth (more than 300 metres).");
	public static final SubsurfaceVesselTypeCategoryCode NOT_KNOWN = new SubsurfaceVesselTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final SubsurfaceVesselTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new SubsurfaceVesselTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_GENERAL = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, general",
			"SS",
			"General designator for a warship, capable of operating under water and usually equipped with torpedoes, missiles and a periscope.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_AUXILIARY = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, auxiliary",
			"SSA",
			"Submarine used mainly in a non-combatant role which has at least a residual combat capability.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_AUXILIARY_NUCLEAR_POWERED = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, auxiliary, nuclear powered",
			"SSAN",
			"Submarine used mainly in a non-combatant role that has at least a residual combat capability and with nuclear power.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_BALLISTIC_MISSILE = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, ballistic missile",
			"SSB",
			"A subsurface vessel designed to deliver ballistic missile attacks against assigned targets from either a submerged or surfaced condition.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_BALLISTIC_MISSILE_NUCLEAR = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, ballistic missile, nuclear",
			"SSBN",
			"A subsurface vessel designed to deliver ballistic missile attacks against assigned targets from either a submerged or surfaced condition with nuclear power.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_COASTAL = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, coastal",
			"SSC",
			"Submarine designed primarily for operations in coastal and shallow waters.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_ATTACK_GUIDED_MISSILE = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, attack, guided missile",
			"SSG",
			"Submarine fitted with underwater to surface or surface-to-surface missiles.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_ATTACK_GUIDED_MISSILE_NUCLEAR = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, attack, guided missile, nuclear",
			"SSGN",
			"Submarine fitted with underwater to surface or surface-to-surface missiles with nuclear power.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_PATROL = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, patrol",
			"SSK",
			"Long-range patrol submarine. May have primary anti- surface or anti-submarine role.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_ATTACK_NUCLEAR = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, attack, nuclear",
			"SSN",
			"Nuclear propelled attack submarine with both anti-submarine and anti-surface capability.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_TRAINING = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, training",
			"SST",
			"Submarine used primarily in a training role but with at least a residual combat capability.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_MILITARY_CAPABILITY_UNKNOWN = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, military capability unknown",
			"SSU",
			"Submarine whose full military capability is unknown or has not been determined.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_MILITARY_CAPABILITY_UNKNOWN_NUCLEAR_POWERED = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, military capability unknown, nuclear powered",
			"SSUN",
			"Submarine with nuclear power whose full military capability is unknown or has not been determined.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMARINE_MIDGET_SWIMMER = new SubsurfaceVesselTypeCategoryCode(
			"Submarine, midget, swimmer",
			"SSW",
			"Midget submarine or submersible designed primarily for special operations and operated by naval forces.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMERSIBLE_GENERAL_COMMERCIAL = new SubsurfaceVesselTypeCategoryCode(
			"Submersible, general (commercial)",
			"TS",
			"General designator for non-combatant submersible.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMERSIBLE_RESEARCH_COMMERCIAL = new SubsurfaceVesselTypeCategoryCode(
			"Submersible, research (commercial)",
			"TSG",
			"Submersible with no combat capability used in research role.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMERSIBLE_RESCUE_COMMERCIAL = new SubsurfaceVesselTypeCategoryCode(
			"Submersible, rescue (commercial)",
			"TSR",
			"Submersible designed specifically for underwater rescue operations.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMERSIBLE_RESCUE_MILITARY = new SubsurfaceVesselTypeCategoryCode(
			"Submersible, rescue, military",
			"YSG",
			"Military operated submersible designed specifically for underwater rescue operations.");
	public static final SubsurfaceVesselTypeCategoryCode SUBMERSIBLE_RESEARCH_MILITARY = new SubsurfaceVesselTypeCategoryCode(
			"Submersible, research, military",
			"YSR",
			"Military operated submersible with no combat capability used in research role.");
	public static final SubsurfaceVesselTypeCategoryCode DEEP_SUBMERSIBLE_RESCUE_VEHICLE_MILITARY = new SubsurfaceVesselTypeCategoryCode(
			"Deep submersible rescue vehicle (military)",
			"YSRV",
			"Military operated submersible designed for submarine rescue operations at great depth (more than 300 metres) and military operated.");
	public static final SubsurfaceVesselTypeCategoryCode DEEP_SUBMERGENCE_VEHICLE_MILITARY = new SubsurfaceVesselTypeCategoryCode(
			"Deep submergence vehicle, military",
			"YSV",
			"Military operated submersible designed to operate at great depth (more than 300 metres).");

	private SubsurfaceVesselTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
