/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAddressPrimacyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the priority that a specific ADDRESS has with respect to a specific OBJECT-ITEM.";
	}

	private static HashMap<String, ObjectItemAddressPrimacyCode> physicalToCode = new HashMap<String, ObjectItemAddressPrimacyCode>();

	public static ObjectItemAddressPrimacyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAddressPrimacyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAddressPrimacyCode PRIMARY = new ObjectItemAddressPrimacyCode(
			"Primary",
			"PRIME",
			"Denotes the primary ADDRESS.");
	public static final ObjectItemAddressPrimacyCode SECONDARY = new ObjectItemAddressPrimacyCode(
			"Secondary",
			"SCNDRY",
			"Denotes the secondary ADDRESS.");
	public static final ObjectItemAddressPrimacyCode TERTIARY = new ObjectItemAddressPrimacyCode(
			"Tertiary",
			"THIRD",
			"Denotes the tertiary ADDRESS.");

	private ObjectItemAddressPrimacyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
