/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielTypeSupplyClassCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the NATO supply class of MATERIEL-TYPE.";
	}

	private static HashMap<String, MaterielTypeSupplyClassCode> physicalToCode = new HashMap<String, MaterielTypeSupplyClassCode>();

	public static MaterielTypeSupplyClassCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielTypeSupplyClassCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielTypeSupplyClassCode CLASS_I = new MaterielTypeSupplyClassCode(
			"Class I",
			"CLS1",
			"Items that are consumed by personnel and animals at an approximately uniform rate, irrespective of local changes in combat or terrain conditions, e.g. food and forage.");
	public static final MaterielTypeSupplyClassCode CLASS_II = new MaterielTypeSupplyClassCode(
			"Class II",
			"CLS2",
			"Supplies for which allowances are established by tables of organisation and equipment, e.g. clothing, weapons, tools, spare parts, vehicles.");
	public static final MaterielTypeSupplyClassCode CLASS_III = new MaterielTypeSupplyClassCode(
			"Class III",
			"CLS3",
			"Fuel and lubricants for all purposes, except for operating aircraft or for use in weapons such as flame-throwers, e.g. gasoline, fuel oil, greases, coal and coke.");
	public static final MaterielTypeSupplyClassCode CLASS_IIIA = new MaterielTypeSupplyClassCode(
			"Class IIIa",
			"CLS3A",
			"Aviation fuel and lubricants.");
	public static final MaterielTypeSupplyClassCode CLASS_IV = new MaterielTypeSupplyClassCode(
			"Class IV",
			"CLS4",
			"Supplies for which initial use allowances are not prescribed by approved issue tables. Normally includes fortification and construction materials, as well as additional quantities of items identical to those authorised for initial issue (Class II) such as additional vehicles.");
	public static final MaterielTypeSupplyClassCode CLASS_V = new MaterielTypeSupplyClassCode(
			"Class V",
			"CLS5",
			"Ammunition, explosives and chemical agents of all types.");

	private MaterielTypeSupplyClassCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
