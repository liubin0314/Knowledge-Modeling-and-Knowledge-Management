/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of PLAN-ORDER.";
	}

	private static HashMap<String, PlanOrderCategoryCode> physicalToCode = new HashMap<String, PlanOrderCategoryCode>();

	public static PlanOrderCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderCategoryCode ORDER = new PlanOrderCategoryCode(
			"ORDER",
			"ORDER",
			"A communication that conveys instructions from a superior to a subordinate.");
	public static final PlanOrderCategoryCode PLAN = new PlanOrderCategoryCode(
			"PLAN",
			"PLAN",
			"A proposal for putting into effect a command decision or project; it represents the preparation for future or anticipated operations.");

	private PlanOrderCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
