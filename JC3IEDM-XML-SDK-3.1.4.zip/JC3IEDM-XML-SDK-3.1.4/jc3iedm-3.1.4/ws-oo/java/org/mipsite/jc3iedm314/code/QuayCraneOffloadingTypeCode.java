/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class QuayCraneOffloadingTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of crane offloading equipment available at a specific QUAY.";
	}

	private static HashMap<String, QuayCraneOffloadingTypeCode> physicalToCode = new HashMap<String, QuayCraneOffloadingTypeCode>();

	public static QuayCraneOffloadingTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<QuayCraneOffloadingTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final QuayCraneOffloadingTypeCode FLOATING_CRANE = new QuayCraneOffloadingTypeCode(
			"Floating crane",
			"FLTCRN",
			"A general-purpose crane that is able to move about by means of a vessel.");
	public static final QuayCraneOffloadingTypeCode NOT_OTHERWISE_SPECIFIED = new QuayCraneOffloadingTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final QuayCraneOffloadingTypeCode RAILED_CRANE = new QuayCraneOffloadingTypeCode(
			"Railed crane",
			"RAILCR",
			"A general-purpose crane that is able to move about by means of railway tracks.");
	public static final QuayCraneOffloadingTypeCode STATIC_CRANE = new QuayCraneOffloadingTypeCode(
			"Static crane",
			"STATCR",
			"A general-purpose crane fixed to one location.");
	public static final QuayCraneOffloadingTypeCode TRACKED_CRAWLER_CRANE = new QuayCraneOffloadingTypeCode(
			"Tracked crawler crane",
			"TRKCRW",
			"A general-purpose crane that is able to move about by means of caterpillar tracks.");
	public static final QuayCraneOffloadingTypeCode WHEELED_CRANE = new QuayCraneOffloadingTypeCode(
			"Wheeled crane",
			"WHLCRN",
			"A general-purpose crane that is able to move about by means of wheels.");

	private QuayCraneOffloadingTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
