/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirRouteSegmentCivilMilitaryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the civil/military status of the AIR-ROUTE-SEGMENT.";
	}

	private static HashMap<String, AirRouteSegmentCivilMilitaryCode> physicalToCode = new HashMap<String, AirRouteSegmentCivilMilitaryCode>();

	public static AirRouteSegmentCivilMilitaryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirRouteSegmentCivilMilitaryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirRouteSegmentCivilMilitaryCode BOTH = new AirRouteSegmentCivilMilitaryCode(
			"Both",
			"BOTH",
			"The AIR-ROUTE-SEGMENT is civil and military.");
	public static final AirRouteSegmentCivilMilitaryCode CIVIL = new AirRouteSegmentCivilMilitaryCode(
			"Civil",
			"CIVIL",
			"The AIR-ROUTE-SEGMENT is civil.");
	public static final AirRouteSegmentCivilMilitaryCode MILITARY = new AirRouteSegmentCivilMilitaryCode(
			"Military",
			"MIL",
			"The AIR-ROUTE-SEGMENT is military.");

	private AirRouteSegmentCivilMilitaryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
