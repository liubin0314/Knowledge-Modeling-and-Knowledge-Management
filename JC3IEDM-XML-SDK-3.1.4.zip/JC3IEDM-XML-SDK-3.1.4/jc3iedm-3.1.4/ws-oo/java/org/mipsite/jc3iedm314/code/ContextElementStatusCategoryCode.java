/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextElementStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific CONTEXT-ELEMENT-STATUS refers to the addition or removal of the CONTEXT-ELEMENT from the CONTEXT.";
	}

	private static HashMap<String, ContextElementStatusCategoryCode> physicalToCode = new HashMap<String, ContextElementStatusCategoryCode>();

	public static ContextElementStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextElementStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextElementStatusCategoryCode ADDITION = new ContextElementStatusCategoryCode(
			"Addition",
			"ADDITN",
			"The specific CONTEXT-ELEMENT is added to the CONTEXT.");
	public static final ContextElementStatusCategoryCode REMOVAL = new ContextElementStatusCategoryCode(
			"Removal",
			"REMOVL",
			"The specific CONTEXT-ELEMENT is removed from the CONTEXT.");

	private ContextElementStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
