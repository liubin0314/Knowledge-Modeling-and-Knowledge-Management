/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractAddress extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private TextTypeVar100 placeNameText; // optional
	private Set<Ref<ObjectItemAddress>> objectItemAddressSet; // zero-one-or-more

	// default constructor

	public AbstractAddress() {
		this.objectItemAddressSet = new HashSet<Ref<ObjectItemAddress>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractAddress.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractAddress.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public TextTypeVar100 getPlaceNameText() {
		return this.placeNameText;
	}

	public void setPlaceNameText(TextTypeVar100 placeNameText) {
		this.placeNameText = placeNameText;
	}

	public Set<Ref<ObjectItemAddress>> getObjectItemAddressSet() {
		return this.objectItemAddressSet;
	}

	public void addObjectItemAddress(Ref<ObjectItemAddress> objectItemAddress) {
		this.objectItemAddressSet.add(objectItemAddress);
	}
}
