/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ChemicalMaterielTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the general class of a specific CHEMICAL-MATERIEL-TYPE.";
	}

	private static HashMap<String, ChemicalMaterielTypeCategoryCode> physicalToCode = new HashMap<String, ChemicalMaterielTypeCategoryCode>();

	public static ChemicalMaterielTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ChemicalMaterielTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ChemicalMaterielTypeCategoryCode BLISTER_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Blister agent",
			"BLISTR",
			"A CHEMICAL-MATERIEL-TYPE that injures the eyes and lungs, and burns or blisters the skin. Also called \"vesicant agent\".");
	public static final ChemicalMaterielTypeCategoryCode BLOOD_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Blood agent",
			"BLOOD",
			"A CHEMICAL-MATERIEL-TYPE, including the cyanide group, that affects bodily functions by preventing the normal transfer of oxygen from the blood to body tissues. Also called \"cyanogen agent\".");
	public static final ChemicalMaterielTypeCategoryCode CHOKING_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Choking agent",
			"CHKNG",
			"A CHEMICAL-MATERIEL-TYPE that affects the human breathing function.");
	public static final ChemicalMaterielTypeCategoryCode G_AGENT = new ChemicalMaterielTypeCategoryCode(
			"G-agent",
			"GAGENT",
			"The types of organophosphorus nerve gases.");
	public static final ChemicalMaterielTypeCategoryCode INCAPACITATING_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Incapacitating agent",
			"INCPCT",
			"A CHEMICAL-MATERIEL-TYPE that prevents a human from functioning in a normal way.");
	public static final ChemicalMaterielTypeCategoryCode IRRITANT = new ChemicalMaterielTypeCategoryCode(
			"Irritant",
			"IRRTNT",
			"A CHEMICAL-MATERIEL-TYPE that is designed to irritate the eyes, lungs and skin.");
	public static final ChemicalMaterielTypeCategoryCode MUSTARD_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Mustard agent",
			"MUSTRD",
			"A potentially lethal CHEMICAL-MATERIEL-TYPE, which is a colourless oily liquid whose vapour is a powerful irritant and vesicant, used in chemical weapons.");
	public static final ChemicalMaterielTypeCategoryCode NERVE_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Nerve agent",
			"NERVE",
			"A potentially lethal CHEMICAL-MATERIEL-TYPE that interferes with the transmission of nerve impulses.");
	public static final ChemicalMaterielTypeCategoryCode NOT_KNOWN = new ChemicalMaterielTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ChemicalMaterielTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ChemicalMaterielTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ChemicalMaterielTypeCategoryCode PENETRATING_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Penetrating agent",
			"PNTRNG",
			"A CHEMICAL-MATERIEL-TYPE that is designed to penetrate the individual and collective equipment, therefore enabling an associated lethal agent to act.");
	public static final ChemicalMaterielTypeCategoryCode TOXIC_INDUSTRIAL_MATERIAL = new ChemicalMaterielTypeCategoryCode(
			"Toxic industrial material",
			"TOXMAT",
			"A generic term for a CHEMICAL-MATERIEL-TYPE compound found in solid, liquid, aerosolised or gaseous form. It may be used, or stored for use, for industrial, commercial, medical, military or domestic purposes.");
	public static final ChemicalMaterielTypeCategoryCode V_AGENT = new ChemicalMaterielTypeCategoryCode(
			"V-agent",
			"VAGENT",
			"A generic term for a CHEMICAL-MATERIEL-TYPE for a class of nerve agents.");
	public static final ChemicalMaterielTypeCategoryCode VOMITING_AGENT = new ChemicalMaterielTypeCategoryCode(
			"Vomiting agent",
			"VOMTNG",
			"A CHEMICAL-MATERIEL-TYPE that is designed to incapacitate by inducing vomiting in humans.");

	private ChemicalMaterielTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
