/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourEstimatedTimeOfArrivalIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether an estimated time of arrival message is required.";
	}

	private static HashMap<String, HarbourEstimatedTimeOfArrivalIndicatorCode> physicalToCode = new HashMap<String, HarbourEstimatedTimeOfArrivalIndicatorCode>();

	public static HarbourEstimatedTimeOfArrivalIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourEstimatedTimeOfArrivalIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourEstimatedTimeOfArrivalIndicatorCode NO = new HarbourEstimatedTimeOfArrivalIndicatorCode(
			"No",
			"NO",
			"An estimated time of arrival message is not required.");
	public static final HarbourEstimatedTimeOfArrivalIndicatorCode YES = new HarbourEstimatedTimeOfArrivalIndicatorCode(
			"Yes",
			"YES",
			"An estimated time of arrival message is required.");

	private HarbourEstimatedTimeOfArrivalIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
