/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractConsumableMaterielType extends AbstractMaterielType {

	// private fields

	private ConsumableMaterielTypeSubcategoryCode consumableMaterielTypeSubcategoryCode; // optional
	private ConsumableMaterielTypeHazardCode hazardCode; // optional
	private ConsumableMaterielTypeIssuingElementCode issuingElementCode; // optional
	private CountType9 issuingCount; // optional
	private ConsumableMaterielTypeIssuingUnitOfMeasureCode issuingUnitOfMeasureCode; // optional
	private QuantityType12_3 issuingWeightQuantity; // optional
	private ConsumableMaterielTypePerishabilityIndicatorCode perishabilityIndicatorCode; // optional
	private ConsumableMaterielTypeUnitedNationsNumberCode unitedNationsNumberCode; // optional

	// default constructor

	public AbstractConsumableMaterielType() {
		// no assignment
	}

	// getter & setter methods

	public ConsumableMaterielTypeSubcategoryCode getConsumableMaterielTypeSubcategoryCode() {
		return this.consumableMaterielTypeSubcategoryCode;
	}

	public void setConsumableMaterielTypeSubcategoryCode(ConsumableMaterielTypeSubcategoryCode consumableMaterielTypeSubcategoryCode) {
		this.consumableMaterielTypeSubcategoryCode = consumableMaterielTypeSubcategoryCode;
	}

	public ConsumableMaterielTypeHazardCode getHazardCode() {
		return this.hazardCode;
	}

	public void setHazardCode(ConsumableMaterielTypeHazardCode hazardCode) {
		this.hazardCode = hazardCode;
	}

	public ConsumableMaterielTypeIssuingElementCode getIssuingElementCode() {
		return this.issuingElementCode;
	}

	public void setIssuingElementCode(ConsumableMaterielTypeIssuingElementCode issuingElementCode) {
		this.issuingElementCode = issuingElementCode;
	}

	public CountType9 getIssuingCount() {
		return this.issuingCount;
	}

	public void setIssuingCount(CountType9 issuingCount) {
		this.issuingCount = issuingCount;
	}

	public ConsumableMaterielTypeIssuingUnitOfMeasureCode getIssuingUnitOfMeasureCode() {
		return this.issuingUnitOfMeasureCode;
	}

	public void setIssuingUnitOfMeasureCode(ConsumableMaterielTypeIssuingUnitOfMeasureCode issuingUnitOfMeasureCode) {
		this.issuingUnitOfMeasureCode = issuingUnitOfMeasureCode;
	}

	public QuantityType12_3 getIssuingWeightQuantity() {
		return this.issuingWeightQuantity;
	}

	public void setIssuingWeightQuantity(QuantityType12_3 issuingWeightQuantity) {
		this.issuingWeightQuantity = issuingWeightQuantity;
	}

	public ConsumableMaterielTypePerishabilityIndicatorCode getPerishabilityIndicatorCode() {
		return this.perishabilityIndicatorCode;
	}

	public void setPerishabilityIndicatorCode(ConsumableMaterielTypePerishabilityIndicatorCode perishabilityIndicatorCode) {
		this.perishabilityIndicatorCode = perishabilityIndicatorCode;
	}

	public ConsumableMaterielTypeUnitedNationsNumberCode getUnitedNationsNumberCode() {
		return this.unitedNationsNumberCode;
	}

	public void setUnitedNationsNumberCode(ConsumableMaterielTypeUnitedNationsNumberCode unitedNationsNumberCode) {
		this.unitedNationsNumberCode = unitedNationsNumberCode;
	}
}
