/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkServiceStatusIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes whether the specific NETWORK-SERVICE is active.";
	}

	private static HashMap<String, NetworkServiceStatusIndicatorCode> physicalToCode = new HashMap<String, NetworkServiceStatusIndicatorCode>();

	public static NetworkServiceStatusIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkServiceStatusIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkServiceStatusIndicatorCode NO = new NetworkServiceStatusIndicatorCode(
			"No",
			"NO",
			"The specific NETWORK-SERVICE is not activated.");
	public static final NetworkServiceStatusIndicatorCode YES = new NetworkServiceStatusIndicatorCode(
			"Yes",
			"YES",
			"The specific NETWORK-SERVICE is activated.");

	private NetworkServiceStatusIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
