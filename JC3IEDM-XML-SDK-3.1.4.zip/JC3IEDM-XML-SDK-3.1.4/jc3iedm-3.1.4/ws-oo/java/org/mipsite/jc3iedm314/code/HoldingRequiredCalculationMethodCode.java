/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HoldingRequiredCalculationMethodCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the required stocks calculation method used for the count of OBJECT-TYPEs in a specific HOLDING.";
	}

	private static HashMap<String, HoldingRequiredCalculationMethodCode> physicalToCode = new HashMap<String, HoldingRequiredCalculationMethodCode>();

	public static HoldingRequiredCalculationMethodCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HoldingRequiredCalculationMethodCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HoldingRequiredCalculationMethodCode LEVEL_OF_EFFORT = new HoldingRequiredCalculationMethodCode(
			"Level of effort",
			"LVLOEF",
			"The method used to complete the required stocks calculation of a specific HOLDING is based on the level of effort methodology.");
	public static final HoldingRequiredCalculationMethodCode TARGET = new HoldingRequiredCalculationMethodCode(
			"Target",
			"TARGET",
			"The method used to complete the required stocks calculation of a specific HOLDING is based on the target related methodology.");

	private HoldingRequiredCalculationMethodCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
