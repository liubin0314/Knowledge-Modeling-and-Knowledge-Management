/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourTankerFacilitiesIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the availability of facilities to process tankers at a specific HARBOUR.";
	}

	private static HashMap<String, HarbourTankerFacilitiesIndicatorCode> physicalToCode = new HashMap<String, HarbourTankerFacilitiesIndicatorCode>();

	public static HarbourTankerFacilitiesIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourTankerFacilitiesIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourTankerFacilitiesIndicatorCode NO = new HarbourTankerFacilitiesIndicatorCode(
			"No",
			"NO",
			"Tanker facilities are not available at the harbour.");
	public static final HarbourTankerFacilitiesIndicatorCode YES = new HarbourTankerFacilitiesIndicatorCode(
			"Yes",
			"YES",
			"Tanker facilities are available at the harbour.");

	private HarbourTankerFacilitiesIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
