/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LocationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a class of LOCATION.";
	}

	private static HashMap<String, LocationCategoryCode> physicalToCode = new HashMap<String, LocationCategoryCode>();

	public static LocationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LocationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LocationCategoryCode LINE = new LocationCategoryCode(
			"LINE",
			"LN",
			"A LOCATION that is defined by two or more POINTs connected by one-dimensional line segments in an ordered sequence.");
	public static final LocationCategoryCode POINT = new LocationCategoryCode(
			"POINT",
			"PT",
			"A zero-dimensional LOCATION.");
	public static final LocationCategoryCode SURFACE = new LocationCategoryCode(
			"SURFACE",
			"SURFAC",
			"A two-dimensional LOCATION.");
	public static final LocationCategoryCode UNDEFINED = new LocationCategoryCode(
			"Undefined",
			"UND",
			"A LOCATION that refers to a position that cannot be determined.");
	public static final LocationCategoryCode GEOMETRIC_VOLUME = new LocationCategoryCode(
			"GEOMETRIC-VOLUME",
			"VL",
			"A specific LOCATION that is a three-dimensional bounded space.");

	private LocationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
