/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ContextAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of relationship between the subject CONTEXT and the object CONTEXT in a specific CONTEXT-ASSOCIATION.";
	}

	private static HashMap<String, ContextAssociationCategoryCode> physicalToCode = new HashMap<String, ContextAssociationCategoryCode>();

	public static ContextAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ContextAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ContextAssociationCategoryCode IS_NEXT_AFTER = new ContextAssociationCategoryCode(
			"Is next after",
			"ISNEXT",
			"The subject CONTEXT follows the object CONTEXT sequentially without negating it. The value is to be used to establish a time-ordered sequence of CONTEXTs.");
	public static final ContextAssociationCategoryCode IS_PART_OF_IS_SUB_CONTEXT_OF = new ContextAssociationCategoryCode(
			"Is part of/Is sub-context of",
			"ISPART",
			"The subject CONTEXT is included in the object CONTEXT.");
	public static final ContextAssociationCategoryCode SUPPLEMENTS = new ContextAssociationCategoryCode(
			"Supplements",
			"SPPLMN",
			"The subject CONTEXT provides amplifying information with respect to the object CONTEXT.");
	public static final ContextAssociationCategoryCode SUPERSEDES = new ContextAssociationCategoryCode(
			"Supersedes",
			"SPRCDS",
			"The subject CONTEXT negates the object CONTEXT by replacing it.");

	private ContextAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
