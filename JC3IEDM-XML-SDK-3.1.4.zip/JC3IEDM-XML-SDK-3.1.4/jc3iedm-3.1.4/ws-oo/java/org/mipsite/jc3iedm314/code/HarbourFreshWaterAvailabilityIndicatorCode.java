/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourFreshWaterAvailabilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of providing fresh water.";
	}

	private static HashMap<String, HarbourFreshWaterAvailabilityIndicatorCode> physicalToCode = new HashMap<String, HarbourFreshWaterAvailabilityIndicatorCode>();

	public static HarbourFreshWaterAvailabilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourFreshWaterAvailabilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourFreshWaterAvailabilityIndicatorCode NO = new HarbourFreshWaterAvailabilityIndicatorCode(
			"No",
			"NO",
			"Fresh water is not available at the harbour.");
	public static final HarbourFreshWaterAvailabilityIndicatorCode YES = new HarbourFreshWaterAvailabilityIndicatorCode(
			"Yes",
			"YES",
			"Fresh water is available at the harbour.");

	private HarbourFreshWaterAvailabilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
