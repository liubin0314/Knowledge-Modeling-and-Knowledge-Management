/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusOperationalStatusQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the qualification of the operational status of a specific MATERIEL.";
	}

	private static HashMap<String, MaterielStatusOperationalStatusQualifierCode> physicalToCode = new HashMap<String, MaterielStatusOperationalStatusQualifierCode>();

	public static MaterielStatusOperationalStatusQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusOperationalStatusQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusOperationalStatusQualifierCode CLEARED = new MaterielStatusOperationalStatusQualifierCode(
			"Cleared",
			"CLEARD",
			"The piece of materiel is weapon and explosive free.");
	public static final MaterielStatusOperationalStatusQualifierCode DENIED = new MaterielStatusOperationalStatusQualifierCode(
			"Denied",
			"DENIED",
			"Subjectively judged by the reporting organisation that a MATERIEL is unavailable through means such as removal, contamination or erection of obstructions.");
	public static final MaterielStatusOperationalStatusQualifierCode DISASSEMBLED = new MaterielStatusOperationalStatusQualifierCode(
			"Disassembled",
			"DISASM",
			"Subjectively judged by the reporting organisation that the MATERIEL is taken apart in a way that it can be reassembled.");
	public static final MaterielStatusOperationalStatusQualifierCode DESTROYED = new MaterielStatusOperationalStatusQualifierCode(
			"Destroyed",
			"DSTRYD",
			"Subjectively judged by the reporting organisation that a MATERIEL is not, and not expected ever to be, capable of performing the missions or functions for which it is designed.");
	public static final MaterielStatusOperationalStatusQualifierCode HEAVILY_DAMAGED = new MaterielStatusOperationalStatusQualifierCode(
			"Heavily damaged",
			"HVYDAM",
			"Subjectively judged by the reporting organisation to be heavily damaged.");
	public static final MaterielStatusOperationalStatusQualifierCode IMMOBILISED = new MaterielStatusOperationalStatusQualifierCode(
			"Immobilised",
			"IMMBLS",
			"Subjectively judged by the reporting organisation that a specific materiel or its component is incapable of movement in its current condition.");
	public static final MaterielStatusOperationalStatusQualifierCode IN_MAINTENANCE = new MaterielStatusOperationalStatusQualifierCode(
			"In maintenance",
			"INMNT",
			"Subjectively judged by the reporting organisation that a specific materiel is under some kind of service.");
	public static final MaterielStatusOperationalStatusQualifierCode INTACT_BUT_UNRECOVERABLE = new MaterielStatusOperationalStatusQualifierCode(
			"Intact but unrecoverable",
			"INTREC",
			"Subjectively judged by the reporting organisation to be in an area unsuitable for recovery due to political, military, or geographic/environmental considerations.");
	public static final MaterielStatusOperationalStatusQualifierCode LIGHTLY_DAMAGED = new MaterielStatusOperationalStatusQualifierCode(
			"Lightly damaged",
			"LGTDAM",
			"Subjectively judged by the reporting organisation to be only lightly damaged.");
	public static final MaterielStatusOperationalStatusQualifierCode LOST = new MaterielStatusOperationalStatusQualifierCode(
			"Lost",
			"LST",
			"Subjectively judged by the reporting organisation that a specific materiel is missing under unknown circumstances.");
	public static final MaterielStatusOperationalStatusQualifierCode LACKING_VITAL_RESOURCES = new MaterielStatusOperationalStatusQualifierCode(
			"Lacking vital resources",
			"LVR",
			"Subjectively judged by the reporting organisation that a MATERIEL is deficient or lacking of some mission-critical resources (e.g., fuel, ammunition).");
	public static final MaterielStatusOperationalStatusQualifierCode MODERATELY_DAMAGED = new MaterielStatusOperationalStatusQualifierCode(
			"Moderately damaged",
			"MODDAM",
			"Subjectively judged by the reporting organisation to be moderately damaged.");
	public static final MaterielStatusOperationalStatusQualifierCode MOTHBALLED = new MaterielStatusOperationalStatusQualifierCode(
			"Mothballed",
			"MTHBLD",
			"Subjectively judged by the reporting organisation that a specific materiel has been preserved to some degree.");
	public static final MaterielStatusOperationalStatusQualifierCode NOT_KNOWN = new MaterielStatusOperationalStatusQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MaterielStatusOperationalStatusQualifierCode SCRAPPED = new MaterielStatusOperationalStatusQualifierCode(
			"Scrapped",
			"SCRPPD",
			"Subjectively judged by the reporting organisation that a specific materiel is dismantled or taken apart into pieces to store or destroy.");
	public static final MaterielStatusOperationalStatusQualifierCode STERILIZED = new MaterielStatusOperationalStatusQualifierCode(
			"Sterilized",
			"STERLZ",
			"Subjectively judged by the reporting organisation that a specific materiel has been made incapable of functioning productively or effectively.");

	private MaterielStatusOperationalStatusQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
