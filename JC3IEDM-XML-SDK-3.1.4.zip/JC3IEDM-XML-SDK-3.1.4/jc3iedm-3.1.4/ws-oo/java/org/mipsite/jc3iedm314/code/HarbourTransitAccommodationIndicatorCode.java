/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourTransitAccommodationIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is capable of supplying transit accommodation facilities.";
	}

	private static HashMap<String, HarbourTransitAccommodationIndicatorCode> physicalToCode = new HashMap<String, HarbourTransitAccommodationIndicatorCode>();

	public static HarbourTransitAccommodationIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourTransitAccommodationIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourTransitAccommodationIndicatorCode NO = new HarbourTransitAccommodationIndicatorCode(
			"No",
			"NO",
			"Transit accommodation is not available at the harbour.");
	public static final HarbourTransitAccommodationIndicatorCode YES = new HarbourTransitAccommodationIndicatorCode(
			"Yes",
			"YES",
			"Transit accommodation is available at the harbour.");

	private HarbourTransitAccommodationIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
