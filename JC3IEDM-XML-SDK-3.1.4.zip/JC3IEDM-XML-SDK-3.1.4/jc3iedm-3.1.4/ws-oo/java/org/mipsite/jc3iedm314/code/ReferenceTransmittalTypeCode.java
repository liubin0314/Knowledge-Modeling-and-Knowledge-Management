/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceTransmittalTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the means by which the artefact cited in a specific REFERENCE is transmitted to the recipient.";
	}

	private static HashMap<String, ReferenceTransmittalTypeCode> physicalToCode = new HashMap<String, ReferenceTransmittalTypeCode>();

	public static ReferenceTransmittalTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceTransmittalTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceTransmittalTypeCode COURIER_MESSAGE = new ReferenceTransmittalTypeCode(
			"Courier message",
			"COUMSG",
			"A message received by courier.");
	public static final ReferenceTransmittalTypeCode ELECTRONIC_TRANSFER = new ReferenceTransmittalTypeCode(
			"Electronic transfer",
			"ELCTRF",
			"The information was received through electronic transfer.");
	public static final ReferenceTransmittalTypeCode E_MAIL_MESSAGE = new ReferenceTransmittalTypeCode(
			"E-mail message",
			"EMLMSG",
			"A message received through an E-mail system.");
	public static final ReferenceTransmittalTypeCode FAX_MESSAGE = new ReferenceTransmittalTypeCode(
			"Fax message",
			"FAXMSG",
			"A message received by fax.");
	public static final ReferenceTransmittalTypeCode NOT_KNOWN = new ReferenceTransmittalTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ReferenceTransmittalTypeCode NOT_OTHERWISE_SPECIFIED = new ReferenceTransmittalTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ReferenceTransmittalTypeCode PHONE_MESSAGE = new ReferenceTransmittalTypeCode(
			"Phone message",
			"PHNMSG",
			"A message received by telephone.");
	public static final ReferenceTransmittalTypeCode RADIO_MESSAGE = new ReferenceTransmittalTypeCode(
			"Radio message",
			"RADMSG",
			"A message received from a radio transmission.");
	public static final ReferenceTransmittalTypeCode SECURE_FAX_MESSAGE = new ReferenceTransmittalTypeCode(
			"Secure fax message",
			"SFXMSG",
			"A message received by secure fax.");
	public static final ReferenceTransmittalTypeCode TELEX_MESSAGE = new ReferenceTransmittalTypeCode(
			"Telex message",
			"TELEX",
			"A message received by a certain kind of civilian means.");
	public static final ReferenceTransmittalTypeCode VIDEO = new ReferenceTransmittalTypeCode(
			"Video",
			"VIDEO",
			"The information was received via video.");

	private ReferenceTransmittalTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
