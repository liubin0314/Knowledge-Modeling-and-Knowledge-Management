/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanStatusDevelopmentStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value assigned to represent the state of preparation for a specific PLAN.";
	}

	private static HashMap<String, PlanStatusDevelopmentStatusCode> physicalToCode = new HashMap<String, PlanStatusDevelopmentStatusCode>();

	public static PlanStatusDevelopmentStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanStatusDevelopmentStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanStatusDevelopmentStatusCode COMPLETE = new PlanStatusDevelopmentStatusCode(
			"Complete",
			"COMPL",
			"The preparation of the specific PLAN has been completed.");
	public static final PlanStatusDevelopmentStatusCode NOT_COMPLETE = new PlanStatusDevelopmentStatusCode(
			"Not complete",
			"NCOMPL",
			"The preparation of the specific PLAN has not been completed.");

	private PlanStatusDevelopmentStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
