/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryObstacleTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of MILITARY-OBSTACLE-TYPE.";
	}

	private static HashMap<String, MilitaryObstacleTypeSubcategoryCode> physicalToCode = new HashMap<String, MilitaryObstacleTypeSubcategoryCode>();

	public static MilitaryObstacleTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryObstacleTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryObstacleTypeSubcategoryCode FIXED_AND_PREFABRICATED = new MilitaryObstacleTypeSubcategoryCode(
			"Fixed and prefabricated",
			"FXAMOV",
			"The obstacle is prefabricated and can not be moved.");
	public static final MilitaryObstacleTypeSubcategoryCode MOVEABLE = new MilitaryObstacleTypeSubcategoryCode(
			"Moveable",
			"MOVABL",
			"It is possible to move the obstacle.");
	public static final MilitaryObstacleTypeSubcategoryCode MOVEABLE_AND_PREFABRICATED = new MilitaryObstacleTypeSubcategoryCode(
			"Moveable and prefabricated",
			"MOVAPR",
			"The obstacle is prefabricated and can be moved.");

	private MilitaryObstacleTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
