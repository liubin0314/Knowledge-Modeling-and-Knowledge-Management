/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OperationalCapabilityQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the degree to which the specific OPERATIONAL-CAPABILITY can be fulfilled.";
	}

	private static HashMap<String, OperationalCapabilityQualifierCode> physicalToCode = new HashMap<String, OperationalCapabilityQualifierCode>();

	public static OperationalCapabilityQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OperationalCapabilityQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OperationalCapabilityQualifierCode HIGH = new OperationalCapabilityQualifierCode(
			"High",
			"HIGH",
			"Can fulfil a specific mission without restriction.");
	public static final OperationalCapabilityQualifierCode LOW = new OperationalCapabilityQualifierCode(
			"Low",
			"LOW",
			"Can fulfil a specific mission only under some circumstances.");
	public static final OperationalCapabilityQualifierCode MEDIUM = new OperationalCapabilityQualifierCode(
			"Medium",
			"MEDIUM",
			"Can fulfil a specific mission with some restriction.");

	private OperationalCapabilityQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
