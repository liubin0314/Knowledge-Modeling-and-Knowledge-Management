/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class WeaponTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of WEAPON-TYPE.";
	}

	private static HashMap<String, WeaponTypeSubcategoryCode> physicalToCode = new HashMap<String, WeaponTypeSubcategoryCode>();

	public static WeaponTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<WeaponTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final WeaponTypeSubcategoryCode ANTI_AIRCRAFT_ARTILLERY = new WeaponTypeSubcategoryCode(
			"Anti-aircraft artillery",
			"AAARTR",
			"An anti-aircraft weapon employed in the air defence role.");
	public static final WeaponTypeSubcategoryCode ANTI_AIRCRAFT_MACHINE_GUN = new WeaponTypeSubcategoryCode(
			"Anti-aircraft machine gun",
			"AAMGUN",
			"An anti-aircraft gun, normally belt fed, employed in the air defence role.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_AUTOMATIC_CANNON = new WeaponTypeSubcategoryCode(
			"Air-defence automatic cannon",
			"ADCAN",
			"An automatic cannon, usually linked to remote sensors, used primarily in the role of air defence.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_GUN = new WeaponTypeSubcategoryCode(
			"Air-defence gun",
			"ADGUN",
			"A gun used primarily in the role of air defence.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_GUN_HEAVY = new WeaponTypeSubcategoryCode(
			"Air-defence gun, heavy",
			"ADHEV",
			"A heavy gun used primarily in the role of air defence.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_GUN_LIGHT = new WeaponTypeSubcategoryCode(
			"Air-defence gun, light",
			"ADLGT",
			"A light gun used primarily in the role of air defence.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_GUN_MEDIUM = new WeaponTypeSubcategoryCode(
			"Air-defence gun, medium",
			"ADMED",
			"A medium gun used primarily in the role of air defence.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Air-defence missile launcher",
			"ADMIS",
			"A structural device designed to support and hold an air defence missile in position for firing.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_MISSILE_LAUNCHER_LONG_RANGE = new WeaponTypeSubcategoryCode(
			"Air-defence missile launcher, long range",
			"ADMLLR",
			"A structural device designed to support and hold a long range air defence missile in position for firing.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_MISSILE_LAUNCHER_MEDIUM_RANGE = new WeaponTypeSubcategoryCode(
			"Air-defence missile launcher, medium range",
			"ADMLMR",
			"A structural device designed to support and hold a medium range air defence missile in position for firing.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_MISSILE_LAUNCHER_SHORT_RANGE = new WeaponTypeSubcategoryCode(
			"Air-defence missile launcher, short range",
			"ADMLSR",
			"A structural device designed to support and hold a short range air defence missile in position for firing.");
	public static final WeaponTypeSubcategoryCode AIR_DEFENCE_MISSILE_LAUNCHER_THEATRE = new WeaponTypeSubcategoryCode(
			"Air-defence missile launcher, theatre",
			"ADMLT",
			"A structural device designed to support and hold a theatre air defence missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ARMOURED_INFANTRY_FIGHTING_COMBAT_VEHICLE = new WeaponTypeSubcategoryCode(
			"Armoured infantry fighting/combat vehicle",
			"AIFV",
			"An armoured vehicle used for transporting an infantry team and able to support it by the use of weapons.");
	public static final WeaponTypeSubcategoryCode ARTILLERY_HEAVY = new WeaponTypeSubcategoryCode(
			"Artillery, heavy",
			"ARTHEV",
			"Field artillery cannon with a calibre normally between 161mm and 210mm.");
	public static final WeaponTypeSubcategoryCode ARTILLERY_LIGHT = new WeaponTypeSubcategoryCode(
			"Artillery, light",
			"ARTLGT",
			"Field artillery cannon with a calibre of 120mm and less.");
	public static final WeaponTypeSubcategoryCode ARTILLERY_MEDIUM = new WeaponTypeSubcategoryCode(
			"Artillery, medium",
			"ARTMED",
			"Field artillery cannon with a calibre between 121 and 160mm.");
	public static final WeaponTypeSubcategoryCode ARTILLERY_VERY_HEAVY = new WeaponTypeSubcategoryCode(
			"Artillery, very heavy",
			"ARTVHV",
			"Heavy artillery, calibre of 211 MM or larger, for use in the field in support of manoeuvre forces.");
	public static final WeaponTypeSubcategoryCode ARMOURED_RECONNAISSANCE_VEHICLE = new WeaponTypeSubcategoryCode(
			"Armoured reconnaissance vehicle",
			"ARV",
			"A lightly armoured, highly mobile vehicle, serving as the main reconnaissance in infantry and airborne operations.");
	public static final WeaponTypeSubcategoryCode ASSAULT_GUN = new WeaponTypeSubcategoryCode(
			"Assault gun",
			"ASSGUN",
			"A cannon, with a relatively long barrel, operating with a relatively low angle of fire, and having a high muzzle velocity.");
	public static final WeaponTypeSubcategoryCode ANTI_SHIP_SURFACE_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Anti-ship surface missile launcher",
			"ASSML",
			"A structural device designed to support and hold an anti-ship surface missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GUN_HEAVY = new WeaponTypeSubcategoryCode(
			"Anti-tank gun, heavy",
			"ATGNHV",
			"A heavy gun designed to destroy tanks.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GUN_LIGHT = new WeaponTypeSubcategoryCode(
			"Anti-tank gun, light",
			"ATGNLT",
			"A light gun designed to destroy tanks.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GUN_MEDIUM = new WeaponTypeSubcategoryCode(
			"Anti-tank gun, medium",
			"ATGNMD",
			"A medium gun designed to destroy tanks.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GRENADE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Anti-tank grenade launcher",
			"ATGRLC",
			"A structural device designed to support and hold an anti-tank grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GRENADE_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Anti-tank grenade launcher, heavy",
			"ATGRLH",
			"A heavy structural device designed to support and hold an anti-tank grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GRENADE_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Anti-tank grenade launcher, light",
			"ATGRLL",
			"A light structural device designed to support and hold an anti-tank grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GRENADE_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Anti-tank grenade launcher, medium",
			"ATGRLM",
			"A medium structural device designed to support and hold an anti-tank grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_GUN = new WeaponTypeSubcategoryCode(
			"Anti-tank gun",
			"ATGUN",
			"A gun designed to destroy tanks.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Anti-tank missile launcher",
			"ATMIS",
			"A structural device designed to support and hold an anti-tank missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_MISSILE_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Anti-tank missile launcher, heavy",
			"ATMLHV",
			"A heavy structural device designed to support and hold an anti-tank missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_MISSILE_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Anti-tank missile launcher, light",
			"ATMLLT",
			"A light structural device designed to support and hold an anti-tank missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_MISSILE_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Anti-tank missile launcher, medium",
			"ATMLMD",
			"A medium structural device designed to support and hold an anti-tank missile in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_ROCKET_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Anti-tank rocket launcher, heavy",
			"ATRLHV",
			"A heavy structural device designed to support and hold an anti-tank rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_ROCKET_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Anti-tank rocket launcher, light",
			"ATRLLT",
			"A light structural device designed to support and hold an anti-tank rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_ROCKET_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Anti-tank rocket launcher, medium",
			"ATRLMD",
			"A medium structural device designed to support and hold an anti-tank rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode ANTI_TANK_ROCKET_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Anti-tank rocket launcher",
			"ATROC",
			"A structural device designed to support and hold an anti-tank rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode BLADE = new WeaponTypeSubcategoryCode(
			"Blade",
			"BLADE",
			"Flat cutting edge of a knife, saw or other tool or weapon.");
	public static final WeaponTypeSubcategoryCode BALLISTIC_MISSILE_LAUNCHER_LONG_RANGE = new WeaponTypeSubcategoryCode(
			"Ballistic missile launcher, long range",
			"BMLLR",
			"A structural device designed to support and hold a long range ballistic missile in position for firing.");
	public static final WeaponTypeSubcategoryCode BALLISTIC_MISSILE_LAUNCHER_MEDIUM_RANGE = new WeaponTypeSubcategoryCode(
			"Ballistic missile launcher, medium range",
			"BMLMR",
			"A structural device designed to support and hold a medium range ballistic missile in position for firing.");
	public static final WeaponTypeSubcategoryCode BALLISTIC_MISSILE_LAUNCHER_SHORT_RANGE = new WeaponTypeSubcategoryCode(
			"Ballistic missile launcher, short range",
			"BMLSR",
			"A structural device designed to support and hold a short range ballistic missile in position for firing.");
	public static final WeaponTypeSubcategoryCode BATTLE_TANK_HEAVY = new WeaponTypeSubcategoryCode(
			"Battle-tank, heavy",
			"BTNKHE",
			"An armoured fighting vehicle of more than 50 metric tons which, as its primary function, is designed to close with the enemy and engage their armour and infantry with direct fire.");
	public static final WeaponTypeSubcategoryCode BATTLE_TANK_LIGHT = new WeaponTypeSubcategoryCode(
			"Battle-tank, light",
			"BTNKLI",
			"An armoured fighting vehicle of less than 20 metric tons which, as its primary function, is designed to close with the enemy and engage their armour and infantry with direct fire.");
	public static final WeaponTypeSubcategoryCode BATTLE_TANK_MEDIUM = new WeaponTypeSubcategoryCode(
			"Battle-tank, medium",
			"BTNKME",
			"An armoured fighting vehicle of more than 20 and less than 50 metric tons which, as its primary function, is designed to close with the enemy and engage their armour and infantry with direct fire.");
	public static final WeaponTypeSubcategoryCode CLOSE_IN_WEAPON_SYSTEM = new WeaponTypeSubcategoryCode(
			"Close in weapon system",
			"CINWPS",
			"An anti-aircraft weapon system employed, as a last resort, in the air defence role.");
	public static final WeaponTypeSubcategoryCode CREW_SERVED_WEAPON_UNKNOWN_TYPE = new WeaponTypeSubcategoryCode(
			"Crew served weapon, unknown type",
			"CRWPUN",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final WeaponTypeSubcategoryCode DIRECT_FIRE_GUN = new WeaponTypeSubcategoryCode(
			"Direct fire gun",
			"DFGN",
			"A cannon with a relatively low angle of fire, having a high muzzle velocity with a tube length of 30 calibres or more that delivers fire on a target using the target itself as a point of aim for either the weapon or the director.");
	public static final WeaponTypeSubcategoryCode DIRECT_FIRE_GUN_HEAVY = new WeaponTypeSubcategoryCode(
			"Direct fire gun, heavy",
			"DFGNHV",
			"No definition provided in APP-6A.");
	public static final WeaponTypeSubcategoryCode DIRECT_FIRE_GUN_LIGHT = new WeaponTypeSubcategoryCode(
			"Direct fire gun, light",
			"DFGNLT",
			"No definition provided in APP-6A.");
	public static final WeaponTypeSubcategoryCode DIRECT_FIRE_GUN_MEDIUM = new WeaponTypeSubcategoryCode(
			"Direct fire gun, medium",
			"DFGNMD",
			"No definition provided in APP-6A.");
	public static final WeaponTypeSubcategoryCode FIXED_FORTIFICATION_ARTILLERY = new WeaponTypeSubcategoryCode(
			"Fixed fortification artillery",
			"FFART",
			"Guns inside a fortress.");
	public static final WeaponTypeSubcategoryCode FLAME_THROWER = new WeaponTypeSubcategoryCode(
			"Flame-thrower",
			"FLAMET",
			"A weapon that projects incendiary fuel and has provision for ignition of this fuel.");
	public static final WeaponTypeSubcategoryCode GUIDED_CRUISE_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Guided cruise missile launcher",
			"GCML",
			"A structural device designed to support and hold a guided cruise missile in position for firing.");
	public static final WeaponTypeSubcategoryCode GRENADE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Grenade launcher",
			"GRENLN",
			"A structural device designed to support and hold a grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode GRENADE_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Grenade launcher, heavy",
			"GRLNHV",
			"A heavy structural device designed to support and hold a grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode GRENADE_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Grenade launcher, light",
			"GRLNLT",
			"A light structural device designed to support and hold a grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode GRENADE_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Grenade launcher, medium",
			"GRLNMD",
			"A medium structural device designed to support and hold a grenade in position for firing.");
	public static final WeaponTypeSubcategoryCode GUN = new WeaponTypeSubcategoryCode(
			"Gun",
			"GUN",
			"A cannon with a relatively long barrel, operating with a relatively low angle of fire, and having a high muzzle velocity.");
	public static final WeaponTypeSubcategoryCode GUN_HOWITZER = new WeaponTypeSubcategoryCode(
			"Gun/howitzer",
			"GUNHOW",
			"A cannon that has the capability of both low-angle and high-angles of fire.");
	public static final WeaponTypeSubcategoryCode HOWITZER = new WeaponTypeSubcategoryCode(
			"Howitzer",
			"HOWIT",
			"A cannon that combines certain characteristics of guns and mortars. Normally a cannon with a tube length of 20 to 30 calibres; however, the tube length can exceed 30 calibres and still be considered a howitzer when the high angle firing zoning solution permits range overlap between charges.");
	public static final WeaponTypeSubcategoryCode HOWITZER_HEAVY = new WeaponTypeSubcategoryCode(
			"Howitzer, heavy",
			"HOWTHV",
			"A heavy cannon that combines certain characteristics of guns and mortars. Normally a cannon with a tube length of 20 to 30 calibres; however, the tube length can exceed 30 calibres and still be considered a howitzer when the high angle firing zoning solution permits range overlap between charges.");
	public static final WeaponTypeSubcategoryCode HOWITZER_LIGHT = new WeaponTypeSubcategoryCode(
			"Howitzer, light",
			"HOWTLT",
			"A light cannon that combines certain characteristics of guns and mortars. Normally a cannon with a tube length of 20 to 30 calibres; however, the tube length can exceed 30 calibres and still be considered a howitzer when the high angle firing zoning solution permits range overlap between charges.");
	public static final WeaponTypeSubcategoryCode HOWITZER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Howitzer, medium",
			"HOWTMD",
			"A medium cannon that combines certain characteristics of guns and mortars. Normally a cannon with a tube length of 20 to 30 calibres; however, the tube length can exceed 30 calibres and still be considered a howitzer when the high angle firing zoning solution permits range overlap between charges.");
	public static final WeaponTypeSubcategoryCode MACHINE_GUN_HEAVY = new WeaponTypeSubcategoryCode(
			"Machine gun, heavy",
			"MACGHV",
			"A heavy automatic gun giving continuous fire.");
	public static final WeaponTypeSubcategoryCode MACHINE_GUN_LIGHT = new WeaponTypeSubcategoryCode(
			"Machine gun, light",
			"MACGLT",
			"A light automatic gun giving continuous fire.");
	public static final WeaponTypeSubcategoryCode MACHINE_GUN = new WeaponTypeSubcategoryCode(
			"Machine gun",
			"MACGUN",
			"An automatic gun giving continuous fire.");
	public static final WeaponTypeSubcategoryCode MACHINE_PISTOL = new WeaponTypeSubcategoryCode(
			"Machine pistol",
			"MCHPTL",
			"A small hand-held firearm capable of giving continuous fire.");
	public static final WeaponTypeSubcategoryCode MULTIPLE_ROCKET_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Multiple rocket launcher",
			"MLRS",
			"A structural device designed to support and hold multiple rockets in position for firing.");
	public static final WeaponTypeSubcategoryCode MULTIPLE_ROCKET_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Multiple rocket launcher, heavy",
			"MLRSHV",
			"A heavy structural device designed to support and hold multiple rockets in position for firing.");
	public static final WeaponTypeSubcategoryCode MULTIPLE_ROCKET_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Multiple rocket launcher, light",
			"MLRSLT",
			"A light structural device designed to support and hold multiple rockets in position for firing.");
	public static final WeaponTypeSubcategoryCode MULTIPLE_ROCKET_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Multiple rocket launcher, medium",
			"MLRSMD",
			"A medium structural device designed to support and hold multiple rockets in position for firing.");
	public static final WeaponTypeSubcategoryCode MORTAR_HEAVY = new WeaponTypeSubcategoryCode(
			"Mortar, heavy",
			"MRTHEV",
			"A towed or vehicle-mounted, indirect fire weapon with either a rifled or smooth bore. It usually has a shorter range than a howitzer, employs a higher angle of fire, and its calibre is usually between 108mm and 150mm.");
	public static final WeaponTypeSubcategoryCode MORTAR_LIGHT = new WeaponTypeSubcategoryCode(
			"Mortar, light",
			"MRTLGT",
			"A man-portable, muzzle-loading, indirect fire weapon with either a rifled or smooth bore. It usually has a shorter range than a howitzer, employs a higher angle of fire, and its calibre is usually 60mm or smaller.");
	public static final WeaponTypeSubcategoryCode MORTAR_MEDIUM = new WeaponTypeSubcategoryCode(
			"Mortar, medium",
			"MRTMED",
			"A man-portable, muzzle-loading, indirect fire weapon with either a rifled or smooth bore. It usually has a shorter range than a howitzer, employs a higher angle of fire, and its calibre is usually between 61mm and 107mm.");
	public static final WeaponTypeSubcategoryCode MORTAR_VERY_HEAVY = new WeaponTypeSubcategoryCode(
			"Mortar, very heavy",
			"MRTVHV",
			"An indirect fire weapon, usually with a shorter range than a howitzer, employs a higher angle of fire, and its calibre is 151mm or larger.");
	public static final WeaponTypeSubcategoryCode NOT_KNOWN = new WeaponTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final WeaponTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new WeaponTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final WeaponTypeSubcategoryCode PISTOL_REVOLVER = new WeaponTypeSubcategoryCode(
			"Pistol/revolver",
			"PISTOL",
			"A small hand-held firearm.");
	public static final WeaponTypeSubcategoryCode RECOILLESS_GUN = new WeaponTypeSubcategoryCode(
			"Recoilless gun",
			"RECGUN",
			"A weapon capable of being fired from either a ground mount or from a vehicle, and capable of destroying tanks.");
	public static final WeaponTypeSubcategoryCode RECONNAISSANCE_TANK = new WeaponTypeSubcategoryCode(
			"Reconnaissance tank",
			"RECTNK",
			"A mobile armoured vehicle providing firepower and crew protection for reconnaissance activities.");
	public static final WeaponTypeSubcategoryCode RIFLE_ASSAULT = new WeaponTypeSubcategoryCode(
			"Rifle, assault",
			"RFLASS",
			"A firearm used in an assault role, that has a rifled bore designed to be fired from the shoulder.");
	public static final WeaponTypeSubcategoryCode RIFLE_CARBINE = new WeaponTypeSubcategoryCode(
			"Rifle, carbine",
			"RFLCRB",
			"A short firearm, usually a rifle that has a rifled bore designed to be fired from the shoulder.");
	public static final WeaponTypeSubcategoryCode RIFLE = new WeaponTypeSubcategoryCode(
			"Rifle",
			"RIFLE",
			"A firearm that has a rifled bore designed to be fired from the shoulder.");
	public static final WeaponTypeSubcategoryCode SURFACE_TO_AIR_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Surface-to-air missile launcher",
			"SAMISL",
			"A structural device designed to support and hold a surface to air missile in position for firing.");
	public static final WeaponTypeSubcategoryCode SHOTGUN = new WeaponTypeSubcategoryCode(
			"Shotgun",
			"SHOTGU",
			"A smooth-bore gun for firing small pellets at short range.");
	public static final WeaponTypeSubcategoryCode SINGLE_ROCKET_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Single rocket launcher",
			"SRCLAU",
			"A structural device designed to support and hold a rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode SINGLE_ROCKET_LAUNCHER_HEAVY = new WeaponTypeSubcategoryCode(
			"Single rocket launcher, heavy",
			"SRKLHV",
			"A heavy structural device designed to support and hold a rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode SINGLE_ROCKET_LAUNCHER_LIGHT = new WeaponTypeSubcategoryCode(
			"Single rocket launcher, light",
			"SRKLLG",
			"A light structural device designed to support and hold a rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode SINGLE_ROCKET_LAUNCHER_MEDIUM = new WeaponTypeSubcategoryCode(
			"Single rocket launcher, medium",
			"SRKLMD",
			"A medium structural device designed to support and hold a rocket in position for firing.");
	public static final WeaponTypeSubcategoryCode SURFACE_TO_SURFACE_MISSILE_LAUNCHER = new WeaponTypeSubcategoryCode(
			"Surface-to-surface missile launcher",
			"SSMIS",
			"A structural device designed to support and hold a surface to surface missile in position for firing.");
	public static final WeaponTypeSubcategoryCode SURFACE_TO_SURFACE_MISSILE_LAUNCHER_LONG_RANGE = new WeaponTypeSubcategoryCode(
			"Surface-to-surface missile launcher, long range",
			"SSMLLR",
			"A structural device designed to support and hold a long range surface to surface missile in position for firing.");
	public static final WeaponTypeSubcategoryCode SURFACE_TO_SURFACE_MISSILE_LAUNCHER_MEDIUM_RANGE = new WeaponTypeSubcategoryCode(
			"Surface-to-surface missile launcher, medium range",
			"SSMLMR",
			"A structural device designed to support and hold a medium range surface to surface missile in position for firing.");
	public static final WeaponTypeSubcategoryCode SURFACE_TO_SURFACE_MISSILE_LAUNCHER_SHORT_RANGE = new WeaponTypeSubcategoryCode(
			"Surface-to-surface missile launcher, short range",
			"SSMLSR",
			"A structural device designed to support and hold a short range surface to surface missile in position for firing.");
	public static final WeaponTypeSubcategoryCode SUBMACHINE_GUN = new WeaponTypeSubcategoryCode(
			"Submachine gun",
			"SUBMAC",
			"A lightweight automatic or semiautomatic gun.");
	public static final WeaponTypeSubcategoryCode TANK_DESTROYER = new WeaponTypeSubcategoryCode(
			"Tank destroyer",
			"TKDTRY",
			"A tracked vehicle that relies on speed and firepower and has minimum armoured protection, usually armed with either anti-tank guided missile launcher, 80-90 MM gun or a recoilless rifle.");
	public static final WeaponTypeSubcategoryCode TANK_GUN_HEAVY = new WeaponTypeSubcategoryCode(
			"Tank gun, heavy",
			"TKGUNH",
			"Heavy, turret mounted, tank gun, calibre over 120 MM, for use in the field against tanks.");
	public static final WeaponTypeSubcategoryCode TANK_GUN_LIGHT = new WeaponTypeSubcategoryCode(
			"Tank gun, light",
			"TKGUNL",
			"Light, turret mounted, tank gun, calibre under 90 MM, for use in the field against tanks.");
	public static final WeaponTypeSubcategoryCode TANK_GUN_MEDIUM = new WeaponTypeSubcategoryCode(
			"Tank gun, medium",
			"TKGUNM",
			"Medium, turret mounted, tank gun, calibre between 90 and 120 MM, for use in the field against tanks.");

	private WeaponTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
