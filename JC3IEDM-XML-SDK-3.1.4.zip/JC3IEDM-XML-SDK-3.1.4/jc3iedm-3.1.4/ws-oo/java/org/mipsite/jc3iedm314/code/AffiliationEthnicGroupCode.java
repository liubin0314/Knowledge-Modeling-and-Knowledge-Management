/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AffiliationEthnicGroupCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents an ethnic group in a specific AFFILIATION-ETHNIC-GROUP.";
	}

	private static HashMap<String, AffiliationEthnicGroupCode> physicalToCode = new HashMap<String, AffiliationEthnicGroupCode>();

	public static AffiliationEthnicGroupCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AffiliationEthnicGroupCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AffiliationEthnicGroupCode ABKHAZ = new AffiliationEthnicGroupCode(
			"Abkhaz",
			"ABKHAZ",
			"The ethnic group of Abkhaz people.");
	public static final AffiliationEthnicGroupCode ABORIGINAL = new AffiliationEthnicGroupCode(
			"Aboriginal",
			"ABORGN",
			"The ethnic group of Aboriginal people.");
	public static final AffiliationEthnicGroupCode ADMIRALTY_ISLANDER = new AffiliationEthnicGroupCode(
			"Admiralty Islander",
			"ADMISL",
			"The ethnic group of Admiralty Islander people.");
	public static final AffiliationEthnicGroupCode AFAR = new AffiliationEthnicGroupCode(
			"Afar",
			"AFAR",
			"The ethnic group of Afar people.");
	public static final AffiliationEthnicGroupCode AFGHANI = new AffiliationEthnicGroupCode(
			"Afghani",
			"AFGHAN",
			"The ethnic group of Afghani people.");
	public static final AffiliationEthnicGroupCode AFRICAN_ADJA = new AffiliationEthnicGroupCode(
			"African (Adja)",
			"AFRADJ",
			"The ethnic group of African (Adja) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_AMERICAN = new AffiliationEthnicGroupCode(
			"African American",
			"AFRAMR",
			"The ethnic group of African American people.");
	public static final AffiliationEthnicGroupCode AFRICAN_BALANTA = new AffiliationEthnicGroupCode(
			"African (Balanta)",
			"AFRBAL",
			"The ethnic group of African (Balanta) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_BARIBA = new AffiliationEthnicGroupCode(
			"African (Bariba)",
			"AFRBAR",
			"The ethnic group of African (Bariba) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_BASSA = new AffiliationEthnicGroupCode(
			"African (Bassa)",
			"AFRBAS",
			"The ethnic group of African (Bassa) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_BELLA = new AffiliationEthnicGroupCode(
			"African (Bella)",
			"AFRBEL",
			"The ethnic group of African (Bella) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_BURKINABE = new AffiliationEthnicGroupCode(
			"African (Burkinabe)",
			"AFRBUR",
			"The ethnic group of African (Burkinabe) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_FON = new AffiliationEthnicGroupCode(
			"African (Fon)",
			"AFRFON",
			"The ethnic group of African (Fon) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_FULA = new AffiliationEthnicGroupCode(
			"African (Fula)",
			"AFRFUL",
			"The ethnic group of African (Fula) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_GBANDI = new AffiliationEthnicGroupCode(
			"African (Gbandi)",
			"AFRGBA",
			"The ethnic group of African (Gbandi) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_GIO = new AffiliationEthnicGroupCode(
			"African (Gio)",
			"AFRGIO",
			"The ethnic group of African (Gio) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_GOLA = new AffiliationEthnicGroupCode(
			"African (Gola)",
			"AFRGOL",
			"The ethnic group of African (Gola) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_GREBO = new AffiliationEthnicGroupCode(
			"African (Grebo)",
			"AFRGRE",
			"The ethnic group of African (Grebo) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_JOLA = new AffiliationEthnicGroupCode(
			"African (Jola)",
			"AFRJOL",
			"The ethnic group of African (Jola) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_KISSI = new AffiliationEthnicGroupCode(
			"African (Kissi)",
			"AFRKIS",
			"The ethnic group of African (Kissi) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_KPELLE = new AffiliationEthnicGroupCode(
			"African (Kpelle)",
			"AFRKPE",
			"The ethnic group of African (Kpelle) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_KRAHN = new AffiliationEthnicGroupCode(
			"African (Krahn)",
			"AFRKRA",
			"The ethnic group of African (Krahn) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_KRU = new AffiliationEthnicGroupCode(
			"African (Kru)",
			"AFRKRU",
			"The ethnic group of African (Kru) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_LOMA = new AffiliationEthnicGroupCode(
			"African (Loma)",
			"AFRLOM",
			"The ethnic group of African (Loma) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_MANDINGA = new AffiliationEthnicGroupCode(
			"African (Mandinga)",
			"AFRMAN",
			"The ethnic group of African (Mandinga) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_MENDE = new AffiliationEthnicGroupCode(
			"African (Mende)",
			"AFRMEN",
			"The ethnic group of African (Mende) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_MANDINKA = new AffiliationEthnicGroupCode(
			"African (Mandinka)",
			"AFRMND",
			"The ethnic group of African (Mandinka) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_MANJACA = new AffiliationEthnicGroupCode(
			"African (Manjaca)",
			"AFRMNJ",
			"The ethnic group of African (Manjaca) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_MANO = new AffiliationEthnicGroupCode(
			"African (Mano)",
			"AFRMNO",
			"The ethnic group of African (Mano) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_NDEBELE = new AffiliationEthnicGroupCode(
			"African (Ndebele)",
			"AFRNDE",
			"The ethnic group of African (Ndebele) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"African not further defined",
			"AFRNFD",
			"The not further defined ethnic groups of African people.");
	public static final AffiliationEthnicGroupCode AFRO_ARAB = new AffiliationEthnicGroupCode(
			"Afro-Arab",
			"AFROAR",
			"The ethnic group of Afro-Arab people.");
	public static final AffiliationEthnicGroupCode AFRO_ASIAN = new AffiliationEthnicGroupCode(
			"Afro-Asian",
			"AFROAS",
			"The ethnic group of Afro-Asian people.");
	public static final AffiliationEthnicGroupCode AFRO_CHINESE = new AffiliationEthnicGroupCode(
			"Afro-Chinese",
			"AFROCH",
			"The ethnic group of Afro-Chinese people.");
	public static final AffiliationEthnicGroupCode AFRO_EAST_INDIAN = new AffiliationEthnicGroupCode(
			"Afro-East Indian",
			"AFROEA",
			"The ethnic group of Afro-East Indian people.");
	public static final AffiliationEthnicGroupCode AFRO_EUROPEAN = new AffiliationEthnicGroupCode(
			"Afro-European",
			"AFROEU",
			"The ethnic group of Afro-European people.");
	public static final AffiliationEthnicGroupCode AFRICAN_PAPEL = new AffiliationEthnicGroupCode(
			"African (Papel)",
			"AFRPAP",
			"The ethnic group of African (Papel) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_SERAHULI = new AffiliationEthnicGroupCode(
			"African (Serahuli)",
			"AFRSER",
			"The ethnic group of African (Serahuli) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_SHONA = new AffiliationEthnicGroupCode(
			"African (Shona)",
			"AFRSHO",
			"The ethnic group of African (Shona) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_TEMNE = new AffiliationEthnicGroupCode(
			"African (Temne)",
			"AFRTEM",
			"The ethnic group of African (Temne) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_VAI = new AffiliationEthnicGroupCode(
			"African (Vai)",
			"AFRVAI",
			"The ethnic group of African (Vai) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_WOLOF = new AffiliationEthnicGroupCode(
			"African (Wolof)",
			"AFRWOL",
			"The ethnic group of African (Wolof) people.");
	public static final AffiliationEthnicGroupCode AFRICAN_YORUBA = new AffiliationEthnicGroupCode(
			"African (Yoruba)",
			"AFRYOR",
			"The ethnic group of African (Yoruba) people.");
	public static final AffiliationEthnicGroupCode AGNI = new AffiliationEthnicGroupCode(
			"Agni",
			"AGNI",
			"The ethnic group of Agni people.");
	public static final AffiliationEthnicGroupCode AITUTAKI_ISLANDER = new AffiliationEthnicGroupCode(
			"Aitutaki Islander",
			"AITISL",
			"The ethnic group of Aitutaki Islander people.");
	public static final AffiliationEthnicGroupCode ALBANIAN_ITALIANS = new AffiliationEthnicGroupCode(
			"Albanian-Italians",
			"ALBANN",
			"The ethnic group of Albanian-Italians people.");
	public static final AffiliationEthnicGroupCode ALBANIAN = new AffiliationEthnicGroupCode(
			"Albanian",
			"ALBNAN",
			"The ethnic group of Albanian people.");
	public static final AffiliationEthnicGroupCode ALEMANNIC = new AffiliationEthnicGroupCode(
			"Alemannic",
			"ALEMAN",
			"The ethnic group of Alemannic people.");
	public static final AffiliationEthnicGroupCode ALGERIAN = new AffiliationEthnicGroupCode(
			"Algerian",
			"ALGRAN",
			"The ethnic group of Algerian people.");
	public static final AffiliationEthnicGroupCode AMERICO_LIBERIANS = new AffiliationEthnicGroupCode(
			"Americo-Liberians",
			"AMERIC",
			"The ethnic group of Americo-Liberians people.");
	public static final AffiliationEthnicGroupCode AMERINDIAN = new AffiliationEthnicGroupCode(
			"Amerindian",
			"AMERIN",
			"The ethnic group of Amerindian people.");
	public static final AffiliationEthnicGroupCode AMERICAN_US = new AffiliationEthnicGroupCode(
			"American (US)",
			"AMERUS",
			"The ethnic group of American (US) people.");
	public static final AffiliationEthnicGroupCode AMHARA = new AffiliationEthnicGroupCode(
			"Amhara",
			"AMHARA",
			"The ethnic group of Amhara people.");
	public static final AffiliationEthnicGroupCode ANDORRAN = new AffiliationEthnicGroupCode(
			"Andorran",
			"ANDORR",
			"The ethnic group of Andorran people.");
	public static final AffiliationEthnicGroupCode ANGOLARES = new AffiliationEthnicGroupCode(
			"Angolares",
			"ANGOLA",
			"The ethnic group of Angolares people.");
	public static final AffiliationEthnicGroupCode ANTAISAKA = new AffiliationEthnicGroupCode(
			"Antaisaka",
			"ANTASA",
			"The ethnic group of Antaisaka people.");
	public static final AffiliationEthnicGroupCode ARAB = new AffiliationEthnicGroupCode(
			"Arab",
			"ARAB",
			"The ethnic group of Arab people.");
	public static final AffiliationEthnicGroupCode ARAB_BERBER = new AffiliationEthnicGroupCode(
			"Arab-Berber",
			"ARABBE",
			"The ethnic group of Arab-Berber people.");
	public static final AffiliationEthnicGroupCode ARGENTINIAN = new AffiliationEthnicGroupCode(
			"Argentinian",
			"ARGNTN",
			"The ethnic group of Argentinian people.");
	public static final AffiliationEthnicGroupCode ARMENIAN = new AffiliationEthnicGroupCode(
			"Armenian",
			"ARMNAN",
			"The ethnic group of Armenian people.");
	public static final AffiliationEthnicGroupCode ASIAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Asian not further defined",
			"ASNNFD",
			"The not further defined ethnic groups of Asian people.");
	public static final AffiliationEthnicGroupCode ASSYRIAN = new AffiliationEthnicGroupCode(
			"Assyrian",
			"ASSYRN",
			"The ethnic group of Assyrian people.");
	public static final AffiliationEthnicGroupCode ATIU_ISLANDER = new AffiliationEthnicGroupCode(
			"Atiu Islander",
			"ATUISL",
			"The ethnic group of Atiu Islander people.");
	public static final AffiliationEthnicGroupCode AUSTRAL_ISLANDER = new AffiliationEthnicGroupCode(
			"Austral Islander",
			"AUSISL",
			"The ethnic group of Austral Islander people.");
	public static final AffiliationEthnicGroupCode AUSTRALIAN_ABORIGINAL = new AffiliationEthnicGroupCode(
			"Australian Aboriginal",
			"AUSTRA",
			"The ethnic group of Australian Aboriginal people.");
	public static final AffiliationEthnicGroupCode AUSTRALIAN = new AffiliationEthnicGroupCode(
			"Australian",
			"AUSTRL",
			"The ethnic group of Australian people.");
	public static final AffiliationEthnicGroupCode AUSTRIAN = new AffiliationEthnicGroupCode(
			"Austrian",
			"AUSTRN",
			"The ethnic group of Austrian people.");
	public static final AffiliationEthnicGroupCode AYMARA = new AffiliationEthnicGroupCode(
			"Aymara",
			"AYMARA",
			"The ethnic group of Aymara people.");
	public static final AffiliationEthnicGroupCode AZERBAIJANI = new AffiliationEthnicGroupCode(
			"Azerbaijani",
			"AZERBA",
			"The ethnic group of Azerbaijani people.");
	public static final AffiliationEthnicGroupCode AZERI = new AffiliationEthnicGroupCode(
			"Azeri",
			"AZERI",
			"The ethnic group of Azeri people.");
	public static final AffiliationEthnicGroupCode BAHRAINI = new AffiliationEthnicGroupCode(
			"Bahraini",
			"BAHRAN",
			"The ethnic group of Bahraini people.");
	public static final AffiliationEthnicGroupCode BAKONGO = new AffiliationEthnicGroupCode(
			"Bakongo",
			"BAKONG",
			"The ethnic group of Bakongo people.");
	public static final AffiliationEthnicGroupCode BALOCH = new AffiliationEthnicGroupCode(
			"Baloch",
			"BALOCH",
			"The ethnic group of Baloch people.");
	public static final AffiliationEthnicGroupCode BANDA = new AffiliationEthnicGroupCode(
			"Banda",
			"BANDA",
			"The ethnic group of Banda people.");
	public static final AffiliationEthnicGroupCode BANGLADESHI = new AffiliationEthnicGroupCode(
			"Bangladeshi",
			"BANGLS",
			"The ethnic group of Bangladeshi people.");
	public static final AffiliationEthnicGroupCode BANTU_BAPOUNOU = new AffiliationEthnicGroupCode(
			"Bantu (Bapounou)",
			"BANTBA",
			"The ethnic group of Bantu (Bapounou) people.");
	public static final AffiliationEthnicGroupCode BANTU_BATEKE = new AffiliationEthnicGroupCode(
			"Bantu (Bateke)",
			"BANTBT",
			"The ethnic group of Bantu (Bateke) people.");
	public static final AffiliationEthnicGroupCode BANTU_ESHIRA = new AffiliationEthnicGroupCode(
			"Bantu (Eshira)",
			"BANTES",
			"The ethnic group of Bantu (Eshira) people.");
	public static final AffiliationEthnicGroupCode BANTU_FANG = new AffiliationEthnicGroupCode(
			"Bantu (Fang)",
			"BANTFA",
			"The ethnic group of Bantu (Fang) people.");
	public static final AffiliationEthnicGroupCode BANTU_KONGO = new AffiliationEthnicGroupCode(
			"Bantu (Kongo)",
			"BANTKO",
			"The ethnic group of Bantu (Kongo) people.");
	public static final AffiliationEthnicGroupCode BANTU_LUBA = new AffiliationEthnicGroupCode(
			"Bantu (Luba)",
			"BANTLU",
			"The ethnic group of Bantu (Luba) people.");
	public static final AffiliationEthnicGroupCode BANTU_MONGO = new AffiliationEthnicGroupCode(
			"Bantu (Mongo)",
			"BANTMO",
			"The ethnic group of Bantu (Mongo) people.");
	public static final AffiliationEthnicGroupCode BANTU = new AffiliationEthnicGroupCode(
			"Bantu",
			"BANTU",
			"The ethnic group of Bantu people.");
	public static final AffiliationEthnicGroupCode BAOULE = new AffiliationEthnicGroupCode(
			"Baoule",
			"BAOULE",
			"The ethnic group of Baoule people.");
	public static final AffiliationEthnicGroupCode BASARWA = new AffiliationEthnicGroupCode(
			"Basarwa",
			"BASARW",
			"The ethnic group of Basarwa people.");
	public static final AffiliationEthnicGroupCode BASHKIR = new AffiliationEthnicGroupCode(
			"Bashkir",
			"BASHKR",
			"The ethnic group of Bashkir people.");
	public static final AffiliationEthnicGroupCode BASQUE = new AffiliationEthnicGroupCode(
			"Basque",
			"BASQUE",
			"The ethnic group of Basque people.");
	public static final AffiliationEthnicGroupCode BATSWANA = new AffiliationEthnicGroupCode(
			"Batswana",
			"BATSWA",
			"The ethnic group of Batswana people.");
	public static final AffiliationEthnicGroupCode BAYA = new AffiliationEthnicGroupCode(
			"Baya",
			"BAYA",
			"The ethnic group of Baya people.");
	public static final AffiliationEthnicGroupCode BEJA = new AffiliationEthnicGroupCode(
			"Beja",
			"BEJA",
			"The ethnic group of Beja people.");
	public static final AffiliationEthnicGroupCode BELAU_PALAU_ISLANDER = new AffiliationEthnicGroupCode(
			"Belau/Palau Islander",
			"BELAU",
			"The ethnic group of Belau/Palau Islander people.");
	public static final AffiliationEthnicGroupCode BELGIAN = new AffiliationEthnicGroupCode(
			"Belgian",
			"BELGAN",
			"The ethnic group of Belgian people.");
	public static final AffiliationEthnicGroupCode BELORUSSIAN = new AffiliationEthnicGroupCode(
			"Belorussian",
			"BELORU",
			"The ethnic group of Belorussian people.");
	public static final AffiliationEthnicGroupCode BENGALI = new AffiliationEthnicGroupCode(
			"Bengali",
			"BENGLI",
			"The ethnic group of Bengali people.");
	public static final AffiliationEthnicGroupCode BERBER = new AffiliationEthnicGroupCode(
			"Berber",
			"BERBER",
			"The ethnic group of Berber people.");
	public static final AffiliationEthnicGroupCode BERI_KANOURI = new AffiliationEthnicGroupCode(
			"Beri (Kanouri)",
			"BERIKA",
			"The ethnic group of Beri (Kanouri) people.");
	public static final AffiliationEthnicGroupCode BETE = new AffiliationEthnicGroupCode(
			"Bete",
			"BETE",
			"The ethnic group of Bete people.");
	public static final AffiliationEthnicGroupCode BETSIMISARAKA = new AffiliationEthnicGroupCode(
			"Betsimisaraka",
			"BETSIM",
			"The ethnic group of Betsimisaraka people.");
	public static final AffiliationEthnicGroupCode BHOTE = new AffiliationEthnicGroupCode(
			"Bhote",
			"BHOTE",
			"The ethnic group of Bhote people.");
	public static final AffiliationEthnicGroupCode BHOTIAS = new AffiliationEthnicGroupCode(
			"Bhotias",
			"BHOTIA",
			"The ethnic group of Bhotias people.");
	public static final AffiliationEthnicGroupCode BIHARIS = new AffiliationEthnicGroupCode(
			"Biharis",
			"BIHARS",
			"The ethnic group of Biharis people.");
	public static final AffiliationEthnicGroupCode BIOKO_BUBI = new AffiliationEthnicGroupCode(
			"Bioko (Bubi)",
			"BIOKOB",
			"The ethnic group of Bioko (Bubi) people.");
	public static final AffiliationEthnicGroupCode BIOKO_FERNANDINOS = new AffiliationEthnicGroupCode(
			"Bioko (Fernandinos)",
			"BIOKOF",
			"The ethnic group of Bioko (Fernandinos) people.");
	public static final AffiliationEthnicGroupCode BISMARK_ARCHIPELAGOAN = new AffiliationEthnicGroupCode(
			"Bismark Archipelagoan",
			"BISMAR",
			"The ethnic group of Bismark Archipelagoan people.");
	public static final AffiliationEthnicGroupCode BLACK = new AffiliationEthnicGroupCode(
			"Black",
			"BLACK",
			"The ethnic group of Black people.");
	public static final AffiliationEthnicGroupCode BLACK_AFRICAN = new AffiliationEthnicGroupCode(
			"Black African",
			"BLACKA",
			"The ethnic group of Black African people.");
	public static final AffiliationEthnicGroupCode BOBO = new AffiliationEthnicGroupCode(
			"Bobo",
			"BOBO",
			"The ethnic group of Bobo people.");
	public static final AffiliationEthnicGroupCode BOLIVIAN = new AffiliationEthnicGroupCode(
			"Bolivian",
			"BOLIVN",
			"The ethnic group of Bolivian people.");
	public static final AffiliationEthnicGroupCode BOSNIAN_CROAT = new AffiliationEthnicGroupCode(
			"Bosnian Croat",
			"BOSCRO",
			"The ethnic group of Bosnian Croat people.");
	public static final AffiliationEthnicGroupCode BOSNIAN_MUSLIM = new AffiliationEthnicGroupCode(
			"Bosnian Muslim",
			"BOSMUS",
			"The ethnic group of Bosnian Muslim people.");
	public static final AffiliationEthnicGroupCode BOSNIAN_SERB = new AffiliationEthnicGroupCode(
			"Bosnian Serb",
			"BOSSER",
			"The ethnic group of Bosnian Serb people.");
	public static final AffiliationEthnicGroupCode BOUGAINVILLEAN = new AffiliationEthnicGroupCode(
			"Bougainvillean",
			"BOUGNV",
			"The ethnic group of Bougainvillean people.");
	public static final AffiliationEthnicGroupCode BRAZILIAN = new AffiliationEthnicGroupCode(
			"Brazilian",
			"BRAZLN",
			"The ethnic group of Brazilian people.");
	public static final AffiliationEthnicGroupCode BRETONS = new AffiliationEthnicGroupCode(
			"Bretons",
			"BRETON",
			"The ethnic group of Bretons people.");
	public static final AffiliationEthnicGroupCode BRITISH_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"British not elsewhere classified",
			"BRTNEC",
			"The not elsewhere classified ethnic groups of British people.");
	public static final AffiliationEthnicGroupCode BRITISH_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"British not further defined",
			"BRTNFD",
			"The not further defined ethnic groups of British people.");
	public static final AffiliationEthnicGroupCode BULGARIAN = new AffiliationEthnicGroupCode(
			"Bulgarian",
			"BULGRN",
			"The ethnic group of Bulgarian people.");
	public static final AffiliationEthnicGroupCode BURGHER = new AffiliationEthnicGroupCode(
			"Burgher",
			"BURGHR",
			"The ethnic group of Burgher people.");
	public static final AffiliationEthnicGroupCode BURMAN = new AffiliationEthnicGroupCode(
			"Burman",
			"BURMAN",
			"The ethnic group of Burman people.");
	public static final AffiliationEthnicGroupCode BURMESE = new AffiliationEthnicGroupCode(
			"Burmese",
			"BURMSE",
			"The ethnic group of Burmese people.");
	public static final AffiliationEthnicGroupCode BUYI = new AffiliationEthnicGroupCode(
			"Buyi",
			"BUYI",
			"The ethnic group of Buyi people.");
	public static final AffiliationEthnicGroupCode BYELORUSSIAN = new AffiliationEthnicGroupCode(
			"Byelorussian",
			"BYLRSN",
			"The ethnic group of Byelorussian people.");
	public static final AffiliationEthnicGroupCode CAFRE = new AffiliationEthnicGroupCode(
			"Cafre",
			"CAFRE",
			"The ethnic group of Cafre people.");
	public static final AffiliationEthnicGroupCode CAMEROON_HIGHLANDERS = new AffiliationEthnicGroupCode(
			"Cameroon Highlanders",
			"CAMERO",
			"The ethnic group of Cameroon Highlanders people.");
	public static final AffiliationEthnicGroupCode CANADIAN = new AffiliationEthnicGroupCode(
			"Canadian",
			"CANADN",
			"The ethnic group of Canadian people.");
	public static final AffiliationEthnicGroupCode CARIB_INDIAN = new AffiliationEthnicGroupCode(
			"Carib Indian",
			"CARIBN",
			"The ethnic group of Carib Indian people.");
	public static final AffiliationEthnicGroupCode CAROLINE_ISLANDER = new AffiliationEthnicGroupCode(
			"Caroline Islander",
			"CARISL",
			"The ethnic group of Caroline Islander people.");
	public static final AffiliationEthnicGroupCode CAUCASIAN = new AffiliationEthnicGroupCode(
			"Caucasian",
			"CAUCAS",
			"The ethnic group of Caucasian people.");
	public static final AffiliationEthnicGroupCode CELTIC = new AffiliationEthnicGroupCode(
			"Celtic",
			"CELTIC",
			"The ethnic group of Celtic people.");
	public static final AffiliationEthnicGroupCode CENTRAL_AMERICAN_INDIAN = new AffiliationEthnicGroupCode(
			"Central American Indian",
			"CENAMR",
			"The ethnic group of Central American Indian people.");
	public static final AffiliationEthnicGroupCode CHAHAR_AIMAKS = new AffiliationEthnicGroupCode(
			"Chahar Aimaks",
			"CHAHAR",
			"The ethnic group of Chahar Aimaks people.");
	public static final AffiliationEthnicGroupCode CHAM = new AffiliationEthnicGroupCode(
			"Cham",
			"CHAM",
			"The ethnic group of Cham people.");
	public static final AffiliationEthnicGroupCode CHAMORRO = new AffiliationEthnicGroupCode(
			"Chamorro",
			"CHAMOR",
			"The ethnic group of Chamorro people.");
	public static final AffiliationEthnicGroupCode CHEWA = new AffiliationEthnicGroupCode(
			"Chewa",
			"CHEWA",
			"The ethnic group of Chewa people.");
	public static final AffiliationEthnicGroupCode CHILEAN = new AffiliationEthnicGroupCode(
			"Chilean",
			"CHLEAN",
			"The ethnic group of Chilean people.");
	public static final AffiliationEthnicGroupCode CHANNEL_ISLANDER = new AffiliationEthnicGroupCode(
			"Channel Islander",
			"CHNISL",
			"The ethnic group of Channel Islander people.");
	public static final AffiliationEthnicGroupCode CHINESE_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Chinese not elsewhere classified",
			"CHNNEC",
			"The not elsewhere classified ethnic groups of Chinese people.");
	public static final AffiliationEthnicGroupCode CHINESE_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Chinese not further defined",
			"CHNNFD",
			"The not further defined ethnic groups of Chinese people.");
	public static final AffiliationEthnicGroupCode CHRISTIAN_MALAY = new AffiliationEthnicGroupCode(
			"Christian Malay",
			"CHRSTN",
			"The ethnic group of Christian Malay people.");
	public static final AffiliationEthnicGroupCode CHUVASH = new AffiliationEthnicGroupCode(
			"Chuvash",
			"CHUVAS",
			"The ethnic group of Chuvash people.");
	public static final AffiliationEthnicGroupCode CIRCASSIAN = new AffiliationEthnicGroupCode(
			"Circassian",
			"CIRCAS",
			"The ethnic group of Circassian people.");
	public static final AffiliationEthnicGroupCode COASTAL_MALAYS = new AffiliationEthnicGroupCode(
			"Coastal Malays",
			"COASTA",
			"The ethnic group of Coastal Malays people.");
	public static final AffiliationEthnicGroupCode COCOS_MALAYS = new AffiliationEthnicGroupCode(
			"Cocos Malays",
			"COCOSM",
			"The ethnic group of Cocos Malays people.");
	public static final AffiliationEthnicGroupCode COOK_ISLAND_MAORI_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Cook Island Maori not further defined",
			"COKNFD",
			"The not further defined ethnic groups of Cook Island Maori people.");
	public static final AffiliationEthnicGroupCode COLOMBIAN = new AffiliationEthnicGroupCode(
			"Colombian",
			"COLMBN",
			"The ethnic group of Colombian people.");
	public static final AffiliationEthnicGroupCode COMORAN = new AffiliationEthnicGroupCode(
			"Comoran",
			"COMORA",
			"The ethnic group of Comoran people.");
	public static final AffiliationEthnicGroupCode CORNISH = new AffiliationEthnicGroupCode(
			"Cornish",
			"CORNSH",
			"The ethnic group of Cornish people.");
	public static final AffiliationEthnicGroupCode CORSICAN = new AffiliationEthnicGroupCode(
			"Corsican",
			"CORSCN",
			"The ethnic group of Corsican people.");
	public static final AffiliationEthnicGroupCode COSTA_RICAN = new AffiliationEthnicGroupCode(
			"Costa Rican",
			"COSTRN",
			"The ethnic group of Costa Rican people.");
	public static final AffiliationEthnicGroupCode COTIERS = new AffiliationEthnicGroupCode(
			"Cotiers",
			"COTIER",
			"The ethnic group of Cotiers people.");
	public static final AffiliationEthnicGroupCode CREOLE_LATIN_AMERICA = new AffiliationEthnicGroupCode(
			"Creole (Latin America)",
			"CRELLA",
			"The ethnic group of Creole (Latin America) people.");
	public static final AffiliationEthnicGroupCode CREOLE_US = new AffiliationEthnicGroupCode(
			"Creole (US)",
			"CRELUS",
			"The ethnic group of Creole (US) people.");
	public static final AffiliationEthnicGroupCode CREOLE = new AffiliationEthnicGroupCode(
			"Creole",
			"CREOLE",
			"The ethnic group of Creole people.");
	public static final AffiliationEthnicGroupCode CREOLE_MULATTO = new AffiliationEthnicGroupCode(
			"Creole (Mulatto)",
			"CREOLM",
			"The ethnic group of Creole (Mulatto) people.");
	public static final AffiliationEthnicGroupCode CROAT_CROATIAN = new AffiliationEthnicGroupCode(
			"Croat/Croatian",
			"CROATN",
			"The ethnic group of Croat/Croatian people.");
	public static final AffiliationEthnicGroupCode CYPRIOT_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Cypriot not further defined",
			"CYRNFD",
			"The not further defined ethnic groups of Cypriot people.");
	public static final AffiliationEthnicGroupCode CZECH = new AffiliationEthnicGroupCode(
			"Czech",
			"CZECH",
			"The ethnic group of Czech people.");
	public static final AffiliationEthnicGroupCode DAGHESTANIS = new AffiliationEthnicGroupCode(
			"Daghestanis",
			"DAGHES",
			"The ethnic group of Daghestanis people.");
	public static final AffiliationEthnicGroupCode DALMATIAN = new AffiliationEthnicGroupCode(
			"Dalmatian",
			"DALMTN",
			"The ethnic group of Dalmatian people.");
	public static final AffiliationEthnicGroupCode DANISH = new AffiliationEthnicGroupCode(
			"Danish",
			"DANISH",
			"The ethnic group of Danish people.");
	public static final AffiliationEthnicGroupCode DIOLA = new AffiliationEthnicGroupCode(
			"Diola",
			"DIOLA",
			"The ethnic group of Diola people.");
	public static final AffiliationEthnicGroupCode DJERMA = new AffiliationEthnicGroupCode(
			"Djerma",
			"DJERMA",
			"The ethnic group of Djerma people.");
	public static final AffiliationEthnicGroupCode DRAVIDIAN = new AffiliationEthnicGroupCode(
			"Dravidian",
			"DRAVID",
			"The ethnic group of Dravidian people.");
	public static final AffiliationEthnicGroupCode DUTCH_NETHERLANDS = new AffiliationEthnicGroupCode(
			"Dutch/Netherlands",
			"DUTCH",
			"The ethnic group of Dutch/Netherlands people.");
	public static final AffiliationEthnicGroupCode EASTER_ISLANDER = new AffiliationEthnicGroupCode(
			"Easter Islander",
			"EASISL",
			"The ethnic group of Easter Islander people.");
	public static final AffiliationEthnicGroupCode ECUADORIAN = new AffiliationEthnicGroupCode(
			"Ecuadorian",
			"ECUDRN",
			"The ethnic group of Ecuadorian people.");
	public static final AffiliationEthnicGroupCode EGYPTIAN = new AffiliationEthnicGroupCode(
			"Egyptian",
			"EGYPTN",
			"The ethnic group of Egyptian people.");
	public static final AffiliationEthnicGroupCode ENGLISH = new AffiliationEthnicGroupCode(
			"English",
			"ENGLSH",
			"The ethnic group of English people.");
	public static final AffiliationEthnicGroupCode EQUATORIAL_BANTU = new AffiliationEthnicGroupCode(
			"Equatorial Bantu",
			"EQUATO",
			"The ethnic group of Equatorial Bantu people.");
	public static final AffiliationEthnicGroupCode ERIRIAN = new AffiliationEthnicGroupCode(
			"Eririan",
			"ERIRIA",
			"The ethnic group of Eririan people.");
	public static final AffiliationEthnicGroupCode ESTONIAN = new AffiliationEthnicGroupCode(
			"Estonian",
			"ESTONN",
			"The ethnic group of Estonian people.");
	public static final AffiliationEthnicGroupCode ETHNIC_NEPALESE = new AffiliationEthnicGroupCode(
			"Ethnic Nepalese",
			"ETHNCN",
			"The ethnic group of Ethnic Nepalese people.");
	public static final AffiliationEthnicGroupCode ETHNIC_TIGRAYS = new AffiliationEthnicGroupCode(
			"Ethnic Tigrays",
			"ETHNCT",
			"The ethnic group of Ethnic Tigrays people.");
	public static final AffiliationEthnicGroupCode EUROPEAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"European not elsewhere classified",
			"EURNEC",
			"The not elsewhere classified ethnic groups of European people.");
	public static final AffiliationEthnicGroupCode EUROPEAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"European not further defined",
			"EURNFD",
			"The not further defined ethnic groups of European people.");
	public static final AffiliationEthnicGroupCode EURO_AFRICANS = new AffiliationEthnicGroupCode(
			"Euro-Africans",
			"EUROAF",
			"The ethnic group of Euro-Africans people.");
	public static final AffiliationEthnicGroupCode EURONESIANS = new AffiliationEthnicGroupCode(
			"Euronesians",
			"EUROIN",
			"The ethnic group of Euronesians people.");
	public static final AffiliationEthnicGroupCode EUROPEAN_INDIAN = new AffiliationEthnicGroupCode(
			"European-Indian",
			"EUROPE",
			"The ethnic group of European-Indian people.");
	public static final AffiliationEthnicGroupCode EWE = new AffiliationEthnicGroupCode(
			"Ewe",
			"EWE",
			"The ethnic group of Ewe people.");
	public static final AffiliationEthnicGroupCode FAROESE = new AffiliationEthnicGroupCode(
			"Faroese",
			"FAROES",
			"The ethnic group of Faroese people.");
	public static final AffiliationEthnicGroupCode FIJIAN_EXCEPT_FIJI_INDIAN_INDO_FIJIAN = new AffiliationEthnicGroupCode(
			"Fijian (except Fiji Indian/Indo-Fijian)",
			"FIJIAN",
			"The ethnic group of Fijian (except Fiji Indian/Indo-Fijian) people.");
	public static final AffiliationEthnicGroupCode FIJIAN_INDIAN_INDO_FIJIAN = new AffiliationEthnicGroupCode(
			"Fijian Indian/Indo-Fijian",
			"FIJNIN",
			"The ethnic group of Fijian Indian/Indo-Fijian people.");
	public static final AffiliationEthnicGroupCode FILIPINO = new AffiliationEthnicGroupCode(
			"Filipino",
			"FILPNO",
			"The ethnic group of Filipino people.");
	public static final AffiliationEthnicGroupCode FINNISH = new AffiliationEthnicGroupCode(
			"Finnish",
			"FINNSH",
			"The ethnic group of Finnish people.");
	public static final AffiliationEthnicGroupCode FLEMISH = new AffiliationEthnicGroupCode(
			"Flemish",
			"FLEMSH",
			"The ethnic group of Flemish people.");
	public static final AffiliationEthnicGroupCode FALKLAND_ISLANDER_KELPER = new AffiliationEthnicGroupCode(
			"Falkland Islander/Kelper",
			"FLKISL",
			"The ethnic group of Falkland Islander/Kelper people.");
	public static final AffiliationEthnicGroupCode FORROS = new AffiliationEthnicGroupCode(
			"Forros",
			"FORROS",
			"The ethnic group of Forros people.");
	public static final AffiliationEthnicGroupCode FRANCO_MAURITIAN = new AffiliationEthnicGroupCode(
			"Franco-Mauritian",
			"FRANCO",
			"The ethnic group of Franco-Mauritian people.");
	public static final AffiliationEthnicGroupCode FRENCH = new AffiliationEthnicGroupCode(
			"French",
			"FRENCH",
			"The ethnic group of French people.");
	public static final AffiliationEthnicGroupCode FULA = new AffiliationEthnicGroupCode(
			"Fula",
			"FULA",
			"The ethnic group of Fula people.");
	public static final AffiliationEthnicGroupCode FULANI = new AffiliationEthnicGroupCode(
			"Fulani",
			"FULANI",
			"The ethnic group of Fulani people.");
	public static final AffiliationEthnicGroupCode GAELIC = new AffiliationEthnicGroupCode(
			"Gaelic",
			"GAELIC",
			"The ethnic group of Gaelic people.");
	public static final AffiliationEthnicGroupCode GAGAUZ = new AffiliationEthnicGroupCode(
			"Gagauz",
			"GAGAUZ",
			"The ethnic group of Gagauz people.");
	public static final AffiliationEthnicGroupCode GARIFUNA = new AffiliationEthnicGroupCode(
			"Garifuna",
			"GARIFU",
			"The ethnic group of Garifuna people.");
	public static final AffiliationEthnicGroupCode GEORGIAN = new AffiliationEthnicGroupCode(
			"Georgian",
			"GEORGN",
			"The ethnic group of Georgian people.");
	public static final AffiliationEthnicGroupCode GERMANIC_BALTIC = new AffiliationEthnicGroupCode(
			"Germanic (Baltic)",
			"GERMAB",
			"The ethnic group of Germanic (Baltic) people.");
	public static final AffiliationEthnicGroupCode GERMANIC_ALPINE = new AffiliationEthnicGroupCode(
			"Germanic (Alpine)",
			"GERMAL",
			"The ethnic group of Germanic (Alpine) people.");
	public static final AffiliationEthnicGroupCode GERMAN = new AffiliationEthnicGroupCode(
			"German",
			"GERMAN",
			"The ethnic group of German people.");
	public static final AffiliationEthnicGroupCode GERMANIC_NORDIC = new AffiliationEthnicGroupCode(
			"Germanic (Nordic)",
			"GERMAR",
			"The ethnic group of Germanic (Nordic) people.");
	public static final AffiliationEthnicGroupCode GILAKI = new AffiliationEthnicGroupCode(
			"Gilaki",
			"GILAKI",
			"The ethnic group of Gilaki people.");
	public static final AffiliationEthnicGroupCode GAMBIER_ISLANDER = new AffiliationEthnicGroupCode(
			"Gambier Islander",
			"GMBISL",
			"The ethnic group of Gambier Islander people.");
	public static final AffiliationEthnicGroupCode GOULAYE = new AffiliationEthnicGroupCode(
			"Goulaye",
			"GOULAY",
			"The ethnic group of Goulaye people.");
	public static final AffiliationEthnicGroupCode GOURMANTCHE = new AffiliationEthnicGroupCode(
			"Gourmantche",
			"GOURMA",
			"The ethnic group of Gourmantche people.");
	public static final AffiliationEthnicGroupCode GREEK_INCL_GREEK_CYPRIOT = new AffiliationEthnicGroupCode(
			"Greek (incl Greek Cypriot)",
			"GREEK",
			"The ethnic group of Greek (incl Greek Cypriot) people.");
	public static final AffiliationEthnicGroupCode GREEK_ITALIANS = new AffiliationEthnicGroupCode(
			"Greek-Italians",
			"GREEKT",
			"The ethnic group of Greek-Italians people.");
	public static final AffiliationEthnicGroupCode GREENLANDER_ESKIMO = new AffiliationEthnicGroupCode(
			"Greenlander (Eskimo)",
			"GREENA",
			"The ethnic group of Greenlander (Eskimo) people.");
	public static final AffiliationEthnicGroupCode GREENLANDER_CAUCASIAN = new AffiliationEthnicGroupCode(
			"Greenlander (Caucasian)",
			"GREENC",
			"The ethnic group of Greenlander (Caucasian) people.");
	public static final AffiliationEthnicGroupCode GREENLANDER = new AffiliationEthnicGroupCode(
			"Greenlander",
			"GRNLND",
			"The ethnic group of Greenlander people.");
	public static final AffiliationEthnicGroupCode GUADALCANALIAN = new AffiliationEthnicGroupCode(
			"Guadalcanalian",
			"GUADLN",
			"The ethnic group of Guadalcanalian people.");
	public static final AffiliationEthnicGroupCode GUATEMALAN = new AffiliationEthnicGroupCode(
			"Guatemalan",
			"GUATLN",
			"The ethnic group of Guatemalan people.");
	public static final AffiliationEthnicGroupCode GUJARATI = new AffiliationEthnicGroupCode(
			"Gujarati",
			"GUJART",
			"The ethnic group of Gujarati people.");
	public static final AffiliationEthnicGroupCode GUAM_ISLANDER_CHAMORRO = new AffiliationEthnicGroupCode(
			"Guam Islander/Chamorro",
			"GUMISL",
			"The ethnic group of Guam Islander/Chamorro people.");
	public static final AffiliationEthnicGroupCode GURAGE = new AffiliationEthnicGroupCode(
			"Gurage",
			"GURAGE",
			"The ethnic group of Gurage people.");
	public static final AffiliationEthnicGroupCode GURUNGS = new AffiliationEthnicGroupCode(
			"Gurungs",
			"GURUNG",
			"The ethnic group of Gurungs people.");
	public static final AffiliationEthnicGroupCode GURUNSI = new AffiliationEthnicGroupCode(
			"Gurunsi",
			"GURUNS",
			"The ethnic group of Gurunsi people.");
	public static final AffiliationEthnicGroupCode GUYANESE = new AffiliationEthnicGroupCode(
			"Guyanese",
			"GUYANS",
			"The ethnic group of Guyanese people.");
	public static final AffiliationEthnicGroupCode GYPSY = new AffiliationEthnicGroupCode(
			"Gypsy",
			"GYPSY",
			"The ethnic group of Gypsy people.");
	public static final AffiliationEthnicGroupCode HAMITIC = new AffiliationEthnicGroupCode(
			"Hamitic",
			"HAMTC",
			"The ethnic group of Hamitic people.");
	public static final AffiliationEthnicGroupCode HAMITIC_MANGBETU_AZANDE = new AffiliationEthnicGroupCode(
			"Hamitic (Mangbetu-Azande)",
			"HAMTCM",
			"The ethnic group of Hamitic (Mangbetu-Azande) people.");
	public static final AffiliationEthnicGroupCode HAN_CHINESE = new AffiliationEthnicGroupCode(
			"Han Chinese",
			"HAN",
			"The ethnic group of Han Chinese people.");
	public static final AffiliationEthnicGroupCode HAUSA = new AffiliationEthnicGroupCode(
			"Hausa",
			"HAUSA",
			"The ethnic group of Hausa people.");
	public static final AffiliationEthnicGroupCode HAWAIIAN = new AffiliationEthnicGroupCode(
			"Hawaiian",
			"HAWIAN",
			"The ethnic group of Hawaiian people.");
	public static final AffiliationEthnicGroupCode HAZARA = new AffiliationEthnicGroupCode(
			"Hazara",
			"HAZARA",
			"The ethnic group of Hazara people.");
	public static final AffiliationEthnicGroupCode HINDUSTANI = new AffiliationEthnicGroupCode(
			"Hindustani",
			"HINDUS",
			"The ethnic group of Hindustani people.");
	public static final AffiliationEthnicGroupCode HISPANIC = new AffiliationEthnicGroupCode(
			"Hispanic",
			"HISPAN",
			"The ethnic group of Hispanic people.");
	public static final AffiliationEthnicGroupCode HONG_KONG_CHINESE = new AffiliationEthnicGroupCode(
			"Hong Kong Chinese",
			"HKCHNS",
			"The ethnic group of Hong Kong Chinese people.");
	public static final AffiliationEthnicGroupCode HMONG = new AffiliationEthnicGroupCode(
			"Hmong",
			"HMONG",
			"The ethnic group of Hmong people.");
	public static final AffiliationEthnicGroupCode HONDURAN = new AffiliationEthnicGroupCode(
			"Honduran",
			"HONDRN",
			"The ethnic group of Honduran people.");
	public static final AffiliationEthnicGroupCode HUI = new AffiliationEthnicGroupCode(
			"Hui",
			"HUI",
			"The ethnic group of Hui people.");
	public static final AffiliationEthnicGroupCode HUNGARIAN = new AffiliationEthnicGroupCode(
			"Hungarian",
			"HUNGRN",
			"The ethnic group of Hungarian people.");
	public static final AffiliationEthnicGroupCode HUTU = new AffiliationEthnicGroupCode(
			"Hutu",
			"HUTU",
			"The ethnic group of Hutu people.");
	public static final AffiliationEthnicGroupCode HUTU_BANTU = new AffiliationEthnicGroupCode(
			"Hutu (Bantu)",
			"HUTUBA",
			"The ethnic group of Hutu (Bantu) people.");
	public static final AffiliationEthnicGroupCode IBOS = new AffiliationEthnicGroupCode(
			"Ibos",
			"IBOS",
			"The ethnic group of Ibos people.");
	public static final AffiliationEthnicGroupCode ICELANDER = new AffiliationEthnicGroupCode(
			"Icelander",
			"ICLNDR",
			"The ethnic group of Icelander people.");
	public static final AffiliationEthnicGroupCode I_KIRIBATI_GILBERTESE = new AffiliationEthnicGroupCode(
			"I-Kiribati/Gilbertese",
			"IKRBAT",
			"The ethnic group of I-Kiribati/Gilbertese people.");
	public static final AffiliationEthnicGroupCode INDIGENOUS_ESKIMO = new AffiliationEthnicGroupCode(
			"Indigenous Eskimo",
			"INDIGE",
			"The ethnic group of Indigenous Eskimo people.");
	public static final AffiliationEthnicGroupCode INDIGENOUS_MELANESIAN = new AffiliationEthnicGroupCode(
			"Indigenous Melanesian",
			"INDIGM",
			"The ethnic group of Indigenous Melanesian people.");
	public static final AffiliationEthnicGroupCode INDIGENOUS_INDIAN = new AffiliationEthnicGroupCode(
			"Indigenous Indian",
			"INDIGN",
			"The ethnic group of Indigenous Indian people.");
	public static final AffiliationEthnicGroupCode INDIAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Indian not elsewhere classified",
			"INDNEC",
			"The not elsewhere classified ethnic groups of Indian people.");
	public static final AffiliationEthnicGroupCode INDIAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Indian not further defined",
			"INDNFD",
			"The not further defined ethnic groups of Indian people.");
	public static final AffiliationEthnicGroupCode INDO_ARYAN = new AffiliationEthnicGroupCode(
			"Indo-Aryan",
			"INDOAR",
			"The ethnic group of Indo-Aryan people.");
	public static final AffiliationEthnicGroupCode INDOCHINESE = new AffiliationEthnicGroupCode(
			"Indochinese",
			"INDOCH",
			"The ethnic group of Indochinese people.");
	public static final AffiliationEthnicGroupCode INDO_MAURITIAN = new AffiliationEthnicGroupCode(
			"Indo-Mauritian",
			"INDOMA",
			"The ethnic group of Indo-Mauritian people.");
	public static final AffiliationEthnicGroupCode INDONESIAN_INCL_JAVANESE_SUNDANESE_SUMATRAN = new AffiliationEthnicGroupCode(
			"Indonesian (incl Javanese/Sundanese/Sumatran)",
			"INDOSN",
			"The ethnic group of Indonesian (incl Javanese/Sundanese/Sumatran) people.");
	public static final AffiliationEthnicGroupCode INUIT_ESKIMO = new AffiliationEthnicGroupCode(
			"Inuit/Eskimo",
			"INUIT",
			"The ethnic group of Inuit/Eskimo people.");
	public static final AffiliationEthnicGroupCode IRAQI = new AffiliationEthnicGroupCode(
			"Iraqi",
			"IRAQI",
			"The ethnic group of Iraqi people.");
	public static final AffiliationEthnicGroupCode IRISH = new AffiliationEthnicGroupCode(
			"Irish",
			"IRISH",
			"The ethnic group of Irish people.");
	public static final AffiliationEthnicGroupCode IRANIAN_PERSIAN = new AffiliationEthnicGroupCode(
			"Iranian/Persian",
			"IRNPER",
			"The ethnic group of Iranian/Persian people.");
	public static final AffiliationEthnicGroupCode ISRAELI_JEWISH_HEBREW = new AffiliationEthnicGroupCode(
			"Israeli/Jewish/Hebrew",
			"ISRJEW",
			"The ethnic group of Israeli/Jewish/Hebrew people.");
	public static final AffiliationEthnicGroupCode ITALIAN = new AffiliationEthnicGroupCode(
			"Italian",
			"ITALAN",
			"The ethnic group of Italian people.");
	public static final AffiliationEthnicGroupCode ITALIAN_FRENCH = new AffiliationEthnicGroupCode(
			"Italian-French",
			"ITALFR",
			"The ethnic group of Italian-French people.");
	public static final AffiliationEthnicGroupCode ITALIAN_GERMAN = new AffiliationEthnicGroupCode(
			"Italian-German",
			"ITALGE",
			"The ethnic group of Italian-German people.");
	public static final AffiliationEthnicGroupCode ITALIAN_SLOVENE = new AffiliationEthnicGroupCode(
			"Italian-Slovene",
			"ITALSL",
			"The ethnic group of Italian-Slovene people.");
	public static final AffiliationEthnicGroupCode JAMAICAN = new AffiliationEthnicGroupCode(
			"Jamaican",
			"JAMACN",
			"The ethnic group of Jamaican people.");
	public static final AffiliationEthnicGroupCode JAPANESE = new AffiliationEthnicGroupCode(
			"Japanese",
			"JAPNES",
			"The ethnic group of Japanese people.");
	public static final AffiliationEthnicGroupCode JAVANESE = new AffiliationEthnicGroupCode(
			"Javanese",
			"JAVANE",
			"The ethnic group of Javanese people.");
	public static final AffiliationEthnicGroupCode JEWISH = new AffiliationEthnicGroupCode(
			"Jewish",
			"JEWISH",
			"The ethnic group of Jewish people.");
	public static final AffiliationEthnicGroupCode JORDANIAN = new AffiliationEthnicGroupCode(
			"Jordanian",
			"JORDNN",
			"The ethnic group of Jordanian people.");
	public static final AffiliationEthnicGroupCode KABYE = new AffiliationEthnicGroupCode(
			"Kabye",
			"KABYE",
			"The ethnic group of Kabye people.");
	public static final AffiliationEthnicGroupCode KALANGA = new AffiliationEthnicGroupCode(
			"Kalanga",
			"KALANG",
			"The ethnic group of Kalanga people.");
	public static final AffiliationEthnicGroupCode KALENJIN = new AffiliationEthnicGroupCode(
			"Kalenjin",
			"KALENJ",
			"The ethnic group of Kalenjin people.");
	public static final AffiliationEthnicGroupCode KAMBA = new AffiliationEthnicGroupCode(
			"Kamba",
			"KAMBA",
			"The ethnic group of Kamba people.");
	public static final AffiliationEthnicGroupCode KAMPUCHEAN_CHINESE = new AffiliationEthnicGroupCode(
			"Kampuchean Chinese",
			"KAMCHN",
			"The ethnic group of Kampuchean Chinese people.");
	public static final AffiliationEthnicGroupCode KANAKA_KANAK = new AffiliationEthnicGroupCode(
			"Kanaka/Kanak",
			"KANAKA",
			"The ethnic group of Kanaka/Kanak people.");
	public static final AffiliationEthnicGroupCode KARAKALPAKS = new AffiliationEthnicGroupCode(
			"Karakalpaks",
			"KARAKA",
			"The ethnic group of Karakalpaks people.");
	public static final AffiliationEthnicGroupCode KAREN = new AffiliationEthnicGroupCode(
			"Karen",
			"KAREN",
			"The ethnic group of Karen people.");
	public static final AffiliationEthnicGroupCode KAZAKH = new AffiliationEthnicGroupCode(
			"Kazakh",
			"KAZAKH",
			"The ethnic group of Kazakh people.");
	public static final AffiliationEthnicGroupCode KAZAKH_QAZAQ = new AffiliationEthnicGroupCode(
			"Kazakh (Qazaq)",
			"KAZAKQ",
			"The ethnic group of Kazakh (Qazaq) people.");
	public static final AffiliationEthnicGroupCode KENYAN = new AffiliationEthnicGroupCode(
			"Kenyan",
			"KENYAN",
			"The ethnic group of Kenyan people.");
	public static final AffiliationEthnicGroupCode KGALAGADI = new AffiliationEthnicGroupCode(
			"Kgalagadi",
			"KGALAG",
			"The ethnic group of Kgalagadi people.");
	public static final AffiliationEthnicGroupCode KHMER_KAMPUCHEAN_CAMBODIAN = new AffiliationEthnicGroupCode(
			"Khmer/Kampuchean/Cambodian",
			"KHMER",
			"The ethnic group of Khmer/Kampuchean/Cambodian people.");
	public static final AffiliationEthnicGroupCode KIKUYU = new AffiliationEthnicGroupCode(
			"Kikuyu",
			"KIKUYU",
			"The ethnic group of Kikuyu people.");
	public static final AffiliationEthnicGroupCode KIMBUNDU = new AffiliationEthnicGroupCode(
			"Kimbundu",
			"KIMBUN",
			"The ethnic group of Kimbundu people.");
	public static final AffiliationEthnicGroupCode KIRDI = new AffiliationEthnicGroupCode(
			"Kirdi",
			"KIRDI",
			"The ethnic group of Kirdi people.");
	public static final AffiliationEthnicGroupCode KIRGHIZ = new AffiliationEthnicGroupCode(
			"Kirghiz",
			"KIRGHZ",
			"The ethnic group of Kirghiz people.");
	public static final AffiliationEthnicGroupCode KISII = new AffiliationEthnicGroupCode(
			"Kisii",
			"KISII",
			"The ethnic group of Kisii people.");
	public static final AffiliationEthnicGroupCode KONGO = new AffiliationEthnicGroupCode(
			"Kongo",
			"KONGO",
			"The ethnic group of Kongo people.");
	public static final AffiliationEthnicGroupCode KOREAN = new AffiliationEthnicGroupCode(
			"Korean",
			"KOREAN",
			"The ethnic group of Korean people.");
	public static final AffiliationEthnicGroupCode KUNAMA = new AffiliationEthnicGroupCode(
			"Kunama",
			"KUNAMA",
			"The ethnic group of Kunama people.");
	public static final AffiliationEthnicGroupCode KURD = new AffiliationEthnicGroupCode(
			"Kurd",
			"KURD",
			"The ethnic group of Kurd people.");
	public static final AffiliationEthnicGroupCode KUWAITI = new AffiliationEthnicGroupCode(
			"Kuwaiti",
			"KUWAIT",
			"The ethnic group of Kuwaiti people.");
	public static final AffiliationEthnicGroupCode LADINO_INDIAN_EUROPEAN = new AffiliationEthnicGroupCode(
			"Ladino (Indian/European)",
			"LADINO",
			"The ethnic group of Ladino (Indian/European) people.");
	public static final AffiliationEthnicGroupCode LAO_LAOTIAN = new AffiliationEthnicGroupCode(
			"Lao/Laotian",
			"LAOTAN",
			"The ethnic group of Lao/Laotian people.");
	public static final AffiliationEthnicGroupCode LAPP = new AffiliationEthnicGroupCode(
			"Lapp",
			"LAPP",
			"The ethnic group of Lapp people.");
	public static final AffiliationEthnicGroupCode LATIN = new AffiliationEthnicGroupCode(
			"Latin",
			"LATIN",
			"The ethnic group of Latin people.");
	public static final AffiliationEthnicGroupCode LATIN_AMERICAN_HISPANIC_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Latin American/Hispanic not elsewhere classified",
			"LATNEC",
			"The not elsewhere classified ethnic groups of Latin American/Hispanic people.");
	public static final AffiliationEthnicGroupCode LATIN_AMERICAN_HISPANIC_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Latin American/Hispanic not further defined",
			"LATNFD",
			"The not further defined ethnic groups of Latin American/Hispanic people.");
	public static final AffiliationEthnicGroupCode LATVIAN = new AffiliationEthnicGroupCode(
			"Latvian",
			"LATVAN",
			"The ethnic group of Latvian people.");
	public static final AffiliationEthnicGroupCode LEBANESE = new AffiliationEthnicGroupCode(
			"Lebanese",
			"LEBNSE",
			"The ethnic group of Lebanese people.");
	public static final AffiliationEthnicGroupCode LIBYAN = new AffiliationEthnicGroupCode(
			"Libyan",
			"LIBYAN",
			"The ethnic group of Libyan people.");
	public static final AffiliationEthnicGroupCode LIMBUS = new AffiliationEthnicGroupCode(
			"Limbus",
			"LIMBUS",
			"The ethnic group of Limbus people.");
	public static final AffiliationEthnicGroupCode LITHUANIAN = new AffiliationEthnicGroupCode(
			"Lithuanian",
			"LITHUN",
			"The ethnic group of Lithuanian people.");
	public static final AffiliationEthnicGroupCode LOBI = new AffiliationEthnicGroupCode(
			"Lobi",
			"LOBI",
			"The ethnic group of Lobi people.");
	public static final AffiliationEthnicGroupCode LOMWE = new AffiliationEthnicGroupCode(
			"Lomwe",
			"LOMWE",
			"The ethnic group of Lomwe people.");
	public static final AffiliationEthnicGroupCode LUHYA = new AffiliationEthnicGroupCode(
			"Luhya",
			"LUHYA",
			"The ethnic group of Luhya people.");
	public static final AffiliationEthnicGroupCode LUO = new AffiliationEthnicGroupCode(
			"Luo",
			"LUO",
			"The ethnic group of Luo people.");
	public static final AffiliationEthnicGroupCode LUR = new AffiliationEthnicGroupCode(
			"Lur",
			"LUR",
			"The ethnic group of Lur people.");
	public static final AffiliationEthnicGroupCode MACEDONIAN = new AffiliationEthnicGroupCode(
			"Macedonian",
			"MACDNN",
			"The ethnic group of Macedonian people.");
	public static final AffiliationEthnicGroupCode MADURESE = new AffiliationEthnicGroupCode(
			"Madurese",
			"MADURE",
			"The ethnic group of Madurese people.");
	public static final AffiliationEthnicGroupCode MAGARS = new AffiliationEthnicGroupCode(
			"Magars",
			"MAGARS",
			"The ethnic group of Magars people.");
	public static final AffiliationEthnicGroupCode MAKOA = new AffiliationEthnicGroupCode(
			"Makoa",
			"MAKOA",
			"The ethnic group of Makoa people.");
	public static final AffiliationEthnicGroupCode MALAGASY = new AffiliationEthnicGroupCode(
			"Malagasy",
			"MALAGA",
			"The ethnic group of Malagasy people.");
	public static final AffiliationEthnicGroupCode MALAITIAN = new AffiliationEthnicGroupCode(
			"Malaitian",
			"MALATN",
			"The ethnic group of Malaitian people.");
	public static final AffiliationEthnicGroupCode MALAY_MALAYAN = new AffiliationEthnicGroupCode(
			"Malay/Malayan",
			"MALAY",
			"The ethnic group of Malay/Malayan people.");
	public static final AffiliationEthnicGroupCode MALAYA_INDONESIAN_BETWILEO = new AffiliationEthnicGroupCode(
			"Malaya-Indonesian (Betwileo)",
			"MALAYA",
			"The ethnic group of Malaya-Indonesian (Betwileo) people.");
	public static final AffiliationEthnicGroupCode MALAYO_INDONESIAN = new AffiliationEthnicGroupCode(
			"Malayo-Indonesian",
			"MALAYI",
			"The ethnic group of Malayo-Indonesian people.");
	public static final AffiliationEthnicGroupCode MALAYO_INDONESIAN_MERINA = new AffiliationEthnicGroupCode(
			"Malayo-Indonesian (Merina)",
			"MALAYM",
			"The ethnic group of Malayo-Indonesian (Merina) people.");
	public static final AffiliationEthnicGroupCode MALAYSIAN_CHINESE = new AffiliationEthnicGroupCode(
			"Malaysian Chinese",
			"MALCHN",
			"The ethnic group of Malaysian Chinese people.");
	public static final AffiliationEthnicGroupCode MALINKE = new AffiliationEthnicGroupCode(
			"Malinke",
			"MALINK",
			"The ethnic group of Malinke people.");
	public static final AffiliationEthnicGroupCode MALTESE = new AffiliationEthnicGroupCode(
			"Maltese",
			"MALTSE",
			"The ethnic group of Maltese people.");
	public static final AffiliationEthnicGroupCode MALVINIAN_SPANISH_SPEAKING_FALKLAND_ISLANDER = new AffiliationEthnicGroupCode(
			"Malvinian (Spanish-speaking Falkland Islander)",
			"MALVAN",
			"The ethnic group of Malvinian (Spanish-speaking Falkland Islander) people.");
	public static final AffiliationEthnicGroupCode MAN = new AffiliationEthnicGroupCode(
			"Man",
			"MAN",
			"The ethnic group of Man people.");
	public static final AffiliationEthnicGroupCode MANCHU = new AffiliationEthnicGroupCode(
			"Manchu",
			"MANCHU",
			"The ethnic group of Manchu people.");
	public static final AffiliationEthnicGroupCode MANDE = new AffiliationEthnicGroupCode(
			"Mande",
			"MANDE",
			"The ethnic group of Mande people.");
	public static final AffiliationEthnicGroupCode MANDE_BAMBARA = new AffiliationEthnicGroupCode(
			"Mande (Bambara)",
			"MANDEB",
			"The ethnic group of Mande (Bambara) people.");
	public static final AffiliationEthnicGroupCode MANDE_MALINKE = new AffiliationEthnicGroupCode(
			"Mande (Malinke)",
			"MANDEM",
			"The ethnic group of Mande (Malinke) people.");
	public static final AffiliationEthnicGroupCode MANDE_SARAKOLE = new AffiliationEthnicGroupCode(
			"Mande (Sarakole)",
			"MANDES",
			"The ethnic group of Mande (Sarakole) people.");
	public static final AffiliationEthnicGroupCode MANDJIA = new AffiliationEthnicGroupCode(
			"Mandjia",
			"MANDJI",
			"The ethnic group of Mandjia people.");
	public static final AffiliationEthnicGroupCode MANDINGO = new AffiliationEthnicGroupCode(
			"Mandingo",
			"MANDNG",
			"The ethnic group of Mandingo people.");
	public static final AffiliationEthnicGroupCode MANGAIA_ISLANDER = new AffiliationEthnicGroupCode(
			"Mangaia Islander",
			"MANGIS",
			"The ethnic group of Mangaia Islander people.");
	public static final AffiliationEthnicGroupCode MANIHIKI_ISLANDER = new AffiliationEthnicGroupCode(
			"Manihiki Islander",
			"MANHIS",
			"The ethnic group of Manihiki Islander people.");
	public static final AffiliationEthnicGroupCode MANUS_ISLANDER = new AffiliationEthnicGroupCode(
			"Manus Islander",
			"MANUIS",
			"The ethnic group of Manus Islander people.");
	public static final AffiliationEthnicGroupCode MANX = new AffiliationEthnicGroupCode(
			"Manx",
			"MANX",
			"The ethnic group of Manx people.");
	public static final AffiliationEthnicGroupCode MAORI = new AffiliationEthnicGroupCode(
			"Maori",
			"MAORI",
			"The ethnic group of Maori people.");
	public static final AffiliationEthnicGroupCode MARIANAS_ISLANDER = new AffiliationEthnicGroupCode(
			"Marianas Islander",
			"MARISL",
			"The ethnic group of Marianas Islander people.");
	public static final AffiliationEthnicGroupCode MARQUESAS_ISLANDER = new AffiliationEthnicGroupCode(
			"Marquesas Islander",
			"MARQIS",
			"The ethnic group of Marquesas Islander people.");
	public static final AffiliationEthnicGroupCode MARSHALL_ISLANDER = new AffiliationEthnicGroupCode(
			"Marshall Islander",
			"MARSIS",
			"The ethnic group of Marshall Islander people.");
	public static final AffiliationEthnicGroupCode MASSA = new AffiliationEthnicGroupCode(
			"Massa",
			"MASSA",
			"The ethnic group of Massa people.");
	public static final AffiliationEthnicGroupCode MAUKE_ISLANDER = new AffiliationEthnicGroupCode(
			"Mauke Islander",
			"MAUKIS",
			"The ethnic group of Mauke Islander people.");
	public static final AffiliationEthnicGroupCode MAUR = new AffiliationEthnicGroupCode(
			"Maur",
			"MAUR",
			"The ethnic group of Maur people.");
	public static final AffiliationEthnicGroupCode MAURITIAN = new AffiliationEthnicGroupCode(
			"Mauritian",
			"MAURTN",
			"The ethnic group of Mauritian people.");
	public static final AffiliationEthnicGroupCode MAYA = new AffiliationEthnicGroupCode(
			"Maya",
			"MAYA",
			"The ethnic group of Maya people.");
	public static final AffiliationEthnicGroupCode MAZANDARANI = new AffiliationEthnicGroupCode(
			"Mazandarani",
			"MAZAND",
			"The ethnic group of Mazandarani people.");
	public static final AffiliationEthnicGroupCode MBAKA = new AffiliationEthnicGroupCode(
			"Mbaka",
			"MBAKA",
			"The ethnic group of Mbaka people.");
	public static final AffiliationEthnicGroupCode MBAYE = new AffiliationEthnicGroupCode(
			"Mbaye",
			"MBAYE",
			"The ethnic group of Mbaye people.");
	public static final AffiliationEthnicGroupCode MBOCHI = new AffiliationEthnicGroupCode(
			"Mbochi",
			"MBOCHI",
			"The ethnic group of Mbochi people.");
	public static final AffiliationEthnicGroupCode MBOUM = new AffiliationEthnicGroupCode(
			"Mboum",
			"MBOUM",
			"The ethnic group of Mboum people.");
	public static final AffiliationEthnicGroupCode MIDDLE_EASTERN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Middle Eastern not elsewhere classified",
			"MDENEC",
			"The not elsewhere classified ethnic groups of Middle Eastern people.");
	public static final AffiliationEthnicGroupCode MIDDLE_EASTERN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Middle Eastern not further defined",
			"MDENFD",
			"The not further defined ethnic groups of Middle Eastern people.");
	public static final AffiliationEthnicGroupCode MELANESIAN = new AffiliationEthnicGroupCode(
			"Melanesian",
			"MELANE",
			"The ethnic group of Melanesian people.");
	public static final AffiliationEthnicGroupCode MEO = new AffiliationEthnicGroupCode(
			"Meo",
			"MEO",
			"The ethnic group of Meo people.");
	public static final AffiliationEthnicGroupCode MERU = new AffiliationEthnicGroupCode(
			"Meru",
			"MERU",
			"The ethnic group of Meru people.");
	public static final AffiliationEthnicGroupCode MESTIZO_INDIAN_AND_EUROPEAN = new AffiliationEthnicGroupCode(
			"Mestizo (Indian and European)",
			"MESTZE",
			"The ethnic group of Mestizo (Indian and European) people.");
	public static final AffiliationEthnicGroupCode MESTIZO_INDIAN_AND_SPANISH = new AffiliationEthnicGroupCode(
			"Mestizo (Indian and Spanish)",
			"MESTZS",
			"The ethnic group of Mestizo (Indian and Spanish) people.");
	public static final AffiliationEthnicGroupCode MEXICAN = new AffiliationEthnicGroupCode(
			"Mexican",
			"MEXCAN",
			"The ethnic group of Mexican people.");
	public static final AffiliationEthnicGroupCode MIAO = new AffiliationEthnicGroupCode(
			"Miao",
			"MIAO",
			"The ethnic group of Miao people.");
	public static final AffiliationEthnicGroupCode MICRONESIAN = new AffiliationEthnicGroupCode(
			"Micronesian",
			"MICRON",
			"The ethnic group of Micronesian people.");
	public static final AffiliationEthnicGroupCode MINA = new AffiliationEthnicGroupCode(
			"Mina",
			"MINA",
			"The ethnic group of Mina people.");
	public static final AffiliationEthnicGroupCode MITIARO_ISLANDER = new AffiliationEthnicGroupCode(
			"Mitiaro Islander",
			"MITISL",
			"The ethnic group of Mitiaro Islander people.");
	public static final AffiliationEthnicGroupCode MIXED = new AffiliationEthnicGroupCode(
			"Mixed",
			"MIXED",
			"The ethnic group of Mixed people.");
	public static final AffiliationEthnicGroupCode MOLDOVAN = new AffiliationEthnicGroupCode(
			"Moldovan",
			"MOLDOV",
			"The ethnic group of Moldovan people.");
	public static final AffiliationEthnicGroupCode MON = new AffiliationEthnicGroupCode(
			"Mon",
			"MON",
			"The ethnic group of Mon people.");
	public static final AffiliationEthnicGroupCode MONEGASQUE = new AffiliationEthnicGroupCode(
			"Monegasque",
			"MONEGA",
			"The ethnic group of Monegasque people.");
	public static final AffiliationEthnicGroupCode MONGOL = new AffiliationEthnicGroupCode(
			"Mongol",
			"MONGOL",
			"The ethnic group of Mongol people.");
	public static final AffiliationEthnicGroupCode MONTENEGRINS = new AffiliationEthnicGroupCode(
			"Montenegrins",
			"MONTEN",
			"The ethnic group of Montenegrins people.");
	public static final AffiliationEthnicGroupCode MOOR = new AffiliationEthnicGroupCode(
			"Moor",
			"MOOR",
			"The ethnic group of Moor people.");
	public static final AffiliationEthnicGroupCode MORAVIAN = new AffiliationEthnicGroupCode(
			"Moravian",
			"MORAVI",
			"The ethnic group of Moravian people.");
	public static final AffiliationEthnicGroupCode MOROCCAN = new AffiliationEthnicGroupCode(
			"Moroccan",
			"MOROCN",
			"The ethnic group of Moroccan people.");
	public static final AffiliationEthnicGroupCode MOSSI = new AffiliationEthnicGroupCode(
			"Mossi",
			"MOSSI",
			"The ethnic group of Mossi people.");
	public static final AffiliationEthnicGroupCode MOUNDANG = new AffiliationEthnicGroupCode(
			"Moundang",
			"MOUND",
			"The ethnic group of Moundang people.");
	public static final AffiliationEthnicGroupCode MOUSSEI = new AffiliationEthnicGroupCode(
			"Moussei",
			"MOUSSE",
			"The ethnic group of Moussei people.");
	public static final AffiliationEthnicGroupCode MUHAJIR = new AffiliationEthnicGroupCode(
			"Muhajir",
			"MUHAJR",
			"The ethnic group of Muhajir people.");
	public static final AffiliationEthnicGroupCode MULATTO = new AffiliationEthnicGroupCode(
			"Mulatto",
			"MULATT",
			"The ethnic group of Mulatto people.");
	public static final AffiliationEthnicGroupCode MUONG = new AffiliationEthnicGroupCode(
			"Muong",
			"MUONG",
			"The ethnic group of Muong people.");
	public static final AffiliationEthnicGroupCode MUSLIM_BOULALA = new AffiliationEthnicGroupCode(
			"Muslim (Boulala)",
			"MUSIMO",
			"The ethnic group of Muslim (Boulala) people.");
	public static final AffiliationEthnicGroupCode MUSLIM = new AffiliationEthnicGroupCode(
			"Muslim",
			"MUSLIM",
			"The ethnic group of Muslim people.");
	public static final AffiliationEthnicGroupCode MUSLIM_ARAB = new AffiliationEthnicGroupCode(
			"Muslim (Arab)",
			"MUSLMA",
			"The ethnic group of Muslim (Arab) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_BAGUIRMI = new AffiliationEthnicGroupCode(
			"Muslim (Baguirmi)",
			"MUSLMB",
			"The ethnic group of Muslim (Baguirmi) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_FULBE = new AffiliationEthnicGroupCode(
			"Muslim (Fulbe)",
			"MUSLMF",
			"The ethnic group of Muslim (Fulbe) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_HADJERAI = new AffiliationEthnicGroupCode(
			"Muslim (Hadjerai)",
			"MUSLMH",
			"The ethnic group of Muslim (Hadjerai) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_KANEMBOU = new AffiliationEthnicGroupCode(
			"Muslim (Kanembou)",
			"MUSLMK",
			"The ethnic group of Muslim (Kanembou) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_MABA = new AffiliationEthnicGroupCode(
			"Muslim (Maba)",
			"MUSLMM",
			"The ethnic group of Muslim (Maba) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_KOTOKO = new AffiliationEthnicGroupCode(
			"Muslim (Kotoko)",
			"MUSLMT",
			"The ethnic group of Muslim (Kotoko) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_TOUBOU = new AffiliationEthnicGroupCode(
			"Muslim (Toubou)",
			"MUSLMU",
			"The ethnic group of Muslim (Toubou) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_MALAY = new AffiliationEthnicGroupCode(
			"Muslim (Malay)",
			"MUSLMY",
			"The ethnic group of Muslim (Malay) people.");
	public static final AffiliationEthnicGroupCode MUSLIM_ZAGHAWA = new AffiliationEthnicGroupCode(
			"Muslim (Zaghawa)",
			"MUSLMZ",
			"The ethnic group of Muslim (Zaghawa) people.");
	public static final AffiliationEthnicGroupCode NORTH_AMERICAN_INDIAN = new AffiliationEthnicGroupCode(
			"North American Indian",
			"NAINDN",
			"The ethnic group of North American Indian people.");
	public static final AffiliationEthnicGroupCode NATIVE_AFRICAN = new AffiliationEthnicGroupCode(
			"Native African",
			"NATVEF",
			"The ethnic group of Native African people.");
	public static final AffiliationEthnicGroupCode NATIVE_AMERICAN = new AffiliationEthnicGroupCode(
			"Native American",
			"NATVEM",
			"The ethnic group of Native American people.");
	public static final AffiliationEthnicGroupCode NAURU_ISLANDER = new AffiliationEthnicGroupCode(
			"Nauru Islander",
			"NAUISL",
			"The ethnic group of Nauru Islander people.");
	public static final AffiliationEthnicGroupCode NEGRITO = new AffiliationEthnicGroupCode(
			"Negrito",
			"NEGRIT",
			"The ethnic group of Negrito people.");
	public static final AffiliationEthnicGroupCode NEPALESE = new AffiliationEthnicGroupCode(
			"Nepalese",
			"NEPLSE",
			"The ethnic group of Nepalese people.");
	public static final AffiliationEthnicGroupCode NEWARS = new AffiliationEthnicGroupCode(
			"Newars",
			"NEWARS",
			"The ethnic group of Newars people.");
	public static final AffiliationEthnicGroupCode NEW_BRITAIN_ISLANDER = new AffiliationEthnicGroupCode(
			"New Britain Islander",
			"NEWBRT",
			"The ethnic group of New Britain Islander people.");
	public static final AffiliationEthnicGroupCode NEW_CALEDONIAN = new AffiliationEthnicGroupCode(
			"New Caledonian",
			"NEWCAL",
			"The ethnic group of New Caledonian people.");
	public static final AffiliationEthnicGroupCode NEW_GEORGIAN = new AffiliationEthnicGroupCode(
			"New Georgian",
			"NEWGER",
			"The ethnic group of New Georgian people.");
	public static final AffiliationEthnicGroupCode NEW_IRELANDER = new AffiliationEthnicGroupCode(
			"New Irelander",
			"NEWIRL",
			"The ethnic group of New Irelander people.");
	public static final AffiliationEthnicGroupCode NEW_ZEALANDER = new AffiliationEthnicGroupCode(
			"New Zealander",
			"NEWZEA",
			"The ethnic group of New Zealander people.");
	public static final AffiliationEthnicGroupCode NEW_ZEALAND_EUROPEAN_PAKEHA = new AffiliationEthnicGroupCode(
			"New Zealand European/Pakeha",
			"NEWZLE",
			"The ethnic group of New Zealand European/Pakeha people.");
	public static final AffiliationEthnicGroupCode NEW_ZEALAND_MAORI = new AffiliationEthnicGroupCode(
			"New Zealand Maori",
			"NEWZLM",
			"The ethnic group of New Zealand Maori people.");
	public static final AffiliationEthnicGroupCode NGAMBYE = new AffiliationEthnicGroupCode(
			"Ngambye",
			"NGAMBY",
			"The ethnic group of Ngambye people.");
	public static final AffiliationEthnicGroupCode NGONDE = new AffiliationEthnicGroupCode(
			"Ngonde",
			"NGONDE",
			"The ethnic group of Ngonde people.");
	public static final AffiliationEthnicGroupCode NGONI = new AffiliationEthnicGroupCode(
			"Ngoni",
			"NGONI",
			"The ethnic group of Ngoni people.");
	public static final AffiliationEthnicGroupCode NICARAGUAN = new AffiliationEthnicGroupCode(
			"Nicaraguan",
			"NICRGN",
			"The ethnic group of Nicaraguan people.");
	public static final AffiliationEthnicGroupCode NIGERIAN = new AffiliationEthnicGroupCode(
			"Nigerian",
			"NIGRAN",
			"The ethnic group of Nigerian people.");
	public static final AffiliationEthnicGroupCode NIUEAN = new AffiliationEthnicGroupCode(
			"Niuean",
			"NIUEAN",
			"The ethnic group of Niuean people.");
	public static final AffiliationEthnicGroupCode NOT_KNOWN = new AffiliationEthnicGroupCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AffiliationEthnicGroupCode NORDIC = new AffiliationEthnicGroupCode(
			"Nordic",
			"NORDIC",
			"The ethnic group of Nordic people.");
	public static final AffiliationEthnicGroupCode NORMAN = new AffiliationEthnicGroupCode(
			"Norman",
			"NORMAN",
			"The ethnic group of Norman people.");
	public static final AffiliationEthnicGroupCode NORMAN_FRENCH = new AffiliationEthnicGroupCode(
			"Norman-French",
			"NORMFR",
			"The ethnic group of Norman-French people.");
	public static final AffiliationEthnicGroupCode NORTH_AFRICAN = new AffiliationEthnicGroupCode(
			"North African",
			"NORTAF",
			"The ethnic group of North African people.");
	public static final AffiliationEthnicGroupCode NORWEGIAN = new AffiliationEthnicGroupCode(
			"Norwegian",
			"NORWGN",
			"The ethnic group of Norwegian people.");
	public static final AffiliationEthnicGroupCode NOT_OTHERWISE_SPECIFIED = new AffiliationEthnicGroupCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AffiliationEthnicGroupCode NYANJA = new AffiliationEthnicGroupCode(
			"Nyanja",
			"NYANJA",
			"The ethnic group of Nyanja people.");
	public static final AffiliationEthnicGroupCode OTHER_AFRICAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Other African not elsewhere classified",
			"OAFNEC",
			"The ethnic group of Other African not elsewhere classified people.");
	public static final AffiliationEthnicGroupCode OTHER_ASIAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Other Asian not elsewhere classified",
			"OASNEC",
			"The ethnic group of Other Asian not elsewhere classified people.");
	public static final AffiliationEthnicGroupCode OCEAN_ISLANDER_BANABAN = new AffiliationEthnicGroupCode(
			"Ocean Islander/Banaban",
			"OCNISL",
			"The ethnic group of Ocean Islander/Banaban people.");
	public static final AffiliationEthnicGroupCode OTHER_EUROPEAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Other European not further defined",
			"OEUNFD",
			"The ethnic group of Other European not further defined people.");
	public static final AffiliationEthnicGroupCode OIMATSAHA = new AffiliationEthnicGroupCode(
			"Oimatsaha",
			"OIMATS",
			"The ethnic group of Oimatsaha people.");
	public static final AffiliationEthnicGroupCode OMANI = new AffiliationEthnicGroupCode(
			"Omani",
			"OMANI",
			"The ethnic group of Omani people.");
	public static final AffiliationEthnicGroupCode OTHER_PACIFIC_ISLAND_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Other Pacific Island not elsewhere classified",
			"OPANEC",
			"The ethnic group of Other Pacific Island not elsewhere classified people.");
	public static final AffiliationEthnicGroupCode OTHER_PACIFIC_ISLAND_GROUPS_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Other Pacific Island Groups not further defined",
			"OPANFD",
			"The ethnic group of Other Pacific Island Groups not further defined people.");
	public static final AffiliationEthnicGroupCode ORIENTAL = new AffiliationEthnicGroupCode(
			"Oriental",
			"ORIENT",
			"The ethnic group of Oriental people.");
	public static final AffiliationEthnicGroupCode ORKNEY_ISLANDER = new AffiliationEthnicGroupCode(
			"Orkney Islander",
			"ORKISL",
			"The ethnic group of Orkney Islander people.");
	public static final AffiliationEthnicGroupCode OROMO = new AffiliationEthnicGroupCode(
			"Oromo",
			"OROMO",
			"The ethnic group of Oromo people.");
	public static final AffiliationEthnicGroupCode OTHER_SOUTHEAST_ASIAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Other Southeast Asian not elsewhere classified",
			"OSANEC",
			"The ethnic group of Other Southeast Asian not elsewhere classified people.");
	public static final AffiliationEthnicGroupCode OSSETIAN = new AffiliationEthnicGroupCode(
			"Ossetian",
			"OSSET",
			"The ethnic group of Ossetian people.");
	public static final AffiliationEthnicGroupCode OVIMBUNDU = new AffiliationEthnicGroupCode(
			"Ovimbundu",
			"OVIMBU",
			"The ethnic group of Ovimbundu people.");
	public static final AffiliationEthnicGroupCode PACIFIC_ISLAND_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Pacific Island not further defined",
			"PACNFD",
			"The not further defined ethnic groups of Pacific Island people.");
	public static final AffiliationEthnicGroupCode PAKISTANI = new AffiliationEthnicGroupCode(
			"Pakistani",
			"PAKSTN",
			"The ethnic group of Pakistani people.");
	public static final AffiliationEthnicGroupCode PALAUANS = new AffiliationEthnicGroupCode(
			"Palauans",
			"PALAUA",
			"The ethnic group of Palauans people.");
	public static final AffiliationEthnicGroupCode PALMERSTON_ISLANDER = new AffiliationEthnicGroupCode(
			"Palmerston Islander",
			"PALMIS",
			"The ethnic group of Palmerston Islander people.");
	public static final AffiliationEthnicGroupCode PALESTINIAN = new AffiliationEthnicGroupCode(
			"Palestinian",
			"PALSTN",
			"The ethnic group of Palestinian people.");
	public static final AffiliationEthnicGroupCode PANAMANIAN = new AffiliationEthnicGroupCode(
			"Panamanian",
			"PANMAN",
			"The ethnic group of Panamanian people.");
	public static final AffiliationEthnicGroupCode PAPUAN_NEW_GUINEAN_IRIAN_JAYAN = new AffiliationEthnicGroupCode(
			"Papuan/New Guinean/Irian Jayan",
			"PAPUAN",
			"The ethnic group of Papuan/New Guinean/Irian Jayan people.");
	public static final AffiliationEthnicGroupCode PARAGUAYAN = new AffiliationEthnicGroupCode(
			"Paraguayan",
			"PARGYN",
			"The ethnic group of Paraguayan people.");
	public static final AffiliationEthnicGroupCode PASHTUN_PATHAN = new AffiliationEthnicGroupCode(
			"Pashtun (Pathan)",
			"PASHTP",
			"The ethnic group of Pashtun (Pathan) people.");
	public static final AffiliationEthnicGroupCode PASHTUN = new AffiliationEthnicGroupCode(
			"Pashtun",
			"PASHTU",
			"The ethnic group of Pashtun people.");
	public static final AffiliationEthnicGroupCode PENRHYN_ISLANDER = new AffiliationEthnicGroupCode(
			"Penrhyn Islander",
			"PENISL",
			"The ethnic group of Penrhyn Islander people.");
	public static final AffiliationEthnicGroupCode PERSIAN = new AffiliationEthnicGroupCode(
			"Persian",
			"PERSAN",
			"The ethnic group of Persian people.");
	public static final AffiliationEthnicGroupCode PERUVIAN = new AffiliationEthnicGroupCode(
			"Peruvian",
			"PERUVN",
			"The ethnic group of Peruvian people.");
	public static final AffiliationEthnicGroupCode PEUL = new AffiliationEthnicGroupCode(
			"Peul",
			"PEUL",
			"The ethnic group of Peul people.");
	public static final AffiliationEthnicGroupCode PHOENIX_ISLANDER = new AffiliationEthnicGroupCode(
			"Phoenix Islander",
			"PHNISL",
			"The ethnic group of Phoenix Islander people.");
	public static final AffiliationEthnicGroupCode PHOUTHEUNG_KYA = new AffiliationEthnicGroupCode(
			"Phoutheung (Kya)",
			"PHOUTH",
			"The ethnic group of Phoutheung (Kya) people.");
	public static final AffiliationEthnicGroupCode PITCAIRN_ISLANDER = new AffiliationEthnicGroupCode(
			"Pitcairn Islander",
			"PITISL",
			"The ethnic group of Pitcairn Islander people.");
	public static final AffiliationEthnicGroupCode POLISH = new AffiliationEthnicGroupCode(
			"Polish",
			"POLISH",
			"The ethnic group of Polish people.");
	public static final AffiliationEthnicGroupCode POLYNESIAN = new AffiliationEthnicGroupCode(
			"Polynesian",
			"POLYNE",
			"The ethnic group of Polynesian people.");
	public static final AffiliationEthnicGroupCode POLYNESIAN_SAMOAN = new AffiliationEthnicGroupCode(
			"Polynesian (Samoan)",
			"POLYNS",
			"The ethnic group of Polynesian (Samoan) people.");
	public static final AffiliationEthnicGroupCode POLYNESIAN_TONGANS = new AffiliationEthnicGroupCode(
			"Polynesian (Tongans)",
			"POLYNT",
			"The ethnic group of Polynesian (Tongans) people.");
	public static final AffiliationEthnicGroupCode PORTUGUESE = new AffiliationEthnicGroupCode(
			"Portuguese",
			"PORTGS",
			"The ethnic group of Portuguese people.");
	public static final AffiliationEthnicGroupCode PUERTO_RICAN = new AffiliationEthnicGroupCode(
			"Puerto Rican",
			"PUERTR",
			"The ethnic group of Puerto Rican people.");
	public static final AffiliationEthnicGroupCode PUKAPUKA_ISLANDER = new AffiliationEthnicGroupCode(
			"Pukapuka Islander",
			"PUKISL",
			"The ethnic group of Pukapuka Islander people.");
	public static final AffiliationEthnicGroupCode PUNJABI = new AffiliationEthnicGroupCode(
			"Punjabi",
			"PUNJAB",
			"The ethnic group of Punjabi people.");
	public static final AffiliationEthnicGroupCode QUECHUA = new AffiliationEthnicGroupCode(
			"Quechua",
			"QUECHU",
			"The ethnic group of Quechua people.");
	public static final AffiliationEthnicGroupCode RAIS = new AffiliationEthnicGroupCode(
			"Rais",
			"RAIS",
			"The ethnic group of Rais people.");
	public static final AffiliationEthnicGroupCode RAKHINE = new AffiliationEthnicGroupCode(
			"Rakhine",
			"RAKHIN",
			"The ethnic group of Rakhine people.");
	public static final AffiliationEthnicGroupCode RAKAHANGA_ISLANDER = new AffiliationEthnicGroupCode(
			"Rakahanga Islander",
			"RAKISL",
			"The ethnic group of Rakahanga Islander people.");
	public static final AffiliationEthnicGroupCode RAROTONGAN = new AffiliationEthnicGroupCode(
			"Rarotongan",
			"RARTGN",
			"The ethnic group of Rarotongan people.");
	public static final AffiliationEthnicGroupCode RIO_MUNI_FANG = new AffiliationEthnicGroupCode(
			"Rio Muni (Fang)",
			"RIOMUN",
			"The ethnic group of Rio Muni (Fang) people.");
	public static final AffiliationEthnicGroupCode ROMANIAN_RUMANIAN = new AffiliationEthnicGroupCode(
			"Romanian/Rumanian",
			"ROMANN",
			"The ethnic group of Romanian/Rumanian people.");
	public static final AffiliationEthnicGroupCode ROMANSCH = new AffiliationEthnicGroupCode(
			"Romansch",
			"ROMANS",
			"The ethnic group of Romansch people.");
	public static final AffiliationEthnicGroupCode ROMANY_GYPSY = new AffiliationEthnicGroupCode(
			"Romany/Gypsy",
			"ROMANY",
			"The ethnic group of Romany/Gypsy people.");
	public static final AffiliationEthnicGroupCode ROTUMAN_ROTUMAN_ISLANDER = new AffiliationEthnicGroupCode(
			"Rotuman/Rotuman Islander",
			"ROTUMN",
			"The ethnic group of Rotuman/Rotuman Islander people.");
	public static final AffiliationEthnicGroupCode RUSSIAN = new AffiliationEthnicGroupCode(
			"Russian",
			"RUSSAN",
			"The ethnic group of Russian people.");
	public static final AffiliationEthnicGroupCode RUTHENIAN = new AffiliationEthnicGroupCode(
			"Ruthenian",
			"RUTHEN",
			"The ethnic group of Ruthenian people.");
	public static final AffiliationEthnicGroupCode RWANDANS = new AffiliationEthnicGroupCode(
			"Rwandans",
			"RWANDA",
			"The ethnic group of Rwandans people.");
	public static final AffiliationEthnicGroupCode SAHO = new AffiliationEthnicGroupCode(
			"Saho",
			"SAHO",
			"The ethnic group of Saho people.");
	public static final AffiliationEthnicGroupCode SAKALAVA = new AffiliationEthnicGroupCode(
			"Sakalava",
			"SAKALA",
			"The ethnic group of Sakalava people.");
	public static final AffiliationEthnicGroupCode SAMMARINESE = new AffiliationEthnicGroupCode(
			"Sammarinese",
			"SAMMAR",
			"The ethnic group of Sammarinese people.");
	public static final AffiliationEthnicGroupCode SAMOAN = new AffiliationEthnicGroupCode(
			"Samoan",
			"SAMOAN",
			"The ethnic group of Samoan people.");
	public static final AffiliationEthnicGroupCode SAMOAN_POLYNESIAN = new AffiliationEthnicGroupCode(
			"Samoan (Polynesian)",
			"SAMOAP",
			"The ethnic group of Samoan (Polynesian) people.");
	public static final AffiliationEthnicGroupCode SANGHA = new AffiliationEthnicGroupCode(
			"Sangha",
			"SANGHA",
			"The ethnic group of Sangha people.");
	public static final AffiliationEthnicGroupCode SANTA_CRUZ_ISLANDER = new AffiliationEthnicGroupCode(
			"Santa Cruz Islander",
			"SANISL",
			"The ethnic group of Santa Cruz Islander people.");
	public static final AffiliationEthnicGroupCode SARA = new AffiliationEthnicGroupCode(
			"Sara",
			"SARA",
			"The ethnic group of Sara people.");
	public static final AffiliationEthnicGroupCode SARDINIAN = new AffiliationEthnicGroupCode(
			"Sardinian",
			"SARDNN",
			"The ethnic group of Sardinian people.");
	public static final AffiliationEthnicGroupCode SCANDINAVIAN = new AffiliationEthnicGroupCode(
			"Scandinavian",
			"SCANDN",
			"The ethnic group of Scandinavian people.");
	public static final AffiliationEthnicGroupCode SCOTTISH_SCOTS = new AffiliationEthnicGroupCode(
			"Scottish (Scots)",
			"SCOTSH",
			"The ethnic group of Scottish (Scots) people.");
	public static final AffiliationEthnicGroupCode SENA = new AffiliationEthnicGroupCode(
			"Sena",
			"SENA",
			"The ethnic group of Sena people.");
	public static final AffiliationEthnicGroupCode SENOUFOU = new AffiliationEthnicGroupCode(
			"Senoufou",
			"SENOUF",
			"The ethnic group of Senoufou people.");
	public static final AffiliationEthnicGroupCode SENUFO = new AffiliationEthnicGroupCode(
			"Senufo",
			"SENUFO",
			"The ethnic group of Senufo people.");
	public static final AffiliationEthnicGroupCode SERB_SERBIAN = new AffiliationEthnicGroupCode(
			"Serb/Serbian",
			"SERBAN",
			"The ethnic group of Serb/Serbian people.");
	public static final AffiliationEthnicGroupCode SERER = new AffiliationEthnicGroupCode(
			"Serer",
			"SERER",
			"The ethnic group of Serer people.");
	public static final AffiliationEthnicGroupCode SERVICAIS = new AffiliationEthnicGroupCode(
			"Servicais",
			"SERVIC",
			"The ethnic group of Servicais people.");
	public static final AffiliationEthnicGroupCode SEYCHELLES_ISLANDER = new AffiliationEthnicGroupCode(
			"Seychelles Islander",
			"SEYISL",
			"The ethnic group of Seychelles Islander people.");
	public static final AffiliationEthnicGroupCode SHAN = new AffiliationEthnicGroupCode(
			"Shan",
			"SHAN",
			"The ethnic group of Shan people.");
	public static final AffiliationEthnicGroupCode SHERPAS = new AffiliationEthnicGroupCode(
			"Sherpas",
			"SHERPA",
			"The ethnic group of Sherpas people.");
	public static final AffiliationEthnicGroupCode SHETLAND_ISLANDER = new AffiliationEthnicGroupCode(
			"Shetland Islander",
			"SHTISL",
			"The ethnic group of Shetland Islander people.");
	public static final AffiliationEthnicGroupCode SICILIAN = new AffiliationEthnicGroupCode(
			"Sicilian",
			"SICLAN",
			"The ethnic group of Sicilian people.");
	public static final AffiliationEthnicGroupCode SIDAMO = new AffiliationEthnicGroupCode(
			"Sidamo",
			"SIDAMO",
			"The ethnic group of Sidamo people.");
	public static final AffiliationEthnicGroupCode SIKH = new AffiliationEthnicGroupCode(
			"Sikh",
			"SIKH",
			"The ethnic group of Sikh people.");
	public static final AffiliationEthnicGroupCode SINGAPOREAN_CHINESE = new AffiliationEthnicGroupCode(
			"Singaporean Chinese",
			"SINCHN",
			"The ethnic group of Singaporean Chinese people.");
	public static final AffiliationEthnicGroupCode SINDHI = new AffiliationEthnicGroupCode(
			"Sindhi",
			"SINDHI",
			"The ethnic group of Sindhi people.");
	public static final AffiliationEthnicGroupCode SINHALESE = new AffiliationEthnicGroupCode(
			"Sinhalese",
			"SINHLS",
			"The ethnic group of Sinhalese people.");
	public static final AffiliationEthnicGroupCode SINO_MAURITIAN = new AffiliationEthnicGroupCode(
			"Sino-Mauritian",
			"SINOMA",
			"The ethnic group of Sino-Mauritian people.");
	public static final AffiliationEthnicGroupCode SLAVIC_SLAV = new AffiliationEthnicGroupCode(
			"Slavic/Slav",
			"SLAVIC",
			"The ethnic group of Slavic/Slav people.");
	public static final AffiliationEthnicGroupCode SLOVAK = new AffiliationEthnicGroupCode(
			"Slovak",
			"SLOVAK",
			"The ethnic group of Slovak people.");
	public static final AffiliationEthnicGroupCode SLOVENE_SLOVENIAN = new AffiliationEthnicGroupCode(
			"Slovene/Slovenian",
			"SLOVNE",
			"The ethnic group of Slovene/Slovenian people.");
	public static final AffiliationEthnicGroupCode SOUTH_SLAV_FORMERLY_YUGOSLAV_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"South Slav (formerly Yugoslav) not elsewhere classified",
			"SLVNEC",
			"The not elsewhere classified ethnic groups of South Slav (formerly Yugoslav) people.");
	public static final AffiliationEthnicGroupCode SOUTH_SLAV_FORMERLY_YUGOSLAV_GROUPS_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"South Slav (formerly Yugoslav groups) not further defined",
			"SLVNFD",
			"The not further defined ethnic groups of South Slav (formerly Yugoslav groups) people.");
	public static final AffiliationEthnicGroupCode SOCIETY_ISLANDER_INCLUDING_TAHITIAN = new AffiliationEthnicGroupCode(
			"Society Islander (including Tahitian)",
			"SOCISL",
			"The ethnic group of Society Islander (including Tahitian) people.");
	public static final AffiliationEthnicGroupCode SOLOMON_ISLANDER = new AffiliationEthnicGroupCode(
			"Solomon Islander",
			"SOLISL",
			"The ethnic group of Solomon Islander people.");
	public static final AffiliationEthnicGroupCode SOLVENE = new AffiliationEthnicGroupCode(
			"Solvene",
			"SOLVEN",
			"The ethnic group of Solvene people.");
	public static final AffiliationEthnicGroupCode SOMALI = new AffiliationEthnicGroupCode(
			"Somali",
			"SOMALI",
			"The ethnic group of Somali people.");
	public static final AffiliationEthnicGroupCode SONGHAI = new AffiliationEthnicGroupCode(
			"Songhai",
			"SONGHA",
			"The ethnic group of Songhai people.");
	public static final AffiliationEthnicGroupCode SOTHO = new AffiliationEthnicGroupCode(
			"Sotho",
			"SOTHO",
			"The ethnic group of Sotho people.");
	public static final AffiliationEthnicGroupCode SOUTH_AFRICAN = new AffiliationEthnicGroupCode(
			"South African",
			"SOUAFR",
			"The ethnic group of South African people.");
	public static final AffiliationEthnicGroupCode SOUTH_AMERICAN_INDIAN = new AffiliationEthnicGroupCode(
			"South American Indian",
			"SOUAMR",
			"The ethnic group of South American Indian people.");
	public static final AffiliationEthnicGroupCode SOUTHEAST_ASIAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Southeast Asian not further defined",
			"SOUNFD",
			"The not further defined ethnic groups of Southeast Asian people.");
	public static final AffiliationEthnicGroupCode SOUSSOU = new AffiliationEthnicGroupCode(
			"Soussou",
			"SOUSSO",
			"The ethnic group of Soussou people.");
	public static final AffiliationEthnicGroupCode SOUTH_ASIAN = new AffiliationEthnicGroupCode(
			"South Asian",
			"SOUTHA",
			"The ethnic group of South Asian people.");
	public static final AffiliationEthnicGroupCode SPANISH = new AffiliationEthnicGroupCode(
			"Spanish",
			"SPANSH",
			"The ethnic group of Spanish people.");
	public static final AffiliationEthnicGroupCode SRI_LANKAN_NOT_ELSEWHERE_CLASSIFIED = new AffiliationEthnicGroupCode(
			"Sri Lankan not elsewhere classified",
			"SRINEC",
			"The not elsewhere classified ethnic groups of Sri Lankan people.");
	public static final AffiliationEthnicGroupCode SRI_LANKAN_NOT_FURTHER_DEFINED = new AffiliationEthnicGroupCode(
			"Sri Lankan not further defined",
			"SRINFD",
			"The not further defined ethnic groups of Sri Lankan people.");
	public static final AffiliationEthnicGroupCode SRI_LANKAN_TAMIL = new AffiliationEthnicGroupCode(
			"Sri Lankan Tamil",
			"SRITML",
			"The ethnic group of Sri Lankan Tamil people.");
	public static final AffiliationEthnicGroupCode SUNDANESE = new AffiliationEthnicGroupCode(
			"Sundanese",
			"SUNDAN",
			"The ethnic group of Sundanese people.");
	public static final AffiliationEthnicGroupCode SWEDISH = new AffiliationEthnicGroupCode(
			"Swedish",
			"SWEDSH",
			"The ethnic group of Swedish people.");
	public static final AffiliationEthnicGroupCode SWISS = new AffiliationEthnicGroupCode(
			"Swiss",
			"SWISS",
			"The ethnic group of Swiss people.");
	public static final AffiliationEthnicGroupCode SYRIAN_LEBANESE = new AffiliationEthnicGroupCode(
			"Syrian-Lebanese",
			"SYRANL",
			"The ethnic group of Syrian-Lebanese people.");
	public static final AffiliationEthnicGroupCode SYRIAN = new AffiliationEthnicGroupCode(
			"Syrian",
			"SYRIAN",
			"The ethnic group of Syrian people.");
	public static final AffiliationEthnicGroupCode SYRO_LEBANESE = new AffiliationEthnicGroupCode(
			"Syro-Lebanese",
			"SYROLE",
			"The ethnic group of Syro-Lebanese people.");
	public static final AffiliationEthnicGroupCode TAHITIAN_INCLUDING_SOCIETY_ISLANDER = new AffiliationEthnicGroupCode(
			"Tahitian (including Society Islander)",
			"TAHITN",
			"The ethnic group of Tahitian (including Society Islander) people.");
	public static final AffiliationEthnicGroupCode TAIWANESE_CHINESE = new AffiliationEthnicGroupCode(
			"Taiwanese Chinese",
			"TAICHN",
			"The ethnic group of Taiwanese Chinese people.");
	public static final AffiliationEthnicGroupCode TAJIK = new AffiliationEthnicGroupCode(
			"Tajik",
			"TAJIK",
			"The ethnic group of Tajik people.");
	public static final AffiliationEthnicGroupCode TAMANGS = new AffiliationEthnicGroupCode(
			"Tamangs",
			"TAMANG",
			"The ethnic group of Tamangs people.");
	public static final AffiliationEthnicGroupCode TAMIL = new AffiliationEthnicGroupCode(
			"Tamil",
			"TAMIL",
			"The ethnic group of Tamil people.");
	public static final AffiliationEthnicGroupCode TATAR = new AffiliationEthnicGroupCode(
			"Tatar",
			"TATAR",
			"The ethnic group of Tatar people.");
	public static final AffiliationEthnicGroupCode TEKE = new AffiliationEthnicGroupCode(
			"Teke",
			"TEKE",
			"The ethnic group of Teke people.");
	public static final AffiliationEthnicGroupCode TEUTONIC = new AffiliationEthnicGroupCode(
			"Teutonic",
			"TEUTON",
			"The ethnic group of Teutonic people.");
	public static final AffiliationEthnicGroupCode THAI_TAI_SIAMESE = new AffiliationEthnicGroupCode(
			"Thai/Tai/Siamese",
			"THAI",
			"The ethnic group of Thai/Tai/Siamese people.");
	public static final AffiliationEthnicGroupCode TIBETAN = new AffiliationEthnicGroupCode(
			"Tibetan",
			"TIBETN",
			"The ethnic group of Tibetan people.");
	public static final AffiliationEthnicGroupCode TIGREAN = new AffiliationEthnicGroupCode(
			"Tigrean",
			"TIGREA",
			"The ethnic group of Tigrean people.");
	public static final AffiliationEthnicGroupCode TOKELAUAN = new AffiliationEthnicGroupCode(
			"Tokelauan",
			"TOKELN",
			"The ethnic group of Tokelauan people.");
	public static final AffiliationEthnicGroupCode TONGAN = new AffiliationEthnicGroupCode(
			"Tongan",
			"TONGAN",
			"The ethnic group of Tongan people.");
	public static final AffiliationEthnicGroupCode TONGAS = new AffiliationEthnicGroupCode(
			"Tongas",
			"TONGAS",
			"The ethnic group of Tongas people.");
	public static final AffiliationEthnicGroupCode TORRES_STRAIT_ISLANDER_THURSDAY_ISLANDER = new AffiliationEthnicGroupCode(
			"Torres Strait Islander/Thursday Islander",
			"TORISL",
			"The ethnic group of Torres Strait Islander/Thursday Islander people.");
	public static final AffiliationEthnicGroupCode TOUBOU = new AffiliationEthnicGroupCode(
			"Toubou",
			"TOUBOU",
			"The ethnic group of Toubou people.");
	public static final AffiliationEthnicGroupCode TOUCOULEUR = new AffiliationEthnicGroupCode(
			"Toucouleur",
			"TOUCOU",
			"The ethnic group of Toucouleur people.");
	public static final AffiliationEthnicGroupCode TSIMIHETY = new AffiliationEthnicGroupCode(
			"Tsimihety",
			"TSIMHE",
			"The ethnic group of Tsimihety people.");
	public static final AffiliationEthnicGroupCode TUAMOTU_ISLANDER = new AffiliationEthnicGroupCode(
			"Tuamotu Islander",
			"TUAISL",
			"The ethnic group of Tuamotu Islander people.");
	public static final AffiliationEthnicGroupCode TUAREG = new AffiliationEthnicGroupCode(
			"Tuareg",
			"TUAREG",
			"The ethnic group of Tuareg people.");
	public static final AffiliationEthnicGroupCode TUMBUKO = new AffiliationEthnicGroupCode(
			"Tumbuko",
			"TUMBUK",
			"The ethnic group of Tumbuko people.");
	public static final AffiliationEthnicGroupCode TUNISIAN = new AffiliationEthnicGroupCode(
			"Tunisian",
			"TUNISN",
			"The ethnic group of Tunisian people.");
	public static final AffiliationEthnicGroupCode TURKMEN = new AffiliationEthnicGroupCode(
			"Turkmen",
			"TURKME",
			"The ethnic group of Turkmen people.");
	public static final AffiliationEthnicGroupCode TURKOMAN = new AffiliationEthnicGroupCode(
			"Turkoman",
			"TURKOM",
			"The ethnic group of Turkoman people.");
	public static final AffiliationEthnicGroupCode TURKISH_INCL_TURKISH_CYPRIOT = new AffiliationEthnicGroupCode(
			"Turkish (incl Turkish Cypriot)",
			"TURKSH",
			"The ethnic group of Turkish (incl Turkish Cypriot) people.");
	public static final AffiliationEthnicGroupCode TUTSI_HAMITIC = new AffiliationEthnicGroupCode(
			"Tutsi (Hamitic)",
			"TUTSI",
			"The ethnic group of Tutsi (Hamitic) people.");
	public static final AffiliationEthnicGroupCode TUVALU_ISLANDER_ELLICE_ISLANDER = new AffiliationEthnicGroupCode(
			"Tuvalu Islander/Ellice Islander",
			"TUVISL",
			"The ethnic group of Tuvalu Islander/Ellice Islander people.");
	public static final AffiliationEthnicGroupCode TWA_PYGMY = new AffiliationEthnicGroupCode(
			"Twa (Pygmy)",
			"TWA",
			"The ethnic group of Twa (Pygmy) people.");
	public static final AffiliationEthnicGroupCode UGANDAN = new AffiliationEthnicGroupCode(
			"Ugandan",
			"UGANDN",
			"The ethnic group of Ugandan people.");
	public static final AffiliationEthnicGroupCode UKRAINIAN = new AffiliationEthnicGroupCode(
			"Ukrainian",
			"UKRANN",
			"The ethnic group of Ukrainian people.");
	public static final AffiliationEthnicGroupCode URUGUAYAN = new AffiliationEthnicGroupCode(
			"Uruguayan",
			"URUGYN",
			"The ethnic group of Uruguayan people.");
	public static final AffiliationEthnicGroupCode UYGUR = new AffiliationEthnicGroupCode(
			"Uygur",
			"UYGUR",
			"The ethnic group of Uygur people.");
	public static final AffiliationEthnicGroupCode UZBEK = new AffiliationEthnicGroupCode(
			"Uzbek",
			"UZBEK",
			"The ethnic group of Uzbek people.");
	public static final AffiliationEthnicGroupCode VANUATU_ISLANDER_NEW_HEBRIDEAN = new AffiliationEthnicGroupCode(
			"Vanuatu Islander/New Hebridean",
			"VANUAT",
			"The ethnic group of Vanuatu Islander/New Hebridean people.");
	public static final AffiliationEthnicGroupCode VEDDA = new AffiliationEthnicGroupCode(
			"Vedda",
			"VEDDA",
			"The ethnic group of Vedda people.");
	public static final AffiliationEthnicGroupCode VENEZUELAN = new AffiliationEthnicGroupCode(
			"Venezuelan",
			"VENEZN",
			"The ethnic group of Venezuelan people.");
	public static final AffiliationEthnicGroupCode VIETNAMESE = new AffiliationEthnicGroupCode(
			"Vietnamese",
			"VIETNM",
			"The ethnic group of Vietnamese people.");
	public static final AffiliationEthnicGroupCode VIETNAMESE_CHINESE = new AffiliationEthnicGroupCode(
			"Vietnamese Chinese",
			"VITCHN",
			"The ethnic group of Vietnamese Chinese people.");
	public static final AffiliationEthnicGroupCode VLACHS = new AffiliationEthnicGroupCode(
			"Vlachs",
			"VLACHS",
			"The ethnic group of Vlachs people.");
	public static final AffiliationEthnicGroupCode VOLTAIC = new AffiliationEthnicGroupCode(
			"Voltaic",
			"VOLTAC",
			"The ethnic group of Voltaic people.");
	public static final AffiliationEthnicGroupCode WAKE_ISLANDER = new AffiliationEthnicGroupCode(
			"Wake Islander",
			"WAKISL",
			"The ethnic group of Wake Islander people.");
	public static final AffiliationEthnicGroupCode WALLIS_ISLANDER = new AffiliationEthnicGroupCode(
			"Wallis Islander",
			"WALISL",
			"The ethnic group of Wallis Islander people.");
	public static final AffiliationEthnicGroupCode WALLISIAN = new AffiliationEthnicGroupCode(
			"Wallisian",
			"WALLIS",
			"The ethnic group of Wallisian people.");
	public static final AffiliationEthnicGroupCode WALLOON = new AffiliationEthnicGroupCode(
			"Walloon",
			"WALLOO",
			"The ethnic group of Walloon people.");
	public static final AffiliationEthnicGroupCode WELSH = new AffiliationEthnicGroupCode(
			"Welsh",
			"WELSH",
			"The ethnic group of Welsh people.");
	public static final AffiliationEthnicGroupCode WHITE = new AffiliationEthnicGroupCode(
			"White",
			"WHITE",
			"The ethnic group of White people.");
	public static final AffiliationEthnicGroupCode WOLOF = new AffiliationEthnicGroupCode(
			"Wolof",
			"WOLOF",
			"The ethnic group of Wolof people.");
	public static final AffiliationEthnicGroupCode WEST_INDIAN_CARIBBEAN = new AffiliationEthnicGroupCode(
			"West Indian/Caribbean",
			"WSTIND",
			"The ethnic group of West Indian/Caribbean people.");
	public static final AffiliationEthnicGroupCode YAO = new AffiliationEthnicGroupCode(
			"Yao",
			"YAO",
			"The ethnic group of Yao people.");
	public static final AffiliationEthnicGroupCode YAP_ISLANDER = new AffiliationEthnicGroupCode(
			"Yap Islander",
			"YAPISL",
			"The ethnic group of Yap Islander people.");
	public static final AffiliationEthnicGroupCode YEMENI = new AffiliationEthnicGroupCode(
			"Yemeni",
			"YEMENI",
			"The ethnic group of Yemeni people.");
	public static final AffiliationEthnicGroupCode YI = new AffiliationEthnicGroupCode(
			"Yi",
			"YI",
			"The ethnic group of Yi people.");
	public static final AffiliationEthnicGroupCode YORUBA = new AffiliationEthnicGroupCode(
			"Yoruba",
			"YORUBA",
			"The ethnic group of Yoruba people.");
	public static final AffiliationEthnicGroupCode YUGOSLAVIAN = new AffiliationEthnicGroupCode(
			"Yugoslavian",
			"YUGOSL",
			"The ethnic group of Yugoslavian people.");
	public static final AffiliationEthnicGroupCode ZAIRIANS = new AffiliationEthnicGroupCode(
			"Zairians",
			"ZAIRAN",
			"The ethnic group of Zairians people.");
	public static final AffiliationEthnicGroupCode ZANZIBARI = new AffiliationEthnicGroupCode(
			"Zanzibari",
			"ZANZIB",
			"The ethnic group of Zanzibari people.");
	public static final AffiliationEthnicGroupCode ZHUANG = new AffiliationEthnicGroupCode(
			"Zhuang",
			"ZHUANG",
			"The ethnic group of Zhuang people.");

	private AffiliationEthnicGroupCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
