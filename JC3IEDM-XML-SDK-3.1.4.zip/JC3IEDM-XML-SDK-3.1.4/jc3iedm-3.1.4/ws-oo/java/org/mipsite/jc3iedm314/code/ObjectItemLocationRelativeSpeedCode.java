/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemLocationRelativeSpeedCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the speed of the object relative to its normal speed.";
	}

	private static HashMap<String, ObjectItemLocationRelativeSpeedCode> physicalToCode = new HashMap<String, ObjectItemLocationRelativeSpeedCode>();

	public static ObjectItemLocationRelativeSpeedCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemLocationRelativeSpeedCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemLocationRelativeSpeedCode FAST = new ObjectItemLocationRelativeSpeedCode(
			"Fast",
			"FAST",
			"Faster than the normal speed of the object reported.");
	public static final ObjectItemLocationRelativeSpeedCode MEDIUM = new ObjectItemLocationRelativeSpeedCode(
			"Medium",
			"MEDIUM",
			"The normal speed of the object reported.");
	public static final ObjectItemLocationRelativeSpeedCode SLOW = new ObjectItemLocationRelativeSpeedCode(
			"Slow",
			"SLOW",
			"Slower than the normal speed of the object reported.");
	public static final ObjectItemLocationRelativeSpeedCode NO_SPEED = new ObjectItemLocationRelativeSpeedCode(
			"No speed",
			"ZERO",
			"Self explanatory.");

	private ObjectItemLocationRelativeSpeedCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
