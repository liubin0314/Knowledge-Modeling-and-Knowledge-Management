/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MilitaryOrganisationTypeServiceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a military, paramilitary, irregular force, force or group, capable of functioning as an offensive or defensive combat or support organisation.";
	}

	private static HashMap<String, MilitaryOrganisationTypeServiceCode> physicalToCode = new HashMap<String, MilitaryOrganisationTypeServiceCode>();

	public static MilitaryOrganisationTypeServiceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MilitaryOrganisationTypeServiceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MilitaryOrganisationTypeServiceCode AIR_FORCE = new MilitaryOrganisationTypeServiceCode(
			"Air Force",
			"AIRFRC",
			"The MILITARY-ORGANISATION-TYPE in question belongs to the Air Force (includes reserves and mobilised air national guard).");
	public static final MilitaryOrganisationTypeServiceCode ARMY = new MilitaryOrganisationTypeServiceCode(
			"Army",
			"ARMY",
			"The MILITARY-ORGANISATION-TYPE in question belongs to the Army (includes territorial army, reserves, and mobilised national guard).");
	public static final MilitaryOrganisationTypeServiceCode BORDER_GUARD = new MilitaryOrganisationTypeServiceCode(
			"Border guard",
			"BRDRGD",
			"A paramilitary MILITARY-ORGANISATION-TYPE whose primary task is to maintain the security of national borders.");
	public static final MilitaryOrganisationTypeServiceCode COAST_GUARD = new MilitaryOrganisationTypeServiceCode(
			"Coast guard",
			"COASTG",
			"The MILITARY-ORGANISATION-TYPE that may be responsible for one or more of the following: coastal defence, protection of life and property at sea, and enforcement of customs, immigration, and navigation laws.");
	public static final MilitaryOrganisationTypeServiceCode COMBINED = new MilitaryOrganisationTypeServiceCode(
			"Combined",
			"COMBND",
			"The MILITARY-ORGANISATION-TYPE contains two or more forces or agencies of two or more allies.");
	public static final MilitaryOrganisationTypeServiceCode CIVIL_SERVICE = new MilitaryOrganisationTypeServiceCode(
			"Civil service",
			"CVLSVC",
			"The MILITARY-ORGANISATION-TYPE that is staffed solely by civilian personnel.");
	public static final MilitaryOrganisationTypeServiceCode GUERRILLA = new MilitaryOrganisationTypeServiceCode(
			"Guerrilla",
			"GUERLL",
			"The MILITARY-ORGANISATION-TYPE in question is an irregular military force.");
	public static final MilitaryOrganisationTypeServiceCode JOINT = new MilitaryOrganisationTypeServiceCode(
			"Joint",
			"JOINT",
			"The MILITARY-ORGANISATION-TYPE contains elements of more than one Service from the same nation.");
	public static final MilitaryOrganisationTypeServiceCode LOCAL_DEFENCE_FORCE = new MilitaryOrganisationTypeServiceCode(
			"Local defence force",
			"LCLDFF",
			"A military MILITARY-ORGANISATION-TYPE whose primary task is defence of a specific region (before mobilisation, a national guard is a local defence force).");
	public static final MilitaryOrganisationTypeServiceCode LOCAL_MILITIA = new MilitaryOrganisationTypeServiceCode(
			"Local militia",
			"LCLMLT",
			"A civilian MILITARY-ORGANISATION-TYPE that has a defence and possibly also a police role (may include irregular civilian MILITARY-ORGANISATION-TYPEs).");
	public static final MilitaryOrganisationTypeServiceCode MARINES = new MilitaryOrganisationTypeServiceCode(
			"Marines",
			"MARINE",
			"The MILITARY-ORGANISATION-TYPE in question belongs to the Marines (includes reserves).");
	public static final MilitaryOrganisationTypeServiceCode NAVY = new MilitaryOrganisationTypeServiceCode(
			"Navy",
			"NAVY",
			"The MILITARY-ORGANISATION-TYPE in question belongs to the Navy (includes reserves).");
	public static final MilitaryOrganisationTypeServiceCode NOT_KNOWN = new MilitaryOrganisationTypeServiceCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MilitaryOrganisationTypeServiceCode NOT_OTHERWISE_SPECIFIED = new MilitaryOrganisationTypeServiceCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MilitaryOrganisationTypeServiceCode PARAMILITARY = new MilitaryOrganisationTypeServiceCode(
			"Paramilitary",
			"PAR",
			"Forces or groups distinct from the regular armed forces of any country, but resembling them in organization, equipment, training, or mission.");
	public static final MilitaryOrganisationTypeServiceCode SPECIAL_FORCE = new MilitaryOrganisationTypeServiceCode(
			"Special force",
			"SPFRC",
			"The MILITARY-ORGANISATION-TYPE in question is trained and equipped for special purposes.");
	public static final MilitaryOrganisationTypeServiceCode TERRITORIAL_FORCE = new MilitaryOrganisationTypeServiceCode(
			"Territorial force",
			"TERFRC",
			"The MILITARY-ORGANISATION-TYPE of a nation's armed forces that is responsible for regional defence.");

	private MilitaryOrganisationTypeServiceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
