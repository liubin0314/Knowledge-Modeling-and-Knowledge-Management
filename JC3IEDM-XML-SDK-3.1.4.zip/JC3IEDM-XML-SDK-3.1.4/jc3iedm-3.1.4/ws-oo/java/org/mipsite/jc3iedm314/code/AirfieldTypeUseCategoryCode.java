/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldTypeUseCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value indicating an airport's main use.";
	}

	private static HashMap<String, AirfieldTypeUseCategoryCode> physicalToCode = new HashMap<String, AirfieldTypeUseCategoryCode>();

	public static AirfieldTypeUseCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldTypeUseCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldTypeUseCategoryCode CIVIL = new AirfieldTypeUseCategoryCode(
			"Civil",
			"A",
			"Civil airports controlled and operated by civil authorities primarily used by civil aircrafts although military aircrafts may have landing privileges and/or contract rights.");
	public static final AirfieldTypeUseCategoryCode JOINT = new AirfieldTypeUseCategoryCode(
			"Joint",
			"B",
			"Joint (civil and military) airports jointly controlled, used or operated by both civil and military agencies.");
	public static final AirfieldTypeUseCategoryCode MILITARY = new AirfieldTypeUseCategoryCode(
			"Military",
			"C",
			"Military airports controlled and operated by military authorities primarily used by military aircrafts although civil aircrafts may have landing privileges and/or contract rights.");
	public static final AirfieldTypeUseCategoryCode LIMITED = new AirfieldTypeUseCategoryCode(
			"Limited",
			"D",
			"Airfields having permanent type surface runways with less than the minimum facilities required for civil, joint or military airports.");

	private AirfieldTypeUseCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
