/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FeatureCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FEATURE.";
	}

	private static HashMap<String, FeatureCategoryCode> physicalToCode = new HashMap<String, FeatureCategoryCode>();

	public static FeatureCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FeatureCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FeatureCategoryCode CONTROL_FEATURE = new FeatureCategoryCode(
			"CONTROL-FEATURE",
			"CF",
			"A non-tangible FEATURE of military interest that is administratively specified, may be represented by a geometric figure, and is associated with the conduct of military operations.");
	public static final FeatureCategoryCode GEOGRAPHIC_FEATURE = new FeatureCategoryCode(
			"GEOGRAPHIC-FEATURE",
			"GF",
			"A FEATURE describing terrain characteristics to which military significance is attached.");
	public static final FeatureCategoryCode METEOROLOGIC_FEATURE = new FeatureCategoryCode(
			"METEOROLOGIC-FEATURE",
			"MF",
			"A FEATURE that describes reported or forecast weather and light conditions.");
	public static final FeatureCategoryCode NOT_OTHERWISE_SPECIFIED = new FeatureCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private FeatureCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
