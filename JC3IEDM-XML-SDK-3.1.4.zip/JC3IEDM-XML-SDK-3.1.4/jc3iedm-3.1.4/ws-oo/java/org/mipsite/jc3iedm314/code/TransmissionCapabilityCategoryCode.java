/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class TransmissionCapabilityCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of TRANSMISSION-CAPABILITY.";
	}

	private static HashMap<String, TransmissionCapabilityCategoryCode> physicalToCode = new HashMap<String, TransmissionCapabilityCategoryCode>();

	public static TransmissionCapabilityCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<TransmissionCapabilityCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final TransmissionCapabilityCategoryCode RECEIVE = new TransmissionCapabilityCategoryCode(
			"Receive",
			"RECEIV",
			"The ability to detect or pick up a broadcast, a signal or programme.");
	public static final TransmissionCapabilityCategoryCode TRANSMIT = new TransmissionCapabilityCategoryCode(
			"Transmit",
			"TRNSMT",
			"The ability to broadcast or send out a signal or programme.");
	public static final TransmissionCapabilityCategoryCode TRANSCEIVE = new TransmissionCapabilityCategoryCode(
			"Transceive",
			"TRNSRC",
			"The ability to detect, pick up, broadcast or send out a signal or programme.");

	private TransmissionCapabilityCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
