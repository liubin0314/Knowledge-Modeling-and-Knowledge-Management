/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusReinforcementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific ORGANISATION has additional or detached strength.";
	}

	private static HashMap<String, OrganisationStatusReinforcementCode> physicalToCode = new HashMap<String, OrganisationStatusReinforcementCode>();

	public static OrganisationStatusReinforcementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusReinforcementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusReinforcementCode DETACHED_ONLY = new OrganisationStatusReinforcementCode(
			"Detached only",
			"DETD",
			"The UNIT in question has sub-UNITs detached.");
	public static final OrganisationStatusReinforcementCode NOT_KNOWN = new OrganisationStatusReinforcementCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusReinforcementCode NORMAL_STRENGTH = new OrganisationStatusReinforcementCode(
			"Normal strength",
			"NORM",
			"The UNIT in question has no attachments or detachments.");
	public static final OrganisationStatusReinforcementCode REINFORCED_ONLY = new OrganisationStatusReinforcementCode(
			"Reinforced only",
			"REIN",
			"The UNIT in question has additional UNITs attached.");
	public static final OrganisationStatusReinforcementCode REINFORCED_AND_DETACHED = new OrganisationStatusReinforcementCode(
			"Reinforced and detached",
			"RIDT",
			"The UNIT in question has UNITs attached and sub-UNITs detached.");

	private OrganisationStatusReinforcementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
