/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CandidateTargetDetailAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CANDIDATE-TARGET-DETAIL-ASSOCIATION.";
	}

	private static HashMap<String, CandidateTargetDetailAssociationCategoryCode> physicalToCode = new HashMap<String, CandidateTargetDetailAssociationCategoryCode>();

	public static CandidateTargetDetailAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CandidateTargetDetailAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CandidateTargetDetailAssociationCategoryCode IS_CO_LOCATED_WITH = new CandidateTargetDetailAssociationCategoryCode(
			"Is co-located with",
			"COLOC",
			"The subject CANDIDATE-TARGET-DETAIL is in the vicinity of the object CANDIDATE-TARGET-DETAIL, but is not functionally related to it.");
	public static final CandidateTargetDetailAssociationCategoryCode HAS_AS_A_COMPONENT = new CandidateTargetDetailAssociationCategoryCode(
			"Has as a component",
			"COMPNT",
			"The subject CANDIDATE-TARGET-DETAIL includes the object CANDIDATE-TARGET-DETAIL as a functional component.");

	private CandidateTargetDetailAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
