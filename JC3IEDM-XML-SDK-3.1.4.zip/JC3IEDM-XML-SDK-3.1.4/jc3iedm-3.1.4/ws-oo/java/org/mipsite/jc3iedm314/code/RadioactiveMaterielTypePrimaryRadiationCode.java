/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RadioactiveMaterielTypePrimaryRadiationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the most intense radiation emitted by a RADIOACTIVE-MATERIEL-TYPE.";
	}

	private static HashMap<String, RadioactiveMaterielTypePrimaryRadiationCode> physicalToCode = new HashMap<String, RadioactiveMaterielTypePrimaryRadiationCode>();

	public static RadioactiveMaterielTypePrimaryRadiationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RadioactiveMaterielTypePrimaryRadiationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RadioactiveMaterielTypePrimaryRadiationCode ALPHA_RADIATION = new RadioactiveMaterielTypePrimaryRadiationCode(
			"Alpha radiation",
			"ALPHA",
			"Ionising radiation consisting of alpha particles (a helium nucleus), emitted by some substances undergoing radioactive decay.");
	public static final RadioactiveMaterielTypePrimaryRadiationCode BETA_RADIATION = new RadioactiveMaterielTypePrimaryRadiationCode(
			"Beta radiation",
			"BETA",
			"Radioactive decay in which an electron is emitted.");
	public static final RadioactiveMaterielTypePrimaryRadiationCode GAMMA_RADIATION = new RadioactiveMaterielTypePrimaryRadiationCode(
			"Gamma radiation",
			"GAMMA",
			"Penetrating electromagnetic radiation of shorter wavelength than X-rays.");
	public static final RadioactiveMaterielTypePrimaryRadiationCode NEUTRON = new RadioactiveMaterielTypePrimaryRadiationCode(
			"Neutron",
			"NEUTRN",
			"Subatomic particle of about the same mass as a proton but without an electric charge, present in all atomic nuclei except those of ordinary hydrogen emitted during nuclear decay.");
	public static final RadioactiveMaterielTypePrimaryRadiationCode NOT_KNOWN = new RadioactiveMaterielTypePrimaryRadiationCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private RadioactiveMaterielTypePrimaryRadiationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
