/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class DistancePrecisionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the maximum resolution used for the expression of a linear measure.";
	}

	private static HashMap<String, DistancePrecisionCode> physicalToCode = new HashMap<String, DistancePrecisionCode>();

	public static DistancePrecisionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<DistancePrecisionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final DistancePrecisionCode _100_FEET = new DistancePrecisionCode(
			"100 feet",
			"100FT",
			"A linear measure (distance, length) is defined to the precision of 100 feet (30.48 metres).");
	public static final DistancePrecisionCode _100_METRES = new DistancePrecisionCode(
			"100 metres",
			"100MTR",
			"A linear measure (distance, length) is defined to the precision of 100 metres.");
	public static final DistancePrecisionCode _10_FEET = new DistancePrecisionCode(
			"10 feet",
			"10FT",
			"A linear measure (distance, length) is defined to the precision of 10 feet (3.048 metres).");
	public static final DistancePrecisionCode _10_METRES = new DistancePrecisionCode(
			"10 metres",
			"10MTR",
			"A linear measure (distance, length) is defined to the precision of 10 metres.");
	public static final DistancePrecisionCode _300_METRES = new DistancePrecisionCode(
			"300 metres",
			"300MTR",
			"A linear measure (distance, length) is defined to the precision of 300 metres.");
	public static final DistancePrecisionCode _30_METRES = new DistancePrecisionCode(
			"30 metres",
			"30MTR",
			"A linear measure (distance, length) is defined to the precision of 30 metres.");
	public static final DistancePrecisionCode _3_METRES = new DistancePrecisionCode(
			"3 metres",
			"3MTR",
			"A linear measure (distance, length) is defined to the precision of 3 metres.");
	public static final DistancePrecisionCode CENTIMETRE = new DistancePrecisionCode(
			"Centimetre",
			"CM",
			"A linear measure (distance, length) is defined to the precision of 0.01 metre.");
	public static final DistancePrecisionCode FOOT = new DistancePrecisionCode(
			"Foot",
			"FOOT",
			"A linear measure (distance, length) is defined to the precision of one foot (0.3048 metres).");
	public static final DistancePrecisionCode INCH = new DistancePrecisionCode(
			"Inch",
			"INCH",
			"A linear measure (distance, length) is defined to the precision of one inch (0.0254 metres).");
	public static final DistancePrecisionCode KILOYARD = new DistancePrecisionCode(
			"Kiloyard",
			"KILYRD",
			"A linear measure (distance, length) is defined to the precision of a kiloyard (914,4 metres).");
	public static final DistancePrecisionCode KILOMETRE = new DistancePrecisionCode(
			"Kilometre",
			"KM",
			"A linear measure (distance, length) is defined to the precision of 1000 metres.");
	public static final DistancePrecisionCode METRE = new DistancePrecisionCode(
			"Metre",
			"METRE",
			"A linear measure (distance, length) is defined to the precision of one metre.");
	public static final DistancePrecisionCode MILE = new DistancePrecisionCode(
			"Mile",
			"MILE",
			"A linear measure (distance, length) is defined to the precision of one mile (1609.344 metres).");
	public static final DistancePrecisionCode MILLIMETRE = new DistancePrecisionCode(
			"Millimetre",
			"MM",
			"A linear measure (distance, length) is defined to the precision of one millimetre.");
	public static final DistancePrecisionCode NAUTICAL_MILE = new DistancePrecisionCode(
			"Nautical mile",
			"NM",
			"A linear measure (distance, length) is defined to the precision of a nautical mile (1852 metres).");
	public static final DistancePrecisionCode YARD = new DistancePrecisionCode(
			"Yard",
			"YARD",
			"A linear measure (distance, length) is defined to the precision of a yard (0.9144 metres).");

	private DistancePrecisionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
