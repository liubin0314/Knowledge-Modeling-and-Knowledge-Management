/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonStatusPhysicalStatusQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that qualifies the health conditions of a specific PERSON at a specific point in time.";
	}

	private static HashMap<String, PersonStatusPhysicalStatusQualifierCode> physicalToCode = new HashMap<String, PersonStatusPhysicalStatusQualifierCode>();

	public static PersonStatusPhysicalStatusQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonStatusPhysicalStatusQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonStatusPhysicalStatusQualifierCode ILL_CONTAGIOUS = new PersonStatusPhysicalStatusQualifierCode(
			"Ill, contagious",
			"ILLCNT",
			"The PERSON has an illness, caused by a disease that is likely to transmit to others.");
	public static final PersonStatusPhysicalStatusQualifierCode ILL_NON_CONTAGIOUS = new PersonStatusPhysicalStatusQualifierCode(
			"Ill, non-contagious",
			"ILLNCN",
			"The PERSON has an illness, caused by a disease that is not transmittable to others.");
	public static final PersonStatusPhysicalStatusQualifierCode ILL_UNKNOWN_DISEASE = new PersonStatusPhysicalStatusQualifierCode(
			"Ill, unknown disease",
			"ILLUNK",
			"The PERSON has an illness, caused by an unidentified disease.");
	public static final PersonStatusPhysicalStatusQualifierCode INJURED = new PersonStatusPhysicalStatusQualifierCode(
			"Injured",
			"INJRD",
			"The PERSON is incapacitated due to an injury resulting from an event other than an armed conflict.");
	public static final PersonStatusPhysicalStatusQualifierCode NOT_KNOWN = new PersonStatusPhysicalStatusQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersonStatusPhysicalStatusQualifierCode PREGNANT = new PersonStatusPhysicalStatusQualifierCode(
			"Pregnant",
			"PRGNT",
			"The PERSON is expecting a baby.");
	public static final PersonStatusPhysicalStatusQualifierCode WOUNDED = new PersonStatusPhysicalStatusQualifierCode(
			"Wounded",
			"WNDD",
			"The PERSON is incapacitated due to an injury resulting from an armed conflict.");

	private PersonStatusPhysicalStatusQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
