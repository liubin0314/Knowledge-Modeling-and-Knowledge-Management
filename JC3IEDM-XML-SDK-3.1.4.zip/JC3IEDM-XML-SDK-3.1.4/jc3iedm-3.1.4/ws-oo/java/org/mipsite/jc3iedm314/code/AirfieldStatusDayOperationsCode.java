/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AirfieldStatusDayOperationsCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the status of a specific AIRFIELD to only operate during daylight.";
	}

	private static HashMap<String, AirfieldStatusDayOperationsCode> physicalToCode = new HashMap<String, AirfieldStatusDayOperationsCode>();

	public static AirfieldStatusDayOperationsCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AirfieldStatusDayOperationsCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AirfieldStatusDayOperationsCode BOTH = new AirfieldStatusDayOperationsCode(
			"Both",
			"BOTH",
			"The specific AIRFIELD can support day and night operations.");
	public static final AirfieldStatusDayOperationsCode DAY = new AirfieldStatusDayOperationsCode(
			"Day",
			"DAY",
			"The specific AIRFIELD is restricted to daylight operations.");
	public static final AirfieldStatusDayOperationsCode NIGHT = new AirfieldStatusDayOperationsCode(
			"Night",
			"NIGHT",
			"The specific AIRFIELD is restricted to night time operations.");
	public static final AirfieldStatusDayOperationsCode NOT_KNOWN = new AirfieldStatusDayOperationsCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private AirfieldStatusDayOperationsCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
