/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusCommitmentStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that gives the commitment status of an ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusCommitmentStatusCode> physicalToCode = new HashMap<String, OrganisationStatusCommitmentStatusCode>();

	public static OrganisationStatusCommitmentStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusCommitmentStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusCommitmentStatusCode COMMITTED = new OrganisationStatusCommitmentStatusCode(
			"Committed",
			"COMM",
			"A status indicating that an ORGANISATION is currently tasked.");
	public static final OrganisationStatusCommitmentStatusCode UNCOMMITTED = new OrganisationStatusCommitmentStatusCode(
			"Uncommitted",
			"UNCOMM",
			"A status indicating that an ORGANISATION is not currently tasked and is available for tasking.");

	private OrganisationStatusCommitmentStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
