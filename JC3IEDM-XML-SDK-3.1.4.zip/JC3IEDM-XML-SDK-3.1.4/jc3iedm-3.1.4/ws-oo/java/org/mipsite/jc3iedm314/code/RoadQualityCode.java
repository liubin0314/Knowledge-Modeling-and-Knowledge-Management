/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RoadQualityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a subjective rating of the quality of the ROAD.";
	}

	private static HashMap<String, RoadQualityCode> physicalToCode = new HashMap<String, RoadQualityCode>();

	public static RoadQualityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RoadQualityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RoadQualityCode EXCELLENT = new RoadQualityCode(
			"Excellent",
			"E",
			"The quality of the ROAD is rated as excellent.");
	public static final RoadQualityCode FAIR = new RoadQualityCode(
			"Fair",
			"F",
			"The quality of the ROAD is rated as fair.");
	public static final RoadQualityCode GOOD = new RoadQualityCode(
			"Good",
			"G",
			"The quality of the ROAD is rated as good.");
	public static final RoadQualityCode POOR = new RoadQualityCode(
			"Poor",
			"P",
			"The quality of the ROAD is rated as poor.");

	private RoadQualityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
