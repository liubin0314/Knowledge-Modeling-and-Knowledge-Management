/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of a specific CONSUMABLE-MATERIEL-TYPE.";
	}

	private static HashMap<String, ConsumableMaterielTypeSubcategoryCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeSubcategoryCode>();

	public static ConsumableMaterielTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeSubcategoryCode _2C_B = new ConsumableMaterielTypeSubcategoryCode(
			"2C-B",
			"2CB",
			"A synthetic hallucinogenic substance marked by visual hallucinations similar to mescaline � a component of the peyote cactus.");
	public static final ConsumableMaterielTypeSubcategoryCode AMPHETAMINE = new ConsumableMaterielTypeSubcategoryCode(
			"Amphetamine",
			"AMPHTM",
			"A synthetic drug used esp. as a stimulant.");
	public static final ConsumableMaterielTypeSubcategoryCode AVIATION_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"Aviation fuel",
			"AVNFU",
			"A petroleum fraction used as fuel in aeroplane engines.");
	public static final ConsumableMaterielTypeSubcategoryCode BALLOON_HAND_HELD = new ConsumableMaterielTypeSubcategoryCode(
			"Balloon, hand held",
			"BALNHH",
			"An airtight envelope of paper, silk or similar material filled with light gas or air designed to be held by hand.");
	public static final ConsumableMaterielTypeSubcategoryCode BATTERY_DRY_WET_CELL = new ConsumableMaterielTypeSubcategoryCode(
			"Battery, dry/wet cell",
			"BATDWC",
			"A portable container of a wet/dry cell or cells carrying an electric charge, as a source of current.");
	public static final ConsumableMaterielTypeSubcategoryCode BOOBY_TRAP = new ConsumableMaterielTypeSubcategoryCode(
			"Booby trap",
			"BBYTRP",
			"An explosive or non-explosive device or other material deliberately placed to cause casualties when an apparently harmless object is disturbed or a normally safe act is performed.");
	public static final ConsumableMaterielTypeSubcategoryCode BLOOD = new ConsumableMaterielTypeSubcategoryCode(
			"Blood",
			"BLOOD",
			"The red liquid circulating in the arteries and veins of man and the higher animals, by which the tissues are constantly nourished and renewed.");
	public static final ConsumableMaterielTypeSubcategoryCode BANDAGES_DRESSINGS = new ConsumableMaterielTypeSubcategoryCode(
			"Bandages/dressings",
			"BNDDR",
			"Medical material applied to cover and protect an injury.");
	public static final ConsumableMaterielTypeSubcategoryCode BOOK = new ConsumableMaterielTypeSubcategoryCode(
			"Book",
			"BOOK",
			"A literary composition such as would occupy one or more volumes, without regard to the material form or forms in which it actually exists.");
	public static final ConsumableMaterielTypeSubcategoryCode CLOTHING = new ConsumableMaterielTypeSubcategoryCode(
			"Clothing",
			"CLTHNG",
			"Articles of dress or attire worn by individuals.");
	public static final ConsumableMaterielTypeSubcategoryCode COAL = new ConsumableMaterielTypeSubcategoryCode(
			"Coal",
			"COAL",
			"Fuel made from carbon, cinder or ember.");
	public static final ConsumableMaterielTypeSubcategoryCode COCAINE = new ConsumableMaterielTypeSubcategoryCode(
			"Cocaine",
			"COCANE",
			"A drug derived from coca or prepared synthetically, used as a local anaesthetic and as a stimulant.");
	public static final ConsumableMaterielTypeSubcategoryCode CRACK = new ConsumableMaterielTypeSubcategoryCode(
			"Crack",
			"CRACK",
			"A potent hard crystalline form of cocaine broken into small pieces and inhaled or smoked for its stimulating effect.");
	public static final ConsumableMaterielTypeSubcategoryCode DIESEL_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"Diesel fuel",
			"DIESEL",
			"A petroleum fraction intended to be used as fuel in diesel engines.");
	public static final ConsumableMaterielTypeSubcategoryCode DOB = new ConsumableMaterielTypeSubcategoryCode(
			"DOB",
			"DOB",
			"A synthetic phenethylamine substance marked by visual hallucinations.");
	public static final ConsumableMaterielTypeSubcategoryCode ECSTASY_MDA = new ConsumableMaterielTypeSubcategoryCode(
			"Ecstasy - MDA",
			"ECSMDA",
			"Methylenedioxyamphetamine, an amphetamine-based drug that causes euphoric and hallucinatory effects, originally produced as an appetite suppressant.");
	public static final ConsumableMaterielTypeSubcategoryCode ECSTASY_MDEA = new ConsumableMaterielTypeSubcategoryCode(
			"Ecstasy - MDEA",
			"ECSMDE",
			"Methylenedioxy-ethylamphetamine, an amphetamine-based drug that causes euphoric and hallucinatory effects, originally produced as an appetite suppressant.");
	public static final ConsumableMaterielTypeSubcategoryCode ECSTASY_MDMA = new ConsumableMaterielTypeSubcategoryCode(
			"Ecstasy - MDMA",
			"ECSMDM",
			"Methylenedioxymethamphetamine, an amphetamine-based drug that causes euphoric and hallucinatory effects, originally produced as an appetite suppressant.");
	public static final ConsumableMaterielTypeSubcategoryCode GHB = new ConsumableMaterielTypeSubcategoryCode(
			"GHB",
			"GHB",
			"Gamma hydroxy butyrate, a designer drug with anaesthetic properties, claimed also to be an aphrodisiac.");
	public static final ConsumableMaterielTypeSubcategoryCode HANDBILL = new ConsumableMaterielTypeSubcategoryCode(
			"Handbill",
			"HANDBL",
			"A printed notice or advertisement on a single page, intended to be delivered or circulated by hand.");
	public static final ConsumableMaterielTypeSubcategoryCode HASHISH = new ConsumableMaterielTypeSubcategoryCode(
			"Hashish",
			"HASHSH",
			"A resinous product of the top leaves and tender parts of hemp, smoked or chewed for its narcotic effects.");
	public static final ConsumableMaterielTypeSubcategoryCode HASHISH_OIL = new ConsumableMaterielTypeSubcategoryCode(
			"Hashish oil",
			"HASOIL",
			"A dark brown to black oily substance possessing a THC content averaging 20 percent.");
	public static final ConsumableMaterielTypeSubcategoryCode HEROIN = new ConsumableMaterielTypeSubcategoryCode(
			"Heroin",
			"HEROIN",
			"A highly addictive crystalline analgesic drug derived from morphine, often used as a narcotic.");
	public static final ConsumableMaterielTypeSubcategoryCode JP_4_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"JP-4 fuel",
			"JP4F",
			"A wide cut gasoline type fuel. Specification MIL-T-5624, interchangeable with AVTAG/FSII, NATO F-40.");
	public static final ConsumableMaterielTypeSubcategoryCode JP_5_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"JP-5 fuel",
			"JP5F",
			"Aviation kerosene, high flash point type, for ship borne aircraft. Specification MIL-T-5624, interchangeable with AVCAT/FSII, NATO F-44.");
	public static final ConsumableMaterielTypeSubcategoryCode JP_7_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"JP-7 fuel",
			"JP7F",
			"A kerosene type fuel of low volatility and high thermal stability. Specification MIL-T-38219.");
	public static final ConsumableMaterielTypeSubcategoryCode JP_8_FUEL = new ConsumableMaterielTypeSubcategoryCode(
			"JP-8 fuel",
			"JP8F",
			"Aviation kerosene, Specification MIL-T-83133 (F-34), interchangeable with AVTUR/FSII, NATO F-34.");
	public static final ConsumableMaterielTypeSubcategoryCode KEROSENE = new ConsumableMaterielTypeSubcategoryCode(
			"Kerosene",
			"KEROS",
			"A mixture of liquid hydrocarbons, a commercial product of the distillation of petroleum intended to be used in kerosene based engines.");
	public static final ConsumableMaterielTypeSubcategoryCode KHAT = new ConsumableMaterielTypeSubcategoryCode(
			"Khat",
			"KHAT",
			"The leaves of this shrub, chewed or infused as a stimulant.");
	public static final ConsumableMaterielTypeSubcategoryCode KETAMINE = new ConsumableMaterielTypeSubcategoryCode(
			"Ketamine",
			"KTMINE",
			"An anaesthetic and pain-killing drug, also used (illicitly) as a hallucinogen.");
	public static final ConsumableMaterielTypeSubcategoryCode LEAFLET = new ConsumableMaterielTypeSubcategoryCode(
			"Leaflet",
			"LEAFLT",
			"A small sized leaf of paper containing printed matter, chiefly for gratuitous distribution.");
	public static final ConsumableMaterielTypeSubcategoryCode LIQUEFIED_PETROLEUM_GAS = new ConsumableMaterielTypeSubcategoryCode(
			"Liquefied petroleum gas",
			"LPG",
			"Liquefied petroleum gas.");
	public static final ConsumableMaterielTypeSubcategoryCode LSD = new ConsumableMaterielTypeSubcategoryCode(
			"LSD",
			"LSD",
			"Lysergic acid diethylamide.");
	public static final ConsumableMaterielTypeSubcategoryCode LETTER_BOMB = new ConsumableMaterielTypeSubcategoryCode(
			"Letter bomb",
			"LTRBMB",
			"An improvised explosive device deliberately sent by postal or other services, as an apparently harmless letter or parcel, to cause casualties to the addressee.");
	public static final ConsumableMaterielTypeSubcategoryCode LUBRICANT = new ConsumableMaterielTypeSubcategoryCode(
			"Lubricant",
			"LUBRIC",
			"A material, usually an oil, used to lubricate machinery.");
	public static final ConsumableMaterielTypeSubcategoryCode MAGAZINE = new ConsumableMaterielTypeSubcategoryCode(
			"Magazine",
			"MAGZNE",
			"A periodical publication containing articles by various writers.");
	public static final ConsumableMaterielTypeSubcategoryCode MARIJUANA = new ConsumableMaterielTypeSubcategoryCode(
			"Marijuana",
			"MARJUN",
			"The dried leaves, flowering tops, and stems of the hemp, used as an intoxicating or hallucinogenic drug and usu. smoked in cigarettes; cannabis.");
	public static final ConsumableMaterielTypeSubcategoryCode MATTING = new ConsumableMaterielTypeSubcategoryCode(
			"Matting",
			"MATING",
			"Steel or other material used to construct a supporting surface over ground.");
	public static final ConsumableMaterielTypeSubcategoryCode MEDICINE = new ConsumableMaterielTypeSubcategoryCode(
			"Medicine",
			"MEDICN",
			"Any substance or preparation used in the treatment of disease.");
	public static final ConsumableMaterielTypeSubcategoryCode MORPHINE = new ConsumableMaterielTypeSubcategoryCode(
			"Morphine",
			"MORFIN",
			"An analgesic and narcotic drug obtained from opium and used medicinally to relieve pain.");
	public static final ConsumableMaterielTypeSubcategoryCode MESCALINE = new ConsumableMaterielTypeSubcategoryCode(
			"Mescaline",
			"MSCLNE",
			"A hallucinogenic alkaloid present in mescal buttons.");
	public static final ConsumableMaterielTypeSubcategoryCode METHAMPHETAMINE = new ConsumableMaterielTypeSubcategoryCode(
			"Methamphetamine",
			"MTHAMP",
			"An amphetamine derivative with quicker and longer action, used as a stimulant.");
	public static final ConsumableMaterielTypeSubcategoryCode MURAL = new ConsumableMaterielTypeSubcategoryCode(
			"Mural",
			"MURAL",
			"A painting executed on a wall or ceiling as part of a scheme or decoration.");
	public static final ConsumableMaterielTypeSubcategoryCode NATO_STANDARD_FUEL_CODE_F18 = new ConsumableMaterielTypeSubcategoryCode(
			"NATO standard fuel code F18",
			"NASF18",
			"Gasoline, Aviation, Grade 100/130.");
	public static final ConsumableMaterielTypeSubcategoryCode NATO_STANDARD_FUEL_CODE_F34 = new ConsumableMaterielTypeSubcategoryCode(
			"NATO standard fuel code F34",
			"NASF34",
			"Turbine Fuel, Aviation, Kerosene Type With S748.");
	public static final ConsumableMaterielTypeSubcategoryCode NATO_STANDARD_FUEL_CODE_F35 = new ConsumableMaterielTypeSubcategoryCode(
			"NATO standard fuel code F35",
			"NASF35",
			"Turbine Fuel, Aviation, Kerosene Type.");
	public static final ConsumableMaterielTypeSubcategoryCode NATO_STANDARD_FUEL_CODE_F40 = new ConsumableMaterielTypeSubcategoryCode(
			"NATO standard fuel code F40",
			"NASF40",
			"Turbine Fuel, Aviation, Wide Cut Type, With S748.");
	public static final ConsumableMaterielTypeSubcategoryCode NATO_STANDARD_FUEL_CODE_F44 = new ConsumableMaterielTypeSubcategoryCode(
			"NATO standard fuel code F44",
			"NASF44",
			"Turbine Fuel, Aviation, High Flash Type With S748.");
	public static final ConsumableMaterielTypeSubcategoryCode NATURAL_GAS = new ConsumableMaterielTypeSubcategoryCode(
			"Natural gas",
			"NATGAS",
			"A flammable gas, consisting largely of methane and other hydrocarbons, occurring naturally underground and used as fuel.");
	public static final ConsumableMaterielTypeSubcategoryCode NBC_KIT = new ConsumableMaterielTypeSubcategoryCode(
			"NBC kit",
			"NBCKIT",
			"The personal equipment and or medical supplies issued to a person for protection against chemical, biological, radiological, or nuclear materiel contamination or exposure.");
	public static final ConsumableMaterielTypeSubcategoryCode NOT_KNOWN = new ConsumableMaterielTypeSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ConsumableMaterielTypeSubcategoryCode NEWSPAPER = new ConsumableMaterielTypeSubcategoryCode(
			"Newspaper",
			"NWSPPR",
			"A printed publication containing the news, commonly with the addition of advertisements and other matters of interest.");
	public static final ConsumableMaterielTypeSubcategoryCode OIL = new ConsumableMaterielTypeSubcategoryCode(
			"Oil",
			"OIL",
			"A substance having the following characters (or most of them): viz. those of being liquid at ordinary temperatures, of a viscid consistence and characteristic smooth and sticky (unctuous) feel, lighter than water and insoluble in it, soluble in alcohol and ether, inflammable, chemically neutral.");
	public static final ConsumableMaterielTypeSubcategoryCode OPIUM = new ConsumableMaterielTypeSubcategoryCode(
			"Opium",
			"OPIUM",
			"A reddish-brown heavy-scented addictive drug prepared from the juice of the opium poppy, used in medicine as an analgesic and narcotic.");
	public static final ConsumableMaterielTypeSubcategoryCode PAINT = new ConsumableMaterielTypeSubcategoryCode(
			"Paint",
			"PAINT",
			"A substance consisting of a solid colouring matter dissolved in a liquid vehicle, as water or oil, used to impart a colour by being spread over a surface.");
	public static final ConsumableMaterielTypeSubcategoryCode PAPER = new ConsumableMaterielTypeSubcategoryCode(
			"Paper",
			"PAPER",
			"A substance composed of fibres interlaced into a compact web.");
	public static final ConsumableMaterielTypeSubcategoryCode PHENCYCLIDINE = new ConsumableMaterielTypeSubcategoryCode(
			"Phencyclidine",
			"PCP",
			"A piperidine derivative used as a veterinary anaesthetic and a hallucinogenic drug.");
	public static final ConsumableMaterielTypeSubcategoryCode PEAT = new ConsumableMaterielTypeSubcategoryCode(
			"Peat",
			"PEAT",
			"Dried bog or swamp matter used for fuel.");
	public static final ConsumableMaterielTypeSubcategoryCode PETROL = new ConsumableMaterielTypeSubcategoryCode(
			"Petrol",
			"PETROL",
			"A refined petroleum product intended to be used as fuel in gasoline engines.");
	public static final ConsumableMaterielTypeSubcategoryCode PAMPHLET = new ConsumableMaterielTypeSubcategoryCode(
			"Pamphlet",
			"PMPHLT",
			"A small treatise occupying fewer pages than would make a book, issued as a separate work; always unbound, with or without paper covers.");
	public static final ConsumableMaterielTypeSubcategoryCode PAINT_BRUSH = new ConsumableMaterielTypeSubcategoryCode(
			"Paint brush",
			"PNTBRS",
			"A device designed to apply paint.");
	public static final ConsumableMaterielTypeSubcategoryCode POSTER = new ConsumableMaterielTypeSubcategoryCode(
			"Poster",
			"POSTER",
			"A placard posted or displayed in a public place as an announcement or advertisement.");
	public static final ConsumableMaterielTypeSubcategoryCode PSILOCYBIN = new ConsumableMaterielTypeSubcategoryCode(
			"Psilocybin",
			"PSLCYB",
			"A hallucinogenic alkaloid found in toadstools of the genus Psilocybe.");
	public static final ConsumableMaterielTypeSubcategoryCode RATIONS_COMBAT = new ConsumableMaterielTypeSubcategoryCode(
			"Rations, combat",
			"RATCO",
			"A package of fixed portions of food allotted for persons.");
	public static final ConsumableMaterielTypeSubcategoryCode RATIONS_FRESH = new ConsumableMaterielTypeSubcategoryCode(
			"Rations, fresh",
			"RATFR",
			"Fresh food allotted for persons.");
	public static final ConsumableMaterielTypeSubcategoryCode RATIONS_TIN = new ConsumableMaterielTypeSubcategoryCode(
			"Rations, tin",
			"RATTI",
			"Food preserved in a container allotted for persons.");
	public static final ConsumableMaterielTypeSubcategoryCode REVETTING_MATERIAL = new ConsumableMaterielTypeSubcategoryCode(
			"Revetting material",
			"REVET",
			"Steel or other supporting material used in constructing a wall of earth.");
	public static final ConsumableMaterielTypeSubcategoryCode SPRAY_TANK = new ConsumableMaterielTypeSubcategoryCode(
			"Spray (tank)",
			"SPRAY",
			"A container used to dispense chemical or biological agents.");
	public static final ConsumableMaterielTypeSubcategoryCode UNIFORM = new ConsumableMaterielTypeSubcategoryCode(
			"Uniform",
			"UNIFRM",
			"A distinctive dress of uniform cut, materials, and colour worn by all the members of a particular naval, military, or other force to which it is recognised as properly belonging and peculiar.");
	public static final ConsumableMaterielTypeSubcategoryCode WIRE = new ConsumableMaterielTypeSubcategoryCode(
			"Wire",
			"WIRE",
			"A pliable metallic strand or rod made in many lengths and diameters.");
	public static final ConsumableMaterielTypeSubcategoryCode WOOD = new ConsumableMaterielTypeSubcategoryCode(
			"Wood",
			"WOOD",
			"A material used for construction or fuel.");
	public static final ConsumableMaterielTypeSubcategoryCode WATER_FIT_FOR_HUMAN_CONSUMPTION = new ConsumableMaterielTypeSubcategoryCode(
			"Water, fit for human consumption",
			"WTRHUM",
			"H2O that has been filtered and processed to remove poisons/toxins harmful to humans.");
	public static final ConsumableMaterielTypeSubcategoryCode WATER_FIT_FOR_MEDICAL_USE = new ConsumableMaterielTypeSubcategoryCode(
			"Water, fit for medical use",
			"WTRMED",
			"H2O that has been filtered or processed to remove poisons/toxins harmful to humans and that has also been sterilised to enable it to be used for medical purposes.");
	public static final ConsumableMaterielTypeSubcategoryCode WATER_NEITHER_MEDICAL_NOR_HUMAN_USE = new ConsumableMaterielTypeSubcategoryCode(
			"Water, neither medical nor human use",
			"WTROTH",
			"H2O that may have a level of poisons/toxins or bacteria that make it unfit for human consumption or medical usage, but that may be used for other purposes.");

	private ConsumableMaterielTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
