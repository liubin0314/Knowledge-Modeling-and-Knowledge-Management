/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceLifecycleCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the lifecycle of the artefact cited in a specific REFERENCE.";
	}

	private static HashMap<String, ReferenceLifecycleCode> physicalToCode = new HashMap<String, ReferenceLifecycleCode>();

	public static ReferenceLifecycleCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceLifecycleCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceLifecycleCode DRAFT = new ReferenceLifecycleCode(
			"Draft",
			"DRAFT",
			"The artefact cited in the specific REFERENCE has been produced in a preliminary version.");
	public static final ReferenceLifecycleCode FINAL = new ReferenceLifecycleCode(
			"Final",
			"FINAL",
			"The artefact cited in the specific REFERENCE has been produced in a completed version.");
	public static final ReferenceLifecycleCode OBSOLETE = new ReferenceLifecycleCode(
			"Obsolete",
			"OBSLTE",
			"The artefact cited in the specific REFERENCE is no longer valid.");

	private ReferenceLifecycleCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
