/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IedTacticalCharacterizationEmploymentMethodCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that describes how the device is delivered or attached to the target.";
	}

	private static HashMap<String, IedTacticalCharacterizationEmploymentMethodCode> physicalToCode = new HashMap<String, IedTacticalCharacterizationEmploymentMethodCode>();

	public static IedTacticalCharacterizationEmploymentMethodCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IedTacticalCharacterizationEmploymentMethodCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IedTacticalCharacterizationEmploymentMethodCode AIR_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Air-borne",
			"ABIED",
			"An IED held aloft by aerodynamic means or buoyancy that serves as concealment means for explosives with an initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode ANIMAL_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Animal-borne",
			"ANIED",
			"An IED worn by an animal where the whole IED or principal IED components are placed on the animal and also serves as the delivery or concealment means for explosives with an initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode LARGE_VEHICLE_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Large vehicle-borne",
			"LVBIED",
			"An IED built into any large ground-based vehicle (e.g., dump truck, panel truck, bongo truck, commercial bus, tanker, etc.) that serves as the concealment means for explosives with an initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode MAGNETIC_ATTACHMENT = new IedTacticalCharacterizationEmploymentMethodCode(
			"Magnetic attachment",
			"TACHMG",
			"A type of IED employment in which the device is attached to the target using magnets.");
	public static final IedTacticalCharacterizationEmploymentMethodCode NON_MAGNETIC_ATTACHMENT = new IedTacticalCharacterizationEmploymentMethodCode(
			"Non-magnetic attachment",
			"TACHNM",
			"A type of IED employment in which the device is attached to the target using non-magnetic means.");
	public static final IedTacticalCharacterizationEmploymentMethodCode PERSON_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Person-borne",
			"PBIED",
			"An IED worn by a person where the whole IED or principal IED components are placed in a vest, belt, backpack, etc, and also serves as the delivery or concealment means for explosives with an initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode POSTAL_PACKAGE_DELIVERY = new IedTacticalCharacterizationEmploymentMethodCode(
			"Postal/Package delivery",
			"POSTAL",
			"An IED introduced or delivered through a postal or package delivery system.");
	public static final IedTacticalCharacterizationEmploymentMethodCode PROJECTED = new IedTacticalCharacterizationEmploymentMethodCode(
			"Projected",
			"PROJD",
			"An IED delivered by an improvised weapons system that delivers the main charge through the air to its target.");
	public static final IedTacticalCharacterizationEmploymentMethodCode UNDERBELLY = new IedTacticalCharacterizationEmploymentMethodCode(
			"Underbelly",
			"UBELLY",
			"A type of IED employment in which the device targets the underside of a vehicle, using large amounts of explosives buried to deliberately defeat armour (can include conventional land mines).");
	public static final IedTacticalCharacterizationEmploymentMethodCode VEHICLE_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Vehicle-borne",
			"VBIED",
			"An IED delivered by any small ground-based vehicle (e.g., passenger vehicle, motorcycle, moped, bicycle, etc.) that serves as the concealment means for explosives with an Initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode VESSEL_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Vessel-borne",
			"VSBIED",
			"An IED delivered by any vessel that serves as the concealment means for explosives with an Initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode WATER_BORNE = new IedTacticalCharacterizationEmploymentMethodCode(
			"Water-borne",
			"WBIED",
			"An IED delivered by floating, drifting, anchored, or propelled on or below the water that serves as the concealment means for explosives with an initiating device.");
	public static final IedTacticalCharacterizationEmploymentMethodCode NOT_OTHERWISE_SPECIFIED = new IedTacticalCharacterizationEmploymentMethodCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final IedTacticalCharacterizationEmploymentMethodCode NOT_KNOWN = new IedTacticalCharacterizationEmploymentMethodCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private IedTacticalCharacterizationEmploymentMethodCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
