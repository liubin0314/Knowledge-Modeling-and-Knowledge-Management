/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class BridgeTypeDesignTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the design class of BRIDGE-TYPE.";
	}

	private static HashMap<String, BridgeTypeDesignTypeCode> physicalToCode = new HashMap<String, BridgeTypeDesignTypeCode>();

	public static BridgeTypeDesignTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<BridgeTypeDesignTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final BridgeTypeDesignTypeCode ARCH = new BridgeTypeDesignTypeCode(
			"Arch",
			"ARCH",
			"A bridge supported by curved structures.");
	public static final BridgeTypeDesignTypeCode BOX_GIRDER = new BridgeTypeDesignTypeCode(
			"Box-girder",
			"BXGRDR",
			"A bridge using large iron or steel beams or compound structure for bearing loads.");
	public static final BridgeTypeDesignTypeCode CANTILEVER = new BridgeTypeDesignTypeCode(
			"Cantilever",
			"CNTLVR",
			"A bridge made of cantilevers projecting from the piers and connected by girders.");
	public static final BridgeTypeDesignTypeCode FERRY = new BridgeTypeDesignTypeCode(
			"Ferry",
			"FERRY",
			"A movable bridge represented by a ferry moving back and forth between fixed bridging sites.");
	public static final BridgeTypeDesignTypeCode FLOATING_BOAT = new BridgeTypeDesignTypeCode(
			"Floating, boat",
			"FLTBOT",
			"A bridge constructed using small boats.");
	public static final BridgeTypeDesignTypeCode FLOATING_NOT_OTHERWISE_SPECIFIED = new BridgeTypeDesignTypeCode(
			"Floating, not otherwise specified",
			"FLTNOS",
			"A bridge on pontoons etc.");
	public static final BridgeTypeDesignTypeCode FLOATING_PONTOON = new BridgeTypeDesignTypeCode(
			"Floating, pontoon",
			"FLTPNT",
			"A bridge constructed on pontoons.");
	public static final BridgeTypeDesignTypeCode LIFT = new BridgeTypeDesignTypeCode(
			"Lift",
			"LIFT",
			"A bridge that can be raised to allow the passage of ships.");
	public static final BridgeTypeDesignTypeCode MILITARY_MEDIUM_GIRDER = new BridgeTypeDesignTypeCode(
			"Military, medium girder",
			"MILMDG",
			"A bridge using medium iron or steel beams or compound structure for bearing loads.");
	public static final BridgeTypeDesignTypeCode MILITARY_VEHICLE_LAUNCHED = new BridgeTypeDesignTypeCode(
			"Military, vehicle launched",
			"MILVHL",
			"A bridge that is carried on a vehicle and is deployed from the vehicle for immediate use.");
	public static final BridgeTypeDesignTypeCode NOT_KNOWN = new BridgeTypeDesignTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final BridgeTypeDesignTypeCode NOT_OTHERWISE_SPECIFIED = new BridgeTypeDesignTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final BridgeTypeDesignTypeCode RAFT = new BridgeTypeDesignTypeCode(
			"Raft",
			"RAFT",
			"A movable bridge represented by a raft moving back and forth between fixed bridging sites, usually along wires connected to both these sites.");
	public static final BridgeTypeDesignTypeCode SLAB = new BridgeTypeDesignTypeCode(
			"Slab",
			"SLAB",
			"A bridge made by use of a flat broad fairly thick usu. square or rectangular piece of solid material, esp. stone.");
	public static final BridgeTypeDesignTypeCode SUSPENSION = new BridgeTypeDesignTypeCode(
			"Suspension",
			"SSPNSN",
			"A bridge with a roadway suspended from cables supported by structures at each end.");
	public static final BridgeTypeDesignTypeCode STRINGER = new BridgeTypeDesignTypeCode(
			"Stringer",
			"STRNGR",
			"A bridge made by use of a longitudinal structural member in a framework.");
	public static final BridgeTypeDesignTypeCode SWING = new BridgeTypeDesignTypeCode(
			"Swing",
			"SWING",
			"A bridge that can be swung to one side to allow the passage of ships.");
	public static final BridgeTypeDesignTypeCode TRUSS = new BridgeTypeDesignTypeCode(
			"Truss",
			"TRUSS",
			"A bridge made by use of a framework, e.g. of rafters and struts.");

	private BridgeTypeDesignTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
