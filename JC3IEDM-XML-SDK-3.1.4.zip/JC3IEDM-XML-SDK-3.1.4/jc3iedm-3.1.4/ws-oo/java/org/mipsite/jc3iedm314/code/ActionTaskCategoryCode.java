/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskCategoryCode> physicalToCode = new HashMap<String, ActionTaskCategoryCode>();

	public static ActionTaskCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskCategoryCode ORDER = new ActionTaskCategoryCode(
			"Order",
			"ORD",
			"An ACTION-TASK that is directed to be executed.");
	public static final ActionTaskCategoryCode PLAN = new ActionTaskCategoryCode(
			"Plan",
			"PLAN",
			"An ACTION-TASK that represents a course of action that is foreseen or anticipated.");
	public static final ActionTaskCategoryCode REQUEST = new ActionTaskCategoryCode(
			"REQUEST",
			"RQT",
			"An ACTION-TASK that states a requirement.");
	public static final ActionTaskCategoryCode TEMPLATE = new ActionTaskCategoryCode(
			"Template",
			"TEM",
			"An ACTION-TASK that serves as a reference in planning.");

	private ActionTaskCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
