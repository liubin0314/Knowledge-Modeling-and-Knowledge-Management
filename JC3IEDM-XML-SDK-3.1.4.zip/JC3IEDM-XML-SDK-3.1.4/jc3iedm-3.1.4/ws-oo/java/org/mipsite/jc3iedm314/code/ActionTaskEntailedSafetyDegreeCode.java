/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskEntailedSafetyDegreeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the degree of safety (or risk) entailed with an ordered operation.";
	}

	private static HashMap<String, ActionTaskEntailedSafetyDegreeCode> physicalToCode = new HashMap<String, ActionTaskEntailedSafetyDegreeCode>();

	public static ActionTaskEntailedSafetyDegreeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskEntailedSafetyDegreeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskEntailedSafetyDegreeCode ALPHA = new ActionTaskEntailedSafetyDegreeCode(
			"ALPHA",
			"ALPHA",
			"No definition provided in ATP-06(B) and ATP-24(B).");
	public static final ActionTaskEntailedSafetyDegreeCode BRAVO = new ActionTaskEntailedSafetyDegreeCode(
			"BRAVO",
			"BRAVO",
			"No definition provided in ATP-06(B) and ATP-24(B).");
	public static final ActionTaskEntailedSafetyDegreeCode CHARLIE = new ActionTaskEntailedSafetyDegreeCode(
			"CHARLIE",
			"CHARLE",
			"No definition provided in ATP-06(B) and ATP-24(B).");

	private ActionTaskEntailedSafetyDegreeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
