/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldLandDepthPlacementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the placement of mines with respect to the surface.";
	}

	private static HashMap<String, MinefieldLandDepthPlacementCode> physicalToCode = new HashMap<String, MinefieldLandDepthPlacementCode>();

	public static MinefieldLandDepthPlacementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldLandDepthPlacementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldLandDepthPlacementCode MIXED = new MinefieldLandDepthPlacementCode(
			"Mixed",
			"MIXED",
			"A minefield that contains both surface and sub-surface laid mines.");
	public static final MinefieldLandDepthPlacementCode NOT_KNOWN = new MinefieldLandDepthPlacementCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MinefieldLandDepthPlacementCode SUBSURFACE = new MinefieldLandDepthPlacementCode(
			"Subsurface",
			"SUBSRF",
			"A minefield placed below the surface so as to be hidden from view.");
	public static final MinefieldLandDepthPlacementCode SURFACE = new MinefieldLandDepthPlacementCode(
			"Surface",
			"SURFCE",
			"A minefield placed on the surface.");

	private MinefieldLandDepthPlacementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
