/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class EchelonSizeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the relative size of the commonly accepted configuration of military formations.";
	}

	private static HashMap<String, EchelonSizeCode> physicalToCode = new HashMap<String, EchelonSizeCode>();

	public static EchelonSizeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<EchelonSizeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final EchelonSizeCode ARMY_GROUP = new EchelonSizeCode(
			"Army group",
			"AG",
			"The largest formation of land forces, normally comprising two or more armies or army corps under a designated commander.");
	public static final EchelonSizeCode ARMY = new EchelonSizeCode(
			"Army",
			"ARMY",
			"A formation larger than an army corps but smaller than an army group. It usually consists of two or more army corps.");
	public static final EchelonSizeCode BATTLE_GROUP = new EchelonSizeCode(
			"Battle group",
			"BATGRP",
			"An operational grouping which is based on either an infantry battalion or a tank regiment, each with at least a squadron or company of the other arm and with elements of other supporting arms and services allocated according to need.");
	public static final EchelonSizeCode BRIGADE = new EchelonSizeCode(
			"Brigade",
			"BDE",
			"Unit composed of a headquarters and two or more battalions. It may be part of an army and be charged with only tactical functions, or it may be a separate unit and be charged with both administrative and tactical functions.");
	public static final EchelonSizeCode BRIGADE_GROUP = new EchelonSizeCode(
			"Brigade group",
			"BDEGRP",
			"An operational grouping which is based on an infantry or armoured brigade and which has elements of other supporting arms and services allocated according to need.");
	public static final EchelonSizeCode BATTALION = new EchelonSizeCode(
			"Battalion",
			"BN",
			"Unit composed of a headquarters and two or more companies or batteries. It may be part of a regiment and be charged with only tactical functions, or it may be a separate unit and be charged with both administrative and tactical functions.");
	public static final EchelonSizeCode BATTALION_GROUP = new EchelonSizeCode(
			"Battalion group",
			"BNG",
			"An operational grouping which is based on an infantry battalion and which has elements of other supporting arms and services allocated according to need.");
	public static final EchelonSizeCode CORPS = new EchelonSizeCode(
			"Corps",
			"CORPS",
			"A formation larger than a division but smaller than an army or army group. It usually consists to two or more divisions together with supporting arms and services.");
	public static final EchelonSizeCode COMPANY = new EchelonSizeCode(
			"Company",
			"COY",
			"Basic administrative and tactical unit in most arms and services of the Army. A company is on a command level below a battalion and above a platoon.");
	public static final EchelonSizeCode COMPANY_GROUP = new EchelonSizeCode(
			"Company group",
			"COYG",
			"An operational grouping which is based on either an infantry company or a tank company, which has elements of other supporting arms and services allocated according to need.");
	public static final EchelonSizeCode DIVISION = new EchelonSizeCode(
			"Division",
			"DIV",
			"A tactical unit/formation that is a major administrative and tactical unit/formation that combines in itself the necessary arms and services required for sustained combat, larger than a regiment/brigade and smaller than a corps.");
	public static final EchelonSizeCode FLEET = new EchelonSizeCode(
			"Fleet",
			"FLEET",
			"An organisation of ships, aircraft, Marine forces, and shore-based fleet activities all under the command of a commander or commander in chief who may exercise operational as well as administrative control.");
	public static final EchelonSizeCode FLIGHT = new EchelonSizeCode(
			"Flight",
			"FLIGHT",
			"A specified group of aircraft engaged in a common mission.");
	public static final EchelonSizeCode NOT_KNOWN = new EchelonSizeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final EchelonSizeCode NOT_OTHERWISE_SPECIFIED = new EchelonSizeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final EchelonSizeCode TASK_FORCE_NAVY = new EchelonSizeCode(
			"Task force, Navy",
			"NTF",
			"A component of a fleet organized by the commander of a task fleet or higher authority for the accomplishment of a specific task or tasks.");
	public static final EchelonSizeCode TASK_GROUP_NAVY = new EchelonSizeCode(
			"Task group, Navy",
			"NTG",
			"A component of a task force organized by the commander of the task force or higher authority for accomplishing specific tasks.");
	public static final EchelonSizeCode TASK_UNIT_NAVY = new EchelonSizeCode(
			"Task unit, Navy",
			"NTU",
			"A component of a task group organized by the commander of a task group or higher authority for accomplishing specific tasks.");
	public static final EchelonSizeCode PLATOON = new EchelonSizeCode(
			"Platoon",
			"PLT",
			"Basic administrative and tactical unit in most arms and services of the Army.");
	public static final EchelonSizeCode REGION = new EchelonSizeCode(
			"Region",
			"REGION",
			"A grouping of two or more Army groups.");
	public static final EchelonSizeCode REGIMENT = new EchelonSizeCode(
			"Regiment",
			"RGT",
			"Administrative and tactical unit, on a command level below a division or brigade and above a battalion, the entire organisation of which is prescribed by table of organisation.");
	public static final EchelonSizeCode SECTION = new EchelonSizeCode(
			"Section",
			"SECT",
			"A small tactical unit.");
	public static final EchelonSizeCode SQUADRON_AIR = new EchelonSizeCode(
			"Squadron, air",
			"SQDRNA",
			"An administrative or tactical organisation normally but not necessarily composed of aircraft of the same type.");
	public static final EchelonSizeCode SQUADRON_MARITIME = new EchelonSizeCode(
			"Squadron, maritime",
			"SQDRNM",
			"An administrative or tactical organisation consisting of two or more divisions of ships, plus such additional ships as may be assigned as flagships or tenders.");
	public static final EchelonSizeCode SQUAD = new EchelonSizeCode(
			"Squad",
			"SQUAD",
			"A small number of men, a subdivision or section of a company, formed for drill.");
	public static final EchelonSizeCode TEAM_FIRE_TEAM_CREW = new EchelonSizeCode(
			"Team/fire team/crew",
			"TEAM",
			"Any unit smaller than a squad that will be denoted by a vehicle or weapon symbol in a graphical representation.");
	public static final EchelonSizeCode TASK_ELEMENT_NAVY = new EchelonSizeCode(
			"Task element, Navy",
			"TSKELN",
			"A component of a task unit organized by the commander of the task unit or higher authority for accomplishing a specific task.");
	public static final EchelonSizeCode WING = new EchelonSizeCode(
			"Wing",
			"WING",
			"An aviation unit composed normally of one primary mission group and the necessary supporting organisations.");

	private EchelonSizeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
