/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskStatusProgressCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the perceived appraisal of the progress of a specific ACTION-TASK.";
	}

	private static HashMap<String, ActionTaskStatusProgressCode> physicalToCode = new HashMap<String, ActionTaskStatusProgressCode>();

	public static ActionTaskStatusProgressCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskStatusProgressCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskStatusProgressCode ABORTED = new ActionTaskStatusProgressCode(
			"Aborted",
			"ABO",
			"The specified ACTION-TASK has been abandoned subsequent to its initiation.");
	public static final ActionTaskStatusProgressCode AIRBORNE = new ActionTaskStatusProgressCode(
			"Airborne",
			"AIRBRN",
			"The specified ACTION-TASK is in the main phase at the time of the report.");
	public static final ActionTaskStatusProgressCode CANCELLED = new ActionTaskStatusProgressCode(
			"Cancelled",
			"CANCLD",
			"The specified ACTION-TASK was cancelled prior to its initiation.");
	public static final ActionTaskStatusProgressCode COMPLETE = new ActionTaskStatusProgressCode(
			"Complete",
			"COM",
			"The specified ACTION-TASK has been carried out and is complete.");
	public static final ActionTaskStatusProgressCode DELAYED = new ActionTaskStatusProgressCode(
			"Delayed",
			"DELAY",
			"The execution of the specified ACTION-TASK has been delayed beyond the planned starting time.");
	public static final ActionTaskStatusProgressCode DEPLOY_MARITIME_MINE_WARFARE_EQUIPMENT = new ActionTaskStatusProgressCode(
			"Deploy, maritime mine warfare equipment",
			"DPLMMW",
			"To deploy maritime mine warfare equipment from a vessel.");
	public static final ActionTaskStatusProgressCode DOWN_TIME_WEATHER = new ActionTaskStatusProgressCode(
			"Down time, weather",
			"DWNTMW",
			"Hours that equipment e.g. helicopters, cannot operate due to weather conditions.");
	public static final ActionTaskStatusProgressCode IN_PROGRESS = new ActionTaskStatusProgressCode(
			"In progress",
			"IPR",
			"The specified ACTION-TASK is in the process of being carried out at the time of the report.");
	public static final ActionTaskStatusProgressCode NOT_KNOWN = new ActionTaskStatusProgressCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionTaskStatusProgressCode NO_OPERATION = new ActionTaskStatusProgressCode(
			"No operation",
			"NOOPER",
			"The planned task was not carried out during a specified period.");
	public static final ActionTaskStatusProgressCode NOT_OTHERWISE_SPECIFIED = new ActionTaskStatusProgressCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionTaskStatusProgressCode NOT_STARTED = new ActionTaskStatusProgressCode(
			"Not started",
			"NST",
			"The specified ACTION-TASK has not yet begun at the time of the report.");
	public static final ActionTaskStatusProgressCode OFF_TASK = new ActionTaskStatusProgressCode(
			"Off task",
			"OFFTSK",
			"Hours that a unit is scheduled off task.");
	public static final ActionTaskStatusProgressCode PAUSED = new ActionTaskStatusProgressCode(
			"Paused",
			"PAU",
			"The specified ACTION-TASK has been temporarily halted for an unspecified period of time.");
	public static final ActionTaskStatusProgressCode PLANNING = new ActionTaskStatusProgressCode(
			"Planning",
			"PLAN",
			"The specified ACTION-TASK is still in the planning phase.");
	public static final ActionTaskStatusProgressCode RECOVER_MARITIME_MINE_WARFARE_EQUIPMENT = new ActionTaskStatusProgressCode(
			"Recover, maritime mine warfare equipment",
			"RECMMW",
			"To recover maritime mine warfare equipment to a vessel.");
	public static final ActionTaskStatusProgressCode RETASKED = new ActionTaskStatusProgressCode(
			"Retasked",
			"RETASK",
			"The specified ACTION-TASK has been replaced or modified subsequent to its initiation.");
	public static final ActionTaskStatusProgressCode SCRAMBLED = new ActionTaskStatusProgressCode(
			"Scrambled",
			"SCRMBL",
			"The order to take-off has been received by the aircraft tasked with the specified ACTION-TASK, but the action area is not yet reached.");
	public static final ActionTaskStatusProgressCode TASKED = new ActionTaskStatusProgressCode(
			"Tasked",
			"TASKED",
			"The specified ACTION-TASK has been assigned, but the execution has not started.");
	public static final ActionTaskStatusProgressCode TURNING_MARITIME_MINE_WARFARE = new ActionTaskStatusProgressCode(
			"Turning, maritime mine warfare",
			"TRNMMW",
			"The method of completing the end of a run on one track and preparing to commence the next run either on the same track or another track.");

	private ActionTaskStatusProgressCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
