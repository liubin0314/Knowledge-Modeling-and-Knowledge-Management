/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SurveillanceCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the SURVEILLANCE-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, SurveillanceCapabilityDescriptorCode> physicalToCode = new HashMap<String, SurveillanceCapabilityDescriptorCode>();

	public static SurveillanceCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SurveillanceCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SurveillanceCapabilityDescriptorCode MAXIMUM_RANGE = new SurveillanceCapabilityDescriptorCode(
			"Maximum range",
			"MRANGE",
			"The longest distance that can be achieved.");
	public static final SurveillanceCapabilityDescriptorCode MINIMUM_RANGE = new SurveillanceCapabilityDescriptorCode(
			"Minimum range",
			"NRANGE",
			"The shortest distance that can be achieved.");

	private SurveillanceCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
