/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class TransmissionCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the TRANSMISSION-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, TransmissionCapabilityDescriptorCode> physicalToCode = new HashMap<String, TransmissionCapabilityDescriptorCode>();

	public static TransmissionCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<TransmissionCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final TransmissionCapabilityDescriptorCode MAXIMUM_FREQUENCY = new TransmissionCapabilityDescriptorCode(
			"Maximum frequency",
			"MAXFRQ",
			"The highest frequency that can be utilised while being operational.");
	public static final TransmissionCapabilityDescriptorCode MAXIMUM_PULSE_REPETITION_FREQUENCY = new TransmissionCapabilityDescriptorCode(
			"Maximum pulse repetition frequency",
			"MAXPRF",
			"The highest number of distinct pulses that can be generated per second while being operational.");
	public static final TransmissionCapabilityDescriptorCode MINIMUM_FREQUENCY = new TransmissionCapabilityDescriptorCode(
			"Minimum frequency",
			"MNMFRQ",
			"The lowest frequency that can be utilised while being operational.");
	public static final TransmissionCapabilityDescriptorCode MINIMUM_PULSE_REPETITION_FREQUENCY = new TransmissionCapabilityDescriptorCode(
			"Minimum pulse repetition frequency",
			"MNMPRF",
			"The lowest number of distinct pulses that can be generated per second while being operational.");
	public static final TransmissionCapabilityDescriptorCode POWER = new TransmissionCapabilityDescriptorCode(
			"Power",
			"POWER",
			"Energy that is produced by mechanical, electrical or other means.");

	private TransmissionCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
