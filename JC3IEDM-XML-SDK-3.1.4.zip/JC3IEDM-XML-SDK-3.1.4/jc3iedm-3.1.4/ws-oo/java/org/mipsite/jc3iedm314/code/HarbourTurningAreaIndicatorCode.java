/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourTurningAreaIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether there is a turning basin or other water area available in a specific HARBOUR.";
	}

	private static HashMap<String, HarbourTurningAreaIndicatorCode> physicalToCode = new HashMap<String, HarbourTurningAreaIndicatorCode>();

	public static HarbourTurningAreaIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourTurningAreaIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourTurningAreaIndicatorCode NO = new HarbourTurningAreaIndicatorCode(
			"No",
			"NO",
			"A turning area is not available at the harbour.");
	public static final HarbourTurningAreaIndicatorCode YES = new HarbourTurningAreaIndicatorCode(
			"Yes",
			"YES",
			"A turning area is available at the harbour.");

	private HarbourTurningAreaIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
