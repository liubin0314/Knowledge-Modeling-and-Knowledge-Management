/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceCriticalityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes a judgement whether a specific resource (OBJECT-ITEM or OBJECT-TYPE) associated with a specific ACTION is essential for the effective completion of that ACTION.";
	}

	private static HashMap<String, ActionResourceCriticalityIndicatorCode> physicalToCode = new HashMap<String, ActionResourceCriticalityIndicatorCode>();

	public static ActionResourceCriticalityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceCriticalityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceCriticalityIndicatorCode NO = new ActionResourceCriticalityIndicatorCode(
			"No",
			"NO",
			"The resource is not essential for the effective completion of the ACTION.");
	public static final ActionResourceCriticalityIndicatorCode YES = new ActionResourceCriticalityIndicatorCode(
			"Yes",
			"YES",
			"The resource is essential for the effective completion of the ACTION.");

	private ActionResourceCriticalityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
