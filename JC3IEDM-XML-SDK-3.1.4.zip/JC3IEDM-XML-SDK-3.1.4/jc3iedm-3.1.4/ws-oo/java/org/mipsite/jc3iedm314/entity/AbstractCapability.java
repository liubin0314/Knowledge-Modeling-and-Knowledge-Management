/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractCapability extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private CapabilityDayNightCode dayNightCode; // optional
	private CapabilityUnitOfMeasureCode unitOfMeasureCode; // mandatory
	private Set<Ref<ActionRequiredCapability>> actionRequiredCapabilitySet; // zero-one-or-more
	private Set<Ref<CapabilityReferenceAssociation>> capabilityReferenceAssociationSet; // zero-one-or-more
	private Set<Ref<ObjectItemCapability>> objectItemCapabilitySet; // zero-one-or-more
	private Set<Ref<ObjectTypeCapabilityNorm>> objectTypeCapabilityNormSet; // zero-one-or-more

	// default constructor

	public AbstractCapability() {
		this.actionRequiredCapabilitySet = new HashSet<Ref<ActionRequiredCapability>>();
		this.capabilityReferenceAssociationSet = new HashSet<Ref<CapabilityReferenceAssociation>>();
		this.objectItemCapabilitySet = new HashSet<Ref<ObjectItemCapability>>();
		this.objectTypeCapabilityNormSet = new HashSet<Ref<ObjectTypeCapabilityNorm>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractCapability.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractCapability.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public CapabilityDayNightCode getDayNightCode() {
		return this.dayNightCode;
	}

	public void setDayNightCode(CapabilityDayNightCode dayNightCode) {
		this.dayNightCode = dayNightCode;
	}

	public CapabilityUnitOfMeasureCode getUnitOfMeasureCode() {
		if (this.unitOfMeasureCode == null) {
			throw new NullValueException("AbstractCapability.unitOfMeasureCode");
		}
		return this.unitOfMeasureCode;
	}

	public void setUnitOfMeasureCode(CapabilityUnitOfMeasureCode unitOfMeasureCode) {
		this.unitOfMeasureCode = unitOfMeasureCode;
	}

	public Set<Ref<ActionRequiredCapability>> getActionRequiredCapabilitySet() {
		return this.actionRequiredCapabilitySet;
	}

	public void addActionRequiredCapability(Ref<ActionRequiredCapability> actionRequiredCapability) {
		this.actionRequiredCapabilitySet.add(actionRequiredCapability);
	}

	public Set<Ref<CapabilityReferenceAssociation>> getCapabilityReferenceAssociationSet() {
		return this.capabilityReferenceAssociationSet;
	}

	public void addCapabilityReferenceAssociation(Ref<CapabilityReferenceAssociation> capabilityReferenceAssociation) {
		this.capabilityReferenceAssociationSet.add(capabilityReferenceAssociation);
	}

	public Set<Ref<ObjectItemCapability>> getObjectItemCapabilitySet() {
		return this.objectItemCapabilitySet;
	}

	public void addObjectItemCapability(Ref<ObjectItemCapability> objectItemCapability) {
		this.objectItemCapabilitySet.add(objectItemCapability);
	}

	public Set<Ref<ObjectTypeCapabilityNorm>> getObjectTypeCapabilityNormSet() {
		return this.objectTypeCapabilityNormSet;
	}

	public void addObjectTypeCapabilityNorm(Ref<ObjectTypeCapabilityNorm> objectTypeCapabilityNorm) {
		this.objectTypeCapabilityNormSet.add(objectTypeCapabilityNorm);
	}
}
