/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ControlFeatureStatusSecurityStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the protection status of the site encompassed by a specific CONTROL-FEATURE.";
	}

	private static HashMap<String, ControlFeatureStatusSecurityStatusCode> physicalToCode = new HashMap<String, ControlFeatureStatusSecurityStatusCode>();

	public static ControlFeatureStatusSecurityStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ControlFeatureStatusSecurityStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ControlFeatureStatusSecurityStatusCode GUARDED = new ControlFeatureStatusSecurityStatusCode(
			"Guarded",
			"GUARDD",
			"The site associated to the specific control-feature is being guarded so as to control entry or exit.");
	public static final ControlFeatureStatusSecurityStatusCode NOT_KNOWN = new ControlFeatureStatusSecurityStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ControlFeatureStatusSecurityStatusCode NONE = new ControlFeatureStatusSecurityStatusCode(
			"None",
			"NONE",
			"No special action has been taken to guarantee the safety of the site associated to the specific control feature.");
	public static final ControlFeatureStatusSecurityStatusCode SECURED = new ControlFeatureStatusSecurityStatusCode(
			"Secured",
			"SECURD",
			"The site associated to the specific control-feature is protected or safe.");

	private ControlFeatureStatusSecurityStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
