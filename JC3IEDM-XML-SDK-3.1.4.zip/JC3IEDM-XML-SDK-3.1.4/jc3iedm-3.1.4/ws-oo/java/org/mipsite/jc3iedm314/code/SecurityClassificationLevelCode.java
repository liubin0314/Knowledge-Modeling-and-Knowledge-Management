/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SecurityClassificationLevelCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the security classification level for the information resource.";
	}

	private static HashMap<String, SecurityClassificationLevelCode> physicalToCode = new HashMap<String, SecurityClassificationLevelCode>();

	public static SecurityClassificationLevelCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SecurityClassificationLevelCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SecurityClassificationLevelCode UNMARKED = new SecurityClassificationLevelCode(
			"Unmarked",
			"0",
			"The material or information is not associated with any security classification.");
	public static final SecurityClassificationLevelCode UNCLASSIFIED = new SecurityClassificationLevelCode(
			"Unclassified",
			"1",
			"Unauthorised disclosure would not be detrimental to the interests or effectiveness of the organisation referenced in the policy.");
	public static final SecurityClassificationLevelCode RESTRICTED = new SecurityClassificationLevelCode(
			"Restricted",
			"2",
			"Unauthorised disclosure would be detrimental to the interests or effectiveness of the organisation referenced in the policy.");
	public static final SecurityClassificationLevelCode CONFIDENTIAL = new SecurityClassificationLevelCode(
			"Confidential",
			"3",
			"Unauthorised disclosure would be damaging to the organisation referenced in the policy.");
	public static final SecurityClassificationLevelCode SECRET = new SecurityClassificationLevelCode(
			"Secret",
			"4",
			"Unauthorised disclosure would result in grave damage to the organisation referenced in the policy.");
	public static final SecurityClassificationLevelCode TOP_SECRET = new SecurityClassificationLevelCode(
			"Top secret",
			"5",
			"Unauthorised disclosure would result in exceptionally grave damage to the organisation referenced in the policy.");

	private SecurityClassificationLevelCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
