/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemStatusBoobyTrapPresenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific OBJECT-ITEM has been booby-trapped.";
	}

	private static HashMap<String, ObjectItemStatusBoobyTrapPresenceCode> physicalToCode = new HashMap<String, ObjectItemStatusBoobyTrapPresenceCode>();

	public static ObjectItemStatusBoobyTrapPresenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemStatusBoobyTrapPresenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemStatusBoobyTrapPresenceCode NO = new ObjectItemStatusBoobyTrapPresenceCode(
			"No",
			"NO",
			"The specific OBJECT-ITEM has not been booby-trapped.");
	public static final ObjectItemStatusBoobyTrapPresenceCode UNKNOWN = new ObjectItemStatusBoobyTrapPresenceCode(
			"Unknown",
			"UNK",
			"It is unknown if the specific OBJECT-ITEM has been booby-trapped.");
	public static final ObjectItemStatusBoobyTrapPresenceCode YES = new ObjectItemStatusBoobyTrapPresenceCode(
			"Yes",
			"YES",
			"The specific OBJECT-ITEM has been booby-trapped.");

	private ObjectItemStatusBoobyTrapPresenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
