/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveItemCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-OBJECTIVE-ITEM.";
	}

	private static HashMap<String, ActionObjectiveItemCategoryCode> physicalToCode = new HashMap<String, ActionObjectiveItemCategoryCode>();

	public static ActionObjectiveItemCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveItemCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveItemCategoryCode NOT_OTHERWISE_SPECIFIED = new ActionObjectiveItemCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionObjectiveItemCategoryCode TARGET = new ActionObjectiveItemCategoryCode(
			"TARGET",
			"TARGET",
			"An ACTION-OBJECTIVE-ITEM that is subject to capture, destruction or intelligence operations.");

	private ActionObjectiveItemCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
