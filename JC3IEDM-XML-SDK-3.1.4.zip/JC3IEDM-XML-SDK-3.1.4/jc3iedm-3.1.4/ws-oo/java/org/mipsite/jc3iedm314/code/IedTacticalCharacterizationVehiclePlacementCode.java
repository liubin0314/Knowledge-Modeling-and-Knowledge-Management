/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IedTacticalCharacterizationVehiclePlacementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether an IED is attached to the underside of a vehicle.";
	}

	private static HashMap<String, IedTacticalCharacterizationVehiclePlacementCode> physicalToCode = new HashMap<String, IedTacticalCharacterizationVehiclePlacementCode>();

	public static IedTacticalCharacterizationVehiclePlacementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IedTacticalCharacterizationVehiclePlacementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IedTacticalCharacterizationVehiclePlacementCode NO = new IedTacticalCharacterizationVehiclePlacementCode(
			"No",
			"OTUVMG",
			"An IED is placed elsewhere than on the underside of the vehicle.");
	public static final IedTacticalCharacterizationVehiclePlacementCode YES = new IedTacticalCharacterizationVehiclePlacementCode(
			"Yes",
			"OTUVNM",
			"An IED is placed on the underside of the vehicle.");
	public static final IedTacticalCharacterizationVehiclePlacementCode NOT_KNOWN = new IedTacticalCharacterizationVehiclePlacementCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private IedTacticalCharacterizationVehiclePlacementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
