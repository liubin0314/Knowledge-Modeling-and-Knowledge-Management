/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AmmunitionTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of AMMUNITION-TYPE.";
	}

	private static HashMap<String, AmmunitionTypeCategoryCode> physicalToCode = new HashMap<String, AmmunitionTypeCategoryCode>();

	public static AmmunitionTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AmmunitionTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AmmunitionTypeCategoryCode AIR_TO_AIR_MISSILE = new AmmunitionTypeCategoryCode(
			"Air-to-air missile",
			"AAMIS",
			"An air-launched guided missile for use against air targets.");
	public static final AmmunitionTypeCategoryCode AIR_LAUNCHED_MISSILE = new AmmunitionTypeCategoryCode(
			"Air launched missile",
			"ALMIS",
			"A self-propelled airborne munition that is guided automatically, or by remote control, fired from an aircraft.");
	public static final AmmunitionTypeCategoryCode AIR_TO_SURFACE_MISSILE = new AmmunitionTypeCategoryCode(
			"Air-to-surface missile",
			"ASMIS",
			"A self-propelled airborne munition which is guided automatically, or by remote control, fired from an aircraft at an object on the ground or sea.");
	public static final AmmunitionTypeCategoryCode ANTI_TANK_GUIDED_WEAPON = new AmmunitionTypeCategoryCode(
			"Anti-tank guided weapon",
			"ATGDWP",
			"A guided weapon designed to immobilise or destroy a tank.");
	public static final AmmunitionTypeCategoryCode BOMB = new AmmunitionTypeCategoryCode(
			"Bomb",
			"BOMB",
			"A case filled with explosive, inflammable material, poison gas, or smoke, etc., dropped from aircraft, or thrown or deposited by hand.");
	public static final AmmunitionTypeCategoryCode BOMBLET = new AmmunitionTypeCategoryCode(
			"Bomblet",
			"BOMBLT",
			"One of a number of small bombs usually contained in a cluster bomb and released in mid-air.");
	public static final AmmunitionTypeCategoryCode CRUISE_MISSILE = new AmmunitionTypeCategoryCode(
			"Cruise missile",
			"CRUMSL",
			"A weapon in the form of a pilotless jet aircraft carrying a warhead and capable of flying at low altitudes.");
	public static final AmmunitionTypeCategoryCode DEPTH_CHARGE = new AmmunitionTypeCategoryCode(
			"Depth charge",
			"DPTHCH",
			"Any charge designed for explosion under water, especially such a charge dropped or catapulted from delivery equipment and used against submarines.");
	public static final AmmunitionTypeCategoryCode EXPLOSIVE = new AmmunitionTypeCategoryCode(
			"Explosive",
			"EXPLOS",
			"An explosive substance.");
	public static final AmmunitionTypeCategoryCode GUN_SHELL = new AmmunitionTypeCategoryCode(
			"Gun shell",
			"GNSHEL",
			"A munition that is propelled from a barrel and thereafter follows a ballistic trajectory.");
	public static final AmmunitionTypeCategoryCode HAND_GRENADE = new AmmunitionTypeCategoryCode(
			"Hand grenade",
			"HNDGRN",
			"An explosive missile, smaller than a bombshell, thrown by hand.");
	public static final AmmunitionTypeCategoryCode MINE_ANTI_HELICOPTER = new AmmunitionTypeCategoryCode(
			"Mine, anti-helicopter",
			"MINAHL",
			"A mine designed to cause damage to helicopters.");
	public static final AmmunitionTypeCategoryCode MINE_ANTI_PERSONNEL = new AmmunitionTypeCategoryCode(
			"Mine, anti-personnel",
			"MINAPR",
			"A mine designed to cause casualties to personnel.");
	public static final AmmunitionTypeCategoryCode MINE_ANTI_TANK = new AmmunitionTypeCategoryCode(
			"Mine, anti-tank",
			"MINAT",
			"A mine designed to immobilise or destroy a tank.");
	public static final AmmunitionTypeCategoryCode MINE_ANTI_TANK_WITH_ANTI_HANDLING_DEVICE = new AmmunitionTypeCategoryCode(
			"Mine, anti-tank with anti-handling device",
			"MINATA",
			"A mine designed to immobilize or destroy a tank. The mine includes an internal or external device arranged to actuate it in case of attempts to deactivate the mine.");
	public static final AmmunitionTypeCategoryCode MINE_DEEP_MOORED = new AmmunitionTypeCategoryCode(
			"Mine, deep moored",
			"MINDPM",
			"Any mine case in more than a certain depth of water is deep.");
	public static final AmmunitionTypeCategoryCode MINE_MOORED = new AmmunitionTypeCategoryCode(
			"Mine, moored",
			"MINMOR",
			"A contact or influence-operated mine of positive buoyancy held below the surface by a mooring attached to a sinker or anchor on the bottom.");
	public static final AmmunitionTypeCategoryCode MINE_NOT_KNOWN = new AmmunitionTypeCategoryCode(
			"Mine, not known",
			"MINNKN",
			"It is not possible to determine the type of mine.");
	public static final AmmunitionTypeCategoryCode MINE_NOT_OTHERWISE_SPECIFIED = new AmmunitionTypeCategoryCode(
			"Mine, not otherwise specified",
			"MINNOS",
			"A mine whose appropriate value is not in the set of specified values.");
	public static final AmmunitionTypeCategoryCode MINE_OFF_ROUTE = new AmmunitionTypeCategoryCode(
			"Mine, off-route",
			"MINOFR",
			"A mine or mines designed to attack a target obliquely to the targets direction of travel (i.e. in the targets flank or side).");
	public static final AmmunitionTypeCategoryCode MINE_SEABED_EXPLOSIVE_CHARGE_500KG_OR_GREATER = new AmmunitionTypeCategoryCode(
			"Mine, seabed - explosive charge 500kg or greater",
			"MINSEG",
			"A mine with negative buoyancy which remains on the seabed with explosive charge of 500kg or greater.");
	public static final AmmunitionTypeCategoryCode MINE_SEABED_EXPLOSIVE_CHARGE_LESS_THAN_500KG = new AmmunitionTypeCategoryCode(
			"Mine, seabed - explosive charge less than 500kg",
			"MINSEL",
			"A mine with negative buoyancy which remains on the seabed with explosive charge less than 500kg.");
	public static final AmmunitionTypeCategoryCode MINE_SHALLOW_MOORED = new AmmunitionTypeCategoryCode(
			"Mine, shallow moored",
			"MINSHM",
			"Any mine case in less than a certain depth of water is shallow.");
	public static final AmmunitionTypeCategoryCode MINE_WIDE_AREA = new AmmunitionTypeCategoryCode(
			"Mine, wide area",
			"MINWAR",
			"A mine designed to disable armoured vehicles and will allow large areas to be sown with smart mines that should be difficult to neutralize.");
	public static final AmmunitionTypeCategoryCode MISSILE_ANTI_RADIATION = new AmmunitionTypeCategoryCode(
			"Missile, anti-radiation",
			"MISATR",
			"A missile that homes passively on a radiation source.");
	public static final AmmunitionTypeCategoryCode MISSILE_GUIDED = new AmmunitionTypeCategoryCode(
			"Missile, guided",
			"MISGUI",
			"An unmanned self-propelled vehicle whose trajectory or course, while in flight, is controlled.");
	public static final AmmunitionTypeCategoryCode MINE_MARITIME_MOVING = new AmmunitionTypeCategoryCode(
			"Mine, maritime, moving",
			"MNMRTM",
			"A mine designed to be propelled to its proposed laying position by propulsion equipment like a torpedo. It sinks at the end of its run and then operates like a mine.");
	public static final AmmunitionTypeCategoryCode MARITIME_MINE_DISPOSAL_CHARGE = new AmmunitionTypeCategoryCode(
			"Maritime mine disposal charge",
			"MRTMDC",
			"An explosive charge that is used to destroy a mine.");
	public static final AmmunitionTypeCategoryCode MORTAR_BOMB = new AmmunitionTypeCategoryCode(
			"Mortar bomb",
			"MRTRBM",
			"A round fired from a mortar weapon.");
	public static final AmmunitionTypeCategoryCode MOVING_MINE_SEA = new AmmunitionTypeCategoryCode(
			"Moving mine, sea",
			"MVSEAM",
			"The collective description of mines, such as drifting, oscillating, creeping, mobile, rising, homing and bouquet mines.");
	public static final AmmunitionTypeCategoryCode NOT_KNOWN = new AmmunitionTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AmmunitionTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new AmmunitionTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AmmunitionTypeCategoryCode PROJECTILE_NOT_OTHERWISE_SPECIFIED = new AmmunitionTypeCategoryCode(
			"Projectile, not otherwise specified",
			"PRJNOS",
			"An object capable of being propelled by a force normally from a gun, and continuing in motion by virtue of its kinetic energy.");
	public static final AmmunitionTypeCategoryCode PROXIMITY_FUSE = new AmmunitionTypeCategoryCode(
			"Proximity fuse",
			"PRXFUS",
			"A fuse wherein primary initiation occurs by remotely sensing the presence, distance or direction of a target or its associated environment by means of a signal generated by the fuse or emitted by the target, or by detecting a disturbance of a natural field surrounding the target.");
	public static final AmmunitionTypeCategoryCode PYROTECHNIC_DEVICE = new AmmunitionTypeCategoryCode(
			"Pyrotechnic device",
			"PYROTC",
			"A mixture of chemicals which when ignited is capable of reacting exothermically to produce light, heat, smoke, sound or gas, and may also be used to introduce a delay into an explosive train because of its known burning time.");
	public static final AmmunitionTypeCategoryCode ROCKET = new AmmunitionTypeCategoryCode(
			"Rocket",
			"RCKET",
			"A munition that is self-propelled in flight whose trajectory or course whilst in flight cannot be controlled.");
	public static final AmmunitionTypeCategoryCode ROCKET_MISSILE_ANTI_PERSONNEL = new AmmunitionTypeCategoryCode(
			"Rocket/missile, anti-personnel",
			"RKTATP",
			"A powered projectile designed for use against people.");
	public static final AmmunitionTypeCategoryCode ROCKET_MISSILE_ANTI_TANK = new AmmunitionTypeCategoryCode(
			"Rocket/missile, anti-tank",
			"RKTATT",
			"A powered projectile designed for use against tanks.");
	public static final AmmunitionTypeCategoryCode ROCKET_MISSILE_HEAVY = new AmmunitionTypeCategoryCode(
			"Rocket/missile, heavy",
			"RKTHEV",
			"A powered projectile designed for use by heavy launchers.");
	public static final AmmunitionTypeCategoryCode ROCKET_MISSILE_LIGHT = new AmmunitionTypeCategoryCode(
			"Rocket/missile, light",
			"RKTLGT",
			"A powered projectile designed for use by light launchers.");
	public static final AmmunitionTypeCategoryCode ROCKET_MISSILE_MEDIUM = new AmmunitionTypeCategoryCode(
			"Rocket/missile, medium",
			"RKTMED",
			"A powered projectile designed for use by medium launchers.");
	public static final AmmunitionTypeCategoryCode ROCKET_PROPELLED_GRENADE = new AmmunitionTypeCategoryCode(
			"Rocket propelled grenade",
			"RPG",
			"An unguided rocket equipped with an explosive warhead.");
	public static final AmmunitionTypeCategoryCode SEABED_MINE = new AmmunitionTypeCategoryCode(
			"Seabed mine",
			"SEABDM",
			"A mine with negative buoyancy, which remains on the seabed. (bottom mine)");
	public static final AmmunitionTypeCategoryCode SEA_MINE = new AmmunitionTypeCategoryCode(
			"Sea mine",
			"SEAMIN",
			"An explosive device laid in the water with the intention of damaging or sinking ships or of deterring shipping from entering an area.");
	public static final AmmunitionTypeCategoryCode SHAPED_CHARGE = new AmmunitionTypeCategoryCode(
			"Shaped charge",
			"SHPCHG",
			"A charge shaped so as to concentrate its explosive force in a particular direction.");
	public static final AmmunitionTypeCategoryCode SMALL_ARMS_AMMUNITION = new AmmunitionTypeCategoryCode(
			"Small-arms ammunition",
			"SMAMMO",
			"Ammunition designed for hand held weapons.");
	public static final AmmunitionTypeCategoryCode SURFACE_TO_AIR_MISSILE = new AmmunitionTypeCategoryCode(
			"Surface-to-air missile",
			"SRAMIS",
			"A self-propelled airborne munition which is guided automatically, or by remote control, fired from the ground or vessel at an aircraft or other airborne target.");
	public static final AmmunitionTypeCategoryCode SURFACE_TO_SURFACE_MISSILE = new AmmunitionTypeCategoryCode(
			"Surface-to-surface missile",
			"SRSMIS",
			"A self-propelled airborne munition which is guided automatically, or by remote control, fired from the ground or vessel at an object on the ground or sea.");
	public static final AmmunitionTypeCategoryCode SUBMUNITION = new AmmunitionTypeCategoryCode(
			"Submunition",
			"SUBMUN",
			"Any munition that, to perform its task, separates from a parent munition.");
	public static final AmmunitionTypeCategoryCode TORPEDO = new AmmunitionTypeCategoryCode(
			"Torpedo",
			"TRPEDO",
			"A weapon for destroying ships by rupturing their hulls below the waterline.");

	private AmmunitionTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
