/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FeatureTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of FEATURE-TYPE.";
	}

	private static HashMap<String, FeatureTypeCategoryCode> physicalToCode = new HashMap<String, FeatureTypeCategoryCode>();

	public static FeatureTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FeatureTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FeatureTypeCategoryCode CONTROL_FEATURE_TYPE = new FeatureTypeCategoryCode(
			"CONTROL-FEATURE-TYPE",
			"CF",
			"A non-tangible FEATURE-TYPE of military interest that may be represented as a geometric figure and is associated with the conduct of military operations.");
	public static final FeatureTypeCategoryCode GEOGRAPHIC_FEATURE_TYPE = new FeatureTypeCategoryCode(
			"GEOGRAPHIC-FEATURE-TYPE",
			"GF",
			"A FEATURE-TYPE that describes terrain characteristics to which military significance is attached.");
	public static final FeatureTypeCategoryCode METEOROLOGIC_FEATURE_TYPE = new FeatureTypeCategoryCode(
			"Meteorologic feature type",
			"MF",
			"A FEATURE-TYPE that describes reported or forecast weather and light conditions.");
	public static final FeatureTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new FeatureTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private FeatureTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
