/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ModeOfTransportationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the mode of transportation of a specific ROUTE-SEGMENT.";
	}

	private static HashMap<String, ModeOfTransportationCode> physicalToCode = new HashMap<String, ModeOfTransportationCode>();

	public static ModeOfTransportationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ModeOfTransportationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ModeOfTransportationCode AIR = new ModeOfTransportationCode(
			"Air",
			"AIR",
			"Represents the general mode of transportation used in movement by air.");
	public static final ModeOfTransportationCode INLAND_WATERWAY = new ModeOfTransportationCode(
			"Inland waterway",
			"IWT",
			"Represents the general mode of transportation used in movement by inland waterways.");
	public static final ModeOfTransportationCode MULTI_MODE = new ModeOfTransportationCode(
			"Multi mode",
			"MULTI",
			"Represents transportation utilizing more than one mode of transportation.");
	public static final ModeOfTransportationCode PIPELINE = new ModeOfTransportationCode(
			"Pipeline",
			"PIPE",
			"Represents the mode of transportation of materiel by pipeline.");
	public static final ModeOfTransportationCode RAIL = new ModeOfTransportationCode(
			"Rail",
			"RAIL",
			"Represents the general mode of transportation used in surface movement by rail.");
	public static final ModeOfTransportationCode ROAD = new ModeOfTransportationCode(
			"Road",
			"ROAD",
			"Represents the general mode of transportation used in surface movement by road.");
	public static final ModeOfTransportationCode SEA = new ModeOfTransportationCode(
			"Sea",
			"SEA",
			"Represents the general mode of transportation used in movement by sea.");
	public static final ModeOfTransportationCode TERRAIN = new ModeOfTransportationCode(
			"Terrain",
			"TERR",
			"Represents the general mode of transportation used in surface movement other than road and rail.");

	private ModeOfTransportationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
