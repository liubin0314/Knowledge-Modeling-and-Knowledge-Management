/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeDepthPlacementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the intended depth placement of maritime mines.";
	}

	private static HashMap<String, MinefieldMaritimeDepthPlacementCode> physicalToCode = new HashMap<String, MinefieldMaritimeDepthPlacementCode>();

	public static MinefieldMaritimeDepthPlacementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeDepthPlacementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeDepthPlacementCode BOTTOM = new MinefieldMaritimeDepthPlacementCode(
			"Bottom",
			"BOTTOM",
			"A minefield placed on the sea bottom.");
	public static final MinefieldMaritimeDepthPlacementCode NOT_KNOWN = new MinefieldMaritimeDepthPlacementCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MinefieldMaritimeDepthPlacementCode SURFACE = new MinefieldMaritimeDepthPlacementCode(
			"Surface",
			"SEASUR",
			"A minefield on the sea surface.");
	public static final MinefieldMaritimeDepthPlacementCode SURF_ZONE = new MinefieldMaritimeDepthPlacementCode(
			"Surf zone",
			"SURFZN",
			"A minefield placed in the surf zone.");
	public static final MinefieldMaritimeDepthPlacementCode VOLUME = new MinefieldMaritimeDepthPlacementCode(
			"Volume",
			"VOLUME",
			"A minefield suspended between the sea surface and the bottom.");

	private MinefieldMaritimeDepthPlacementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
