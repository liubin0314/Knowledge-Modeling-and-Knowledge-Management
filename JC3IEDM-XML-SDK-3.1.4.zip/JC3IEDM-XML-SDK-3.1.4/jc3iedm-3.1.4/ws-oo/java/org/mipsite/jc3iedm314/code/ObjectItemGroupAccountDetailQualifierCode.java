/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemGroupAccountDetailQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that describes the condition of the group counted in a specific OBJECT-ITEM-GROUP-ACCOUNT-DETAIL.";
	}

	private static HashMap<String, ObjectItemGroupAccountDetailQualifierCode> physicalToCode = new HashMap<String, ObjectItemGroupAccountDetailQualifierCode>();

	public static ObjectItemGroupAccountDetailQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemGroupAccountDetailQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemGroupAccountDetailQualifierCode AILING = new ObjectItemGroupAccountDetailQualifierCode(
			"Ailing",
			"AILING",
			"The objects included in the grouping are deemed to be suffering from an ailment whose specific basis has not been established.");
	public static final ObjectItemGroupAccountDetailQualifierCode ASSUMED_KILLED_IN_ACTION = new ObjectItemGroupAccountDetailQualifierCode(
			"Assumed killed in action",
			"ASSKIA",
			"The objects included in the grouping are assumed to be killed in action.");
	public static final ObjectItemGroupAccountDetailQualifierCode AWAITING_PICKUP = new ObjectItemGroupAccountDetailQualifierCode(
			"Awaiting pickup",
			"AWTNPU",
			"The objects included in the grouping are awaiting search and rescue pickup.");
	public static final ObjectItemGroupAccountDetailQualifierCode CAPTURED = new ObjectItemGroupAccountDetailQualifierCode(
			"Captured",
			"CAPTRD",
			"The objects included in the grouping are known to have been captured.");
	public static final ObjectItemGroupAccountDetailQualifierCode COMBAT_STRESS = new ObjectItemGroupAccountDetailQualifierCode(
			"Combat stress",
			"COMSTR",
			"The objects included in the grouping are deemed to be suffering from combat stress.");
	public static final ObjectItemGroupAccountDetailQualifierCode CAPTURE_APPEARS_IMMINENT = new ObjectItemGroupAccountDetailQualifierCode(
			"Capture appears imminent",
			"CPTRAI",
			"The objects included in the grouping were observed in or near the vicinity of the enemy.");
	public static final ObjectItemGroupAccountDetailQualifierCode DESERTED = new ObjectItemGroupAccountDetailQualifierCode(
			"Deserted",
			"DESRTD",
			"The objects included in the grouping are known to have deserted from the assigned organisation.");
	public static final ObjectItemGroupAccountDetailQualifierCode DETACHED = new ObjectItemGroupAccountDetailQualifierCode(
			"Detached",
			"DETD",
			"The objects included in the grouping are performing tasks separate from the assigned organisation.");
	public static final ObjectItemGroupAccountDetailQualifierCode DISEASED = new ObjectItemGroupAccountDetailQualifierCode(
			"Diseased",
			"DISEAS",
			"The objects included in the grouping are deemed to be diseased.");
	public static final ObjectItemGroupAccountDetailQualifierCode EVADING = new ObjectItemGroupAccountDetailQualifierCode(
			"Evading",
			"EVADNG",
			"The objects included in the grouping are on the ground and evading the enemy.");
	public static final ObjectItemGroupAccountDetailQualifierCode HEALTHY = new ObjectItemGroupAccountDetailQualifierCode(
			"Healthy",
			"HEALTH",
			"The objects included in the grouping are deemed to be healthy.");
	public static final ObjectItemGroupAccountDetailQualifierCode INJURED_WOUNDED = new ObjectItemGroupAccountDetailQualifierCode(
			"Injured/wounded",
			"INJRDW",
			"The objects included in the grouping are deemed to be injured or wounded.");
	public static final ObjectItemGroupAccountDetailQualifierCode KILLED_IN_ACTION = new ObjectItemGroupAccountDetailQualifierCode(
			"Killed in action",
			"KIA",
			"The objects included in the grouping were killed in action.");
	public static final ObjectItemGroupAccountDetailQualifierCode KILLED = new ObjectItemGroupAccountDetailQualifierCode(
			"Killed",
			"KILL",
			"The objects included in the grouping are deemed to have been killed under circumstances other than military action.");
	public static final ObjectItemGroupAccountDetailQualifierCode MISSING_IN_ACTION = new ObjectItemGroupAccountDetailQualifierCode(
			"Missing in action",
			"MIA",
			"The objects included in the grouping are deemed to be missing in action.");
	public static final ObjectItemGroupAccountDetailQualifierCode MISSING = new ObjectItemGroupAccountDetailQualifierCode(
			"Missing",
			"MIS",
			"The objects included in the grouping are deemed to be missing and the reason for absence is not known.");
	public static final ObjectItemGroupAccountDetailQualifierCode NO_CHUTES = new ObjectItemGroupAccountDetailQualifierCode(
			"No chutes",
			"NOCHUT",
			"The aircraft has crashed, but no parachute(s) were sighted.");
	public static final ObjectItemGroupAccountDetailQualifierCode PARACHUTED = new ObjectItemGroupAccountDetailQualifierCode(
			"Parachuted",
			"PARCHT",
			"The objects included in the grouping were observed parachuting from the plane prior to destruction or impact.");
	public static final ObjectItemGroupAccountDetailQualifierCode PROBABLE_CAPTURED = new ObjectItemGroupAccountDetailQualifierCode(
			"Probable captured",
			"PRBCPT",
			"The objects included in the grouping are probably captured.");
	public static final ObjectItemGroupAccountDetailQualifierCode RESCUED = new ObjectItemGroupAccountDetailQualifierCode(
			"Rescued",
			"RESCUD",
			"The objects included in the grouping were rescued.");
	public static final ObjectItemGroupAccountDetailQualifierCode SAFE_FROM_CAPTURE = new ObjectItemGroupAccountDetailQualifierCode(
			"Safe from capture",
			"SAFCPT",
			"The objects included in the grouping are not to be in or near the vicinity of the enemy.");
	public static final ObjectItemGroupAccountDetailQualifierCode UNKNOWN = new ObjectItemGroupAccountDetailQualifierCode(
			"Unknown",
			"UNK",
			"Disposition of the objects included in the grouping is unknown.");

	private ObjectItemGroupAccountDetailQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
