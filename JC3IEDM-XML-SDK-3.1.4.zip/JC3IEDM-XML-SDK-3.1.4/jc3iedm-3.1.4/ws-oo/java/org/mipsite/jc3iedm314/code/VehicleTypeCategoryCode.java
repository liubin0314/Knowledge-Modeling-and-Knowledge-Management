/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class VehicleTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of VEHICLE-TYPE.";
	}

	private static HashMap<String, VehicleTypeCategoryCode> physicalToCode = new HashMap<String, VehicleTypeCategoryCode>();

	public static VehicleTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<VehicleTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final VehicleTypeCategoryCode ARMOURED_C2V_ACV = new VehicleTypeCategoryCode(
			"Armoured C2V/ACV",
			"ACVACV",
			"An Armoured Command and Control Vehicle (C2V) or an Armoured Combat Vehicle (ACV).");
	public static final VehicleTypeCategoryCode AMBULANCE = new VehicleTypeCategoryCode(
			"Ambulance",
			"AMBUL",
			"A vehicle for conveying sick, wounded, incapacitated, or injured persons.");
	public static final VehicleTypeCategoryCode AMPHIBIAN = new VehicleTypeCategoryCode(
			"Amphibian",
			"AMPH",
			"A vehicle designed to travel over land and on water.");
	public static final VehicleTypeCategoryCode ARMOURED_PERSONNEL_CARRIER = new VehicleTypeCategoryCode(
			"Armoured personnel carrier",
			"APC",
			"A lightly armoured, highly mobile vehicle, amphibious and air-droppable, used primarily for transporting personnel and their individual equipment during tactical operations.");
	public static final VehicleTypeCategoryCode ARMOURED_PERSONNEL_CARRIER_RECOVERY = new VehicleTypeCategoryCode(
			"Armoured personnel carrier, recovery",
			"APCREC",
			"A vehicle designed to recover armoured personnel carriers.");
	public static final VehicleTypeCategoryCode ARMOURED = new VehicleTypeCategoryCode(
			"Armoured",
			"ARMORD",
			"A vehicle that has some form of ballistic protection (excluding tanks).");
	public static final VehicleTypeCategoryCode ARMOURED_RECONNAISSANCE_CARRIER = new VehicleTypeCategoryCode(
			"Armoured reconnaissance carrier",
			"ARMRCC",
			"An armoured vehicle used to carry persons for reconnaissance activities.");
	public static final VehicleTypeCategoryCode ARMOURED_VEHICLE_LIGHT = new VehicleTypeCategoryCode(
			"Armoured vehicle, light",
			"ARVELT",
			"An armoured vehicle with less armour that uses its increased mobility and possibly more lethal armaments for survivability.");
	public static final VehicleTypeCategoryCode ARMOURED_SERVICE_SUPPORT = new VehicleTypeCategoryCode(
			"Armoured service support",
			"ASSV",
			"An armoured vehicle mainly used for maintenance, recovery, ambulance functions or resupply.");
	public static final VehicleTypeCategoryCode ASSAULT_VEHICLE = new VehicleTypeCategoryCode(
			"Assault vehicle",
			"ASSVEH",
			"A vehicle designed to carry assault troops.");
	public static final VehicleTypeCategoryCode AUTOMOBILE = new VehicleTypeCategoryCode(
			"Automobile",
			"AUTOMO",
			"A self-propelled passenger vehicle.");
	public static final VehicleTypeCategoryCode BICYCLE = new VehicleTypeCategoryCode(
			"Bicycle",
			"BICYCL",
			"A vehicle of two wheels held in a frame one behind the other, propelled by pedals and steered with handlebars attached to the front wheel.");
	public static final VehicleTypeCategoryCode BATTLE_TANK_HEAVY_RECOVERY = new VehicleTypeCategoryCode(
			"Battle tank, heavy, recovery",
			"BTHVRE",
			"A vehicle designed to recover heavy weight battle tanks.");
	public static final VehicleTypeCategoryCode BATTLE_TANK_LIGHT_RECOVERY = new VehicleTypeCategoryCode(
			"Battle tank, light recovery",
			"BTLTRE",
			"A vehicle designed to recover light weight battle tanks.");
	public static final VehicleTypeCategoryCode BATTLE_TANK_MEDIUM_RECOVERY = new VehicleTypeCategoryCode(
			"Battle tank, medium, recovery",
			"BTMDRE",
			"A vehicle designed to recover medium weight battle tanks.");
	public static final VehicleTypeCategoryCode BUS = new VehicleTypeCategoryCode(
			"Bus",
			"BUS",
			"A large passenger road vehicle.");
	public static final VehicleTypeCategoryCode CART = new VehicleTypeCategoryCode(
			"Cart",
			"CART",
			"A non self-propelled vehicle with two or four wheels for carrying loads.");
	public static final VehicleTypeCategoryCode CROSS_COUNTRY_TRUCK = new VehicleTypeCategoryCode(
			"Cross-country truck",
			"CCTRCK",
			"An automotive vehicle designed to be used off road for transporting loads.");
	public static final VehicleTypeCategoryCode COMBAT_ENGINEER_VEHICLE = new VehicleTypeCategoryCode(
			"Combat engineer vehicle",
			"CEVEH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final VehicleTypeCategoryCode COMMAND_POST = new VehicleTypeCategoryCode(
			"Command post",
			"CMDPST",
			"A vehicle designed to be used as a command post or as part of a command post.");
	public static final VehicleTypeCategoryCode COMMAND_POST_ARMOURED = new VehicleTypeCategoryCode(
			"Command post, armoured",
			"CMDPTA",
			"An armoured vehicle designed to be used as a command post or as part of a command post.");
	public static final VehicleTypeCategoryCode COMMAND_POST_WHEELED = new VehicleTypeCategoryCode(
			"Command post, wheeled",
			"CMDPTW",
			"A wheeled, non-armoured vehicle, designed to be used as a command post or as part of a command post.");
	public static final VehicleTypeCategoryCode COMBAT_SUPPORT_VEHICLE = new VehicleTypeCategoryCode(
			"Combat support vehicle",
			"CSVEH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final VehicleTypeCategoryCode ENGINEERING_NOT_OTHERWISE_SPECIFIED = new VehicleTypeCategoryCode(
			"Engineering, not otherwise specified",
			"ENGNOS",
			"A vehicle used by engineers, without any other precision.");
	public static final VehicleTypeCategoryCode FORKLIFT = new VehicleTypeCategoryCode(
			"Forklift",
			"FORKLF",
			"A vehicle with a horizontal fork in front for lifting and carrying loads.");
	public static final VehicleTypeCategoryCode FIREFIGHTING = new VehicleTypeCategoryCode(
			"Firefighting",
			"FRFGTN",
			"A large motor vehicle designed to carry fire-fighters and equipment to a fire and supports extinguishing operations.");
	public static final VehicleTypeCategoryCode GENERAL_PURPOSE = new VehicleTypeCategoryCode(
			"General purpose",
			"GNLPRP",
			"A vehicle designed for multiple uses.");
	public static final VehicleTypeCategoryCode HALF_TRACK = new VehicleTypeCategoryCode(
			"Half-track",
			"HALFTR",
			"A vehicle, usually military, with wheels in front and tracks in the rear.");
	public static final VehicleTypeCategoryCode HEAVY_EQUIPMENT_TRANSPORT = new VehicleTypeCategoryCode(
			"Heavy equipment transport",
			"HETVEH",
			"A vehicle designed to carry cumbersome or heavy items.");
	public static final VehicleTypeCategoryCode LANDING_VEHICLE = new VehicleTypeCategoryCode(
			"Landing vehicle",
			"LNDVEH",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1650/6.");
	public static final VehicleTypeCategoryCode MAINTENANCE = new VehicleTypeCategoryCode(
			"Maintenance",
			"MAINT",
			"A vehicle which, as its primary function, is designed to provide equipment support facilities in or out of the battlespace.");
	public static final VehicleTypeCategoryCode MATERIEL_HANDLING = new VehicleTypeCategoryCode(
			"Materiel handling",
			"MHVEH",
			"A vehicle which, as its primary, is designed to provide materiel handling facilities in or out of the battlespace.");
	public static final VehicleTypeCategoryCode MILITARY_UTILITY = new VehicleTypeCategoryCode(
			"Military utility",
			"MILUV",
			"A small, sturdy, four-wheel-drive army vehicle, used chiefly for reconnaissance; a similar vehicle in non-military use.");
	public static final VehicleTypeCategoryCode MOPED = new VehicleTypeCategoryCode(
			"Moped",
			"MOPED",
			"A motorized pedal cycle.");
	public static final VehicleTypeCategoryCode MOTORCYCLE = new VehicleTypeCategoryCode(
			"Motorcycle",
			"MOTCYC",
			"A vehicle with two wheels in tandem, self-propelled and sometimes having a sidecar with a third wheel.");
	public static final VehicleTypeCategoryCode NOT_KNOWN = new VehicleTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final VehicleTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new VehicleTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final VehicleTypeCategoryCode PACK_ANIMAL = new VehicleTypeCategoryCode(
			"Pack animal",
			"PACKAN",
			"An animal (such as a mule, donkey, camel or horse) with the role of transport used to carry loads.");
	public static final VehicleTypeCategoryCode SEMI = new VehicleTypeCategoryCode(
			"Semi",
			"SEMI",
			"A road trailer that has a wheel system at the rear only and is coupled to a suitable tractor to form an articulated lorry.");
	public static final VehicleTypeCategoryCode SNOWPLOUGH = new VehicleTypeCategoryCode(
			"Snowplough",
			"SNOWPL",
			"A vehicle designed to push snow aside.");
	public static final VehicleTypeCategoryCode SPECIAL_PURPOSE = new VehicleTypeCategoryCode(
			"Special purpose",
			"SPCPRP",
			"A vehicle specifically designed for special use.");
	public static final VehicleTypeCategoryCode TRACTOR = new VehicleTypeCategoryCode(
			"Tractor",
			"TRACTR",
			"A powered vehicle that pulls or draws machinery.");
	public static final VehicleTypeCategoryCode TRAILER = new VehicleTypeCategoryCode(
			"Trailer",
			"TRAILR",
			"A vehicle designed to be towed by another.");
	public static final VehicleTypeCategoryCode TRANSPORTER_GENERAL = new VehicleTypeCategoryCode(
			"Transporter, general",
			"TRANSG",
			"A vehicle whose primary role is the transportation of heavy equipment.");
	public static final VehicleTypeCategoryCode TRANSPORTER_TANK = new VehicleTypeCategoryCode(
			"Transporter, tank",
			"TRANST",
			"A vehicle whose primary role is the transportation of main battle tanks.");
	public static final VehicleTypeCategoryCode TROLLEY_BUS = new VehicleTypeCategoryCode(
			"Trolley bus",
			"TRLBUS",
			"A bus powered by electricity obtained from an overhead cable by means of a trolley-wheel.");
	public static final VehicleTypeCategoryCode TRUCK = new VehicleTypeCategoryCode(
			"Truck",
			"TRUCK",
			"An automotive vehicle used for transporting loads.");
	public static final VehicleTypeCategoryCode TRUCK_DUMP = new VehicleTypeCategoryCode(
			"Truck, dump",
			"TRUCKD",
			"A truck having a body that tilts and opens for unloading materials");
	public static final VehicleTypeCategoryCode UTILITY = new VehicleTypeCategoryCode(
			"Utility",
			"UTILTY",
			"A small, sturdy, four-wheel-drive vehicle, used chiefly for reconnaissance; a similar vehicle in non-military use.");
	public static final VehicleTypeCategoryCode VAN = new VehicleTypeCategoryCode(
			"Van",
			"VAN",
			"A covered motor vehicle, typically without side windows, used for transporting goods or people.");
	public static final VehicleTypeCategoryCode WRECKER = new VehicleTypeCategoryCode(
			"Wrecker",
			"WRCKR",
			"A vehicle used in recovering a damaged one.");

	private VehicleTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
