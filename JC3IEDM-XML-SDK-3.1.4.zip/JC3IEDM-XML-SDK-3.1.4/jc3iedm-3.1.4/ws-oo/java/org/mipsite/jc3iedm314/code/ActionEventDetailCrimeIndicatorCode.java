/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEventDetailCrimeIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes a judgement whether a specific event is a crime or not.";
	}

	private static HashMap<String, ActionEventDetailCrimeIndicatorCode> physicalToCode = new HashMap<String, ActionEventDetailCrimeIndicatorCode>();

	public static ActionEventDetailCrimeIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEventDetailCrimeIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEventDetailCrimeIndicatorCode NO = new ActionEventDetailCrimeIndicatorCode(
			"No",
			"NO",
			"The event is not considered to be a crime.");
	public static final ActionEventDetailCrimeIndicatorCode YES = new ActionEventDetailCrimeIndicatorCode(
			"Yes",
			"YES",
			"The event is considered to be a crime.");

	private ActionEventDetailCrimeIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
