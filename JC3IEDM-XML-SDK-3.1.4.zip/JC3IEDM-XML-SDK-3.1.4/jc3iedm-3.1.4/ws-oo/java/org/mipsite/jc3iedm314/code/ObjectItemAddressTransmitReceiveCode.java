/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemAddressTransmitReceiveCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the OBJECT-ITEM usage of an ELECTRONIC-ADDRESS in terms of transmission and reception.";
	}

	private static HashMap<String, ObjectItemAddressTransmitReceiveCode> physicalToCode = new HashMap<String, ObjectItemAddressTransmitReceiveCode>();

	public static ObjectItemAddressTransmitReceiveCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemAddressTransmitReceiveCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemAddressTransmitReceiveCode RECEIVE = new ObjectItemAddressTransmitReceiveCode(
			"Receive",
			"RECEIV",
			"The specific ELECTRONIC-ADDRESS is used only for reception purposes with respect to the specific OBJECT-ITEM.");
	public static final ObjectItemAddressTransmitReceiveCode TRANSMIT_AND_RECEIVE = new ObjectItemAddressTransmitReceiveCode(
			"Transmit and receive",
			"TRNREC",
			"The specific ELECTRONIC-ADDRESS is used both for transmission and reception purposes with respect to the specific OBJECT-ITEM.");
	public static final ObjectItemAddressTransmitReceiveCode TRANSMIT = new ObjectItemAddressTransmitReceiveCode(
			"Transmit",
			"TRNSMT",
			"The specific ELECTRONIC-ADDRESS is used only for transmission purposes with respect to the specific OBJECT-ITEM.");

	private ObjectItemAddressTransmitReceiveCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
