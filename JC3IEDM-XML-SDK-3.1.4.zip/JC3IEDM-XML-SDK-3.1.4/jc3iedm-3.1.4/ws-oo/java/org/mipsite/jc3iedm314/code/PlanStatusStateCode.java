/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanStatusStateCode extends CodeDomain {

	public static String getComment() {
		return "The specific value assigned to represent the condition for a specific PLAN.";
	}

	private static HashMap<String, PlanStatusStateCode> physicalToCode = new HashMap<String, PlanStatusStateCode>();

	public static PlanStatusStateCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanStatusStateCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanStatusStateCode APPROVED = new PlanStatusStateCode(
			"Approved",
			"APPRVD",
			"A state of a specific PLAN that allows sub-units to initiate their own planning processes.");
	public static final PlanStatusStateCode CANCELLED = new PlanStatusStateCode(
			"Cancelled",
			"CANCEL",
			"A state of a specific PLAN to indicate that the PLAN will not be used or further developed.");
	public static final PlanStatusStateCode WITHDRAWN = new PlanStatusStateCode(
			"Withdrawn",
			"WTHDRN",
			"A state of a specific PLAN that permits the PLAN to be edited.");

	private PlanStatusStateCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
