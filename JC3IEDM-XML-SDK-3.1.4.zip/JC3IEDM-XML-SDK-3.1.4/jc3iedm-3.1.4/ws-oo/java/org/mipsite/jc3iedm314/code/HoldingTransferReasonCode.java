/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HoldingTransferReasonCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that characterises the basis for a specific HOLDING-TRANSFER.";
	}

	private static HashMap<String, HoldingTransferReasonCode> physicalToCode = new HashMap<String, HoldingTransferReasonCode>();

	public static HoldingTransferReasonCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HoldingTransferReasonCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HoldingTransferReasonCode DESTROYED_OR_LOST = new HoldingTransferReasonCode(
			"Destroyed or lost",
			"DSTRYD",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that has been destroyed or lost.");
	public static final HoldingTransferReasonCode FIXED_TERM_LOAN = new HoldingTransferReasonCode(
			"Fixed-term loan",
			"FXDTRM",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is lent to the receiving OBJECT-ITEM for a period with a fixed term.");
	public static final HoldingTransferReasonCode INDEFINITE_LOAN = new HoldingTransferReasonCode(
			"Indefinite loan",
			"INDFLN",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is lent to the receiving OBJECT-ITEM for an indefinite period.");
	public static final HoldingTransferReasonCode ISSUE = new HoldingTransferReasonCode(
			"Issue",
			"ISSUE",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is issued to the receiving OBJECT-ITEM as a user.");
	public static final HoldingTransferReasonCode NOT_OTHERWISE_SPECIFIED = new HoldingTransferReasonCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final HoldingTransferReasonCode PERMANENT_TRANSFER = new HoldingTransferReasonCode(
			"Permanent transfer",
			"PRMTRF",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is issued to the receiving OBJECT-ITEM as permanent custodian.");
	public static final HoldingTransferReasonCode RETURN_TO_CUSTODIAN = new HoldingTransferReasonCode(
			"Return to custodian",
			"RTNCST",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is returned to the receiving OBJECT-ITEM as the custodian.");
	public static final HoldingTransferReasonCode SCHEDULED_SUPPLY = new HoldingTransferReasonCode(
			"Scheduled supply",
			"SCHSPL",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is scheduled for delivery to the receiving OBJECT-ITEM as the user.");
	public static final HoldingTransferReasonCode SCRAPPED = new HoldingTransferReasonCode(
			"Scrapped",
			"SCRPPD",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is being scrapped and removed from the custodian�s responsibility.");
	public static final HoldingTransferReasonCode TOTAL_DUE_IN = new HoldingTransferReasonCode(
			"Total due in",
			"TOTDIN",
			"The perceived count in a specific HOLDING represents OBJECT-TYPEs that are expected to be received.");
	public static final HoldingTransferReasonCode TOTAL_DUE_OUT = new HoldingTransferReasonCode(
			"Total due out",
			"TOTDOT",
			"The perceived count in a specific HOLDING represents OBJECT-TYPEs that are expected to be transferred out.");
	public static final HoldingTransferReasonCode TRANSFER_FOR_MAINTENANCE = new HoldingTransferReasonCode(
			"Transfer for maintenance",
			"TRFMNT",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is sent to the receiving OBJECT-ITEM in order to perform maintenance.");
	public static final HoldingTransferReasonCode TRANSFER_FOR_TRANSPORTATION = new HoldingTransferReasonCode(
			"Transfer for transportation",
			"TRFTRN",
			"The specific HOLDING-TRANSFER represents an OBJECT-TYPE that is sent to the receiving OBJECT-ITEM as the custodian during transportation operations.");

	private HoldingTransferReasonCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
