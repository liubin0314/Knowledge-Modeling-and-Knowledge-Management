/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusReserveIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether a specific ORGANISATION has been placed in reserve.";
	}

	private static HashMap<String, OrganisationStatusReserveIndicatorCode> physicalToCode = new HashMap<String, OrganisationStatusReserveIndicatorCode>();

	public static OrganisationStatusReserveIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusReserveIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusReserveIndicatorCode NO = new OrganisationStatusReserveIndicatorCode(
			"No",
			"NO",
			"The specific ORGANISATION is not in reserve status.");
	public static final OrganisationStatusReserveIndicatorCode YES = new OrganisationStatusReserveIndicatorCode(
			"Yes",
			"YES",
			"The specific ORGANISATION is currently in reserve status.");

	private OrganisationStatusReserveIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
