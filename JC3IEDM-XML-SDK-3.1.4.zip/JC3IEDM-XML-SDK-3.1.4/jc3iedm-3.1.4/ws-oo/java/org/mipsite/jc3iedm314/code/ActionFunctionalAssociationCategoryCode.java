/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionFunctionalAssociationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of relationship of subject ACTION to object ACTION.";
	}

	private static HashMap<String, ActionFunctionalAssociationCategoryCode> physicalToCode = new HashMap<String, ActionFunctionalAssociationCategoryCode>();

	public static ActionFunctionalAssociationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionFunctionalAssociationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionFunctionalAssociationCategoryCode IS_AN_ALTERNATIVE_TO = new ActionFunctionalAssociationCategoryCode(
			"Is an alternative to",
			"ALT",
			"The subject ACTION may replace the object ACTION.");
	public static final ActionFunctionalAssociationCategoryCode HAS_AS_A_PROVISIONAL_SUB_ACTION = new ActionFunctionalAssociationCategoryCode(
			"Has as a provisional sub-ACTION",
			"HASPRV",
			"The subject ACTION may be re-directed to an alternative object ACTION. Note: The need for object ACTION is foreseen in planning, but its execution depends on external circumstances.");
	public static final ActionFunctionalAssociationCategoryCode HAS_AS_SECONDARY = new ActionFunctionalAssociationCategoryCode(
			"Has as secondary",
			"HASSEC",
			"The subject ACTION is designated as the primary activity and has the object ACTION as a secondary activity.");
	public static final ActionFunctionalAssociationCategoryCode HAS_AS_A_SUB_ACTION = new ActionFunctionalAssociationCategoryCode(
			"Has as a sub-ACTION",
			"HSA",
			"The value that links two activities such that the subject ACTION has as a sub-ACTION the object ACTION.");
	public static final ActionFunctionalAssociationCategoryCode IS_A_MODIFICATION_OF = new ActionFunctionalAssociationCategoryCode(
			"Is a modification of",
			"IMO",
			"The value denoting that the subject ACTION amends (or suggests an amendment to) an existing object ACTION (be it a plan, order, or request).");
	public static final ActionFunctionalAssociationCategoryCode IN_RESPONSE_TO = new ActionFunctionalAssociationCategoryCode(
			"In response to",
			"INRSTO",
			"The value that links two ACTIONs such that the subject ACTION is planned to be or may be expected to be carried out in reaction to the object ACTION.");
	public static final ActionFunctionalAssociationCategoryCode IN_ORDER_THAT = new ActionFunctionalAssociationCategoryCode(
			"In order that",
			"IOT",
			"The subject ACTION is to be carried out so that the conditions are established for the completion of the object ACTION (e.g., carrying out ACTION A so that ACTION B can then be carried out). (Note: This has no bearing on the temporal relationships between ACTIONs).");
	public static final ActionFunctionalAssociationCategoryCode IS_A_PREREQUISITE_FOR = new ActionFunctionalAssociationCategoryCode(
			"Is a prerequisite for",
			"ISAPRQ",
			"The subject ACTION must be completed as planned before the object ACTION may commence.");
	public static final ActionFunctionalAssociationCategoryCode IS_THE_CAUSE_OF = new ActionFunctionalAssociationCategoryCode(
			"Is the cause of",
			"ISCAUS",
			"The value denoting that the subject ACTION is the cause for the object ACTION. (Note: This is intended to be used only when the ACTION is an ACTION-EVENT).");
	public static final ActionFunctionalAssociationCategoryCode IS_A_TEMPLATE_FOR = new ActionFunctionalAssociationCategoryCode(
			"Is a template for",
			"TPL",
			"The subject ACTION constitutes an example that the object ACTION should conform to.");
	public static final ActionFunctionalAssociationCategoryCode USES_AS_A_REFERENCE = new ActionFunctionalAssociationCategoryCode(
			"Uses as a reference",
			"UAR",
			"The value that establishes a link between existing ACTIONs and new ACTIONs, be they requests, plans, or orders. (Note: The subject ACTION uses the specified object ACTION as a reference).");

	private ActionFunctionalAssociationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
