/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class WeaponTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of WEAPON-TYPE.";
	}

	private static HashMap<String, WeaponTypeCategoryCode> physicalToCode = new HashMap<String, WeaponTypeCategoryCode>();

	public static WeaponTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<WeaponTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final WeaponTypeCategoryCode AIR_DEFENCE = new WeaponTypeCategoryCode(
			"Air-defence",
			"AD",
			"A weapon specifically designed for the engagement of aircraft.");
	public static final WeaponTypeCategoryCode ANTI_SUBMARINE = new WeaponTypeCategoryCode(
			"Anti-submarine",
			"ANTSUB",
			"A weapon specifically designed for the engagement of submarines.");
	public static final WeaponTypeCategoryCode ANTI_TANK = new WeaponTypeCategoryCode(
			"Anti-tank",
			"AT",
			"A weapon specifically designed for the engagement of armoured vehicles.");
	public static final WeaponTypeCategoryCode CANNON = new WeaponTypeCategoryCode(
			"Cannon",
			"CANNON",
			"A weapon for firing projectiles, having a heavy metal tube installed on a carriage or mounting.");
	public static final WeaponTypeCategoryCode FIELD_ARTILLERY = new WeaponTypeCategoryCode(
			"Field artillery",
			"FA",
			"Artillery that is self-propelled or towed for use in the field in support of manoeuvre forces.");
	public static final WeaponTypeCategoryCode MISSILE_SYSTEM = new WeaponTypeCategoryCode(
			"Missile system",
			"MISSYS",
			"A system designed to launch one or more powered guided objects at a target.");
	public static final WeaponTypeCategoryCode MORTAR = new WeaponTypeCategoryCode(
			"Mortar",
			"MORTAR",
			"A portable, muzzle-loading cannon used to fire shells at low velocities, short ranges, and high trajectories.");
	public static final WeaponTypeCategoryCode NOT_KNOWN = new WeaponTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final WeaponTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new WeaponTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final WeaponTypeCategoryCode ROCKET_ARTILLERY = new WeaponTypeCategoryCode(
			"Rocket artillery",
			"RCKART",
			"A system designed to launch one or more powered unguided objects at a target.");
	public static final WeaponTypeCategoryCode SMALL_ARMS = new WeaponTypeCategoryCode(
			"Small arms",
			"SMARMS",
			"Individual portable weapon for defensive purposes.");
	public static final WeaponTypeCategoryCode TANK = new WeaponTypeCategoryCode(
			"Tank",
			"TANK",
			"An armoured vehicle whose principal weapon is a direct fire gun optimised for the destruction of armoured vehicles.");

	private WeaponTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
