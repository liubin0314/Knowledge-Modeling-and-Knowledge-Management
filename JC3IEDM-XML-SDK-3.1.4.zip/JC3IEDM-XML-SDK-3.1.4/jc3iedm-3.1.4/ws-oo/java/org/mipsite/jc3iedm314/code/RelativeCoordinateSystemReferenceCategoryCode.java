/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RelativeCoordinateSystemReferenceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the source of the reference for defining the origin and axial directions for a specific RELATIVE-COORDINATE-SYSTEM.";
	}

	private static HashMap<String, RelativeCoordinateSystemReferenceCategoryCode> physicalToCode = new HashMap<String, RelativeCoordinateSystemReferenceCategoryCode>();

	public static RelativeCoordinateSystemReferenceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RelativeCoordinateSystemReferenceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RelativeCoordinateSystemReferenceCategoryCode OBJECT_REFERENCE = new RelativeCoordinateSystemReferenceCategoryCode(
			"OBJECT-REFERENCE",
			"OBJREF",
			"A RELATIVE-COORDINATE-SYSTEM that has its frame of reference defined by using the position and orientation of a specific OBJECT-ITEM at a given point in time.");
	public static final RelativeCoordinateSystemReferenceCategoryCode POINT_REFERENCE = new RelativeCoordinateSystemReferenceCategoryCode(
			"POINT-REFERENCE",
			"PNTREF",
			"A RELATIVE-COORDINATE-SYSTEM that uses three specific POINTs to establish its frame of reference.");

	private RelativeCoordinateSystemReferenceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
