/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class WindCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of WIND.";
	}

	private static HashMap<String, WindCategoryCode> physicalToCode = new HashMap<String, WindCategoryCode>();

	public static WindCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<WindCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final WindCategoryCode CONSTANT = new WindCategoryCode(
			"Constant",
			"CONST",
			"Winds that have a constant force.");
	public static final WindCategoryCode GUSTING = new WindCategoryCode(
			"Gusting",
			"GUST",
			"A rapid increase in the strength of the wind relative to the mean strength at the time.");
	public static final WindCategoryCode NOT_KNOWN = new WindCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final WindCategoryCode SQUALLS = new WindCategoryCode(
			"Squalls",
			"SQUAL",
			"A strong wind that rises suddenly, generally lasts for some minutes, and dies comparatively suddenly away. It is distinguished from a gust by its longer duration.");
	public static final WindCategoryCode TURBULENCE_EXTREME = new WindCategoryCode(
			"Turbulence, extreme",
			"TRBLEX",
			"Extreme turbulence is a transitory atmospheric condition that has varying effects on aircraft operations. It is a serious hazard to pilots that may occur without warning.");
	public static final WindCategoryCode TURBULENCE_LIGHT = new WindCategoryCode(
			"Turbulence, light",
			"TRBLLI",
			"Light turbulence is a transitory atmospheric condition that has varying effects on aircraft operations. It is a serious hazard to pilots that may occur without warning.");
	public static final WindCategoryCode TURBULENCE_MODERATE = new WindCategoryCode(
			"Turbulence, moderate",
			"TRBLMO",
			"Moderate turbulence is a transitory atmospheric condition that has varying effects on aircraft operations. It is a serious hazard to pilots that may occur without warning.");
	public static final WindCategoryCode TURBULENCE_SEVERE = new WindCategoryCode(
			"Turbulence, severe",
			"TRBLSE",
			"Severe turbulence is a transitory atmospheric condition that has varying effects on aircraft operations. It is a serious hazard to pilots that may occur without warning.");
	public static final WindCategoryCode VARIABLE = new WindCategoryCode(
			"Variable",
			"VRB",
			"Winds that have a variable force.");
	public static final WindCategoryCode WIND_SHEAR = new WindCategoryCode(
			"Wind shear",
			"WSHEAR",
			"A variation in wind velocity at right angles to the wind's direction.");

	private WindCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
