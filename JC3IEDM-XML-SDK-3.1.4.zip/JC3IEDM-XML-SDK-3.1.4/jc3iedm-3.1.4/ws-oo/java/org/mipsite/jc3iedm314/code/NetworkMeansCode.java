/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkMeansCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the physical linkage between the nodes of a specific NETWORK.";
	}

	private static HashMap<String, NetworkMeansCode> physicalToCode = new HashMap<String, NetworkMeansCode>();

	public static NetworkMeansCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkMeansCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkMeansCode CABLE = new NetworkMeansCode(
			"Cable",
			"CABLE",
			"A transmission means using electrical signals, typically through copper cable.");
	public static final NetworkMeansCode COAXIAL_CABLE = new NetworkMeansCode(
			"Coaxial cable",
			"COAXCB",
			"A transmission means consisting of a centre conductor surrounded by an insulating material and a concentric outer conductor.");
	public static final NetworkMeansCode DEDICATED_LINE = new NetworkMeansCode(
			"Dedicated line",
			"DDCDLN",
			"The NETWORK is set up through a reserved public switched telephone network circuit.");
	public static final NetworkMeansCode DIAL_UP = new NetworkMeansCode(
			"Dial-up",
			"DIALUP",
			"The NETWORK is set up through a public switched telephone network.");
	public static final NetworkMeansCode FIBRE_OPTIC = new NetworkMeansCode(
			"Fibre optic",
			"FBROPT",
			"A transmission means using light transmission using fibre optic cable.");
	public static final NetworkMeansCode INFRARED = new NetworkMeansCode(
			"Infrared",
			"INFRED",
			"A transmission means using infrared light.");
	public static final NetworkMeansCode LASER = new NetworkMeansCode(
			"Laser",
			"LASER",
			"A transmission means using a laser beam.");
	public static final NetworkMeansCode MASER = new NetworkMeansCode(
			"Maser",
			"MASER",
			"A transmission means using a maser beam (amplified electromagnetic waves).");
	public static final NetworkMeansCode MICROWAVE = new NetworkMeansCode(
			"Microwave",
			"MICROW",
			"A transmission means using micrometric frequency electromagnetic waves.");
	public static final NetworkMeansCode MIXED = new NetworkMeansCode(
			"Mixed",
			"MIXED",
			"A transmission where more than one type of network means is used across a single communication link.");
	public static final NetworkMeansCode NOT_KNOWN = new NetworkMeansCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NetworkMeansCode NOT_OTHERWISE_SPECIFIED = new NetworkMeansCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final NetworkMeansCode RADIO_LINK_GENERAL = new NetworkMeansCode(
			"Radio link, general",
			"RDLNKG",
			"A transmission means using the Electromagnetic spectrum.");
	public static final NetworkMeansCode RADIO_LINK_SATELLITE = new NetworkMeansCode(
			"Radio link, satellite",
			"RDLNKS",
			"A transmission means using the Electromagnetic spectrum specifically through a satellite.");
	public static final NetworkMeansCode RADIO_LINK_TERRESTRIAL = new NetworkMeansCode(
			"Radio link, terrestrial",
			"RDLTER",
			"A transmission means using the Electromagnetic spectrum specifically through a path that does not include a satellite.");
	public static final NetworkMeansCode RADIO_LINK_TROPOSPHERIC = new NetworkMeansCode(
			"Radio link, tropospheric",
			"RDLTRO",
			"A transmission means using the Electromagnetic spectrum and specifically the reflective properties of the troposphere.");
	public static final NetworkMeansCode RADIO_RELAY = new NetworkMeansCode(
			"Radio relay",
			"RDRLY",
			"A transmission means using a highly directional line of sight transmission mainly for trunk communications.");
	public static final NetworkMeansCode TWISTED_PAIR_CABLE = new NetworkMeansCode(
			"Twisted pair cable",
			"TWTPRC",
			"A transmission means made up of one or more separately insulated twisted-wire pairs, none of which is arranged with another to form quads.");

	private NetworkMeansCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
