/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CapabilityUnitOfMeasureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the quantities in terms of which the magnitude of a specific CAPABILITY descriptor is stated.";
	}

	private static HashMap<String, CapabilityUnitOfMeasureCode> physicalToCode = new HashMap<String, CapabilityUnitOfMeasureCode>();

	public static CapabilityUnitOfMeasureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CapabilityUnitOfMeasureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CapabilityUnitOfMeasureCode CUBIC_METRE = new CapabilityUnitOfMeasureCode(
			"Cubic metre",
			"CM",
			"The standard international unit of volume in the metric system.");
	public static final CapabilityUnitOfMeasureCode CUBIC_METRE_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Cubic metre(s) per hour",
			"CMH",
			"Units of cubic metres divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode DEGREE = new CapabilityUnitOfMeasureCode(
			"Degree",
			"DEG",
			"One of 360 equally divided parts of a circle.");
	public static final CapabilityUnitOfMeasureCode EACH = new CapabilityUnitOfMeasureCode(
			"Each",
			"EA",
			"Singly.");
	public static final CapabilityUnitOfMeasureCode GIGAHERTZ = new CapabilityUnitOfMeasureCode(
			"Gigahertz",
			"GHZ",
			"1,000,000,000 hertz.");
	public static final CapabilityUnitOfMeasureCode HOUR = new CapabilityUnitOfMeasureCode(
			"Hour",
			"HR",
			"A unit of 3,600 seconds duration.");
	public static final CapabilityUnitOfMeasureCode HERTZ = new CapabilityUnitOfMeasureCode(
			"Hertz",
			"HZ",
			"The standard international unit of frequency in the metric system equal to one cycle per second.");
	public static final CapabilityUnitOfMeasureCode ITEM_S_PER_DAY = new CapabilityUnitOfMeasureCode(
			"Item(s) per day",
			"ITEMPD",
			"Number of Items against one day.");
	public static final CapabilityUnitOfMeasureCode ITEM_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Item(s) per hour",
			"ITEMPH",
			"Number of Items against one hour.");
	public static final CapabilityUnitOfMeasureCode ITEM_S_PER_MINUTE = new CapabilityUnitOfMeasureCode(
			"Item(s) per minute",
			"ITEMPM",
			"Number of Items against one minute.");
	public static final CapabilityUnitOfMeasureCode KILOGRAM = new CapabilityUnitOfMeasureCode(
			"Kilogram",
			"KG",
			"The standard international unit of mass in the metric system.");
	public static final CapabilityUnitOfMeasureCode KILOGRAM_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Kilogram(s) per hour",
			"KGH",
			"Units of 1,000 grams divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode KILOHERTZ = new CapabilityUnitOfMeasureCode(
			"Kilohertz",
			"KHZ",
			"1,000 hertz.");
	public static final CapabilityUnitOfMeasureCode KILOMETRE = new CapabilityUnitOfMeasureCode(
			"Kilometre",
			"KM",
			"1,000 metres.");
	public static final CapabilityUnitOfMeasureCode KNOTS = new CapabilityUnitOfMeasureCode(
			"Knots",
			"KNOTS",
			"A standard measure of a ship�s speed in nautical miles per hour.");
	public static final CapabilityUnitOfMeasureCode KILOMETRE_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Kilometre(s) per hour",
			"KPH",
			"Units of 1,000 metres divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode LITRE = new CapabilityUnitOfMeasureCode(
			"Litre",
			"LI",
			"A standard international unit of capacity in the metric system.");
	public static final CapabilityUnitOfMeasureCode LITRE_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Litre(s) per hour",
			"LPH",
			"Units of litres divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode LITRE_S_PER_MINUTE = new CapabilityUnitOfMeasureCode(
			"Litre(s) per minute",
			"LPM",
			"Units of litres divided by the elapsed time in minutes.");
	public static final CapabilityUnitOfMeasureCode MAN_HOUR = new CapabilityUnitOfMeasureCode(
			"Man-hour",
			"MANHUR",
			"An hour regarded in terms of the amount of work that could be done by one person within this period.");
	public static final CapabilityUnitOfMeasureCode METRE = new CapabilityUnitOfMeasureCode(
			"Metre",
			"METRE",
			"The standard international unit of linear measure in the metric system.");
	public static final CapabilityUnitOfMeasureCode MAN_HOUR_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Man-hour(s) per hour",
			"MHPRHR",
			"Units of man-hours divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode MEGAHERTZ = new CapabilityUnitOfMeasureCode(
			"Megahertz",
			"MHZ",
			"1,000,000 hertz.");
	public static final CapabilityUnitOfMeasureCode MINUTE = new CapabilityUnitOfMeasureCode(
			"Minute",
			"MINUTE",
			"A unit of 60 seconds duration.");
	public static final CapabilityUnitOfMeasureCode METRE_S_PER_SECOND = new CapabilityUnitOfMeasureCode(
			"Metre(s) per second",
			"MPS",
			"Units of metres divided by the elapsed time in seconds.");
	public static final CapabilityUnitOfMeasureCode METRIC_TON = new CapabilityUnitOfMeasureCode(
			"Metric ton",
			"MTRCTN",
			"1,000 kilograms.");
	public static final CapabilityUnitOfMeasureCode NAUTICAL_MILE = new CapabilityUnitOfMeasureCode(
			"Nautical mile",
			"NM",
			"A standard measure of length equal to one minute of a great circle of the earth.");
	public static final CapabilityUnitOfMeasureCode PULSE_S_PER_SECOND = new CapabilityUnitOfMeasureCode(
			"Pulse(s) per second",
			"PPS",
			"The rate at which pulses are generated or received.");
	public static final CapabilityUnitOfMeasureCode PERCENTAGE = new CapabilityUnitOfMeasureCode(
			"Percentage",
			"PRCNTG",
			"A rate or proportion per cent.");
	public static final CapabilityUnitOfMeasureCode ROUND_S_PER_MINUTE = new CapabilityUnitOfMeasureCode(
			"Round(s) per minute",
			"RDM",
			"The number of rounds that can be fired in 60 seconds.");
	public static final CapabilityUnitOfMeasureCode SECOND = new CapabilityUnitOfMeasureCode(
			"Second",
			"SECOND",
			"The standard international unit of time in the metric system.");
	public static final CapabilityUnitOfMeasureCode SQUARE_METRE_S_PER_HOUR = new CapabilityUnitOfMeasureCode(
			"Square metre(s) per hour",
			"SMH",
			"Units of square metres divided by the elapsed time in hours.");
	public static final CapabilityUnitOfMeasureCode SQUARE_METRE = new CapabilityUnitOfMeasureCode(
			"Square metre",
			"SQM",
			"A standard international unit of area in the metric system.");
	public static final CapabilityUnitOfMeasureCode UNITLESS = new CapabilityUnitOfMeasureCode(
			"Unitless",
			"UNTLS",
			"There is no unit of measure used.");
	public static final CapabilityUnitOfMeasureCode WATT = new CapabilityUnitOfMeasureCode(
			"Watt",
			"WATT",
			"The standard international unit of power in the metric system.");

	private CapabilityUnitOfMeasureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
