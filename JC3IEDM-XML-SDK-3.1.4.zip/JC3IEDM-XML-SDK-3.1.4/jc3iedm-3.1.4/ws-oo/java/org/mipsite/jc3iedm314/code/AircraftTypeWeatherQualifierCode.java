/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeWeatherQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the weather conditions in which an AIRCRAFT-TYPE can perform its mission.";
	}

	private static HashMap<String, AircraftTypeWeatherQualifierCode> physicalToCode = new HashMap<String, AircraftTypeWeatherQualifierCode>();

	public static AircraftTypeWeatherQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeWeatherQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeWeatherQualifierCode ALL_WEATHER = new AircraftTypeWeatherQualifierCode(
			"All weather",
			"ALL",
			"All weather conditions.");
	public static final AircraftTypeWeatherQualifierCode CLEAR_WEATHER = new AircraftTypeWeatherQualifierCode(
			"Clear weather",
			"CLEAR",
			"Clear weather conditions only.");
	public static final AircraftTypeWeatherQualifierCode NOT_KNOWN = new AircraftTypeWeatherQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private AircraftTypeWeatherQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
