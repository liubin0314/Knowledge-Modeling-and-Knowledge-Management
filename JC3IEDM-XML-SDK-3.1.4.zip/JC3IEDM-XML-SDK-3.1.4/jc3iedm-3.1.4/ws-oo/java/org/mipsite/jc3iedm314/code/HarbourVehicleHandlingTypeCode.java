/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourVehicleHandlingTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific types of facilities available at a specified HARBOUR.";
	}

	private static HashMap<String, HarbourVehicleHandlingTypeCode> physicalToCode = new HashMap<String, HarbourVehicleHandlingTypeCode>();

	public static HarbourVehicleHandlingTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourVehicleHandlingTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourVehicleHandlingTypeCode NOT_KNOWN = new HarbourVehicleHandlingTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final HarbourVehicleHandlingTypeCode NOT_OTHERWISE_SPECIFIED = new HarbourVehicleHandlingTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final HarbourVehicleHandlingTypeCode ROLL_ON_ROLL_OFF_FIXED_LINK_SPAN = new HarbourVehicleHandlingTypeCode(
			"Roll on/roll off fixed link span",
			"ROROFL",
			"A permanent bridge, usually fixed to piles, specifically designed to enable a Roll on/Roll off (RORO) vessel to dock against, either stern-on or bow-on and which joins the vessel to the shore or dockside. This structure enables land vehicles to transit between the RORO vessel and the shore or dockside.");
	public static final HarbourVehicleHandlingTypeCode ROLL_ON_ROLL_OFF_FLOATING_RAMP = new HarbourVehicleHandlingTypeCode(
			"Roll on/roll off floating ramp",
			"ROROFR",
			"A permanent bridge, usually on a pontoon(s) or a ballast tank(s)/buoyancy tank(s), against which a Roll on/Roll off (RORO) vessel docks, either stern-on or bow-on, and which joins the RORO vessel to the shore or dockside. The structure enables land vehicles to transit between the RORO vessel and the shore or dockside. The link span rises or falls with the tide as it floats on the water.");
	public static final HarbourVehicleHandlingTypeCode ROLL_ON_ROLL_OFF_MOVEABLE_LINK_SPAN = new HarbourVehicleHandlingTypeCode(
			"Roll on/roll off moveable link span",
			"ROROML",
			"A moveable bridge, usually on a pontoon(s) or a ballast tank(s)/buoyancy tank(s), against which a Roll on/Roll off (RORO) vessel docks, either stern-on or bow-on, and which joins the RORO vessel to the shore or dockside. The structure enables land vehicles to transit between the RORO vessel and the shore or dockside. The link span rises or falls with the tide and can be moved to another location, as it is floating on the water.");

	private HarbourVehicleHandlingTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
