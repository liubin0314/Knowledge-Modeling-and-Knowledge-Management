/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LiquidSurfaceStatusSeaStateCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a range of wave heights on a specific liquid surface.";
	}

	private static HashMap<String, LiquidSurfaceStatusSeaStateCode> physicalToCode = new HashMap<String, LiquidSurfaceStatusSeaStateCode>();

	public static LiquidSurfaceStatusSeaStateCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LiquidSurfaceStatusSeaStateCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LiquidSurfaceStatusSeaStateCode CALM_GLASSY = new LiquidSurfaceStatusSeaStateCode(
			"Calm (glassy)",
			"0",
			"Wave height 0 metres.");
	public static final LiquidSurfaceStatusSeaStateCode CALM_RIPPLED = new LiquidSurfaceStatusSeaStateCode(
			"Calm (rippled)",
			"1",
			"Wave height 0 to 0.1 metre.");
	public static final LiquidSurfaceStatusSeaStateCode SMOOTH_WAVELETS = new LiquidSurfaceStatusSeaStateCode(
			"Smooth (wavelets)",
			"2",
			"Wave height 0.1 to 0.5 metre.");
	public static final LiquidSurfaceStatusSeaStateCode SLIGHT = new LiquidSurfaceStatusSeaStateCode(
			"Slight",
			"3",
			"Wave height 0.5 to 1.25 metre.");
	public static final LiquidSurfaceStatusSeaStateCode MODERATE = new LiquidSurfaceStatusSeaStateCode(
			"Moderate",
			"4",
			"Wave height 1.25 to 2.5 metres.");
	public static final LiquidSurfaceStatusSeaStateCode ROUGH = new LiquidSurfaceStatusSeaStateCode(
			"Rough",
			"5",
			"Wave height 2.5 to 4 metres.");
	public static final LiquidSurfaceStatusSeaStateCode VERY_ROUGH = new LiquidSurfaceStatusSeaStateCode(
			"Very rough",
			"6",
			"Wave height 4 to 6 metres.");
	public static final LiquidSurfaceStatusSeaStateCode HIGH = new LiquidSurfaceStatusSeaStateCode(
			"High",
			"7",
			"Wave height 6 to 9 metres.");
	public static final LiquidSurfaceStatusSeaStateCode VERY_HIGH = new LiquidSurfaceStatusSeaStateCode(
			"Very high",
			"8",
			"Wave height 9 to 14 metres.");
	public static final LiquidSurfaceStatusSeaStateCode PHENOMENAL = new LiquidSurfaceStatusSeaStateCode(
			"Phenomenal",
			"9",
			"Wave height greater than 14 metres.");

	private LiquidSurfaceStatusSeaStateCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
