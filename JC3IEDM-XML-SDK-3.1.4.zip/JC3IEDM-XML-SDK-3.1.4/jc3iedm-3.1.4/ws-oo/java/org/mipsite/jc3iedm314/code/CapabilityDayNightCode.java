/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class CapabilityDayNightCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that defines the light conditions that apply to a particular CAPABILITY.";
	}

	private static HashMap<String, CapabilityDayNightCode> physicalToCode = new HashMap<String, CapabilityDayNightCode>();

	public static CapabilityDayNightCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<CapabilityDayNightCode> getCodes() {
		return physicalToCode.values();
	}

	public static final CapabilityDayNightCode DAY = new CapabilityDayNightCode(
			"Day",
			"DAY",
			"The figures are based on the capability being invoked during daylight hours.");
	public static final CapabilityDayNightCode DAY_AND_NIGHT = new CapabilityDayNightCode(
			"Day and night",
			"DN",
			"The figures are based on the capability being invoked at any time.");
	public static final CapabilityDayNightCode NIGHT = new CapabilityDayNightCode(
			"Night",
			"N",
			"The figures are based on the capability being invoked during hours of darkness.");

	private CapabilityDayNightCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
