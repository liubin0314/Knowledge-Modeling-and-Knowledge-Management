/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PlanOrderComponentContentReferenceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the reason a specific REFERENCE is associated to a specific PLAN-ORDER-COMPONENT-CONTENT.";
	}

	private static HashMap<String, PlanOrderComponentContentReferenceCategoryCode> physicalToCode = new HashMap<String, PlanOrderComponentContentReferenceCategoryCode>();

	public static PlanOrderComponentContentReferenceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PlanOrderComponentContentReferenceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PlanOrderComponentContentReferenceCategoryCode HAS_INSTRUCTIONS_PROVIDED_IN = new PlanOrderComponentContentReferenceCategoryCode(
			"Has instructions provided in",
			"HASINS",
			"The specific artefact is subject to guidance provided in the artefact cited by the specific REFERENCE.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_AMPLIFIED_BY = new PlanOrderComponentContentReferenceCategoryCode(
			"Is amplified by",
			"ISAMPL",
			"The specific artefact is subject to additional detail provided in the artefact cited by the specific REFERENCE.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_DISSOCIATED_FROM = new PlanOrderComponentContentReferenceCategoryCode(
			"Is dissociated from",
			"ISDISS",
			"The relationship of the specific PLAN-ORDER-CONTENT with the specific REFERENCE is deleted.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_PROVIDED_SUPPLEMENTARY_INFORMATION_BY = new PlanOrderComponentContentReferenceCategoryCode(
			"Is provided supplementary information by",
			"ISPROV",
			"The specific artefact is subject to relevant background information in the artefact cited by the specific REFERENCE.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_RECORDED_IN = new PlanOrderComponentContentReferenceCategoryCode(
			"Is recorded in",
			"ISRCRD",
			"The specific artefact is physically stored in the artefact cited by the specific REFERENCE.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_SUPPORTED_BY_CHARTS_AND_MAPS_IN = new PlanOrderComponentContentReferenceCategoryCode(
			"Is supported by charts and maps in",
			"ISSPCM",
			"The specific artefact references geographic mapping products in the artefact cited by the specific REFERENCE.");
	public static final PlanOrderComponentContentReferenceCategoryCode IS_SUPPORTED_BY_PICTORIAL_MATERIAL_IN = new PlanOrderComponentContentReferenceCategoryCode(
			"Is supported by pictorial material in",
			"ISSPPM",
			"The specific artefact references relevant pictorial material in the artefact cited by the specific REFERENCE.");

	private PlanOrderComponentContentReferenceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
