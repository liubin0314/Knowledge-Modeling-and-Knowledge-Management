/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersonIdentificationDocumentCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of document used to identify a specific PERSON.";
	}

	private static HashMap<String, PersonIdentificationDocumentCode> physicalToCode = new HashMap<String, PersonIdentificationDocumentCode>();

	public static PersonIdentificationDocumentCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersonIdentificationDocumentCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersonIdentificationDocumentCode CIVILIAN_IDENTIFICATION_CARD = new PersonIdentificationDocumentCode(
			"Civilian identification card",
			"CIVID",
			"The PERSON is identified by a civilian identification card.");
	public static final PersonIdentificationDocumentCode MILITARY_IDENTIFICATION_CARD = new PersonIdentificationDocumentCode(
			"Military identification card",
			"MILID",
			"The PERSON is identified by a military identification card.");
	public static final PersonIdentificationDocumentCode MILITARY_ORDERS = new PersonIdentificationDocumentCode(
			"Military orders",
			"MILORD",
			"The PERSON is identified by military orders.");
	public static final PersonIdentificationDocumentCode NOT_OTHERWISE_SPECIFIED = new PersonIdentificationDocumentCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final PersonIdentificationDocumentCode PASSPORT = new PersonIdentificationDocumentCode(
			"Passport",
			"PSSPRT",
			"The PERSON is identified by a passport.");

	private PersonIdentificationDocumentCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
