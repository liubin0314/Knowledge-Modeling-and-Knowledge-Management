/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AmmunitionTypeExerciseMineFlareColourCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the colour of the flare released by the exercise mine.";
	}

	private static HashMap<String, AmmunitionTypeExerciseMineFlareColourCode> physicalToCode = new HashMap<String, AmmunitionTypeExerciseMineFlareColourCode>();

	public static AmmunitionTypeExerciseMineFlareColourCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AmmunitionTypeExerciseMineFlareColourCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AmmunitionTypeExerciseMineFlareColourCode GREEN = new AmmunitionTypeExerciseMineFlareColourCode(
			"Green",
			"GREEN",
			"Self defined.");
	public static final AmmunitionTypeExerciseMineFlareColourCode ORANGE = new AmmunitionTypeExerciseMineFlareColourCode(
			"Orange",
			"ORANGE",
			"Self defined.");
	public static final AmmunitionTypeExerciseMineFlareColourCode RED = new AmmunitionTypeExerciseMineFlareColourCode(
			"Red",
			"RED",
			"Self defined.");
	public static final AmmunitionTypeExerciseMineFlareColourCode WHITE = new AmmunitionTypeExerciseMineFlareColourCode(
			"White",
			"WHITE",
			"Self defined.");
	public static final AmmunitionTypeExerciseMineFlareColourCode YELLOW = new AmmunitionTypeExerciseMineFlareColourCode(
			"Yellow",
			"YELLOW",
			"Self defined.");

	private AmmunitionTypeExerciseMineFlareColourCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
