/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GroupCharacteristicMaladyTransmissibilityIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that identifies whether the type of ill health, ailment or disease in a specific GROUP-CHARACTERISTIC is communicable.";
	}

	private static HashMap<String, GroupCharacteristicMaladyTransmissibilityIndicatorCode> physicalToCode = new HashMap<String, GroupCharacteristicMaladyTransmissibilityIndicatorCode>();

	public static GroupCharacteristicMaladyTransmissibilityIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GroupCharacteristicMaladyTransmissibilityIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GroupCharacteristicMaladyTransmissibilityIndicatorCode NO = new GroupCharacteristicMaladyTransmissibilityIndicatorCode(
			"No",
			"NO",
			"The ill health, ailment or disease is not communicable.");
	public static final GroupCharacteristicMaladyTransmissibilityIndicatorCode YES = new GroupCharacteristicMaladyTransmissibilityIndicatorCode(
			"Yes",
			"YES",
			"The ill health, ailment or disease is communicable.");

	private GroupCharacteristicMaladyTransmissibilityIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
