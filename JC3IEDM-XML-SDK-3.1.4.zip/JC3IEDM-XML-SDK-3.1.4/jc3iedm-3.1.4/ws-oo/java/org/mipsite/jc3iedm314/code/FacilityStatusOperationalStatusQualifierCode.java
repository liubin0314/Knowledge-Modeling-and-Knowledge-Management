/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusOperationalStatusQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the qualification of the operational status of a specific FACILITY.";
	}

	private static HashMap<String, FacilityStatusOperationalStatusQualifierCode> physicalToCode = new HashMap<String, FacilityStatusOperationalStatusQualifierCode>();

	public static FacilityStatusOperationalStatusQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusOperationalStatusQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusOperationalStatusQualifierCode BREACHED = new FacilityStatusOperationalStatusQualifierCode(
			"Breached",
			"BRCHED",
			"Subjectively judged by the reporting organisation that a FACILITY has been penetrated.");
	public static final FacilityStatusOperationalStatusQualifierCode BURNED_OUT = new FacilityStatusOperationalStatusQualifierCode(
			"Burned out",
			"BRNOUT",
			"Subjectively judged by the reporting organisation that a FACILITY has been set on fire and is destroyed.");
	public static final FacilityStatusOperationalStatusQualifierCode COVERED_BY_FIRE = new FacilityStatusOperationalStatusQualifierCode(
			"Covered by fire",
			"CVRFIR",
			"Subjectively judged by the reporting organisation that a FACILITY is being protected by weaponry.");
	public static final FacilityStatusOperationalStatusQualifierCode DENIED = new FacilityStatusOperationalStatusQualifierCode(
			"Denied",
			"DENIED",
			"Subjectively judged by the reporting organisation that a FACILITY is unavailable through means such as removal, contamination or erection of obstructions.");
	public static final FacilityStatusOperationalStatusQualifierCode DISASSEMBLED = new FacilityStatusOperationalStatusQualifierCode(
			"Disassembled",
			"DISASM",
			"Subjectively judged by the reporting organisation that a FACILITY is taken apart in a way that it can be reassembled.");
	public static final FacilityStatusOperationalStatusQualifierCode DESTROYED = new FacilityStatusOperationalStatusQualifierCode(
			"Destroyed",
			"DSTRYD",
			"Subjectively judged by the reporting organisation that a FACILITY is not, and not expected ever to be, capable of performing the missions or functions for which it is organised or designed.");
	public static final FacilityStatusOperationalStatusQualifierCode HEAVILY_DAMAGED = new FacilityStatusOperationalStatusQualifierCode(
			"Heavily damaged",
			"HVYDAM",
			"Subjectively judged by the reporting organisation to be heavily damaged.");
	public static final FacilityStatusOperationalStatusQualifierCode IN_MAINTENANCE = new FacilityStatusOperationalStatusQualifierCode(
			"In maintenance",
			"INMNT",
			"Subjectively judged by the reporting organisation that a FACILITY is undergoing service of some kind.");
	public static final FacilityStatusOperationalStatusQualifierCode LIGHTLY_DAMAGED = new FacilityStatusOperationalStatusQualifierCode(
			"Lightly damaged",
			"LGTDAM",
			"Subjectively judged by the reporting organisation to be only lightly damaged.");
	public static final FacilityStatusOperationalStatusQualifierCode LOST = new FacilityStatusOperationalStatusQualifierCode(
			"Lost",
			"LST",
			"Subjectively judged by the reporting organisation that a FACILITY is missing or captured.");
	public static final FacilityStatusOperationalStatusQualifierCode LACKING_VITAL_RESOURCES = new FacilityStatusOperationalStatusQualifierCode(
			"Lacking vital resources",
			"LVR",
			"Subjectively judged by the reporting organisation that a FACILITY is deficient or lacking of some mission-critical resources (e.g., fuel, ammunition).");
	public static final FacilityStatusOperationalStatusQualifierCode MARKED = new FacilityStatusOperationalStatusQualifierCode(
			"Marked",
			"MARKED",
			"Subjectively judged by the reporting organisation that a FACILITY has been identified.");
	public static final FacilityStatusOperationalStatusQualifierCode MODERATELY_DAMAGED = new FacilityStatusOperationalStatusQualifierCode(
			"Moderately damaged",
			"MODDAM",
			"Subjectively judged by the reporting organisation to be moderately damaged.");
	public static final FacilityStatusOperationalStatusQualifierCode NOT_KNOWN = new FacilityStatusOperationalStatusQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FacilityStatusOperationalStatusQualifierCode PASSABLE = new FacilityStatusOperationalStatusQualifierCode(
			"Passable",
			"PASABL",
			"Subjectively judged by the reporting organisation that a FACILITY can be crossed.");
	public static final FacilityStatusOperationalStatusQualifierCode PREPARED_FOR_EXECUTION = new FacilityStatusOperationalStatusQualifierCode(
			"Prepared for execution",
			"PRPEXE",
			"Subjectively judged by the reporting organisation that a FACILITY has been made ready to assume a particular role.");
	public static final FacilityStatusOperationalStatusQualifierCode PARTLY_DISMANTLED = new FacilityStatusOperationalStatusQualifierCode(
			"Partly dismantled",
			"PRTDSM",
			"Subjectively judged by the reporting organisation that a FACILITY is taken apart to some extent.");
	public static final FacilityStatusOperationalStatusQualifierCode STERILIZED = new FacilityStatusOperationalStatusQualifierCode(
			"Sterilized",
			"STERLZ",
			"Subjectively judged by the reporting organisation that a FACILITY has been made incapable of functioning productively or effectively.");
	public static final FacilityStatusOperationalStatusQualifierCode UNDER_CONSTRUCTION = new FacilityStatusOperationalStatusQualifierCode(
			"Under construction",
			"UNCNST",
			"Subjectively judged by the reporting organisation that a FACILITY is being built.");

	private FacilityStatusOperationalStatusQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
