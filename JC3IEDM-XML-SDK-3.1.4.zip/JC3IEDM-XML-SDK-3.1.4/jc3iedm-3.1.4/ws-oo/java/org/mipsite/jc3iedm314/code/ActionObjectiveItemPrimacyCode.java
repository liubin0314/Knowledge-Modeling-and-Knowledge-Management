/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveItemPrimacyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the relative usage of a specific ACTION-OBJECTIVE-ITEM when more than one instance of ACTION-OBJECTIVE-ITEM is designated for a specific ACTION.";
	}

	private static HashMap<String, ActionObjectiveItemPrimacyCode> physicalToCode = new HashMap<String, ActionObjectiveItemPrimacyCode>();

	public static ActionObjectiveItemPrimacyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveItemPrimacyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveItemPrimacyCode ALTERNATE = new ActionObjectiveItemPrimacyCode(
			"Alternate",
			"ALTERN",
			"Denotes an alternate ACTION-OBJECTIVE-ITEM.");
	public static final ActionObjectiveItemPrimacyCode PRIMARY = new ActionObjectiveItemPrimacyCode(
			"Primary",
			"PRIME",
			"Denotes a primary ACTION-OBJECTIVE-ITEM.");
	public static final ActionObjectiveItemPrimacyCode SECONDARY = new ActionObjectiveItemPrimacyCode(
			"Secondary",
			"SECOND",
			"Denotes a secondary ACTION-OBJECTIVE-ITEM.");

	private ActionObjectiveItemPrimacyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
