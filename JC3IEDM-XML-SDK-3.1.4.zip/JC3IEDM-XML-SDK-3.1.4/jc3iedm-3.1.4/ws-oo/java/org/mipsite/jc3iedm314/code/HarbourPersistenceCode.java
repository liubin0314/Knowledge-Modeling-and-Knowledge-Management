/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourPersistenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR is permanent or temporary.";
	}

	private static HashMap<String, HarbourPersistenceCode> physicalToCode = new HashMap<String, HarbourPersistenceCode>();

	public static HarbourPersistenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourPersistenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourPersistenceCode NOT_KNOWN = new HarbourPersistenceCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final HarbourPersistenceCode PERMANENT = new HarbourPersistenceCode(
			"Permanent",
			"PERMAN",
			"The harbour is a fixed installation and cannot be moved.");
	public static final HarbourPersistenceCode TEMPORARY = new HarbourPersistenceCode(
			"Temporary",
			"TEMPRY",
			"The harbour has been constructed using pre-fabricated structures and constructed on a site that was not previously a harbour.");

	private HarbourPersistenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
