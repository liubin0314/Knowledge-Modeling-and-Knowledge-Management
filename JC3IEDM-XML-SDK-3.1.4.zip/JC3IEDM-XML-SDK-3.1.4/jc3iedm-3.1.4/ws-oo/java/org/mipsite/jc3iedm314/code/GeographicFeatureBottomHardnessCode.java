/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureBottomHardnessCode extends CodeDomain {

	public static String getComment() {
		return "A specific value that represents the subjective indication obtained by a diver of the hardness of the liquid/solid surface interface and is the result of a single arm thrust.";
	}

	private static HashMap<String, GeographicFeatureBottomHardnessCode> physicalToCode = new HashMap<String, GeographicFeatureBottomHardnessCode>();

	public static GeographicFeatureBottomHardnessCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureBottomHardnessCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureBottomHardnessCode ARM_PENETRATES_TO_ELBOW = new GeographicFeatureBottomHardnessCode(
			"Arm penetrates to elbow",
			"ARMELB",
			"The depth to which the divers arm penetrates the surface bottom, using a clenched fist, up to the elbow.");
	public static final GeographicFeatureBottomHardnessCode HAND_PENETRATES_TO_KNUCKLES = new GeographicFeatureBottomHardnessCode(
			"Hand penetrates to knuckles",
			"ARMKNU",
			"The depth to which the divers arm penetrates the surface bottom, using extended fingers, up to the knuckles.");
	public static final GeographicFeatureBottomHardnessCode HAND_PENETRATES_TO_PALM = new GeographicFeatureBottomHardnessCode(
			"Hand penetrates to palm",
			"ARMPLM",
			"The depth to which the divers arm penetrates the surface bottom, using extended fingers, up to the palm.");
	public static final GeographicFeatureBottomHardnessCode ARM_PENETRATES_TO_SHOULDER = new GeographicFeatureBottomHardnessCode(
			"Arm penetrates to shoulder",
			"ARMSHO",
			"The depth to which the divers arm penetrates the surface bottom, using a clenched fist, up to the shoulder.");
	public static final GeographicFeatureBottomHardnessCode ARM_PENETRATES_TO_WRIST = new GeographicFeatureBottomHardnessCode(
			"Arm penetrates to wrist",
			"ARMWRS",
			"The depth to which the divers arm penetrates the surface bottom, using a clenched fist, up to the wrist.");
	public static final GeographicFeatureBottomHardnessCode NO_PENETRATION = new GeographicFeatureBottomHardnessCode(
			"No penetration",
			"NOPENT",
			"The depth to which the divers arm penetrates the surface bottom, using a clenched fist, resulting in no penetration.");

	private GeographicFeatureBottomHardnessCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
