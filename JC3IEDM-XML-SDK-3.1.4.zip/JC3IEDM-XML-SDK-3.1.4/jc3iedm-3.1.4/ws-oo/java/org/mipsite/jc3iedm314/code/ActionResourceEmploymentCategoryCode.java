/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionResourceEmploymentCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-RESOURCE-EMPLOYMENT.";
	}

	private static HashMap<String, ActionResourceEmploymentCategoryCode> physicalToCode = new HashMap<String, ActionResourceEmploymentCategoryCode>();

	public static ActionResourceEmploymentCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionResourceEmploymentCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionResourceEmploymentCategoryCode ACTION_AIRCRAFT_EMPLOYMENT = new ActionResourceEmploymentCategoryCode(
			"ACTION-AIRCRAFT-EMPLOYMENT",
			"AIREMP",
			"The procedure that guides the use of an ACTION-RESOURCE that is capable of atmospheric flight.");
	public static final ActionResourceEmploymentCategoryCode ACTION_ELECTRONIC_WARFARE_EMPLOYMENT = new ActionResourceEmploymentCategoryCode(
			"ACTION-ELECTRONIC-WARFARE-EMPLOYMENT",
			"ELCEMP",
			"The technique used by an ACTION-RESOURCE for Electronic Warfare by electronic or mechanical means.");
	public static final ActionResourceEmploymentCategoryCode ACTION_MARITIME_EMPLOYMENT = new ActionResourceEmploymentCategoryCode(
			"ACTION-MARITIME-EMPLOYMENT",
			"MAREMP",
			"The procedure that guides the use of an ACTION-RESOURCE in a maritime environment.");
	public static final ActionResourceEmploymentCategoryCode NOT_OTHERWISE_SPECIFIED = new ActionResourceEmploymentCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionResourceEmploymentCategoryCode ACTION_RECONNAISSANCE_EMPLOYMENT = new ActionResourceEmploymentCategoryCode(
			"ACTION-RECONNAISSANCE-EMPLOYMENT",
			"RECEMP",
			"The parameters that guide the use of an ACTION-RESOURCE that is employed in a reconnaissance role.");

	private ActionResourceEmploymentCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
