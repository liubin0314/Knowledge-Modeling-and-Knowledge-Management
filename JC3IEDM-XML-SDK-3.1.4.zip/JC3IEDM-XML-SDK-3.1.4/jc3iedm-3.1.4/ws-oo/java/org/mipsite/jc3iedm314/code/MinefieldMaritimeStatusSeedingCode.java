/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeStatusSeedingCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the seeding details for a MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeStatusSeedingCode> physicalToCode = new HashMap<String, MinefieldMaritimeStatusSeedingCode>();

	public static MinefieldMaritimeStatusSeedingCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeStatusSeedingCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeStatusSeedingCode EIGHTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Eighth reseeding",
			"EIGHTH",
			"The eighth addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode FIFTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Fifth reseeding",
			"FIFTH",
			"The fifth addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode FIRST_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"First reseeding",
			"FIRST",
			"The first addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode FOURTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Fourth reseeding",
			"FOURTH",
			"The fourth addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode INITIAL_IMPLANT = new MinefieldMaritimeStatusSeedingCode(
			"Initial implant",
			"INITAL",
			"The original laying of the maritime minefield.");
	public static final MinefieldMaritimeStatusSeedingCode NINTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Ninth reseeding",
			"NINTH",
			"The ninth addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode SECOND_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Second reseeding",
			"SECOND",
			"The second addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode SEVENTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Seventh reseeding",
			"SEVNTH",
			"The seventh addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode SIXTH_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Sixth reseeding",
			"SIXTH",
			"The sixth addition of replacement or extra mines to a minefield.");
	public static final MinefieldMaritimeStatusSeedingCode THIRD_RESEEDING = new MinefieldMaritimeStatusSeedingCode(
			"Third reseeding",
			"THIRD",
			"The third addition of replacement or extra mines to a minefield.");

	private MinefieldMaritimeStatusSeedingCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
