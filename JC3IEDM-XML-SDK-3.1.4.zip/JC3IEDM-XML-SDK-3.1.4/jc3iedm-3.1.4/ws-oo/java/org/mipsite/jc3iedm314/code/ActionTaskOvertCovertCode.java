/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskOvertCovertCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the property of an ACTION-TASK to be overt or covert.";
	}

	private static HashMap<String, ActionTaskOvertCovertCode> physicalToCode = new HashMap<String, ActionTaskOvertCovertCode>();

	public static ActionTaskOvertCovertCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskOvertCovertCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskOvertCovertCode COVERT = new ActionTaskOvertCovertCode(
			"Covert",
			"COVERT",
			"The ACTION-TASK is to be conducted secretly.");
	public static final ActionTaskOvertCovertCode OVERT = new ActionTaskOvertCovertCode(
			"Overt",
			"OVERT",
			"The ACTION-TASK is to be conducted openly.");

	private ActionTaskOvertCovertCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
