/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionTaskTimingDayCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the notional start of the ACTION in terms of a day with defined operational meaning.";
	}

	private static HashMap<String, ActionTaskTimingDayCode> physicalToCode = new HashMap<String, ActionTaskTimingDayCode>();

	public static ActionTaskTimingDayCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionTaskTimingDayCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionTaskTimingDayCode C = new ActionTaskTimingDayCode(
			"C",
			"C",
			"The day on which deployment for an operation commences or is due to commence.");
	public static final ActionTaskTimingDayCode D = new ActionTaskTimingDayCode(
			"D",
			"D",
			"The day on which an operation commences or is due to commence. This may be commencement of hostilities or any other operation.");
	public static final ActionTaskTimingDayCode E = new ActionTaskTimingDayCode(
			"E",
			"E",
			"The day on which a NATO exercise commences.");
	public static final ActionTaskTimingDayCode G = new ActionTaskTimingDayCode(
			"G",
			"G",
			"The day on which an order (normally national) is given to deploy a unit.");
	public static final ActionTaskTimingDayCode J = new ActionTaskTimingDayCode(
			"J",
			"J",
			"French equivalent to D-day.");
	public static final ActionTaskTimingDayCode K = new ActionTaskTimingDayCode(
			"K",
			"K",
			"The day on which a convoy system is introduced or is due to be introduced on any particular land convoy route or sea convoy lane.");
	public static final ActionTaskTimingDayCode M = new ActionTaskTimingDayCode(
			"M",
			"M",
			"The day on which mobilization commences or is due to commence.");
	public static final ActionTaskTimingDayCode T = new ActionTaskTimingDayCode(
			"T",
			"T",
			"The day of Transfer of Authority.");

	private ActionTaskTimingDayCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
