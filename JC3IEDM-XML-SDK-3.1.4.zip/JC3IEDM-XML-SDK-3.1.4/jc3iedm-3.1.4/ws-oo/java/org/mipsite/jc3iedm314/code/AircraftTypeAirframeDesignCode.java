/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeAirframeDesignCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the design of the airframe of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeAirframeDesignCode> physicalToCode = new HashMap<String, AircraftTypeAirframeDesignCode>();

	public static AircraftTypeAirframeDesignCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeAirframeDesignCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeAirframeDesignCode AUTOGYRO = new AircraftTypeAirframeDesignCode(
			"Autogyro",
			"AUTOGY",
			"An aircraft powered by a conventional propeller and a freewheeling, horizontal rotor.");
	public static final AircraftTypeAirframeDesignCode BALLOON = new AircraftTypeAirframeDesignCode(
			"Balloon",
			"BALOON",
			"An unpowered lighter than air aircraft.");
	public static final AircraftTypeAirframeDesignCode BOMBER = new AircraftTypeAirframeDesignCode(
			"Bomber",
			"BOMBER",
			"An aircraft capable of air operations using air to ground ordnance to destroy or neutralize enemy forces or installations.");
	public static final AircraftTypeAirframeDesignCode TRANSPORT = new AircraftTypeAirframeDesignCode(
			"Transport",
			"CARGO",
			"An aircraft designed primarily for the carriage of personnel and/or cargo, and/or fuel.");
	public static final AircraftTypeAirframeDesignCode DIRIGIBLE = new AircraftTypeAirframeDesignCode(
			"Dirigible",
			"DIRIG",
			"A powered lighter than air aircraft.");
	public static final AircraftTypeAirframeDesignCode FIGHTER = new AircraftTypeAirframeDesignCode(
			"Fighter",
			"FIGHTR",
			"A generic term to describe a type of fast and manoeuvrable fixed wing aircraft capable of tactical air operations against air and/or surface targets.");
	public static final AircraftTypeAirframeDesignCode GLIDER = new AircraftTypeAirframeDesignCode(
			"Glider",
			"GLIDER",
			"A fixed wing aircraft that flies without an engine.");
	public static final AircraftTypeAirframeDesignCode HELICOPTER = new AircraftTypeAirframeDesignCode(
			"Helicopter",
			"HELO",
			"A rotary wing aircraft capable of atmospheric flight and dependent on rotating blades for lift.");
	public static final AircraftTypeAirframeDesignCode NOT_KNOWN = new AircraftTypeAirframeDesignCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeAirframeDesignCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeAirframeDesignCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AircraftTypeAirframeDesignCode SATELLITE = new AircraftTypeAirframeDesignCode(
			"Satellite",
			"SATEL",
			"A space vehicle that orbits the earth.");

	private AircraftTypeAirframeDesignCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
