/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MeteorologicFeatureSourceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the basis for the estimate of a condition for a specific METEOROLOGIC-FEATURE.";
	}

	private static HashMap<String, MeteorologicFeatureSourceCode> physicalToCode = new HashMap<String, MeteorologicFeatureSourceCode>();

	public static MeteorologicFeatureSourceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MeteorologicFeatureSourceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MeteorologicFeatureSourceCode FORECAST = new MeteorologicFeatureSourceCode(
			"Forecast",
			"FOR",
			"A statement of anticipated (meteorological) conditions for a specified place (or area, route, etc.) and period of time.");
	public static final MeteorologicFeatureSourceCode OBSERVED = new MeteorologicFeatureSourceCode(
			"Observed",
			"OBSRVD",
			"Reported based on observation, in meteorological context, a record of measurement or assessment of one or more meteorological elements - e.g. temperature pressure, cloud type and amount - at a particular time and place.");

	private MeteorologicFeatureSourceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
