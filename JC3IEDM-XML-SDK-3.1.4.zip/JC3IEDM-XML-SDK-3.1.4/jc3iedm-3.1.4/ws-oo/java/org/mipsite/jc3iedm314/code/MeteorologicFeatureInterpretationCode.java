/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MeteorologicFeatureInterpretationCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the statistical meaning of a specified METEOROLOGIC-FEATURE.";
	}

	private static HashMap<String, MeteorologicFeatureInterpretationCode> physicalToCode = new HashMap<String, MeteorologicFeatureInterpretationCode>();

	public static MeteorologicFeatureInterpretationCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MeteorologicFeatureInterpretationCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MeteorologicFeatureInterpretationCode ABSOLUTE_MAXIMUM = new MeteorologicFeatureInterpretationCode(
			"Absolute maximum",
			"ABMAX",
			"The highest actual value.");
	public static final MeteorologicFeatureInterpretationCode ABSOLUTE_MINIMUM = new MeteorologicFeatureInterpretationCode(
			"Absolute minimum",
			"ABMIN",
			"The lowest actual value.");
	public static final MeteorologicFeatureInterpretationCode AVERAGE_MAXIMUM = new MeteorologicFeatureInterpretationCode(
			"Average maximum",
			"AVMAX",
			"A value that represents the average of maximum readings over a period of time.");
	public static final MeteorologicFeatureInterpretationCode AVERAGE_MINIMUM = new MeteorologicFeatureInterpretationCode(
			"Average minimum",
			"AVMIN",
			"A value that represents the average of minimum readings over a period of time.");
	public static final MeteorologicFeatureInterpretationCode NOMINAL = new MeteorologicFeatureInterpretationCode(
			"Nominal",
			"NOMIN",
			"The actual or expected value.");

	private MeteorologicFeatureInterpretationCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
