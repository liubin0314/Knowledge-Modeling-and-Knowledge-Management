/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the coordinated air sea procedure (CASP) category for a friendly force, indicating the nature of the force relationship to the air commander.";
	}

	private static HashMap<String, ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode> physicalToCode = new HashMap<String, ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode>();

	public static ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode COORDINATED_AIR_SEA_PROCEDURE_ONE = new ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode(
			"Coordinated air/sea procedure one",
			"CASP1",
			"An air-defence capable warship ORGANISATION is under tactical control of the Air Defence Commander.");
	public static final ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode COORDINATED_AIR_SEA_PROCEDURE_TWO = new ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode(
			"Coordinated air/sea procedure two",
			"CASP2",
			"An air-defence capable warship ORGANISATION is working closely with the shore based Air Defence Commander. Tactical control of the ship remains with the Officer in Tactical Command.");
	public static final ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode COORDINATED_AIR_SEA_PROCEDURE_THREE = new ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode(
			"Coordinated air/sea procedure three",
			"CASP3",
			"A warship ORGANISATION that is unable to contribute to the Recognized Air Picture but requires receiving it normally via the Joint Anti-Air Warfare Shore Coordination net.");
	public static final ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode COORDINATED_AIR_SEA_PROCEDURE_FOUR = new ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode(
			"Coordinated air/sea procedure four",
			"CASP4",
			"An air-defence capable warship ORGANISATION, entering or berthed in a port or anchorage, which is able to assist the SOC/CAOC in whose sector the port or anchorage is located.");

	private ActionMaritimeEmploymentCoordinatedAirSeaProcedureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
