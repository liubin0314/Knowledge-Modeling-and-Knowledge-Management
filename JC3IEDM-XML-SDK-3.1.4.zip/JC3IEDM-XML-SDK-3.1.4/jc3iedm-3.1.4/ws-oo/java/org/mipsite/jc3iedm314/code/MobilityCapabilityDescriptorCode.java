/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MobilityCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the MOBILITY-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, MobilityCapabilityDescriptorCode> physicalToCode = new HashMap<String, MobilityCapabilityDescriptorCode>();

	public static MobilityCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MobilityCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MobilityCapabilityDescriptorCode MAXIMUM_ALTITUDE = new MobilityCapabilityDescriptorCode(
			"Maximum altitude",
			"MALTID",
			"The highest elevation above sea-level at which a specified aircraft can fly.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_FORDING_DEPTH = new MobilityCapabilityDescriptorCode(
			"Maximum fording depth",
			"MAXFOR",
			"The one-dimensional linear measurement denoting the greatest depth a vehicle can traverse.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_DEPTH = new MobilityCapabilityDescriptorCode(
			"Maximum depth",
			"MDEPTH",
			"The one-dimensional linear measurement that represents the greatest depth at which a vessel can operate.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_ONE_WAY_TRACKED = new MobilityCapabilityDescriptorCode(
			"Military load classification - one-way tracked",
			"MLCOWT",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by tracked vehicles in one-way traffic.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_ONE_WAY_WHEELED = new MobilityCapabilityDescriptorCode(
			"Military load classification - one-way wheeled",
			"MLCOWW",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by wheeled vehicles in one-way traffic.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_TRACKED = new MobilityCapabilityDescriptorCode(
			"Military load classification - tracked",
			"MLCTRK",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by tracked vehicles.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_TWO_WAY_TRACKED = new MobilityCapabilityDescriptorCode(
			"Military load classification - two-way tracked",
			"MLCTWT",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by tracked vehicles in two-way traffic.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_TWO_WAY_WHEELED = new MobilityCapabilityDescriptorCode(
			"Military load classification - two-way wheeled",
			"MLCTWW",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by wheeled vehicles in two-way traffic.");
	public static final MobilityCapabilityDescriptorCode MILITARY_LOAD_CLASSIFICATION_WHEELED = new MobilityCapabilityDescriptorCode(
			"Military load classification - wheeled",
			"MLCWHL",
			"The specific value that represents the military class number indicating the relationship between the load bearing capacity of a terrain feature or man-made structure and the effect produced by wheeled vehicles.");
	public static final MobilityCapabilityDescriptorCode MINIMUM_LANDING_DISTANCE = new MobilityCapabilityDescriptorCode(
			"Minimum landing distance",
			"MNLAND",
			"The shortest stretch of unblocked and flat terrain or water required by an aircraft for it to be able to land.");
	public static final MobilityCapabilityDescriptorCode MINIMUM_SPEED = new MobilityCapabilityDescriptorCode(
			"Minimum speed",
			"MNMSPD",
			"The slowest speed at which a piece of equipment can operate and remain functional.");
	public static final MobilityCapabilityDescriptorCode MINIMUM_TAKE_OFF_DISTANCE = new MobilityCapabilityDescriptorCode(
			"Minimum take off distance",
			"MNTOFF",
			"The shortest stretch of unblocked and flat terrain or water required by an aircraft for it to be able to take off.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_OBSTACLE_GRADIENT_ANGLE = new MobilityCapabilityDescriptorCode(
			"Maximum obstacle gradient angle",
			"MOBGRA",
			"The numeric value representing the gradient of the steepest slope that can be climbed or descended head-on.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_RANGE = new MobilityCapabilityDescriptorCode(
			"Maximum range",
			"MRANGE",
			"The longest distance that can be achieved.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_SPEED = new MobilityCapabilityDescriptorCode(
			"Maximum speed",
			"MSPEED",
			"The highest velocity in any direction that can be achieved for a prolonged period of time.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_SIDE_SLOPE_ANGLE = new MobilityCapabilityDescriptorCode(
			"Maximum side slope angle",
			"MSSLOP",
			"The numeric value representing the gradient of the steepest slope that can be traversed in a direction perpendicular to that slope.");
	public static final MobilityCapabilityDescriptorCode MAXIMUM_TRENCH_WIDTH = new MobilityCapabilityDescriptorCode(
			"Maximum trench width",
			"MTRENC",
			"The one-dimensional linear measurement that represents the largest horizontal distance of any aperture that can be successfully navigated.");
	public static final MobilityCapabilityDescriptorCode MINIMUM_DEPTH = new MobilityCapabilityDescriptorCode(
			"Minimum depth",
			"NDEPTH",
			"The one-dimensional linear measurement that represents the shallowest depth a vessel can navigate.");
	public static final MobilityCapabilityDescriptorCode MINIMUM_RANGE = new MobilityCapabilityDescriptorCode(
			"Minimum range",
			"NRANGE",
			"The shortest distance that can be achieved.");
	public static final MobilityCapabilityDescriptorCode PLANNING_RANGE = new MobilityCapabilityDescriptorCode(
			"Planning range",
			"PRANGE",
			"The average distance that can be achieved which is considered normal for planning purposes.");
	public static final MobilityCapabilityDescriptorCode PLANNING_SPEED = new MobilityCapabilityDescriptorCode(
			"Planning speed",
			"PSPEED",
			"The average speed that can be achieved which is considered normal for planning purposes.");

	private MobilityCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
