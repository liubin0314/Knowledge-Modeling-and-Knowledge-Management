/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ExecutiveMilitaryOrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of EXECUTIVE-MILITARY-ORGANISATION-TYPE.";
	}

	private static HashMap<String, ExecutiveMilitaryOrganisationTypeCategoryCode> physicalToCode = new HashMap<String, ExecutiveMilitaryOrganisationTypeCategoryCode>();

	public static ExecutiveMilitaryOrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ExecutiveMilitaryOrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ExecutiveMilitaryOrganisationTypeCategoryCode HEADQUARTERS = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Headquarters",
			"HQ",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE that performs the management functions of an international, national, strategic or service headquarters.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode LOGISTICS = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Logistics",
			"LOG",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE that provides management of logistics services.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode MILITARY_SERVICE = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Military service",
			"MILSVC",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE, other than police, that manages the training, equipping, manning, and operating of an armed uniformed force.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode PERSONNEL = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Personnel",
			"PRSNL",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE that provides management of personnel services.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode SUPPLY = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Supply",
			"SUPPLY",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE that provides management of supply services.");
	public static final ExecutiveMilitaryOrganisationTypeCategoryCode TRANSPORTATION = new ExecutiveMilitaryOrganisationTypeCategoryCode(
			"Transportation",
			"TRNPTN",
			"An EXECUTIVE-MILITARY-ORGANISATION-TYPE that provides management of transportation services.");

	private ExecutiveMilitaryOrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
