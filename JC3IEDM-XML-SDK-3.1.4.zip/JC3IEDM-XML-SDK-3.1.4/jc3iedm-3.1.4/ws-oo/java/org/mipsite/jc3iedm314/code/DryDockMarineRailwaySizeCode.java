/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class DryDockMarineRailwaySizeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the bearing capacity of the underwater railway in the DRY-DOCK.";
	}

	private static HashMap<String, DryDockMarineRailwaySizeCode> physicalToCode = new HashMap<String, DryDockMarineRailwaySizeCode>();

	public static DryDockMarineRailwaySizeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<DryDockMarineRailwaySizeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final DryDockMarineRailwaySizeCode LARGE = new DryDockMarineRailwaySizeCode(
			"Large",
			"L",
			"Large - over 1000 tons.");
	public static final DryDockMarineRailwaySizeCode MEDIUM = new DryDockMarineRailwaySizeCode(
			"Medium",
			"M",
			"Medium - 201 to 1000 tons.");
	public static final DryDockMarineRailwaySizeCode SMALL = new DryDockMarineRailwaySizeCode(
			"Small",
			"S",
			"Small - Up to 200 tons.");

	private DryDockMarineRailwaySizeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
