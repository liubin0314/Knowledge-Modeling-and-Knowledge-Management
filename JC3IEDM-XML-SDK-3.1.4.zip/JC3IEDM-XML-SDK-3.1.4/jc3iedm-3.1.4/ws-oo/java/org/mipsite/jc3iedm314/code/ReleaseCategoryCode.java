/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReleaseCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the chemical, biological, or radiological class of release.";
	}

	private static HashMap<String, ReleaseCategoryCode> physicalToCode = new HashMap<String, ReleaseCategoryCode>();

	public static ReleaseCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReleaseCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReleaseCategoryCode CONTINUOUS = new ReleaseCategoryCode(
			"Continuous",
			"CONT",
			"A continuous discharge of a contaminant release in a release other than attack (ROTA) event.");
	public static final ReleaseCategoryCode NOT_KNOWN = new ReleaseCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ReleaseCategoryCode NOT_OTHERWISE_SPECIFIED = new ReleaseCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ReleaseCategoryCode SINGLE_RELEASE_OF_A_CLOUD = new ReleaseCategoryCode(
			"Single release of a cloud",
			"PUFF",
			"A single discharge of a contaminant release in a release other than attack (ROTA) event.");
	public static final ReleaseCategoryCode SPRAYING = new ReleaseCategoryCode(
			"Spraying",
			"SPRAY",
			"The spraying of a contaminant in a release other than attack (ROTA) event.");

	private ReleaseCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
