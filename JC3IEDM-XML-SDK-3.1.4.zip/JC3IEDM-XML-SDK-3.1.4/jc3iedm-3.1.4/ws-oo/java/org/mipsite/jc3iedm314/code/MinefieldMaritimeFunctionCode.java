/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinefieldMaritimeFunctionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the intended function of a specific MINEFIELD-MARITIME.";
	}

	private static HashMap<String, MinefieldMaritimeFunctionCode> physicalToCode = new HashMap<String, MinefieldMaritimeFunctionCode>();

	public static MinefieldMaritimeFunctionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinefieldMaritimeFunctionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinefieldMaritimeFunctionCode DEFENSIVE = new MinefieldMaritimeFunctionCode(
			"Defensive",
			"DEFSV",
			"A minefield employed to protect an ORGANISATION, FACILITY, or FEATURE that is laid in international waters.");
	public static final MinefieldMaritimeFunctionCode OFFENSIVE = new MinefieldMaritimeFunctionCode(
			"Offensive",
			"OFFSV",
			"A minefield employed as an obstacle laid in enemy waters.");
	public static final MinefieldMaritimeFunctionCode PROTECTIVE = new MinefieldMaritimeFunctionCode(
			"Protective",
			"PROTCT",
			"A minefield employed to protect an ORGANISATION, FACILITY, or FEATURE.");

	private MinefieldMaritimeFunctionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
