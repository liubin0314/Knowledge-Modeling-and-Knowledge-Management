/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AssociationStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific status refers to the beginning or termination of the association.";
	}

	private static HashMap<String, AssociationStatusCategoryCode> physicalToCode = new HashMap<String, AssociationStatusCategoryCode>();

	public static AssociationStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AssociationStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AssociationStatusCategoryCode END = new AssociationStatusCategoryCode(
			"End",
			"END",
			"The period of effectiveness of the specific association is terminating.");
	public static final AssociationStatusCategoryCode START = new AssociationStatusCategoryCode(
			"Start",
			"START",
			"The period of effectiveness of the specific association is beginning.");

	private AssociationStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
