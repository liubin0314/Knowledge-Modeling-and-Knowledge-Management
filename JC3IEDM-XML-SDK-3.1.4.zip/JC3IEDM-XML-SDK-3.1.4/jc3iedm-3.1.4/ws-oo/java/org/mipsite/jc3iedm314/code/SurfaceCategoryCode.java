/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class SurfaceCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of SURFACE.";
	}

	private static HashMap<String, SurfaceCategoryCode> physicalToCode = new HashMap<String, SurfaceCategoryCode>();

	public static SurfaceCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<SurfaceCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final SurfaceCategoryCode CORRIDOR_AREA = new SurfaceCategoryCode(
			"CORRIDOR-AREA",
			"CORDAR",
			"A SURFACE that is defined by its width and a sequence of points.");
	public static final SurfaceCategoryCode ELLIPSE = new SurfaceCategoryCode(
			"ELLIPSE",
			"ELLPSE",
			"A planar SURFACE in the form of an ellipse.");
	public static final SurfaceCategoryCode FAN_AREA = new SurfaceCategoryCode(
			"FAN-AREA",
			"FA",
			"A SURFACE that is in the form of a truncated ring sector, which is a sector lying between and being bounded by the rays emanating from the centre-point of the ring and having a central angle.");
	public static final SurfaceCategoryCode ORBIT_AREA = new SurfaceCategoryCode(
			"ORBIT-AREA",
			"ORBTAR",
			"An AREA that is (a) an open rectangular section defined by its width and the distance between the two specific POINTS, (b) is closed by two half-circles with radii equal to half the width, and is positioned left, centred, or right with respect to the line formed by the defining points.");
	public static final SurfaceCategoryCode POLYARC_AREA = new SurfaceCategoryCode(
			"POLYARC-AREA",
			"PLYAAR",
			"An AREA that consists of a circular arc and a polygonal segment defined by a specific LINE whose beginning coincides with the initial point of the arc and whose end coincides with the last point of the arc.");
	public static final SurfaceCategoryCode POLYGON_AREA = new SurfaceCategoryCode(
			"POLYGON-AREA",
			"PLYGAR",
			"An AREA that has its boundaries defined by a specific LINE.");
	public static final SurfaceCategoryCode TRACK_AREA = new SurfaceCategoryCode(
			"TRACK-AREA",
			"TRCKAR",
			"An AREA that is a rectangular section with its length defined by the two specific POINTs and its width by the sum of the widths to the left and right of the connecting line between the two points.");

	private SurfaceCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
