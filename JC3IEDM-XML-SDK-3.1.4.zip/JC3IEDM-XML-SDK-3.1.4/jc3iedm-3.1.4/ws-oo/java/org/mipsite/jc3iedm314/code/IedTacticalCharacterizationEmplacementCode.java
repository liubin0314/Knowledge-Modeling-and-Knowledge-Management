/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class IedTacticalCharacterizationEmplacementCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that describes where the device is positioned.";
	}

	private static HashMap<String, IedTacticalCharacterizationEmplacementCode> physicalToCode = new HashMap<String, IedTacticalCharacterizationEmplacementCode>();

	public static IedTacticalCharacterizationEmplacementCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<IedTacticalCharacterizationEmplacementCode> getCodes() {
		return physicalToCode.values();
	}

	public static final IedTacticalCharacterizationEmplacementCode IN_ON = new IedTacticalCharacterizationEmplacementCode(
			"In/on",
			"INON",
			"IED emplaced inside or directly on an object.");
	public static final IedTacticalCharacterizationEmplacementCode OVERHEAD = new IedTacticalCharacterizationEmplacementCode(
			"Overhead",
			"OVERHD",
			"IED emplaced in a structure above the intended target.");
	public static final IedTacticalCharacterizationEmplacementCode SUBSURFACE = new IedTacticalCharacterizationEmplacementCode(
			"Subsurface",
			"SUBSFC",
			"IED emplaced under the surface or below the intended target, i.e. buried, in a culvert, underwater.");
	public static final IedTacticalCharacterizationEmplacementCode SURFACE = new IedTacticalCharacterizationEmplacementCode(
			"Surface",
			"SURFAC",
			"IED emplaced directly on the ground or water surface.");
	public static final IedTacticalCharacterizationEmplacementCode NOT_OTHERWISE_SPECIFIED = new IedTacticalCharacterizationEmplacementCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final IedTacticalCharacterizationEmplacementCode NOT_KNOWN = new IedTacticalCharacterizationEmplacementCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private IedTacticalCharacterizationEmplacementCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
