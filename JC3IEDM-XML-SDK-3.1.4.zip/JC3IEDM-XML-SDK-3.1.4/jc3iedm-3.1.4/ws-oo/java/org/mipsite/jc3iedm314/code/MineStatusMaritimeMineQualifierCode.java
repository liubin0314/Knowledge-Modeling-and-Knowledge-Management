/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MineStatusMaritimeMineQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the qualification status of a specific maritime mine.";
	}

	private static HashMap<String, MineStatusMaritimeMineQualifierCode> physicalToCode = new HashMap<String, MineStatusMaritimeMineQualifierCode>();

	public static MineStatusMaritimeMineQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MineStatusMaritimeMineQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MineStatusMaritimeMineQualifierCode COUNTERMINED = new MineStatusMaritimeMineQualifierCode(
			"Countermined",
			"CNTMND",
			"A maritime mine rendered inoperative by the shock of a nearby explosion of another or independent explosive charge, resulting in the main charge of the maritime mine exploding.");
	public static final MineStatusMaritimeMineQualifierCode DISPOSED = new MineStatusMaritimeMineQualifierCode(
			"Disposed",
			"DISPSD",
			"Mine has been destroyed or rendered harmless and discarded.");
	public static final MineStatusMaritimeMineQualifierCode EXPLODED_LEFT_SIDE = new MineStatusMaritimeMineQualifierCode(
			"Exploded left side",
			"EXPLLS",
			"Mine partially destroyed on the left side by gunfire.");
	public static final MineStatusMaritimeMineQualifierCode EXPLODED_RIGHT_SIDE = new MineStatusMaritimeMineQualifierCode(
			"Exploded right side",
			"EXPLRS",
			"Mine partially destroyed on the right side by gunfire.");
	public static final MineStatusMaritimeMineQualifierCode FLOATING = new MineStatusMaritimeMineQualifierCode(
			"Floating",
			"FLOATN",
			"Mine visible on the surface.");
	public static final MineStatusMaritimeMineQualifierCode FOULED = new MineStatusMaritimeMineQualifierCode(
			"Fouled",
			"FOULED",
			"Mine is entangled in some obstruction, unable to deploy as designed.");
	public static final MineStatusMaritimeMineQualifierCode NEUTRALIZED = new MineStatusMaritimeMineQualifierCode(
			"Neutralized",
			"NEUTRL",
			"Mine rendered, by external means, permanently incapable of firing on passage of a vehicle sweep, although it may remain dangerous to handle. The mine case may remain virtually intact.");
	public static final MineStatusMaritimeMineQualifierCode NOT_DEALT_WITH = new MineStatusMaritimeMineQualifierCode(
			"Not dealt with",
			"NOTDLT",
			"The located mine remains in its detected position and no action has been taken against the mine.");
	public static final MineStatusMaritimeMineQualifierCode RECOVERED = new MineStatusMaritimeMineQualifierCode(
			"Recovered",
			"RECVRD",
			"Mine salvaged as nearly as intact as possible to permit further investigation for intelligence and/or evaluation purposes.");
	public static final MineStatusMaritimeMineQualifierCode REMOVED = new MineStatusMaritimeMineQualifierCode(
			"Removed",
			"REMOVD",
			"Mine removed out of an area where its detonation would be unacceptable.");
	public static final MineStatusMaritimeMineQualifierCode RENDERED_SAFE = new MineStatusMaritimeMineQualifierCode(
			"Rendered safe",
			"RNDRSF",
			"The interruption of the function or separation of essential components of unexploded ordnance to prevent an unacceptable detonation.");
	public static final MineStatusMaritimeMineQualifierCode SUNKEN = new MineStatusMaritimeMineQualifierCode(
			"Sunken",
			"SUNKEN",
			"Buoyant mine holed, either deliberately or through malfunction, water filled and allowed to sink to the bottom surface.");

	private MineStatusMaritimeMineQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
