/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ControlFeatureTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of CONTROL-FEATURE-TYPE.";
	}

	private static HashMap<String, ControlFeatureTypeCategoryCode> physicalToCode = new HashMap<String, ControlFeatureTypeCategoryCode>();

	public static ControlFeatureTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ControlFeatureTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ControlFeatureTypeCategoryCode AIR_AXIS_OF_ADVANCE = new ControlFeatureTypeCategoryCode(
			"Air axis of advance",
			"AAXIS",
			"A general air corridor of advance, which extends towards the enemy. An air axis of advance symbol graphically portrays a commander�s air manoeuvre intention, such as avoidance air defence coverage or envelopment of an enemy force. It follows an axis suitable for the airmobile force to which the axis was assigned. An air axis of advance does not directly control or use terrain.");
	public static final ControlFeatureTypeCategoryCode AIRCRAFT_CONTROL_POSITION = new ControlFeatureTypeCategoryCode(
			"Aircraft control position",
			"ACCPOS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1044/66.");
	public static final ControlFeatureTypeCategoryCode AIR_DEFENCE_ACTION_AREA = new ControlFeatureTypeCategoryCode(
			"Air defence action area",
			"ADACAR",
			"An area and the airspace above it within which friendly aircraft or surface-to-air weapons are normally given precedence in operations except under specified conditions.");
	public static final ControlFeatureTypeCategoryCode AIR_DEFENCE_AREA = new ControlFeatureTypeCategoryCode(
			"Air defence area",
			"ADAREA",
			"A specifically defined airspace for which air defence must be planned and provided.");
	public static final ControlFeatureTypeCategoryCode AIR_DEFENCE_IDENTIFICATION_ZONE = new ControlFeatureTypeCategoryCode(
			"Air defence identification zone",
			"ADIDZN",
			"Airspace within which ready identification, location, and control of airborne vehicles are required.");
	public static final ControlFeatureTypeCategoryCode AIR_DEFENCE_OPERATIONS_AREA = new ControlFeatureTypeCategoryCode(
			"Air defence operations area",
			"ADOPAR",
			"A geographical area within which procedures are established to minimize interference between air defence operations and other types of operations.");
	public static final ControlFeatureTypeCategoryCode AIM_POINT = new ControlFeatureTypeCategoryCode(
			"Aim point",
			"AIMPT",
			"A point associated with a target and assigned for a specific weapon impact.");
	public static final ControlFeatureTypeCategoryCode AIRSPACE_CONTROL_AREA = new ControlFeatureTypeCategoryCode(
			"Airspace control area",
			"AIRCAR",
			"Airspace which is laterally defined by boundaries of the area of operations.");
	public static final ControlFeatureTypeCategoryCode AIRSPACE_COORDINATION_AREA = new ControlFeatureTypeCategoryCode(
			"Airspace coordination area",
			"AIRCOA",
			"A CONTROL-FEATURE-TYPE that is a three-dimensional block of airspace in a target area, established by the appropriate ground commander, in which friendly aircraft are reasonably safe from friendly surface fire. The ACA may be formal or informal.");
	public static final ControlFeatureTypeCategoryCode AIRSPACE_CONTROL_SUBAREA_SECTOR = new ControlFeatureTypeCategoryCode(
			"Airspace control subarea/sector",
			"AIRCSA",
			"Sub-element of an airspace control area, established to facilitate the control of the overall area.");
	public static final ControlFeatureTypeCategoryCode AIR_CONTROL_POINT = new ControlFeatureTypeCategoryCode(
			"Air control point",
			"AIRCTP",
			"An easily identifiable point on the terrain or an electronic navigational aid used to provide necessary control during air movement. Air control points are generally designated at each point where the flight route or air corridor makes a definite change in any direction and at any other point deemed necessary for timing or control of the operation.");
	public static final ControlFeatureTypeCategoryCode AIRBORNE_EARLY_WARNING_AREA = new ControlFeatureTypeCategoryCode(
			"Airborne early warning area",
			"AIREWA",
			"Airspace established specifically for airborne platforms conducting early warning.");
	public static final ControlFeatureTypeCategoryCode AIRHEAD = new ControlFeatureTypeCategoryCode(
			"Airhead",
			"AIRH",
			"A designated area in a hostile or threatened territory which, when seized and held, ensures the continuous air landing of troops and material and provides manoeuvre space for operations. Normally it is the area seized in the assault phase of an airborne or air assault operation. Army--The airhead contains enough drop zones (DZs), landing zones (LZs), and extraction zones (EZs) to ensure mass, interior lines of communication and defence in depth.");
	public static final ControlFeatureTypeCategoryCode AIR_TO_AIR_REFUELLING_AREA = new ControlFeatureTypeCategoryCode(
			"Air-to-air refuelling area",
			"AIRRFL",
			"Airspace of defined dimensions set aside for air-to-air refuelling operations, excluding special operation forces air-to-air missions.");
	public static final ControlFeatureTypeCategoryCode ALERT_AREA = new ControlFeatureTypeCategoryCode(
			"Alert area",
			"ALRTAR",
			"Airspace which may contain a high volume of pilot training activities or an unusual type of aerial activity, neither of which is hazardous to aircraft.");
	public static final ControlFeatureTypeCategoryCode ALTITUDE_RESERVATION_AREA = new ControlFeatureTypeCategoryCode(
			"Altitude reservation area",
			"ALTRAR",
			"Block of altitude, normally medium to high, reserved for aircraft to transit or loiter within the Force Air Coordination Area (FACA) for mission accomplishment.");
	public static final ControlFeatureTypeCategoryCode AMBULANCE_EXCHANGE_POINT = new ControlFeatureTypeCategoryCode(
			"Ambulance exchange point",
			"AMBEXP",
			"A location where a patient is transferred from one ambulance to another en-route to a medical treatment facility. This may be an established point in an ambulance shuttle system or it may be designated independently.");
	public static final ControlFeatureTypeCategoryCode AMPHIBIOUS_DEFENCE_ZONE = new ControlFeatureTypeCategoryCode(
			"Amphibious defence zone",
			"AMPDZN",
			"Area encompassing the amphibious objective area and adjoining airspace as required for the accompanying naval force.");
	public static final ControlFeatureTypeCategoryCode AMPHIBIOUS_OPERATION_AREA = new ControlFeatureTypeCategoryCode(
			"Amphibious operation area",
			"AMPHOA",
			"A CONTROL-FEATURE-TYPE with an area location, delineated in the initiating directive, for purposes of command and control within which is located the objective(s) to be secured by the amphibious task force.");
	public static final ControlFeatureTypeCategoryCode AMPHIBIOUS_OBJECTIVE_AREA = new ControlFeatureTypeCategoryCode(
			"Amphibious objective area",
			"AMPOZN",
			"Geographic area delineated for the purpose of command and control within which is located the objective(s) to be secured by the amphibious task force.");
	public static final ControlFeatureTypeCategoryCode AREA_OF_COVERAGE = new ControlFeatureTypeCategoryCode(
			"Area of coverage",
			"AOC",
			"The summation of geographical areas under surveillance or protected by supporting fire.");
	public static final ControlFeatureTypeCategoryCode AREA_OF_INTEREST = new ControlFeatureTypeCategoryCode(
			"Area of interest",
			"AOI",
			"A CONTROL-FEATURE-TYPE with an area location which denotes that area of concern to the commander, including the area of influence, and extending into enemy territory to the objectives of current or planned operations. This area also includes areas occupied by enemy forces that could jeopardise the accomplishment of the mission.");
	public static final ControlFeatureTypeCategoryCode AREA_OF_OPERATIONS = new ControlFeatureTypeCategoryCode(
			"Area of operations",
			"AOP",
			"That portion of an area necessary for military operations and for the administration of such operations. Army--A geographical area, usually defined by lateral, forward, and rear boundaries assigned to a commander, by a higher commander, in which he has responsibility and the authority to conduct military operations.");
	public static final ControlFeatureTypeCategoryCode AREA_OF_RESPONSIBILITY = new ControlFeatureTypeCategoryCode(
			"Area of responsibility",
			"AOR",
			"A CONTROL-FEATURE-TYPE with an area location which defines an area of land in which responsibility is specifically assigned to the commander of the area for the development and maintenance of installations, control of movement and the conduct of tactical operations involving troops under his control along with parallel authority to exercise these functions.");
	public static final ControlFeatureTypeCategoryCode APPROACH_DIRECTION = new ControlFeatureTypeCategoryCode(
			"Approach direction",
			"APPRDR",
			"A CONTROL-FEATURE-TYPE that specifies approach directional details for takeoff and landing.");
	public static final ControlFeatureTypeCategoryCode ARTILLERY_AREA = new ControlFeatureTypeCategoryCode(
			"Artillery area",
			"ARA",
			"A CONTROL-FEATURE-TYPE with an area location assigned to artillery units for terrain management purposes on which the artillery manoeuvres.");
	public static final ControlFeatureTypeCategoryCode AIRFIELD_ZONE = new ControlFeatureTypeCategoryCode(
			"Airfield zone",
			"ARFLDZ",
			"A CONTROL-FEATURE-TYPE that approximates the location of the airspace of an airfield.");
	public static final ControlFeatureTypeCategoryCode ASSAULT_POSITION = new ControlFeatureTypeCategoryCode(
			"Assault position",
			"ASLTPO",
			"That position between the line of departure (LD) and the objective in an attack from which forces assault the objective. Ideally, it is the last covered and concealed position before reaching the objective.");
	public static final ControlFeatureTypeCategoryCode ASSEMBLY_AREA_GENERAL = new ControlFeatureTypeCategoryCode(
			"Assembly area, general",
			"ASYGEN",
			"An area in which a command is assembled preparatory to further action.");
	public static final ControlFeatureTypeCategoryCode ASSEMBLY_AREA_SUPPLY = new ControlFeatureTypeCategoryCode(
			"Assembly area, supply",
			"ASYSPL",
			"In a supply installation, the gross area used for collecting and combining components into complete units, kits, or assemblies.");
	public static final ControlFeatureTypeCategoryCode AIR_TRAFFIC_CONTROL_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Air traffic control airspace",
			"ATCAIR",
			"Airspace of defined dimensions within which air traffic control service is provided to instrument flight rules (IFR) and visual flight rules (VFR) flights in accordance with civil air traffic control regulations.");
	public static final ControlFeatureTypeCategoryCode ATTACK_BY_FIRE_POSITION = new ControlFeatureTypeCategoryCode(
			"Attack by fire position",
			"ATTFIR",
			"A CONTROL-FEATURE-TYPE that is an area against which fire is employed to destroy the enemy from a distance, normally used when the mission does not dictate or support occupation of the objective.");
	public static final ControlFeatureTypeCategoryCode ATTACK_POSITION = new ControlFeatureTypeCategoryCode(
			"Attack position",
			"ATTPOS",
			"The last position occupied or passed through by the assault echelon before crossing the line of departure (LD).");
	public static final ControlFeatureTypeCategoryCode AXIS_OF_ADVANCE = new ControlFeatureTypeCategoryCode(
			"Axis of advance",
			"AXIS",
			"A general route of advance, assigned for control, which extends towards the enemy. An axis of advance symbol graphically portrays a commander�s intention, such as avoidance of built-up areas or envelopment of an enemy force. It follows terrain suitable for the size of the force to which the axis was assigned, and is often a road, a group of roads, or a designated series of locations. An axis of advance is not used to direct the control of terrain or the clearance of enemy forces from specific locations. Intermediate objectives are normally assigned for these purposes.");
	public static final ControlFeatureTypeCategoryCode BASE_DEFENCE_ZONE = new ControlFeatureTypeCategoryCode(
			"Base defence zone",
			"BASDZN",
			"A zone established around airbases to enhance the effectiveness of local ground based air defence systems.");
	public static final ControlFeatureTypeCategoryCode BATTLE_POSITION = new ControlFeatureTypeCategoryCode(
			"Battle position",
			"BATPOS",
			"1. A defensive location oriented on a likely enemy avenue of approach. (FM 3-90) 2. For attack helicopters, an area designated in which they can manoeuvre and fire into a designated engagement area or engage targets of opportunity. (FM 1-112) (Marine Corps) 1. In ground operations, a defensive location oriented on an enemy avenue of approach from which a unit may defend. 2. In air operations, an airspace coordination area containing fire points for attack helicopters.");
	public static final ControlFeatureTypeCategoryCode BEACHHEAD = new ControlFeatureTypeCategoryCode(
			"Beachhead",
			"BCHH",
			"A designated area on a hostile or potentially hostile shore that, when seized and held, ensures the continuous landing of troops and materiel, and provides manoeuvre space requisite for subsequent projected operations ashore.");
	public static final ControlFeatureTypeCategoryCode BOUNDARY_ORGANISATION = new ControlFeatureTypeCategoryCode(
			"Boundary, organisation",
			"BDYOR",
			"1. A line which delineates surface areas (or airspace) for the purpose of facilitating coordination and deconfliction of operations between adjacent units, formations or areas. 2. A control measure normally drawn along identifiable terrain features and used to delineate areas of tactical responsibility between adjacent units and between higher headquarters to the rear of the subordinate units. Control measures which define the left and right limits of a unit's zone of action or sector. Together with the rear and forward boundary and a coordinating altitude, lateral boundaries define the area of operations for a commander.");
	public static final ControlFeatureTypeCategoryCode BOUNDARY_POLITICAL_ADMINISTRATIVE = new ControlFeatureTypeCategoryCode(
			"Boundary, political/administrative",
			"BDYPOA",
			"A CONTROL-FEATURE-TYPE with a line location by which political or administrative areas of responsibility are defined.");
	public static final ControlFeatureTypeCategoryCode BOUNDARY_POINT = new ControlFeatureTypeCategoryCode(
			"Boundary point",
			"BDYPT",
			"A point on a boundary.");
	public static final ControlFeatureTypeCategoryCode BEARING_LINE = new ControlFeatureTypeCategoryCode(
			"Bearing line",
			"BERLIN",
			"A CONTROL-FEATURE-TYPE that is the angle and direction from which electronic, acoustic, or optical contact is made.");
	public static final ControlFeatureTypeCategoryCode BIOLOGICAL_ATMOSPHERIC_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Biological atmospheric concentration contour line",
			"BIOATC",
			"A line on a map, diagram or overlay joining all points at which the biological atmospheric concentration at a given time is the same. Biological atmospheric concentration is the mass of a biological substance distributed in the atmosphere per unit volume.");
	public static final ControlFeatureTypeCategoryCode BIOLOGICAL_CONCENTRATION_TIME_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Biological concentration time contour line",
			"BIOCNT",
			"A line on a map, diagram or overlay joining all points at which the biological concentration-time (for which a quantified portion of exposed personnel are expected to experience (or not experience) effects of given severity) at a given time is the same. Biological concentration time is the product of the concentration of a biological substance in the atmosphere and the exposure time.");
	public static final ControlFeatureTypeCategoryCode BIOLOGICALLY_CONTAMINATED_AREA = new ControlFeatureTypeCategoryCode(
			"Biologically contaminated area",
			"BIOCTM",
			"A CONTROL-FEATURE-TYPE that identifies the predicted or confirmed contour of an area in which biological agents may produce casualties in man or animals and damage to plants or materiel.");
	public static final ControlFeatureTypeCategoryCode BIOLOGICAL_SURFACE_DEPOSITION_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Biological surface deposition concentration contour line",
			"BIODPC",
			"A line on a map, diagram or overlay joining all points at which the biological surface deposition concentration at a given time is the same. Biological surface deposition concentration is the mass of a biological substance distributed on a surface per unit area.");
	public static final ControlFeatureTypeCategoryCode BLOCKING_POSITION = new ControlFeatureTypeCategoryCode(
			"Blocking position",
			"BLOPOS",
			"A defensive position so sited as to deny the enemy access to a given area or to prevent his advance in a given direction.");
	public static final ControlFeatureTypeCategoryCode BOMB_AREA = new ControlFeatureTypeCategoryCode(
			"Bomb area",
			"BOMBAR",
			"An area or a group of targets constituting an area designated for bombing.");
	public static final ControlFeatureTypeCategoryCode BOUNDARY_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Boundary, airspace",
			"BOUNDR",
			"The lateral limits of an airspace control area, airspace control sub-area, high-density airspace control zone or airspace restricted area.");
	public static final ControlFeatureTypeCategoryCode BRIDGEHEAD = new ControlFeatureTypeCategoryCode(
			"Bridgehead",
			"BRDGH",
			"An area of ground held or to be gained on the enemy�s side of an obstacle. Army--In river-crossing operations, an area on the enemy�s side of the water obstacle that is large enough to accommodate the majority of the crossing force, has adequate terrain to permit defence of the crossing sites, and provides a base for continuing the attack.");
	public static final ControlFeatureTypeCategoryCode BREAK_UP_POINT = new ControlFeatureTypeCategoryCode(
			"Break-up point",
			"BRKUPP",
			"A CONTROL-FEATURE-TYPE that identifies a point where aircraft split up during a mission.");
	public static final ControlFeatureTypeCategoryCode BUFFER_ZONE = new ControlFeatureTypeCategoryCode(
			"Buffer zone",
			"BUFRZN",
			"Airspace designed specifically to provide a buffer between various airspace control measures.");
	public static final ControlFeatureTypeCategoryCode BULLSEYE = new ControlFeatureTypeCategoryCode(
			"Bullseye",
			"BULEYE",
			"An established reference point from which the position of an object can be references by bearing (Magnetic) and range (in nautical miles NM) from this point.");
	public static final ControlFeatureTypeCategoryCode CBRN_HAZARD_AREA = new ControlFeatureTypeCategoryCode(
			"CBRN hazard area",
			"CBRNHA",
			"A CONTROL-FEATURE-TYPE that identifies the predicted or confirmed contour of the NBC (CBRN) hazard area.");
	public static final ControlFeatureTypeCategoryCode CBRN_RELEASE_OR_ATTACK_AREA = new ControlFeatureTypeCategoryCode(
			"CBRN release or attack area",
			"CBRNRA",
			"A CONTROL-FEATURE-TYPE that identifies the predicted or confirmed area immediately affected by the CBRN-EVENT. If the release is an attack, then the release area is generally called the attack area.");
	public static final ControlFeatureTypeCategoryCode CBRN_READING_SAMPLE_DETECTION = new ControlFeatureTypeCategoryCode(
			"CBRN reading/sample/detection",
			"CBRNRS",
			"The point at which a reading, sample or detection of an NBC (CBRN) contaminant is performed.");
	public static final ControlFeatureTypeCategoryCode COORDINATION_FIRE_LINE = new ControlFeatureTypeCategoryCode(
			"Coordination fire line",
			"CFL",
			"A line beyond which conventional surface fire support may fire at any time within the area of operations of the establishing headquarters without additional coordination. NOTE Also known as Coordinated fire line.");
	public static final ControlFeatureTypeCategoryCode CHOKE_POINT = new ControlFeatureTypeCategoryCode(
			"Choke point",
			"CHKPT",
			"A terrain movement restriction of individuals or groups.");
	public static final ControlFeatureTypeCategoryCode CHEMICAL_ATMOSPHERIC_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Chemical atmospheric concentration contour line",
			"CHMATC",
			"A line on a map, diagram or overlay joining all points at which the chemical atmospheric concentration at a given time is the same. Chemical atmospheric concentration is the mass of a chemical substance distributed in the atmosphere per unit volume.");
	public static final ControlFeatureTypeCategoryCode CHEMICAL_CONCENTRATION_TIME_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Chemical concentration time contour line",
			"CHMCNT",
			"A line on a map, diagram or overlay joining all points at which the chemical concentration-time (for which a quantified portion of exposed personnel are expected to experience (or not experience) effects of given severity) at a given time is the same. Chemical concentration time is the product of the concentration of a chemical substance in the atmosphere and the exposure time.");
	public static final ControlFeatureTypeCategoryCode CHEMICALLY_CONTAMINATED_AREA = new ControlFeatureTypeCategoryCode(
			"Chemically contaminated area",
			"CHMCTM",
			"A CONTROL-FEATURE-TYPE that identifies the predicted or confirmed contour of an area in which chemical agents may produce casualties in man or animals and damage to plants or materiel.");
	public static final ControlFeatureTypeCategoryCode CHEMICAL_SURFACE_DEPOSITION_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Chemical surface deposition concentration contour line",
			"CHMDPC",
			"A line on a map, diagram or overlay joining all points at which the chemical surface deposition concentration at a given time is the same. Chemical surface deposition concentration is the mass of a chemical substance distributed on a surface per unit area.");
	public static final ControlFeatureTypeCategoryCode CHECK_POINT_GENERAL = new ControlFeatureTypeCategoryCode(
			"Check point, general",
			"CKPGEN",
			"A CONTROL-FEATURE-TYPE used as a means of controlling movement, a registration target for fire adjustment, or reference for location.");
	public static final ControlFeatureTypeCategoryCode CBRN_CLOUD_RADIUS = new ControlFeatureTypeCategoryCode(
			"CBRN cloud radius",
			"CLDRAD",
			"A CONTROL-FEATURE-TYPE that identifies the linear distance from the centre of the CBRN-EVENT to the outer edge of the initial cloud.");
	public static final ControlFeatureTypeCategoryCode CLASS_A_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-A airspace",
			"CLSASP",
			"An airspace in which only instrument flight rule flights are permitted; all flights are subject to air traffic control service and are separated from each other.");
	public static final ControlFeatureTypeCategoryCode CLASS_B_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-B airspace",
			"CLSBSP",
			"An airspace in which instrument flight rule and visual flight rule flights are permitted; all flights are subject to air traffic control service and are separated from each other.");
	public static final ControlFeatureTypeCategoryCode CLASS_C_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-C airspace",
			"CLSCSP",
			"An airspace in which instrument flight rule and visual flight rule flights are permitted; all flights are subject to air traffic control service and instrument flight rule flights are separated from other instrument flight rule flights and from visual flight rule flights. Visual flight rule flights are separated from instrument flight rule flights and receive traffic information in respect to other visual flight rule flights.");
	public static final ControlFeatureTypeCategoryCode CLASS_D_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-D airspace",
			"CLSDSP",
			"An airspace in which instrument flight rule and visual flight rule flights are permitted; all flights are subject to air traffic control service and instrument flight rule flights are separated from other instrument flight rule flights and receive traffic information in respect to visual flight rule flights. Visual flight rule flights receive traffic information in respect to all other flights.");
	public static final ControlFeatureTypeCategoryCode CLASS_E_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-E airspace",
			"CLSESP",
			"An airspace in which instrument flight rule flights and visual flight rule flights are permitted; all flights are subject to air traffic control service and are separated from other instrument flight rule flights. All flights receive traffic information as far as practical.");
	public static final ControlFeatureTypeCategoryCode CLASS_F_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-F airspace",
			"CLSFSP",
			"An airspace in which instrument flight rule and visual flight rule flights are permitted; all participating instrument flight rule flights receive an air traffic advisory service and all flights receive flight information service if requested.");
	public static final ControlFeatureTypeCategoryCode CLASS_G_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Class-G airspace",
			"CLSGSP",
			"An airspace in which instrument flight rule and visual flights are permitted; all flights receive flight information service if requested.");
	public static final ControlFeatureTypeCategoryCode CLOSE_AIR_SUPPORT_HOLDING_AREA = new ControlFeatureTypeCategoryCode(
			"Close air support holding area",
			"CLSHAR",
			"Airspace designed for holding orbit and used by rotary and fixed-winged aircraft in close proximity to friendly forces.");
	public static final ControlFeatureTypeCategoryCode CONTACT_POINT_AIR = new ControlFeatureTypeCategoryCode(
			"Contact point, air",
			"CNTPTA",
			"A CONTROL-FEATURE-TYPE that identifies the position at which a mission leader makes radio contact with an air control agency. Note: A point used for control purposes in air-to-air refuelling and close air support missions.");
	public static final ControlFeatureTypeCategoryCode CONTACT_POINT_LAND = new ControlFeatureTypeCategoryCode(
			"Contact point, land",
			"CNTPTL",
			"A CONTROL-FEATURE-TYPE with an easily identifiable point location, where two or more units are required to make contact.");
	public static final ControlFeatureTypeCategoryCode COMBAT_AIR_PATROL_AREA = new ControlFeatureTypeCategoryCode(
			"Combat air patrol area",
			"COAPAR",
			"An area established for aircraft to patrol over an objective area, over the force protected, over the critical area of a combat zone, or over an air defence area, for the purpose of interception and destroying hostile aircraft before they reach their target.");
	public static final ControlFeatureTypeCategoryCode COMMUNICATION_CHECKPOINT = new ControlFeatureTypeCategoryCode(
			"Communication checkpoint",
			"COMCKP",
			"An air control point that requires serial leaders to report either to the aviation mission commander or the terminal control facility.");
	public static final ControlFeatureTypeCategoryCode COMMUNICATION_ZONE = new ControlFeatureTypeCategoryCode(
			"Communication zone",
			"COMMZ",
			"A CONTROL-FEATURE-TYPE with an area location which defines the rear part of theatre of operations (behind but contiguous to the combat zone) which contains the lines of communication, establishments for supply and evacuation, and other agencies required for the immediate support and maintenance of the field forces.");
	public static final ControlFeatureTypeCategoryCode CONCENTRATION_AREA = new ControlFeatureTypeCategoryCode(
			"Concentration area",
			"CONCA",
			"An area, usually in the theatre of operations, where troops are assembled before beginning active operations.");
	public static final ControlFeatureTypeCategoryCode CONTROL_AREA = new ControlFeatureTypeCategoryCode(
			"Control area",
			"CONTAR",
			"A controlled airspace extending upwards from a specified limit above the earth.");
	public static final ControlFeatureTypeCategoryCode CONTROL_ZONE = new ControlFeatureTypeCategoryCode(
			"Control zone",
			"CONTZN",
			"A controlled airspace extending upwards from the surface of the earth to a specified upper limit.");
	public static final ControlFeatureTypeCategoryCode COORDINATED_AIR_DEFENCE_AREA = new ControlFeatureTypeCategoryCode(
			"Coordinated air defence area",
			"COOAAR",
			"A mutually defined block of airspace between land-based air commander and a naval commander when their forces are operating in close proximity to one another.");
	public static final ControlFeatureTypeCategoryCode COORDINATION_LEVEL = new ControlFeatureTypeCategoryCode(
			"Coordination level",
			"COORLV",
			"A procedural method to separate fixed and rotary wing aircraft by determining an altitude below which fixed wing aircraft normally will not fly.");
	public static final ControlFeatureTypeCategoryCode CARRIER_CONTROL_ZONE = new ControlFeatureTypeCategoryCode(
			"Carrier control zone",
			"CRCNZN",
			"Area around a ship operating fixed/rotary wing aircraft.");
	public static final ControlFeatureTypeCategoryCode COORDINATING_ALTITUDE = new ControlFeatureTypeCategoryCode(
			"Coordinating altitude",
			"CRDALT",
			"A procedural airspace control method to separate fixed-and rotary-wing aircraft by determining an altitude below which fixed-wing aircraft will normally not fly and above which rotary-wing aircraft normally will not fly. The coordinating altitude is normally specified in the airspace control plan and may include a buffer zone for small altitude deviations.");
	public static final ControlFeatureTypeCategoryCode COORDINATING_POINT = new ControlFeatureTypeCategoryCode(
			"Coordinating point",
			"CRDPNT",
			"Designated point at which, in all types of combat, adjacent units/formations must make contact for purposes of control and coordination. Army--A control measure that indicates a specific location for the coordination of fires and manoeuvre between adjacent units. They usually are indicated whenever a boundary crosses the forward battle area (FEBA), and may be indicated when a boundary crosses phase lines (PLs) used to control security forces.");
	public static final ControlFeatureTypeCategoryCode CROSS_BORDER_AREA = new ControlFeatureTypeCategoryCode(
			"Cross-border area",
			"CRSBAR",
			"A temporary segregated area established over international boundaries for specific operational requirements.");
	public static final ControlFeatureTypeCategoryCode CROSSOVER_ZONE = new ControlFeatureTypeCategoryCode(
			"Crossover zone",
			"CRSVZN",
			"The airspace beyond the maritime Missile Engagement Zone (MEZ) that may be entered by Combat Air Patrol (CAP) aircraft when in hot pursuit in order to complete an interception.");
	public static final ControlFeatureTypeCategoryCode CONTROL_POINT = new ControlFeatureTypeCategoryCode(
			"Control point",
			"CTLPNT",
			"A position along a route of march at which men are stationed to give information and instructions for the regulation of supply or traffic.");
	public static final ControlFeatureTypeCategoryCode COMBAT_ZONE = new ControlFeatureTypeCategoryCode(
			"Combat zone",
			"CZ",
			"A CONTROL-FEATURE-TYPE with an area location that denotes the area required by combat forces for the conduct of operations.");
	public static final ControlFeatureTypeCategoryCode DIRECTION_OF_ATTACK = new ControlFeatureTypeCategoryCode(
			"Direction of attack",
			"DA",
			"A specific direction or route that the main attack or the centre of mass of the unit main body of the force will follow.");
	public static final ControlFeatureTypeCategoryCode DECISION_POINT = new ControlFeatureTypeCategoryCode(
			"Decision point",
			"DECPNT",
			"An event, area, line, or point in the battlespace where tactical decisions are required resulting from the wargaming process or the operations order. Decision points do not dictate commander's decisions, they only indicate that a decision is required, and they indicate when/where the decision should be made to have the maximum effect on friendly or enemy courses of action.");
	public static final ControlFeatureTypeCategoryCode DEFENSIVE_POSITION = new ControlFeatureTypeCategoryCode(
			"Defensive position",
			"DEFPOS",
			"A CONTROL-FEATURE-TYPE that is used in planning to designate a belt of terrain, generally parallel to the front, which includes two or more organised, or partially organised, battle positions.");
	public static final ControlFeatureTypeCategoryCode DEFENCE_ZONE = new ControlFeatureTypeCategoryCode(
			"Defence zone",
			"DEFZ",
			"The area extending from the forward edge of the battle area to its rear boundary.");
	public static final ControlFeatureTypeCategoryCode DESIRED_MEAN_POINT_OF_IMPACT = new ControlFeatureTypeCategoryCode(
			"Desired mean point of impact",
			"DMPI",
			"The point at which a projectile, bomb, or re-entry vehicle is expected to impact.");
	public static final ControlFeatureTypeCategoryCode DANGER_AREA = new ControlFeatureTypeCategoryCode(
			"Danger area",
			"DNGRAR",
			"An airspace of defined dimensions within which activities dangerous to the flight of aircraft may exist at specified times.");
	public static final ControlFeatureTypeCategoryCode DOWNED_AIRCREW_PICKUP_POINT = new ControlFeatureTypeCategoryCode(
			"Downed aircrew pickup point",
			"DNPKPT",
			"A point to where aviators will attempt to evade and escape to be recovered by friendly forces.");
	public static final ControlFeatureTypeCategoryCode DEEP_BATTLE_SYNCHRONISATION_LINE = new ControlFeatureTypeCategoryCode(
			"Deep battle synchronisation line",
			"DPBSLN",
			"The forward boundary of the ground component commander's (GCC) area of operation. The DBSL defines the geographic areas of responsibility of the GCC and air component commander.");
	public static final ControlFeatureTypeCategoryCode DROP_POINT = new ControlFeatureTypeCategoryCode(
			"Drop point",
			"DROPPT",
			"Position of weapon release.");
	public static final ControlFeatureTypeCategoryCode DROP_ZONE = new ControlFeatureTypeCategoryCode(
			"Drop zone",
			"DZ",
			"A specific area upon which airborne troops, equipment, or supplies are airdropped by parachute. NOTE: This zone can include one or more drop sites.");
	public static final ControlFeatureTypeCategoryCode ENGAGEMENT_AREA = new ControlFeatureTypeCategoryCode(
			"Engagement area",
			"EA",
			"An area where the commander intends to contain and destroy an enemy force with the massed fires of all available weapons and supporting systems.");
	public static final ControlFeatureTypeCategoryCode ELECTRONIC_COMBAT_AREA = new ControlFeatureTypeCategoryCode(
			"Electronic combat area",
			"ELCCAR",
			"Airspace established specifically for airborne platforms engaging in electronic combat.");
	public static final ControlFeatureTypeCategoryCode ENCIRCLEMENT = new ControlFeatureTypeCategoryCode(
			"Encirclement",
			"ENCRCL",
			"The loss of freedom of manoeuvre to one force resulting from an enemy force�s control of all routes of egress and reinforcement.");
	public static final ControlFeatureTypeCategoryCode END_AERIAL_REFUELLING_POINT = new ControlFeatureTypeCategoryCode(
			"End aerial refuelling point",
			"ENDARP",
			"A CONTROL-FEATURE-TYPE that identifies the point that marks the end of a straight-line segment along which a tanker aircraft offloads fuel to a receiving aircraft.");
	public static final ControlFeatureTypeCategoryCode END_OF_MISSION_POINT = new ControlFeatureTypeCategoryCode(
			"End of mission point",
			"ENDMPT",
			"The mission will terminate at the specific point.");
	public static final ControlFeatureTypeCategoryCode END_OF_ROUTE_POINT = new ControlFeatureTypeCategoryCode(
			"End of route point",
			"ENDRPT",
			"Identifies the end point of a route.");
	public static final ControlFeatureTypeCategoryCode ENGINEER_REGULATING_POINT = new ControlFeatureTypeCategoryCode(
			"Engineer regulating point",
			"ENGREG",
			"Checkpoint to ensure that vehicles do not exceed the capacity of the crossing means and to give drivers final instructions on site-specific procedures and information, such as speed and vehicle interval.");
	public static final ControlFeatureTypeCategoryCode ENTRY_LINE = new ControlFeatureTypeCategoryCode(
			"Entry line",
			"ENTL",
			"The line bounding a controlled area (such as crossing area) that controls entry to that area.");
	public static final ControlFeatureTypeCategoryCode ENTRY_POINT = new ControlFeatureTypeCategoryCode(
			"Entry point",
			"ENTPT",
			"A point designated for use by vehicles or personnel in entering an area, line or volume.");
	public static final ControlFeatureTypeCategoryCode ENTRY_GATE = new ControlFeatureTypeCategoryCode(
			"Entry gate",
			"ENTRGT",
			"The point to which an aircraft will be directed to commence the transit inbound from an airfield or force at sea.");
	public static final ControlFeatureTypeCategoryCode EXIT_GATE = new ControlFeatureTypeCategoryCode(
			"Exit gate",
			"EXITGT",
			"The point to which an aircraft will be directed to commence the transit outbound from an airfield or force at sea.");
	public static final ControlFeatureTypeCategoryCode EXIT_POINT = new ControlFeatureTypeCategoryCode(
			"Exit point",
			"EXITPT",
			"A point designated for use by vehicles or personnel in leaving an area, line or volume.");
	public static final ControlFeatureTypeCategoryCode EXTRACTION_ZONE = new ControlFeatureTypeCategoryCode(
			"Extraction zone",
			"EXTZON",
			"A specified drop zone used for the delivery of equipment and/or supplies by means of an extraction technique from an aircraft flying very close to the ground.");
	public static final ControlFeatureTypeCategoryCode FALCON_RADIALS_AREA = new ControlFeatureTypeCategoryCode(
			"Falcon radials area",
			"FALRAR",
			"Planned magnetic bearings along which aircraft depart and return to ships.");
	public static final ControlFeatureTypeCategoryCode FORWARD_ARMING_AND_REFUELLING_POINT = new ControlFeatureTypeCategoryCode(
			"Forward arming and refuelling point",
			"FARRFP",
			"A point designated by a deployed aviation commander that permits combat aircraft to rapidly refuel and rearm simultaneously.");
	public static final ControlFeatureTypeCategoryCode FORWARD_COMBAT_ZONE = new ControlFeatureTypeCategoryCode(
			"Forward combat zone",
			"FCZ",
			"A CONTROL-FEATURE-TYPE with an area location compromising the territory forward of the corps rear boundary.");
	public static final ControlFeatureTypeCategoryCode FORWARD_EDGE_OF_THE_BATTLE_AREA = new ControlFeatureTypeCategoryCode(
			"Forward edge of the battle area",
			"FEBA",
			"The foremost limits of a series of areas in which ground combat units are deployed, excluding the areas in which the covering or screening forces are operating, designated to coordinate fire support, the positioning of forces, or the manoeuvre of units.");
	public static final ControlFeatureTypeCategoryCode FIGHTER_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Fighter engagement zone",
			"FEZ",
			"The airspace beyond the crossover zone out to limits defined by the officer in tactical command, in which fighters have freedom of action to identify and engage air targets.");
	public static final ControlFeatureTypeCategoryCode FINAL_APPROACH_FIX = new ControlFeatureTypeCategoryCode(
			"Final approach fix",
			"FINAPF",
			"The point in a non-precision approach where the final approach normally begins.");
	public static final ControlFeatureTypeCategoryCode FIRE_POSITION_AREA = new ControlFeatureTypeCategoryCode(
			"Fire position area",
			"FIRING",
			"The specific location within an Artillery area CONTROL-FEATURE-TYPE from which a fire unit delivers fire.");
	public static final ControlFeatureTypeCategoryCode FIRE_UMBRELLA = new ControlFeatureTypeCategoryCode(
			"Fire umbrella",
			"FIRUMB",
			"The airspace over a naval force at sea within the fire of ships' anti-aircraft weapons can endanger aircraft, and within which special procedures are established for identification and operation of friendly aircraft.");
	public static final ControlFeatureTypeCategoryCode FLIGHT_INFORMATION_REGION = new ControlFeatureTypeCategoryCode(
			"Flight information region",
			"FLINRG",
			"An airspace of defined dimensions within which flight information service and alerting service are provided.");
	public static final ControlFeatureTypeCategoryCode FORWARD_LINE_OF_TROOPS = new ControlFeatureTypeCategoryCode(
			"Forward line of troops",
			"FLT",
			"Line indicating the most forward positions of friendly forces in any kind of military operation at a specific time.");
	public static final ControlFeatureTypeCategoryCode FINAL_COORDINATION_LINE = new ControlFeatureTypeCategoryCode(
			"Final coordination line",
			"FNCOLN",
			"A line close to the enemy position used to coordinate the lifting and/or shifting of supporting fires with the final deployment of manoeuvre elements. It should be recognisable on the ground. It is not a fire support coordination measure.");
	public static final ControlFeatureTypeCategoryCode FINAL_PROTECTIVE_FIRE = new ControlFeatureTypeCategoryCode(
			"Final protective fire",
			"FNPRFR",
			"An immediately available prearranged barrier of fire designed to impede enemy movement across defensive lines or areas.");
	public static final ControlFeatureTypeCategoryCode FORCE_AIR_COORDINATION_AREA = new ControlFeatureTypeCategoryCode(
			"Force air coordination area",
			"FOACAR",
			"An area surrounding a force within which air coordination measures are required to prevent mutual interference between all friendly surface and air units and their weapon systems.");
	public static final ControlFeatureTypeCategoryCode FORWARD_OPERATING_LOCATION = new ControlFeatureTypeCategoryCode(
			"Forward operating location",
			"FOOPLN",
			"An advanced position, usually of a temporary nature, from which air or ground units operate.");
	public static final ControlFeatureTypeCategoryCode FREE_FIRE_AREA = new ControlFeatureTypeCategoryCode(
			"Free fire area",
			"FREFIR",
			"Supplementary permissive fire support coordination measure, established to facilitate the rapid engagement of targets of opportunity, into which any weapon system may fire without additional coordination with the establishing headquarters.");
	public static final ControlFeatureTypeCategoryCode FORMING_UP_PLACE = new ControlFeatureTypeCategoryCode(
			"Forming up place",
			"FRUPPL",
			"The last position occupied by the assault echelon before crossing the start line/line of departure.");
	public static final ControlFeatureTypeCategoryCode FIRE_SUPPORT_COORDINATION_LINE = new ControlFeatureTypeCategoryCode(
			"Fire support coordination line",
			"FSCL",
			"A CONTROL-FEATURE-TYPE with an area location that is established and adjusted by appropriate land or amphibious force commanders within their boundaries in consultation with superior, subordinate, supporting, and affected commanders. Fire support coordination lines (FSCLs) facilitate the expeditious attack of surface targets of opportunity beyond the coordinating measure.");
	public static final ControlFeatureTypeCategoryCode FORWARD_AREA_AIR_DEFENCE_ZONE = new ControlFeatureTypeCategoryCode(
			"Forward area air defence zone",
			"FWDZON",
			"An area of forward area air defence (FAAD) deployment that may fall within a missile engagement zone.");
	public static final ControlFeatureTypeCategoryCode GENERAL_AREA = new ControlFeatureTypeCategoryCode(
			"General area",
			"GENARE",
			"A CONTROL-FEATURE-TYPE that identifies an area defined by a higher commander within which the subordinate must accomplish his mission and protect his forces. It applies to both land and naval forces.");
	public static final ControlFeatureTypeCategoryCode HIGH_ALTITUDE_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"High altitude missile engagement zone",
			"HAMZON",
			"The airspace of defined dimensions within which the responsibility for engagement of air threats normally rests with high-altitude surface-to-air missiles.");
	public static final ControlFeatureTypeCategoryCode HIGH_DENSITY_AIRSPACE_CONTROL_ZONE = new ControlFeatureTypeCategoryCode(
			"High density airspace control zone",
			"HDAZON",
			"Airspace designated in an airspace control plan or airspace control order in which there is a concentrated employment of numerous and varied weapons and airspace users. A high-density airspace control zone has defined dimensions that usually coincide with geographical features or navigational aids. Access to a high-density airspace control zone is normally controlled by the manoeuvre commander. The manoeuvre commander can also direct a more restrictive weapons status within the high-density airspace control zone.");
	public static final ControlFeatureTypeCategoryCode HIDE = new ControlFeatureTypeCategoryCode(
			"Hide",
			"HIDE",
			"An area in which a force conceals itself before operations or before moving into battle position.");
	public static final ControlFeatureTypeCategoryCode HAND_OVER_GATE = new ControlFeatureTypeCategoryCode(
			"Hand over gate",
			"HNDVGT",
			"A point at which the control of the aircraft, if radar hand over is used, changes from one controller to another.");
	public static final ControlFeatureTypeCategoryCode HOLDING_LINE = new ControlFeatureTypeCategoryCode(
			"Holding line",
			"HOLDLN",
			"In retrograde river-crossing operations, the outer limit of the area established between the enemy and the water obstacle to preclude direct and observed indirect fires into crossing areas.");
	public static final ControlFeatureTypeCategoryCode IDENTIFICATION_SAFETY_POINT = new ControlFeatureTypeCategoryCode(
			"Identification safety point",
			"IDSFPT",
			"A point at which aircraft, on joining a maritime force, will attempt to establish two-way communications with the surface force and commence identification procedures.");
	public static final ControlFeatureTypeCategoryCode IDENTIFICATION_FRIEND_FOE_SWITCH_OFF_LINE = new ControlFeatureTypeCategoryCode(
			"Identification Friend Foe switch off line",
			"IFFOFF",
			"Line demarking where friendly aircraft enroute to targets stop emitting an Identification-Friend-Foe signal.");
	public static final ControlFeatureTypeCategoryCode IDENTIFICATION_FRIEND_FOE_SWITCH_ON_LINE = new ControlFeatureTypeCategoryCode(
			"Identification Friend Foe switch on line",
			"IFFONL",
			"Line demarking where friendly aircraft returning to friendly territory start emitting an Identification-Friend-Foe signal.");
	public static final ControlFeatureTypeCategoryCode IMPACT_POINT = new ControlFeatureTypeCategoryCode(
			"Impact point",
			"IMPTPT",
			"1. The point on the drop zone where the first parachutist or air dropped cargo item lands or is expected to land. See FM 90-26. 2. The point at which a projectile, bomb, or re-entry vehicle impacts or is expected to impact.");
	public static final ControlFeatureTypeCategoryCode INCIDENT_POINT = new ControlFeatureTypeCategoryCode(
			"Incident point",
			"INCDPT",
			"A CONTROL-FEATURE-TYPE that identifies a point where an incident has occurred.");
	public static final ControlFeatureTypeCategoryCode INFILTRATION_LINE = new ControlFeatureTypeCategoryCode(
			"Infiltration line",
			"INFLIN",
			"An infiltration lane is a control measure that fixes fire planning responsibilities and coordinates forward and lateral movement of infiltrating units.");
	public static final ControlFeatureTypeCategoryCode INITIAL_APPROACH_FIX = new ControlFeatureTypeCategoryCode(
			"Initial approach fix",
			"INIAPF",
			"The point in an instrument approach that the aircraft has departed and is manoeuvring to enter the intermediate or final approach.");
	public static final ControlFeatureTypeCategoryCode INITIAL_POINT = new ControlFeatureTypeCategoryCode(
			"Initial point",
			"INITPT",
			"A well-defined point, easily distinguishable visually and/or electronically, used as a starting point for a weapons or reconnaissance run on a target.");
	public static final ControlFeatureTypeCategoryCode INTERMEDIATE_OBJECTIVE = new ControlFeatureTypeCategoryCode(
			"Intermediate objective",
			"INTOBJ",
			"An area or feature between the line of departure and an objective that must be seized and/or held.");
	public static final ControlFeatureTypeCategoryCode IDENTIFICATION_SAFETY_RANGE = new ControlFeatureTypeCategoryCode(
			"Identification safety range",
			"ISR",
			"Minimum range to which an aircraft may close to a maritime force without having been positively identified as friendly.");
	public static final ControlFeatureTypeCategoryCode JOINT_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Joint engagement zone",
			"JEZ",
			"Airspace in which friendly surface-to-air missiles and fighters are simultaneously employed and operated.");
	public static final ControlFeatureTypeCategoryCode JOINT_OPERATIONS_AREA = new ControlFeatureTypeCategoryCode(
			"Joint operations area",
			"JNTOAR",
			"Area of land, sea, and airspace defined by a combat commander or subordinate unified commander, in which joint force commander conducts military operations to accomplish a specific mission.");
	public static final ControlFeatureTypeCategoryCode KEY_TERRAIN = new ControlFeatureTypeCategoryCode(
			"Key terrain",
			"KEYTER",
			"Any locality, or area, the seizure of which affords a marked advantage to either combatant.");
	public static final ControlFeatureTypeCategoryCode KILL_BOX = new ControlFeatureTypeCategoryCode(
			"Kill box",
			"KILBOX",
			"A volume of airspace where fighter aircraft operate in a weapons free mode and can use their weapons in beyond line of sight operations.");
	public static final ControlFeatureTypeCategoryCode KILLING_AREA = new ControlFeatureTypeCategoryCode(
			"Killing area",
			"KILLA",
			"A zone in which a commander plans to force the enemy to concentrate so as to destroy him.");
	public static final ControlFeatureTypeCategoryCode LANDING_AREA = new ControlFeatureTypeCategoryCode(
			"Landing area",
			"LA",
			"The part of the objective area within which the landing operations of an amphibious force are conducted.");
	public static final ControlFeatureTypeCategoryCode LOW_ALTITUDE_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Low altitude missile engagement zone",
			"LAMZON",
			"Airspace within which the responsibility for engagement normally rests with the commander of the low-to-medium altitude GBAD systems.");
	public static final ControlFeatureTypeCategoryCode LANDING_POINT = new ControlFeatureTypeCategoryCode(
			"Landing point",
			"LANDPT",
			"The aircraft, ship or other vehicle will land at the route point.");
	public static final ControlFeatureTypeCategoryCode LAND_FIGHTER_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Land fighter engagement zone",
			"LFGEZN",
			"Airspace of defined dimensions within which the responsibility for engagement of air threats normally rests with the commander of the AD fighter package.");
	public static final ControlFeatureTypeCategoryCode LIGHT_LINE = new ControlFeatureTypeCategoryCode(
			"Light line",
			"LGHTLN",
			"A designated phase line forward of which vehicles are required to use blackout lights at night.");
	public static final ControlFeatureTypeCategoryCode LIMIT_OF_ADVANCE = new ControlFeatureTypeCategoryCode(
			"Limit of advance",
			"LIMADV",
			"An easily recognized terrain feature beyond which attacking elements will not advance.");
	public static final ControlFeatureTypeCategoryCode LIMITED_ACCESS_AREA = new ControlFeatureTypeCategoryCode(
			"Limited access area",
			"LIMARE",
			"A CONTROL-FEATURE-TYPE with an area location to indicate to what personnel or equipment the area is impassable. Note - this definition does not identify whether it is a procedural issue, limitation or a trafficability issue.");
	public static final ControlFeatureTypeCategoryCode LINKUP_POINT = new ControlFeatureTypeCategoryCode(
			"Linkup point",
			"LNKPPT",
			"An easily recognisable point location on the ground where two forces conducting a linkup meet. When one force is stationary, linkup points normally are established where the moving force's routes of advance intersect the stationary force's security elements. Linkup points for two moving forces are established on boundaries where the two forces are expected to converge.");
	public static final ControlFeatureTypeCategoryCode LAND_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Land missile engagement zone",
			"LNMEZN",
			"Airspace of defined dimensions within which the responsibility for engagement of air threats normally rests with the commander of the surface based air defence system.");
	public static final ControlFeatureTypeCategoryCode LINE_OF_CONTACT = new ControlFeatureTypeCategoryCode(
			"Line of contact",
			"LOC",
			"The designation of forward friendly positions as the LD when opposing forces are in contact.");
	public static final ControlFeatureTypeCategoryCode LINE_OF_DEPARTURE_LAND = new ControlFeatureTypeCategoryCode(
			"Line of departure, land",
			"LODLND",
			"A line designated to coordinate the departure of attack elements (commitment of attacking units or scouting elements at a specific time).");
	public static final ControlFeatureTypeCategoryCode LINE_OF_DEPARTURE_SEA = new ControlFeatureTypeCategoryCode(
			"Line of departure, sea",
			"LODSEA",
			"A suitably marked offshore coordinating line to assist assault craft to land on designated beaches at scheduled times.");
	public static final ControlFeatureTypeCategoryCode LOGICAL_NODE = new ControlFeatureTypeCategoryCode(
			"Logical node",
			"LOGNOD",
			"A CONTROL-FEATURE-TYPE that participates as a logical element in a communications network.");
	public static final ControlFeatureTypeCategoryCode LEFT_RADIAL_LINE = new ControlFeatureTypeCategoryCode(
			"Left radial line",
			"LRADLN",
			"The line extending outward from the area of Secondary Hazard marking the maximum extent to the left (facing in the effective downwind direction) where significant fallout is expected to occur.");
	public static final ControlFeatureTypeCategoryCode LANDING_ZONE = new ControlFeatureTypeCategoryCode(
			"Landing zone",
			"LZ",
			"A specified area used for the landing of aircraft.");
	public static final ControlFeatureTypeCategoryCode MAIN_AXIS_OF_ADVANCE = new ControlFeatureTypeCategoryCode(
			"Main axis of advance",
			"MAXIS",
			"A main route of advance, assigned for control, which extends towards the enemy. A main axis of advance symbol graphically portrays a commander�s intention for the main elements of his force, such as avoidance of built-up areas or envelopment of an enemy force. It follows terrain suitable for the size of the force to which the axis was assigned, and is often a road, a group of roads, or a designated series of locations. An axis of advance is not used to direct the control of terrain or the clearance of enemy forces from specific locations. Intermediate objectives are normally assigned for these purposes.");
	public static final ControlFeatureTypeCategoryCode MINE_DANGER_AREA_SEA = new ControlFeatureTypeCategoryCode(
			"Mine danger area, sea",
			"MDASEA",
			"An area established around the position of a suspected or known mine.");
	public static final ControlFeatureTypeCategoryCode MISSILE_ENGAGEMENT_ZONE_GENERAL = new ControlFeatureTypeCategoryCode(
			"Missile engagement zone, general",
			"MEZ",
			"In air defence, that airspace of defined dimensions within which the responsibility for engagement of air threats normally rests with short-range air defence weapons. It may be established within a low or high altitude missile engagement.");
	public static final ControlFeatureTypeCategoryCode MARITIME_FIGHTER_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Maritime fighter engagement zone",
			"MFGEZN",
			"The airspace beyond the crossover zone out to limits defined by the officer in tactical command, in which fighters have freedom of action to identify and engage air targets.");
	public static final ControlFeatureTypeCategoryCode MILITARY_OPERATIONS_AREA = new ControlFeatureTypeCategoryCode(
			"Military operations area",
			"MLOPAR",
			"Airspace established outside class \"A\" airspace to separate or segregate certain non-hazardous military activities from instrument flight rule traffic and to identify for visual flight rule traffic where these activities are conducted.");
	public static final ControlFeatureTypeCategoryCode MAIN_BEAM_AXIS = new ControlFeatureTypeCategoryCode(
			"Main beam axis",
			"MNBMAX",
			"The direction within the beam of an antenna for which the amplitude of the specified field component is a maximum or about which the beam may be considered symmetrical.");
	public static final ControlFeatureTypeCategoryCode MAIN_BATTLE_AREA = new ControlFeatureTypeCategoryCode(
			"Main battle area",
			"MNBTAR",
			"That portion of the battlespace in which the decisive battle is fought to defeat the enemy. For any particular command, the main battle area extends rearward from the forward edge of the battle area to the rear boundary of the command's subordinate units.");
	public static final ControlFeatureTypeCategoryCode MINIMUM_SAFE_DISTANCE_1 = new ControlFeatureTypeCategoryCode(
			"Minimum safe distance 1",
			"MNSFD1",
			"Minimum Safe Distance 1 identifies the minimum safe distance for warned, protected personnel measured to the nearest 100 metres from the expected ground zero. The recommended action within Minimum Safe Distance 1 prior to strike is evacuation of all personnel (if evacuation is not possible or if a commander elects a higher degree of risk, maximum protective measures will be required). Minimum Safe Distance 1 is used when there is a single burst.");
	public static final ControlFeatureTypeCategoryCode MINIMUM_SAFE_DISTANCE_2 = new ControlFeatureTypeCategoryCode(
			"Minimum safe distance 2",
			"MNSFD2",
			"Minimum Safe Distance 2 identifies the minimum safe distance for warned, exposed personnel measured to the nearest 100 metres from the planned ground zero. Within Minimum Safe Distance 2 and outside of Minimum Safe Distance 1 there is a limit of negligible risk to warned and protected personnel. Maximum protective measures will be required. Minimum Safe Distance 2 is used when there is a single burst.");
	public static final ControlFeatureTypeCategoryCode MAIN_THREAT_AXIS = new ControlFeatureTypeCategoryCode(
			"Main threat axis",
			"MNTHAX",
			"A CONTROL-FEATURE-TYPE that represents the line or area along which the enemy forces are assumed to constitute the largest threat.");
	public static final ControlFeatureTypeCategoryCode MARITIME_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Maritime missile engagement zone",
			"MRMEZN",
			"A designated airspace in which, under weapons control status weapons free, ships are automatically cleared to fire at any target which penetrates the zone, unless known to be friendly, adhering to airspace control procedures or unless otherwise directed by the anti-air warfare commander.");
	public static final ControlFeatureTypeCategoryCode MARSHALLING_GATE = new ControlFeatureTypeCategoryCode(
			"Marshalling gate",
			"MRSHGT",
			"A point to which aircraft fly for air traffic purposes prior to commencing an outbound transit after takeoff or prior to landing.");
	public static final ControlFeatureTypeCategoryCode MISSILE_ARC = new ControlFeatureTypeCategoryCode(
			"Missile arc",
			"MSLARC",
			"An area of arc subtending 10 degrees, or as large as ordered by the officer in tactical command (OTC), centred on the bearing of the target with a range that extends to the maximum range of the surface-to-air missile (SAM).");
	public static final ControlFeatureTypeCategoryCode MISSILE_DETECT_POINT = new ControlFeatureTypeCategoryCode(
			"Missile detect point",
			"MSLDET",
			"No definition provided in APP-6B JUN 08.");
	public static final ControlFeatureTypeCategoryCode NAVIGATION_POINT = new ControlFeatureTypeCategoryCode(
			"Navigation point",
			"NAGTPT",
			"The aircraft, ship or other vehicle will change course, speed and/or altitude at this point.");
	public static final ControlFeatureTypeCategoryCode NAMED_AREA_OF_INTEREST = new ControlFeatureTypeCategoryCode(
			"Named area of interest",
			"NAMAIN",
			"A point or area along a particular avenue of approach through which enemy activity is expected to occur. Activity or lack of activity within an NAI will help to confirm or deny a particular enemy course of action.");
	public static final ControlFeatureTypeCategoryCode NO_FIRE_LINE = new ControlFeatureTypeCategoryCode(
			"No fire line",
			"NFL",
			"A line short of which artillery or ships do not fire except on request or approval of the supported commander, but beyond which they may fire at any time without danger to friendly troops.");
	public static final ControlFeatureTypeCategoryCode NO_FIRE_AREA = new ControlFeatureTypeCategoryCode(
			"No fire area",
			"NFRARE",
			"An area/airspace in which fires or the effects of fires are not allowed without prior clearance from the establishing headquarters, except when a force must defend itself against an engaging enemy force within the no fire area.");
	public static final ControlFeatureTypeCategoryCode NO_GO_AREA = new ControlFeatureTypeCategoryCode(
			"No go area",
			"NGA",
			"An area that is not trafficable.");
	public static final ControlFeatureTypeCategoryCode NO_GO_AREA_CIVIL = new ControlFeatureTypeCategoryCode(
			"No go area, civil",
			"NGACIV",
			"An area to which access is denied by civil authority or group of people (e.g. faction, gang, militia).");
	public static final ControlFeatureTypeCategoryCode NO_FLY_ZONE = new ControlFeatureTypeCategoryCode(
			"No fly zone",
			"NOFLZN",
			"Airspace of specific dimensions set aside for a specific purpose in which no aircraft operations are permitted, except as authorized by the appropriate commander and controlling agency.");
	public static final ControlFeatureTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new ControlFeatureTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ControlFeatureTypeCategoryCode NUCLEAR_TARGET = new ControlFeatureTypeCategoryCode(
			"Nuclear target",
			"NUCTGT",
			"No definition provided in APP-6B JUN 08.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_FREE_AREA = new ControlFeatureTypeCategoryCode(
			"Obstacle free area",
			"OBFARE",
			"An area the commander designates as restricted from the emplacement of man-made obstacles, normally to facilitate future operations.");
	public static final ControlFeatureTypeCategoryCode OBJECTIVE_AREA = new ControlFeatureTypeCategoryCode(
			"Objective area",
			"OBJA",
			"A defined geographical area within which is located an objective to be captured or reached by the military forces. This area is defined by competent authority for purposes of command and control.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_RESTRICTED_AREA = new ControlFeatureTypeCategoryCode(
			"Obstacle restricted area",
			"OBRARE",
			"A command and control measure used to limit the type or number of obstacles within an area.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_BELT = new ControlFeatureTypeCategoryCode(
			"Obstacle belt",
			"OBSBLT",
			"Normally, a brigade-level obstacle control measure that specifies the intent and location of subordinate obstacles. It also supports the intent of the higher headquarters obstacle zone.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_GAP = new ControlFeatureTypeCategoryCode(
			"Obstacle gap",
			"OBSGAP",
			"An area within a minefield or obstacle belt, free of live mines or obstacles, whose width and direction will allow a friendly force to pass through in tactical formation.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_LANE = new ControlFeatureTypeCategoryCode(
			"Obstacle lane",
			"OBSLAN",
			"A route through an enemy or friendly obstacle that provides a passing force safe passage. The route may be reduced and proofed as part of a breach operation, or constructed as part of a friendly obstacle. A clear route through an obstacle.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_LINE = new ControlFeatureTypeCategoryCode(
			"Obstacle line",
			"OBSLIN",
			"A conceptual control measure used at battalion or brigade level to show placement intent without specifying a particular type of linear obstacle.");
	public static final ControlFeatureTypeCategoryCode OBSTACLE_ZONE = new ControlFeatureTypeCategoryCode(
			"Obstacle zone",
			"OBSZON",
			"A division-level command and control measure, normally done graphically, to designate specific land areas where lower echelons are allowed to employ tactical obstacles.");
	public static final ControlFeatureTypeCategoryCode OPERATIONS_ZONE = new ControlFeatureTypeCategoryCode(
			"Operations zone",
			"OPERZN",
			"That portion of an area of war necessary for military operations and for the administration of such operations.");
	public static final ControlFeatureTypeCategoryCode ORBIT_POINT = new ControlFeatureTypeCategoryCode(
			"Orbit point",
			"ORBTPT",
			"A geographically or electronically defined location used in stationing aircraft in flight during tactical operations when a predetermined pattern is not established.");
	public static final ControlFeatureTypeCategoryCode PHASE_LINE = new ControlFeatureTypeCategoryCode(
			"Phase line",
			"PHLINE",
			"A line used for control and coordination of military operations, usually a terrain feature extending across the zone of action. Army-- A line used for control and coordination of military operations. It is usually along a recognisable terrain feature extending across the sector or zone of action. Units normally report crossing PLs, but do not halt unless specifically directed.");
	public static final ControlFeatureTypeCategoryCode POSITIVE_IDENTIFICATION_RADAR_ADVISORY_ZONE = new ControlFeatureTypeCategoryCode(
			"Positive identification radar advisory zone",
			"PIRAZN",
			"An area within which navy ships separate friendly from hostile aircraft.");
	public static final ControlFeatureTypeCategoryCode PENETRATION_BOX = new ControlFeatureTypeCategoryCode(
			"Penetration box",
			"PNTRBX",
			"A CONTROL-FEATURE-TYPE that defines the area intended for penetration through enemy defences, a form of offensive which seeks to break through the enemy's defence and disrupt the defensive system.");
	public static final ControlFeatureTypeCategoryCode POP_UP_POINT = new ControlFeatureTypeCategoryCode(
			"Pop-up point",
			"POPUPT",
			"The location at which aircraft quickly gain altitude for target acquisition and engagement.");
	public static final ControlFeatureTypeCategoryCode PROHIBITED_AREA = new ControlFeatureTypeCategoryCode(
			"Prohibited area",
			"PRHBAR",
			"An airspace of defined dimensions, above the land areas or territorial waters of a state within which the flight of aircraft is prohibited.");
	public static final ControlFeatureTypeCategoryCode PREDICTED_IMPACT_POINT = new ControlFeatureTypeCategoryCode(
			"Predicted impact point",
			"PRITPT",
			"The point at which a projectile, bomb or re-entry vehicle is expected to strike on earth.");
	public static final ControlFeatureTypeCategoryCode PASSAGE_POINT = new ControlFeatureTypeCategoryCode(
			"Passage point",
			"PSSGPT",
			"A specifically designated place where units will pass through one another either in an advance or withdrawal. It is located where the commander desires subordinate units to physically execute a passage of lines.");
	public static final ControlFeatureTypeCategoryCode POINT_OF_DEPARTURE = new ControlFeatureTypeCategoryCode(
			"Point of departure",
			"PTDPRT",
			"In night or limited visibility attacks, a specific place on the line of departure (LD) where a unit will cross.");
	public static final ControlFeatureTypeCategoryCode POINT_OF_INTEREST = new ControlFeatureTypeCategoryCode(
			"Point of interest",
			"PTINT",
			"A CONTROL-FEATURE-TYPE with a point location that is significant for military planning or activity.");
	public static final ControlFeatureTypeCategoryCode PICKUP_ZONE = new ControlFeatureTypeCategoryCode(
			"Pickup zone",
			"PZ",
			"A geographic area used to pick up troops and/or equipment by helicopter.");
	public static final ControlFeatureTypeCategoryCode Q_ZONE = new ControlFeatureTypeCategoryCode(
			"Q-zone",
			"QZONE",
			"A CONTROL-FEATURE-TYPE that represents one of the 18 main geographical sea areas of the world.");
	public static final ControlFeatureTypeCategoryCode RADIOACTIVE_AREA = new ControlFeatureTypeCategoryCode(
			"Radioactive area",
			"RADARE",
			"A CONTROL-FEATURE-TYPE that identifies the predicted or confirmed contour of an area in which radiological materials may produce casualties in man or animals and damage to plants or materiel.");
	public static final ControlFeatureTypeCategoryCode RADIOACTIVE_ATMOSPHERIC_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Radioactive atmospheric concentration contour line",
			"RADATC",
			"A line on a map, diagram or overlay joining all points at which the radiation atmospheric concentration at a given time is the same. Radiation atmospheric concentration is the quantity of radioactive material distributed in the atmosphere per unit volume.");
	public static final ControlFeatureTypeCategoryCode RADAR_DETERMINED_CONTOUR_OF_RADIOACTIVE_CLOUD = new ControlFeatureTypeCategoryCode(
			"Radar determined contour of radioactive cloud",
			"RADCLD",
			"The boundary of the region of the atmosphere where radar measurements indicate the presence of suspended radioactive material.");
	public static final ControlFeatureTypeCategoryCode RADIATION_DOSE_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Radiation dose contour line",
			"RADDOS",
			"A line on a map, diagram or overlay joining all points at which the radiation dose at a given time is the same. Radiation dose is the amount of energy from ionizing radiation that would be absorbed.");
	public static final ControlFeatureTypeCategoryCode RADIOACTIVE_SURFACE_DEPOSITION_CONCENTRATION_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Radioactive surface deposition concentration contour line",
			"RADDPC",
			"A line on a map, diagram or overlay joining all points at which the radiation surface deposition concentration at a given time is the same. Radiation surface deposition concentration is the quantity of radioactive material distributed on a surface per unit area.");
	public static final ControlFeatureTypeCategoryCode RADIATION_DOSE_RATE_CONTOUR_LINE = new ControlFeatureTypeCategoryCode(
			"Radiation dose rate contour line",
			"RADDSR",
			"A line on a map, diagram or overlay joining all points at which the radiation dose rate at a given time is the same. Radiation dose rate is the rate at which energy from ionizing radiation is absorbed.");
	public static final ControlFeatureTypeCategoryCode RALLY_POINT = new ControlFeatureTypeCategoryCode(
			"Rally point",
			"RALYPT",
			"An easily identifiable point location on the ground at which units can reassemble/reorganise if they become disbursed or aircrews/passengers can assemble and reorganise following an incident requiring a forced landing.");
	public static final ControlFeatureTypeCategoryCode REAR_BOUNDARY_OF_THE_FORWARD_AREA = new ControlFeatureTypeCategoryCode(
			"Rear boundary of the forward area",
			"RBFA",
			"A line delineating the rear of an area in proximity to combat.");
	public static final ControlFeatureTypeCategoryCode RECONNAISSANCE_AREA = new ControlFeatureTypeCategoryCode(
			"Reconnaissance area",
			"RCNSAR",
			"Airspace established specifically for airborne platforms conducting reconnaissance.");
	public static final ControlFeatureTypeCategoryCode REAR_COMBAT_ZONE = new ControlFeatureTypeCategoryCode(
			"Rear combat zone",
			"RCZ",
			"A CONTROL-FEATURE-TYPE with an area location usually compromising the territory between the corps rear boundary and the army group rear boundary.");
	public static final ControlFeatureTypeCategoryCode REDUCED_COORDINATION_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Reduced coordination airspace",
			"RDCOSP",
			"A portion of defined dimensions within which general air traffic (GAT) is permitted \"off-route\" without requiring GAT controllers to initiate coordination with operational air traffic (OAT) controllers.");
	public static final ControlFeatureTypeCategoryCode REFERENCE_POINT = new ControlFeatureTypeCategoryCode(
			"Reference point",
			"REFCPT",
			"A point or set of coordinates generally used for control purposes or to indicate a reference position.");
	public static final ControlFeatureTypeCategoryCode REFUELLING_POINT = new ControlFeatureTypeCategoryCode(
			"Refuelling point",
			"REFLPT",
			"The aircraft, ship or other vehicle will refuel at this point.");
	public static final ControlFeatureTypeCategoryCode REFORM_POINT = new ControlFeatureTypeCategoryCode(
			"Reform point",
			"REFRPT",
			"A CONTROL-FEATURE-TYPE that identifies a point where aircraft join again during a mission.");
	public static final ControlFeatureTypeCategoryCode RELEASE_LINE = new ControlFeatureTypeCategoryCode(
			"Release line",
			"RELL",
			"Phase line used in river-crossing operations that delineates a change in the headquarters controlling movement.");
	public static final ControlFeatureTypeCategoryCode RELEASE_POINT = new ControlFeatureTypeCategoryCode(
			"Release point",
			"RELPT",
			"A well-defined point on a route at which the elements composing a column return under the authority of their respective commanders, each one of these elements continuing its movement toward its own appropriate destination.");
	public static final ControlFeatureTypeCategoryCode REPORT_LINE = new ControlFeatureTypeCategoryCode(
			"Report line",
			"REPLIN",
			"A line at which troops, after having reached it, must report to their command echelon.");
	public static final ControlFeatureTypeCategoryCode REPORT_POINT = new ControlFeatureTypeCategoryCode(
			"Report point",
			"REPRPT",
			"A CONTROL-FEATURE-TYPE that identifies a point at which troops, after having reached it, must report to their command.");
	public static final ControlFeatureTypeCategoryCode RESTRICTED_FIRE_LINE = new ControlFeatureTypeCategoryCode(
			"Restricted fire line",
			"RFL",
			"A line established between converging forces that prohibits fires or the effect of fires across the line without prior coordination.");
	public static final ControlFeatureTypeCategoryCode RECONNAISSANCE_AND_INTERDICTION_PLANNING_LINE = new ControlFeatureTypeCategoryCode(
			"Reconnaissance and interdiction planning line",
			"RIPL",
			"A CONTROL-FEATURE-TYPE with a line location to divide responsibility for the nomination of ground targets. Short of the RIPL the ground commander has this responsibility for nominating targets that have a direct bearing on the land battle. Beyond this, the targeting authority lies with the Air Commander.");
	public static final ControlFeatureTypeCategoryCode RENDEZVOUS_POINT = new ControlFeatureTypeCategoryCode(
			"Rendezvous point",
			"RNDZPT",
			"A given location at which to regroup before, during or after an operation at a specified time or in a specified situation.");
	public static final ControlFeatureTypeCategoryCode ROCKET_MISSILE_AREA = new ControlFeatureTypeCategoryCode(
			"Rocket/missile area",
			"ROMIAR",
			"A CONTROL-FEATURE-TYPE with an area location assigned to rocket/missile units for terrain management purposes on which they manoeuvre.");
	public static final ControlFeatureTypeCategoryCode RELEASE_OTHER_THAN_ATTACK_ROTA_ISOLATION_AND_HAZARD_AREA = new ControlFeatureTypeCategoryCode(
			"Release other than attack (ROTA) isolation and hazard area",
			"ROTAAR",
			"The predicted or confirmed contour of the toxic industrial material isolation and hazard area.");
	public static final ControlFeatureTypeCategoryCode RIGHT_RADIAL_LINE = new ControlFeatureTypeCategoryCode(
			"Right radial line",
			"RRADLN",
			"The line extending outward from the area of Secondary Hazard marking the maximum extent to the right (facing in the effective downwind direction) where significant fallout is expected to occur.");
	public static final ControlFeatureTypeCategoryCode RESTRICTED_FIRE_AREA = new ControlFeatureTypeCategoryCode(
			"Restricted fire area",
			"RSFARE",
			"An area/airspace into which specific restrictions are imposed and into which fires that exceed those restrictions are prohibited without prior coordination.");
	public static final ControlFeatureTypeCategoryCode RESTRICTED_OPERATIONS_AREA = new ControlFeatureTypeCategoryCode(
			"Restricted operations area",
			"RSOPAR",
			"Airspace designated by the airspace control authority, in response to specific operational situations/requirements within which the operation of one or more airspace users is restricted.");
	public static final ControlFeatureTypeCategoryCode RESTRICTED_OPERATIONS_ZONE = new ControlFeatureTypeCategoryCode(
			"Restricted operations zone",
			"RSOPZN",
			"A volume of airspace of defined dimensions designated for a specific operational mission. Entry into that zone is authorised only by the originating headquarters.");
	public static final ControlFeatureTypeCategoryCode RESTRICTED_AREA = new ControlFeatureTypeCategoryCode(
			"Restricted area",
			"RSTRAR",
			"An airspace of defined dimensions, above the land areas or territorial waters of a state, within which the flight of aircraft is restricted in accordance with certain specified conditions.");
	public static final ControlFeatureTypeCategoryCode ROUTE_TYPE = new ControlFeatureTypeCategoryCode(
			"ROUTE-TYPE",
			"RTETYP",
			"A CONTROL-FEATURE-TYPE that is the prescribed course to be travelled from a point of origin to a destination.");
	public static final ControlFeatureTypeCategoryCode SAFE_LANE = new ControlFeatureTypeCategoryCode(
			"Safe lane",
			"SAFELN",
			"A bi-directional lane connecting an airbase, landing site and/or base defence zone to adjacent routes/corridors. Safe lanes may also be used to connect adjacent activated routes/corridors.");
	public static final ControlFeatureTypeCategoryCode SAFETY_ZONE = new ControlFeatureTypeCategoryCode(
			"Safety zone",
			"SAFZ",
			"An area (land, sea or air) reserved for non-combat operations of friendly aircraft, surface ships, submarines or ground forces.");
	public static final ControlFeatureTypeCategoryCode SEARCH_AND_RESCUE_POINT = new ControlFeatureTypeCategoryCode(
			"Search and rescue point",
			"SARPNT",
			"A reference point used during SAR operations.");
	public static final ControlFeatureTypeCategoryCode SURFACE_TO_AIR_WEAPON_CONTROL_POSITION = new ControlFeatureTypeCategoryCode(
			"Surface to air weapon control position",
			"SAWCTP",
			"No definition provided in ADatP-3 Baseline 11.");
	public static final ControlFeatureTypeCategoryCode SEARCH_AREA_RECONNAISSANCE_AREA = new ControlFeatureTypeCategoryCode(
			"Search area/reconnaissance area",
			"SEREAR",
			"Used to depict the area within which a unit or formation is responsible for reconnaissance. As shown, the points of the arrows indicate the width of that area but not its forward edge.");
	public static final ControlFeatureTypeCategoryCode SAFE_AREA_FOR_EVASION = new ControlFeatureTypeCategoryCode(
			"Safe area for evasion",
			"SFAREV",
			"Designated area in hostile territory that offers the evader or escapee a reasonable chance of avoiding capture and of surviving until he can be evacuated.");
	public static final ControlFeatureTypeCategoryCode SAFETY_SECTOR = new ControlFeatureTypeCategoryCode(
			"Safety sector",
			"SFSCTR",
			"An airspace established to route friendly aircraft to maritime forces with minimum risk.");
	public static final ControlFeatureTypeCategoryCode SLOW_GO_AREA = new ControlFeatureTypeCategoryCode(
			"Slow go area",
			"SGA",
			"An area that is trafficable with difficulty.");
	public static final ControlFeatureTypeCategoryCode SHIP_CONTROL_ZONE = new ControlFeatureTypeCategoryCode(
			"Ship control zone",
			"SHPCZN",
			"An area activated around a ship operating aircraft, which is not to be entered by friendly aircraft without permission, in order to prevent friendly interference.");
	public static final ControlFeatureTypeCategoryCode SITE_OF_ALLEGED_KILLS = new ControlFeatureTypeCategoryCode(
			"Site of alleged kills",
			"SITKIL",
			"A CONTROL-FEATURE-TYPE that marks a point or area where alleged kills have occurred.");
	public static final ControlFeatureTypeCategoryCode SMOKE_TARGET = new ControlFeatureTypeCategoryCode(
			"Smoke target",
			"SMOKTG",
			"A line along which, or an area in which, fires with smoke bombs or rockets degrades temporarily the capability of enemy forces to see through.");
	public static final ControlFeatureTypeCategoryCode SPECIAL_ELECTRONIC_MISSION_AREA = new ControlFeatureTypeCategoryCode(
			"Special electronic mission area",
			"SPEMAR",
			"Airspace established specifically for airborne platforms conducting special electronic missions.");
	public static final ControlFeatureTypeCategoryCode SPECIAL_OPERATIONS_FORCES_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Special operations forces airspace",
			"SPOFSP",
			"Airspace specifically for special operations forces missions requested by special operations forces airspace planners.");
	public static final ControlFeatureTypeCategoryCode SPREAD_POINT = new ControlFeatureTypeCategoryCode(
			"Spread point",
			"SPRDPT",
			"A CONTROL-FEATURE-TYPE that identifies a point where aircraft separate during a mission.");
	public static final ControlFeatureTypeCategoryCode SUPPORT_BY_FIRE_POSITION = new ControlFeatureTypeCategoryCode(
			"Support by fire position",
			"SPTPOS",
			"A CONTROL-FEATURE-TYPE that is an area by which a manoeuvre element moves to a position in the battlespace where it can engage the enemy by direct fire. The manoeuvre element does not attempt to manoeuvre to capture enemy forces or terrain.");
	public static final ControlFeatureTypeCategoryCode SHORT_RANGE_AIR_DEFENCE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Short range air defence engagement zone",
			"SRADZN",
			"The airspace of defined dimensions within which the responsibility for engagement of air-threats normally rests with short-range air defence (SHORAD) weapons.");
	public static final ControlFeatureTypeCategoryCode SEARCH_CENTRE = new ControlFeatureTypeCategoryCode(
			"Search centre",
			"SRCHAR",
			"A CONTROL-FEATURE-TYPE with a point location that specifies the centre point of a search area.");
	public static final ControlFeatureTypeCategoryCode STANDARD_SURFACE_TO_AIR_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Standard surface to air missile engagement zone",
			"SSAMEN",
			"A designated airspace in which, under weapons control status (WCS) Weapons Free, ships are automatically cleared to fire at any target which penetrates the zone, unless known to be friendly, adhering to airspace control (ASC) procedures or unless otherwise directed by the AAWC (anti air warfare commander).");
	public static final ControlFeatureTypeCategoryCode SILENT_SURFACE_TO_AIR_MISSILE_ENGAGEMENT_ZONE = new ControlFeatureTypeCategoryCode(
			"Silent surface to air missile engagement zone",
			"SSAMEZ",
			"Maritime MEZ designated area, promulgated in the OPTASK AAW message, within which the: (a) Ships remain covert, receiving the air picture via data links. (b) Ship Weapon Control Status is automatically \"Weapons Free\". (c) No friendly aircraft are allowed in the Maritime MEZ SSMEZ, except for airborne early warning (AEW) aircraft, anti-surface warfare (ASuW) aircraft and anti-submarine warfare (ASW) aircraft that are required to operate within this area, provided that the following criteria are met: 1. SAM ships be alerted to the mission. 2. Aircraft are kept under positive control. 3. Aircraft are being continuously tracked and their position transmitted via data link. 4. Gridlock between data link reporting unit and SAM ship is excellent. (d) No safety sectors are established in a Maritime MEZ SSMEZ.");
	public static final ControlFeatureTypeCategoryCode SURFACE_TO_SURFACE_MISSILE_SYSTEM_AREA = new ControlFeatureTypeCategoryCode(
			"Surface-to-surface missile system area",
			"SSMSAR",
			"Airspace defined specifically for army tactical missile system and tomahawk land attack missile launch and impact points.");
	public static final ControlFeatureTypeCategoryCode STAGING_AREA = new ControlFeatureTypeCategoryCode(
			"Staging area",
			"STAGA",
			"A CONTROL-FEATURE-TYPE that is a general locality established for the concentration of organisations and transient persons between movements over the lines of communications.");
	public static final ControlFeatureTypeCategoryCode STRONG_POINT = new ControlFeatureTypeCategoryCode(
			"Strong point",
			"STPT",
			"A defensive position, usually strongly fortified and heavily armed with automatic weapons around which other positions are grouped for its protection. Army--A position requiring extensive engineering effort for obstacles and survivability positions and positioned to control or block an avenue of approach. Normally, command and control, aid stations, and critical supply stockpiles will be dug-in with overhead protection. Trenches and other protective construction will be done to protect soldiers and weapons from damage during assault by mounted and dismounted forces.");
	public static final ControlFeatureTypeCategoryCode START_POINT = new ControlFeatureTypeCategoryCode(
			"Start point",
			"STRTPT",
			"A well-defined point on a route at which movement of vehicles begins to be under the control of the commander of this movement. It is at this point that the column is formed by the successive passing, at an appointed time, of each of the elements composing the column. In addition to the principal start point of a column there may be secondary start points for its different elements.");
	public static final ControlFeatureTypeCategoryCode SUPPLY_AREA = new ControlFeatureTypeCategoryCode(
			"Supply area",
			"SUPARE",
			"A CONTROL-FEATURE-TYPE that identifies the contour of an area where supply units, depots, and dumps may be located.");
	public static final ControlFeatureTypeCategoryCode SPECIAL_USE_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Special use airspace",
			"SUSASP",
			"Airspace defined for a specific purpose; or to designate airspace in which no flight activity is organized.");
	public static final ControlFeatureTypeCategoryCode TERMINATION_POINT = new ControlFeatureTypeCategoryCode(
			"Termination point",
			"TERMPT",
			"The aircraft, ship or other vehicle will terminate its mission at this route point.");
	public static final ControlFeatureTypeCategoryCode TARGETED_AREA_OF_INTEREST = new ControlFeatureTypeCategoryCode(
			"Targeted area of interest",
			"TGTAOI",
			"The geographical area or point along a mobility corridor the successful interdiction of which will cause an enemy to either abandon a particular course of action or require him to use specialized engineer support to continue and where he can be acquired and engaged by friendly forces. Not all TAI will form part of the friendly COA; only TAI associated with higher payoff targets (HTP) are of interest to the staff. These are identified during staff planning and wargaming. TAI differ from engagement areas in degree. Engagement areas plan for the use of all available weapons; TAI might be engaged by a single weapon.");
	public static final ControlFeatureTypeCategoryCode TARGET_LOCATION = new ControlFeatureTypeCategoryCode(
			"Target location",
			"TGTLOC",
			"A designated location that is expected to contain a target or targets.");
	public static final ControlFeatureTypeCategoryCode TARGET_REFERENCE_POINT = new ControlFeatureTypeCategoryCode(
			"Target reference point",
			"TGTRPT",
			"An easily recognisable point location on the ground (either natural or man-made) used to initiate, distribute, and control fires. TRPs can also designate the centre of an area where the commander plans to distribute or converge the fires of all his weapons rapidly. They are used by task force and below, and can further delineate sectors of fire within an engagement area. TRPs are designated using the standard target symbol and numbers issued by the fire support officer. Once designated, TRPs also constitute indirect fire targets.");
	public static final ControlFeatureTypeCategoryCode TAKEOFF_POINT = new ControlFeatureTypeCategoryCode(
			"Takeoff point",
			"TKEOFF",
			"The aircraft will take off from the route point.");
	public static final ControlFeatureTypeCategoryCode TIMING_REFERENCE_POINT = new ControlFeatureTypeCategoryCode(
			"Timing reference point",
			"TMREPT",
			"A point used to adjust or control time relative to a known geographical position.");
	public static final ControlFeatureTypeCategoryCode TEMPORARY_SEGREGATED_AREA = new ControlFeatureTypeCategoryCode(
			"Temporary segregated area",
			"TMSGAR",
			"An airspace of defined dimensions within which activities require the reservation of airspace for the exclusive use of specific users during a determined period of time.");
	public static final ControlFeatureTypeCategoryCode TERMINAL_CONTROL_AREA = new ControlFeatureTypeCategoryCode(
			"Terminal control area",
			"TRCNAR",
			"A control area normally established at the confluence of air traffic services routes in the vicinity of one or more major aerodromes.");
	public static final ControlFeatureTypeCategoryCode TRAINING_AREA = new ControlFeatureTypeCategoryCode(
			"Training area",
			"TRNGAR",
			"Battlespace created during a contingency for the purpose of conducting training.");
	public static final ControlFeatureTypeCategoryCode TERMINAL_RADAR_SERVICE_AREA = new ControlFeatureTypeCategoryCode(
			"Terminal radar service area",
			"TRRSAR",
			"Airspace surrounding designated airports wherein air traffic control provides radar vectoring, sequencing, and separation on a full-time basis for all instrument flight rule and participating visual flight rule aircraft.");
	public static final ControlFeatureTypeCategoryCode TRANSIT_CORRIDOR = new ControlFeatureTypeCategoryCode(
			"Transit corridor",
			"TRSCRD",
			"Bi-directional corridor in the rear area. Air traffic services not normally provided.");
	public static final ControlFeatureTypeCategoryCode TRAVERSE_LEVEL = new ControlFeatureTypeCategoryCode(
			"Traverse level",
			"TRVLVL",
			"That vertical displacement above low level air defence systems, expressed both as a height and altitude, at which aircraft can cross that area in order to improve the effectiveness of the air defence systems by providing an extra friendly discriminator.");
	public static final ControlFeatureTypeCategoryCode TURNING_POINT = new ControlFeatureTypeCategoryCode(
			"Turning point",
			"TURNPT",
			"The aircraft, ship or other vehicle will change direction at this point.");
	public static final ControlFeatureTypeCategoryCode UNMANNED_AERIAL_VEHICLE_AIRSPACE = new ControlFeatureTypeCategoryCode(
			"Unmanned aerial vehicle airspace",
			"UAVASP",
			"Airspace created specifically for unmanned aerial vehicle operations.");
	public static final ControlFeatureTypeCategoryCode UNEXPLODED_ORDNANCE_AREA = new ControlFeatureTypeCategoryCode(
			"Unexploded ordnance area",
			"UNEXOD",
			"An area in which there are unexploded ordnance. Explosive ordnance which has been primed, fused, armed, or otherwise prepared for action, and which has been fired, dropped, launched, or placed in such a manner as to constitute a hazard to operations, installations, personnel, or material, and remains unexploded either by malfunction or for any other cause.");
	public static final ControlFeatureTypeCategoryCode WAITING_AREA = new ControlFeatureTypeCategoryCode(
			"Waiting area",
			"WAITA",
			"A location adjacent to the route or axis that may be used for the concealment of vehicles, troops, and equipment while an element is waiting to resume movement. Waiting areas are normally located on both banks close to crossing areas.");
	public static final ControlFeatureTypeCategoryCode WARNING_AREA = new ControlFeatureTypeCategoryCode(
			"Warning area",
			"WARNAR",
			"Airspace extending from 3 nautical miles (5.556 km) outward from the coast of the continental (US) that contains activity that may be hazardous to non-participating aircraft.");
	public static final ControlFeatureTypeCategoryCode WAY_POINT = new ControlFeatureTypeCategoryCode(
			"Way point",
			"WAYPT",
			"1. In air operations, a point or a series of points in space to which an aircraft, ship, or cruise missile may be vectored. 2. A designated point or series of points loaded and stored in a global positioning system or other electronic navigational aid system to facilitate movement.");
	public static final ControlFeatureTypeCategoryCode WEAPON_CONTROL_AREA = new ControlFeatureTypeCategoryCode(
			"Weapon control area",
			"WPNCTA",
			"The area in which a specified weapon control status is imposed.");
	public static final ControlFeatureTypeCategoryCode WEAPONS_FREE_ZONE = new ControlFeatureTypeCategoryCode(
			"Weapons free zone",
			"WPNFZN",
			"An air defence zone (ADZ) established around key assets or facilities which merit special protection by ground based air defence assets, other than airbases, where weapons may be fired at any target not positively identified as friendly.");
	public static final ControlFeatureTypeCategoryCode CROSSING_AREA = new ControlFeatureTypeCategoryCode(
			"Crossing area",
			"XA",
			"A number of adjacent crossing sites under the control of one commander.");
	public static final ControlFeatureTypeCategoryCode CROSSING_SITE = new ControlFeatureTypeCategoryCode(
			"Crossing site",
			"XSITE",
			"The location along a water obstacle where the crossing can be made using amphibious vehicles, assault boats, rafts, bridges, or fording vehicles.");
	public static final ControlFeatureTypeCategoryCode ZONE_OF_FIRE = new ControlFeatureTypeCategoryCode(
			"Zone of fire",
			"ZFIRE",
			"An area into which a designated ground unit or fire support asset delivers, or is prepared to deliver, fires.");
	public static final ControlFeatureTypeCategoryCode ZONE_I = new ControlFeatureTypeCategoryCode(
			"Zone I",
			"ZONEI",
			"A circular area of Immediate Operational Concern where exposed, unprotected personnel may receive doses of 150 cGy or greater in relatively short periods of time (less than 4 hours after actual arrival of fallout). Major disruptions to unit operations and casualties may occur in some parts of this zone. However, radiation risk category for emergency risk is changing from 150 cGy to 125 cGy. Zone I is calculated on the basis of the weapon size and downwind speed. The boundary for Zone 1 is determined by drawing 2 lines tangent to the cloud radius circle and intersecting the points on the radial lines where the Zone 1 downwind distance arc intersects these lines.");
	public static final ControlFeatureTypeCategoryCode ZONE_II = new ControlFeatureTypeCategoryCode(
			"Zone II",
			"ZONEII",
			"A circular area (less Zone I area) of Secondary Hazard where the total dose received by exposed, unprotected personnel is not expected to reach 150 cGy within a period of four hours after the actual arrival of fallout. Within this zone, personnel may receive a total dose of 50 cGy or greater within the first 24 hours after arrival of fallout. The boundaries of Zone II are determined by the Zone 1 downwind distance arc, the Zone 2 distance arc and the 2 radial lines.");

	private ControlFeatureTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
