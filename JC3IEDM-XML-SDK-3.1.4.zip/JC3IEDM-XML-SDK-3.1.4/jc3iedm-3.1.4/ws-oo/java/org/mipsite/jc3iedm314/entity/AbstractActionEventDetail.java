/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractActionEventDetail extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private ActionEventDetailClassificationCode classificationCode; // optional
	private ActionEventDetailCrimeIndicatorCode crimeIndicatorCode; // optional
	private TextTypeVar255 text; // optional
	private Ref<AbstractReportingData> reportingData; // mandatory
	private ActionEventDetailCategoryCode actionEventDetailCategoryCode; // mandatory
	private ActionEventDetailIntendedOutcomeCode intendedOutcomeCode; // optional

	// default constructor

	public AbstractActionEventDetail() {
		// no assignment
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractActionEventDetail.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractActionEventDetail.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public ActionEventDetailClassificationCode getClassificationCode() {
		return this.classificationCode;
	}

	public void setClassificationCode(ActionEventDetailClassificationCode classificationCode) {
		this.classificationCode = classificationCode;
	}

	public ActionEventDetailCrimeIndicatorCode getCrimeIndicatorCode() {
		return this.crimeIndicatorCode;
	}

	public void setCrimeIndicatorCode(ActionEventDetailCrimeIndicatorCode crimeIndicatorCode) {
		this.crimeIndicatorCode = crimeIndicatorCode;
	}

	public TextTypeVar255 getText() {
		return this.text;
	}

	public void setText(TextTypeVar255 text) {
		this.text = text;
	}

	public Ref<AbstractReportingData> getReportingData() {
		if (this.reportingData == null) {
			throw new NullValueException("AbstractActionEventDetail.reportingData");
		}
		return this.reportingData;
	}

	public void setReportingData(Ref<AbstractReportingData> reportingData) {
		this.reportingData = reportingData;
	}

	public ActionEventDetailCategoryCode getActionEventDetailCategoryCode() {
		if (this.actionEventDetailCategoryCode == null) {
			throw new NullValueException("AbstractActionEventDetail.actionEventDetailCategoryCode");
		}
		return this.actionEventDetailCategoryCode;
	}

	public void setActionEventDetailCategoryCode(ActionEventDetailCategoryCode actionEventDetailCategoryCode) {
		this.actionEventDetailCategoryCode = actionEventDetailCategoryCode;
	}

	public ActionEventDetailIntendedOutcomeCode getIntendedOutcomeCode() {
		return this.intendedOutcomeCode;
	}

	public void setIntendedOutcomeCode(ActionEventDetailIntendedOutcomeCode intendedOutcomeCode) {
		this.intendedOutcomeCode = intendedOutcomeCode;
	}
}
