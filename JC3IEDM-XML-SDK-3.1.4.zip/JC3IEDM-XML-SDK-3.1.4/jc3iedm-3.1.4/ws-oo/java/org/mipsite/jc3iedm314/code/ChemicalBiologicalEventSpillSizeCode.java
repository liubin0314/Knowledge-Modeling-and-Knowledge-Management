/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ChemicalBiologicalEventSpillSizeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the mass or the volume of a materiel spilled in a CHEMICAL-BIOLOGICAL-EVENT that is a release other than attack (ROTA).";
	}

	private static HashMap<String, ChemicalBiologicalEventSpillSizeCode> physicalToCode = new HashMap<String, ChemicalBiologicalEventSpillSizeCode>();

	public static ChemicalBiologicalEventSpillSizeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ChemicalBiologicalEventSpillSizeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ChemicalBiologicalEventSpillSizeCode LARGE = new ChemicalBiologicalEventSpillSizeCode(
			"Large",
			"LRG",
			"Equal to or greater than 208 litres and less than or equal to 1500 litres in volume or equal to or greater than 200 kilograms and less than or equal to 1500 kilograms in mass.");
	public static final ChemicalBiologicalEventSpillSizeCode NOT_KNOWN = new ChemicalBiologicalEventSpillSizeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ChemicalBiologicalEventSpillSizeCode SMALL = new ChemicalBiologicalEventSpillSizeCode(
			"Small",
			"SML",
			"Less than 208 litres in volume or 200 kilograms in mass.");
	public static final ChemicalBiologicalEventSpillSizeCode EXTRA_LARGE = new ChemicalBiologicalEventSpillSizeCode(
			"Extra large",
			"XLG",
			"Greater than 1500 litres in volume or 1500 kilograms in mass.");

	private ChemicalBiologicalEventSpillSizeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
