/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaritimeEquipmentTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of MARITIME-EQUIPMENT-TYPE.";
	}

	private static HashMap<String, MaritimeEquipmentTypeSubcategoryCode> physicalToCode = new HashMap<String, MaritimeEquipmentTypeSubcategoryCode>();

	public static MaritimeEquipmentTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaritimeEquipmentTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_BEACON_DAN = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, beacon dan",
			"BUOYBC",
			"A temporary marker active buoy used during minesweeping operations to indicate the boundaries of swept paths, swept areas, known hazards or other locations for some specific reason.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_DAN = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, dan",
			"BUOYDN",
			"A temporary marker buoy used during minesweeping operations to indicate the boundaries of swept paths, swept areas, known hazards or other locations of reference points.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_DEEP_DAN = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, deep dan",
			"BUOYDP",
			"A temporary marker active buoy used in deep water during minesweeping operations to indicate the boundaries of swept paths, swept areas, known hazards or other locations for some specific reason.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_DATUM_DAN = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, datum dan",
			"BUOYDT",
			"A dan buoy intended as a geographical reference or check, which needs to be more visible and more securely moored than a normal dan buoy.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_MARKER = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, marker",
			"BUOYMR",
			"A floating object fastened in a particular place to point out the position of a specific hazard or obstacle or act as a marker for some specific purpose.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_MASTER_REFERENCE = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, master reference",
			"BUOYMS",
			"A floating object fastened in a particular place to point out the position acting as a reference marker for MCM operations.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_NAVIGATION = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, navigation",
			"BUOYNV",
			"A floating object fastened in a particular place to point out the position of a specific hazard or obstacle for navigation purposes.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_PM_5 = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, PM-5",
			"BUOYPM",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1196/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_POSITION_NUMBER = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, position number",
			"BUOYPS",
			"A marked floating object fastened in a particular place to point out the position of a specific hazard or obstacle or act as a marker for some specific reason.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_STANDARD_DAN = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, standard dan",
			"BUOYSD",
			"A temporary marker active buoy used during minesweeping operations to indicate the boundaries of swept paths, swept areas, known hazards or other locations for some specific reason.");
	public static final MaritimeEquipmentTypeSubcategoryCode BUOY_SHORT_SCOPE = new MaritimeEquipmentTypeSubcategoryCode(
			"Buoy, short scope",
			"BUOYSS",
			"A buoy used as a navigational reference that remains nearly vertical over its sinker.");
	public static final MaritimeEquipmentTypeSubcategoryCode CUTTER_END = new MaritimeEquipmentTypeSubcategoryCode(
			"Cutter, end",
			"CUTTEN",
			"In naval mine warfare a device fitted to the end of a sweep wire to cut or part the mooring of mines or obstructors; it may also be fitted in, or to, the mooring of a mine or obstructors to part a sweep wire.");
	public static final MaritimeEquipmentTypeSubcategoryCode CUTTER_EXPLOSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Cutter, explosive",
			"CUTTEX",
			"In naval mine warfare an explosive device fitted to a sweep wire to cut or part the mooring of mines or obstructors; it may also be fitted in, or to, the mooring of a mine or obstructors to part a sweep wire.");
	public static final MaritimeEquipmentTypeSubcategoryCode CUTTER_STATIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Cutter, static",
			"CUTTST",
			"A device that is static and cuts the cable by use of mechanical forces.");
	public static final MaritimeEquipmentTypeSubcategoryCode MULTI_CHANNEL_DIFAR_RELAY = new MaritimeEquipmentTypeSubcategoryCode(
			"Multi-channel DIFAR relay",
			"MCDFRR",
			"A relaying Directional Frequency Ranging sonobuoy with 4-64 Channels.");
	public static final MaritimeEquipmentTypeSubcategoryCode MULTI_CHANNEL_JEZEBEL_RELAY = new MaritimeEquipmentTypeSubcategoryCode(
			"Multi-channel JEZEBEL relay",
			"MCJZBR",
			"A relaying air dropped sonobuoy with 4-64 channels.");
	public static final MaritimeEquipmentTypeSubcategoryCode NOT_OTHERWISE_SPECIFIED = new MaritimeEquipmentTypeSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaritimeEquipmentTypeSubcategoryCode SHF = new MaritimeEquipmentTypeSubcategoryCode(
			"SHF",
			"SHF",
			"A relaying air dropped sonobuoy 4-64 channels.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONARBUOY = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonarbuoy",
			"SONARB",
			"No definition provided in ADatP-3 BL 11.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONOBUOY_ACTIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonobuoy, active",
			"SONOAC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONOBUOY_COMMAND_ACTIVATED_SYSTEM = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonobuoy, command activated system",
			"SONOCA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONOBUOY_DIRECTIONAL_COMMAND_ACTIVATED_SYSTEM = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonobuoy, directional command activated system",
			"SONODC",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONOBUOY_PASSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonobuoy, passive",
			"SONOPA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_ACTIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, active",
			"SONRAC",
			"A system that projects acoustic energy into the water and measures the speed of its return from a reflective surface as an echo to detect an underwater object and determine its range and bearing.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_CRITICAL_ANGLE_TOWED_ARRAY = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, critical angle towed array",
			"SONRCR",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_DIPPING_ACTIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, dipping, active",
			"SONRDA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_DIPPING_PASSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, dipping, passive",
			"SONRDP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_DEPRESSED_ANGLE_TOWED_ARRAY = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, depressed angle towed array",
			"SONRDT",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_HAND_HELD = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, hand held",
			"SONRHH",
			"A hand held acoustic device used primarily for the detection and location of underwater objects.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_PASSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, passive",
			"SONRPS",
			"A system that detects acoustic radiation from another vessel or object.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_REFLECTOR_DIABLO = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, reflector Diablo",
			"SONRRD",
			"A device to make a training mine appear larger or for use during diving conning run ICOS 42+ sides etc.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_SHIP = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, ship",
			"SONRSH",
			"Equipment mounted on a ship that uses acoustic or SOund Navigation And Ranging (SONAR) technology.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_VARIABLE_DEPTH_ACTIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, variable depth, active",
			"SONRVA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SONAR_VARIABLE_DEPTH_PASSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sonar, variable depth, passive",
			"SONRVP",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode STAFF_STAVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Staff/stave",
			"STAFF",
			"A part of the buoy equipment.");
	public static final MaritimeEquipmentTypeSubcategoryCode SURVEILLANCE_TOWED_ARRAY_LONG_RANGE_SYSTEM = new MaritimeEquipmentTypeSubcategoryCode(
			"Surveillance towed array (long range) system",
			"SUBTAS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SUBMARINE_TOWED_ARRAY_SURVEILLANCE_SYSTEM = new MaritimeEquipmentTypeSubcategoryCode(
			"Submarine towed array surveillance system",
			"SUBTSS",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SUBMARINE_TOWED_ARRAY = new MaritimeEquipmentTypeSubcategoryCode(
			"Submarine towed array",
			"SUBTWA",
			"No definition provided in ADatP-3 Baseline 13.1 FFIRN/FUD 1434/1.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_ACOUSTIC_AF = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, acoustic AF",
			"SWPAAF",
			"Equipment designed to locate mines by use of a sweep designed to operate the acoustic firing system of a mine, audio frequency.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_ACOUSTIC_COMBINED = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, acoustic combined",
			"SWPACC",
			"Equipment designed to locate mines by use of a sweep designed to operate the acoustic firing system of a mine, MF and LF frequency 30 to 15000HZ.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_ACOUSTIC_EXPLOSIVE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, acoustic explosive",
			"SWPACE",
			"Equipment designed to locate mines by use of a sweep using the detonation of explosive charges to actuate the acoustic sensors in the mine.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_ACOUSTIC_LF = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, acoustic LF",
			"SWPACL",
			"Equipment designed to locate mines by use of a sweep designed to operate the acoustic firing system of a mine, low frequency, up to 30Hz.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_ACOUSTIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, acoustic",
			"SWPACO",
			"Equipment designed to be used in minesweeping operations, utilizing the acoustic firing mechanisms of the target mines.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HELICOPTER_ACOUSTIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, helicopter acoustic",
			"SWPHAC",
			"Equipment mounted on a helicopter designed to be used in minesweeping operations, utilizing the acoustic firing mechanisms of the target mines.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HELICOPTER_MAGNETIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, helicopter magnetic",
			"SWPHMA",
			"Equipment mounted on a helicopter designed to locate mines by use of a conducting cable through which is passed a high current, towed behind a minesweeper helicopter.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HELICOPTER_MECHANICAL = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, helicopter mechanical",
			"SWPHME",
			"Equipment mounted on a helicopter designed to locate mines in the lane swept by mechanical means.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HOVERCRAFT_ACOUSTIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, hovercraft acoustic",
			"SWPHVA",
			"Equipment mounted on a hovercraft designed to be used in minesweeping operations, utilising the acoustic firing mechanisms of the target mines.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HOVERCRAFT_MECHANICAL = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, hovercraft mechanical",
			"SWPHVE",
			"Equipment mounted on a hovercraft designed to locate mines in the lane swept by mechanical means.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_HOVERCRAFT_MAGNETIC = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, hovercraft magnetic",
			"SWPHVM",
			"Equipment mounted on a hovercraft designed to locate mines by use of a conducting cable through which is passed a high current, towed behind a minesweeper hovercraft.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MECHANICAL_CHAIN = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, mechanical chain",
			"SWPMCC",
			"Equipment designed to locate mines in the lane swept by mechanical means, chains, normally fixed between two or more minesweeping vessels, dragged across the sea-bed.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MECHANICAL_NET = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, mechanical net",
			"SWPMCN",
			"Equipment designed to locate mines in the lane swept by mechanical means; nets normally fixed between two or more minesweeping vessels.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MECHANICAL_SNAGLINE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, mechanical snagline",
			"SWPMCS",
			"Equipment designed to locate mines by use of a wire to catch the snagline of a moored mine.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MECHANICAL_TEAM = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, mechanical team",
			"SWPMCT",
			"Equipment designed to locate mines by towing either a mechanical or influence gear through the liquid with the intention of cutting or destruction of mines. Sweep wire towed between two or more ships using only kites to keep the sweep down.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MECHANICAL = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, mechanical",
			"SWPMEC",
			"Equipment designed to locate mines in the lane swept by mechanical means.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MAGNETIC_ANTENNA = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, magnetic antenna",
			"SWPMGA",
			"Equipment designed to locate mines in the lane swept with either a single or multiple ship rig and is designed to ensure that the sweep wire is not brought into contact with the mines antenna until the mine is a safe distance astern.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MAGNETIC_CLOSED_LOOP = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, magnetic closed loop",
			"SWPMGC",
			"Equipment designed to locate mines by use of a conducting cable, loop shaped through which is passed a high current, towed behind a minesweeper.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MAGNETIC_ELECTRODE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, magnetic electrode",
			"SWPMGE",
			"Equipment designed to locate mines by use of two buoyant conducting cable an electrode fitted between each leg, the electrical circuit being completed through the seawater.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MAGNETIC_OPEN_LOOP = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, magnetic open loop",
			"SWPMGO",
			"Equipment designed to locate mines by use of a conducting cable, open loop shaped through which is passed a high current, towed behind a minesweeper.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_MAGNETIC_SOLENOID = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, magnetic solenoid",
			"SWPMGS",
			"Equipment designed to locate mines by use of large number of horizontal coils through which a small current is passed.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_OROPESA = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, OROPESA",
			"SWPORO",
			"Equipment designed to locate mines using a length of sweep wire that is towed by a single ship, lateral displacement being caused by an Otter and depth being controlled at the ship end by a Kite at the Otter end by a float and float wire.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_PRESSURE = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, pressure",
			"SWPPRS",
			"Equipment designed to locate mine by use of pressure differentials.");
	public static final MaritimeEquipmentTypeSubcategoryCode SWEEP_PROTECTIVE_COMBINATION = new MaritimeEquipmentTypeSubcategoryCode(
			"Sweep, protective combination",
			"SWPPRT",
			"Equipment designed to locate mines by use of a sweep designed to operate the acoustic firing system of a mine, MF and LF frequency 30 to 15000HZ.");

	private MaritimeEquipmentTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
