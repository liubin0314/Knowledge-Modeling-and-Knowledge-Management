/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of OBJECT-ITEM-STATUS.";
	}

	private static HashMap<String, ObjectItemStatusCategoryCode> physicalToCode = new HashMap<String, ObjectItemStatusCategoryCode>();

	public static ObjectItemStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemStatusCategoryCode CONTROL_FEATURE_STATUS = new ObjectItemStatusCategoryCode(
			"CONTROL-FEATURE-STATUS",
			"CF",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific CONTROL-FEATURE.");
	public static final ObjectItemStatusCategoryCode FACILITY_STATUS = new ObjectItemStatusCategoryCode(
			"FACILITY-STATUS",
			"FA",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific FACILITY.");
	public static final ObjectItemStatusCategoryCode GEOGRAPHIC_FEATURE_STATUS = new ObjectItemStatusCategoryCode(
			"GEOGRAPHIC-FEATURE-STATUS",
			"GF",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific GEOGRAPHIC-FEATURE.");
	public static final ObjectItemStatusCategoryCode MATERIEL_STATUS = new ObjectItemStatusCategoryCode(
			"MATERIEL-STATUS",
			"MA",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific MATERIEL.");
	public static final ObjectItemStatusCategoryCode NOT_KNOWN = new ObjectItemStatusCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ObjectItemStatusCategoryCode ORGANISATION_STATUS = new ObjectItemStatusCategoryCode(
			"ORGANISATION-STATUS",
			"OR",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific ORGANISATION.");
	public static final ObjectItemStatusCategoryCode PERSON_STATUS = new ObjectItemStatusCategoryCode(
			"PERSON-STATUS",
			"PE",
			"An OBJECT-ITEM-STATUS that is a record of condition of a specific PERSON.");

	private ObjectItemStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
