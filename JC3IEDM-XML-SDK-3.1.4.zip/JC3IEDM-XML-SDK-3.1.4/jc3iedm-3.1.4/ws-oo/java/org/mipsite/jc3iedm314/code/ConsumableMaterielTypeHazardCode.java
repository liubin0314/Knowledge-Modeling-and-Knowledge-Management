/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ConsumableMaterielTypeHazardCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a CONSUMABLE-MATERIEL-TYPE that requires special handling because of environmental or safety reasons.";
	}

	private static HashMap<String, ConsumableMaterielTypeHazardCode> physicalToCode = new HashMap<String, ConsumableMaterielTypeHazardCode>();

	public static ConsumableMaterielTypeHazardCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ConsumableMaterielTypeHazardCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ConsumableMaterielTypeHazardCode BIOLOGICAL = new ConsumableMaterielTypeHazardCode(
			"Biological",
			"BIOLOG",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having biological properties.");
	public static final ConsumableMaterielTypeHazardCode CHEMICAL = new ConsumableMaterielTypeHazardCode(
			"Chemical",
			"CHM",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having chemical properties.");
	public static final ConsumableMaterielTypeHazardCode CORROSIVE = new ConsumableMaterielTypeHazardCode(
			"Corrosive",
			"COR",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having corrosive properties.");
	public static final ConsumableMaterielTypeHazardCode EXPLOSIVE = new ConsumableMaterielTypeHazardCode(
			"Explosive",
			"EXPLOS",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having explosive properties.");
	public static final ConsumableMaterielTypeHazardCode INFLAMMABLE = new ConsumableMaterielTypeHazardCode(
			"Inflammable",
			"INF",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having inflammable properties.");
	public static final ConsumableMaterielTypeHazardCode NOT_KNOWN = new ConsumableMaterielTypeHazardCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ConsumableMaterielTypeHazardCode NOT_OTHERWISE_SPECIFIED = new ConsumableMaterielTypeHazardCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ConsumableMaterielTypeHazardCode RADIATION = new ConsumableMaterielTypeHazardCode(
			"Radiation",
			"RAD",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having radiation properties.");
	public static final ConsumableMaterielTypeHazardCode TOXIC = new ConsumableMaterielTypeHazardCode(
			"Toxic",
			"TOX",
			"The designation of the possible danger caused by a specific CONSUMABLE-MATERIEL-TYPE having toxic properties.");

	private ConsumableMaterielTypeHazardCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
