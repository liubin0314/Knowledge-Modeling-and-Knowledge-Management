/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GroupOrganisationTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of GROUP-ORGANISATION-TYPE.";
	}

	private static HashMap<String, GroupOrganisationTypeCategoryCode> physicalToCode = new HashMap<String, GroupOrganisationTypeCategoryCode>();

	public static GroupOrganisationTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GroupOrganisationTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GroupOrganisationTypeCategoryCode CIVILIAN_CONVOY_TYPE = new GroupOrganisationTypeCategoryCode(
			"Civilian-convoy-type",
			"CIVCON",
			"A class of civilian convoys.");
	public static final GroupOrganisationTypeCategoryCode CONTRACTOR = new GroupOrganisationTypeCategoryCode(
			"Contractor",
			"CNTRCT",
			"A GROUP-ORGANISATION-TYPE who contracts or undertakes to supply certain articles, or to perform any work or service (esp. for government or other public body) at a certain price or rate.");
	public static final GroupOrganisationTypeCategoryCode CRIMINAL = new GroupOrganisationTypeCategoryCode(
			"Criminal",
			"CRIMIN",
			"A GROUP-ORGANISATION-TYPE that comprises persons who attempt to profit by violating the law.");
	public static final GroupOrganisationTypeCategoryCode DISPLACED_PERSON = new GroupOrganisationTypeCategoryCode(
			"Displaced person",
			"DSPLPR",
			"A GROUP-ORGANISATION-TYPE that comprises persons removed from their home country by military or political pressure.");
	public static final GroupOrganisationTypeCategoryCode EDUCATIONAL = new GroupOrganisationTypeCategoryCode(
			"Educational",
			"EDUCAL",
			"A GROUP-ORGANISATION-TYPE that provides labour and material for the educational process.");
	public static final GroupOrganisationTypeCategoryCode FINANCIAL = new GroupOrganisationTypeCategoryCode(
			"Financial",
			"FINCAL",
			"A GROUP-ORGANISATION-TYPE that provides finance, financial advice and guidance, support for the procurement process, providing pay and disbursing support.");
	public static final GroupOrganisationTypeCategoryCode FOREIGN_FIGHTERS = new GroupOrganisationTypeCategoryCode(
			"Foreign fighters",
			"FRNFGT",
			"A GROUP-ORGANISATION-TYPE that consists of fighters who are not from the country in which the fighting is taking place supporting belligerents or irregular forces.");
	public static final GroupOrganisationTypeCategoryCode GANG = new GroupOrganisationTypeCategoryCode(
			"Gang",
			"GANG",
			"A GROUP-ORGANISATION-TYPE that comprises persons that go together or act in concert.");
	public static final GroupOrganisationTypeCategoryCode INSURGENT = new GroupOrganisationTypeCategoryCode(
			"Insurgent",
			"INSRGT",
			"A GROUP-ORGANISATION-TYPE that rises in revolt against authority.");
	public static final GroupOrganisationTypeCategoryCode INTELLIGENCE = new GroupOrganisationTypeCategoryCode(
			"Intelligence",
			"INTEL",
			"A GROUP-ORGANISATION-TYPE that is employed to gather information.");
	public static final GroupOrganisationTypeCategoryCode INTELLECTUAL = new GroupOrganisationTypeCategoryCode(
			"Intellectual",
			"INTLCT",
			"A GROUP-ORGANISATION-TYPE that comprises intellectual beings possessing superior powers of intellect.");
	public static final GroupOrganisationTypeCategoryCode JOURNALIST = new GroupOrganisationTypeCategoryCode(
			"Journalist",
			"JRNLST",
			"A GROUP-ORGANISATION-TYPE that comprises persons that earn their living by editing or writing for a public journal.");
	public static final GroupOrganisationTypeCategoryCode JUDICIAL = new GroupOrganisationTypeCategoryCode(
			"Judicial",
			"JUDCAL",
			"A GROUP-ORGANISATION-TYPE that is provides judgment in courts of justice or the administration of justice.");
	public static final GroupOrganisationTypeCategoryCode LANDOWNER = new GroupOrganisationTypeCategoryCode(
			"Landowner",
			"LNDOWN",
			"A GROUP-ORGANISATION-TYPE that comprises persons that are owners or proprietors of land.");
	public static final GroupOrganisationTypeCategoryCode LOCAL_INHABITANT = new GroupOrganisationTypeCategoryCode(
			"Local inhabitant",
			"LOCINH",
			"A GROUP-ORGANISATION-TYPE of a particular place regarded with reference to that place.");
	public static final GroupOrganisationTypeCategoryCode MEDICAL = new GroupOrganisationTypeCategoryCode(
			"Medical",
			"MEDCAL",
			"A GROUP-ORGANISATION-TYPE that provides a medical service.");
	public static final GroupOrganisationTypeCategoryCode MEDIA_INTERNATIONAL = new GroupOrganisationTypeCategoryCode(
			"Media, international",
			"MEDINT",
			"A GROUP-ORGANISATION-TYPE that comprises persons that report for international mass communications, but do not take part in the actions.");
	public static final GroupOrganisationTypeCategoryCode MEDIA_LOCAL = new GroupOrganisationTypeCategoryCode(
			"Media, local",
			"MEDLCL",
			"A GROUP-ORGANISATION-TYPE that comprises persons that report for local mass communications, but do not take part in the actions.");
	public static final GroupOrganisationTypeCategoryCode MEDIA_NATIONAL = new GroupOrganisationTypeCategoryCode(
			"Media, national",
			"MEDNAT",
			"A GROUP-ORGANISATION-TYPE that comprises persons that report for national mass communications, but do not take part in the actions.");
	public static final GroupOrganisationTypeCategoryCode MEDIA_NOT_OTHERWISE_SPECIFIED = new GroupOrganisationTypeCategoryCode(
			"Media, not otherwise specified",
			"MEDNOS",
			"A GROUP-ORGANISATION-TYPE that comprises persons that report for mass communications (especially television, radio, and newspapers) of an origin not specified.");
	public static final GroupOrganisationTypeCategoryCode MERCHANT = new GroupOrganisationTypeCategoryCode(
			"Merchant",
			"MRCHNT",
			"A GROUP-ORGANISATION-TYPE that comprises persons whose occupation is the purchase and sale of marketable commodities for profit.");
	public static final GroupOrganisationTypeCategoryCode NOT_KNOWN = new GroupOrganisationTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final GroupOrganisationTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new GroupOrganisationTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final GroupOrganisationTypeCategoryCode POLICE_CHIEF = new GroupOrganisationTypeCategoryCode(
			"Police chief",
			"POLCHF",
			"A GROUP-ORGANISATION-TYPE that comprises persons that have the responsibility for the regulation, discipline, and control of a community for the enforcement of law and public order.");
	public static final GroupOrganisationTypeCategoryCode POLICE = new GroupOrganisationTypeCategoryCode(
			"Police",
			"POLICE",
			"A GROUP-ORGANISATION-TYPE that is responsible for the regulation, discipline and control of community, civil administration; enforcement of the law; public order.");
	public static final GroupOrganisationTypeCategoryCode POLITICAL = new GroupOrganisationTypeCategoryCode(
			"Political",
			"POLTCL",
			"A GROUP-ORGANISATION-TYPE that is identified as being involved within a political area of activity and concerned with politics or has ties to a political party.");
	public static final GroupOrganisationTypeCategoryCode PRISONER_OF_WAR = new GroupOrganisationTypeCategoryCode(
			"Prisoner of war",
			"POW",
			"A GROUP-ORGANISATION-TYPE that comprises persons that have fallen in the hands of or surrendered to an opponent.");
	public static final GroupOrganisationTypeCategoryCode PRISONER = new GroupOrganisationTypeCategoryCode(
			"Prisoner",
			"PRSNR",
			"A GROUP-ORGANISATION-TYPE in custody on a criminal charge and on trial.");
	public static final GroupOrganisationTypeCategoryCode REFUGEE = new GroupOrganisationTypeCategoryCode(
			"Refugee",
			"REFUGE",
			"A GROUP-ORGANISATION-TYPE that comprises persons who, owing to religious persecution or political troubles, seek refuge.");
	public static final GroupOrganisationTypeCategoryCode SHURA = new GroupOrganisationTypeCategoryCode(
			"Shura",
			"SHURA",
			"A GROUP-ORGANISATION-TYPE that is an Islamic consultative council or similar advisory body.");
	public static final GroupOrganisationTypeCategoryCode SOCIAL = new GroupOrganisationTypeCategoryCode(
			"Social",
			"SOCIAL",
			"A GROUP-ORGANISATION-TYPE that seeks and enjoys companies of others, or characterized by friendly companionship or relations.");
	public static final GroupOrganisationTypeCategoryCode TERRORIST = new GroupOrganisationTypeCategoryCode(
			"Terrorist",
			"TERRST",
			"A GROUP-ORGANISATION-TYPE that comprises persons that attempt to further their views by a system of coercive intimidation.");
	public static final GroupOrganisationTypeCategoryCode TRIBAL = new GroupOrganisationTypeCategoryCode(
			"Tribal",
			"TRIBAL",
			"A GROUP-ORGANISATION-TYPE consisting of a number of families, clans, or other groups who share a common ancestry and culture.");
	public static final GroupOrganisationTypeCategoryCode VILLAGE_ELDER = new GroupOrganisationTypeCategoryCode(
			"Village elder",
			"VILELD",
			"A GROUP-ORGANISATION-TYPE that comprises persons that are of ripe years and experience whose counsel is therefore sought and valued.");
	public static final GroupOrganisationTypeCategoryCode WRITER = new GroupOrganisationTypeCategoryCode(
			"Writer",
			"WRITER",
			"A GROUP-ORGANISATION-TYPE that comprises persons that practice or perform writing.");

	private GroupOrganisationTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
