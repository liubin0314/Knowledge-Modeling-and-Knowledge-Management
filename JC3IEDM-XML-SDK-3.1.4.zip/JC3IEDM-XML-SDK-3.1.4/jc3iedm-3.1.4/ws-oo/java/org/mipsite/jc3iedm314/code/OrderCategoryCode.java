/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrderCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of ORDER.";
	}

	private static HashMap<String, OrderCategoryCode> physicalToCode = new HashMap<String, OrderCategoryCode>();

	public static OrderCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrderCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrderCategoryCode ADMINISTRATIVE_LOGISTICS_ORDER = new OrderCategoryCode(
			"Administrative/Logistics order",
			"ADLOGO",
			"An order to give the commander�s plan for administrative and service support of operations.");
	public static final OrderCategoryCode FRAGMENTARY_ORDER_TO_EXISTING_OPERATION_ORDER = new OrderCategoryCode(
			"Fragmentary order to existing operation order",
			"FRAGO",
			"An abbreviated form of an Operations order.");
	public static final OrderCategoryCode OPERATIONS_ORDER = new OrderCategoryCode(
			"Operations order",
			"OPORD",
			"An order that includes only such detail as is necessary for commanders of subordinate formations/units to issue their own orders and to ensure coordination.");
	public static final OrderCategoryCode WARNING_ORDER = new OrderCategoryCode(
			"Warning order",
			"WNGO",
			"An order to assist units and their staffs initiate the preparations for and the execution of their new mission by giving them the maximum warning and essential details of impending operations and information of time available.");
	public static final OrderCategoryCode NOT_OTHERWISE_SPECIFIED = new OrderCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private OrderCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
