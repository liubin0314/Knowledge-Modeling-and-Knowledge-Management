/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class TargetPersonnelProtectionCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that denotes the protective posture of personnel for the specific TARGET.";
	}

	private static HashMap<String, TargetPersonnelProtectionCategoryCode> physicalToCode = new HashMap<String, TargetPersonnelProtectionCategoryCode>();

	public static TargetPersonnelProtectionCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<TargetPersonnelProtectionCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final TargetPersonnelProtectionCategoryCode UNDER_COVER = new TargetPersonnelProtectionCategoryCode(
			"Under cover",
			"COVER",
			"First volley (under overhead cover); second volley (under overhead cover).");
	public static final TargetPersonnelProtectionCategoryCode DUG_IN = new TargetPersonnelProtectionCategoryCode(
			"Dug in",
			"DUGIN",
			"First volley (dug in); second volley (dug in).");
	public static final TargetPersonnelProtectionCategoryCode HALF_PRONE_HALF_STANDING = new TargetPersonnelProtectionCategoryCode(
			"Half prone, half standing",
			"PRAND",
			"First volley (half prone; half standing); second volley (all prone).");
	public static final TargetPersonnelProtectionCategoryCode PRONE = new TargetPersonnelProtectionCategoryCode(
			"Prone",
			"PRONE",
			"First volley (prone); second volley (prone).");
	public static final TargetPersonnelProtectionCategoryCode PRONE_UNDER_COVER = new TargetPersonnelProtectionCategoryCode(
			"Prone, under cover",
			"PROVER",
			"First volley (prone); second volley (under overhead cover).");
	public static final TargetPersonnelProtectionCategoryCode PRONE_DUG_IN = new TargetPersonnelProtectionCategoryCode(
			"Prone, dug in",
			"PRUG",
			"First volley (prone); second volley (dug in).");

	private TargetPersonnelProtectionCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
