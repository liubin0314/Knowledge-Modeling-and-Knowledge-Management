/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrbitAreaAlignmentCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the placement of a specific ORBIT-AREA with respect to its defining reference axis.";
	}

	private static HashMap<String, OrbitAreaAlignmentCode> physicalToCode = new HashMap<String, OrbitAreaAlignmentCode>();

	public static OrbitAreaAlignmentCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrbitAreaAlignmentCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrbitAreaAlignmentCode CENTRE = new OrbitAreaAlignmentCode(
			"Centre",
			"CENTRE",
			"The sides of a specific ORBIT-AREA are equidistant from the reference axis.");
	public static final OrbitAreaAlignmentCode LEFT = new OrbitAreaAlignmentCode(
			"Left",
			"LEFT",
			"The right side of a specific ORBIT-AREA coincides with the reference axis.");
	public static final OrbitAreaAlignmentCode RIGHT = new OrbitAreaAlignmentCode(
			"Right",
			"RIGHT",
			"The left side of a specific ORBIT-AREA coincides with the reference axis.");

	private OrbitAreaAlignmentCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
