/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ORGANISATION.";
	}

	private static HashMap<String, OrganisationCategoryCode> physicalToCode = new HashMap<String, OrganisationCategoryCode>();

	public static OrganisationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationCategoryCode CONVOY = new OrganisationCategoryCode(
			"CONVOY",
			"CO",
			"An ORGANISATION that is a group of vehicles or vessels organised for the purpose of control and orderly movement with or without escort protection.");
	public static final OrganisationCategoryCode NOT_OTHERWISE_SPECIFIED = new OrganisationCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final OrganisationCategoryCode UNIT = new OrganisationCategoryCode(
			"UNIT",
			"UN",
			"A military ORGANISATION whose structure is prescribed by competent authority.");

	private OrganisationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
