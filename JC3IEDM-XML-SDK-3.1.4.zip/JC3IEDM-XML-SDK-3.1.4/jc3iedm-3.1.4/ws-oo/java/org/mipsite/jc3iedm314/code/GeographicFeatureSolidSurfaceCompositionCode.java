/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureSolidSurfaceCompositionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the composition of the surface of the GEOGRAPHIC-FEATURE.";
	}

	private static HashMap<String, GeographicFeatureSolidSurfaceCompositionCode> physicalToCode = new HashMap<String, GeographicFeatureSolidSurfaceCompositionCode>();

	public static GeographicFeatureSolidSurfaceCompositionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureSolidSurfaceCompositionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureSolidSurfaceCompositionCode BEDROCK = new GeographicFeatureSolidSurfaceCompositionCode(
			"Bedrock",
			"BDROCK",
			"A characterisation of an area which is composed of a naturally exposed material consisting of bedrock.");
	public static final GeographicFeatureSolidSurfaceCompositionCode CORAL = new GeographicFeatureSolidSurfaceCompositionCode(
			"Coral",
			"CORAL",
			"A characterisation of an area which is composed of coral.");
	public static final GeographicFeatureSolidSurfaceCompositionCode EARTH = new GeographicFeatureSolidSurfaceCompositionCode(
			"Earth",
			"EARTH",
			"A characterisation of an area which is composed of soil.");
	public static final GeographicFeatureSolidSurfaceCompositionCode ICE = new GeographicFeatureSolidSurfaceCompositionCode(
			"Ice",
			"ICE",
			"A characterisation of an area which is composed of a layer or mass of frozen water.");
	public static final GeographicFeatureSolidSurfaceCompositionCode NOT_OTHERWISE_SPECIFIED = new GeographicFeatureSolidSurfaceCompositionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final GeographicFeatureSolidSurfaceCompositionCode SAND = new GeographicFeatureSolidSurfaceCompositionCode(
			"Sand",
			"SAND",
			"A characterisation of an area that is composed mainly of small, loose grains of worn or disintegrated rock.");
	public static final GeographicFeatureSolidSurfaceCompositionCode SNOW = new GeographicFeatureSolidSurfaceCompositionCode(
			"Snow",
			"SNOW",
			"A characterisation of an area which is composed of snow.");

	private GeographicFeatureSolidSurfaceCompositionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
