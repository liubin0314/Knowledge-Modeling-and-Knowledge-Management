/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GenderCode extends CodeDomain {

	public static String getComment() {
		return "A code that represents the classification of a person based on reproductive physiological traits.";
	}

	private static HashMap<String, GenderCode> physicalToCode = new HashMap<String, GenderCode>();

	public static GenderCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GenderCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GenderCode FEMALE = new GenderCode(
			"Female",
			"FEMALE",
			"Feminine.");
	public static final GenderCode MALE = new GenderCode(
			"Male",
			"MALE",
			"Masculine.");
	public static final GenderCode NOT_KNOWN = new GenderCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private GenderCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
