/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class LanguageCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a particular language.";
	}

	private static HashMap<String, LanguageCategoryCode> physicalToCode = new HashMap<String, LanguageCategoryCode>();

	public static LanguageCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<LanguageCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final LanguageCategoryCode AFGHAN = new LanguageCategoryCode(
			"Afghan",
			"AFGHAN",
			"The language of Afghan.");
	public static final LanguageCategoryCode AFRICAN_AKAN = new LanguageCategoryCode(
			"African (Akan)",
			"AFRAKN",
			"The language of African (Akan).");
	public static final LanguageCategoryCode AFRICAN_EWE = new LanguageCategoryCode(
			"African (Ewe)",
			"AFREWE",
			"The language of African (Ewe).");
	public static final LanguageCategoryCode AFRICAN_GA = new LanguageCategoryCode(
			"African (Ga)",
			"AFRGA",
			"The language of African (Ga).");
	public static final LanguageCategoryCode AFRICAN_KIKONGO = new LanguageCategoryCode(
			"African (Kikongo)",
			"AFRKKN",
			"The language of African (Kikongo).");
	public static final LanguageCategoryCode AFRIKAANS = new LanguageCategoryCode(
			"Afrikaans",
			"AFRKNS",
			"The language of Afrikaans.");
	public static final LanguageCategoryCode AFRICAN_LINGALA = new LanguageCategoryCode(
			"African (Lingala)",
			"AFRLNG",
			"The language of African (Lingala).");
	public static final LanguageCategoryCode AFRICAN_MOSHI_DAGOMBA = new LanguageCategoryCode(
			"African (Moshi-dagomba)",
			"AFRMSH",
			"The language of African (Moshi-dagomba).");
	public static final LanguageCategoryCode ALBANIAN = new LanguageCategoryCode(
			"Albanian",
			"ALBNAN",
			"The language of Albanian.");
	public static final LanguageCategoryCode ALEMANNIC = new LanguageCategoryCode(
			"Alemannic",
			"ALMNIC",
			"The language of Alemannic.");
	public static final LanguageCategoryCode AMHARIC = new LanguageCategoryCode(
			"Amharic",
			"AMHRIC",
			"The language of Amharic.");
	public static final LanguageCategoryCode AMERINDIAN = new LanguageCategoryCode(
			"Amerindian",
			"AMRNDN",
			"The language of Amerindian.");
	public static final LanguageCategoryCode ANGAUR = new LanguageCategoryCode(
			"Angaur",
			"ANGAUR",
			"The language of Angaur.");
	public static final LanguageCategoryCode ARABIC = new LanguageCategoryCode(
			"Arabic",
			"ARABIC",
			"The language of Arabic.");
	public static final LanguageCategoryCode ARMENIAN = new LanguageCategoryCode(
			"Armenian",
			"ARMNAN",
			"The language of Armenian.");
	public static final LanguageCategoryCode ASSAMESE = new LanguageCategoryCode(
			"Assamese",
			"ASSMES",
			"The language of Assamese.");
	public static final LanguageCategoryCode ASSYRIAN = new LanguageCategoryCode(
			"Assyrian",
			"ASSYRN",
			"The language of Assyrian.");
	public static final LanguageCategoryCode AYMARA = new LanguageCategoryCode(
			"Aymara",
			"AYMARA",
			"The language of Aymara.");
	public static final LanguageCategoryCode AZERI = new LanguageCategoryCode(
			"Azeri",
			"AZERI",
			"The language of Azeri.");
	public static final LanguageCategoryCode AZERBAIJANI = new LanguageCategoryCode(
			"Azerbaijani",
			"AZRBJN",
			"The language of Azerbaijani.");
	public static final LanguageCategoryCode BAHASA_INDONESIA = new LanguageCategoryCode(
			"Bahasa indonesia",
			"BAHSIN",
			"The language of Bahasa indonesia.");
	public static final LanguageCategoryCode BALOCHI = new LanguageCategoryCode(
			"Balochi",
			"BALOCH",
			"The language of Balochi.");
	public static final LanguageCategoryCode BAMBRA = new LanguageCategoryCode(
			"Bambra",
			"BAMBRA",
			"The language of Bambra.");
	public static final LanguageCategoryCode BANDJABI = new LanguageCategoryCode(
			"Bandjabi",
			"BANDJB",
			"The language of Bandjabi.");
	public static final LanguageCategoryCode BANGLA = new LanguageCategoryCode(
			"Bangla",
			"BANGLA",
			"The language of Bangla.");
	public static final LanguageCategoryCode BANTU = new LanguageCategoryCode(
			"Bantu",
			"BANTU",
			"The language of Bantu.");
	public static final LanguageCategoryCode BAPOUNOU_ESCHIRA = new LanguageCategoryCode(
			"Bapounou-eschira",
			"BAPNES",
			"The language of Bapounou-eschira.");
	public static final LanguageCategoryCode BATEKE = new LanguageCategoryCode(
			"Bateke",
			"BATEKE",
			"The language of Bateke.");
	public static final LanguageCategoryCode BENGALI = new LanguageCategoryCode(
			"Bengali",
			"BENGLI",
			"The language of Bengali.");
	public static final LanguageCategoryCode BERBER = new LanguageCategoryCode(
			"Berber",
			"BERBER",
			"The language of Berber.");
	public static final LanguageCategoryCode BHOTESE_TIBETAN = new LanguageCategoryCode(
			"Bhotese (Tibetan)",
			"BHTSTB",
			"The language of Bhotese (Tibetan).");
	public static final LanguageCategoryCode BICHELAMA = new LanguageCategoryCode(
			"Bichelama",
			"BICHLM",
			"The language of Bichelama.");
	public static final LanguageCategoryCode BISLAMA = new LanguageCategoryCode(
			"Bislama",
			"BISLMA",
			"The language of Bislama.");
	public static final LanguageCategoryCode BOJPOORI = new LanguageCategoryCode(
			"Bojpoori",
			"BOJPOR",
			"The language of Bojpoori.");
	public static final LanguageCategoryCode BUBI = new LanguageCategoryCode(
			"Bubi",
			"BUBI",
			"The language of Bubi.");
	public static final LanguageCategoryCode BULGARIAN = new LanguageCategoryCode(
			"Bulgarian",
			"BULGRN",
			"The language of Bulgarian.");
	public static final LanguageCategoryCode BURMESE = new LanguageCategoryCode(
			"Burmese",
			"BURMSE",
			"The language of Burmese.");
	public static final LanguageCategoryCode BYELORUSSIAN = new LanguageCategoryCode(
			"Byelorussian",
			"BYLRSN",
			"The language of Byelorussian.");
	public static final LanguageCategoryCode CAKCHIQUEL = new LanguageCategoryCode(
			"Cakchiquel",
			"CAKCHQ",
			"The language of Cakchiquel.");
	public static final LanguageCategoryCode CAROLINIAN = new LanguageCategoryCode(
			"Carolinian",
			"CAROLN",
			"The language of Carolinian.");
	public static final LanguageCategoryCode CHAMORRO = new LanguageCategoryCode(
			"Chamorro",
			"CHAMOR",
			"The language of Chamorro.");
	public static final LanguageCategoryCode CHICHEWA = new LanguageCategoryCode(
			"Chichewa",
			"CHICHW",
			"The language of Chichewa.");
	public static final LanguageCategoryCode CHINESE_CANTONESE = new LanguageCategoryCode(
			"Chinese (Cantonese)",
			"CHNCNT",
			"The language of Chinese (Cantonese).");
	public static final LanguageCategoryCode CHINESE = new LanguageCategoryCode(
			"Chinese",
			"CHNESE",
			"The language of Chinese.");
	public static final LanguageCategoryCode CHINESE_HAKKA = new LanguageCategoryCode(
			"Chinese (Hakka)",
			"CHNHKK",
			"The language of Chinese (Hakka).");
	public static final LanguageCategoryCode CHINESE_MANDARIN = new LanguageCategoryCode(
			"Chinese (Mandarin)",
			"CHNMND",
			"The language of Chinese (Mandarin).");
	public static final LanguageCategoryCode CHINESE_PUTONGHUA = new LanguageCategoryCode(
			"Chinese (Putonghua)",
			"CHNPTN",
			"The language of Chinese (Putonghua).");
	public static final LanguageCategoryCode CIRCASSIAN = new LanguageCategoryCode(
			"Circassian",
			"CIRCAS",
			"The language of Circassian.");
	public static final LanguageCategoryCode COMORAN = new LanguageCategoryCode(
			"Comoran",
			"COMORN",
			"The language of Comoran.");
	public static final LanguageCategoryCode CREOLE = new LanguageCategoryCode(
			"Creole",
			"CREOLE",
			"The language of Creole.");
	public static final LanguageCategoryCode CREOLE_PATOIS = new LanguageCategoryCode(
			"Creole patois",
			"CREPAT",
			"The language of Creole patois.");
	public static final LanguageCategoryCode CRIOLO = new LanguageCategoryCode(
			"Criolo",
			"CRIOLO",
			"The language of Criolo.");
	public static final LanguageCategoryCode CUSHITIC = new LanguageCategoryCode(
			"Cushitic",
			"CUSHTC",
			"The language of Cushitic.");
	public static final LanguageCategoryCode CZECH = new LanguageCategoryCode(
			"Czech",
			"CZECH",
			"The language of Czech.");
	public static final LanguageCategoryCode DAGOMBA = new LanguageCategoryCode(
			"Dagomba",
			"DAGOMB",
			"The language of Dagomba.");
	public static final LanguageCategoryCode DANISH = new LanguageCategoryCode(
			"Danish",
			"DANISH",
			"The language of Danish.");
	public static final LanguageCategoryCode DIALECTS = new LanguageCategoryCode(
			"Dialects",
			"DIALCT",
			"The languages of Dialects.");
	public static final LanguageCategoryCode DIOLA = new LanguageCategoryCode(
			"Diola",
			"DIOLA",
			"The language of Diola.");
	public static final LanguageCategoryCode DIVEHI = new LanguageCategoryCode(
			"Divehi",
			"DIVEHI",
			"The language of Divehi.");
	public static final LanguageCategoryCode DJERMA = new LanguageCategoryCode(
			"Djerma",
			"DJERMA",
			"The language of Djerma.");
	public static final LanguageCategoryCode DUTCH = new LanguageCategoryCode(
			"Dutch",
			"DUTCH",
			"The language of Dutch.");
	public static final LanguageCategoryCode DZONGKHA = new LanguageCategoryCode(
			"Dzongkha",
			"DZONGK",
			"The language of Dzongkha.");
	public static final LanguageCategoryCode ENGLISH = new LanguageCategoryCode(
			"English",
			"ENGLSH",
			"The language of English.");
	public static final LanguageCategoryCode ENGLISH_MALAY = new LanguageCategoryCode(
			"English malay",
			"ENGLSM",
			"The language of English malay.");
	public static final LanguageCategoryCode ESKIMO_DIALECTS = new LanguageCategoryCode(
			"Eskimo dialects",
			"ESKIMO",
			"The languages of Eskimo dialects.");
	public static final LanguageCategoryCode ESTONIAN = new LanguageCategoryCode(
			"Estonian",
			"ESTONN",
			"The language of Estonian.");
	public static final LanguageCategoryCode FANG = new LanguageCategoryCode(
			"Fang",
			"FANG",
			"The language of Fang.");
	public static final LanguageCategoryCode FAROESE = new LanguageCategoryCode(
			"Faroese",
			"FAROES",
			"The language of Faroese.");
	public static final LanguageCategoryCode FARSI = new LanguageCategoryCode(
			"Farsi",
			"FARSI",
			"The language of Farsi.");
	public static final LanguageCategoryCode FIJIAN = new LanguageCategoryCode(
			"Fijian",
			"FIJIAN",
			"The language of Fijian.");
	public static final LanguageCategoryCode FILIPINO = new LanguageCategoryCode(
			"Filipino",
			"FILPNO",
			"The language of Filipino.");
	public static final LanguageCategoryCode FINNISH = new LanguageCategoryCode(
			"Finnish",
			"FINNSH",
			"The language of Finnish.");
	public static final LanguageCategoryCode FLEMISH = new LanguageCategoryCode(
			"Flemish",
			"FLEMSH",
			"The language of Flemish.");
	public static final LanguageCategoryCode FON = new LanguageCategoryCode(
			"Fon",
			"FON",
			"The language of Fon.");
	public static final LanguageCategoryCode FRENCH = new LanguageCategoryCode(
			"French",
			"FRENCH",
			"The language of French.");
	public static final LanguageCategoryCode FRENCH_ALSATIAN = new LanguageCategoryCode(
			"French (Alsatian)",
			"FRNHAL",
			"The language of French (Alsatian).");
	public static final LanguageCategoryCode FRENCH_BASQUE = new LanguageCategoryCode(
			"French (Basque)",
			"FRNHBA",
			"The language of French (Basque).");
	public static final LanguageCategoryCode FRENCH_BRETON = new LanguageCategoryCode(
			"French (Breton)",
			"FRNHBR",
			"The language of French (Breton).");
	public static final LanguageCategoryCode FRENCH_CATALAN = new LanguageCategoryCode(
			"French (Catalan)",
			"FRNHCA",
			"The language of French (Catalan).");
	public static final LanguageCategoryCode FRENCH_CORSICAN = new LanguageCategoryCode(
			"French (Corsican)",
			"FRNHCO",
			"The language of French (Corsican).");
	public static final LanguageCategoryCode FRENCH_NORMAN = new LanguageCategoryCode(
			"French (Norman)",
			"FRNHNO",
			"The language of French (Norman).");
	public static final LanguageCategoryCode FRENCH_PATOIS = new LanguageCategoryCode(
			"French (Patois)",
			"FRNHPA",
			"The language of French (Patois).");
	public static final LanguageCategoryCode FRENCH_PROVENCAL = new LanguageCategoryCode(
			"French (Provencal)",
			"FRNHPR",
			"The language of French (Provencal).");
	public static final LanguageCategoryCode FULA = new LanguageCategoryCode(
			"Fula",
			"FULA",
			"The language of Fula.");
	public static final LanguageCategoryCode FULANI = new LanguageCategoryCode(
			"Fulani",
			"FULANI",
			"The language of Fulani.");
	public static final LanguageCategoryCode GAN = new LanguageCategoryCode(
			"Gan",
			"GAN",
			"The language of Gan.");
	public static final LanguageCategoryCode GEORGIAN = new LanguageCategoryCode(
			"Georgian",
			"GEORGN",
			"The language of Georgian.");
	public static final LanguageCategoryCode GERMAN = new LanguageCategoryCode(
			"German",
			"GERMAN",
			"The language of German.");
	public static final LanguageCategoryCode GILBERTESE = new LanguageCategoryCode(
			"Gilbertese",
			"GILBER",
			"The language of Gilbertese.");
	public static final LanguageCategoryCode GREEK = new LanguageCategoryCode(
			"Greek",
			"GREEK",
			"The language of Greek.");
	public static final LanguageCategoryCode GARIFUNA_CARIB = new LanguageCategoryCode(
			"Garifuna (Carib)",
			"GRFNCA",
			"The language of Garifuna (Carib).");
	public static final LanguageCategoryCode GREENLANDIC = new LanguageCategoryCode(
			"Greenlandic",
			"GRNLND",
			"The language of Greenlandic.");
	public static final LanguageCategoryCode GUARAGINGA = new LanguageCategoryCode(
			"Guaraginga",
			"GUARAG",
			"The language of Guaraginga.");
	public static final LanguageCategoryCode GUARANI = new LanguageCategoryCode(
			"Guarani",
			"GUARAN",
			"The language of Guarani.");
	public static final LanguageCategoryCode GUJARATI = new LanguageCategoryCode(
			"Gujarati",
			"GUJART",
			"The language of Gujarati.");
	public static final LanguageCategoryCode HASSANIYA_ARABIC = new LanguageCategoryCode(
			"Hassaniya arabic",
			"HASNAR",
			"The language of Hassaniya arabic.");
	public static final LanguageCategoryCode HAUSSA = new LanguageCategoryCode(
			"Haussa",
			"HAUSSA",
			"The language of Haussa.");
	public static final LanguageCategoryCode HEBREW = new LanguageCategoryCode(
			"Hebrew",
			"HEBREW",
			"The language of Hebrew.");
	public static final LanguageCategoryCode HINDI = new LanguageCategoryCode(
			"Hindi",
			"HINDI",
			"The language of Hindi.");
	public static final LanguageCategoryCode HINDUSTANI = new LanguageCategoryCode(
			"Hindustani",
			"HINDUS",
			"The language of Hindustani.");
	public static final LanguageCategoryCode HUNGARIAN = new LanguageCategoryCode(
			"Hungarian",
			"HUNGRN",
			"The language of Hungarian.");
	public static final LanguageCategoryCode HUNSA = new LanguageCategoryCode(
			"Hunsa",
			"HUNSA",
			"The language of Hunsa.");
	public static final LanguageCategoryCode IBO = new LanguageCategoryCode(
			"Ibo",
			"IBO",
			"The language of Ibo.");
	public static final LanguageCategoryCode ICELANDIC = new LanguageCategoryCode(
			"Icelandic",
			"ICELND",
			"The language of Icelandic.");
	public static final LanguageCategoryCode INDIAN = new LanguageCategoryCode(
			"Indian",
			"INDIAN",
			"The language of Indian.");
	public static final LanguageCategoryCode INDIAN_QUECHUA = new LanguageCategoryCode(
			"Indian (Quechua)",
			"INDQUE",
			"The language of Indian (Quechua).");
	public static final LanguageCategoryCode IRISH_GAELIC = new LanguageCategoryCode(
			"Irish (Gaelic)",
			"IRISHG",
			"The language of Irish (Gaelic).");
	public static final LanguageCategoryCode ITALIAN = new LanguageCategoryCode(
			"Italian",
			"ITALAN",
			"The language of Italian.");
	public static final LanguageCategoryCode JAPANESE = new LanguageCategoryCode(
			"Japanese",
			"JAPNES",
			"The language of Japanese.");
	public static final LanguageCategoryCode JAVANESE = new LanguageCategoryCode(
			"Javanese",
			"JAVNES",
			"The language of Javanese.");
	public static final LanguageCategoryCode KABYE = new LanguageCategoryCode(
			"Kabye",
			"KABYE",
			"The language of Kabye.");
	public static final LanguageCategoryCode KANNADA = new LanguageCategoryCode(
			"Kannada",
			"KANADA",
			"The language of Kannada.");
	public static final LanguageCategoryCode KASHMIRI = new LanguageCategoryCode(
			"Kashmiri",
			"KASHMR",
			"The language of Kashmiri.");
	public static final LanguageCategoryCode KAZAKH_QAZAQ = new LanguageCategoryCode(
			"Kazakh (Qazaq)",
			"KAZKHQ",
			"The language of Kazakh (Qazaq).");
	public static final LanguageCategoryCode KEKCHI = new LanguageCategoryCode(
			"Kekchi",
			"KEKCHI",
			"The language of Kekchi.");
	public static final LanguageCategoryCode KHALKHA_MONGOL = new LanguageCategoryCode(
			"Khalkha mongol",
			"KHLKHM",
			"The language of Khalkha mongol.");
	public static final LanguageCategoryCode KHMER = new LanguageCategoryCode(
			"Khmer",
			"KHMER",
			"The language of Khmer.");
	public static final LanguageCategoryCode KIKONGO = new LanguageCategoryCode(
			"Kikongo",
			"KIKNGO",
			"The language of Kikongo.");
	public static final LanguageCategoryCode KINGWANA = new LanguageCategoryCode(
			"Kingwana",
			"KINGWN",
			"The language of Kingwana.");
	public static final LanguageCategoryCode KINYARWANDA = new LanguageCategoryCode(
			"Kinyarwanda",
			"KINYRW",
			"The language of Kinyarwanda.");
	public static final LanguageCategoryCode KIRGHIZ_KYRGYZ = new LanguageCategoryCode(
			"Kirghiz (Kyrgyz)",
			"KIRGZK",
			"The language of Kirghiz (Kyrgyz).");
	public static final LanguageCategoryCode KIRUNDI = new LanguageCategoryCode(
			"Kirundi",
			"KIRUND",
			"The language of Kirundi.");
	public static final LanguageCategoryCode KISWAHILI = new LanguageCategoryCode(
			"Kiswahili",
			"KISWHL",
			"The language of Kiswahili.");
	public static final LanguageCategoryCode KOREAN = new LanguageCategoryCode(
			"Korean",
			"KOREAN",
			"The language of Korean.");
	public static final LanguageCategoryCode KRIO = new LanguageCategoryCode(
			"Krio",
			"KRIO",
			"The language of Krio.");
	public static final LanguageCategoryCode KUNAMA = new LanguageCategoryCode(
			"Kunama",
			"KUNAMA",
			"The language of Kunama.");
	public static final LanguageCategoryCode KURDISH = new LanguageCategoryCode(
			"Kurdish",
			"KURDSH",
			"The language of Kurdish.");
	public static final LanguageCategoryCode LAO = new LanguageCategoryCode(
			"Lao",
			"LAO",
			"The language of Lao.");
	public static final LanguageCategoryCode LAPP = new LanguageCategoryCode(
			"Lapp",
			"LAPP",
			"The language of Lapp.");
	public static final LanguageCategoryCode LATIN = new LanguageCategoryCode(
			"Latin",
			"LATIN",
			"The language of Latin.");
	public static final LanguageCategoryCode LATVIAN = new LanguageCategoryCode(
			"Latvian",
			"LATVAN",
			"The language of Latvian.");
	public static final LanguageCategoryCode LINGALA = new LanguageCategoryCode(
			"Lingala",
			"LINGAL",
			"The language of Lingala.");
	public static final LanguageCategoryCode LITHUANIAN = new LanguageCategoryCode(
			"Lithuanian",
			"LITHUN",
			"The language of Lithuanian.");
	public static final LanguageCategoryCode LUGANDA = new LanguageCategoryCode(
			"Luganda",
			"LUGAND",
			"The language of Luganda.");
	public static final LanguageCategoryCode LURI = new LanguageCategoryCode(
			"Luri",
			"LURI",
			"The language of Luri.");
	public static final LanguageCategoryCode LUXEMBOURGISCH = new LanguageCategoryCode(
			"Luxembourgisch",
			"LUXEMB",
			"The language of Luxembourgisch.");
	public static final LanguageCategoryCode MACEDONIAN = new LanguageCategoryCode(
			"Macedonian",
			"MACDNN",
			"The language of Macedonian.");
	public static final LanguageCategoryCode MAHORIAN = new LanguageCategoryCode(
			"Mahorian",
			"MAHRAN",
			"The language of Mahorian.");
	public static final LanguageCategoryCode MALAY = new LanguageCategoryCode(
			"Malay",
			"MALAY",
			"The language of Malay.");
	public static final LanguageCategoryCode MALAYALAM = new LanguageCategoryCode(
			"Malayalam",
			"MALAYL",
			"The language of Malayalam.");
	public static final LanguageCategoryCode MALAYO_POLYNESIAN = new LanguageCategoryCode(
			"Malayo-polynesian",
			"MALAYO",
			"The language of Malayo-polynesian.");
	public static final LanguageCategoryCode MALAGASY = new LanguageCategoryCode(
			"Malagasy",
			"MALGSY",
			"The language of Malagasy.");
	public static final LanguageCategoryCode MALTESE = new LanguageCategoryCode(
			"Maltese",
			"MALTSE",
			"The language of Maltese.");
	public static final LanguageCategoryCode MANDINGO = new LanguageCategoryCode(
			"Mandingo",
			"MANDNG",
			"The language of Mandingo.");
	public static final LanguageCategoryCode MANDINKA = new LanguageCategoryCode(
			"Mandinka",
			"MANDNK",
			"The language of Mandinka.");
	public static final LanguageCategoryCode MANDARIN = new LanguageCategoryCode(
			"Mandarin",
			"MANDRN",
			"The language of Mandarin.");
	public static final LanguageCategoryCode MANX_GAELIC = new LanguageCategoryCode(
			"Manx gaelic",
			"MANXGL",
			"The language of Manx gaelic.");
	public static final LanguageCategoryCode MAORI = new LanguageCategoryCode(
			"Maori",
			"MAORI",
			"The language of Maori.");
	public static final LanguageCategoryCode MARATHI = new LanguageCategoryCode(
			"Marathi",
			"MARATH",
			"The language of Marathi.");
	public static final LanguageCategoryCode MARSHALLESE = new LanguageCategoryCode(
			"Marshallese",
			"MARSHL",
			"The language of Marshallese.");
	public static final LanguageCategoryCode MAYA = new LanguageCategoryCode(
			"Maya",
			"MAYA",
			"The language of Maya.");
	public static final LanguageCategoryCode MELANESIAN_PIDGIN = new LanguageCategoryCode(
			"Melanesian pidgin",
			"MELANP",
			"The language of Melanesian pidgin.");
	public static final LanguageCategoryCode MENDE = new LanguageCategoryCode(
			"Mende",
			"MENDE",
			"The language of Mende.");
	public static final LanguageCategoryCode MINA = new LanguageCategoryCode(
			"Mina",
			"MINA",
			"The language of Mina.");
	public static final LanguageCategoryCode MINBEI_FUZHOU = new LanguageCategoryCode(
			"Minbei (Fuzhou)",
			"MINBEI",
			"The language of Minbei (Fuzhou).");
	public static final LanguageCategoryCode MINNAN_HOKKIEN_TAIWANESE = new LanguageCategoryCode(
			"Minnan (Hokkien-taiwanese)",
			"MINNAN",
			"The language of Minnan (Hokkien-taiwanese).");
	public static final LanguageCategoryCode MOLDOVAN = new LanguageCategoryCode(
			"Moldovan",
			"MOLDVN",
			"The language of Moldovan.");
	public static final LanguageCategoryCode MONEGASGUE = new LanguageCategoryCode(
			"Monegasgue",
			"MONGSG",
			"The language of Monegasgue.");
	public static final LanguageCategoryCode MON_KHMER = new LanguageCategoryCode(
			"Mon-khmer",
			"MONKHM",
			"The language of Mon-khmer.");
	public static final LanguageCategoryCode MOROCCAN = new LanguageCategoryCode(
			"Moroccan",
			"MOROCN",
			"The language of Moroccan.");
	public static final LanguageCategoryCode MOTU = new LanguageCategoryCode(
			"Motu",
			"MOTU",
			"The language of Motu.");
	public static final LanguageCategoryCode MYENE = new LanguageCategoryCode(
			"Myene",
			"MYENE",
			"The language of Myene.");
	public static final LanguageCategoryCode NAHUA = new LanguageCategoryCode(
			"Nahua",
			"NAHUA",
			"The language of Nahua.");
	public static final LanguageCategoryCode NAPALESE = new LanguageCategoryCode(
			"Napalese",
			"NAPALS",
			"The language of Napalese.");
	public static final LanguageCategoryCode NAURAN = new LanguageCategoryCode(
			"Nauran",
			"NAURAN",
			"The language of Nauran.");
	public static final LanguageCategoryCode NEPALI = new LanguageCategoryCode(
			"Nepali",
			"NEPALI",
			"The language of Nepali.");
	public static final LanguageCategoryCode NIGER_CONGO = new LanguageCategoryCode(
			"Niger-congo",
			"NIGRCN",
			"The language of Niger-congo.");
	public static final LanguageCategoryCode NILOCI = new LanguageCategoryCode(
			"Niloci",
			"NILOCI",
			"The language of Niloci.");
	public static final LanguageCategoryCode NILO_HAMITIC = new LanguageCategoryCode(
			"Nilo-hamitic",
			"NILOHM",
			"The language of Nilo-hamitic.");
	public static final LanguageCategoryCode NILOTIC = new LanguageCategoryCode(
			"Nilotic",
			"NILOTC",
			"The language of Nilotic.");
	public static final LanguageCategoryCode NORA_BANA = new LanguageCategoryCode(
			"Nora-bana",
			"NORABN",
			"The language of Nora-bana.");
	public static final LanguageCategoryCode NORTH_SOTHO = new LanguageCategoryCode(
			"North sotho",
			"NORTHS",
			"The language of North sotho.");
	public static final LanguageCategoryCode NORWEGIAN = new LanguageCategoryCode(
			"Norwegian",
			"NORWGN",
			"The language of Norwegian.");
	public static final LanguageCategoryCode NOT_OTHERWISE_SPECIFIED = new LanguageCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final LanguageCategoryCode NUBIAN = new LanguageCategoryCode(
			"Nubian",
			"NUBIAN",
			"The language of Nubian.");
	public static final LanguageCategoryCode ORIYA = new LanguageCategoryCode(
			"Oriya",
			"ORIYA",
			"The language of Oriya.");
	public static final LanguageCategoryCode OROMINGA = new LanguageCategoryCode(
			"Orominga",
			"ORMNGA",
			"The language of Orominga.");
	public static final LanguageCategoryCode PALAUAN = new LanguageCategoryCode(
			"Palauan",
			"PALAUN",
			"The language of Palauan.");
	public static final LanguageCategoryCode PAPIAMENTO = new LanguageCategoryCode(
			"Papiamento",
			"PAPMNT",
			"The language of Papiamento.");
	public static final LanguageCategoryCode PASHAI = new LanguageCategoryCode(
			"Pashai",
			"PASHAI",
			"The language of Pashai.");
	public static final LanguageCategoryCode PASHTU = new LanguageCategoryCode(
			"Pashtu",
			"PASHTU",
			"The language of Pashtu.");
	public static final LanguageCategoryCode PERSIAN = new LanguageCategoryCode(
			"Persian",
			"PERSN",
			"The language of Persian.");
	public static final LanguageCategoryCode PERSIAN_DARI = new LanguageCategoryCode(
			"Persian (Dari)",
			"PERSND",
			"The language of Persian (Dari).");
	public static final LanguageCategoryCode PIDGIN_ENGLISH = new LanguageCategoryCode(
			"Pidgin english",
			"PIDGNE",
			"The language of Pidgin english.");
	public static final LanguageCategoryCode POHNPEIAN = new LanguageCategoryCode(
			"Pohnpeian",
			"POHNPN",
			"The language of Pohnpeian.");
	public static final LanguageCategoryCode POLISH = new LanguageCategoryCode(
			"Polish",
			"POLISH",
			"The language of Polish.");
	public static final LanguageCategoryCode POLYNESIAN = new LanguageCategoryCode(
			"Polynesian",
			"POLYNS",
			"The language of Polynesian.");
	public static final LanguageCategoryCode PORTUGUESE = new LanguageCategoryCode(
			"Portuguese",
			"PORTGS",
			"The language of Portuguese.");
	public static final LanguageCategoryCode PULAR = new LanguageCategoryCode(
			"Pular",
			"PULAR",
			"The language of Pular.");
	public static final LanguageCategoryCode PUNJABI = new LanguageCategoryCode(
			"Punjabi",
			"PUNJAB",
			"The language of Punjabi.");
	public static final LanguageCategoryCode QIECHUA = new LanguageCategoryCode(
			"Qiechua",
			"QIECHA",
			"The language of Qiechua.");
	public static final LanguageCategoryCode QUICHE = new LanguageCategoryCode(
			"Quiche",
			"QUICHE",
			"The language of Quiche.");
	public static final LanguageCategoryCode ROMANIAN = new LanguageCategoryCode(
			"Romanian",
			"ROMNAN",
			"The language of Romanian.");
	public static final LanguageCategoryCode ROMANSCH = new LanguageCategoryCode(
			"Romansch",
			"ROMNSC",
			"The language of Romansch.");
	public static final LanguageCategoryCode RUSSIAN = new LanguageCategoryCode(
			"Russian",
			"RUSSAN",
			"The language of Russian.");
	public static final LanguageCategoryCode SAMOAN = new LanguageCategoryCode(
			"Samoan",
			"SAMOAN",
			"The language of Samoan.");
	public static final LanguageCategoryCode SANGHO = new LanguageCategoryCode(
			"Sangho",
			"SANGHO",
			"The language of Sangho.");
	public static final LanguageCategoryCode SANSKRIT = new LanguageCategoryCode(
			"Sanskrit",
			"SANSKT",
			"The language of Sanskrit.");
	public static final LanguageCategoryCode SARA = new LanguageCategoryCode(
			"Sara",
			"SARA",
			"The language of Sara.");
	public static final LanguageCategoryCode SCOTTISH_GAELIC = new LanguageCategoryCode(
			"Scottish gaelic",
			"SCOTGA",
			"The language of Scottish gaelic.");
	public static final LanguageCategoryCode SERBO_CROATIAN = new LanguageCategoryCode(
			"Serbo-croatian",
			"SERBOC",
			"The language of Serbo-croatian.");
	public static final LanguageCategoryCode SESOTHO_SOUTH_SOTHO = new LanguageCategoryCode(
			"Sesotho (South sotho)",
			"SESTHS",
			"The language of Sesotho (South sotho).");
	public static final LanguageCategoryCode SETSWANA = new LanguageCategoryCode(
			"Setswana",
			"SETSWN",
			"The language of Setswana.");
	public static final LanguageCategoryCode SHONA = new LanguageCategoryCode(
			"Shona",
			"SHONA",
			"The language of Shona.");
	public static final LanguageCategoryCode SINDEBELE = new LanguageCategoryCode(
			"Sindebele",
			"SINDBL",
			"The language of Sindebele.");
	public static final LanguageCategoryCode SINDHI = new LanguageCategoryCode(
			"Sindhi",
			"SINDHI",
			"The language of Sindhi.");
	public static final LanguageCategoryCode SINHALA = new LanguageCategoryCode(
			"Sinhala",
			"SINHAL",
			"The language of Sinhala.");
	public static final LanguageCategoryCode SIWATI = new LanguageCategoryCode(
			"Siwati",
			"SIWATI",
			"The language of Siwati.");
	public static final LanguageCategoryCode SLOVAK = new LanguageCategoryCode(
			"Slovak",
			"SLOVAK",
			"The language of Slovak.");
	public static final LanguageCategoryCode SLOVENE = new LanguageCategoryCode(
			"Slovene",
			"SLOVNE",
			"The language of Slovene.");
	public static final LanguageCategoryCode SLOVENIAN = new LanguageCategoryCode(
			"Slovenian",
			"SLOVNN",
			"The language of Slovenian.");
	public static final LanguageCategoryCode SOMALI = new LanguageCategoryCode(
			"Somali",
			"SOMALI",
			"The language of Somali.");
	public static final LanguageCategoryCode SONINKE = new LanguageCategoryCode(
			"Soninke",
			"SONNKE",
			"The language of Soninke.");
	public static final LanguageCategoryCode SONSOROLESE = new LanguageCategoryCode(
			"Sonsorolese",
			"SONSRL",
			"The language of Sonsorolese.");
	public static final LanguageCategoryCode SPANISH = new LanguageCategoryCode(
			"Spanish",
			"SPANSH",
			"The language of Spanish.");
	public static final LanguageCategoryCode SPANISH_BASQUE = new LanguageCategoryCode(
			"Spanish (Basque)",
			"SPNBSQ",
			"The language of Spanish (Basque).");
	public static final LanguageCategoryCode SPANISH_CASTILIAN = new LanguageCategoryCode(
			"Spanish (Castilian)",
			"SPNCST",
			"The language of Spanish (Castilian).");
	public static final LanguageCategoryCode SPANISH_CATALAN = new LanguageCategoryCode(
			"Spanish (Catalan)",
			"SPNCTL",
			"The language of Spanish (Catalan).");
	public static final LanguageCategoryCode SPANISH_GALICIAN = new LanguageCategoryCode(
			"Spanish (Galician)",
			"SPNGLC",
			"The language of Spanish (Galician).");
	public static final LanguageCategoryCode SRANAN_TONGO = new LanguageCategoryCode(
			"Sranan tongo",
			"SRNNTN",
			"The language of Sranan tongo.");
	public static final LanguageCategoryCode SUDANIC = new LanguageCategoryCode(
			"Sudanic",
			"SUDANC",
			"The language of Sudanic.");
	public static final LanguageCategoryCode SURINAMESE = new LanguageCategoryCode(
			"Surinamese",
			"SURNMS",
			"The language of Surinamese.");
	public static final LanguageCategoryCode SWAHILI = new LanguageCategoryCode(
			"Swahili",
			"SWAHIL",
			"The language of Swahili.");
	public static final LanguageCategoryCode SWEDISH = new LanguageCategoryCode(
			"Swedish",
			"SWEDSH",
			"The language of Swedish.");
	public static final LanguageCategoryCode TA_BEDAWIE = new LanguageCategoryCode(
			"Ta bedawie",
			"TABEDW",
			"The language of Ta bedawie.");
	public static final LanguageCategoryCode TAHITIAN = new LanguageCategoryCode(
			"Tahitian",
			"TAHTAN",
			"The language of Tahitian.");
	public static final LanguageCategoryCode TAIWANESE = new LanguageCategoryCode(
			"Taiwanese",
			"TAIWNS",
			"The language of Taiwanese.");
	public static final LanguageCategoryCode TAJIK = new LanguageCategoryCode(
			"Tajik",
			"TAJIK",
			"The language of Tajik.");
	public static final LanguageCategoryCode TAKI_TAKI = new LanguageCategoryCode(
			"Taki-taki",
			"TAKITK",
			"The language of Taki-taki.");
	public static final LanguageCategoryCode TAMIL = new LanguageCategoryCode(
			"Tamil",
			"TAMIL",
			"The language of Tamil.");
	public static final LanguageCategoryCode TELUGU = new LanguageCategoryCode(
			"Telugu",
			"TELUGU",
			"The language of Telugu.");
	public static final LanguageCategoryCode TEMNE = new LanguageCategoryCode(
			"Temne",
			"TEMNE",
			"The language of Temne.");
	public static final LanguageCategoryCode THAI = new LanguageCategoryCode(
			"Thai",
			"THAI",
			"The language of Thai.");
	public static final LanguageCategoryCode TIGRE = new LanguageCategoryCode(
			"Tigre",
			"TIGRE",
			"The language of Tigre.");
	public static final LanguageCategoryCode TIGRINYA = new LanguageCategoryCode(
			"Tigrinya",
			"TIGRNY",
			"The language of Tigrinya.");
	public static final LanguageCategoryCode TOBI = new LanguageCategoryCode(
			"Tobi",
			"TOBI",
			"The language of Tobi.");
	public static final LanguageCategoryCode TOKELAUAN = new LanguageCategoryCode(
			"Tokelauan",
			"TOKELN",
			"The language of Tokelauan.");
	public static final LanguageCategoryCode TONGAN = new LanguageCategoryCode(
			"Tongan",
			"TONGAN",
			"The language of Tongan.");
	public static final LanguageCategoryCode TOSK = new LanguageCategoryCode(
			"Tosk",
			"TOSK",
			"The language of Tosk.");
	public static final LanguageCategoryCode TRUKESE = new LanguageCategoryCode(
			"Trukese",
			"TRUKES",
			"The language of Trukese.");
	public static final LanguageCategoryCode TSHILUBA = new LanguageCategoryCode(
			"Tshiluba",
			"TSHLUB",
			"The language of Tshiluba.");
	public static final LanguageCategoryCode TSWANA = new LanguageCategoryCode(
			"Tswana",
			"TSWANA",
			"The language of Tswana.");
	public static final LanguageCategoryCode TURKIC = new LanguageCategoryCode(
			"Turkic",
			"TURKIC",
			"The language of Turkic.");
	public static final LanguageCategoryCode TURKMEN = new LanguageCategoryCode(
			"Turkmen",
			"TURKMN",
			"The language of Turkmen.");
	public static final LanguageCategoryCode TURKISH = new LanguageCategoryCode(
			"Turkish",
			"TURKSH",
			"The language of Turkish.");
	public static final LanguageCategoryCode TUVALUAN = new LanguageCategoryCode(
			"Tuvaluan",
			"TUVALN",
			"The language of Tuvaluan.");
	public static final LanguageCategoryCode UKRAINIAN = new LanguageCategoryCode(
			"Ukrainian",
			"UKRANN",
			"The language of Ukrainian.");
	public static final LanguageCategoryCode URDU = new LanguageCategoryCode(
			"Urdu",
			"URDU",
			"The language of Urdu.");
	public static final LanguageCategoryCode UZBEK = new LanguageCategoryCode(
			"Uzbek",
			"UZBEK",
			"The language of Uzbek.");
	public static final LanguageCategoryCode VIETNAMESE = new LanguageCategoryCode(
			"Vietnamese",
			"VIETNM",
			"The language of Vietnamese.");
	public static final LanguageCategoryCode WALLISIAN = new LanguageCategoryCode(
			"Wallisian",
			"WALLSN",
			"The language of Wallisian.");
	public static final LanguageCategoryCode WELSH = new LanguageCategoryCode(
			"Welsh",
			"WELSH",
			"The language of Welsh.");
	public static final LanguageCategoryCode WOLOF = new LanguageCategoryCode(
			"Wolof",
			"WOLOF",
			"The language of Wolof.");
	public static final LanguageCategoryCode WU_SHANGHAINESE = new LanguageCategoryCode(
			"Wu (Shanghainese)",
			"WUSHNG",
			"The language of Wu (Shanghainese).");
	public static final LanguageCategoryCode XHOSA = new LanguageCategoryCode(
			"Xhosa",
			"XHOSA",
			"The language of Xhosa.");
	public static final LanguageCategoryCode XIANG = new LanguageCategoryCode(
			"Xiang",
			"XIANG",
			"The language of Xiang.");
	public static final LanguageCategoryCode YAPESE = new LanguageCategoryCode(
			"Yapese",
			"YAPESE",
			"The language of Yapese.");
	public static final LanguageCategoryCode YORUBA = new LanguageCategoryCode(
			"Yoruba",
			"YORUBA",
			"The language of Yoruba.");
	public static final LanguageCategoryCode YUE_CANTONESE = new LanguageCategoryCode(
			"Yue (Cantonese)",
			"YUECNT",
			"The language of Yue (Cantonese).");
	public static final LanguageCategoryCode ZULU = new LanguageCategoryCode(
			"Zulu",
			"ZULU",
			"The language of Zulu.");

	private LanguageCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
