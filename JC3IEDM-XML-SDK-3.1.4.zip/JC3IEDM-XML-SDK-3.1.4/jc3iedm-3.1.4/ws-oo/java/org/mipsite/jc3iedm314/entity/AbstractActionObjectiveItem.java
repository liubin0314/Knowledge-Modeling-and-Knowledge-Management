/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.code.*;

public abstract class AbstractActionObjectiveItem extends AbstractActionObjective {

	// private fields

	private ActionObjectiveItemPrimacyCode primacyCode; // optional
	private Ref<CandidateTargetDetailItem> candidateTargetDetailItem; // optional
	private Ref<AbstractObjectItem> objectItem; // mandatory
	private Set<Ref<ActionObjectiveItemMarking>> markingSet; // zero-one-or-more

	// default constructor

	public AbstractActionObjectiveItem() {
		this.markingSet = new HashSet<Ref<ActionObjectiveItemMarking>>();
	}

	// getter & setter methods

	public ActionObjectiveItemPrimacyCode getPrimacyCode() {
		return this.primacyCode;
	}

	public void setPrimacyCode(ActionObjectiveItemPrimacyCode primacyCode) {
		this.primacyCode = primacyCode;
	}

	public Ref<CandidateTargetDetailItem> getCandidateTargetDetailItem() {
		return this.candidateTargetDetailItem;
	}

	public void setCandidateTargetDetailItem(Ref<CandidateTargetDetailItem> candidateTargetDetailItem) {
		this.candidateTargetDetailItem = candidateTargetDetailItem;
	}

	public Ref<AbstractObjectItem> getObjectItem() {
		if (this.objectItem == null) {
			throw new NullValueException("AbstractActionObjectiveItem.objectItem");
		}
		return this.objectItem;
	}

	public void setObjectItem(Ref<AbstractObjectItem> objectItem) {
		this.objectItem = objectItem;
	}

	public Set<Ref<ActionObjectiveItemMarking>> getMarkingSet() {
		return this.markingSet;
	}

	public void addMarking(Ref<ActionObjectiveItemMarking> marking) {
		this.markingSet.add(marking);
	}
}
