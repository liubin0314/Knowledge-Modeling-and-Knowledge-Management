/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemHostilityStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the perceived hostility status of a specific OBJECT-ITEM.";
	}

	private static HashMap<String, ObjectItemHostilityStatusCode> physicalToCode = new HashMap<String, ObjectItemHostilityStatusCode>();

	public static ObjectItemHostilityStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemHostilityStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemHostilityStatusCode ASSUMED_FRIEND = new ObjectItemHostilityStatusCode(
			"Assumed friend",
			"AFR",
			"An OBJECT-ITEM that is assumed to be a friend because of its characteristics, behaviour or origin.");
	public static final ObjectItemHostilityStatusCode ASSUMED_HOSTILE = new ObjectItemHostilityStatusCode(
			"Assumed hostile",
			"AHO",
			"An indication that the OBJECT-ITEM in question is likely to belong to enemy forces.");
	public static final ObjectItemHostilityStatusCode ASSUMED_INVOLVED = new ObjectItemHostilityStatusCode(
			"Assumed involved",
			"AIV",
			"An indication that the OBJECT-ITEM in question is likely to belong to involved forces different from own, allied and enemy forces.");
	public static final ObjectItemHostilityStatusCode ASSUMED_NEUTRAL = new ObjectItemHostilityStatusCode(
			"Assumed neutral",
			"ANT",
			"An indication that the OBJECT-ITEM in question is likely to belong to neither own, allied, enemy or otherwise involved forces.");
	public static final ObjectItemHostilityStatusCode FAKER = new ObjectItemHostilityStatusCode(
			"Faker",
			"FAKER",
			"An OBJECT-ITEM that is a friendly aircraft simulating a hostile aircraft in an air defence exercise.");
	public static final ObjectItemHostilityStatusCode FRIEND = new ObjectItemHostilityStatusCode(
			"Friend",
			"FR",
			"An OBJECT-ITEM that belongs to a declared friendly nation.");
	public static final ObjectItemHostilityStatusCode HOSTILE = new ObjectItemHostilityStatusCode(
			"Hostile",
			"HO",
			"An OBJECT-ITEM that is positively identified as enemy.");
	public static final ObjectItemHostilityStatusCode INVOLVED = new ObjectItemHostilityStatusCode(
			"Involved",
			"IV",
			"An indication that the OBJECT-ITEM in question belongs to involved forces different from own, allied and enemy forces.");
	public static final ObjectItemHostilityStatusCode JOKER = new ObjectItemHostilityStatusCode(
			"Joker",
			"JOKER",
			"An OBJECT-ITEM that is acting as a suspect track for exercise purposes only.");
	public static final ObjectItemHostilityStatusCode NEUTRAL = new ObjectItemHostilityStatusCode(
			"Neutral",
			"NEUTRL",
			"An OBJECT-ITEM whose characteristics, behaviour, origin or nationality indicate that it is neither supporting friendly nor opposing forces.");
	public static final ObjectItemHostilityStatusCode PENDING = new ObjectItemHostilityStatusCode(
			"Pending",
			"PENDNG",
			"An OBJECT-ITEM for which identification is to be determined.");
	public static final ObjectItemHostilityStatusCode SUSPECT = new ObjectItemHostilityStatusCode(
			"Suspect",
			"SUSPCT",
			"An OBJECT-ITEM that is potentially hostile because of its characteristics, behaviour or origin.");
	public static final ObjectItemHostilityStatusCode UNKNOWN = new ObjectItemHostilityStatusCode(
			"Unknown",
			"UNK",
			"An OBJECT-ITEM for which its hostility status information is not available.");

	private ObjectItemHostilityStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
