/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AffiliationCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of AFFILIATION.";
	}

	private static HashMap<String, AffiliationCategoryCode> physicalToCode = new HashMap<String, AffiliationCategoryCode>();

	public static AffiliationCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AffiliationCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AffiliationCategoryCode AFFILIATION_GEOPOLITICAL = new AffiliationCategoryCode(
			"AFFILIATION-GEOPOLITICAL",
			"AFLGEO",
			"A specification of a country or political entity to which membership or allegiance may be ascribed.");
	public static final AffiliationCategoryCode AFFILIATION_ETHNIC_GROUP = new AffiliationCategoryCode(
			"AFFILIATION-ETHNIC-GROUP",
			"AFLETH",
			"A specification of an ethnic group to which membership or allegiance may be ascribed.");
	public static final AffiliationCategoryCode AFFILIATION_FUNCTIONAL_GROUP = new AffiliationCategoryCode(
			"AFFILIATION-FUNCTIONAL-GROUP",
			"AFLFNC",
			"A specification of a functional group characterised by its primary purpose to which membership or allegiance may be ascribed.");
	public static final AffiliationCategoryCode AFFILIATION_RELIGION = new AffiliationCategoryCode(
			"AFFILIATION-RELIGION",
			"AFLREL",
			"A specification of a religion to which membership or allegiance may be ascribed.");

	private AffiliationCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
