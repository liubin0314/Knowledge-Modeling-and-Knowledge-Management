/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class FacilityStatusSecurityStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the security status of a specific FACILITY.";
	}

	private static HashMap<String, FacilityStatusSecurityStatusCode> physicalToCode = new HashMap<String, FacilityStatusSecurityStatusCode>();

	public static FacilityStatusSecurityStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<FacilityStatusSecurityStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final FacilityStatusSecurityStatusCode GUARDED = new FacilityStatusSecurityStatusCode(
			"Guarded",
			"GUARDD",
			"The specific facility is being guarded so as to control entry or exit.");
	public static final FacilityStatusSecurityStatusCode NOT_KNOWN = new FacilityStatusSecurityStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final FacilityStatusSecurityStatusCode NONE = new FacilityStatusSecurityStatusCode(
			"None",
			"NONE",
			"No special action has been taken to guarantee the security of the specific facility.");
	public static final FacilityStatusSecurityStatusCode SECURED = new FacilityStatusSecurityStatusCode(
			"Secured",
			"SECURD",
			"The specific facility is protected or safe.");

	private FacilityStatusSecurityStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
