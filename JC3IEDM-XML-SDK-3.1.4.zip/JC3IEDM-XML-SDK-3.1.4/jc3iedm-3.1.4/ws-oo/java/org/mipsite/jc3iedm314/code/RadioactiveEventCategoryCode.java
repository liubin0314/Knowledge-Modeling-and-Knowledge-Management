/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RadioactiveEventCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of RADIOACTIVE-EVENT.";
	}

	private static HashMap<String, RadioactiveEventCategoryCode> physicalToCode = new HashMap<String, RadioactiveEventCategoryCode>();

	public static RadioactiveEventCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RadioactiveEventCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RadioactiveEventCategoryCode NOT_OTHERWISE_SPECIFIED = new RadioactiveEventCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RadioactiveEventCategoryCode NUCLEAR_EVENT = new RadioactiveEventCategoryCode(
			"NUCLEAR-EVENT",
			"NUCEVT",
			"A RADIOACTIVE-EVENT involving nuclear materiel and/or nuclear detonation.");
	public static final RadioactiveEventCategoryCode RADIATION_ALARM = new RadioactiveEventCategoryCode(
			"Radiation alarm",
			"RADALM",
			"An action by which a radiological detector is triggered or a group is warned.");
	public static final RadioactiveEventCategoryCode RADIOLOGICAL_EVENT = new RadioactiveEventCategoryCode(
			"RADIOLOGICAL-EVENT",
			"RADEVT",
			"A RADIOACTIVE-EVENT involving radioactive materiel(s) but not involving nuclear materiel(s) and/or nuclear detonation.");

	private RadioactiveEventCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
