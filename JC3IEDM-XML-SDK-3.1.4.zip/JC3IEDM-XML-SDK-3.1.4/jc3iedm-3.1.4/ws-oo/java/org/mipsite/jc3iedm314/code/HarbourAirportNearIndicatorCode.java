/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourAirportNearIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether an airport is near the HARBOUR.";
	}

	private static HashMap<String, HarbourAirportNearIndicatorCode> physicalToCode = new HashMap<String, HarbourAirportNearIndicatorCode>();

	public static HarbourAirportNearIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourAirportNearIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourAirportNearIndicatorCode NO = new HarbourAirportNearIndicatorCode(
			"No",
			"NO",
			"No airport is near the harbour.");
	public static final HarbourAirportNearIndicatorCode YES = new HarbourAirportNearIndicatorCode(
			"Yes",
			"YES",
			"An airport is near the harbour.");

	private HarbourAirportNearIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
