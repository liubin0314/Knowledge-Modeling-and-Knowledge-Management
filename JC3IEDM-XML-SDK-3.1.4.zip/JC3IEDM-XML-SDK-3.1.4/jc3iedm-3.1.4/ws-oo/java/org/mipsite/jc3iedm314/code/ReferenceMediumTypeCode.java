/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ReferenceMediumTypeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of medium of the artefact cited in a specific REFERENCE.";
	}

	private static HashMap<String, ReferenceMediumTypeCode> physicalToCode = new HashMap<String, ReferenceMediumTypeCode>();

	public static ReferenceMediumTypeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ReferenceMediumTypeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ReferenceMediumTypeCode ELECTRONIC_FILE_DETACHED_PHYSICAL_STORAGE = new ReferenceMediumTypeCode(
			"Electronic file, detached physical storage",
			"ELCFLD",
			"The artefact cited in the specific REFERENCE is available as an electronic file on a discrete physical storage device (e.g., CD, DVD, USB stick, etc.).");
	public static final ReferenceMediumTypeCode ELECTRONIC_FILE_NETWORK = new ReferenceMediumTypeCode(
			"Electronic file, network",
			"ELCFLN",
			"The artefact cited in the specific REFERENCE is available as an electronic file on a network device.");
	public static final ReferenceMediumTypeCode FILM = new ReferenceMediumTypeCode(
			"Film",
			"FILM",
			"The artefact cited in the specific REFERENCE is available on negative or positive film.");
	public static final ReferenceMediumTypeCode MAGNETIC_TAPE = new ReferenceMediumTypeCode(
			"Magnetic tape",
			"MAGTPE",
			"The artefact cited in the specific REFERENCE is available as a magnetic recording containing audio, data, or video.");
	public static final ReferenceMediumTypeCode NOT_KNOWN = new ReferenceMediumTypeCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ReferenceMediumTypeCode NOT_OTHERWISE_SPECIFIED = new ReferenceMediumTypeCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ReferenceMediumTypeCode PAPER_BASED = new ReferenceMediumTypeCode(
			"Paper-based",
			"PAPERB",
			"The artefact cited in the specific REFERENCE is available as text or imagery printed on paper.");

	private ReferenceMediumTypeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
