/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionReconnaissanceEmploymentImageCoverageModeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the mode of image coverage required.";
	}

	private static HashMap<String, ActionReconnaissanceEmploymentImageCoverageModeCode> physicalToCode = new HashMap<String, ActionReconnaissanceEmploymentImageCoverageModeCode>();

	public static ActionReconnaissanceEmploymentImageCoverageModeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionReconnaissanceEmploymentImageCoverageModeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionReconnaissanceEmploymentImageCoverageModeCode MONO_MODE_COMPLETE_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Mono mode/complete coverage",
			"MONOCC",
			"Complete imagery coverage in mono mode.");
	public static final ActionReconnaissanceEmploymentImageCoverageModeCode MONO_MODE_PARTIAL_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Mono mode/partial coverage",
			"MONOPC",
			"Partial imagery coverage in mono mode.");
	public static final ActionReconnaissanceEmploymentImageCoverageModeCode PARTIAL_STEREO_MODE_COMPLETE_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Partial stereo mode/complete coverage",
			"PSMCC",
			"Complete imagery coverage in partial stereo mode.");
	public static final ActionReconnaissanceEmploymentImageCoverageModeCode PARTIAL_STEREO_MODE_PARTIAL_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Partial stereo mode/partial coverage",
			"PSMPC",
			"Partial imagery coverage in partial stereo mode.");
	public static final ActionReconnaissanceEmploymentImageCoverageModeCode STEREO_MODE_COMPLETE_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Stereo mode/complete coverage",
			"STMCC",
			"Complete imagery coverage in stereo mode.");
	public static final ActionReconnaissanceEmploymentImageCoverageModeCode STEREO_MODE_PARTIAL_COVERAGE = new ActionReconnaissanceEmploymentImageCoverageModeCode(
			"Stereo mode/partial coverage",
			"STMPC",
			"Partial imagery coverage in stereo mode.");

	private ActionReconnaissanceEmploymentImageCoverageModeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
