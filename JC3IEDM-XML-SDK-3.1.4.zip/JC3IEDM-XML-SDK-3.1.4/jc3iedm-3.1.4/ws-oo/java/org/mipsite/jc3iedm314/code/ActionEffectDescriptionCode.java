/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionEffectDescriptionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the type of outcome of a specific ACTION that is being estimated or recorded.";
	}

	private static HashMap<String, ActionEffectDescriptionCode> physicalToCode = new HashMap<String, ActionEffectDescriptionCode>();

	public static ActionEffectDescriptionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionEffectDescriptionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionEffectDescriptionCode BURNING = new ActionEffectDescriptionCode(
			"Burning",
			"BURN",
			"The ACTION objective is alight.");
	public static final ActionEffectDescriptionCode CAPTURED = new ActionEffectDescriptionCode(
			"Captured",
			"CAPTRD",
			"The ACTION objective has been captured or acquired and is available for use or interrogation/possession has been taken of an area, normally by force.");
	public static final ActionEffectDescriptionCode CONSUMED = new ActionEffectDescriptionCode(
			"Consumed",
			"CONS",
			"The consumption of specified consumables or CONSUMABLE-MATERIEL-TYPEs.");
	public static final ActionEffectDescriptionCode DESTROYED_K_KILL = new ActionEffectDescriptionCode(
			"Destroyed (K-kill)",
			"DSTRYK",
			"Cannot function as intended nor be repaired or restored to an operational status.");
	public static final ActionEffectDescriptionCode FIREPOWER_KILL_F_KILL = new ActionEffectDescriptionCode(
			"Firepower kill (F-kill)",
			"FKIL",
			"The destruction of a vehicle (or system's) primary weapon system.");
	public static final ActionEffectDescriptionCode FORCED_TO_FLEE = new ActionEffectDescriptionCode(
			"Forced to flee",
			"FLIG",
			"The setting to flight of a PERSON or PERSON-TYPEs from their present location.");
	public static final ActionEffectDescriptionCode IDENTIFIED = new ActionEffectDescriptionCode(
			"Identified",
			"IDNT",
			"The ACTION objective has been either identified (i.e., classified as friend/foe/neutral) or recognised (i.e., the unit designation of the ORGANISATION or object is known).");
	public static final ActionEffectDescriptionCode ILLUMINATED = new ActionEffectDescriptionCode(
			"Illuminated",
			"ILLUMN",
			"The temporary supply of IR or white-light illumination (usually in coordination with direct or indirect fire).");
	public static final ActionEffectDescriptionCode INTACT_BUT_UNRECOVERABLE = new ActionEffectDescriptionCode(
			"Intact but unrecoverable",
			"INTREC",
			"An equipment lost in an area unsuitable for recovery due to political, military or geographic/environmental considerations.");
	public static final ActionEffectDescriptionCode KILLED = new ActionEffectDescriptionCode(
			"Killed",
			"KILL",
			"A casualty who is killed outright or dies as a result of wounds, disease or other injuries.");
	public static final ActionEffectDescriptionCode LIGHT_DAMAGE = new ActionEffectDescriptionCode(
			"Light damage",
			"LDAM",
			"The subjective categorisation of the physical effect of an ACTION on buildings, infrastructure and/or equipment by a reporting ORGANISATION.");
	public static final ActionEffectDescriptionCode LIGHT_RESISTANCE = new ActionEffectDescriptionCode(
			"Light resistance",
			"LGTRST",
			"The ACTION-OBJECTIVE reacted against the ACTION using light physical violence.");
	public static final ActionEffectDescriptionCode LOST = new ActionEffectDescriptionCode(
			"Lost",
			"LOST",
			"The object is no longer available for military operations.");
	public static final ActionEffectDescriptionCode MOBILITY_KILL_M_KILL = new ActionEffectDescriptionCode(
			"Mobility kill (M-kill)",
			"MKIL",
			"The rendering of a vehicle as being temporarily or permanently incapable of tactical movement.");
	public static final ActionEffectDescriptionCode MODERATE_DAMAGE = new ActionEffectDescriptionCode(
			"Moderate damage",
			"MODDAM",
			"The subjective categorisation of the physical effect of an ACTION on buildings, infrastructure and/or equipment by a reporting ORGANISATION.");
	public static final ActionEffectDescriptionCode NON_BATTLE_CASUALTY = new ActionEffectDescriptionCode(
			"Non-battle casualty",
			"NBCAS",
			"A person who is not a battle casualty, but who is lost to his organisation by reason of disease or injury, including persons dying from disease or injury, or by reason of being missing where the absence does not appear to be voluntary or due to enemy action or to being interned.");
	public static final ActionEffectDescriptionCode NOT_KNOWN = new ActionEffectDescriptionCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionEffectDescriptionCode NO_RESISTANCE = new ActionEffectDescriptionCode(
			"No resistance",
			"NORSTN",
			"The ACTION-OBJECTIVE did not react against the ACTION.");
	public static final ActionEffectDescriptionCode NOT_OTHERWISE_SPECIFIED = new ActionEffectDescriptionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionEffectDescriptionCode NEUTRALIZED = new ActionEffectDescriptionCode(
			"Neutralized",
			"NUTRLD",
			"The rendering of the ACTION objective temporarily ineffective by the infliction of significant casualties (norm for indirect fire is 10 percent).");
	public static final ActionEffectDescriptionCode SEVERE_DAMAGE = new ActionEffectDescriptionCode(
			"Severe damage",
			"SDAM",
			"The subjective categorisation of the physical effect of an ACTION on buildings, infrastructure and/or equipment by a reporting ORGANISATION.");
	public static final ActionEffectDescriptionCode SUPPRESSED = new ActionEffectDescriptionCode(
			"Suppressed",
			"SUPRSD",
			"Reduction of the effectiveness of the ACTION objective for a specific period or purpose (normally to prevent an enemy from interfering with friendly ACTIONs); this effect may be entirely transitory and cause no casualties.");
	public static final ActionEffectDescriptionCode VIOLENT_RESISTANCE = new ActionEffectDescriptionCode(
			"Violent resistance",
			"VLNRST",
			"The ACTION-OBJECTIVE reacted against the ACTION using heavy physical violence.");
	public static final ActionEffectDescriptionCode VERBAL_PROTEST = new ActionEffectDescriptionCode(
			"Verbal protest",
			"VRBPRT",
			"The ACTION-OBJECTIVE reacted against the ACTION using verbal abuse.");
	public static final ActionEffectDescriptionCode WOUNDED = new ActionEffectDescriptionCode(
			"Wounded",
			"WNDD",
			"A casualty other than \"killed\" who has incurred an injury due to an external agent or cause.");

	private ActionEffectDescriptionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
