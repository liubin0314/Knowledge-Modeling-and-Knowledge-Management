/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;

import java.util.Set;
import java.util.HashSet;
import org.mipsite.xml.processing.*;
import org.mipsite.xml.processing.OIDType;
import org.mipsite.xml.processing.exception.*;
import org.mipsite.jc3iedm314.simple.*;

public abstract class AbstractAction extends Entity {

	// private fields

	private OIDType oID; // mandatory
	private OIDType creatorId; // mandatory
	private UpdateSeqnrType15 updateSequenceNo; // optional
	private TextTypeVar50 nameText; // optional
	private Set<Ref<ActionContext>> actionContextSet; // zero-one-or-more
	private Set<Ref<ActionFunctionalAssociation>> actionFunctionalAssociationInObjectSet; // zero-one-or-more
	private Set<Ref<ActionFunctionalAssociation>> actionFunctionalAssociationInSubjectSet; // zero-one-or-more
	private Set<Ref<ActionLocation>> actionLocationSet; // zero-one-or-more
	private Set<Ref<ActionReferenceAssociation>> actionReferenceAssociationSet; // zero-one-or-more
	private Set<Ref<ActionRequiredCapability>> actionRequiredCapabilitySet; // zero-one-or-more
	private Set<Ref<ActionTemporalAssociation>> actionTemporalAssociationInObjectSet; // zero-one-or-more
	private Set<Ref<ActionTemporalAssociation>> actionTemporalAssociationInSubjectSet; // zero-one-or-more
	private Set<Ref<ActionComment>> commentSet; // zero-one-or-more
	private Set<Ref<AbstractActionEffect>> effectSet; // zero-one-or-more
	private Set<Ref<AbstractActionObjective>> objectiveSet; // zero-one-or-more
	private Set<Ref<OrganisationActionAssociation>> organisationActionAssociationSet; // zero-one-or-more
	private Set<Ref<AbstractActionResource>> resourceSet; // zero-one-or-more

	// default constructor

	public AbstractAction() {
		this.actionContextSet = new HashSet<Ref<ActionContext>>();
		this.actionFunctionalAssociationInObjectSet = new HashSet<Ref<ActionFunctionalAssociation>>();
		this.actionFunctionalAssociationInSubjectSet = new HashSet<Ref<ActionFunctionalAssociation>>();
		this.actionLocationSet = new HashSet<Ref<ActionLocation>>();
		this.actionReferenceAssociationSet = new HashSet<Ref<ActionReferenceAssociation>>();
		this.actionRequiredCapabilitySet = new HashSet<Ref<ActionRequiredCapability>>();
		this.actionTemporalAssociationInObjectSet = new HashSet<Ref<ActionTemporalAssociation>>();
		this.actionTemporalAssociationInSubjectSet = new HashSet<Ref<ActionTemporalAssociation>>();
		this.commentSet = new HashSet<Ref<ActionComment>>();
		this.effectSet = new HashSet<Ref<AbstractActionEffect>>();
		this.objectiveSet = new HashSet<Ref<AbstractActionObjective>>();
		this.organisationActionAssociationSet = new HashSet<Ref<OrganisationActionAssociation>>();
		this.resourceSet = new HashSet<Ref<AbstractActionResource>>();
	}

	// getter & setter methods

	@Override
	public OIDType getOID() {
		if (this.oID == null) {
			throw new NullValueException("AbstractAction.oID");
		}
		return this.oID;
	}

	public void setOID(OIDType oID) {
		this.oID = oID;
	}

	public OIDType getCreatorId() {
		if (this.creatorId == null) {
			throw new NullValueException("AbstractAction.creatorId");
		}
		return this.creatorId;
	}

	public void setCreatorId(OIDType creatorId) {
		this.creatorId = creatorId;
	}

	public UpdateSeqnrType15 getUpdateSequenceNo() {
		return this.updateSequenceNo;
	}

	public void setUpdateSequenceNo(UpdateSeqnrType15 updateSequenceNo) {
		this.updateSequenceNo = updateSequenceNo;
	}

	public TextTypeVar50 getNameText() {
		return this.nameText;
	}

	public void setNameText(TextTypeVar50 nameText) {
		this.nameText = nameText;
	}

	public Set<Ref<ActionContext>> getActionContextSet() {
		return this.actionContextSet;
	}

	public void addActionContext(Ref<ActionContext> actionContext) {
		this.actionContextSet.add(actionContext);
	}

	public Set<Ref<ActionFunctionalAssociation>> getActionFunctionalAssociationInObjectSet() {
		return this.actionFunctionalAssociationInObjectSet;
	}

	public void addActionFunctionalAssociationInObject(Ref<ActionFunctionalAssociation> actionFunctionalAssociationInObject) {
		this.actionFunctionalAssociationInObjectSet.add(actionFunctionalAssociationInObject);
	}

	public Set<Ref<ActionFunctionalAssociation>> getActionFunctionalAssociationInSubjectSet() {
		return this.actionFunctionalAssociationInSubjectSet;
	}

	public void addActionFunctionalAssociationInSubject(Ref<ActionFunctionalAssociation> actionFunctionalAssociationInSubject) {
		this.actionFunctionalAssociationInSubjectSet.add(actionFunctionalAssociationInSubject);
	}

	public Set<Ref<ActionLocation>> getActionLocationSet() {
		return this.actionLocationSet;
	}

	public void addActionLocation(Ref<ActionLocation> actionLocation) {
		this.actionLocationSet.add(actionLocation);
	}

	public Set<Ref<ActionReferenceAssociation>> getActionReferenceAssociationSet() {
		return this.actionReferenceAssociationSet;
	}

	public void addActionReferenceAssociation(Ref<ActionReferenceAssociation> actionReferenceAssociation) {
		this.actionReferenceAssociationSet.add(actionReferenceAssociation);
	}

	public Set<Ref<ActionRequiredCapability>> getActionRequiredCapabilitySet() {
		return this.actionRequiredCapabilitySet;
	}

	public void addActionRequiredCapability(Ref<ActionRequiredCapability> actionRequiredCapability) {
		this.actionRequiredCapabilitySet.add(actionRequiredCapability);
	}

	public Set<Ref<ActionTemporalAssociation>> getActionTemporalAssociationInObjectSet() {
		return this.actionTemporalAssociationInObjectSet;
	}

	public void addActionTemporalAssociationInObject(Ref<ActionTemporalAssociation> actionTemporalAssociationInObject) {
		this.actionTemporalAssociationInObjectSet.add(actionTemporalAssociationInObject);
	}

	public Set<Ref<ActionTemporalAssociation>> getActionTemporalAssociationInSubjectSet() {
		return this.actionTemporalAssociationInSubjectSet;
	}

	public void addActionTemporalAssociationInSubject(Ref<ActionTemporalAssociation> actionTemporalAssociationInSubject) {
		this.actionTemporalAssociationInSubjectSet.add(actionTemporalAssociationInSubject);
	}

	public Set<Ref<ActionComment>> getCommentSet() {
		return this.commentSet;
	}

	public void addComment(Ref<ActionComment> comment) {
		this.commentSet.add(comment);
	}

	public Set<Ref<AbstractActionEffect>> getEffectSet() {
		return this.effectSet;
	}

	public void addEffect(Ref<AbstractActionEffect> effect) {
		this.effectSet.add(effect);
	}

	public Set<Ref<AbstractActionObjective>> getObjectiveSet() {
		return this.objectiveSet;
	}

	public void addObjective(Ref<AbstractActionObjective> objective) {
		this.objectiveSet.add(objective);
	}

	public Set<Ref<OrganisationActionAssociation>> getOrganisationActionAssociationSet() {
		return this.organisationActionAssociationSet;
	}

	public void addOrganisationActionAssociation(Ref<OrganisationActionAssociation> organisationActionAssociation) {
		this.organisationActionAssociationSet.add(organisationActionAssociation);
	}

	public Set<Ref<AbstractActionResource>> getResourceSet() {
		return this.resourceSet;
	}

	public void addResource(Ref<AbstractActionResource> resource) {
		this.resourceSet.add(resource);
	}
}
