/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailwayTrackGaugeCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the distance between the internal sides of rails on a RAILWAY line.";
	}

	private static HashMap<String, RailwayTrackGaugeCode> physicalToCode = new HashMap<String, RailwayTrackGaugeCode>();

	public static RailwayTrackGaugeCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailwayTrackGaugeCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailwayTrackGaugeCode NARROW = new RailwayTrackGaugeCode(
			"Narrow",
			"NAR",
			"The RAILWAY has a narrow track gauge (3' 5 3/8\").");
	public static final RailwayTrackGaugeCode STANDARD = new RailwayTrackGaugeCode(
			"Standard",
			"STD",
			"The RAILWAY has a standard track gauge (4' 8 1/2\").");

	private RailwayTrackGaugeCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
