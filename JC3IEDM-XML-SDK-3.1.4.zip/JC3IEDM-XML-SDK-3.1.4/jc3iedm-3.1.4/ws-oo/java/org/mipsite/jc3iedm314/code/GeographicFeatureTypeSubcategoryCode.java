/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureTypeSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the detailed class of GEOGRAPHIC-FEATURE-TYPE.";
	}

	private static HashMap<String, GeographicFeatureTypeSubcategoryCode> physicalToCode = new HashMap<String, GeographicFeatureTypeSubcategoryCode>();

	public static GeographicFeatureTypeSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureTypeSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureTypeSubcategoryCode BACKSHORE = new GeographicFeatureTypeSubcategoryCode(
			"Backshore",
			"BCKSHR",
			"Area between the normal limit of wave action above either Mean High Water Springs (MHWS) or Mean High High Water (MHHW) as defined by the National Authority and the maximum limit of wave action.");
	public static final GeographicFeatureTypeSubcategoryCode BEACH = new GeographicFeatureTypeSubcategoryCode(
			"Beach",
			"BEACH",
			"The shore of the sea or lake, sandy or pebbly, brought up by the waves (including the foreshore area).");
	public static final GeographicFeatureTypeSubcategoryCode BLUFF_CLIFF_ESCARPMENT = new GeographicFeatureTypeSubcategoryCode(
			"Bluff/cliff/escarpment",
			"BLUFF",
			"A steep, vertical, or overhanging face of rock or earth.");
	public static final GeographicFeatureTypeSubcategoryCode BOG = new GeographicFeatureTypeSubcategoryCode(
			"Bog",
			"BOG",
			"A poorly drained or periodically flooded area, excluding tidal waters, with soil rich in plant residue.");
	public static final GeographicFeatureTypeSubcategoryCode CAVE = new GeographicFeatureTypeSubcategoryCode(
			"Cave",
			"CAVE",
			"A natural subterranean chamber or series of chambers open to the Earth�s surface.");
	public static final GeographicFeatureTypeSubcategoryCode CAY = new GeographicFeatureTypeSubcategoryCode(
			"Cay",
			"CAY",
			"A small insular feature, which may contain scant vegetation; usually composed of sand or coral. Often applied to smaller coral shoals.");
	public static final GeographicFeatureTypeSubcategoryCode CHANNEL = new GeographicFeatureTypeSubcategoryCode(
			"Channel",
			"CHANEL",
			"That part of a body of water, sometimes dredged, deep enough for navigation through an area otherwise not navigable. It is usually marked by a single or double line of navigational aids.");
	public static final GeographicFeatureTypeSubcategoryCode CREVICE_CREVASSE = new GeographicFeatureTypeSubcategoryCode(
			"Crevice/crevasse",
			"CRVCEC",
			"A narrow fissure, crack, or rift in the Earth�s surface, snow or ice.");
	public static final GeographicFeatureTypeSubcategoryCode COASTLINE = new GeographicFeatureTypeSubcategoryCode(
			"Coastline",
			"CSTLNE",
			"A line generally following the contact between a land mass and a body of water, based on the low water line, and used as a reference for measuring international boundaries such as Territorial Limits or Exclusive Economic Zone (EEZ).");
	public static final GeographicFeatureTypeSubcategoryCode CUT = new GeographicFeatureTypeSubcategoryCode(
			"Cut",
			"CUT",
			"An excavation of the Earth�s surface to provide passage for a road, railroad, canal, etc.");
	public static final GeographicFeatureTypeSubcategoryCode DEPRESSION = new GeographicFeatureTypeSubcategoryCode(
			"Depression",
			"DPRSSN",
			"A low area surrounded by higher ground.");
	public static final GeographicFeatureTypeSubcategoryCode DRY_GAP = new GeographicFeatureTypeSubcategoryCode(
			"Dry gap",
			"DRYGAP",
			"A waterless ravine or mountain pass.");
	public static final GeographicFeatureTypeSubcategoryCode EMBANKMENT_FILL = new GeographicFeatureTypeSubcategoryCode(
			"Embankment/fill",
			"EMBANK",
			"A raised long mound of earth or other material.");
	public static final GeographicFeatureTypeSubcategoryCode ESKER = new GeographicFeatureTypeSubcategoryCode(
			"Esker",
			"ESKER",
			"A long, narrow ridge of sand and gravel deposited by a glacial stream.");
	public static final GeographicFeatureTypeSubcategoryCode FAN = new GeographicFeatureTypeSubcategoryCode(
			"Fan",
			"FAN",
			"A gently sloping fan shaped feature usually found near the lower termination of a canyon.");
	public static final GeographicFeatureTypeSubcategoryCode FAULT = new GeographicFeatureTypeSubcategoryCode(
			"Fault",
			"FAULT",
			"A fracture in the Earth�s crust with displacement on one side of the fracture relative to the other.");
	public static final GeographicFeatureTypeSubcategoryCode FLOODED_AREA = new GeographicFeatureTypeSubcategoryCode(
			"Flooded area",
			"FLDDAR",
			"Land subject to controlled inundation (i.e. flooded by the regulation of the level of water impounded by a dam or beaver dam), and is normally associated with permanently flooded areas in which trees are still standing. Also known as inundated land.");
	public static final GeographicFeatureTypeSubcategoryCode FLUME = new GeographicFeatureTypeSubcategoryCode(
			"Flume",
			"FLUME",
			"An open, inclined channel which carries water for use in such operations as mining or logging.");
	public static final GeographicFeatureTypeSubcategoryCode FORD = new GeographicFeatureTypeSubcategoryCode(
			"Ford",
			"FORD",
			"A shallow part of a body of water that can be crossed without bridging, boats, or rafts. A location in a water barrier where the physical characteristics of current, bottom, and approaches permit the passage of personnel and/or vehicles and other equipment that remain in contact with the bottom.");
	public static final GeographicFeatureTypeSubcategoryCode FORESHORE = new GeographicFeatureTypeSubcategoryCode(
			"Foreshore",
			"FRESHR",
			"Area between the low water line defined by Mean Low Water Springs (MLWS) or Mean Low Low Water (MLLW) as appropriate and the normal limit of wave action above Mean High Water Springs (MHWS) or Mean High High Water (MHHW) as appropriate.");
	public static final GeographicFeatureTypeSubcategoryCode GEOTHERMAL_FEATURE = new GeographicFeatureTypeSubcategoryCode(
			"Geothermal feature",
			"GEOTHR",
			"A terrain surface feature controlled by or derived from the heat of the Earth�s interior.");
	public static final GeographicFeatureTypeSubcategoryCode GLACIER = new GeographicFeatureTypeSubcategoryCode(
			"Glacier",
			"GLACER",
			"A large mass of snow and ice moving slowly down a slope or valley from above the snowline.");
	public static final GeographicFeatureTypeSubcategoryCode GULLY_GORGE = new GeographicFeatureTypeSubcategoryCode(
			"Gully/gorge",
			"GULLY",
			"A long, narrow, deep erosion with steep banks.");
	public static final GeographicFeatureTypeSubcategoryCode HILL = new GeographicFeatureTypeSubcategoryCode(
			"Hill",
			"HILL",
			"A small, isolated elevation, smaller than a mountain.");
	public static final GeographicFeatureTypeSubcategoryCode HARBOUR_NATURAL = new GeographicFeatureTypeSubcategoryCode(
			"Harbour, natural",
			"HRBRNT",
			"A place of shelter for ships; where they may lie close to and sheltered by the shore or by works extended from it.");
	public static final GeographicFeatureTypeSubcategoryCode HUMMOCK = new GeographicFeatureTypeSubcategoryCode(
			"Hummock",
			"HUMOCK",
			"An area of higher elevation within a swamp, bog, or marsh.");
	public static final GeographicFeatureTypeSubcategoryCode ICE_CLIFF = new GeographicFeatureTypeSubcategoryCode(
			"Ice cliff",
			"ICECLF",
			"The vertical face of a glacier or ice shelf.");
	public static final GeographicFeatureTypeSubcategoryCode ICE_PEAK_NUNATAK = new GeographicFeatureTypeSubcategoryCode(
			"Ice peak/nunatak",
			"ICEPKN",
			"A rocky peak projecting above a surrounding ice field that may be perpetually covered with ice.");
	public static final GeographicFeatureTypeSubcategoryCode ICE_SHELF = new GeographicFeatureTypeSubcategoryCode(
			"Ice shelf",
			"ICESHL",
			"A sheet of thick ice, with level or undulating surface, attached to the land but mostly afloat which is bounded on the seaward side by an Ice Cliff.");
	public static final GeographicFeatureTypeSubcategoryCode INLAND_SHORELINE = new GeographicFeatureTypeSubcategoryCode(
			"Inland shoreline",
			"INLNDS",
			"The land-water boundary for all inland hydrographic features having shorelines, Lake /Pond, or Island.");
	public static final GeographicFeatureTypeSubcategoryCode ISLAND = new GeographicFeatureTypeSubcategoryCode(
			"Island",
			"ISLAND",
			"A land mass smaller than a continent and surrounded by water.");
	public static final GeographicFeatureTypeSubcategoryCode LAGOON_REEF_POOL = new GeographicFeatureTypeSubcategoryCode(
			"Lagoon/reef pool",
			"LAGOON",
			"Open body of water separated from the sea by a sand bank or coral reef.");
	public static final GeographicFeatureTypeSubcategoryCode LEDGE = new GeographicFeatureTypeSubcategoryCode(
			"Ledge",
			"LEDGE",
			"A narrow, flat surface or shelf, especially one that projects, as from a wall of rock.");
	public static final GeographicFeatureTypeSubcategoryCode LAKE_POND = new GeographicFeatureTypeSubcategoryCode(
			"Lake/pond",
			"LKEPND",
			"A body of water surrounded by land.");
	public static final GeographicFeatureTypeSubcategoryCode LAND_SUBJECT_TO_INUNDATION = new GeographicFeatureTypeSubcategoryCode(
			"Land subject to inundation",
			"LNDSBJ",
			"An area periodically covered by flood water, excluding tidal waters.");
	public static final GeographicFeatureTypeSubcategoryCode LANDSLIDE_SCREE = new GeographicFeatureTypeSubcategoryCode(
			"Landslide/scree",
			"LNDSLD",
			"A mass of land, with a high potential of slipping down from a mountain, hill, etc.");
	public static final GeographicFeatureTypeSubcategoryCode LARGE_ISOLATED_ROCK_BOULDER_OR_ROCKY_FORMATION = new GeographicFeatureTypeSubcategoryCode(
			"Large isolated rock, boulder, or rocky formation",
			"LRGRCK",
			"A conspicuous isolated rocky formation or single large stone existing in its entirety above the high water mark. From offshore it would appear to a mariner as a single point on land and would be appropriate for use in navigation.");
	public static final GeographicFeatureTypeSubcategoryCode MARSH = new GeographicFeatureTypeSubcategoryCode(
			"Marsh",
			"MARSH",
			"An area of wet, often spongy ground that is subject to frequent or tidal inundations, but not considered to be continually under water.");
	public static final GeographicFeatureTypeSubcategoryCode MOUNTAIN_PASS = new GeographicFeatureTypeSubcategoryCode(
			"Mountain pass",
			"MNTPSS",
			"A natural route through a low place in a mountain range.");
	public static final GeographicFeatureTypeSubcategoryCode MORAINE = new GeographicFeatureTypeSubcategoryCode(
			"Moraine",
			"MORANE",
			"An accumulation of soil and stone debris deposited by a glacier.");
	public static final GeographicFeatureTypeSubcategoryCode MOUNTAIN = new GeographicFeatureTypeSubcategoryCode(
			"Mountain",
			"MOUNTN",
			"A natural elevation of the earth's surface rising more or less abruptly from the surrounding level, and attaining an altitude which, relatively to adjacent elevations, is impressive or notable.");
	public static final GeographicFeatureTypeSubcategoryCode NEARSHORE = new GeographicFeatureTypeSubcategoryCode(
			"Nearshore",
			"NRSHRE",
			"Area between the 10 meter depth curve and the low water line defined by either Mean Low Water Springs (MLWS) or Mean Low Low Water (MLLW) as defined by the National Authority and the International Hydrographic Organisation.");
	public static final GeographicFeatureTypeSubcategoryCode PACK_ICE = new GeographicFeatureTypeSubcategoryCode(
			"Pack ice",
			"PCKICE",
			"An area of ice formed by the drifting and crushing together of floating pieces of ice.");
	public static final GeographicFeatureTypeSubcategoryCode PINGO = new GeographicFeatureTypeSubcategoryCode(
			"Pingo",
			"PINGO",
			"A cone or dome shaped mound or hill of peat or soil, usually with a core of ice. It is found in tundra regions and is produced by the pressure of water or ice accumulating underground and pushing upward.");
	public static final GeographicFeatureTypeSubcategoryCode POLAR_ICE = new GeographicFeatureTypeSubcategoryCode(
			"Polar ice",
			"PLRICE",
			"The heaviest, thickest form of ice over land or water.");
	public static final GeographicFeatureTypeSubcategoryCode RAPIDS = new GeographicFeatureTypeSubcategoryCode(
			"Rapids",
			"RAPIDS",
			"A place in a stream or river where the current is swift and the surface is usually broken by boulders and rocks.");
	public static final GeographicFeatureTypeSubcategoryCode ROCK_STRATA_ROCK_FORMATION = new GeographicFeatureTypeSubcategoryCode(
			"Rock strata/rock formation",
			"RCKSTR",
			"A visual topographic outcrop, layers or beds of rock.");
	public static final GeographicFeatureTypeSubcategoryCode REEF = new GeographicFeatureTypeSubcategoryCode(
			"Reef",
			"REEF",
			"A rocky or coral elevation at or near enough to the surface of the sea to be a danger to surface navigation.");
	public static final GeographicFeatureTypeSubcategoryCode ROCK = new GeographicFeatureTypeSubcategoryCode(
			"Rock",
			"ROCK",
			"An isolated rocky formation or a single large stone above or below the water surface.");
	public static final GeographicFeatureTypeSubcategoryCode RIVER_BANK = new GeographicFeatureTypeSubcategoryCode(
			"River bank",
			"RVRBNK",
			"The limit line between the water area of a river and the area of land.");
	public static final GeographicFeatureTypeSubcategoryCode RIVER_STREAM = new GeographicFeatureTypeSubcategoryCode(
			"River/stream",
			"RVRSTR",
			"A natural flowing watercourse.");
	public static final GeographicFeatureTypeSubcategoryCode RIVER_STREAM_VANISHING_POINT = new GeographicFeatureTypeSubcategoryCode(
			"River/stream vanishing point",
			"RVRSTV",
			"Point at which a river or stream passes into the ground.");
	public static final GeographicFeatureTypeSubcategoryCode SEBKHA = new GeographicFeatureTypeSubcategoryCode(
			"Sebkha",
			"SEBKHA",
			"A natural depression in arid or semi-arid regions whose bed is covered with salt encrusted clayey soil.");
	public static final GeographicFeatureTypeSubcategoryCode SHORELINE = new GeographicFeatureTypeSubcategoryCode(
			"Shoreline",
			"SHRLNE",
			"A line drawn along the normal limit of wave action above either Mean High Water Springs (MHWS) or Mean High High Water (MHHW) as defined by the National Authority.");
	public static final GeographicFeatureTypeSubcategoryCode SALT_PAN = new GeographicFeatureTypeSubcategoryCode(
			"Salt pan",
			"SLTPAN",
			"A flat area of natural surface salt deposits.");
	public static final GeographicFeatureTypeSubcategoryCode SAND_DUNE_SAND_HILL = new GeographicFeatureTypeSubcategoryCode(
			"Sand dune/sand hill",
			"SNDDUN",
			"Ridges or hills of sand.");
	public static final GeographicFeatureTypeSubcategoryCode SNAGS_SUBMERGED_STUMPS = new GeographicFeatureTypeSubcategoryCode(
			"Snags/submerged stumps",
			"SNGSSS",
			"A stem or a trunk of a tree below the surface of water.");
	public static final GeographicFeatureTypeSubcategoryCode SNOW_FIELD_ICE_FIELD = new GeographicFeatureTypeSubcategoryCode(
			"Snow field/ice field",
			"SNWICE",
			"A large area permanently covered by snow or ice over land or water.");
	public static final GeographicFeatureTypeSubcategoryCode SPRING_WATER_HOLE = new GeographicFeatureTypeSubcategoryCode(
			"Spring/water hole",
			"SPRING",
			"A natural outflow of water from below the ground surface.");
	public static final GeographicFeatureTypeSubcategoryCode SWAMP = new GeographicFeatureTypeSubcategoryCode(
			"Swamp",
			"SWAMP",
			"A low lying saturated area covered with water all or most of the year, where accumulating dead vegetation does not rapidly decay. It can exist on flat-lying areas created by certain geomorphic environments.");
	public static final GeographicFeatureTypeSubcategoryCode TUNDRA = new GeographicFeatureTypeSubcategoryCode(
			"Tundra",
			"TUNDRA",
			"A prairie-like region in the Arctic and Subarctic zones in which the subsoil is permanently frozen.");
	public static final GeographicFeatureTypeSubcategoryCode UNDERGROUND_WATER_PHREATIC_WATER = new GeographicFeatureTypeSubcategoryCode(
			"Underground water/phreatic water",
			"UNDRGW",
			"Water situated underground but reachable by wells.");
	public static final GeographicFeatureTypeSubcategoryCode UNDERMINED_LAND = new GeographicFeatureTypeSubcategoryCode(
			"Undermined land",
			"UNDRML",
			"Area undermined through mining activities that has already partly subsided or that is in the process of subsiding.");
	public static final GeographicFeatureTypeSubcategoryCode UNDERWATER_SAND_RIDGE = new GeographicFeatureTypeSubcategoryCode(
			"Underwater sand ridge",
			"UNDRSR",
			"Sand on the sea floor having steeper sides and less regular topography than a rise.");
	public static final GeographicFeatureTypeSubcategoryCode VALLEY = new GeographicFeatureTypeSubcategoryCode(
			"Valley",
			"VALLEY",
			"A stretched-out groove in the land, usually formed by streams or rivers. A valley begins with high ground on three sides, and usually has a course of running water through it.");
	public static final GeographicFeatureTypeSubcategoryCode VOLCANO_DIKE = new GeographicFeatureTypeSubcategoryCode(
			"Volcano dike",
			"VLCNOD",
			"A steep ridge of igneous rock.");
	public static final GeographicFeatureTypeSubcategoryCode VOLCANO = new GeographicFeatureTypeSubcategoryCode(
			"Volcano",
			"VOLCNO",
			"A mountain or hill, often conical, formed around a vent in the earth's crust through which molten rock, ash, or gases are or have been expelled.");
	public static final GeographicFeatureTypeSubcategoryCode WATER_EXCEPT_INLAND = new GeographicFeatureTypeSubcategoryCode(
			"Water (except inland)",
			"WATER",
			"An area of water that normally has tidal fluctuations.");
	public static final GeographicFeatureTypeSubcategoryCode WATERFALL = new GeographicFeatureTypeSubcategoryCode(
			"Waterfall",
			"WATRFL",
			"A vertical or nearly vertical descent of water.");

	private GeographicFeatureTypeSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
