/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveItemMarkingMethodCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the method of marking a position.";
	}

	private static HashMap<String, ActionObjectiveItemMarkingMethodCode> physicalToCode = new HashMap<String, ActionObjectiveItemMarkingMethodCode>();

	public static ActionObjectiveItemMarkingMethodCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveItemMarkingMethodCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveItemMarkingMethodCode FLARE = new ActionObjectiveItemMarkingMethodCode(
			"Flare",
			"FLR",
			"The marking of an object by a pyrotechnic munition producing illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode ILLUMINATION = new ActionObjectiveItemMarkingMethodCode(
			"Illumination",
			"ILLUMN",
			"The act or process of marking of an object by visible or near visible light.");
	public static final ActionObjectiveItemMarkingMethodCode LASER = new ActionObjectiveItemMarkingMethodCode(
			"Laser",
			"LAS",
			"The marking of an object by a device that produces an electromagnetic beam for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode LIGHT = new ActionObjectiveItemMarkingMethodCode(
			"Light",
			"LIGHT",
			"The marking of an object by a device that places visible light for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode MARKER_PANEL = new ActionObjectiveItemMarkingMethodCode(
			"Marker panel",
			"MPL",
			"A sheet of material that is used as a reference point for object marking.");
	public static final ActionObjectiveItemMarkingMethodCode NOT_KNOWN = new ActionObjectiveItemMarkingMethodCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final ActionObjectiveItemMarkingMethodCode NOT_OTHERWISE_SPECIFIED = new ActionObjectiveItemMarkingMethodCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final ActionObjectiveItemMarkingMethodCode RADIO_BEACON = new ActionObjectiveItemMarkingMethodCode(
			"Radio beacon",
			"RBE",
			"The reference point of an object by a radio transmitter that emits a distinctive, or characteristic, signal used for the determination of bearings, courses or location.");
	public static final ActionObjectiveItemMarkingMethodCode SMOKE = new ActionObjectiveItemMarkingMethodCode(
			"Smoke",
			"SMOKE",
			"The marking of an object by a munition producing smoke.");
	public static final ActionObjectiveItemMarkingMethodCode STROBE_BEACON = new ActionObjectiveItemMarkingMethodCode(
			"Strobe beacon",
			"STRBBN",
			"The marking of an object by use of a strobe beacon for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode STROBE_LIGHTS = new ActionObjectiveItemMarkingMethodCode(
			"Strobe lights",
			"STRBLT",
			"The marking of an object by use of strobe lights for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode STAR_CLUSTER = new ActionObjectiveItemMarkingMethodCode(
			"Star cluster",
			"STRCLS",
			"The marking of an object by use of a star cluster for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode TORCH = new ActionObjectiveItemMarkingMethodCode(
			"Torch",
			"TORCH",
			"The marking of an object by use of a torch for illumination or identification.");
	public static final ActionObjectiveItemMarkingMethodCode VEHICLE_LIGHTS = new ActionObjectiveItemMarkingMethodCode(
			"Vehicle lights",
			"VHCLLT",
			"The marking of an object by lights from a vehicle for illumination or identification.");

	private ActionObjectiveItemMarkingMethodCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
