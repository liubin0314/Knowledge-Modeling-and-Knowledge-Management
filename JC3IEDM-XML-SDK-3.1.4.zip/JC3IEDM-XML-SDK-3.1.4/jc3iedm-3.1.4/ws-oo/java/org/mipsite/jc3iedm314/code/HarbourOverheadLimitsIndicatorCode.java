/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourOverheadLimitsIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether bridge and/or overhead power cables exist.";
	}

	private static HashMap<String, HarbourOverheadLimitsIndicatorCode> physicalToCode = new HashMap<String, HarbourOverheadLimitsIndicatorCode>();

	public static HarbourOverheadLimitsIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourOverheadLimitsIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourOverheadLimitsIndicatorCode NO = new HarbourOverheadLimitsIndicatorCode(
			"No",
			"NO",
			"No overhead limitation at the harbour.");
	public static final HarbourOverheadLimitsIndicatorCode YES = new HarbourOverheadLimitsIndicatorCode(
			"Yes",
			"YES",
			"Overhead limitation at the harbour.");

	private HarbourOverheadLimitsIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
