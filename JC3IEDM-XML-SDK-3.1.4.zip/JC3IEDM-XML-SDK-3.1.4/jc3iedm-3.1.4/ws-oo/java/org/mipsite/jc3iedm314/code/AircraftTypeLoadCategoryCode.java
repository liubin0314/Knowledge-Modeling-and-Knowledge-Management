/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AircraftTypeLoadCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a loading capability of an AIRCRAFT-TYPE.";
	}

	private static HashMap<String, AircraftTypeLoadCategoryCode> physicalToCode = new HashMap<String, AircraftTypeLoadCategoryCode>();

	public static AircraftTypeLoadCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AircraftTypeLoadCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AircraftTypeLoadCategoryCode HEAVY = new AircraftTypeLoadCategoryCode(
			"Heavy",
			"HEAVY",
			"An aircraft is capable of lifting heavy loads.");
	public static final AircraftTypeLoadCategoryCode LIGHT = new AircraftTypeLoadCategoryCode(
			"Light",
			"LIGHT",
			"An aircraft is capable of lifting lightweight loads.");
	public static final AircraftTypeLoadCategoryCode MEDIUM = new AircraftTypeLoadCategoryCode(
			"Medium",
			"MEDIUM",
			"An aircraft is capable of lifting medium weight loads.");
	public static final AircraftTypeLoadCategoryCode NOT_KNOWN = new AircraftTypeLoadCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AircraftTypeLoadCategoryCode NOT_OTHERWISE_SPECIFIED = new AircraftTypeLoadCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private AircraftTypeLoadCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
