/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RunwayPavementMaximumTyrePressureCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the pavement maximum tyre pressure classification, which is part of the standard ICAO (International Civil Aviation Organization) method of reporting pavement strength for pavements with bearing strength greater than 5,700 kilograms (12,500 pounds).";
	}

	private static HashMap<String, RunwayPavementMaximumTyrePressureCode> physicalToCode = new HashMap<String, RunwayPavementMaximumTyrePressureCode>();

	public static RunwayPavementMaximumTyrePressureCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RunwayPavementMaximumTyrePressureCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RunwayPavementMaximumTyrePressureCode HIGH = new RunwayPavementMaximumTyrePressureCode(
			"High",
			"W",
			"The specific value, which indicates that the maximum tyre pressure is not limited.");
	public static final RunwayPavementMaximumTyrePressureCode MEDIUM = new RunwayPavementMaximumTyrePressureCode(
			"Medium",
			"X",
			"The specific value, which indicates that the maximum tyre pressure is limited between 1006,634 Pa and 1496,162 Pa (146 and 217 (Pounds per square inch)) PSI (1 PSI = 6894.757 Pa).");
	public static final RunwayPavementMaximumTyrePressureCode LOW = new RunwayPavementMaximumTyrePressureCode(
			"Low",
			"Y",
			"The specific value, which indicates that the maximum tyre pressure is limited between 510,212 Pa and 999,739 Pa (74 and 145 (Pounds per square inch)) PSI (1 PSI = 6894.757 Pa).");
	public static final RunwayPavementMaximumTyrePressureCode ULTRA_LOW = new RunwayPavementMaximumTyrePressureCode(
			"Ultra-low",
			"Z",
			"The specific value, which indicates that the maximum tyre pressure is limited to 503,317 Pa (73 Pounds per square inch) PSI (1 PSI = 6894.757 Pa).");

	private RunwayPavementMaximumTyrePressureCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
