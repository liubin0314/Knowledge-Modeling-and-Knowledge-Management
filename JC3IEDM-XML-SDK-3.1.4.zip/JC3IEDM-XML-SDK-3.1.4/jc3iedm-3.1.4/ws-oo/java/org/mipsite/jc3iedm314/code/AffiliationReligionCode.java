/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class AffiliationReligionCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a religion in a specific AFFILIATION-RELIGION.";
	}

	private static HashMap<String, AffiliationReligionCode> physicalToCode = new HashMap<String, AffiliationReligionCode>();

	public static AffiliationReligionCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<AffiliationReligionCode> getCodes() {
		return physicalToCode.values();
	}

	public static final AffiliationReligionCode AFRICAN_METHODIST_EPISCOPAL_ZION = new AffiliationReligionCode(
			"African Methodist Episcopal (Zion)",
			"AFRMTH",
			"One who adheres to or identifies with the African Methodist Episcopal (Zion) doctrine.");
	public static final AffiliationReligionCode ANGLICAN = new AffiliationReligionCode(
			"Anglican",
			"ANGLCN",
			"One who adheres to or identifies with the Anglican doctrine.");
	public static final AffiliationReligionCode ANIMISM = new AffiliationReligionCode(
			"Animism",
			"ANIMSM",
			"One who adheres to or identifies with the Animism doctrine.");
	public static final AffiliationReligionCode APOSTOLIC = new AffiliationReligionCode(
			"Apostolic",
			"APSTLC",
			"One who adheres to or identifies with the Apostolic doctrine.");
	public static final AffiliationReligionCode ARMENIAN = new AffiliationReligionCode(
			"Armenian",
			"ARMNAN",
			"One who adheres to or identifies with the Armenian doctrine.");
	public static final AffiliationReligionCode ARMENIAN_ORTHODOX = new AffiliationReligionCode(
			"Armenian Orthodox",
			"ARMORT",
			"One who adheres to or identifies with the Armenian Orthodox doctrine.");
	public static final AffiliationReligionCode ASSEMBLY_OF_GOD = new AffiliationReligionCode(
			"Assembly of God",
			"ASMGOD",
			"One who adheres to or identifies with the Assembly of God doctrine.");
	public static final AffiliationReligionCode ATHEIST = new AffiliationReligionCode(
			"Atheist",
			"ATHEST",
			"One who denies or disbelieves the existence of any deity.");
	public static final AffiliationReligionCode BABYLONIAN = new AffiliationReligionCode(
			"Babylonian",
			"BABYLN",
			"One who adheres to or identifies with the Babylonian doctrine.");
	public static final AffiliationReligionCode BAHA_I = new AffiliationReligionCode(
			"Baha'i",
			"BAHAI",
			"One who adheres to or identifies with the Baha'i doctrine.");
	public static final AffiliationReligionCode BAPTIST = new AffiliationReligionCode(
			"Baptist",
			"BAPTST",
			"One who adheres to or identifies with the Baptist doctrine.");
	public static final AffiliationReligionCode BEHA_I = new AffiliationReligionCode(
			"Beha'i",
			"BEHAI",
			"One who adheres to or identifies with the Beha'i doctrine.");
	public static final AffiliationReligionCode BULGARIAN_ORTHODOX = new AffiliationReligionCode(
			"Bulgarian Orthodox",
			"BLGORT",
			"One who adheres to or identifies with the Bulgarian Orthodox doctrine.");
	public static final AffiliationReligionCode BUDDHISM = new AffiliationReligionCode(
			"Buddhism",
			"BUDHSM",
			"One who adheres to or identifies with the Buddhism doctrine.");
	public static final AffiliationReligionCode CALVINIST = new AffiliationReligionCode(
			"Calvinist",
			"CALVNS",
			"One who adheres to or identifies with the Calvinist doctrine.");
	public static final AffiliationReligionCode CATHOLIC = new AffiliationReligionCode(
			"Catholic",
			"CATHLC",
			"One who adheres to or identifies with the Catholic doctrine.");
	public static final AffiliationReligionCode CHONDOGYO = new AffiliationReligionCode(
			"Chondogyo",
			"CHNDGY",
			"One who adheres to or identifies with the Chondogyo doctrine.");
	public static final AffiliationReligionCode CHURCH_OF_ENGLAND = new AffiliationReligionCode(
			"Church of England",
			"CHRENG",
			"One who adheres to or identifies with the Church of England doctrine.");
	public static final AffiliationReligionCode CHRISTIAN_FREE_WESLEYAN_CHURCH = new AffiliationReligionCode(
			"Christian (Free Wesleyan Church)",
			"CHRFRW",
			"One who adheres to or identifies with the Christian (Free Wesleyan Church) doctrine.");
	public static final AffiliationReligionCode CHURCH_OF_GOD = new AffiliationReligionCode(
			"Church of God",
			"CHRGOD",
			"One who adheres to or identifies with the Church of God doctrine.");
	public static final AffiliationReligionCode CHRISTIAN_LIEBENZELL_MISSION = new AffiliationReligionCode(
			"Christian (Liebenzell Mission)",
			"CHRSLB",
			"One who adheres to or identifies with the Christian (Liebenzell Mission) doctrine.");
	public static final AffiliationReligionCode CHRISTIAN = new AffiliationReligionCode(
			"Christian",
			"CHRSTN",
			"One who adheres to or identifies with the Christian doctrine.");
	public static final AffiliationReligionCode CHURCH_OF_TUVALU = new AffiliationReligionCode(
			"Church of Tuvalu",
			"CHRTVL",
			"One who adheres to or identifies with the Church of Tuvalu doctrine.");
	public static final AffiliationReligionCode CONFUCIANISM = new AffiliationReligionCode(
			"Confucianism",
			"CNFCNS",
			"One who adheres to or identifies with the Confucianism doctrine.");
	public static final AffiliationReligionCode CONGREGATIONAL = new AffiliationReligionCode(
			"Congregational",
			"CNG",
			"One who adheres to or identifies with the Congregational doctrine.");
	public static final AffiliationReligionCode CONGREGATIONAL_CHRISTIAN_CHURCH = new AffiliationReligionCode(
			"Congregational Christian Church",
			"CNGCCH",
			"One who adheres to or identifies with the Congregational Christian Church doctrine.");
	public static final AffiliationReligionCode CONGREGATIONAL_NEW_CHURCH = new AffiliationReligionCode(
			"Congregational New Church",
			"CNGNCH",
			"One who adheres to or identifies with the Congregational New Church doctrine.");
	public static final AffiliationReligionCode COPTIC_CHRISTIAN = new AffiliationReligionCode(
			"Coptic Christian",
			"CPTCHR",
			"One who adheres to or identifies with the Coptic Christian doctrine.");
	public static final AffiliationReligionCode DRUZE = new AffiliationReligionCode(
			"Druze",
			"DRUZE",
			"One who adheres to or identifies with the Druze doctrine.");
	public static final AffiliationReligionCode EKALESIA_NIEUE = new AffiliationReligionCode(
			"Ekalesia Nieue",
			"EKLNIE",
			"One who adheres to or identifies with the Ekalesia Nieue doctrine.");
	public static final AffiliationReligionCode EPISCOPALIAN = new AffiliationReligionCode(
			"Episcopalian",
			"EPSCPL",
			"One who adheres to or identifies with the Episcopalian doctrine.");
	public static final AffiliationReligionCode EASTERN_ORTHODOX = new AffiliationReligionCode(
			"Eastern Orthodox",
			"ESTORT",
			"One who adheres to or identifies with the Eastern Orthodox doctrine.");
	public static final AffiliationReligionCode ETHIOPIAN_ORTHODOX = new AffiliationReligionCode(
			"Ethiopian Orthodox",
			"ETHORT",
			"One who adheres to or identifies with the Ethiopian Orthodox doctrine.");
	public static final AffiliationReligionCode EVANGELICAL_ALLIANCE = new AffiliationReligionCode(
			"Evangelical Alliance",
			"EVNALL",
			"One who adheres to or identifies with the Evangelical Alliance doctrine.");
	public static final AffiliationReligionCode EVANGELIST_CHURCH = new AffiliationReligionCode(
			"Evangelist Church",
			"EVNGCH",
			"One who adheres to or identifies with the Evangelist Church doctrine.");
	public static final AffiliationReligionCode EVANGELICAL_LUTHERAN = new AffiliationReligionCode(
			"Evangelical Lutheran",
			"EVNLUT",
			"One who adheres to or identifies with the Evangelical Lutheran doctrine.");
	public static final AffiliationReligionCode GEORGIAN_ORTHODOX = new AffiliationReligionCode(
			"Georgian Orthodox",
			"GEOORT",
			"One who adheres to or identifies with the Georgian Orthodox doctrine.");
	public static final AffiliationReligionCode GREGORIAN_ARMENIAN = new AffiliationReligionCode(
			"Gregorian-Armenian",
			"GRGARM",
			"One who adheres to or identifies with the Gregorian-Armenian doctrine.");
	public static final AffiliationReligionCode GREEK_CATHOLIC = new AffiliationReligionCode(
			"Greek Catholic",
			"GRKCTH",
			"One who adheres to or identifies with the Greek Catholic doctrine.");
	public static final AffiliationReligionCode GREEK_ORTHODOX = new AffiliationReligionCode(
			"Greek Orthodox",
			"GRKORT",
			"One who adheres to or identifies with the Greek Orthodox doctrine.");
	public static final AffiliationReligionCode HINDUISM = new AffiliationReligionCode(
			"Hinduism",
			"HINDU",
			"One who adheres to or identifies with the Hinduism doctrine.");
	public static final AffiliationReligionCode IBADHI_MUSLIM = new AffiliationReligionCode(
			"Ibadhi Muslim",
			"IBDMUS",
			"One who adheres to or identifies with the Ibadhi Muslim doctrine.");
	public static final AffiliationReligionCode INDIGENOUS = new AffiliationReligionCode(
			"Indigenous",
			"INDGNS",
			"One who adheres to or identifies with the Indigenous doctrine.");
	public static final AffiliationReligionCode ISLAM_ALAWITE = new AffiliationReligionCode(
			"Islam (Alawite)",
			"ISLAMA",
			"One who adheres to or identifies with the Islam (Alawite) doctrine.");
	public static final AffiliationReligionCode ISLAMIC = new AffiliationReligionCode(
			"Islamic",
			"ISLAMC",
			"One who adheres to or identifies with the Islamic doctrine.");
	public static final AffiliationReligionCode ISLAM_ISMA_ILITE = new AffiliationReligionCode(
			"Islam (Isma'ilite)",
			"ISLAMI",
			"One who adheres to or identifies with the Islam (Isma'ilite) doctrine.");
	public static final AffiliationReligionCode ISLAM_NUSAYRI = new AffiliationReligionCode(
			"Islam (Nusayri)",
			"ISLAMN",
			"One who adheres to or identifies with the Islam (Nusayri) doctrine.");
	public static final AffiliationReligionCode JAINS = new AffiliationReligionCode(
			"Jains",
			"JAINS",
			"One who adheres to or identifies with the Jains doctrine.");
	public static final AffiliationReligionCode JEHOVAH_S_WITNESS = new AffiliationReligionCode(
			"Jehovah's Witness",
			"JHVWTN",
			"One who adheres to or identifies with the Jehovah's Witness doctrine.");
	public static final AffiliationReligionCode JUDAISM = new AffiliationReligionCode(
			"Judaism",
			"JUDASM",
			"One who adheres to or identifies with the Judaism doctrine.");
	public static final AffiliationReligionCode KIEV_PATRIARCHATE = new AffiliationReligionCode(
			"Kiev Patriarchate",
			"KIEVPT",
			"One who adheres to or identifies with the Kiev Patriarchate doctrine.");
	public static final AffiliationReligionCode KIMBANGUIST = new AffiliationReligionCode(
			"Kimbanguist",
			"KMBNGS",
			"One who adheres to or identifies with the Kimbanguist doctrine.");
	public static final AffiliationReligionCode LAMAISTIC_BUDDHISM = new AffiliationReligionCode(
			"Lamaistic Buddhism",
			"LAMBUD",
			"One who adheres to or identifies with the Lamaistic Buddhism doctrine.");
	public static final AffiliationReligionCode LONDON_MISSIONARY_SOCIETY = new AffiliationReligionCode(
			"London Missionary Society",
			"LNDMSN",
			"One who adheres to or identifies with the London Missionary Society doctrine.");
	public static final AffiliationReligionCode LATTER_DAY_SAINTS = new AffiliationReligionCode(
			"Latter-day Saints",
			"LTRSNT",
			"One who adheres to or identifies with the Latter-day Saints doctrine.");
	public static final AffiliationReligionCode LUTHERAN = new AffiliationReligionCode(
			"Lutheran",
			"LUTHRN",
			"One who adheres to or identifies with the Lutheran doctrine.");
	public static final AffiliationReligionCode MANDEAEN = new AffiliationReligionCode(
			"Mandeaen",
			"MANDEA",
			"One who adheres to or identifies with the Mandeaen doctrine.");
	public static final AffiliationReligionCode MARONITE = new AffiliationReligionCode(
			"Maronite",
			"MARONT",
			"One who adheres to or identifies with the Maronite doctrine.");
	public static final AffiliationReligionCode MENNONITE = new AffiliationReligionCode(
			"Mennonite",
			"MENNTE",
			"One who adheres to or identifies with the Mennonite doctrine.");
	public static final AffiliationReligionCode METHODIST = new AffiliationReligionCode(
			"Methodist",
			"METHDS",
			"One who adheres to or identifies with the Methodist doctrine.");
	public static final AffiliationReligionCode MODEKNGEI = new AffiliationReligionCode(
			"Modekngei",
			"MODKNG",
			"One who adheres to or identifies with the Modekngei doctrine.");
	public static final AffiliationReligionCode MORMON = new AffiliationReligionCode(
			"Mormon",
			"MORMON",
			"One who adheres to or identifies with the Mormon doctrine.");
	public static final AffiliationReligionCode MOSCOW_PATRIARCHATE = new AffiliationReligionCode(
			"Moscow Patriarchate",
			"MSCWPT",
			"One who adheres to or identifies with the Moscow Patriarchate doctrine.");
	public static final AffiliationReligionCode MUSLIM = new AffiliationReligionCode(
			"Muslim",
			"MUSLIM",
			"One who adheres to or identifies with the Muslim doctrine.");
	public static final AffiliationReligionCode MUSLIM_MALAYS = new AffiliationReligionCode(
			"Muslim (Malays)",
			"MUSMLY",
			"One who adheres to or identifies with the Muslim (Malays) doctrine.");
	public static final AffiliationReligionCode MUSLIM_SHA_FI = new AffiliationReligionCode(
			"Muslim (Sha'fi)",
			"MUSSHF",
			"One who adheres to or identifies with the Muslim (Sha'fi) doctrine.");
	public static final AffiliationReligionCode MUSLIM_ZAYDI = new AffiliationReligionCode(
			"Muslim (Zaydi)",
			"MUSZYD",
			"One who adheres to or identifies with the Muslim (Zaydi) doctrine.");
	public static final AffiliationReligionCode NIUEAN_CHURCH = new AffiliationReligionCode(
			"Niuean Church",
			"NIUNCH",
			"One who adheres to or identifies with the Niuean Church doctrine.");
	public static final AffiliationReligionCode NOT_KNOWN = new AffiliationReligionCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final AffiliationReligionCode NONE = new AffiliationReligionCode(
			"None",
			"NONE",
			"One who does not adhere to a religion.");
	public static final AffiliationReligionCode NOT_OTHERWISE_SPECIFIED = new AffiliationReligionCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final AffiliationReligionCode ORTHODOX = new AffiliationReligionCode(
			"Orthodox",
			"ORTHDX",
			"One who adheres to or identifies with the Orthodox doctrine.");
	public static final AffiliationReligionCode PARSI = new AffiliationReligionCode(
			"Parsi",
			"PARSI",
			"One who adheres to or identifies with the Parsi doctrine.");
	public static final AffiliationReligionCode PAGAN_AFRICAN = new AffiliationReligionCode(
			"Pagan African",
			"PGNAFR",
			"One who adheres to or identifies with the Pagan African doctrine.");
	public static final AffiliationReligionCode PENTECOSTAL = new AffiliationReligionCode(
			"Pentecostal",
			"PNTCST",
			"One who adheres to or identifies with the Pentecostal doctrine.");
	public static final AffiliationReligionCode PRESBYTERIAN = new AffiliationReligionCode(
			"Presbyterian",
			"PRSBYT",
			"One who adheres to or identifies with the Presbyterian doctrine.");
	public static final AffiliationReligionCode PROTESTANT = new AffiliationReligionCode(
			"Protestant",
			"PRT",
			"One who adheres to or identifies with the Protestant doctrine.");
	public static final AffiliationReligionCode PROTESTANT_ADVENTIST = new AffiliationReligionCode(
			"Protestant (Adventist)",
			"PRTADV",
			"One who adheres to or identifies with the Protestant (Adventist) doctrine.");
	public static final AffiliationReligionCode PROTESTANT_EVANGELICAL_METHODIST = new AffiliationReligionCode(
			"Protestant (Evangelical Methodist)",
			"PRTEVN",
			"One who adheres to or identifies with the Protestant (Evangelical Methodist) doctrine.");
	public static final AffiliationReligionCode PROTESTANT_MORAVIAN = new AffiliationReligionCode(
			"Protestant (Moravian)",
			"PRTMRV",
			"One who adheres to or identifies with the Protestant (Moravian) doctrine.");
	public static final AffiliationReligionCode ROMAN_CATHOLIC = new AffiliationReligionCode(
			"Roman Catholic",
			"RMNCTH",
			"One who adheres to or identifies with the Roman Catholic doctrine.");
	public static final AffiliationReligionCode ROMAN_CATHOLIC_UNIATE = new AffiliationReligionCode(
			"Roman Catholic (Uniate)",
			"RMNCTU",
			"One who adheres to or identifies with the Roman Catholic (Uniate) doctrine.");
	public static final AffiliationReligionCode ROMANIAN_ORTHODOX = new AffiliationReligionCode(
			"Romanian Orthodox",
			"ROMORT",
			"One who adheres to or identifies with the Romanian Orthodox doctrine.");
	public static final AffiliationReligionCode RUSSIAN_ORTHODOX = new AffiliationReligionCode(
			"Russian Orthodox",
			"RUSORT",
			"One who adheres to or identifies with the Russian Orthodox doctrine.");
	public static final AffiliationReligionCode SHI_A_MUSLIM = new AffiliationReligionCode(
			"Shi'a Muslim",
			"SHIMUS",
			"One who adheres to or identifies with the Shi'a Muslim doctrine.");
	public static final AffiliationReligionCode SHINTO = new AffiliationReligionCode(
			"Shinto",
			"SHINTO",
			"One who adheres to or identifies with the Shinto doctrine.");
	public static final AffiliationReligionCode SHAMANISM = new AffiliationReligionCode(
			"Shamanism",
			"SHMNSM",
			"One who adheres to or identifies with the Shamanism doctrine.");
	public static final AffiliationReligionCode SIKH = new AffiliationReligionCode(
			"Sikh",
			"SIKH",
			"One who adheres to or identifies with the Sikh doctrine.");
	public static final AffiliationReligionCode SLAVIC_MUSLIM = new AffiliationReligionCode(
			"Slavic Muslim",
			"SLVMUS",
			"One who adheres to or identifies with the Slavic Muslim doctrine.");
	public static final AffiliationReligionCode SOCIETY_OF_FRIENDS = new AffiliationReligionCode(
			"Society of Friends",
			"SOCFRD",
			"One who adheres to or identifies with the Society of Friends doctrine.");
	public static final AffiliationReligionCode SPIRITUAL_CULTS = new AffiliationReligionCode(
			"Spiritual Cults",
			"SPRCLT",
			"One who adheres to or identifies with the Spiritual Cults doctrine.");
	public static final AffiliationReligionCode SUNNI_MUSLIM = new AffiliationReligionCode(
			"Sunni Muslim",
			"SUNMUS",
			"One who adheres to or identifies with the Sunni Muslim doctrine.");
	public static final AffiliationReligionCode SEVENTH_DAY_ADVENTIST = new AffiliationReligionCode(
			"Seventh-day Adventist",
			"SVNADV",
			"One who adheres to or identifies with the Seventh-day Adventist doctrine.");
	public static final AffiliationReligionCode SYNCRETIC_CHONDOGYO = new AffiliationReligionCode(
			"Syncretic Chondogyo",
			"SYNCHN",
			"One who adheres to or identifies with the Syncretic Chondogyo doctrine.");
	public static final AffiliationReligionCode TAOISM = new AffiliationReligionCode(
			"Taoism",
			"TAOISM",
			"One who adheres to or identifies with the Taoism doctrine.");
	public static final AffiliationReligionCode TIBETAN_BUDDHIST = new AffiliationReligionCode(
			"Tibetan Buddhist",
			"TBTBUD",
			"One who adheres to or identifies with the Tibetan Buddhist doctrine.");
	public static final AffiliationReligionCode THERAVADA_BUDDHISM = new AffiliationReligionCode(
			"Theravada Buddhism",
			"THRVBD",
			"One who adheres to or identifies with the Theravada Buddhism doctrine.");
	public static final AffiliationReligionCode TRIBAL_RELIGION = new AffiliationReligionCode(
			"Tribal Religion",
			"TRBREL",
			"One who adheres to or identifies with the Tribal Religion doctrine.");
	public static final AffiliationReligionCode TRADITIONAL = new AffiliationReligionCode(
			"Traditional",
			"TRD",
			"One who adheres to or identifies with the Traditional doctrine.");
	public static final AffiliationReligionCode TRADITIONAL_MAYAN = new AffiliationReligionCode(
			"Traditional Mayan",
			"TRDMYN",
			"One who adheres to or identifies with the Traditional Mayan doctrine.");
	public static final AffiliationReligionCode UKRAINIAN_AUTOCEPHALOUS = new AffiliationReligionCode(
			"Ukrainian Autocephalous",
			"UKRAUT",
			"One who adheres to or identifies with the Ukrainian Autocephalous doctrine.");
	public static final AffiliationReligionCode UKRAINIAN_CATHOLIC_UNIATE = new AffiliationReligionCode(
			"Ukrainian Catholic (Uniate)",
			"UKRCTH",
			"One who adheres to or identifies with the Ukrainian Catholic (Uniate) doctrine.");
	public static final AffiliationReligionCode UKRAINIAN_ORTHODOX = new AffiliationReligionCode(
			"Ukrainian Orthodox",
			"UKRORT",
			"One who adheres to or identifies with the Ukrainian Orthodox doctrine.");
	public static final AffiliationReligionCode UNITED_CHURCH = new AffiliationReligionCode(
			"United Church",
			"UNCH",
			"One who adheres to or identifies with the United Church doctrine.");
	public static final AffiliationReligionCode UNITING_CHURCH_IN_AUSTRALIA = new AffiliationReligionCode(
			"Uniting Church in Australia",
			"UNCHAU",
			"One who adheres to or identifies with the Uniting Church in Australia doctrine.");
	public static final AffiliationReligionCode UNITED_CHURCH_CONGREGATIONAL = new AffiliationReligionCode(
			"United Church (Congregational)",
			"UNCHCN",
			"One who adheres to or identifies with the United Church (Congregational) doctrine.");
	public static final AffiliationReligionCode UNITED_CHURCH_PRESBYTERIAN = new AffiliationReligionCode(
			"United Church (Presbyterian)",
			"UNCHPR",
			"One who adheres to or identifies with the United Church (Presbyterian) doctrine.");
	public static final AffiliationReligionCode UNITED_METHODIST = new AffiliationReligionCode(
			"United (Methodist)",
			"UNDMTH",
			"One who adheres to or identifies with the United (Methodist) doctrine.");
	public static final AffiliationReligionCode UNITED_PRESBYTERIAN = new AffiliationReligionCode(
			"United (Presbyterian)",
			"UNDPRB",
			"One who adheres to or identifies with the United (Presbyterian) doctrine.");
	public static final AffiliationReligionCode UNITED_FREE_CHURCH = new AffiliationReligionCode(
			"United Free Church",
			"UNFRCH",
			"One who adheres to or identifies with the United Free Church doctrine.");
	public static final AffiliationReligionCode UNIATE_CATHOLIC = new AffiliationReligionCode(
			"Uniate Catholic",
			"UNICTH",
			"One who adheres to or identifies with the Uniate Catholic doctrine.");
	public static final AffiliationReligionCode VOODOO = new AffiliationReligionCode(
			"Voodoo",
			"VOODOO",
			"One who adheres to or identifies with the Voodoo doctrine.");
	public static final AffiliationReligionCode ZOROASTRIAN = new AffiliationReligionCode(
			"Zoroastrian",
			"ZRSTRN",
			"One who adheres to or identifies with the Zoroastrian doctrine.");

	private AffiliationReligionCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
