/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ActionObjectiveCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of ACTION-OBJECTIVE with respect to item or type.";
	}

	private static HashMap<String, ActionObjectiveCategoryCode> physicalToCode = new HashMap<String, ActionObjectiveCategoryCode>();

	public static ActionObjectiveCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ActionObjectiveCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ActionObjectiveCategoryCode ACTION_OBJECTIVE_ITEM = new ActionObjectiveCategoryCode(
			"ACTION-OBJECTIVE-ITEM",
			"OI",
			"A battlespace object (FACILITY, FEATURE, MATERIEL, ORGANISATION or PERSON) which is the focus of a specific ACTION.");
	public static final ActionObjectiveCategoryCode ACTION_OBJECTIVE_TYPE = new ActionObjectiveCategoryCode(
			"ACTION-OBJECTIVE-TYPE",
			"OT",
			"A class of battlespace object (FACILITY-TYPE, FEATURE-TYPE, MATERIEL-TYPE, ORGANISATION-TYPE or PERSON-TYPE) which is the focus of a specific ACTION.");
	public static final ActionObjectiveCategoryCode ACTION_OBJECTIVE_TASK = new ActionObjectiveCategoryCode(
			"ACTION-OBJECTIVE-TASK",
			"OTASK",
			"The objective of the specific ACTION is the operation identified as the specific ACTION-TASK.");

	private ActionObjectiveCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
