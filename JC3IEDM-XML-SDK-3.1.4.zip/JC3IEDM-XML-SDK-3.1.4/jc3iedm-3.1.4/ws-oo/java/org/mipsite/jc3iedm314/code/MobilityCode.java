/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MobilityCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates the suitability of a specific ROUTE or ROUTE-SEGMENT for movement.";
	}

	private static HashMap<String, MobilityCode> physicalToCode = new HashMap<String, MobilityCode>();

	public static MobilityCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MobilityCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MobilityCode FOOT = new MobilityCode(
			"Foot",
			"FOOT",
			"Suitable only for pedestrians and animals.");
	public static final MobilityCode NOT_KNOWN = new MobilityCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final MobilityCode TRACKED = new MobilityCode(
			"Tracked",
			"TRACK",
			"Suitable for tracked vehicles.");
	public static final MobilityCode WHEELED_GENERAL = new MobilityCode(
			"Wheeled, general",
			"WHEEL",
			"Suitable for wheeled vehicles without need for any additional capability.");
	public static final MobilityCode WHEELED_ALL_ROAD = new MobilityCode(
			"Wheeled, all road",
			"WHLAWD",
			"Suitable for wheeled vehicles with improved capabilities.");
	public static final MobilityCode WHEELED_AND_TRACKED = new MobilityCode(
			"Wheeled and tracked",
			"WHTR",
			"Suitable for wheeled and tracked vehicles.");

	private MobilityCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
