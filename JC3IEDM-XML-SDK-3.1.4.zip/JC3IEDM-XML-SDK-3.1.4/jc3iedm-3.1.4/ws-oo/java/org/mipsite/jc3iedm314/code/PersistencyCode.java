/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class PersistencyCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the temporal variation of the effectiveness of a biological or chemical materiel under determined conditions after its dispersal.";
	}

	private static HashMap<String, PersistencyCode> physicalToCode = new HashMap<String, PersistencyCode>();

	public static PersistencyCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<PersistencyCode> getCodes() {
		return physicalToCode.values();
	}

	public static final PersistencyCode NOT_KNOWN = new PersistencyCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final PersistencyCode NON_PERSISTENT = new PersistencyCode(
			"Non-persistent",
			"NONPRS",
			"Agents that are disseminated mainly as vapour, but some of the agent types may leave unevaporated liquid in shell or bomb craters for either hours or days depending upon the climatic conditions and the munition type. Craters should be avoided until tests have proved the absence of a liquid hazard.");
	public static final PersistencyCode PERSISTENT = new PersistencyCode(
			"Persistent",
			"PRSTNT",
			"Agents that are disseminated as liquid and present a vapour hazard as well as a contact hazard. This hazard will last for several hours to days depending on the terrain, climatic conditions and munition type.");
	public static final PersistencyCode THICKENED = new PersistencyCode(
			"Thickened",
			"THCKND",
			"Agents that may have to be treated as persistent, ground contaminating agents. Blister agents are normally classified as persistent agents and will be so indicated when detected by three way detection paper. Some agents however, are very volatile and should be treated as nonpersistent, but still ground contaminating agents.");

	private PersistencyCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
