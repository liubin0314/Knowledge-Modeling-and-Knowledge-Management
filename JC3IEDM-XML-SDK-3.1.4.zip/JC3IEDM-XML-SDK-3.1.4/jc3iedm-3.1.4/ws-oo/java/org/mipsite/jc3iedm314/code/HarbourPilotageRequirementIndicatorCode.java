/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class HarbourPilotageRequirementIndicatorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents whether the HARBOUR requires vessels to have a pilot.";
	}

	private static HashMap<String, HarbourPilotageRequirementIndicatorCode> physicalToCode = new HashMap<String, HarbourPilotageRequirementIndicatorCode>();

	public static HarbourPilotageRequirementIndicatorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<HarbourPilotageRequirementIndicatorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final HarbourPilotageRequirementIndicatorCode NO = new HarbourPilotageRequirementIndicatorCode(
			"No",
			"NO",
			"Vessels do not require a pilot to use the harbour.");
	public static final HarbourPilotageRequirementIndicatorCode YES = new HarbourPilotageRequirementIndicatorCode(
			"Yes",
			"YES",
			"Vessels do require a pilot to use the harbour.");

	private HarbourPilotageRequirementIndicatorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
