/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusOperationalStatusQualifierCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the qualification of the operational status of a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusOperationalStatusQualifierCode> physicalToCode = new HashMap<String, OrganisationStatusOperationalStatusQualifierCode>();

	public static OrganisationStatusOperationalStatusQualifierCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusOperationalStatusQualifierCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusOperationalStatusQualifierCode DESTROYED = new OrganisationStatusOperationalStatusQualifierCode(
			"Destroyed",
			"DSTRYD",
			"Subjectively judged by the reporting organisation that an ORGANISATION is not, and not expected ever to be, capable of performing the missions or functions for which it is created.");
	public static final OrganisationStatusOperationalStatusQualifierCode HEAVILY_DAMAGED = new OrganisationStatusOperationalStatusQualifierCode(
			"Heavily damaged",
			"HVYDAM",
			"Subjectively judged by the reporting organisation to be heavily damaged.");
	public static final OrganisationStatusOperationalStatusQualifierCode LIGHTLY_DAMAGED = new OrganisationStatusOperationalStatusQualifierCode(
			"Lightly damaged",
			"LGTDAM",
			"Subjectively judged by the reporting organisation to be only lightly damaged.");
	public static final OrganisationStatusOperationalStatusQualifierCode LOST = new OrganisationStatusOperationalStatusQualifierCode(
			"Lost",
			"LST",
			"Subjectively judged by the reporting organisation that a specific organisation is missing under unknown circumstances.");
	public static final OrganisationStatusOperationalStatusQualifierCode LACKING_VITAL_RESOURCES = new OrganisationStatusOperationalStatusQualifierCode(
			"Lacking vital resources",
			"LVR",
			"Subjectively judged by the reporting organisation that an ORGANISATION is deficient or lacking of some mission-critical resources (e.g., fuel, ammunition).");
	public static final OrganisationStatusOperationalStatusQualifierCode MODERATELY_DAMAGED = new OrganisationStatusOperationalStatusQualifierCode(
			"Moderately damaged",
			"MODDAM",
			"Subjectively judged by the reporting organisation to be moderately damaged.");
	public static final OrganisationStatusOperationalStatusQualifierCode NOT_KNOWN = new OrganisationStatusOperationalStatusQualifierCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private OrganisationStatusOperationalStatusQualifierCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
