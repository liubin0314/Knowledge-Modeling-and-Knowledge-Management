/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class UsageStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the usage of a specific CONTROL-FEATURE, MATERIEL or FACILITY.";
	}

	private static HashMap<String, UsageStatusCode> physicalToCode = new HashMap<String, UsageStatusCode>();

	public static UsageStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<UsageStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final UsageStatusCode ACTIVATED = new UsageStatusCode(
			"Activated",
			"ACTIVE",
			"A status indicating that a CONTROL-FEATURE, MATERIEL or FACILITY is performing the function or service for which it is designed.");
	public static final UsageStatusCode DEACTIVATED = new UsageStatusCode(
			"Deactivated",
			"DEACTV",
			"A status indicating that a CONTROL-FEATURE, MATERIEL or FACILITY is not performing the function or service for which it is designed.");
	public static final UsageStatusCode NOT_KNOWN = new UsageStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");

	private UsageStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
