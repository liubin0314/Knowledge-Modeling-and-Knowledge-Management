/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RailcarTypeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of RAILCAR-TYPE.";
	}

	private static HashMap<String, RailcarTypeCategoryCode> physicalToCode = new HashMap<String, RailcarTypeCategoryCode>();

	public static RailcarTypeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RailcarTypeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RailcarTypeCategoryCode LOCOMOTIVE = new RailcarTypeCategoryCode(
			"Locomotive",
			"LCMTVE",
			"A detachable, wheeled engine used for pulling trains.");
	public static final RailcarTypeCategoryCode NOT_KNOWN = new RailcarTypeCategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RailcarTypeCategoryCode NOT_OTHERWISE_SPECIFIED = new RailcarTypeCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final RailcarTypeCategoryCode RAILED_EQUIPMENT = new RailcarTypeCategoryCode(
			"Railed equipment",
			"RLDEQP",
			"Mobile equipment that uses rails to move on, for example, dockyard cranes.");
	public static final RailcarTypeCategoryCode ROLLING_STOCK = new RailcarTypeCategoryCode(
			"Rolling stock",
			"RLLSTK",
			"Generic term for wagons, either passenger, freight or specialised that are used to form a train.");
	public static final RailcarTypeCategoryCode TRAIN = new RailcarTypeCategoryCode(
			"Train",
			"TRAIN",
			"A self-propelled passenger carrying vehicle that runs on rails.");
	public static final RailcarTypeCategoryCode TRAM = new RailcarTypeCategoryCode(
			"Tram",
			"TRAM",
			"A passenger carrying vehicle that runs on rails normally along roads, with minimal earthworks, typically powered by electricity from overhead power cables via a pantograph.");

	private RailcarTypeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
