/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class NetworkSubcategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the specific class of NETWORK.";
	}

	private static HashMap<String, NetworkSubcategoryCode> physicalToCode = new HashMap<String, NetworkSubcategoryCode>();

	public static NetworkSubcategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<NetworkSubcategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final NetworkSubcategoryCode CIRCUIT_SWITCHED = new NetworkSubcategoryCode(
			"Circuit switched",
			"CIRCSW",
			"A transmission in which a communication channel is established to transmit a message over an optimum path.");
	public static final NetworkSubcategoryCode PACKET_SWITCHED = new NetworkSubcategoryCode(
			"Packet switched",
			"PCKSWT",
			"A transmission in which a message is broken into a number of parts which are sent independently, over whatever route is optimum for each packet, and reassembled at the destination.");
	public static final NetworkSubcategoryCode VIRTUAL_CIRCUIT_SWITCHED = new NetworkSubcategoryCode(
			"Virtual circuit switched",
			"VRTSWT",
			"A transmission in which a message is transmitted over a virtual circuit switched communication channel established on top of a packet switched medium.");
	public static final NetworkSubcategoryCode NOT_KNOWN = new NetworkSubcategoryCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final NetworkSubcategoryCode NOT_OTHERWISE_SPECIFIED = new NetworkSubcategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");

	private NetworkSubcategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
