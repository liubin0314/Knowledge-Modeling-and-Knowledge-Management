/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.entity;


public abstract class AbstractControlFeature extends AbstractFeature {

	// private fields


	// default constructor

	public AbstractControlFeature() {
		// no assignment
	}

	// getter & setter methods
}
