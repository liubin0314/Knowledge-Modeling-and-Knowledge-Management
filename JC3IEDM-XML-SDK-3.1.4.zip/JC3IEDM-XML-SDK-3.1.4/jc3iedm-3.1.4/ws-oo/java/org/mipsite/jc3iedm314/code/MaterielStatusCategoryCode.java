/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MaterielStatusCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of MATERIEL-STATUS.";
	}

	private static HashMap<String, MaterielStatusCategoryCode> physicalToCode = new HashMap<String, MaterielStatusCategoryCode>();

	public static MaterielStatusCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MaterielStatusCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MaterielStatusCategoryCode MINE_STATUS = new MaterielStatusCategoryCode(
			"MINE-STATUS",
			"MNESTA",
			"A MATERIEL-STATUS that is a record of condition of a specific MINE.");
	public static final MaterielStatusCategoryCode NOT_OTHERWISE_SPECIFIED = new MaterielStatusCategoryCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final MaterielStatusCategoryCode UXO_STATUS = new MaterielStatusCategoryCode(
			"UXO-STATUS",
			"UXOSTA",
			"A MATERIEL-STATUS that is a record of a condition of an explosive ordnance that has been primed, fused, armed, or otherwise prepared for action, and which has been fired, dropped, launched, placed in such a manner, as to constitute a hazard to operation, and remains unexploded either by malfunction or for any other cause.");

	private MaterielStatusCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
