/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeometricVolumeCategoryCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the class of GEOMETRIC-VOLUME.";
	}

	private static HashMap<String, GeometricVolumeCategoryCode> physicalToCode = new HashMap<String, GeometricVolumeCategoryCode>();

	public static GeometricVolumeCategoryCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeometricVolumeCategoryCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeometricVolumeCategoryCode CONE_VOLUME = new GeometricVolumeCategoryCode(
			"CONE-VOLUME",
			"CN",
			"A GEOMETRIC-VOLUME whose boundary is swept by a line that has a fixed point and another that moves along the path defined by the border of a specific SURFACE.");
	public static final GeometricVolumeCategoryCode SPHERE_VOLUME = new GeometricVolumeCategoryCode(
			"SPHERE-VOLUME",
			"SPHVOL",
			"A VOLUME that has its horizontal boundaries defined by the spherical surface determined by the radius and the specified POINT.");
	public static final GeometricVolumeCategoryCode SURFACE_VOLUME = new GeometricVolumeCategoryCode(
			"SURFACE-VOLUME",
			"SURVOL",
			"A VOLUME that has its horizontal boundaries defined by a specific SURFACE.");

	private GeometricVolumeCategoryCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
