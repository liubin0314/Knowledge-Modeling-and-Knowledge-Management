/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class GeographicFeatureTerrainCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents a tract of land.";
	}

	private static HashMap<String, GeographicFeatureTerrainCode> physicalToCode = new HashMap<String, GeographicFeatureTerrainCode>();

	public static GeographicFeatureTerrainCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<GeographicFeatureTerrainCode> getCodes() {
		return physicalToCode.values();
	}

	public static final GeographicFeatureTerrainCode FLAT = new GeographicFeatureTerrainCode(
			"Flat",
			"FLAT",
			"The terrain of the GEOGRAPHIC-FEATURE is characterised as broadly level.");
	public static final GeographicFeatureTerrainCode HILLY = new GeographicFeatureTerrainCode(
			"Hilly",
			"HILLY",
			"The terrain of the GEOGRAPHIC-FEATURE is characterised as having multiple hills.");
	public static final GeographicFeatureTerrainCode MOUNTAINOUS = new GeographicFeatureTerrainCode(
			"Mountainous",
			"MOUNTS",
			"The terrain of the GEOGRAPHIC-FEATURE is characterised as having many large natural elevations of the earth's surface rising abruptly from the surrounding level.");
	public static final GeographicFeatureTerrainCode NOT_KNOWN = new GeographicFeatureTerrainCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final GeographicFeatureTerrainCode NOT_OTHERWISE_SPECIFIED = new GeographicFeatureTerrainCode(
			"Not otherwise specified",
			"NOS",
			"The appropriate value is not in the set of specified values.");
	public static final GeographicFeatureTerrainCode UNDULATING = new GeographicFeatureTerrainCode(
			"Undulating",
			"UNDULT",
			"The terrain of the GEOGRAPHIC-FEATURE is characterised as rolling or wavy.");
	public static final GeographicFeatureTerrainCode URBAN = new GeographicFeatureTerrainCode(
			"Urban",
			"URBAN",
			"A topographical complex where man-made construction or high population density is the dominant feature.");

	private GeographicFeatureTerrainCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
