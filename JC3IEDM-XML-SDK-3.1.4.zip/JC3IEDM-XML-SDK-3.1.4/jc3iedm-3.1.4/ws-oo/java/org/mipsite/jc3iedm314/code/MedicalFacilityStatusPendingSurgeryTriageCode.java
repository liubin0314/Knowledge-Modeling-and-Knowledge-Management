/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MedicalFacilityStatusPendingSurgeryTriageCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the categorisation of surgery cases according to multilevel triage classification scheme in a specific MEDICAL-FACILITY-STATUS-PENDING-SURGERY.";
	}

	private static HashMap<String, MedicalFacilityStatusPendingSurgeryTriageCode> physicalToCode = new HashMap<String, MedicalFacilityStatusPendingSurgeryTriageCode>();

	public static MedicalFacilityStatusPendingSurgeryTriageCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MedicalFacilityStatusPendingSurgeryTriageCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MedicalFacilityStatusPendingSurgeryTriageCode T1_VERY_SERIOUSLY_INJURED = new MedicalFacilityStatusPendingSurgeryTriageCode(
			"T1-Very seriously injured",
			"T1",
			"Very seriously injured - 1 hour expected duration for surgery.");
	public static final MedicalFacilityStatusPendingSurgeryTriageCode T2_SERIOUSLY_INJURED = new MedicalFacilityStatusPendingSurgeryTriageCode(
			"T2-Seriously injured",
			"T2",
			"Seriously injured - 2 hours expected duration for surgery.");
	public static final MedicalFacilityStatusPendingSurgeryTriageCode T3_MINIMALLY_INJURED = new MedicalFacilityStatusPendingSurgeryTriageCode(
			"T3-Minimally injured",
			"T3",
			"Minimally injured - 35 minutes expected duration for surgery.");

	private MedicalFacilityStatusPendingSurgeryTriageCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
