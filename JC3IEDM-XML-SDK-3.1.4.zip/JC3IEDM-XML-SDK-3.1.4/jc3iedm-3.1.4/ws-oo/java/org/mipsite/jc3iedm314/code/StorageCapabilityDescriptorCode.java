/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class StorageCapabilityDescriptorCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the STORAGE-CAPABILITY that is being quantified.";
	}

	private static HashMap<String, StorageCapabilityDescriptorCode> physicalToCode = new HashMap<String, StorageCapabilityDescriptorCode>();

	public static StorageCapabilityDescriptorCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<StorageCapabilityDescriptorCode> getCodes() {
		return physicalToCode.values();
	}

	public static final StorageCapabilityDescriptorCode BULK_LIQUID = new StorageCapabilityDescriptorCode(
			"Bulk liquid",
			"BLKLIQ",
			"The numeric value representing the maximum amount of any unpackaged liquid.");
	public static final StorageCapabilityDescriptorCode BULK_VOLUME = new StorageCapabilityDescriptorCode(
			"Bulk volume",
			"BLKVOL",
			"The numeric value representing the maximum volume of any unpackaged mass.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_COUNT = new StorageCapabilityDescriptorCode(
			"Maximum count",
			"MAXCNT",
			"The numeric value representing the maximum item count.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_CARGO_HEIGHT = new StorageCapabilityDescriptorCode(
			"Maximum cargo height",
			"MCRHEI",
			"The one-dimensional linear measurement that represents the extreme vertical distance, measured from the lowest to the highest reference point, of any object.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_CARGO_LENGTH = new StorageCapabilityDescriptorCode(
			"Maximum cargo length",
			"MCRLEN",
			"The one-dimensional linear measurement that represents the extreme horizontal distance, measured from side to side and perpendicular to the central axis, of any object.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_CARGO_WEIGHT = new StorageCapabilityDescriptorCode(
			"Maximum cargo weight",
			"MCRWGT",
			"The numeric value representing the maximum weight of any cargo.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_CARGO_WIDTH = new StorageCapabilityDescriptorCode(
			"Maximum cargo width",
			"MCRWID",
			"The one-dimensional linear measurement that represents the extreme horizontal distance, measured from side to side and parallel to the central axis, of any object.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_LANE_LENGTH = new StorageCapabilityDescriptorCode(
			"Maximum lane length",
			"MLNLEN",
			"The one-dimensional linear measurement that represents the maximum horizontal distance for a number lane strips.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_SURFACE_AREA = new StorageCapabilityDescriptorCode(
			"Maximum surface area",
			"MSRFAR",
			"The numeric value representing a maximum two-dimensional area.");
	public static final StorageCapabilityDescriptorCode MAXIMUM_WEIGHT_BEARING = new StorageCapabilityDescriptorCode(
			"Maximum weight bearing",
			"MWGTBR",
			"The numeric value representing the maximum gravitational force exerted by an object on a unit of surface.");
	public static final StorageCapabilityDescriptorCode NEQ_LIMIT = new StorageCapabilityDescriptorCode(
			"NEQ limit",
			"NEQLMT",
			"The numeric value representing the Net Explosive Quantity limit equivalent to TNT (trinitrotoluene) explosive power.");

	private StorageCapabilityDescriptorCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
