/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class ObjectItemStatusEmissionControlCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the emission control status of a specific OBJECT-ITEM.";
	}

	private static HashMap<String, ObjectItemStatusEmissionControlCode> physicalToCode = new HashMap<String, ObjectItemStatusEmissionControlCode>();

	public static ObjectItemStatusEmissionControlCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<ObjectItemStatusEmissionControlCode> getCodes() {
		return physicalToCode.values();
	}

	public static final ObjectItemStatusEmissionControlCode EMCON_1 = new ObjectItemStatusEmissionControlCode(
			"EMCON 1",
			"EMCON1",
			"Electronic Silence is a deliberate prohibition of electronic radiation to prevent the emission of significant electromagnetic signals.");
	public static final ObjectItemStatusEmissionControlCode EMCON_2 = new ObjectItemStatusEmissionControlCode(
			"EMCON 2",
			"EMCON2",
			"Radio Silence is a restriction placed on the use of all or certain radio equipment. Any commander at any level may impose radio silence.");
	public static final ObjectItemStatusEmissionControlCode EMCON_3 = new ObjectItemStatusEmissionControlCode(
			"EMCON 3",
			"EMCON3",
			"No restrictions, normal operations.");

	private ObjectItemStatusEmissionControlCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
