/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class MinePresenceCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that indicates whether a specific FACILITY or GEOGRAPHIC-FEATURE contains mines.";
	}

	private static HashMap<String, MinePresenceCode> physicalToCode = new HashMap<String, MinePresenceCode>();

	public static MinePresenceCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<MinePresenceCode> getCodes() {
		return physicalToCode.values();
	}

	public static final MinePresenceCode NOT_KNOWN = new MinePresenceCode(
			"Not known",
			"NKN",
			"It is not possible to determine whether mines are present.");
	public static final MinePresenceCode NO = new MinePresenceCode(
			"No",
			"NO",
			"There are no mines in the specific FACILITY or GEOGRAPHIC-FEATURE.");
	public static final MinePresenceCode YES = new MinePresenceCode(
			"Yes",
			"YES",
			"Mines are present in the specific FACILITY or GEOGRAPHIC-FEATURE.");

	private MinePresenceCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
