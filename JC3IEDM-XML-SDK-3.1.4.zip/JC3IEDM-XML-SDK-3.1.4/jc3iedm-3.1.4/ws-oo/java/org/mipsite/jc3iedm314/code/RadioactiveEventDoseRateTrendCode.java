/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class RadioactiveEventDoseRateTrendCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the rate of change of the ionising radiation emitted by a radioactive materiel.";
	}

	private static HashMap<String, RadioactiveEventDoseRateTrendCode> physicalToCode = new HashMap<String, RadioactiveEventDoseRateTrendCode>();

	public static RadioactiveEventDoseRateTrendCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<RadioactiveEventDoseRateTrendCode> getCodes() {
		return physicalToCode.values();
	}

	public static final RadioactiveEventDoseRateTrendCode DECREASING = new RadioactiveEventDoseRateTrendCode(
			"Decreasing",
			"DECR",
			"A decreasing radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventDoseRateTrendCode INCREASING = new RadioactiveEventDoseRateTrendCode(
			"Increasing",
			"INCR",
			"An increasing radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventDoseRateTrendCode INITIAL = new RadioactiveEventDoseRateTrendCode(
			"Initial",
			"INIT",
			"The initial radiation intensity of any radioactive material at the moment of the nuclear event.");
	public static final RadioactiveEventDoseRateTrendCode NOT_KNOWN = new RadioactiveEventDoseRateTrendCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final RadioactiveEventDoseRateTrendCode PEAK = new RadioactiveEventDoseRateTrendCode(
			"Peak",
			"PEAK",
			"A maximum radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventDoseRateTrendCode SAME = new RadioactiveEventDoseRateTrendCode(
			"Same",
			"SAME",
			"A constant radiation intensity of any radioactive material with respect to time.");
	public static final RadioactiveEventDoseRateTrendCode BACKGROUND = new RadioactiveEventDoseRateTrendCode(
			"Background",
			"BACK",
			"A background radiation reading of any radioactive material with respect to time.");

	private RadioactiveEventDoseRateTrendCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
