/**
 * @author Multilateral Interoperability Programme (MIP) - Editor: Dr. Michael Gerz, gerz@fgan.de, FGAN FKIE, Germany
 * @version 1.2 for XML schema version 2.2
 */

package org.mipsite.jc3iedm314.code;

import java.util.Collection;
import java.util.HashMap;

import org.mipsite.xml.processing.domain.CodeDomain;

public class OrganisationStatusOperationalStatusCode extends CodeDomain {

	public static String getComment() {
		return "The specific value that represents the operational status of a specific ORGANISATION.";
	}

	private static HashMap<String, OrganisationStatusOperationalStatusCode> physicalToCode = new HashMap<String, OrganisationStatusOperationalStatusCode>();

	public static OrganisationStatusOperationalStatusCode getCode(String physicalValue) {
		return physicalToCode.get(physicalValue);
	}

	public static Collection<OrganisationStatusOperationalStatusCode> getCodes() {
		return physicalToCode.values();
	}

	public static final OrganisationStatusOperationalStatusCode MARGINALLY_OPERATIONAL = new OrganisationStatusOperationalStatusCode(
			"Marginally operational",
			"MOPS",
			"Subjectively judged by the reporting organisation to be marginally capable of performing the missions or functions for which it is created.");
	public static final OrganisationStatusOperationalStatusCode NOT_KNOWN = new OrganisationStatusOperationalStatusCode(
			"Not known",
			"NKN",
			"It is not possible to determine which value is most applicable.");
	public static final OrganisationStatusOperationalStatusCode NOT_OPERATIONAL = new OrganisationStatusOperationalStatusCode(
			"Not operational",
			"NOP",
			"Subjectively judged by the reporting organisation to be permanently not capable of performing the missions or functions for which it is created.");
	public static final OrganisationStatusOperationalStatusCode OPERATIONAL = new OrganisationStatusOperationalStatusCode(
			"Operational",
			"OPR",
			"Subjectively judged by the reporting organisation to be fully capable of performing the missions or functions for which it is created.");
	public static final OrganisationStatusOperationalStatusCode SUBSTANTIALLY_OPERATIONAL = new OrganisationStatusOperationalStatusCode(
			"Substantially operational",
			"SOPS",
			"Subjectively judged by the reporting organisation to have minor deficiencies which limit its capability to perform the missions or functions for which it is created.");
	public static final OrganisationStatusOperationalStatusCode TEMPORARILY_NOT_OPERATIONAL = new OrganisationStatusOperationalStatusCode(
			"Temporarily not operational",
			"TNOPS",
			"Subjectively judged by the reporting organisation to be temporarily not capable of performing the missions or functions for which it is created.");

	private OrganisationStatusOperationalStatusCode(String displayValue, String physicalValue, String definition) {
		super(displayValue, physicalValue, definition);
		physicalToCode.put(physicalValue, this);
	}
}
