/*	SO_Classification.java
 *  Copyright (C) 2017 University of NUDT, Changsha, PRC
 *  mail:b0314@139.com
 */
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import org.semanticweb.owlapi.apibinding.OWLManager;
import org.semanticweb.owlapi.model.IRI;
import org.semanticweb.owlapi.model.OWLAxiom;
import org.semanticweb.owlapi.model.OWLClass;
import org.semanticweb.owlapi.model.OWLDataFactory;
import org.semanticweb.owlapi.model.OWLNamedIndividual;
import org.semanticweb.owlapi.model.OWLObjectProperty;
import org.semanticweb.owlapi.model.OWLOntology;
import org.semanticweb.owlapi.model.OWLOntologyCreationException;
import org.semanticweb.owlapi.model.OWLOntologyManager;
import org.semanticweb.owlapi.reasoner.NodeSet;
import org.semanticweb.owlapi.reasoner.OWLReasoner;
import org.semanticweb.owlapi.reasoner.OWLReasonerFactory;
import org.semanticweb.owlapi.reasoner.SimpleConfiguration;
import org.semanticweb.owlapi.vocab.PrefixOWLOntologyFormat;

import com.clarkparsia.pellet.owlapiv3.PelletReasonerFactory;
public class TemporalReasoning {
	public static String getMatchedInds(OWLOntology ontology, String individual,String propName){ 
		/*ʹ��OWLOntologyManager���ʱ���*/
		OWLOntologyManager manager=ontology.getOWLOntologyManager();//����OWLOntologyManager����
		//��ȡ�����ǰ׺��
        PrefixOWLOntologyFormat pm =(PrefixOWLOntologyFormat) manager.getOntologyFormat(ontology); 
        //���������ռ�
        String ns=ontology.getOntologyID().getOntologyIRI().toString()+"#";
        pm.setDefaultPrefix(ns);
        //��ȡ��Ϊindividual��ʵ��
		OWLDataFactory factory = manager.getOWLDataFactory(); 
        OWLNamedIndividual ind=factory.getOWLNamedIndividual(":"+individual, pm);
//        OWLClass timeInterval=factory.getOWLClass(":TimeInterval",pm);
//        OWLAxiom assertion=factory.getOWLClassAssertionAxiom(timeInterval, ind);
//        OWLNamedIndividual ind2=factory.getOWLNamedIndividual(":t2", pm);
        //��ȡ��ΪpropName������
        OWLObjectProperty op=factory.getOWLObjectProperty(":"+propName, pm);
//        OWLAxiom assertion1=factory.getOWLObjectPropertyAssertionAxiom(op, ind, ind2);
//        
//        manager.addAxiom(ontology, assertion);
//        Set<OWLAxiom> set=new HashSet<OWLAxiom>();
//        set.add(assertion1);
//        set.add(assertion);
//        manager.addAxioms(ontology, set);
        //ʹ��pellet�������Ա�������
        OWLReasonerFactory reasonerFactory = PelletReasonerFactory.getInstance(); 
        OWLReasoner reasoner = reasonerFactory.createReasoner(ontology, new SimpleConfiguration());
        String soType="";
        if(!reasoner.isConsistent()){
        	System.out.println("���岻һ��");
            reasoner.dispose();
            System.exit(0);
        }else{
        	//����������в�ѯindividual��propName���Ե�ȡֵ
        	Set<OWLNamedIndividual> op_vals=reasoner.getObjectPropertyValues(ind, op).getFlattened();
        	System.out.println(op_vals.size());
			for (OWLNamedIndividual val: op_vals) {
				soType+=val.toString()+";\n";//��ѯ���ת��Ϊ�ַ���
			}
        }
		return soType;
    }
	
	public static void main(String []args) throws OWLOntologyCreationException{
		String ontPath="D:/JavaWorks/OntoTest/ʱ�䱾��.owl";
		/*
		 * ʹ��OWLOntologyManager���뱾��
		 */
        OWLOntologyManager manager = OWLManager.createOWLOntologyManager(); 
        OWLOntology ont= manager.loadOntologyFromOntologyDocument(IRI.create("file:"+ontPath)); 
        //���ú���getIndsTypes��ʹ����������ȡ��������Ϊso1��ʵ��������
        String soType=getMatchedInds(ont, "t0","before");
        //��ӡ
        System.out.println("ʹ��ʱ���pellet�������õ�before(t0,X)��X��ȡֵ����Ϊ"+soType);
	}
}
